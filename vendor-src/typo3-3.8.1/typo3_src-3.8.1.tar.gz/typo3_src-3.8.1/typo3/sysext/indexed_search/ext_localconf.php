<?php
if (!defined ('TYPO3_MODE')) 	die ('Access denied.');

t3lib_extMgm::addPItoST43($_EXTKEY);

t3lib_extMgm::addTypoScript($_EXTKEY,'editorcfg','
	tt_content.CSS_editor.ch.tx_indexedsearch = < plugin.tx_indexedsearch.CSS_editor
',43);

	// Attach to hooks:
$TYPO3_CONF_VARS['SC_OPTIONS']['tslib/class.tslib_fe.php']['pageIndexing'][] = 'EXT:indexed_search/class.indexer.php:tx_indexedsearch_indexer';
$TYPO3_CONF_VARS['SC_OPTIONS']['tslib/class.tslib_fe.php']['headerNoCache']['tx_indexedsearch'] = 'EXT:indexed_search/class.indexer.php:&tx_indexedsearch_indexer->fe_headerNoCache';

	// Register with "crawler" extension:
$TYPO3_CONF_VARS['EXTCONF']['crawler']['procInstructions']['tx_indexedsearch_reindex'] = 'Re-indexing';

	// Configure default document parsers:
$TYPO3_CONF_VARS['EXTCONF']['indexed_search']['external_parsers'] = array(
	'pdf' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'doc' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'pps' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'ppt' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'xls' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'sxc' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'sxi' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'sxw' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'rtf' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'txt' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'html' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'htm' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'csv' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'xml' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'jpg' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'jpeg' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
	'tif' => 'EXT:indexed_search/class.external_parser.php:&tx_indexed_search_extparse',
);


	// EXAMPLE configuration of hooks:
/*
$TYPO3_CONF_VARS['EXTCONF']['indexed_search']['pi1_hooks'] = array (
	'initialize_postProc' => 'EXT:indexed_search/example/class.pihook.php:&tx_indexedsearch_pihook',
	'getResultRows' => 'EXT:indexed_search/example/class.pihook.php:&tx_indexedsearch_pihook',
	'printResultRow' => 'EXT:indexed_search/example/class.pihook.php:&tx_indexedsearch_pihook',
	'prepareResultRowTemplateData_postProc' => 'EXT:indexed_search/example/class.pihook.php:&tx_indexedsearch_pihook',
);
*/

	// EXAMPLE of adding fields to root line:
#$TYPO3_CONF_VARS['EXTCONF']['indexed_search']['addRootLineFields']['level3'] = 3;

?>