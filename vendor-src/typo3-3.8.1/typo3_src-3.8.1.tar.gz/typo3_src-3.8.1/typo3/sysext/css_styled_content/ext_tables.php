<?php
# TYPO3 CVS ID: $Id: ext_tables.php,v 1.1 2004/11/16 15:21:46 typo3 Exp $
if (!defined ('TYPO3_MODE')) 	die ('Access denied.');

t3lib_extMgm::addStaticFile($_EXTKEY,'static/','CSS Styled Content');
?>