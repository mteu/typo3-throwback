<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Extension to userauth.php; Authentication of users in Typo3 Backend
 *
 * Expects global var TYPO3_CONF_VARS
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



include_once(PATH_t3lib."class.t3lib_tsparser.php"); 

class t3lib_userAuthGroup extends t3lib_userAuth {
	var $usergroup_column = "usergroup";		// Should be set to the usergroup-column (id-list) in the user-record
	var $usergroup_table = "be_groups";			// The name of the group-table

		// internal
	var $groupData = Array(				// This array holds lists of eg. tables, fields and other values related to the permission-system. See fetchGroupData
		"filemounts" => Array()		// Filemounts are loaded here
	);

	var $userGroups = Array();			// This array will hold the groups that the user is a member of
	var $userGroupsUID = Array();		// This array holds the uid's of the groups in the listed order
	var $groupList ="";					// This is $this->userGroupsUID imploded...
	var $dataLists=array(				// Used internally to accumulate data for the user-group
		"webmount_list"=>"",
		"filemount_list"=>"",
		"modList"=>"",
		"tables_select"=>"",
		"tables_modify"=>"",
		"pagetypes_select"=>"",
		"non_exclude_fields"=>""
	);
	var $includeHierarchy=array();		// For debugging/display of order in which subgroups are included.
	var $includeGroupArray=array();		// List of group_id's in the order they are processed.

	var $OS="";		// Set to "WIN", if windows
	var $TSdataArray=array();		// Used to accumulate the TSconfig data of the user
	var $userTS = array();
	var $userTSUpdated=0;	


	function fetchGroupData()	{
		// initializes a lot of stuff like the access-lists, database-mountpoints and filemountpoints
		if ($this->user["uid"])	{
				// Get lists
			$this->dataLists["modList"] = $this->user["userMods"];
			$this->dataLists["webmount_list"] = $this->user["db_mountpoints"];
			$this->dataLists["filemount_list"] = $this->user["file_mountpoints"];

				// Setting default configuration:
			$this->TSdataArray[]=$GLOBALS["TYPO3_CONF_VARS"]["BE"]["defaultUserTSconfig"];
		
				// Init TSconfig
			if ($this->isAdmin())	{
				$this->TSdataArray[]="
					admPanel.enable.all = 1
					setup.default.deleteCmdInClipboard = 1
					// Setting defaults for sys_note author / email...
					TCAdefaults.sys_note.author = ".$this->user["realName"]."
					TCAdefaults.sys_note.email = ".$this->user["email"]."
					TCAdefaults.tt_news.author = ".$this->user["realName"]."
					TCAdefaults.tt_news.author_email = ".$this->user["email"]."
					options.shortcutFrame=1
				";
			}
				// user filemounts
				// Admin users has the base fileadmin dir mounted
			if ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["fileadminDir"] && $this->isAdmin())	{	
				$this->addFileMount($GLOBALS["TYPO3_CONF_VARS"]["BE"]["fileadminDir"], "", PATH_site.$GLOBALS["TYPO3_CONF_VARS"]["BE"]["fileadminDir"], 0, "");
			}
				// If userHomePath is set, we attempt to mount it
			if ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["userHomePath"])	{
				$didMount=$this->addFileMount($this->user["username"], "", $GLOBALS["TYPO3_CONF_VARS"]["BE"]["userHomePath"].$this->user["uid"]."_".$this->user["username"], 0, "user");
				if (!$didMount)	{		// If no user-dir with prepended name, then mount without.
					$this->addFileMount($this->user["username"], "", $GLOBALS["TYPO3_CONF_VARS"]["BE"]["userHomePath"].$this->user["uid"], 0, "user");
				}
			}

				// Get the groups...
			$grList = t3lib_BEfunc::getSQLselectableList($this->user[$this->usergroup_column],$this->usergroup_table,$this->usergroup_table);
			if ($grList)	{
				$this->fetchGroups($grList);
			}
				// Add the TS for the user him self.
			$this->TSdataArray[] = $this->user["TSconfig"];
//debug($this->TSdataArray);
				// Parsing the user TS (or getting from cache)
			$userTS = implode($this->TSdataArray,chr(10)."[GLOBAL]".chr(10));
			$hash = md5("userTS:".$userTS);
			$cachedContent = t3lib_BEfunc::getHash($hash,0);
			if (isset($cachedContent))	{
				$this->userTS = unserialize($cachedContent);
			} else {
				$parseObj = t3lib_div::makeInstance("t3lib_TSparser");
				$parseObj->parse($userTS);
				$this->userTS = $parseObj->setup;
				t3lib_BEfunc::storeHash($hash,serialize($this->userTS),"BE_USER_TSconfig");
					// Update UC:
				$this->userTSUpdated=1;
			}

				// Processing webmounts
			if ($this->isAdmin() && !$this->getTSConfigVal("options.dontMountAdminMounts"))	{	// Admin's always have the root mounted
				$this->dataLists["webmount_list"]="0,".$this->dataLists["webmount_list"];
			}
				// Processing filemounts
			$this->dataLists["filemount_list"]=t3lib_div::uniqueList($this->dataLists["filemount_list"]);
			if ($this->dataLists["filemount_list"])	{
				$res = mysql(TYPO3_db,"SELECT * FROM sys_filemounts WHERE NOT deleted AND NOT hidden AND pid=0 AND uid IN (".$this->dataLists["filemount_list"].")");
				while ($row=mysql_fetch_assoc($res))	{
					$this->addFileMount($row["title"], $row["path"], $row["path"], $row["base"]?1:0, "");
				}
			}
			
				// The lists are cleaned for duplicates
			$this->groupData["webmounts"] = t3lib_div::uniqueList($this->dataLists["webmount_list"]);
			$this->groupData["pagetypes_select"] = t3lib_div::uniqueList($this->dataLists["pagetypes_select"]);
			$this->groupData["tables_select"] = t3lib_div::uniqueList($this->dataLists["tables_modify"].",".$this->dataLists["tables_select"]);
			$this->groupData["tables_modify"] = t3lib_div::uniqueList($this->dataLists["tables_modify"]);
			$this->groupData["non_exclude_fields"] = t3lib_div::uniqueList($this->dataLists["non_exclude_fields"]);
			$this->groupData["modules"] = t3lib_div::uniqueList($this->dataLists["modList"]);


				// populating the $this->userGroupsUID -array with the groups in the order in which they were LAST included.!!
	//			debug($this->includeGroupArray);
				
			$this->userGroupsUID = array_reverse(array_unique(array_reverse($this->includeGroupArray)));
//			debug($this->userGroupsUID);
			
				// Finally this is the list of group_uid's in the order they are parsed (including subgroups!) and without duplicates (duplicates are presented with their last entrance in the list, which thus reflects the order of the TypoScript in TSconfig)
			$this->groupList = implode(",",$this->userGroupsUID);
			$this->setCachedList($this->groupList);


//debug($this->groupList);
//debug($this->groupData);
//debug($this->TSdataArray);
//debug($this->includeGroupArray);
//debug($this->userTS);
//debug($this->groupList);
		}
	}
	function setCachedList($cList)	{
		if ($cList!=$this->user["usergroup_cached_list"])	{
			$query="UPDATE be_users SET usergroup_cached_list='".addslashes($cList)."' WHERE uid=".intval($this->user["uid"]);
			$res = mysql(TYPO3_db,$query);
//			debug($query,1);
		}
	}
	/**
	 * Returns the value/properties of a TS-object as given by $objectString, eg. "options.dontMountAdminMounts"
	 */
	function getTSConfig($objectString,$config="")	{
		if (!is_array($config))	{
			$config=$this->userTS;	// Getting Root-ts if not sent
		}
		$TSConf=array();
		$parts = explode(".",$objectString,2);
		$key = $parts[0];
		if (trim($key))	{
			if (count($parts)>1 && trim($parts[1]))	{
				// Go on, get the next level
				if (is_array($config[$key."."]))	$TSConf = $this->getTSConfig($parts[1],$config[$key."."]);
			} else {
				$TSConf["value"]=$config[$key];
				$TSConf["properties"]=$config[$key."."];
			}
		}
		return $TSConf;
	}
	function getTSConfigVal($objectString)	{
		$TSConf = $this->getTSConfig($objectString);
		return $TSConf["value"];
	}
	function getTSConfigProp($objectString)	{
		$TSConf = $this->getTSConfig($objectString);
		return $TSConf["properties"];
	}
	function fetchGroups($grList,$idList="")	{
			// Fetching records:
		$lockToDomain_SQL = " AND (lockToDomain='' OR lockToDomain='".getenv("HTTP_HOST")."')";
		$res = mysql(TYPO3_db,"SELECT * FROM ".$this->usergroup_table." WHERE NOT deleted AND NOT hidden AND pid=0 AND uid IN (".$grList.")".$lockToDomain_SQL);
		while ($row=mysql_fetch_assoc($res))	{
				// The userGroups array is filled
			$this->userGroups[$row["uid"]]=$row;
		}
		
			// Traversing records in the correct order
		$include_staticArr = t3lib_div::intExplode(",",$grList);
		reset($include_staticArr);
		while(list(,$uid)=each($include_staticArr))	{	// traversing list
				// Get row:
			$row=$this->userGroups[$uid];
			if (is_array($row) && !t3lib_div::inList($idList,$uid))	{	// Must be an array and $uid should not be in the idList, because then it is somewhere previously in the grouplist
					// Include sub groups
				if (trim($row["subgroup"]) )	{
					$theList = implode(t3lib_div::intExplode(",",$row["subgroup"]),",");
					$this->fetchGroups($theList, $idList.",".$uid);
				}
				$this->includeGroupArray[]=$uid;
				$this->includeHierarchy[]=$idList;
				$this->TSdataArray[] = $row["TSconfig"];

					// Mount group database-mounts
				if (($this->user["options"]&1) == 1)	{	$this->dataLists["webmount_list"].= ",".$row["db_mountpoints"];	}
	
					// Mount group file-mounts
				if (($this->user["options"]&2) == 2)	{	$this->dataLists["filemount_list"].= ",".$row["file_mountpoints"];	}
	
					// Mount group home-dirs
				if (($this->user["options"]&2) == 2)	{
						// If groupHomePath is set, we attempt to mount it
					if ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["groupHomePath"])	{
						$this->addFileMount($row["title"], "", $GLOBALS["TYPO3_CONF_VARS"]["BE"]["groupHomePath"].$row["uid"], 0, "group");
					}
				}

					// The lists are made: groupMods, tables_select, tables_modify, pagetypes_select, non_exclude_fields
				if ($row["inc_access_lists"]==1)	{
					$this->dataLists["modList"].= ",".$row["groupMods"];
					$this->dataLists["tables_select"].= ",".$row["tables_select"];
					$this->dataLists["tables_modify"].= ",".$row["tables_modify"];
					$this->dataLists["pagetypes_select"].= ",".$row["pagetypes_select"];
					$this->dataLists["non_exclude_fields"].= ",".$row["non_exclude_fields"];
				}
				if (!strcmp($idList,"") && !$this->firstMainGroup)	{
					$this->firstMainGroup=$uid;
				}
			}
		}
		
	}
	function isAdmin()	{
		// returns true if user is admin
		return ($this->user["admin"]&1==1);
	}
	function isRTE()	{
		global $CLIENT;
		if (
			$CLIENT["BROWSER"]=="msie" && 
			$CLIENT["SYSTEM"]=="win" && 
			$CLIENT["VERSION"]>=5 && 
			$this->uc["edit_RTE"] &&
			$GLOBALS["TYPO3_CONF_VARS"]["BE"]["RTEenabled"]
			)	{
				return 1;
		} else {
			return 0;
		}
	}
	function check ($type,$value)	{
		// Returns true if the $value is found in the list in $this->groupData[] pointed to by $type. 
		// If user is admin true is also returned
		if (isset($this->groupData[$type]))	{
			if ($this->user["admin"] || $this->inList($this->groupData[$type],$value)) {
				return 1;
			}
		}
	}
	function inList($in_list,$item)	{
			// Returns true if $item is in $in_list
		return strstr(",".$in_list.",", ",".$item.",");
	}
	function addFileMount($title, $altTitle, $path, $webspace, $type)	{
		// This adds a file-mount point
		if ($webspace && !$GLOBALS["TYPO3_CONF_VARS"]["BE"]["fileadminDir"])	return false;	// Return false if fileadminDir is not set and we try to mount a relative path
		$path=trim($path);
		if ($this->OS=="WIN")	{		// with WINDOWS convert backslash to slash!!
			$path=str_replace("\\","/",$path);
		}
		if ($path && !strstr($path,"\\") && !strstr($path,"..") && !strstr($path,"//"))	{
			$path=ereg_replace("^[\/\. ]*","",$path);	// these lines remove all slashes and dots before and after the path
			$path=trim(ereg_replace("[\/\. ]*$","",$path));
			if ($path)	{	// there must be some chars in the path
				$fdir=PATH_site.$GLOBALS["TYPO3_CONF_VARS"]["BE"]["fileadminDir"];	// fileadmin dir
				if ($webspace)	{
					$path=$fdir.$path;	// PATH_site + fileadmin dir is prepended
				} else {
					if ($this->OS!="WIN")	{		// with WINDOWS no prepending!!
						$path="/".$path;	// root-level is the start...
					}
				}
				$path.="/";
				if (@is_dir($path) &&
					(($GLOBALS["TYPO3_CONF_VARS"]["BE"]["lockRootPath"] && t3lib_div::isFirstPartOfStr($path,$GLOBALS["TYPO3_CONF_VARS"]["BE"]["lockRootPath"])) || t3lib_div::isFirstPartOfStr($path,$fdir)))	{
						$name = $title ? $title : $altTitle;
						$this->groupData["filemounts"][md5($name."|".$path."|".$type)] = Array("name"=>$name, "path"=>$path, "type"=>$type);
						return 1;
				}
			}
		}
	}

	
	
	// ************************************
	// Logging:
	// ************************************
	
	function writelog($type,$action,$error,$details_nr,$details,$data,$tablename="",$recuid="",$recpid="",$event_pid=-1,$NEWid="") {
		// Writes an entry in the logfile
		/*
			$type:		- denotes which module that has submitted the entry. This is the current list:
				1: tce_db
				2: tce_file
				3: system (eg. sys_history save)
				4: modules
				254:	Personal settings changed
				255:	login / out action: 1=login, 2=logout, 3=failed login (+ errorcode 3), 4=failure_warning_email sent
			$action:	- denotes which specific operation that wrote the entry (eg. "delete", "upload", "update" and so on...). Specific for each $type. Also used to trigger update of the interface.
				(see the log-module for the meaning of each number !!)
			$error:		- flag. 0 = message, 1 = error (user problem), 2 = System Error (which should not happen), 3 = security notice (admin)
			$details:	- Default text that follows the message
			$details_nr:	- The message number. Specific for each $type and $action. in the future this will make it possible to translate errormessages to other languages
			$data:		- Data that follows the log. Might be used to carry special information. If an array the first 5 entries (0-4) will be sprintf'ed the details-text...

			$tablename, $recuid, $recpid:	Special fields used by tce_main.php. These holds the reference to the record which the log-entry is about. Used in status.php to update the interface.
			$event_pid:		The page_uid (pid) where the event occurred. Used to select log-content for specific pages.
			$NEWid:			NEWid string
		*/
		$userid = $this->user["uid"];
		$tstamp = $GLOBALS["EXEC_TIME"];
		if (TYPO3_db)	{
			$query = "INSERT INTO sys_log (userid,type,action,error,details_nr,details,log_data,tablename,recuid,recpid,IP,tstamp,event_pid,NEWid) ". 
					"VALUES (".intval($userid).",".intval($type).",".intval($action).",".intval($error).",".intval($details_nr).",'".addslashes($details)."','".addslashes(serialize($data))."','".$tablename."',".intval($recuid).",".intval($recpid).",'".getenv("REMOTE_ADDR")."',".$tstamp.",".intval($event_pid).",'".addslashes($NEWid)."')";
			mysql(TYPO3_db,$query);
			return mysql_insert_id();
		}
	}
	function checkLogFailures($email, $secondsBack=3600, $max=3)	{
		if ($email)	{
			$theTimeBack = time()-$secondsBack;
				// get last flag set in the log for sending 
			$query = "SELECT tstamp FROM sys_log where type=255 and action=4 and tstamp>".$theTimeBack." order by tstamp desc limit 1";
			$res = mysql(TYPO3_db,$query);
			if ($testRow=mysql_fetch_assoc($res))	{
				$theTimeBack = $testRow["tstamp"];
			}
				// Check for more than $max number of error failures with the last period.
			$query = "SELECT * FROM sys_log where type=255 and action=3 and error!=0 and tstamp>".$theTimeBack." order by tstamp";
			$res = mysql(TYPO3_db,$query);
			if (mysql_num_rows($res)>$max)	{
				$subject = 'Typo3 Login Failure Warning (at '.$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"].')';
				$email_body = '
There has been numerous attempts ('.mysql_num_rows($res).') to login at the Typo3
site "'.$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"].'" ('.getenv("HTTP_HOST").').

This is a dump of the failures:

';
				while($testRows=mysql_fetch_assoc($res))	{
					$theData = unserialize($testRows["log_data"]);
					$email_body.=date($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["ddmmyy"]." H:i",$testRows["tstamp"]).":  ".sprintf($testRows["details"],"".$theData[0],"".$theData[1],"".$theData[2]);
					$email_body.=chr(10);
				}
				mail(	$email,
						$subject,
						$email_body,
						"From: Typo3 Login WARNING<>"
				);
				$this->writelog(255,4,0,3,"Failure warning (%s failures within %s seconds) sent by email to %s",Array(mysql_num_rows($res),$secondsBack,$email));	// Logout written to log
			}
		}
	}
	
	


	// ************************************
	// Permission checking functions:
	// ************************************

	function calcPerms($row)	{
		// Returns a combined binary representation of the current users permissions for the page-record $row.
		// The perms for user, group and everybody is OR'ed together (provided the the page-owner is the user and for the groups that the user is a member of the group
		// If the user is admin, 31 is returned	
		if ($this->isAdmin()) {return 31;}
		$out=0;
		if (isset($row["perms_userid"]) && isset($row["perms_user"]) && isset($row["perms_groupid"]) && isset($row["perms_group"]) && isset($row["perms_everybody"]) && isset($this->groupList))	{
			if ($this->user["uid"]==$row["perms_userid"])	{
				$out|=$row["perms_user"];
			}
			if ($this->isMemberOfGroup($row["perms_groupid"]))	{
				$out|=$row["perms_group"];
			}
			$out|=$row["perms_everybody"];
		}
		return $out;
	}
	function isMemberOfGroup($groupId)	{
		// Returns true if the current user is a member of group $groupId
		// $groupId must be set. $this->groupList must contain groups
		$groupId = intval($groupId);
		if ($this->groupList && $groupId)	{
			return $this->inList($this->groupList, $groupId);
		}
	}
	function getPagePermsClause($perms)	{
		// Returns a where-clause for the pages-table where we've taken the permissions into account. 
		// $perms is the "mask" used to select. Fx. if $perms is 1 then you'll get all pages that a user can actually see!
		// 2^0 = show (1)
		// 2^1 = edit (2)
		// 2^2 = delete (4)
		// 2^3 = new (8)

		if ($this->user)	{
			if ($this->user["admin"])	{
				return " 1=1";
			}
			$str= " (".
				"(pages.perms_everybody & $perms = $perms)".
				"OR(pages.perms_userid = ".$this->user["uid"]." AND pages.perms_user & $perms = $perms)";
			if ($this->groupList){$str.="OR(pages.perms_groupid in (".$this->groupList.") AND pages.perms_group & $perms = $perms)";}
			$str.=")";
			return $str;
		} else {
			return " 1=0";
		}
	}
	function doesUserHaveAccess($row,$perms)	{	
		// Checks if the permissions is granted based on a page-record ($row) and $perms (binary and'ed)
		// $row is the pagerow for which the permissions is checked
		// $perms is the binary representation of the permission we are going to check. Every bit in this number represents a permission that must be set
	/*		
			1 - Show:	See/Copy page and the pagecontent.
			16- Edit pagecontent: Change/Add/Delete/Move pagecontent.
			2- Edit page: Change/Move the page, eg. change title, startdate, hidden.
			4- Delete page: Delete the page and pagecontent.
			8- New pages: Create new pages under the page.
	*/	
		$userPerms = $this->calcPerms($row);
		return ($userPerms & $perms)==$perms;
	}
	function isPSet($lCP,$table,$type)	{
		if ($this->isAdmin())	return true;
		if ($table=="pages")	{
			if ($type=="edit")	return $lCP & 2;
			if ($type=="new")	return ($lCP & 8) || ($lCP & 16);	// Create new page OR pagecontent
			if ($type=="delete")	return $lCP & 4;
			if ($type=="editcontent")	return $lCP & 16;
		} else {
			return $lCP & 16;
		}
	}
	function isInWebMount($id,$readPerms="",$exitOnError=0)	{
		if (!$GLOBALS["TYPO3_CONF_VARS"]["BE"]["lockBeUserToDBmounts"] || $this->isAdmin())	return 1;
		$id = intval($id);
		if (!$readPerms)	$readPerms = $this->getPagePermsClause(1);
		if ($id>0)	{
			$wM=$this->returnWebmounts();
			$rL=t3lib_BEfunc::BEgetRootLine($id," AND ".$readPerms);
			reset($rL);
			while(list(,$v)=each($rL))	{
				if ($v["uid"] && in_array($v["uid"],$wM))	{
//debug(array($v["uid"],$wM,in_array($v["uid"],$wM)));
					return $v["uid"];
				}
			}
		}
		if ($exitOnError)	{
			t3lib_BEfunc::typo3PrintError ("Access Error","This page is not within your DB-mounts",0);
			exit;
		}
	}
	function modAccess($conf,$exitOnError)	{
			// Returns true if conf[access] is not set at all or if the user is admin
			// If $conf["access"] is set but not with "admin" then we return true, if the module is found in the modList
		if (!$conf["access"]  ||  $this->isAdmin()) return true;
		if (!strstr($conf["access"],"admin") && $conf["name"])	{
			$acs = $this->check("modules",$conf["name"]);
		}
		if (!$acs && $exitOnError)	{
			t3lib_BEfunc::typo3PrintError ("Access Error","You don't have access to this module.",0);
			exit;
		} else return $acs;
	}
	function returnWebmounts()	{
		return (string)($this->groupData["webmounts"])!="" ? explode(",",$this->groupData["webmounts"]) : Array();
	}
	function returnFilemounts()	{
		return $this->groupData["filemounts"];
	}
	function mayMakeShortcut()	{
		return $this->getTSConfigVal("options.shortcutFrame") && !$this->getTSConfigVal("options.mayNotCreateEditShortcuts");
	}
	
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_userauthgroup.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_userauthgroup.php"]);
}

?>