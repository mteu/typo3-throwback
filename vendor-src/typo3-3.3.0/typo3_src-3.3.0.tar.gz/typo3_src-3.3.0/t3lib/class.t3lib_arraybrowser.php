<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Class for displaying an array as a tree
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_arrayBrowser	{
	var $depthKeys = array();
	var $searchKeys = array();
	var $fixedLgd=1;
	var $regexMode=0;
	
	function tree($arr, $depth_in, $depthData)	{
		$HTML="";
		$a=0;

		if ($depth_in)	{$depth_in = $depth_in.".";}
		
		$c=count($arr);
		reset($arr);
		while (list($key,)=each($arr))	{
			$a++;
			$depth=$depth_in.$key;
			$goto = substr(md5($depth),0,6);

			$deeper = (is_array($arr[$key]) && $this->depthKeys[$depth]) ? 1 : 0;
			$PM = "join";
			$LN = ($a==$c)?"blank":"line";
			$BTM = ($a==$c)?"bottom":"";
			$PM = is_array($arr[$key]) ? ($deeper ? "minus":"plus") : "join";


			$HTML.=$depthData;
			$theIcon='<IMG src="'.$GLOBALS["BACK_PATH"].'t3lib/gfx/ol/'.$PM.$BTM.'.gif" width="18" height="16" align="top" border=0>';
			if ($PM=="join")	{
				$HTML.=$theIcon;
			} else {
				$HTML.='<a name="'.$goto.'" href="index.php?node['.$depth.']='.($deeper?0:1).'#'.$goto.'">'.$theIcon.'</a>';
			}


			$label = $key;
			$HTML.="[".$label."]";

			if (!is_array($arr[$key]))	{
				$theValue = $arr[$key];
				if ($this->fixedLgd)	{
					$imgBlocks = ceil(1+strlen($depthData)/77);
//					debug($imgBlocks);
					$lgdChars = 68-ceil(strlen("[".$key."]")*0.8)-$imgBlocks*3;
					$theValue = $this->fixed_lgd($theValue,$lgdChars);
				}
				if ($this->searchKeys[$depth])	{
					$HTML.='=<b><font color="red">'.htmlspecialchars($theValue).'</font></b>';
				} else {
					$HTML.="=<b>".htmlspecialchars($theValue)."</b>";
				}
			} 
			$HTML.="<BR>";
				
			if ($deeper)	{
				$HTML.=$this->tree($arr[$key], $depth, $depthData.'<IMG src="'.$GLOBALS["BACK_PATH"].'t3lib/gfx/ol/'.$LN.'.gif" width="18" height="16" align="top">');
			}
		}
		return fw($HTML);
	}
	function getSearchKeys($keyArr, $depth_in, $searchString, $keyArray)		{
		reset($keyArr);
		$c=count($keyArr);
		if ($depth_in)	{$depth_in = $depth_in.".";}
		while (list($key,)=each($keyArr))	{
			$depth=$depth_in.$key;
			$deeper = is_array($keyArr[$key]);
			
			if ($this->regexMode)	{
				if (ereg($searchString,$keyArr[$key]))	{	$this->searchKeys[$depth]=1;	}
			} else {
				if (stristr($keyArr[$key],$searchString))	{	$this->searchKeys[$depth]=1;	}
			}
			
			if ($deeper)	{
				$cS = count($this->searchKeys);
				$keyArray = $this->getSearchKeys($keyArr[$key], $depth, $searchString, $keyArray);
				if ($cS != count($this->searchKeys))	{
					$keyArray[$depth]=1;
				}
			}
		}	
		return $keyArray;
	}
	function fixed_lgd($string,$chars)	{
		if ($chars >= 4)	{
			if(strlen($string)>$chars)  {
				return substr($string, 0, $chars-3)."...";
			}
		}
		return $string;
	}
	function depthKeys($arr,$settings)	{
		reset($arr);
		$tsbrArray=array();
		while(list($theK,$theV)=each($arr))	{
			$theKeyParts = explode(".",$theK);
			$depth="";
			$c=count($theKeyParts);
			$a=0;
			while(list(,$p)=each($theKeyParts))	{
				$a++;
				$depth.=($depth?".":"").$p;
				$tsbrArray[$depth]= ($c==$a) ? $theV : 1;
			}
		}
			// Modify settings
		reset($tsbrArray);
		while(list($theK,$theV)=each($tsbrArray))	{
			if ($theV)	{
				$settings[$theK] = 1;
			} else {
				unset($settings[$theK]);
			}
		}
		return $settings;
	}
}

if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_arraybrowser.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_arraybrowser.php"]);
}


?>