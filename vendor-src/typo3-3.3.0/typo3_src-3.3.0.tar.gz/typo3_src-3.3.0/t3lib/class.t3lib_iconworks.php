<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Icon generation, backend
 *
 * 
 * This library has functions that returns - and if necessary creates - the icon for a element in Typo3
 * 
 * 
 * Expects global vars:
 * - $BACK_PATH
 * - PATH_typo3
 * - $TCA, $PAGES_TYPES
 * 
 * 
 * Notes:
 * These functions are strongly related to the interface of Typo3.
 * The file is included in eg. init.php
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_iconWorks	{
	
	function getIconImage($table,$row=array(),$backPath,$params="",$shaded=0)	{
		$str='<img src="'.$backPath.t3lib_iconWorks::getIcon($table,$row,$shaded).'" width=18 height=16 border=0'.(trim($params)?" ".trim($params):"").'>';
		return $str;
	}
	function getIcon($table,$row=array(),$shaded=0)	{
		global $TCA, $PAGES_TYPES, $ICON_TYPES;
		$user=false;
		if ($table=="pages")	{
			if (!$iconfile = $PAGES_TYPES[$row["doktype"]]["icon"])	{
				$iconfile = $PAGES_TYPES["default"]["icon"];
			}
			if ($row["module"] && $ICON_TYPES[$row["module"]]["icon"])	{
				$iconfile = $ICON_TYPES[$row["module"]]["icon"];
			}
	/*		if ($row[fe_group] && $row[doktype]<200)	{
				$user=$row[fe_group];
			}*/
		} else {
			if (!$iconfile = $TCA[$table][ctrl][typeicons][$row[$TCA[$table][ctrl][typeicon_column]]])	{
				$iconfile = (($TCA[$table][ctrl][iconfile]) ? $TCA[$table][ctrl][iconfile] : $table.".gif");
			}
		}
			// Setting path if not already set:
		if (!strstr($iconfile,"/"))	{
			$iconfile = "gfx/i/".$iconfile;
		}
		if (substr($iconfile,0,3)=="../")	{
			$absfile=PATH_site.substr($iconfile,3);
		} else {
			$absfile=PATH_typo3.$iconfile;
		}
		
		
		$hidden = false;
		$timing = false;
		$futuretiming = false;
		$deleted = false;
		$protectSection=0;
		if ($enCols=$TCA[$table][ctrl][enablecolumns])	{
			if ($enCol=$row[$enCols[disabled]])	{if ($enCol){$hidden=true;}}
			if ($enCol=$row[$enCols[starttime]])	{if (time() < $enCol){$timing=true;}}
			if ($enCol=$row[$enCols[endtime]])	{
				if ($enCol!=0){
					if ($enCol < time())	{
						$timing=true;
					} else {
						$futuretiming=true;
					}
				} 
			}
			if ($enCol=$row[$enCols["fe_group"]])	{
				$user=$enCol;
/*				if ($table=="pages" && $row["fe_group_subpages"])	{
					$protectSection=1;
				}*/
			}		// new!!
		}
		if ($col=$row[$TCA[$table][ctrl][delete]])	{
			$deleted = true;
		}
		if ($table=="pages" && $row["extendToSubpages"] && ($hidden || $timing || $futuretiming || $user))	{
			$protectSection=1;
		}
		if ($hidden || $timing || $futuretiming || $deleted || $user || $shaded)	{
			$string="";
			if ($deleted)	{
				$string="deleted";
			} else {
				if ($hidden) $string.="hidden";
				if ($timing) $string.="timing";
				if (!$string && $futuretiming) {
					$string="futuretiming";
				}
			}
			$theRes= t3lib_iconWorks::makeIcon($GLOBALS["BACK_PATH"].$iconfile, $string, $user, $protectSection, $absfile);
			return $theRes;
		} else {
			return $iconfile;
		}
	}
	function makeIcon($iconfile,$mode, $user, $protectSection=0,$absFile="")	{
		$mainpath = "temp/icon_".t3lib_div::shortMD5($iconfile."|".$mode."|-".$user."|".$protectSection).".gif";
		$path = PATH_typo3.$mainpath;
		if (@file_exists($path))	{
			return $mainpath;
		} else {
			if (@file_exists($absFile))	{
				if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"] && !$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib_png"])	{
					$im = imagecreatefromgif($absFile);
					if ($mode!="futuretiming" && !(!$mode && $user))	{
						for ($c=0; $c<ImageColorsTotal($im); $c++)	{
							$cols = ImageColorsForIndex($im,$c);
							$newcol = round(($cols[red]+$cols[green]+$cols[blue])/3);
							$lighten = 2;
							$newcol = round (255-((255-$newcol)/$lighten));
							ImageColorSet($im,$c,$newcol,$newcol,$newcol);
						}
					}
					if ($user)	{
						$black = ImageColorAllocate($im, 0,0,0);
						imagefilledrectangle($im, 0,0,(($user>10)?9:5),8,$black);
						
						$white = ImageColorAllocate($im, 255,255,255);
						imagestring($im, 1, 1, 1, $user, $white);
		
//						$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_".($protectSection ? "accesssection":"group").".gif");
						$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_group.gif");
						imagecopyresized($im, $ol_im, 0, 0, 0, 0, imagesx($ol_im), imagesy($ol_im), imagesx($ol_im), imagesy($ol_im));
					}
					if ($mode)	{
						unset($ol_im);
						switch($mode)	{
							case "deleted":
								$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_deleted.gif");
							break;
							case "futuretiming":
								$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_timing.gif");
							break;
							case "timing":
								$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_timing.gif");
							break;
							case "hiddentiming":
								$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_hidden_timing.gif");
							break;
							case "hidden":
							default:
								$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_hidden.gif");
							break;
						}
						imagecopyresized($im, $ol_im, 0, 0, 0, 0, imagesx($ol_im), imagesy($ol_im), imagesx($ol_im), imagesy($ol_im));
					}
					if ($protectSection)	{
						$ol_im = imagecreatefromgif($GLOBALS["BACK_PATH"]."gfx/overlay_sub5.gif");
						imagecopyresized($im, $ol_im, 0, 0, 0, 0, imagesx($ol_im), imagesy($ol_im), imagesx($ol_im), imagesy($ol_im));
					}
					@ImageGif($im, $path);
					t3lib_div::gif_compress($path, "IM");
					ImageDestroy($im);
					return $mainpath;
				} else {
					return $iconfile;
				}
			} else {
				return $GLOBALS["BACK_PATH"]."gfx/fileicons/default.gif";
			}
		}
	}
}


?>