<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Customization
 *
 * This document (tables.php) holds all customized values that makes Typo work against a given MySQL database.
 * Please don't edit this file directly as it's regularly updated. 
 *
 * Rather use the $typo_db_extTableDef_script variable in localconf.php to point to a script-filename in typo3conf/ folder which will be included subsquently to this file and in that file you can then modify the TCA array as you like...
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
 

 
/*
************************
$PAGES_TYPES

this array defines the different types of pages (the obligatory table "pages"!)
Here you can set the icon and especially you can define which tables are allowed on a certain pagetype (doktype)
NOTE: The "default" entry in the $PAGES_TYPES-array is the "base" for all types, and for every 
type the entries simply overrides the entries in the "default" type!!
************************
*/

$PAGES_TYPES = Array(
	"3" => Array(
		"icon" => "pages_link.gif"
	),
	"4" => Array(
		"icon" => "pages_shortcut.gif"
	),
	"5" => Array(
		"icon" => "pages_notinmenu.gif"
	),
	"6" => Array(	
		"type" => "web",
		"icon" => "be_users_section.gif",
		"allowedTables" => "*"
	),
	"199" => Array(		// TypoScript: Limit is 200. When the doktype is 200 or above, the page WILL NOT be regarded as a "page" by TypoScript. Rather is it a system-type page
		"type" => "sys",
		"icon" => "spacer_icon.gif",
	),
	"254" => Array(	
		"type" => "sys",
		"icon" => "sysf.gif",
		"allowedTables" => "*"
	),
	"255" => Array(		// Typo3: Doktype 255 is a recycle-bin. Documents will be put here when deleted. See manual
		"type" => "sys",
		"icon" => "recycler.gif",
		"allowedTables" => "*"
	),
	"default" => Array(
		"type" => "web",
		"icon" => "pages.gif",
		"allowedTables" => "pages,pages_language_overlay,tt_content,tt_links,tt_board,tt_guest,tt_address,tt_calender,tt_products,tt_news,sys_template,sys_dc,sys_domain,sys_note,pages_language_overlay",
		"onlyAllowedTables" => "0"
	)
);

$ICON_TYPES = Array(
	"shop" => Array("icon" => "modules_shop.gif"),
	"board" => Array("icon" => "modules_board.gif"),
	"news" => Array("icon" => "modules_news.gif"),
	"dmail" => Array("icon" => "modules_dmail.gif"),
	"fe_users" => Array("icon" => "modules_fe_users.gif"),
	"approve" => Array("icon" => "modules_approvals.gif")
);




$LANG_GENERAL_LABELS = array(
	"endtime" => "Stop:|Stop:|Stop:|Stopp:|Fine:|Arr�t:|Final:|Stop:|Stop:|Stop:|Stop:|Stop:|Durdur:",
	"hidden" => "Hide:|Skjul:|Verstecken:|Skjul:|Nascondi:|Cacher:|Ocultar:|Verberg:|Skr�t:|Ukryj:|Skrij:|Piilota:|Sakla:",
	"starttime" => "Start:|Start:|Start:|Start:|Inizio:|Lancement:|Inicio:|Start:|Start:|Start:|Start:|Aloita:|Ba�lat:",
	"fe_group" => "Access:|Adgang:|Zugriff:|Adgang:|Accesso:|Acc�s:|Acceso:|Toegang:|P��stup:|Uprawnienia:|Dostop:|P��syoikeus:|Eri�im:",
	"hide_at_login" => "Hide at login|Skjul ved login|Beim Login verstecken|Skjul ved login|Nascondo al login|Cacher � la connexion|No mostrar si hay sesi�n|Verberg bij login|Skr�t po p�ihl�en�|Ukryj po zalogowaniu|Skrij ob prijavi|Piilota sis��nkirjoituksessa|Giri�te gizle",
	"any_login" => "Show at any login|Vis ved alle logins|Bei jeden Login anzeigen|Vis ved alle login||||Toon bij elke login||Poka� po zalogowaniu||N�yt� kaikilla sis��nkirjoituksilla|Giri�te g�ster",
	"usergroups" => "__Usergroups:__|__Brugergrupper:__|__Benutzergruppen:__|__Brukergrupper:__|__Gruppo utenti:__|__Groupes utilisateurs:__|__Grupos de usuarios:__|__Gebruikersgroep:__|__Skupiny u�ivatel�:__|__Grupy u�ytk.:__|__Upor. skupine:__|__K�ytt�j�ryhm�t:__|__Kullan�c� grubu:__",
	"type" => "Type:|Type:|Typ:|Type:|Tipo:|Type:|Tipo:|Type:|Typ:|Typ:|Tip:|Tyyppi:|T�r:",
	"description" => "Description:|Beskrivelse:|Beschreibung:|Beskrivelse:|Descrizione:|Descrition:|Descripci�n:|Omschrijving:|Popis:|Opis:|Opis:|Kuvaus:|Tan�t�m:",
	"prependAtCopy" => " (copy %s)| (kopi %s)| (kopiere %s)| (kopi %s)| (copia %s)| (copie %s)| (copiar %s)| (kopie %s)| (kopie %s)| (kopiuj %s)|(kopija %s)|(kopioi %s)|(kopyala %s)",
	"layout" => "Layout:|Layout:|Layout:|Layout:|Layout:|Pr�paration-type:|Layout:|Layout:|Layout:|Uk�ad:|Izgled:|Muotomalli:|Sayfa d�zeni:",
	"default_value" => "Default|Standard|Standard|Standard|Predefinito|Par d�faut|Default|Standaard|Z�kladn�|Domy�lnie|Privzeto|Oletusarvo|Standart",
	"normal" => "Normal|Normal|Normal|Normal|Normale|Normal|Normal|Normaal|Norm�ln�|Normalnie|Normalno|Normaali|Normal",
	"images" => "Images:|Billeder:|Bilder:|Bilder:|Immagini:|Images:|Im�genes:|Afbeeldingen:|Obr�zky:|Obrazki:|Slike:|Kuvat:|Resimler:",
	"image" => "Image:|Billede:|Bild:|Bilde:|Immagine:|Image:|Im�gen:|Afbeelding:|Obr�zek:|Obrazek:|Slika:|Kuva:|Resim:",
	"caption" => "Caption:|Billedtekst:|Bildtext:|Bildetekst:|Caption:|Titre:|Pi� de foto:|Onderschrift:|Popisek:|Podpis:|Napis:|Kuvateksti|Man�et:",
	"subheader" => "Subheader:|Manchet:|Untertitel:|Undertittel:|Sottointestazione:|Sous-titre:|Subt�tulo:|Subkop:|Podnadpis:|Podnag��wek:|Podnaslov:|Alaotsikko:|Alt ana ba�l�k:",
	"text" => "Text:|Tekst:|Text:|Tekst:|Testo:|Texte:|Texto:|Tekst:|Text:|Tekst:|Tekst:|Teksti:|Metin:",
	"name" => "Name:|Navn:|Name:|Navn:|Nome:|Nom:|Nombre:|Naam:|N�zev:|Nazwa:|Ime:|Nimi:|�sim:",
	"title" => "Title:|Titel:|Titel:|Tittel:|Titolo:|Titre:|T�tulo:|Titel:|Titul:|Tytu�:|Naziv:|Arvo:|Ba�l�k:",
	"address" => "Address:|Adresse:|Adresse:|Adresse:|Indirizzo:|Adresse:|Direcci�n:|Adres:|Adresa:|Adres:|Naslov:|Osoite:|Adres:",
	"phone" => "Phone:|Telefon:|Telefon:|Telefon:|Telefono:|T�l�phone:|Tel�fono:|Telefoon:|Telefon:|Telefon:|Telefon:|Puhelin:|Telefon:",
	"fax" => "Fax:|Fax:|Fax:|Fax:|Fax:|Fax:|Fax:|Fax:|Fax:|Fax:|Faks:|Fax:|Fax:",
	"author" => "Author:|Forfatter:|Autor:|Forfatter:|Autore:|Auteur:|Autor:|Auteur:|Autor:|Autor:|Avtor:|Kirjoittaja:|Yazar:",
	"email" => "Email:|Email:|Email:|Epost:|Email:|E-mail:|Email:|Email:|E-mail:|Email:|Email:|S�hk�posti:|E-mail:",
	"company" => "Company:|Firma:|Firma:|Firma:|Societa\':|Soci�t�:|Empresa:|Bedrijf:|Firma:|Firma:|Podjetje:|Yritys:|Firma:",
	"city" => "City:|By:|Stadt:|By:|Citta\':|Localit�:|Ciudad:|Stad:|M�sto:|Miasto:|Mesto:|Kaupunki:|�ehir:",
	"zip" => "Zipcode:|Postnr:|PLZ:|Postnr:|CAP:|NPA:|C�digo Postal:|Postcode:|PS�:|Kod pocztowy:|Po�tna �t.:|Postinumero:|Posta kodu:",
	"country" => "Country:|Land:|Land:|Land:|Paese:|Pays:|Pa�s:|Land:|St�t:|Kraj:|Dr�ava:|Maa:|�lke:",
	"www" => "www:|www:|www:|www:|sito web:|www:|sitio web:|www:|www:|www:|www:|WWW:|www:",
	"note" => "Note:|Note:|Bemerkung:|Merk deg:|Note:|Note:|Nota:|Opmerking:|Pozn�mka:|Notatka:|Opomba:|Huomautus:|Not:",
	"parameters" => "Parameters:|Parametre:|Parameter:|Parameter:|Parametri:|Param�tres:|Par�metros:|Parameters:|Parametry:|Parametry:|Parametri:|Muuttujat:|Parametreler:",
	"code" => "CODE:|KODE:|CODE:|KODE:|CODICE:|CODE:|CODE:|CODE:|K�D:|KOD:|KODA:|CODE:|KOD:",
	"links" => "Links|Links|Links|Linker|Links|Liens:|Ligas|Links|Odkazy|Odno�niki|Povezave|Linkit|Linkler",
	"language" => "Language:|Sprog:|Sprache:|Spr�k:|Lingua:|Langues:|Lenguaje:|Taal:|Jazyk:|J�zyk:|Jezik|Kieli|Dil:",
	"category" => "Category:|Kategori:|Kategorie:|Kategori:|Categoria:|Cat�gorie:|Categor�a:|Categorie:|Kategorie:|Kategoria:|Kategorija:|Luokka:|Kategori:",
	"shortcut_page" => "Shortcut to page:|Genvej til side:|Shortcut zur Seite:|Snarvei til side:|Collegamento alla pagina:|Raccourci vers page:|Acceso directo a la p�gina:|Snelkoppeling naar pagina:|Zkratka na stranu:|Skr�t do strony:|Bli�njica do strani:|Pikavalinta sivulle:|Sayfaya k�sayol:",
	"keywords" => "Keywords (,):|N�gleord (,):|Stichworte (,):|N�kkelord (,):|Parole chiavi:|Mots-cl� (,):|Palabras clave (,):|Kernwoorden (,):|Kl��ov� slova (,):|S�owa kluczowe (,):|Klju�ne besede (,):|Avainsanat (,):|Anahtar kelimeler (,):",
	"disable" => "Disable:|Inaktiv:|Inaktiv:|Deaktiv:|Disabilitato:|D�sactiver:|Deshabilitar:|Uitschakelen:|Inaktivovat:|Wy��cz:|Izklopi:|Poista k�yt�st�:|Devre d��� b�rak:",
	"startingpoint" => "Startingpoint:|Udgangspunkt:|Ausgangspunkt:|Utgangspunkt:|Punto di partenza:|Point de d�marrage:|Lugar de inicio:|Startpunt:|Za��tek:|Punkt startowy:|Za�ni na:|Aloituspaikka:|Ba�lama noktas�:",
	"disableRTE" => "Disable Rich Text Editor:|Sl� formatteret redigering fra:|Rich Text Editor abschalten:|Ikke benytt \'Rik tekst editor\':|Disabilita Rich Text:|D�sactiver Rich Text Editor:|Desactivar editor RTF:|Deactiveer Tekst Plus Editor (TPE):||Wy��cz RTE:|Izklopi urejevalnik oblikovanega besedila:|Poista RTE k�yt�st�:|Zengin Metin D�zenleyiciyi devre d��� b�rak:",
//	"userDefined" => "User defined %1\$s|Brugerdefineret %1\$s|Benutzerdefiniert %1\$s|Brukerdefinert %1\$s|Definizione utente %1\$s|D�fini par l'utilisateur %1\$s|Definido por el usuario %1\$s|Gebruiker gedefinieerd %1\$s|Definovan� u?ivatelem %1\$s|Zdefiniowane %1\$s|Uporabni�ko dolo�eno %1\$s|K�ytt�j�n m��ritelm� %1\$s",
//	"frame" => "Frame %1\$s|Ramme %1\$s|Rahmen %1\$s|Ramme %1\$s|Frame %1\$s|Frame %1\$s|Marco %1\$s|Frame %1\$s|R�me�ek %1\$s|Otoczka %1\$s|Okvir %1\$s|Raami %1\$s",
//	"category_num" => "Cat %1\$s|Kat %1\$s|Kat %1\$s|Kat %1\$s|Cat %1\$s|Cat %1\$s|Cat %1\$s|Cat %1\$s|Cat %1\$s|Kategoria %1\$s|Kat. %1\$s|Luokka %1\$s",
	"external" => "External URL|Extern URL|Externe URL|Ekstern URL|URL esterno|URL externe|URL Externo|Externe URL|Extern� URL|URL zewn�trzny|Eksterni URL|Ulkopuolinen URL|D�� URL",
	"recursive" => "Recursive:|Rekursivt:|Rekursiv:|Rekursivt:|Recorsivita:|Niveaux d\'aborescence:|Recursivo:|Recursief:|Rekurzivn�:|Rekursywnie:|||Yinele:"
);



/*****************************************************************************************************************

$TCA:

this array defines the tables and the relationship between them 
and how the fields in tables are treated and so on


See documentation for the syntax and list of required tables/fields!


tables:
 must contain:
   uid, pid, (tstamp??)

pages:
must ALSO contain
  deleted, (doktype??)
  
  
NOTE: You cannot use the single-quote (') in textlabels for fields (unless you escape it like this: (\')). This will not work out when the label is transferred to JavaScript in ti_inc.php. You MAY use double-qoute (")!
		Labels for item-lists or tablenames may include single-quotes and they MUST NOT be escaped!!
NOTE: The (default) icon for a table is defined 1) as a giffile named "gfx/i/[tablename].gif" or 2) as the value of [table][ctrl][iconfile]
NOTE: [table][ctrl][rootLevel] goes NOT for pages. Apart from that if rootLevel is true, records can ONLY be created on rootLevel. If it's false records can ONLY be created OUTSIDE rootLevel

******************************************************************************************/ 

/*


Languages:

All labels are split by "|".
The order of the languages can be seen in typo3/lang/lang.php

Currently it's:

default | Danish | German | Norwegian | Italian | French | Spanish | Netherlands | Czech | Polish | Slovenian
(default|da|de|no|it|fr|es|nl|cz|pl|si)


*/





// ******************************************************************
// This is the mandatory pages table. 
// Must be completely configured in tables.php
// ******************************************************************
$TCA["pages"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"sortby" => "sorting",
		"title" => "Page|Side|Seite|Side|Pagina|Page|P�gina|Pagina|Strana|Strona|Stran|Sivu|Sayfa",
		"type" => "doktype",
		"delete" => "deleted",
		"crdate" => "crdate",
		"hideAtCopy" => 1,
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"cruser_id" => "cruser_id",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime",
			"fe_group" => "fe_group",
		),
		"mainpalette" => 1,
		"useColumnsForDefaultValues" => "doktype,fe_group,hidden"
	),
	"interface" => Array (
		"showRecordFieldList" => "doktype,title,alias,hidden,starttime,endtime,fe_group,url,target,no_cache,shortcut,keywords,description,abstract,newUntil,lastUpdated,cache_timeout",
		"maxDBListItems" => 30,
		"maxSingleDBListItems" => 50
	),
	"columns" => Array (	
		"doktype" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (	
					Array("Standard|Standard|Standard|Standard|Standard|Standard|Standard|Standaard|Standardn�|Standardowa|Standardno|Normaali|Standart", "1"),
					Array("Advanced|Avanceret|Erweitert|Avansert|Avanzato|Avanc�|Avanzado|Uitgebreid|Pokro�il�|Rozszerzona|Napredno|Laajennettu|Geli�mi�", "2"),
					Array($LANG_GENERAL_LABELS["external"], "3"),
					Array("Shortcut|Genvej|Shortcut|Snarvei|Collegamento|Raccourci|Acceso directo|Snelkoppeling|Zkratka|Skr�t do strony|Bli�njica|Pikavalinta|K�sayol", "4"),
					Array("Not in menu|Ikke i menu|Nicht im Men�|Ikke I Meny|Non presente nel menu|Absent du menu|No presentar en el men�|Niet in het menu|Nen� v menu|Nie w menu|Ni v meniju|Ei valikkoon|Men�de de�il", "5"),
					Array("Backend User Section|Opdateringsbruger sektion|Backend Benutzer Bereich|Oppdateringsbruker seksjon|Backend User Section|Section utilisateur Backend|Selecci�n de usuario del Backend|Gebruikers Sectie BeheerSite|Odd�l u?ivatele backendu|Dla u�ytkownika||Backenc k�ytt�j� osa|Arkaplan kullan�c� b�l�m�", "6"),
					Array("-----", "--div--"),
					Array("Spacer|Mellemrum|Abstand|Mellomrom|Spacer|D�limiteur|Delimitador|Tussenruimte|Mezera|Oddzielacz|Presledek|Spacer|Bo�luk veren", "199"),
					Array("SysFolder|SysFolder|SysOrdner|SysMappe|Cartella di sistema|Dossier syst�me|Carpeta del sistema|SysMap|Syst�mov� slo�ka|Folder systemowy|SysMapa|SysFolder|Sistem klas�r�", "254"),
					Array("Recycler|Papirkurv|Papierkorb|Papirkurv|Cestino|Corbeille|Cesta|Prullenbak|Ko�|Kosz|Ko�|Recycler|Geri d�n���m sa�layan", "255")
				),
				"default" => "1"
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => "Hide page:|Skjul side:|Seite verstecken:|Skjul side:|Nascondi pagina:|Cacher page:|Ocultar p�gina:|Verberg pagina:|Skr�t stranu:|Ukryj stron�:|Skrij stran:|Piillota sivu:|Sayfa gizle:",
			"config" => Array (
				"type" => "check",
				"default" => "1"
			)
		),
		"starttime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["starttime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["endtime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"layout" => Array (
			"exclude" => 1,
			"label" => $LANG_GENERAL_LABELS["layout"],
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["normal"], "0"),
					Array("Layout 1|Layout 1|Layout 1|Layout 1|Layout 1|Pr�paration-type 1|Layout 1|Layout 1|Layout 1|Uk�ad 1|Oblika 1|Malli 1|Sayfa d�zeni 1", "1"),
					Array("Layout 2|Layout 2|Layout 2|Layout 2|Layout 2|Pr�paration-type 2|Layout 2|Layout 2|Layout 2|Uk�ad 2|Oblika 2|Malli 2|Sayfa d�zeni 2", "2"),
					Array("Layout 3|Layout 3|Layout 3|Layout 3|Layout 3|Pr�paration-type 3|Layout 3|Layout 3|Layout 3|Uk�ad 3|Oblika 3|Malli 3|Sayfa d�zeni 3", "3")
				),
				"default" => "0"
			)
		),
		"fe_group" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["fe_group"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (
					Array("", 0),
					Array($LANG_GENERAL_LABELS["hide_at_login"], -1),
					Array($LANG_GENERAL_LABELS["any_login"], -2),
					Array($LANG_GENERAL_LABELS["usergroups"], "--div--")
				),
				"foreign_table" => "fe_groups"
			)
		),
		"extendToSubpages" => Array (
			"exclude" => 1,	
			"label" => "Include subpages:|Omfat undersider:|Inklusive Unterseiten:|Inkluder undersider:|Includi sottopagine:|Inclure les sous-pages:|Incluir subp�ginas:|Subpagina\'s opnemen:|Vlo�it podstrany:|Do��cz podstrony:|Vklju�i podstrani:|Sis�llyt� alasivut:|Alt sayfalar� dahil et:",
			"config" => Array (
				"type" => "check"
			)
		),
		"title" => Array (
			"label" => "Pagetitle:|Sidetitel:|Seitentitel:|Sidetittel:|Titolo pagina:|Titre visible sur le c�t�:|T�tulo de la p�gina:|Paginatitel:|Titul strany:|Tytu�:|Naslov strani:|Sivun otsikko:|Sayfa ba�l���:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"max" => "256",
				"eval" => "required"
			)
		),
		"nav_title" => Array (
			"exclude" => 1,	
			"label" => "Navigation title:|Titel i menuen:|Navigationstitel:|Tittel i menyen:||||Navigatietitel:||Tytu� nawigacyjny:||Valikon otsikko:|Navigation ba�l���:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"max" => "256",
				"checkbox" => "",
				"eval" => "trim"
			)
		),
		"subtitle" => Array (
			"exclude" => 1,	
			"label" => "Subtitle:|Undertitel:|Untertitel:|Undertittel:|Sottotitolo:|Sous-titre:|Subt�tulo:|Subtitel:|Podtitul:|Podtytu�:|Podnaslov:|Alaotsikko:|Alt ba�l�k:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"max" => "256",
				"eval" => ""
			)
		),
		"target" => Array (
			"exclude" => 1,	
			"label" => "Target:|Target:|Ziel:|Target:|Obiettivo:|Cible:|Target:|Doel:|Target:|Target:|Cilj:|Kohde:|Hedef:",
			"config" => Array (
				"type" => "input",	
				"size" => "7",
				"max" => "20",
				"eval" => "trim",
				"checkbox" => ""
			)
		),
		"alias" => Array (
			"label" => "Alias:|Alias:|Alias:|Alias:|Alias:|Alias:|Alias:|Alias:|Alias:|Alias:||Aliasnimi:|Takma ad�:",
			"config" => Array (
				"type" => "input",	
				"size" => "10",
				"max" => "20",
				"eval" => "nospace,alphanum_x,lower,unique"
			)
		),
		"url" => Array (
			"label" => "URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:",
			"config" => Array (
				"type" => "input",		
				"size" => "25",
				"max" => "256",
				"eval" => "trim"
			)
		),
		"urltype" => Array (
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("", "0"),
					Array("http://", "1"),
					Array("ftp://", "2"),
					Array("mailto:", "3")
				),
				"default" => "1"
			)
		),
		"lastUpdated" => Array (
			"exclude" => 1,	
			"label" => "Last updated:|Sidst opdateret:|Letzte �nderung:|Sist oppdatert:|Ultimo aggiornamento:|Derni�re mise � jour:|�ltima modificaci�n:|Laatste aanpassing:|Posledn� aktualizace:|Ostatnio zmieniana:|Zadnja sprememba:|Viimeinen p�ivitys:|En son g�ncelleme:",
			"config" => Array (
				"type" => "input",
				"size" => "12",
				"max" => "20",
				"eval" => "datetime",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"newUntil" => Array (
			"exclude" => 1,	
			"label" => "\'New\' until:|\'Ny\' indtil:|\'Neu\' bis:|\'Ny\' inntil:|\'Nuovo\' dal:|\'Nouveau\' jusqu\'�:|\'Nuevo\' hasta:|\'Nieuw\' tot:|\'Nov�\' do:|\'Nowo��\' do:|\'Novo\' do:|\'Uusi\' saakka:|\'Yeni\' kadar:",
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"cache_timeout" => Array (
			"exclude" => 1,	
			"label" => "Cache expires:|Cachen udl�ber:|Cache verf�llt:|Cachen utl�per:|Scadenza cache:|Renouvellement du cache:|Cache expira:|Cache periode verloopt:|Cache expiruje:|Wa�no�� cache:|Prepomnilnik pote�e:|V�limuisti poistuu:|�n bellek yok oluyor:",
			"config" => Array (
				"type" => "select",
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["default_value"], 0),
					Array("1 min|1 min|1 Min|1 min|1 min|1 min|1 min|1 min|1 min|1 min|1 min|1 min|1 dk", 60),
					Array("5 min|5 min|5 Min|5 min|5 min|5 min|5 min|5 min|5 min|5 min|5 min|5 min|5 dk", 5*60),
					Array("15 min|15 min|15 Min|15 min|15 min|15 min|15 min|15 min|15 min|15 min|15 min|15 min|15 dk", 15*60),
					Array("30 min|30 min|30 Min|30 min|30 min|30 min|30 min|30 min|30 min|30 min|30 min|30 min|30 dk", 30*60),
					Array("1 hour|1 time|1 Stunde|1 time|1 ora|1 heure|1 hora|1 uur|1 h|1 godzina|1 ura|1 tunti|1 saat", 60*60),
					Array("4 hours|4 timer|4 Stunden|4 timer|1 ore|4 heures|4 horas|4 uur|4 h|4 godziny|4 ura|4 tuntia|4 saat", 4*60*60),
					Array("1 day|1 dag|1 Tag|1 dag|1 giorno|1 jour|1 d�a|1 dag|1 den|1 dzie�|1 dan|1 p�iv�|1 g�n", 24*60*60),
					Array("2 days|2 dage|2 Tage|2 dager|2 giorni|2 jours|2 d�as|2 dagen|2 dny|2 dni|2 dneva|2 p�iv��|2 g�n", 2*24*60*60),
					Array("7 days|7 dage|7 Tage|7 dager|7 giorni|7 jours|7 d�as|7 dagen|7 dn�|7 dni|7 dni|7 p�iv��|7 g�n", 7*24*60*60),
					Array("1 month|1 m�ned|1 Monat|1 m�ned|1 mese|1 mois|1 mes|1 maand|1 m�s�c|1 miesi�c|1 mesec|1 kuukausi|1 ay", 31*24*60*60)
				),
				"default" => "0"
			)
		),
		"no_cache" => Array (
			"exclude" => 1,	
			"label" => "No cache:|Ingen cache:|Nicht cachen:|Ingen cache:|No cache:|Pas de cache:|Sin cache:|Geen cache:|Bez cache:|Bez cache:|Ni predpomnilnika:|Ei v�limuistia:|�n bellek yok:",
			"config" => Array (
				"type" => "check"
			)
		),
		"no_search" => Array (
			"exclude" => 1,	
			"label" => "No search:|Ingen s�gning:|Nicht suchen:|Ingen s�king:|No ricerca:|Pas de recherche:|Sin b�squeda:|Niet zoeken:|Nehledat:|Nie wyszukuj:|Ni iskanja:|Ei hakua:|Arama yok:",
			"config" => Array (
				"type" => "check"
			)
		),
		"shortcut" => Array (
			"label" => $LANG_GENERAL_LABELS["shortcut_page"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "pages",
				"size" => "3",
				"maxitems" => "1",
				"minitems" => "0",	// Change from '1' 090102
				"show_thumbs" => "1"
			)
		),
		"keywords" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["keywords"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"description" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["description"],
			"config" => Array (
				"type" => "input",		
				"size" => "40",
				"eval" => "trim"
			)
		),
		"abstract" => Array (
			"exclude" => 1,	
			"label" => "Abstract:|Sammendrag:|Inhaltsangabe:|Sammendrag:|Abstract:|Abstract:|Abstracto:|Samenvatting:|Abstrakt:|Skr�t zawarto�ci:|Izvle�ek:|Lyhennelm�:|�zet:",
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"author" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["author"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"author_email" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["email"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"TSconfig" => Array (
			"exclude" => 1,	
			"label" => "TSconfig:||||TSconfig:|||TSconfig:|||||TSconfig:",
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "5",
				"wizards" => Array(
					"_PADDING" => 4,
					"0" => Array(
						"type" => "popup",
						"title" => "TSconfig QuickReference",
						"script" => "wizard_tsconfig.php?mode=page",
						"icon" => "wizard_tsconfig.gif",
						"JSopenParams" => "height=500,width=780,status=0,menubar=0,scrollbars=1",
					)
				)
			)
		),
		"module" => Array (
			"exclude" => 1,	
			"label" => "Contains plugin:|Indeholder plugin:|Enth�lt Erweiterung:|Inneholder plugin:||||Bevat plugin:||Zawiera wtyczki:||Sis�lt�� plugin:|Mod�l:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", ""),
					Array("Shop|Butik|Shop|Webshop|Negozio|Magasin|Tienda|Winkel|Obchod|Sklep|Trgovina|Kauppa|Ma�aza", "shop"),
					Array("Board|Forum|Forum|Forum|Board|Forum|Foro|Forum|F�rum|Forum|Oglasna deska|Keskustelu|�lan tahtas�", "board"),
					Array("News|Nyheder|News|Nyheter|News|Nouvelles|Noticias|Nieuws|Zpr�vy|Newsy|Novice|Uutiset|Haber", "news"),
					Array("Website users|Website brugere|Website Benutzer|Webomr�de brukere|Sito utente|Utilisateurs web|Usuarios del website|Website gebruikers|U?ivatel website|U�ytkownicy zewn�trzni|Web Uporabniki|WWW-sivujen k�ytt�j�t|Website kullan�c�lar�", "fe_users"),
					Array("Direct Mail|Direct-mail|Direct Mail|Direct Mail|Direct Mail|Direct Mail|Correo Directo|Direct Mail|Direct Mail|Mailing bezpo�redni|Direct Mail|Suora s�hk�posti|Do�rudan mail", "dmail"),
					Array("Approvals|Godkendelser|Abstimmungen|Godkjenninger|Approvati|Acceptation|Aprovaciones|Akkoord|Souhlasy|Potwierdzenia|Odobritve|Hyv�ksynt�|Onaylamalar", "approve")
				),
				"default" => ""
			)
		),
		"treeStop" => Array (		// This flag demands a little note: If it's set, the JavaScript-loaded page tree in the TBE will NOT descend beyond this point. This may be cool if you have more than a 1000 pages and don't want them all to load! You can still use the "LIST" submodule to descend the tree (and the other non-JS tree browsers)
			"exclude" => 1,	
			"label" => "JS stop:||||JS stop:|||JS stop:|||||JS durdur:",
			"config" => Array (
				"type" => "check"
			)
		),
		"media" => Array (
			"exclude" => 1,	
			"label" => "Files:|Filer:|Dateien:|Filer:|Files:|Fichiers:|Archivos:|Bestanden:|Soubory:|Pliki:|Datoteke:|Tiedostot:|Dosyalar:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"].",html,htm,ttf,txt,css",
				"max_size" => "2000",
				"uploadfolder" => "uploads/media",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "5",
				"minitems" => "0"
			)
		),
		"is_siteroot" => Array (
			"exclude" => 1,	
			"label" => "Is root of website:|Siden er websitets rod:|Ist Anfang der Webseite:|Siden er webomr�dets rot:||||Is basis van website:||Jest korzeniem witryny:||T�m� on websivujen juuri:|Websitesinin k�k�:",
			"config" => Array (
				"type" => "check"
			)
		),
		"php_tree_stop" => Array (
			"exclude" => 1,	
			"label" => "Stop page tree:|Stop sidetr�:|Seitenbaum stoppen:|Stopp sidetre:||||Stop paginaboomstructuur:||Zablokuj drzewo stron:||Ei sivujen puurakennetta:|Sayfa a�ac�n� durdur:",
			"config" => Array (
				"type" => "check"
			)
		),
		"storage_pid" => Array (
			"exclude" => 1,	
			"label" => "General Record Storage page:|Generel elementlager-side:|Allgemeine Datensatzsammlung:|Generell elementlagerside:||||Algemene recordopslag:||Strona przechowuj�ca rekordy:||Yleinen tietovarasto sivu:|Genel Kay�t Depolama sayfas�:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "pages",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
	),
	"types" => Array (					
		"1" => Array("showitem" => "hidden;;;;1-1-1, doktype;;2;button, title;;3;;2-2-2, subtitle, TSconfig;;6;nowrap;5-5-5, storage_pid;;7"),
		"2" => Array("showitem" => "hidden;;;;1-1-1, doktype;;2;button, title;;3;;2-2-2, subtitle, nav_title, --div--, abstract;;5;;3-3-3, keywords, description, media;;;;4-4-4, --div--, TSconfig;;6;nowrap;5-5-5, storage_pid;;7, module"),
		"3" => Array("showitem" => "hidden;;;;1-1-1, doktype, title;;3;;2-2-2, url;;4;;3-3-3, TSconfig;;6;nowrap;5-5-5, storage_pid;;7"),
		"4" => Array("showitem" => "hidden;;;;1-1-1, doktype, title;;3;;2-2-2, shortcut;;;;3-3-3, TSconfig;;6;nowrap;5-5-5, storage_pid;;7"),
		"5" => Array("showitem" => "hidden;;;;1-1-1, doktype;;2;button, title;;3;;2-2-2, subtitle, TSconfig;;6;nowrap;5-5-5, storage_pid;;7"),
		"199" => Array("showitem" => "hidden;;;;1-1-1, doktype, title;;;;2-2-2, TSconfig;;6;nowrap;5-5-5, storage_pid;;7"),
		"254" => Array("showitem" => "hidden;;;;1-1-1, doktype, title;".$LANG_GENERAL_LABELS["title"].";;;2-2-2, --div--, TSconfig;;6;nowrap;5-5-5, storage_pid;;7, module"),
		"255" => Array("showitem" => "hidden;;;;1-1-1, doktype, title;;;;2-2-2, TSconfig;;6;nowrap;5-5-5, storage_pid;;7")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "starttime,endtime,fe_group,extendToSubpages"),
		"2" => Array("showitem" => "layout, lastUpdated, newUntil, no_search"),
		"3" => Array("showitem" => "alias, target, no_cache, cache_timeout"),
		"4" => Array("showitem" => "urltype"),
		"5" => Array("showitem" => "author,author_email"),
		"6" => Array("showitem" => "php_tree_stop,treeStop"),
		"7" => Array("showitem" => "is_siteroot")
	),
	""
);




// ******************************************************************
// This is the standard TypoScript content table, tt_content
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt_content.php
// ******************************************************************
$TCA["tt_content"] = Array (
	"ctrl" => Array (
		"label" => "header",
		"label_alt" => "subheader,bodytext",
		"sortby" => "sorting",
		"tstamp" => "tstamp",
		"title" => "Pagecontent|Sideindhold|Seiteninhalt|Sideinnhold|Contenuto pagina|Contenu de la page|Contenido de p�gina|Pagina-inhoud|Obsah strany|Zawarto��|Vsebina strani|Sivun sis�lt�|Sayfa i�eri�i",
		"delete" => "deleted",
		"type" => "CType",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"copyAfterDuplFields" => "colPos,sys_language_uid",
		"useColumnsForDefaultValues" => "colPos,sys_language_uid",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime",
			"fe_group" => "fe_group",
		),
		"typeicon_column" => "CType",
		"typeicons" => Array (
			"header" => "tt_content_header.gif",
			"textpic" => "tt_content_textpic.gif",
			"image" => "tt_content_image.gif",
			"bullets" => "tt_content_bullets.gif",
			"table" => "tt_content_table.gif",
			"splash" => "tt_content_news.gif",
			"uploads" => "tt_content_uploads.gif",
			"multimedia" => "tt_content_mm.gif",
			"menu" => "tt_content_menu.gif",
			"list" => "tt_content_list.gif",
			"mailform" => "tt_content_form.gif",
			"search" => "tt_content_search.gif",
			"login" => "tt_content_login.gif",
			"shortcut" => "tt_content_shortcut.gif",
			"script" => "tt_content_script.gif",
			"div" => "tt_content_div.gif",
			"html" => "tt_content_html.gif"
		),
		"mainpalette" => "1",
		"thumbnail" => "image",
		"dynamicConfigFile" => "T3LIB:tbl_tt_content.php"
	)
);



// ******************************************************************
// This is the standard TypoScript address table, tt_address
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_address"] = Array (
	"ctrl" => Array (
		"label" => "name",
		"default_sortby" => "ORDER BY name",
		"tstamp" => "tstamp",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"delete" => "deleted",
		"title" => "Address|Adresse|Adresse|Adresse|Indirizzo|Adresse|Direcci�n|Adres|Adresa|Adres|Naslov|Osoite:|Adres",
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"thumbnail" => "image",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	),
	"feInterface" => Array (
		"fe_admin_fieldList" => "pid,hidden,name,title,address,phone,fax,mobile,www,email,city,zip,company,country,description,module_sys_dmail_category,module_sys_dmail_html"
	)
);



// ******************************************************************
// This is the standard TypoScript links table, tt_links
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_links"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"default_sortby" => "ORDER BY title",
		"tstamp" => "tstamp",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"crdate" => "crdate",
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"title" => $LANG_GENERAL_LABELS["links"],
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);



// ******************************************************************
// This is the standard TypoScript guestbook
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_guest"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"default_sortby" => "ORDER BY crdate DESC",
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"title" => "Guestbook|G�stebog|G�stebuch|Gjestebok|Libro visitatori|Livre d'or|Libro de visitantes|Gastenboek|N�v�t�vn� kniha|Ksi�ga go�ci|Knjiga gostov|Vieraskirja|Z�yaret�i defteri",
		"iconfile" => "tt_faq_no.gif",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);



// ******************************************************************
// This is the standard TypoScript Board table, tt_board
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_board"] = Array (
	"ctrl" => Array (
		"label" => "subject",
		"default_sortby" => "ORDER BY parent,crdate DESC",		// crdate should gradually not be used! Trying to phase it out in favour of datetime.
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"delete" => "deleted",
		"copyAfterDuplFields" => "parent",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"title" => "Board|Forum|Forum|Forum|Board|Forum|Foro|Forum|F�rum|Forum|Oglasna deska|Keskustelu|�lan tahtas�",
		"typeicon_column" => "parent",
		"typeicons" => Array (
			"0" => "tt_faq_board_root.gif"
		),
		"useColumnsForDefaultValues" => "parent",
		"iconfile" => "tt_faq_board.gif",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);



// ******************************************************************
// This is the standard TypoScript calendar table, tt_calender
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_calender"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"default_sortby" => "ORDER BY date",
		"tstamp" => "tstamp",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"delete" => "deleted",
		"type" => "type",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime"
		),
		"mainpalette" => 1,
		"typeicon_column" => "type",
		"typeicons" => Array (
			"0" => "tt_calender.gif",
			"1" => "tt_calender_todo.gif"
		),
		"title" => "Calendar|Kalender|Kalender|Kalender|Calendario|Calendrier|Calendario|Kalender|Kalend��|Kalendarz|Koledar|Kalenteri|Takvim",
		"useColumnsForDefaultValues" => "type",
		"mainpalette" => 1,
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);




// ******************************************************************
// This is the standard TypoScript calendar category table, tt_calender_cat
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_calender_cat"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"crdate" => "crdate",
		"title" => "Calendar category|Kalender kategori|Kalender Kategorie|Kalender kategori|Categoria calendario|Cat�gorie du calendrier|Categor�a de calendario|Kalender categorie|Kategorie kalend��e|Kategoria kalendarza||Kalenteriluokka|Takvim kategorisi",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);




// ******************************************************************
// This is the standard TypoScript address table, tt_address
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_products"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"default_sortby" => "ORDER BY title",
		"tstamp" => "tstamp",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"delete" => "deleted",
		"title" => "Products|Produkter|Produkte|Produkter|Prodotti|Produits|Productos|Producten|Produkty|Produkty|Izdelki|Tuotteet:|�r�nler",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime",
			"fe_group" => "fe_group",
		),
		"thumbnail" => "image",
		"useColumnsForDefaultValues" => "category",
		"mainpalette" => 1,
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);




// ******************************************************************
// This is the standard TypoScript products category table, tt_products_cat
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_products_cat"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"crdate" => "crdate",
		"title" => "Product category|Produkt kategori|Produkt Kategorie|Produkt kategori|Categoria prodotto|Cat�gorie de produit|Categor�a de producto|Product categorie|Kategorie produktu|Kategoria produktu||Tuoteluokka|�r�n kategorisi",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);




// ******************************************************************
// This is the standard TypoScript news table, tt_news
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_news"] = Array (
	"ctrl" => Array (
		"title" => "News|Nyheder|News|Nyheter|News|Nouvelles|Noticias|Nieuws|Zpr�vy|Newsy|Novice|Uutiset|Haberler",
		"label" => "title",
		"default_sortby" => "ORDER BY datetime DESC",
		"tstamp" => "tstamp",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"crdate" => "crdate",
		"type" => "type",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime",
			"fe_group" => "fe_group",
		),
		"typeicon_column" => "type",
		"typeicons" => Array (
			"1" => "tt_news_article.gif",
			"2" => "tt_news_exturl.gif",
		),
		"thumbnail" => "image",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);




// ******************************************************************
// This is the standard TypoScript news category table, tt_news
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["tt_news_cat"] = Array (
	"ctrl" => Array (
		"title" => "News category|Nyheder kategori|News Kategorie|Nyhetskategori|Categoria News|Cat�gorie de nouvelles|Categor�as de noticias|Nieuws categorie|Kategorie zpr�v|Kategoria news�w|Kategorija novic|Uutisluokka|Haber kategorisi",
		"label" => "title",
		"tstamp" => "tstamp",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"crdate" => "crdate",
		"dynamicConfigFile" => "T3LIB:tbl_tt.php"
	)
);




// ******************************************************************
// sys_dmail
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["sys_dmail"] = Array (
	"ctrl" => Array (
		"label" => "subject",
		"default_sortby" => "ORDER BY tstamp DESC",
		"tstamp" => "tstamp",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"title" => "Direct mails|Direct mail|Direct Mails|Direct mail|Direct Mail|Direct mails|Correo directo|Direct mails|Direct mail|Maile bezpo�rednie|DirectMail sporo�ila|Suora s�hk�posti|Do�rudan mailler",
		"iconfile" => "mail.gif",
		"type" => "type",
		"useColumnsForDefaultValues" => "from_email,from_name,replyto_email,replyto_name,organisation,priority,sendOptions,type",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// sys_dmail_group
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_tt.php
// ******************************************************************
$TCA["sys_dmail_group"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"default_sortby" => "ORDER BY title",
		"tstamp" => "tstamp",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"title" => "Direct mail group|Direct mail gruppe|Direct Mail Gruppe|Direct mail gruppe|Gruppo Direct Mail|Groupe Direct Mail|Grupo de correo directo|Direct mail groep|Skupina Direct mail|Grupa mailowa|DirectMail skupina|Suora postituksen ryhm�|Do�rudan mail grubu",
		"delete" => "deleted",
		"iconfile" => "mailgroup.gif",
		"type" => "type",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);





// ******************************************************************
// fe_users
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_users.php
// ******************************************************************
$TCA["fe_users"] = Array (
	"ctrl" => Array (
		"label" => "username",
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"fe_cruser_id" => "fe_cruser_id",
		"title" => "Website user|Website bruger|Website Benutzer|Webside bruker|Utente Web|Utilisateur website|Usuarios del Website|Website gebruiker|U�ivatel website|U�ytkownik zewn�trzny|Web uporabnik|WWW-sivujen k�tt�j�|Website kullan�c�s�",
		"delete" => "deleted",
		"mainpalette" => "1",
		"enablecolumns" => Array (
			"disabled" => "disable",
			"starttime" => "starttime",
			"endtime" => "endtime"
		),
		"useColumnsForDefaultValues" => "usergroup,lockToDomain,disable,starttime,endtime",
		"dynamicConfigFile" => "T3LIB:tbl_users.php"
	),
	"feInterface" => Array (
		"fe_admin_fieldList" => "username,password,usergroup,name,address,telephone,fax,email,title,zip,city,country,www,company,module_sys_dmail_category,module_sys_dmail_html",
	)
);




// ******************************************************************
// fe_groups
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_users.php
// ******************************************************************
$TCA["fe_groups"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"delete" => "deleted",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"title" => "Website usergroup|Website brugergruppe|Website Benutzergruppe|Webside brukergruppe|Gruppo Utenti web|Groupe d'utilisateur website|Grupos de usuarios del Website|Webpagina gebruikersgroep|Skupina website|Grupa zewn�trzna|Skupina web uporabnikov|WWW-sivujen k�ytt�j� ryhm�|Website kullan�c� grubu",
		"useColumnsForDefaultValues" => "lockToDomain",
		"dynamicConfigFile" => "T3LIB:tbl_users.php"
	)
);




// ******************************************************************
// be_groups
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_users.php
// ******************************************************************
$TCA["be_users"] = Array (
	"ctrl" => Array (
		"label" => "username",
		"tstamp" => "tstamp",
		"title" => "Backend user|Opdaterings bruger|Backend Benutzer|Oppdater bruker|Utente backend|Utilisateur Backend|Operadores|BeheerSite gebruiker|U�ivatel backendu|U�ytkownik|Administrativni uporabnik|Backend k�ytt�j�|Arka plan kullan�c�s�",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"delete" => "deleted",
		"adminOnly" => 1,	// Only admin, if any
		"rootLevel" => 1,
		"default_sortby" => "ORDER BY admin, username",
		"enablecolumns" => Array (
			"disabled" => "disable",
			"starttime" => "starttime",
			"endtime" => "endtime"
		),
		"type" => "admin",
		"typeicon_column" => "admin",
		"typeicons" => Array (
			"0" => "be_users.gif",
			"1" => "be_users_admin.gif"
		),
		"mainpalette" => "1",
		"useColumnsForDefaultValues" => "usergroup,lockToDomain,options,db_mountpoints,file_mountpoints,fileoper_perms,userMods",
		"dynamicConfigFile" => "T3LIB:tbl_users.php"
	)
);




// ******************************************************************
// be_groups
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_users.php
// ******************************************************************
$TCA["be_groups"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"delete" => "deleted",
		"default_sortby" => "ORDER BY title",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"adminOnly" => 1,	// Only admin, if any
		"rootLevel" => 1,
		"type" => "inc_access_lists",
		"typeicon_column" => "inc_access_lists",
		"typeicons" => Array (
			"1" => "be_groups_lists.gif"
		),
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"title" => "Backend usergroup|Opdaterings brugergruppe|Backend Benutzergruppe|Oppdater brukergruppe|Gruppo backend|Groupe d'utilisateur Backend|Grupos de operadores|BeheerSite gebruikersgroep|U�ivatelsk� Skupina backendu|Grupa|Administrativna skupina|Backend k�ytt�j� ryhm�|Arka plan kullan�c� grubu",
		"useColumnsForDefaultValues" => "lockToDomain",
		"dynamicConfigFile" => "T3LIB:tbl_users.php"
	)
);




// ******************************************************************
// sys_filemounts
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_filemounts"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"title" => "Filemount|Filmount|Dateifreigaben|Filmount|Filemount|Point de montage|Punto de montaje de archivos|Bestandstartpunt|Filemount|Pod��czenie||Filemount|Dosya mount�",
		"adminOnly" => 1,	// Only admin, if any
		"rootLevel" => 1,
		"delete" => "deleted",
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"iconfile" => "_icon_ftp.gif",
		"useColumnsForDefaultValues" => "path,base",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// sys_domain
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_domain"] = Array (
	"ctrl" => Array (
		"label" => "domainName",
		"tstamp" => "tstamp",
		"sortby" => "sorting",
		"title" => "Domain|Dom�ne|Domain|Domene|Dominio|Domaine|Dominio|Domein|Dom�na|Domena|Domena|Domain:|Alan ad�",
		"iconfile" => "domain.gif",
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// This is the standard TypoScript Note table , sys_note
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_note"] = Array (
	"ctrl" => Array (
		"label" => "subject",
		"default_sortby" => "ORDER BY crdate",
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"cruser_id" => "cruser",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"delete" => "deleted",
		"title" => "Internal note|Intern note|Interne Notiz|Internt notis|Note interne|Note interne|Nota Interna|Interne opmerking|Intern� pozn�mka|Notatka wewn�trzna|Interna opomba|Sis�inen tiedote|�� k�sma ait not",
		"iconfile" => "sys_note.gif",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// Static file edit table
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_staticfile_edit"] = Array (
	"ctrl" => Array (
		"label" => "edit_file",
		"default_sortby" => "ORDER BY edit_file",
		"tstamp" => "tstamp",
		"crdate" => "crdate",
		"cruser_id" => "cruser",
		"delete" => "deleted",
		"title" => "HTML-file editing|Redigering af HTML-fil|HTML-Datei Bearbeitung|Redigering av HTML-fil|HTML-file editing|Editer un fichier HTML|Edici�n de archivo HTML|HTML opmaak||Edycja pliku HTML|Urejanje HTML datoteke|HTML-tiedsoton muokkaus|HTML-dosya d�zenleyici",
		"iconfile" => "sys_staticfile.gif",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// pages_language_overlay
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["pages_language_overlay"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"title" => "Alternative Page Language|Alternativt sidesprog|Alternative Seiten Sprache|Alternativt sidespr�k|Pagina alternativa del linguaggio|Langue alternative de la page|P�gina Alternaiva de Lenguaje|Alternatieve Pagina Taal|Alternativn� jazyk str�nky|Alternatywny j�zyk strony|Alternativni jezik strani|Vaihtoehtoisen sivun kieli|Alternatif sayfa dili",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime"
		),
		"mainpalette" => 1,
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// sys_action
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_action"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"default_sortby" => "ORDER BY title",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"title" => "Action|Handling|Befehl|Handling|Azione|Action|Aci�n|Actie|Akce|Akcja|Akcija|Toiminto|Faaliyeti",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"adminOnly" => 1,
		"rootLevel" => -1,
		"setToDefaultOnCopy" => "assign_to_groups",
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"type" => "type",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// sys_workflows
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_workflows"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"default_sortby" => "ORDER BY title",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"title" => "Workflow|Arbejdsgang|Workflow|Arbeidsflyt|Workflow|Workflow|Flujo de Trabajo|Werkschema|Workflow|Przydzia� prac|Potek dela:|Ty�kulku|�� ak���",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"adminOnly" => 1,
		"rootLevel" => 1,
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"type" => "final_set_perms",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// sys_language
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_language"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"default_sortby" => "ORDER BY title",
		"title" => "Website Language|Website sprog|Website Sprache|Webomr�despr�k|Linguaggio del Web|Langue du site web|Lenguaje del Website|Website Taal|Jazyk webu:|J�zyk witryny|Jezik spletnega mesta|WWW-sivuston kieli|Website dili",
		"adminOnly" => 1,
		"rootLevel" => 1,
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);





// ******************************************************************
// sys_dc - Design Component table
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_dc"] = Array (
	"ctrl" => Array (
		"title" => "Design Component|Design Komponent|Design Komponente|Design Komponent||||Design Component||Komponent Wygl�du||Suunnittelu Osa|Tasar�m Unsuru",
		"label" => "title",
		"tstamp" => "tstamp",
		"sortby" => "sorting",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"crdate" => "crdate",
		"cruser_id" => "cruser",
		"delete" => "deleted",
		"enablecolumns" => Array (
			"disabled" => "hidden"
		),
		"iconfile" => "default.gif",
		"type" => "component_type",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);





// ******************************************************************
// sys_dc_type - (Local) Design Component Type
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_dc_type"] = Array (
	"ctrl" => Array (
		"title" => "Design Component Type|Design Komponent Type|Design Komponenten Typ|Design Komponent Type||||Design Component Type||Typ Komponentu Wygl�du||Suunnittelu Osa Tyyppi|Tasar�m T�r� Unsuru",
		"label" => "title",
		"tstamp" => "tstamp",
		"adminOnly" => 1,	// Only admin, if any
		"rootLevel" => 1,
		"default_sortby" => "ORDER BY title",
		"iconfile" => "default.gif",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);





// ******************************************************************
// static_dc_type - Static Design Component Type
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["static_dc_type"] = Array (
	"ctrl" => Array (
		"title" => "Static Design Component Type|Statisk Design Komponent Type|Statischer Design Komponenten Typ|Statisk Design Komponent Type||||Statisch Design Component Type||Typ Statycznego Komponentu Wygl�du||Stattinen Suunnittelu Osa Tyyppi|Statik Tasar�m T�r� Unsuru",
		"label" => "title",
		"tstamp" => "tstamp",
		"readOnly" => 1,	// This should always be true, as it prevents the static templates from being altered
		"adminOnly" => 1,	// Only admin, if any
		"rootLevel" => 1,
		"default_sortby" => "ORDER BY title",
		"iconfile" => "default.gif",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);





// ******************************************************************
// sys_template
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["sys_template"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"sortby" => "sorting",
		"prependAtCopy" => $LANG_GENERAL_LABELS["prependAtCopy"],
		"title" => "Template|Skabelon|Template|Mal|Template|Gabariat|Template|Template|�ablona|Szablon|Predloga|Malli:|�ablon",
		"crdate" => "crdate",
		"cruser_id" => "cruser_id",
		"delete" => "deleted",
		"adminOnly" => 1,	// Only admin, if any
		"iconfile" => "template.gif",
		"thumbnail" => "resources",
		"enablecolumns" => Array (
			"disabled" => "hidden",
			"starttime" => "starttime",
			"endtime" => "endtime"
		),
		"typeicon_column" => "root",
		"typeicons" => Array (
			"0" => "template_add.gif"
		),
		"mainpalette" => "1",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);




// ******************************************************************
// static_template
//
// This is only the "header" part (ctrl). 
// The full configuration is found in t3lib/install/tbl_sys.php
// ******************************************************************
$TCA["static_template"] = Array (
	"ctrl" => Array (
		"label" => "title",
		"tstamp" => "tstamp",
		"title" => "Static templates|Faste skabeloner|Statisches Template|Faste maler|Template statici|Gabarits statiques|Template est�tico|Statische sjablonen|Statick� �ablony|Szablony statyczne|Stati�ne predloge|Pysyv�t mallit|Statik �ablonlar",
		"readOnly" => 1,	// This should always be true, as it prevents the static templates from being altered
		"adminOnly" => 1,	// Only admin, if any
		"rootLevel" => 1,
		"default_sortby" => "ORDER BY title",
		"crdate" => "crdate",
		"iconfile" => "template_standard.gif",
		"dynamicConfigFile" => "T3LIB:tbl_sys.php"
	)
);







/*

Modules configuraion. 


Every entry in this array represents a tab in the upper left corner pane in the Typo3 interface


Add Modules: 
If the key (associative key) of the entry exists as a folder by that same name in 
the folder "mod/"-folder AND if that folder holds a conf-file (with valid 
PHP-configuration inside!) then a tab is added to the pane. 
If this is not the case the entry is regarded as a "spacer" in the pane


Add Submodules: 
As long as the value of a valid (see above) module is empty ("") 
then no submodules are added. If not the value is regarded as a comma-sep. 
list of submodules. These must exist as subfolders to the modules folder 
and if the do not they are just regarded as spacers instead.

*/


$TBE_MODULES = Array (
	"web" => "layout,view,modules,list,info,perm,func,ts",
	"file" => "list,images",
	"doc" => "",	// This should always be empty!
	"spacer1"=>"",
	"user" => "task,setup",
	"tools" => "beuser,dbint,log,config,isearch,install,phpadmin",
	"help" => "aboutmodules,quick,about,welcome"
);




/**
 * Setting up backend styles and colors
 */
$TBE_STYLES = array(
	"colorschemes" => Array (
		"0" => "#E4E0DB,#CBC7C3,#EDE9E5",
	),
	"borderschemes" => Array (
		"0" => array("border:solid 1px black;",5)
	)
);


?>