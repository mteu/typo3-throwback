<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Dynamic configuation of the content-related tables, typ. tt_* series
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */




// ******************************************************************
// This is the standard TypoScript address table, tt_address
// ******************************************************************
$TCA["tt_address"] = Array (
	"ctrl" => $TCA["tt_address"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "name,address,city,zip,country,phone,fax,email,www,title,company,image"
	),
	"feInterface" => $TCA["tt_address"]["feInterface"],
	"columns" => Array (	
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check"
			)
		),
		"name" => Array (
			"label" => $LANG_GENERAL_LABELS["name"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"title" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "40"
			)
		),
		"address" => Array (
			"label" => $LANG_GENERAL_LABELS["address"],
			"config" => Array (
				"type" => "text",
				"cols" => "20",	
				"rows" => "3"
			)
		),
		"phone" => Array (
			"label" => $LANG_GENERAL_LABELS["phone"],
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "20",
				"max" => "30"
			)
		),
		"fax" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["fax"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "30"
			)
		),
		"mobile" => Array (
			"exclude" => 1,	
			"label" => "Mobile:|Mobil:|Mobil:|Mobil:|Cellulare:|Mobile:|Celular:|GSM:|Mobil:|Kom:|Mobitel:|Mobile:|Cep telefonu:",
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "20",
				"max" => "30"
			)
		),
		"www" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["www"],
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "20",
				"max" => "80"
			)
		),
		"email" => Array (
			"label" => $LANG_GENERAL_LABELS["email"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"company" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["company"],
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "20",
				"max" => "80"
			)
		),
		"city" => Array (
			"label" => $LANG_GENERAL_LABELS["city"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"zip" => Array (
			"label" => $LANG_GENERAL_LABELS["zip"],
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "10",
				"max" => "20"
			)
		),
		"country" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["country"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "30"
			)
		),
		"image" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["image"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],
				"max_size" => "1000",
				"uploadfolder" => "uploads/pics",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "6",
				"minitems" => "0"
			)
		),
		"description" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["description"],
			"config" => Array (
				"type" => "text",
				"rows" => 5,
				"cols" => 48
			)
		),
		"module_sys_dmail_category" => Array("config"=>array("type"=>"passthrough")),
		"module_sys_dmail_html" => Array("config"=>array("type"=>"passthrough"))
	),
	"types" => Array (	
		"1" => Array("showitem" => "hidden;;;;1-1-1, name;;2;;3-3-3, address, zip, city;;3, email;;5, phone;;4, image;;;;4-4-4, description")
	),
	"palettes" => Array (
		"2" => Array("showitem" => "title, company"),
		"3" => Array("showitem" => "country"),
		"4" => Array("showitem" => "mobile, fax"),
		"5" => Array("showitem" => "www")
	)
);




// ******************************************************************
// This is the standard TypoScript links table, tt_links
// ******************************************************************
$TCA["tt_links"] = Array (
	"ctrl" => $TCA["tt_links"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,url,hidden,note,note2"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"note" => Array (
			"label" => $LANG_GENERAL_LABELS["note"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "5"
			)
		),
		"note2" => Array (
			"exclude" => 1,	
			"label" => "Note (alt):|Note (alt):|Bemerkung (alt):|Merk deg (alt):|Note(alt.):|Note (alt):|Nota (alt):|Aantekening (alt):|Pozn�mka (alt):|Notatka (alt):|Opomba (alt):|Muistio (vaihtoeht.)|Not (alt):",
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "5"
			)
		),
		"url" => Array (
			"label" => "URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:|URL:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "256"
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check",
				"default" => "1"
			)
		)
	),
	"types" => Array (	
		"1" => Array("showitem" => "hidden;;;;1-1-1, title;;;;3-3-3, note, note2, url")
	)
);




// ******************************************************************
// This is the standard TypoScript guestbook
// ******************************************************************
$TCA["tt_guest"] = Array (
	"ctrl" => $TCA["tt_guest"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,cr_name,cr_email,note,www,hidden"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"note" => Array (
			"label" => $LANG_GENERAL_LABELS["note"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "5"
			)
		),
		"cr_name" => Array (
			"label" => "Sender name:|Afsender navn:|Absender Name:|Avsenderens navn:|Mittente:|Nom de l\'auteur:|Nombre del remitente:|Naam afzender:|Odes�latel:|Autor:|Ime po�iljatelja:|L�hett�j�n nimi:|G�nderenin ad�:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"cr_email" => Array (
			"label" => "Sender email:|Afsender email:|Absender email:|Avsenderens Epost:|E-mail mittente:|E-Mail de l\'auteur:|E-mail de remitente:|Emailadres afzender:|E-mail odes�latele:|Email autora:|Email po�iljatelja:|L�hett�j�n s�hk�postiosoite;|G�nderenin e-maili:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"www" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["www"],
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "20",
				"max" => "256"
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check",
				"default" => "1"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "hidden;;;;1-1-1, title;;;;3-3-3, note, cr_name, cr_email, www")
	)
);




// ******************************************************************
// This is the standard TypoScript Board table, tt_board
// ******************************************************************
$TCA["tt_board"] = Array (
	"ctrl" => $TCA["tt_board"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "subject,author,email,message"
	),
	"columns" => Array (	
		"subject" => Array (
			"label" => "Subject:|Emne:|Titel:|Emne:|Soggetto:|Sujet:|Asunto:|Onderwerp:|P�edm�t:|Temat:|Predmet:|Asia:|Konu:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"message" => Array (
			"label" => "Message:|Indhold:|Mitteilung:|Innhold:|Messaggio:|Message:|Mensaje:|Bericht:|Zpr�va:|Wiadomo��:|Sporo�ilo:|Viesti:|Mesaj:",
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "5"
			)
		),
		"author" => Array (
			"label" => $LANG_GENERAL_LABELS["author"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"email" => Array (
			"label" => $LANG_GENERAL_LABELS["email"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"hidden" => Array (
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check"
			)
		),
		"parent" => Array (
			"label" => "Parent:|Forrige:|Vorherige:|Forrige:|Parent:|Parent:|Padre:|Bron:|Odvozen:|Nadrz�dny:||Edellinen:|E� d�zey:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "tt_board",
				"size" => "3",
				"maxitems" => "1",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"notify_me" => Array (
			"label" => "Notify by email:|Orientering pr. email:|Benachrichtigung per email:|Orientering per Epost:|Notifica via email:|Avertir par e-mail:|Notificar por email:|Kennisgeving per email:|Ozn�mit e-mailem:|Powiadom emailem:|Opozori po emailu:|Muistuta s�hk�postitse:|E-maille haber ver:",
			"config" => Array (
				"type" => "check"
			)
		),
		"crdate" => Array (		// This field is by default filled with creation date. See tt_board "ctrl" section
			"exclude" => 1,	
			"label" => "Date/Time:|Dato/Tidspunkt:|Datum/Zeit:|Dato/tidspunkt:|Data/Ora:|Date/Heure:|Fecha/Hora:|Datum/Tijd:|Datum/�as:|Data/Czas:|Datum/Ura:|P�iv�ys/Kello|Tarih/Zaman:",
			"config" => Array (
				"type" => "input",
				"size" => "10",
				"max" => "20",
				"eval" => "datetime"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "hidden;;;;1-1-1, crdate, subject;;;;3-3-3, message, author, email, parent;;;;5-5-5, notify_me")
	)
);




// ******************************************************************
// This is the standard TypoScript calendar table, tt_calender
// ******************************************************************
$TCA["tt_calender"] = Array (
	"ctrl" => $TCA["tt_calender"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "type,date,title,note,category,responsible,workgroup,time,week,hidden,starttime,endtime"
	),
	"columns" => Array (	
		"starttime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["starttime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["endtime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check",
				"default" => "1"
			)
		),
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"note" => Array (
			"label" => $LANG_GENERAL_LABELS["note"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "5"
			)
		),
		"type" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("Calendar|Kalender|Kalender|Kalender|Calendario|Calendrier|Calendario|Kalender|Kalend��|Kalendarz|Koledar|Kalenteri|Takvim", 0),
					Array("Todo|Todo|Todo|Todo|Da fare|A Faire|Pendiente|TeDoen|�koly|Zadanie|Naloge|To-Do|Yap�lacak i�ler", 1)
				),
				"default" => 0
			)
		),
		"date" => Array (
			"exclude" => 1,	
			"label" => "Date:|Dato:|Datum:|Dato:|Data:|Date:|Fecha:|Datum:|Datum:|Data:|Datum:|P�iv�ys:|Tarih:",
			"config" => Array (
				"type" => "input",
				"size" => "10",
				"max" => "20",
				"eval" => "date",
				"default" => "0"
			)
		),
		"time" => Array (
			"exclude" => 1,	
			"label" => "Time:|Tidspunkt:|Zeit:|Tidspunkt:|Ora:|Temps:|Hora:|Tijd:|�as:|Czas:|Ura:|Kello:|Zaman:",
			"config" => Array (
				"type" => "input",
				"size" => "10",
				"max" => "20",
				"eval" => "time",
				"default" => "0"
			)
		),
		"week" => Array (
			"exclude" => 1,	
			"label" => "Week:|Uge:|Woche:|Uke:|Settimana:|Semaine:|Semana:|Week:|T�den:|Tydzie�:|Teden:|Viikko:|Hafta:",
			"config" => Array (
				"type" => "input",
				"size" => "6",
				"max" => "6",
				"eval" => "int",
				"range" => Array (
					"upper" => 52,
					"lower" => 1
				),
				"default" => "0"
			)
		),
		"datetext" => Array (
			"exclude" => 1,	
			"label" => "Datetext:|Datotekst:|Datumstext:|Datotekst:|Data:|Date:|Texto:|Datumtekst:|Datumtext:|Data tekstowo:|Datum z besedo:|P�iv�yksen teksti:|Tarih metni:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"complete" => Array (
			"exclude" => 1,	
			"label" => "Finished:|Afsluttet:|Ende:|Avslutt:|Finire:|Termin�:|Finalizar:|Geeindigd:|Dokon�eno:|Zako�czone:|Kon�ano:|Valmis:|Sonland�:",
			"config" => Array (
				"type" => "check",
				"default" => "0"
			)
		),
		"workgroup" => Array (
			"exclude" => 1,	
			"label" => "Workgroup:|Arbejdsgruppe:|Arbeitsgruppe:|Arbeidsgruppe:|Gruppo di lavoro:|Groupe de travail:|Grupo de trabajo:|Werkgroep:|Pracovn� skupina:|Zesp�:|Delovna skupina:|Ty�ryhm�:|�al��ma grubu:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"priority" => Array (
			"label" => "Priority:|Prioritet:|Priorit�t:|Prioritet:|Priorita\':|Priorit�:|Prioridad:|Prioriteit:|D�le�itost:|Priorytet:|Prioriteta:|Prioriteetti:|�ncelikli:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("High|H�j|Hoch|H�y|Alta|Haute|Alta|Hoog|Vysok�|Wysoki|Visoka|Korkea|Y�ksek", 1),
					Array("Medium|Mellem|Mittel|Medium|Media|Moyenne|Media|Medium|St�edn�|�redni|Srednja|Normaali|Orta", 3),
					Array("Low|Lav|Niedrig|Lav|Bassa|Basse|Baja|Laag|N�zk�|Niski|Nizka|Matala|D���k", 5)
				),
				"default" => 3
			)
		),
		"responsible" => Array (
			"exclude" => 1,	
			"label" => "Responsible:|Ansvarlige:|Verantwortlich:|Ansvarlige:|Responsabile:|Responsable:|Responsable:|Verantwoordelijk:|Odpov�dn�:|Odpowiedzialny:|Odgovorna oseba:|Vastuullinen|Sorumlu:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "tt_address",
				"size" => "3",
				"eval" => "trim",
				"maxitems" => "6",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"category" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["category"],
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", 0)
				),
				"foreign_table" => "tt_calender_cat"
			)
		),
		"link" => Array (
			"exclude" => 1,	
			"label" => "Link to page:|Link til side:|Link zur Seite:|Link til side:|Lonk alla pagina:|Liens vers la page:|Ligar a la p�gina:|Link naar pagina:|Odkaz na stranu:|Odno�nik do strony:|Povezava na stran:|Linkki sivulle|Sayfaya link:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "pages",
				"size" => "3",
				"maxitems" => "5",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "type;;;;1-1-1, hidden, date;;2;;3-3-3, title, note, category, --div--, datetext;;;;5-5-5, link"),
		"1" => Array("showitem" => "type;;;;1-1-1, hidden, date;;2;;3-3-3, title, note, category, --div--, complete;;;;5-5-5, priority, workgroup, responsible, link")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "starttime, endtime"),
		"2" => Array("showitem" => "week,time")	//, month
	)
);




// ******************************************************************
// This is the standard TypoScript calendar category table, tt_calender_cat
// ******************************************************************
$TCA["tt_calender_cat"] = Array (
	"ctrl" => $TCA["tt_calender_cat"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "title;;;;3-3-3")
	)
);




// ******************************************************************
// This is the standard TypoScript address table, tt_address
// ******************************************************************
$TCA["tt_products"] = Array (
	"ctrl" => $TCA["tt_products"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,itemnumber,price,price2,note,category,inStock,image,hidden,starttime,endtime"
	),
	"columns" => Array (	
		"starttime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["starttime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["endtime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check"
			)
		),
		"fe_group" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["fe_group"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (
					Array("", 0),
					Array($LANG_GENERAL_LABELS["hide_at_login"], -1),
					Array($LANG_GENERAL_LABELS["any_login"], -2),					
					Array($LANG_GENERAL_LABELS["usergroups"], "--div--")
				),
				"foreign_table" => "fe_groups"
			)
		),
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"note" => Array (
			"label" => $LANG_GENERAL_LABELS["note"],
			"config" => Array (
				"type" => "text",
				"cols" => "48",	
				"rows" => "5"
			)
		),
		"price" => Array (
			"label" => "Price:|Pris:|Preis:|Pris:|Prezzo:|Prix:|Precio:|Prijs:|Cena:|Cena:|Cena:|Hinta:|Fiyat:",
			"config" => Array (
				"type" => "input",
				"size" => "12",
				"eval" => "trim,double2",
				"max" => "20"
			)
		),
		"price2" => Array (
			"exclude" => 1,	
			"label" => "Price (2):|Pris (2):|Preis (2):|Pris (2):|Prezzo(2):|Prix (2):|Precio (2):|Prijs (2):|Cena (2):|Cena (2):|Cena (2):|Hinta (2):|Fiyat (2):",
			"config" => Array (
				"type" => "input",
				"size" => "12",
				"eval" => "trim,double2",
				"max" => "20"
			)
		),
		"www" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["www"],
			"config" => Array (
				"type" => "input",
				"eval" => "trim",
				"size" => "20",
				"max" => "80"
			)
		),
		"itemnumber" => Array (
			"label" => "Item number:|Emne nummer:|Artikel Nr.:|Emne nummer:|Numero item:|No article:|N� de parte:|Item nummer:|��slo polo�ky:|Ilo��:|�t. izdelka:|Tuote numero:|Nesne numaras�:",
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "40"
			)
		),
		"category" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["category"],
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", 0)
				),
				"foreign_table" => "tt_products_cat"
			)
		),
		"inStock" => Array (
			"exclude" => 1,	
			"label" => "In Stock (pcs):|P� lager (stk):|Am Lager (St.):|P� lager (stk.):|In giacenza (p.zi):|En stocks (pcs):|En existencia (pz.):|Per Stuk (stks):|Na sklad� (ks):|Sztuk:|Na zalogi (kom):|Varastossa (kpl)|Stoktaki (pr�):",
			"config" => Array (
				"type" => "input",
				"size" => "6",
				"max" => "6",
				"eval" => "int",
				"range" => Array (
					"lower" => 0
				)
			)
		),
		"image" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["image"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],
				"max_size" => "1000",
				"uploadfolder" => "uploads/pics",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "6",
				"minitems" => "0"
			)
		)
	),
	"types" => Array (	
		"1" => Array("showitem" => "hidden;;;;1-1-1, title;;3;;3-3-3, itemnumber, category, price;;2, note, image;;;;4-4-4")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "starttime, endtime, fe_group"),
		"2" => Array("showitem" => "price2, inStock"),
		"3" => Array("showitem" => "www")
	)
);





// ******************************************************************
// This is the standard TypoScript products category table, tt_products_cat
// ******************************************************************
$TCA["tt_products_cat"] = Array (
	"ctrl" => $TCA["tt_products_cat"]["ctrl"],
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "title;;;;3-3-3")
	)
);





// ******************************************************************
// This is the standard TypoScript news table, tt_news
// ******************************************************************
$TCA["tt_news"] = Array (
	"ctrl" => $TCA["tt_news"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,hidden,datetime,starttime,archivedate,category,author,author_email,short,image,imagecaption,links,related"
	),
	"columns" => Array (	
		"starttime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["starttime"],
			"config" => Array (
				"type" => "input",
				"size" => "10",
				"max" => "20",
				"eval" => "datetime",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["endtime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check",
				"default" => "1"
			)
		),
		"fe_group" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["fe_group"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (
					Array("", 0),
					Array($LANG_GENERAL_LABELS["hide_at_login"], -1),
					Array($LANG_GENERAL_LABELS["any_login"], -2),					
					Array($LANG_GENERAL_LABELS["usergroups"], "--div--")
				),
				"foreign_table" => "fe_groups"
			)
		),
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"ext_url" => Array (
			"label" => $LANG_GENERAL_LABELS["external"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256",
				"wizards" => Array(
					"_PADDING" => 2,
					"link" => Array(
						"type" => "popup",
						"title" => "Link",
						"icon" => "link_popup.gif",
						"script" => "browse_links.php?mode=wizard",
						"JSopenParams" => "height=300,width=500,status=0,menubar=0,scrollbars=1"
					)
				)
			)
		),
		"bodytext" => Array (
			"label" => $LANG_GENERAL_LABELS["text"],
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "5"
			)
		),
		"short" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["subheader"],	
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"type" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("News|Nyhed|News|Nyhet|News|Nouvelles|Noticias|Nieuws|Zpr�vy|Newsy|Novica|Uutiset|Haberler", 0),
					Array("Article|Artikel|Artikel|Artikkel|Articolo|Article|Art�culo|Artikel|�l�nek|Artyku�|�lanek|Artikkeli|Makale", 1),
					Array($LANG_GENERAL_LABELS["external"], 2)
				),
				"default" => 0
			)
		),
		"datetime" => Array (
			"exclude" => 1,	
			"label" => "Date/Time:|Dato/Tidspunkt:|Datum/Zeit:|Dato/tid:|Data/Ora:|Date/Heure:|Fecha/Hora:|Datum/Tijd:|Datum/�as:|Data/czas:|Datum/Ura:|P�iv�ys/Kello|Tarih/Zaman:",
			"config" => Array (
				"type" => "input",
				"size" => "10",
				"max" => "20",
				"eval" => "datetime",
				"default" => "0"
			)
		),
		"archivedate" => Array (
			"exclude" => 1,	
			"label" => "Archive date:|Arkiv dato:|Archivdatum:|Arkivdato:|Data archiviazione:|Date d\'archivage:|Fecha de archivo:|Archief datum:|Datum archivace:|Data archiwum:|Arhivski datum:|Arkisto p�iv�ys:|Ar�iv tarihi:",
			"config" => Array (
				"type" => "input",
				"size" => "10",
				"max" => "20",
				"eval" => "date",
				"default" => "0"
			)
		),
		"image" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["images"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],
				"max_size" => "1000",
				"uploadfolder" => "uploads/pics",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "10",
				"minitems" => "0"
			)
		),
		"imagecaption" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["caption"],
			"config" => Array (
				"type" => "text",
				"cols" => "30",
				"rows" => "3"
			)
		),
		"author" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["author"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"author_email" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["email"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"related" => Array (
			"exclude" => 1,	
			"label" => "Related news:|Relaterede nyheder:|In Verbindung stehende News:|Relaterte nyheter:|News in relazione:|Nouvelles en relations:|Noticias relacionadas:|Gerelateerd nieuws:|Podobn� zpr�vy:|Newsy zwi�zane:|Sorodne novice:|Asiaan liittyvi� uutisia:|�lgili haberler:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "tt_news",
					"MM" => "tt_news_related_mm",
				"size" => "5",
				"maxitems" => "200",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"keywords" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["keywords"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"links" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["links"],	
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"category" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["category"],
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", 0)
				),
				"foreign_table" => "tt_news_cat"
			)
		),
		"page" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["shortcut_page"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "pages",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "hidden;;;;1-1-1,type,title;;;;2-2-2,datetime,starttime;;1,archivedate,category,author,author_email,keywords,--div--,short;;;;3-3-3,bodytext,image;;;;4-4-4,imagecaption,--div--,links;;;;5-5-5,related"),
		"1" => Array("showitem" => "hidden;;;;1-1-1,type,page,title;;;;2-2-2,datetime,starttime;;1,archivedate,category,author,author_email,keywords,--div--,short;;;;3-3-3"),
		"2" => Array("showitem" => "hidden;;;;1-1-1,type,ext_url,title;;;;2-2-2,datetime,starttime;;1,archivedate,category,author,author_email,keywords,--div--,short;;;;3-3-3")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "endtime,fe_group")
	)
);






// ******************************************************************
// This is the standard TypoScript news category table, tt_news_cat
// ******************************************************************
$TCA["tt_news_cat"] = Array (
	"ctrl" => $TCA["tt_news_cat"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "title;;;;3-3-3")
	)
);




?>