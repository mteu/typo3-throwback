# MySQL dump 6.4
#
# Host: localhost    Database: t3_testsite
#--------------------------------------------------------
# Server version	3.22.27

#
# Table structure for table 'be_groups'
#
CREATE TABLE be_groups (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  title varchar(20) DEFAULT '' NOT NULL,
  non_exclude_fields blob NOT NULL,
  db_mountpoints varchar(40) DEFAULT '' NOT NULL,
  pagetypes_select tinyblob NOT NULL,
  tables_select tinyblob NOT NULL,
  tables_modify tinyblob NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  groupMods tinyblob NOT NULL,
  file_mountpoints varchar(40) DEFAULT '' NOT NULL,
  hidden tinyint(3) unsigned DEFAULT '0' NOT NULL,
  inc_access_lists tinyint(3) unsigned DEFAULT '0' NOT NULL,
  description text NOT NULL,
  lockToDomain varchar(50) DEFAULT '' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  TSconfig blob NOT NULL,
  subgroup tinyblob NOT NULL,
  hide_in_lists tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'be_sessions'
#
CREATE TABLE be_sessions (
  ses_id varchar(32) DEFAULT '' NOT NULL,
  ses_name varchar(32) DEFAULT '' NOT NULL,
  ses_userid int(11) unsigned DEFAULT '0' NOT NULL,
  ses_tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  ses_data blob NOT NULL,
  PRIMARY KEY (ses_id,ses_name)
);

#
# Table structure for table 'be_users'
#
CREATE TABLE be_users (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  username varchar(20) DEFAULT '' NOT NULL,
  password varchar(40) DEFAULT '' NOT NULL,
  admin tinyint(4) unsigned DEFAULT '0' NOT NULL,
  usergroup tinyblob NOT NULL,
  disable tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  lang char(2) DEFAULT '' NOT NULL,
  email varchar(80) DEFAULT '' NOT NULL,
  db_mountpoints varchar(40) DEFAULT '' NOT NULL,
  options tinyint(4) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  realName varchar(80) DEFAULT '' NOT NULL,
  userMods tinyblob NOT NULL,
  uc blob NOT NULL,
  file_mountpoints varchar(40) DEFAULT '' NOT NULL,
  fileoper_perms tinyint(4) DEFAULT '0' NOT NULL,
  lockToDomain varchar(50) DEFAULT '' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  TSconfig blob NOT NULL,
  lastlogin int(10) unsigned DEFAULT '0' NOT NULL,
  createdByAction int(11) DEFAULT '0' NOT NULL,
  usergroup_cached_list tinytext NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY username (username)
);

#
# Table structure for table 'cache_hash'
#
CREATE TABLE cache_hash (
  hash varchar(32) DEFAULT '' NOT NULL,
  content mediumblob NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  ident varchar(20) DEFAULT '' NOT NULL,
  PRIMARY KEY (hash)
);

#
# Table structure for table 'cache_pages'
#
CREATE TABLE cache_pages (
  id int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  hash varchar(32) DEFAULT '' NOT NULL,
  page_id int(11) unsigned DEFAULT '0' NOT NULL,
  HTML mediumblob NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  expires int(10) unsigned DEFAULT '0' NOT NULL,
  cache_data mediumblob NOT NULL,
  KEY page_id (page_id),
  KEY sel (hash,page_id),
  PRIMARY KEY (id)
);

#
# Table structure for table 'cache_pagesection'
#
CREATE TABLE cache_pagesection (
  page_id int(11) unsigned DEFAULT '0' NOT NULL,
  content blob NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (page_id)
);

#
# Table structure for table 'cache_search'
#
CREATE TABLE cache_search (
  id int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  hash varchar(32) DEFAULT '' NOT NULL,
  page_id int(11) unsigned DEFAULT '0' NOT NULL,
  HTMLfreeText mediumtext NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  tempFile_data blob NOT NULL,
  cHashParams tinyblob NOT NULL,
  page_type int(10) unsigned DEFAULT '0' NOT NULL,
  page_gr_list varchar(20) DEFAULT '' NOT NULL,
  KEY page_id (page_id),
  KEY sel (hash),
  PRIMARY KEY (id)
);

#
# Table structure for table 'cache_sys_dmail_stat'
#
CREATE TABLE cache_sys_dmail_stat (
  mid int(11) DEFAULT '0' NOT NULL,
  rid int(11) DEFAULT '0' NOT NULL,
  rtbl char(1) DEFAULT '' NOT NULL,
  pings tinyint(3) unsigned DEFAULT '0' NOT NULL,
  plain_links tinyint(3) unsigned DEFAULT '0' NOT NULL,
  html_links tinyint(3) unsigned DEFAULT '0' NOT NULL,
  links tinyint(3) unsigned DEFAULT '0' NOT NULL,
  recieved_html tinyint(3) unsigned DEFAULT '0' NOT NULL,
  recieved_plain tinyint(3) unsigned DEFAULT '0' NOT NULL,
  size int(11) DEFAULT '0' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  pings_first int(11) DEFAULT '0' NOT NULL,
  pings_last int(11) DEFAULT '0' NOT NULL,
  html_links_first int(11) DEFAULT '0' NOT NULL,
  html_links_last int(11) DEFAULT '0' NOT NULL,
  plain_links_first int(11) DEFAULT '0' NOT NULL,
  plain_links_last int(11) DEFAULT '0' NOT NULL,
  links_first int(11) DEFAULT '0' NOT NULL,
  links_last int(11) DEFAULT '0' NOT NULL,
  response_first int(11) DEFAULT '0' NOT NULL,
  response_last int(11) DEFAULT '0' NOT NULL,
  response tinyint(3) unsigned DEFAULT '0' NOT NULL,
  time_firstping int(11) DEFAULT '0' NOT NULL,
  time_lastping int(11) DEFAULT '0' NOT NULL,
  time_first_link int(11) DEFAULT '0' NOT NULL,
  time_last_link int(11) DEFAULT '0' NOT NULL,
  firstlink tinyint(4) DEFAULT '0' NOT NULL,
  firstlink_time int(11) DEFAULT '0' NOT NULL,
  secondlink tinyint(4) DEFAULT '0' NOT NULL,
  secondlink_time int(11) DEFAULT '0' NOT NULL,
  thirdlink tinyint(4) DEFAULT '0' NOT NULL,
  thirdlink_time int(11) DEFAULT '0' NOT NULL,
  KEY mid (mid)
);

#
# Table structure for table 'cache_typo3temp_log'
#
CREATE TABLE cache_typo3temp_log (
  md5hash varchar(32) DEFAULT '' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  filename tinytext NOT NULL,
  orig_filename tinytext NOT NULL,
  PRIMARY KEY (md5hash)
);

#
# Table structure for table 'fe_groups'
#
CREATE TABLE fe_groups (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  title varchar(20) DEFAULT '' NOT NULL,
  hidden tinyint(3) unsigned DEFAULT '0' NOT NULL,
  lockToDomain varchar(50) DEFAULT '' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  description text NOT NULL,
  TSconfig blob NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'fe_session_data'
#
CREATE TABLE fe_session_data (
  hash varchar(32) DEFAULT '' NOT NULL,
  content blob NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (hash)
);

#
# Table structure for table 'fe_sessions'
#
CREATE TABLE fe_sessions (
  ses_id varchar(32) DEFAULT '' NOT NULL,
  ses_name varchar(32) DEFAULT '' NOT NULL,
  ses_userid int(11) unsigned DEFAULT '0' NOT NULL,
  ses_tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  ses_data blob NOT NULL,
  PRIMARY KEY (ses_id,ses_name)
);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  username varchar(50) DEFAULT '' NOT NULL,
  password varchar(40) DEFAULT '' NOT NULL,
  usergroup tinyblob NOT NULL,
  disable tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  name varchar(80) DEFAULT '' NOT NULL,
  address tinytext NOT NULL,
  telephone varchar(20) DEFAULT '' NOT NULL,
  fax varchar(20) DEFAULT '' NOT NULL,
  email varchar(80) DEFAULT '' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  lockToDomain varchar(50) DEFAULT '' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  uc blob NOT NULL,
  title varchar(40) DEFAULT '' NOT NULL,
  zip varchar(10) DEFAULT '' NOT NULL,
  city varchar(50) DEFAULT '' NOT NULL,
  country varchar(40) DEFAULT '' NOT NULL,
  www varchar(80) DEFAULT '' NOT NULL,
  company varchar(80) DEFAULT '' NOT NULL,
  image tinyblob NOT NULL,
  TSconfig blob NOT NULL,
  module_sys_dmail_category int(10) unsigned DEFAULT '0' NOT NULL,
  module_sys_dmail_html tinyint(3) unsigned DEFAULT '0' NOT NULL,
  fe_cruser_id int(10) unsigned DEFAULT '0' NOT NULL,
  lastlogin int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY username (username),
  KEY pid (pid,username)
);

#
# Table structure for table 'index_fulltext'
#
CREATE TABLE index_fulltext (
  phash int(11) DEFAULT '0' NOT NULL,
  fulltextdata mediumtext NOT NULL,
  PRIMARY KEY (phash)
);

#
# Table structure for table 'index_grlist'
#
CREATE TABLE index_grlist (
  phash int(11) DEFAULT '0' NOT NULL,
  hash_gr_list int(11) DEFAULT '0' NOT NULL,
  gr_list tinytext NOT NULL,
  uniqid int(11) DEFAULT '0' NOT NULL auto_increment,
  PRIMARY KEY (uniqid),
  KEY joinkey (phash,hash_gr_list)
);

#
# Table structure for table 'index_phash'
#
CREATE TABLE index_phash (
  phash int(11) DEFAULT '0' NOT NULL,
  phash_grouping int(11) DEFAULT '0' NOT NULL,
  cHashParams tinyblob NOT NULL,
  data_filename tinytext NOT NULL,
  data_page_id int(11) unsigned DEFAULT '0' NOT NULL,
  data_page_type tinyint(3) unsigned DEFAULT '0' NOT NULL,
  item_type tinyint(4) DEFAULT '0' NOT NULL,
  item_title tinytext NOT NULL,
  item_description tinytext NOT NULL,
  item_mtime int(11) DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  item_size int(11) DEFAULT '0' NOT NULL,
  contentHash int(11) DEFAULT '0' NOT NULL,
  crdate int(11) DEFAULT '0' NOT NULL,
  parsetime int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (phash),
  UNIQUE phash (phash),
  UNIQUE grouping (phash,phash_grouping)
);

#
# Table structure for table 'index_rel'
#
CREATE TABLE index_rel (
  phash int(10) DEFAULT '0' NOT NULL,
  wid int(10) DEFAULT '0' NOT NULL,
  count tinyint(3) unsigned DEFAULT '0' NOT NULL,
  first tinyint(3) unsigned DEFAULT '0' NOT NULL,
  freq smallint(5) unsigned DEFAULT '0' NOT NULL,
  flags tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (phash,wid)
);

#
# Table structure for table 'index_section'
#
CREATE TABLE index_section (
  phash int(11) DEFAULT '0' NOT NULL,
  phash_t3 int(11) DEFAULT '0' NOT NULL,
  rl0 int(10) unsigned DEFAULT '0' NOT NULL,
  rl1 int(10) unsigned DEFAULT '0' NOT NULL,
  rl2 int(10) unsigned DEFAULT '0' NOT NULL,
  page_id int(11) DEFAULT '0' NOT NULL,
  uniqid int(11) DEFAULT '0' NOT NULL auto_increment,
  PRIMARY KEY (uniqid),
  KEY joinkey (phash,rl0)
);

#
# Table structure for table 'index_words'
#
CREATE TABLE index_words (
  wid int(11) DEFAULT '0' NOT NULL,
  baseword varchar(30) DEFAULT '' NOT NULL,
  metaphone int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (wid),
  KEY baseword (baseword),
  KEY metaphone (metaphone)
);

#
# Table structure for table 'pages'
#
CREATE TABLE pages (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(4) unsigned DEFAULT '0' NOT NULL,
  perms_userid int(11) unsigned DEFAULT '0' NOT NULL,
  perms_groupid int(11) unsigned DEFAULT '0' NOT NULL,
  perms_user tinyint(4) unsigned DEFAULT '0' NOT NULL,
  perms_group tinyint(4) unsigned DEFAULT '0' NOT NULL,
  perms_everybody tinyint(4) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  alias varchar(20) DEFAULT '' NOT NULL,
  doktype tinyint(3) unsigned DEFAULT '0' NOT NULL,
  url tinytext NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  urltype tinyint(4) unsigned DEFAULT '0' NOT NULL,
  shortcut int(10) unsigned DEFAULT '0' NOT NULL,
  no_cache int(10) unsigned DEFAULT '0' NOT NULL,
  fe_group int(11) DEFAULT '0' NOT NULL,
  subtitle tinytext NOT NULL,
  layout tinyint(3) unsigned DEFAULT '0' NOT NULL,
  target varchar(20) DEFAULT '' NOT NULL,
  media blob NOT NULL,
  lastUpdated int(10) unsigned DEFAULT '0' NOT NULL,
  keywords text NOT NULL,
  cache_timeout int(10) unsigned DEFAULT '0' NOT NULL,
  newUntil int(10) unsigned DEFAULT '0' NOT NULL,
  description text NOT NULL,
  no_search tinyint(3) unsigned DEFAULT '0' NOT NULL,
  SYS_LASTCHANGED int(10) unsigned DEFAULT '0' NOT NULL,
  abstract text NOT NULL,
  module varchar(10) DEFAULT '' NOT NULL,
  extendToSubpages tinyint(3) unsigned DEFAULT '0' NOT NULL,
  TSconfig blob NOT NULL,
  author tinytext NOT NULL,
  author_email varchar(80) DEFAULT '' NOT NULL,
  treeStop tinyint(4) DEFAULT '0' NOT NULL,
  nav_title tinytext NOT NULL,
  storage_pid int(11) DEFAULT '0' NOT NULL,
  is_siteroot tinyint(4) DEFAULT '0' NOT NULL,
  php_tree_stop tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY alias (alias)
);

#
# Table structure for table 'pages_language_overlay'
#
CREATE TABLE pages_language_overlay (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  sys_language_uid int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  subtitle tinytext NOT NULL,
  media tinyblob NOT NULL,
  keywords text NOT NULL,
  description text NOT NULL,
  abstract text NOT NULL,
  author tinytext NOT NULL,
  author_email varchar(80) DEFAULT '' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'static_dc_type'
#
CREATE TABLE static_dc_type (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  tmpl_a_subpart_marker tinytext NOT NULL,
  active int(11) DEFAULT '0' NOT NULL,
  tmpl_a_description text NOT NULL,
  tmpl_a_content text NOT NULL,
  tmpl_a_TSconfig text NOT NULL,
  tmpl_b_subpart_marker tinytext NOT NULL,
  tmpl_b_description text NOT NULL,
  tmpl_b_content text NOT NULL,
  tmpl_b_TSconfig text NOT NULL,
  tmpl_c_subpart_marker tinytext NOT NULL,
  tmpl_c_description text NOT NULL,
  tmpl_c_content text NOT NULL,
  tmpl_c_TSconfig text NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'static_template'
#
CREATE TABLE static_template (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  include_static tinyblob NOT NULL,
  constants blob NOT NULL,
  config blob NOT NULL,
  description text NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'static_tsconfig_help'
#
CREATE TABLE static_tsconfig_help (
  uid int(11) DEFAULT '0' NOT NULL auto_increment,
  guide varchar(40) DEFAULT '' NOT NULL,
  md5hash varchar(32) DEFAULT '' NOT NULL,
  description text NOT NULL,
  obj_string tinytext NOT NULL,
  data blob NOT NULL,
  title tinytext NOT NULL,
  PRIMARY KEY (uid),
  KEY guide (guide,md5hash)
);

#
# Table structure for table 'sys_action'
#
CREATE TABLE sys_action (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  type tinyint(3) unsigned DEFAULT '0' NOT NULL,
  t1_userprefix varchar(20) DEFAULT '' NOT NULL,
  t1_copy_of_user int(11) DEFAULT '0' NOT NULL,
  t1_allowed_groups tinyblob NOT NULL,
  t2_data blob NOT NULL,
  assign_to_groups int(11) DEFAULT '0' NOT NULL,
  hidden tinyint(4) DEFAULT '0' NOT NULL,
  t1_create_user_dir tinyint(4) DEFAULT '0' NOT NULL,
  t3_listPid int(11) DEFAULT '0' NOT NULL,
  t3_tables varchar(40) DEFAULT '' NOT NULL,
  t4_recordsToEdit text NOT NULL,
  PRIMARY KEY (uid),
  KEY cruser_id (cruser_id),
  KEY parent (pid)
);

#
# Table structure for table 'sys_action_asgr_mm'
#
CREATE TABLE sys_action_asgr_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'sys_be_shortcuts'
#
CREATE TABLE sys_be_shortcuts (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  userid int(11) unsigned DEFAULT '0' NOT NULL,
  module_name tinytext NOT NULL,
  url text NOT NULL,
  description tinytext NOT NULL,
  sorting int(11) DEFAULT '0' NOT NULL,
  sc_group tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY event (userid)
);

#
# Table structure for table 'sys_dc'
#
CREATE TABLE sys_dc (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  component_type int(11) DEFAULT '0' NOT NULL,
  tmpl_a_content text NOT NULL,
  hidden tinyint(4) DEFAULT '0' NOT NULL,
  tmpl_b_content text NOT NULL,
  tmpl_c_content text NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_dc_type'
#
CREATE TABLE sys_dc_type (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  tmpl_a_subpart_marker tinytext NOT NULL,
  active int(11) DEFAULT '0' NOT NULL,
  tmpl_a_description text NOT NULL,
  tmpl_a_content text NOT NULL,
  tmpl_a_TSconfig text NOT NULL,
  tmpl_b_subpart_marker tinytext NOT NULL,
  tmpl_b_description text NOT NULL,
  tmpl_b_content text NOT NULL,
  tmpl_b_TSconfig text NOT NULL,
  tmpl_c_subpart_marker tinytext NOT NULL,
  tmpl_c_description text NOT NULL,
  tmpl_c_content text NOT NULL,
  tmpl_c_TSconfig text NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_dmail'
#
CREATE TABLE sys_dmail (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  type tinyint(4) unsigned DEFAULT '0' NOT NULL,
  page int(11) unsigned DEFAULT '0' NOT NULL,
  attachment tinyblob NOT NULL,
  subject varchar(120) DEFAULT '' NOT NULL,
  from_email varchar(80) DEFAULT '' NOT NULL,
  from_name varchar(80) DEFAULT '' NOT NULL,
  replyto_email varchar(80) DEFAULT '' NOT NULL,
  replyto_name varchar(80) DEFAULT '' NOT NULL,
  organisation varchar(80) DEFAULT '' NOT NULL,
  priority tinyint(4) unsigned DEFAULT '0' NOT NULL,
  sendOptions tinyint(4) unsigned DEFAULT '0' NOT NULL,
  HTMLParams varchar(80) DEFAULT '' NOT NULL,
  plainParams varchar(80) DEFAULT '' NOT NULL,
  issent tinyint(4) unsigned DEFAULT '0' NOT NULL,
  renderedsize int(11) unsigned DEFAULT '0' NOT NULL,
  mailContent mediumblob NOT NULL,
  scheduled int(10) unsigned DEFAULT '0' NOT NULL,
  query_info blob NOT NULL,
  scheduled_begin int(10) unsigned DEFAULT '0' NOT NULL,
  scheduled_end int(10) unsigned DEFAULT '0' NOT NULL,
  return_path varchar(80) DEFAULT '' NOT NULL,
  PRIMARY KEY (uid)
);

#
# Table structure for table 'sys_dmail_group'
#
CREATE TABLE sys_dmail_group (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(4) unsigned DEFAULT '0' NOT NULL,
  type tinyint(4) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  query blob NOT NULL,
  static_list int(11) DEFAULT '0' NOT NULL,
  list mediumblob NOT NULL,
  csv tinyint(4) DEFAULT '0' NOT NULL,
  pages tinyblob NOT NULL,
  whichtables tinyint(4) DEFAULT '0' NOT NULL,
  recursive tinyint(4) DEFAULT '0' NOT NULL,
  mail_groups tinyblob NOT NULL,
  select_categories int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_dmail_group_mm'
#
CREATE TABLE sys_dmail_group_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
  tablenames varchar(30) DEFAULT '' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'sys_dmail_maillog'
#
CREATE TABLE sys_dmail_maillog (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  mid int(11) unsigned DEFAULT '0' NOT NULL,
  rid int(11) unsigned DEFAULT '0' NOT NULL,
  rtbl char(1) DEFAULT '' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  url tinyblob NOT NULL,
  size int(11) unsigned DEFAULT '0' NOT NULL,
  parsetime int(11) unsigned DEFAULT '0' NOT NULL,
  response_type tinyint(4) DEFAULT '0' NOT NULL,
  html_sent tinyint(4) DEFAULT '0' NOT NULL,
  url_id tinyint(4) DEFAULT '0' NOT NULL,
  return_content mediumblob NOT NULL,
  return_code smallint(6) DEFAULT '0' NOT NULL,
  KEY rid (rid,rtbl),
  PRIMARY KEY (uid),
  KEY mid (mid,response_type)
);

#
# Table structure for table 'sys_domain'
#
CREATE TABLE sys_domain (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  domainName varchar(80) DEFAULT '' NOT NULL,
  redirectTo varchar(120) DEFAULT '' NOT NULL,
  sorting int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_filemounts'
#
CREATE TABLE sys_filemounts (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  title varchar(30) DEFAULT '' NOT NULL,
  path varchar(120) DEFAULT '' NOT NULL,
  base tinyint(4) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(3) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_history'
#
CREATE TABLE sys_history (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  sys_log_uid int(11) DEFAULT '0' NOT NULL,
  history_data mediumblob NOT NULL,
  fieldlist blob NOT NULL,
  recuid int(11) DEFAULT '0' NOT NULL,
  tablename varchar(40) DEFAULT '' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  history_files mediumblob NOT NULL,
  snapshot tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY recordident (tablename,recuid),
  KEY sys_log_uid (sys_log_uid)
);

#
# Table structure for table 'sys_language'
#
CREATE TABLE sys_language (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  title varchar(80) DEFAULT '' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_lockedrecords'
#
CREATE TABLE sys_lockedrecords (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  userid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  record_table varchar(40) DEFAULT '' NOT NULL,
  record_uid int(11) DEFAULT '0' NOT NULL,
  record_pid int(11) DEFAULT '0' NOT NULL,
  username varchar(20) DEFAULT '' NOT NULL,
  PRIMARY KEY (uid),
  KEY event (userid,tstamp)
);

#
# Table structure for table 'sys_log'
#
CREATE TABLE sys_log (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  userid int(11) unsigned DEFAULT '0' NOT NULL,
  action tinyint(4) unsigned DEFAULT '0' NOT NULL,
  recuid int(11) unsigned DEFAULT '0' NOT NULL,
  tablename varchar(40) DEFAULT '' NOT NULL,
  recpid int(11) DEFAULT '0' NOT NULL,
  error tinyint(4) unsigned DEFAULT '0' NOT NULL,
  details tinytext NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  type tinyint(3) unsigned DEFAULT '0' NOT NULL,
  details_nr tinyint(3) unsigned DEFAULT '0' NOT NULL,
  IP varchar(15) DEFAULT '' NOT NULL,
  log_data tinyblob NOT NULL,
  event_pid int(11) DEFAULT '-1' NOT NULL,
  NEWid varchar(20) DEFAULT '' NOT NULL,
  PRIMARY KEY (uid),
  KEY event (userid,event_pid)
);

#
# Table structure for table 'sys_messages'
#
CREATE TABLE sys_messages (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  note text NOT NULL,
  parent int(11) unsigned DEFAULT '0' NOT NULL,
  orig_recipient tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY cruser_id (cruser_id),
  KEY parent (pid)
);

#
# Table structure for table 'sys_messages_users_mm'
#
CREATE TABLE sys_messages_users_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
  status tinyint(4) DEFAULT '0' NOT NULL,
  is_read tinyint(4) DEFAULT '0' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  mm_uid int(11) DEFAULT '0' NOT NULL auto_increment,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign),
  PRIMARY KEY (mm_uid)
);

#
# Table structure for table 'sys_note'
#
CREATE TABLE sys_note (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser int(11) unsigned DEFAULT '0' NOT NULL,
  author varchar(80) DEFAULT '' NOT NULL,
  email varchar(80) DEFAULT '' NOT NULL,
  subject tinytext NOT NULL,
  message text NOT NULL,
  personal tinyint(3) unsigned DEFAULT '0' NOT NULL,
  category tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_notepad'
#
CREATE TABLE sys_notepad (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  note text NOT NULL,
  crdate int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY cruser_id (cruser_id),
  KEY parent (pid)
);

#
# Table structure for table 'sys_products_orders'
#
CREATE TABLE sys_products_orders (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(4) unsigned DEFAULT '0' NOT NULL,
  note text NOT NULL,
  name varchar(80) DEFAULT '' NOT NULL,
  telephone varchar(20) DEFAULT '' NOT NULL,
  email varchar(80) DEFAULT '' NOT NULL,
  payment varchar(80) DEFAULT '' NOT NULL,
  shipping varchar(80) DEFAULT '' NOT NULL,
  amount varchar(20) DEFAULT '' NOT NULL,
  email_notify tinyint(4) unsigned DEFAULT '0' NOT NULL,
  tracking_code varchar(20) DEFAULT '' NOT NULL,
  status tinyint(4) unsigned DEFAULT '0' NOT NULL,
  status_log blob NOT NULL,
  orderData mediumblob NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY tracking (tracking_code),
  KEY status (status)
);

#
# Table structure for table 'sys_products_orders_mm_tt_products'
#
CREATE TABLE sys_products_orders_mm_tt_products (
  sys_products_orders_uid int(11) unsigned DEFAULT '0' NOT NULL,
  sys_products_orders_qty int(11) unsigned DEFAULT '0' NOT NULL,
  tt_products_uid int(11) unsigned DEFAULT '0' NOT NULL,
  KEY tt_products_uid (tt_products_uid),
  KEY sys_products_orders_uid (sys_products_orders_uid)
);

#
# Table structure for table 'sys_stat'
#
CREATE TABLE sys_stat (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  page_id int(11) unsigned DEFAULT '0' NOT NULL,
  jumpurl tinytext NOT NULL,
  feuser_id int(11) unsigned DEFAULT '0' NOT NULL,
  cookie varchar(10) DEFAULT '' NOT NULL,
  IP tinytext NOT NULL,
  host tinytext NOT NULL,
  referer tinytext NOT NULL,
  browser tinytext NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  page_type tinyint(4) unsigned DEFAULT '0' NOT NULL,
  parsetime mediumint(11) unsigned DEFAULT '0' NOT NULL,
  flags tinyint(3) unsigned DEFAULT '0' NOT NULL,
  rl0 int(11) DEFAULT '0' NOT NULL,
  rl1 int(11) DEFAULT '0' NOT NULL,
  sureCookie int(11) DEFAULT '0' NOT NULL,
  client_browser varchar(5) DEFAULT '' NOT NULL,
  client_version double(16,4) DEFAULT '0.0000' NOT NULL,
  client_os varchar(4) DEFAULT '' NOT NULL,
  PRIMARY KEY (uid),
  KEY page_id (page_id,tstamp,sureCookie),
  KEY rl0 (rl0,tstamp,sureCookie),
  KEY rl1 (rl1,tstamp,sureCookie)
);

#
# Table structure for table 'sys_staticfile_edit'
#
CREATE TABLE sys_staticfile_edit (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser int(11) unsigned DEFAULT '0' NOT NULL,
  edit_content mediumtext NOT NULL,
  edit_file tinyblob NOT NULL,
  edit_subpart_marker varchar(40) DEFAULT '' NOT NULL,
  always_reload tinyint(4) DEFAULT '0' NOT NULL,
  update_status tinytext NOT NULL,
  rte_enabled tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_tabledescr'
#
CREATE TABLE sys_tabledescr (
  tablename varchar(40) DEFAULT '' NOT NULL,
  fieldname varchar(40) DEFAULT '' NOT NULL,
  description tinytext NOT NULL,
  details text NOT NULL,
  syntax text NOT NULL,
  image tinytext NOT NULL,
  image_descr tinytext NOT NULL,
  seeAlso text NOT NULL,
  serial int(11) DEFAULT '0' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (tablename,fieldname)
);

#
# Table structure for table 'sys_tabledescr_dk'
#
CREATE TABLE sys_tabledescr_dk (
  tablename varchar(40) DEFAULT '' NOT NULL,
  fieldname varchar(40) DEFAULT '' NOT NULL,
  description_dk tinytext NOT NULL,
  details_dk text NOT NULL,
  syntax_dk text NOT NULL,
  image_descr_dk tinytext NOT NULL,
  serial_dk int(11) DEFAULT '0' NOT NULL,
  tstamp_dk int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (tablename,fieldname)
);

#
# Table structure for table 'sys_tabledescr_local'
#
CREATE TABLE sys_tabledescr_local (
  tablename varchar(40) DEFAULT '' NOT NULL,
  fieldname varchar(40) DEFAULT '' NOT NULL,
  description tinytext NOT NULL,
  details text NOT NULL,
  syntax text NOT NULL,
  image_descr tinytext NOT NULL,
  serial int(11) DEFAULT '0' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  image tinytext NOT NULL,
  seeAlso text NOT NULL,
  mode tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (tablename,fieldname)
);

#
# Table structure for table 'sys_template'
#
CREATE TABLE sys_template (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  sitetitle tinytext NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  root tinyint(4) unsigned DEFAULT '0' NOT NULL,
  clear tinyint(4) unsigned DEFAULT '0' NOT NULL,
  include_static tinyblob NOT NULL,
  constants blob NOT NULL,
  config blob NOT NULL,
  resources blob NOT NULL,
  nextLevel varchar(5) DEFAULT '' NOT NULL,
  description text NOT NULL,
  basedOn tinyblob NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  includeStaticAfterBasedOn tinyint(4) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_todos'
#
CREATE TABLE sys_todos (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(4) unsigned DEFAULT '0' NOT NULL,
  type varchar(11) DEFAULT '' NOT NULL,
  deadline int(11) unsigned DEFAULT '0' NOT NULL,
  finished tinyint(3) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY cruser_id (cruser_id)
);

#
# Table structure for table 'sys_todos_users_mm'
#
CREATE TABLE sys_todos_users_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) DEFAULT '0' NOT NULL,
  status tinyint(4) DEFAULT '0' NOT NULL,
  status_log mediumblob NOT NULL,
  is_read tinyint(4) DEFAULT '0' NOT NULL,
  tstamp int(11) DEFAULT '0' NOT NULL,
  mm_uid int(11) DEFAULT '0' NOT NULL auto_increment,
  deleted tinyint(4) DEFAULT '0' NOT NULL,
  rec_reference varchar(50) DEFAULT '' NOT NULL,
  finalized tinyint(4) DEFAULT '0' NOT NULL,
  finished_instance tinyint(4) DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign),
  PRIMARY KEY (mm_uid)
);

#
# Table structure for table 'sys_trackbeuser'
#
CREATE TABLE sys_trackbeuser (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  userid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  script text NOT NULL,
  PRIMARY KEY (uid),
  KEY event (userid,tstamp)
);

#
# Table structure for table 'sys_workflows'
#
CREATE TABLE sys_workflows (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  tablename varchar(60) DEFAULT '' NOT NULL,
  working_area int(11) DEFAULT '0' NOT NULL,
  allowed_groups int(11) DEFAULT '0' NOT NULL,
  review_users int(11) DEFAULT '0' NOT NULL,
  final_target int(11) DEFAULT '0' NOT NULL,
  final_unhide tinyint(4) DEFAULT '0' NOT NULL,
  final_perms_userid int(11) DEFAULT '0' NOT NULL,
  final_perms_groupid int(11) DEFAULT '0' NOT NULL,
  final_perms_user tinyint(11) DEFAULT '0' NOT NULL,
  final_perms_group tinyint(11) DEFAULT '0' NOT NULL,
  final_perms_everybody tinyint(11) DEFAULT '0' NOT NULL,
  hidden tinyint(4) DEFAULT '0' NOT NULL,
  final_set_perms tinyint(4) DEFAULT '0' NOT NULL,
  target_groups tinyblob NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'sys_workflows_algr_mm'
#
CREATE TABLE sys_workflows_algr_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'sys_workflows_rvuser_mm'
#
CREATE TABLE sys_workflows_rvuser_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tt_address'
#
CREATE TABLE tt_address (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  name tinytext NOT NULL,
  title varchar(40) DEFAULT '' NOT NULL,
  email varchar(80) DEFAULT '' NOT NULL,
  phone varchar(30) DEFAULT '' NOT NULL,
  mobile varchar(30) DEFAULT '' NOT NULL,
  www varchar(80) DEFAULT '' NOT NULL,
  address tinytext NOT NULL,
  company varchar(80) DEFAULT '' NOT NULL,
  city varchar(80) DEFAULT '' NOT NULL,
  zip varchar(20) DEFAULT '' NOT NULL,
  country varchar(30) DEFAULT '' NOT NULL,
  image tinyblob NOT NULL,
  fax varchar(30) DEFAULT '' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  description text NOT NULL,
  module_sys_dmail_category int(10) unsigned DEFAULT '0' NOT NULL,
  module_sys_dmail_html tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY pid (pid,email)
);

#
# Table structure for table 'tt_board'
#
CREATE TABLE tt_board (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  author varchar(80) DEFAULT '' NOT NULL,
  email varchar(80) DEFAULT '' NOT NULL,
  subject tinytext NOT NULL,
  message text NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  parent int(10) unsigned DEFAULT '0' NOT NULL,
  notify_me tinyint(3) unsigned DEFAULT '0' NOT NULL,
  doublePostCheck int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid),
  KEY parent_select (pid,parent)
);

#
# Table structure for table 'tt_calender'
#
CREATE TABLE tt_calender (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  type tinyint(4) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  note text NOT NULL,
  date int(11) unsigned DEFAULT '0' NOT NULL,
  datetext varchar(80) DEFAULT '' NOT NULL,
  week tinyint(4) unsigned DEFAULT '0' NOT NULL,
  complete tinyint(4) unsigned DEFAULT '0' NOT NULL,
  workgroup varchar(80) DEFAULT '' NOT NULL,
  responsible varchar(20) DEFAULT '' NOT NULL,
  category int(11) unsigned DEFAULT '0' NOT NULL,
  priority tinyint(4) unsigned DEFAULT '0' NOT NULL,
  link tinytext NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  time int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_calender_cat'
#
CREATE TABLE tt_calender_cat (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_content'
#
CREATE TABLE tt_content (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  CType varchar(10) DEFAULT '' NOT NULL,
  header tinytext NOT NULL,
  header_position varchar(6) DEFAULT '' NOT NULL,
  bodytext mediumtext NOT NULL,
  image blob NOT NULL,
  imagewidth mediumint(11) unsigned DEFAULT '0' NOT NULL,
  imageorient tinyint(4) unsigned DEFAULT '0' NOT NULL,
  imagecaption text NOT NULL,
  imagecols tinyint(4) unsigned DEFAULT '0' NOT NULL,
  imageborder tinyint(4) unsigned DEFAULT '0' NOT NULL,
  media tinyblob NOT NULL,
  layout tinyint(3) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(4) unsigned DEFAULT '0' NOT NULL,
  cols tinyint(3) unsigned DEFAULT '0' NOT NULL,
  records blob NOT NULL,
  pages tinyblob NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  colPos tinyint(3) unsigned DEFAULT '0' NOT NULL,
  subheader tinytext NOT NULL,
  spaceBefore tinyint(4) unsigned DEFAULT '0' NOT NULL,
  spaceAfter tinyint(4) unsigned DEFAULT '0' NOT NULL,
  fe_group int(11) DEFAULT '0' NOT NULL,
  header_link tinytext NOT NULL,
  imagecaption_position varchar(6) DEFAULT '' NOT NULL,
  image_link tinytext NOT NULL,
  image_zoom tinyint(3) unsigned DEFAULT '0' NOT NULL,
  image_noRows tinyint(3) unsigned DEFAULT '0' NOT NULL,
  image_effects tinyint(3) unsigned DEFAULT '0' NOT NULL,
  image_compression tinyint(3) unsigned DEFAULT '0' NOT NULL,
  header_layout tinyint(3) unsigned DEFAULT '0' NOT NULL,
  text_align varchar(6) DEFAULT '' NOT NULL,
  text_face tinyint(3) unsigned DEFAULT '0' NOT NULL,
  text_size tinyint(3) unsigned DEFAULT '0' NOT NULL,
  text_color tinyint(3) unsigned DEFAULT '0' NOT NULL,
  text_properties tinyint(3) unsigned DEFAULT '0' NOT NULL,
  menu_type tinyint(3) unsigned DEFAULT '0' NOT NULL,
  list_type tinyint(3) unsigned DEFAULT '0' NOT NULL,
  table_border tinyint(3) unsigned DEFAULT '0' NOT NULL,
  table_cellspacing tinyint(3) unsigned DEFAULT '0' NOT NULL,
  table_cellpadding tinyint(3) unsigned DEFAULT '0' NOT NULL,
  table_bgColor tinyint(3) unsigned DEFAULT '0' NOT NULL,
  select_key varchar(80) DEFAULT '' NOT NULL,
  sectionIndex tinyint(3) unsigned DEFAULT '0' NOT NULL,
  linkToTop tinyint(3) unsigned DEFAULT '0' NOT NULL,
  filelink_size tinyint(3) unsigned DEFAULT '0' NOT NULL,
  section_frame tinyint(3) unsigned DEFAULT '0' NOT NULL,
  date int(10) unsigned DEFAULT '0' NOT NULL,
  splash_layout tinyint(3) unsigned DEFAULT '0' NOT NULL,
  multimedia tinyblob NOT NULL,
  image_frames tinyint(3) unsigned DEFAULT '0' NOT NULL,
  recursive tinyint(3) unsigned DEFAULT '0' NOT NULL,
  imageheight mediumint(8) unsigned DEFAULT '0' NOT NULL,
  module_sys_dmail_category int(10) unsigned DEFAULT '0' NOT NULL,
  rte_enabled tinyint(4) DEFAULT '0' NOT NULL,
  sys_language_uid int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_guest'
#
CREATE TABLE tt_guest (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  note text NOT NULL,
  cr_name varchar(80) DEFAULT '' NOT NULL,
  cr_email varchar(80) DEFAULT '' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  www tinytext NOT NULL,
  doublePostCheck int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_links'
#
CREATE TABLE tt_links (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  note text NOT NULL,
  url tinytext NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  note2 text NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_news'
#
CREATE TABLE tt_news (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  fe_group int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  datetime int(11) unsigned DEFAULT '0' NOT NULL,
  image tinyblob NOT NULL,
  imagecaption text NOT NULL,
  related int(11) DEFAULT '0' NOT NULL,
  short text NOT NULL,
  bodytext mediumtext NOT NULL,
  author tinytext NOT NULL,
  author_email tinytext NOT NULL,
  category int(11) DEFAULT '0' NOT NULL,
  links text NOT NULL,
  type tinyint(4) DEFAULT '0' NOT NULL,
  page int(11) DEFAULT '0' NOT NULL,
  keywords text NOT NULL,
  archivedate int(11) DEFAULT '0' NOT NULL,
  ext_url tinytext NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_news_cat'
#
CREATE TABLE tt_news_cat (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_news_related_mm'
#
CREATE TABLE tt_news_related_mm (
  uid_local int(11) unsigned DEFAULT '0' NOT NULL,
  uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
  sorting int(11) unsigned DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tt_poll'
#
CREATE TABLE tt_poll (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  question text NOT NULL,
  answers text NOT NULL,
  votes int(11) DEFAULT '0' NOT NULL,
  recordlink tinyblob NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_products'
#
CREATE TABLE tt_products (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  starttime int(11) unsigned DEFAULT '0' NOT NULL,
  endtime int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  note text NOT NULL,
  price varchar(20) DEFAULT '' NOT NULL,
  price2 varchar(20) DEFAULT '' NOT NULL,
  image tinyblob NOT NULL,
  www varchar(80) DEFAULT '' NOT NULL,
  itemnumber varchar(40) DEFAULT '' NOT NULL,
  category int(10) unsigned DEFAULT '0' NOT NULL,
  inStock int(11) DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  ordered int(10) unsigned DEFAULT '0' NOT NULL,
  fe_group int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_products_cat'
#
CREATE TABLE tt_products_cat (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

#
# Table structure for table 'tt_rating'
#
CREATE TABLE tt_rating (
  uid int(11) unsigned DEFAULT '0' NOT NULL auto_increment,
  pid int(11) unsigned DEFAULT '0' NOT NULL,
  tstamp int(11) unsigned DEFAULT '0' NOT NULL,
  crdate int(11) unsigned DEFAULT '0' NOT NULL,
  title tinytext NOT NULL,
  description text NOT NULL,
  rating varchar(20) DEFAULT '0' NOT NULL,
  votes int(11) DEFAULT '0' NOT NULL,
  ratingstat tinytext NOT NULL,
  hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
  deleted tinyint(3) unsigned DEFAULT '0' NOT NULL,
  recordlink tinyblob NOT NULL,
  PRIMARY KEY (uid),
  KEY parent (pid)
);

