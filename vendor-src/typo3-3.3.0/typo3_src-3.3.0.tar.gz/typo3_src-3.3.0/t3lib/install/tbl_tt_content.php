<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Dynamic configuation of the tt_content table
 * This gets it's own file because it's so huge and central to typical Typo3 use.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



$TCA["tt_content"] = Array (
	"ctrl" => $TCA["tt_content"]["ctrl"],
	"interface" => Array (
		"always_description" => 0,
		"showRecordFieldList" => "CType,header,header_link,bodytext,image,imagewidth,imageorient,media,records,colPos,starttime,endtime,fe_group"
	),
	"columns" => Array (	
		"CType" => Array (
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("Header|Overskrift|�berschrift|Overskrift|Intestazione|Titre|T�tulo|Kop|Nadpis|Nag��wek|Naslov|Otsikko|Ana ba�l�k", "header"),
					Array("Text|Tekst|Text|Tekst|Testo|Texte|Texto|Tekst|Text|Tekst|Besedilo|Teksti|Metin", "text"),
					Array("Text w/image|Tekst m/Billede|Text m/Bild|Tekst m/bilde|Testo con immagini|Texte w/image|Texto con im�gen|Tekst met afbeelding|Text s obr�zkem|Tekst z obrazkiem|Besedilo s slikami|Kuvallinen teksti|Metin w/resim", "textpic"),
#					Array("Rich Text|Formatteret tekst|Rich Text|Rik tekst (tekstbehandler)|Rich Text|Rich Text|Texto con formato (RTF)|Tekst Plus|Rich Text|Tekst formatowany|Oblikovano besedilo|Rich Text / Laajennettu teksti tyyppi", "rte"),
					Array("Image|Billede|Bild|Bilde|Immagine|Image|Im�gen|Afbeelding|Obr�zek|Obrazek|Slike|Kuva|Resim", "image"),
					Array("Bullet list|Punktliste|Punktliste|Punktliste|Elenco puntato|Liste � puces|Lista con vi�etas|Bullet list|V��et|Lista|Seznam po to�kah|Merkki lista|Madde i�areti listesi", "bullets"),
					Array("Table|Tabel|Tabelle|Tabell|Tavola|Table|Tabla|Table|Tabulka|Tabelka|Tabela|Taulukko|Tablo", "table"),
					Array("Filelinks|Fillinks|Dateilinks|Filhyperkoblinger|Link su file|Lien vers fichier|Ligas a archivos|Filelinks|Odkaz na soubory|Lista plik�w|Povezave do datotek|Tiedosto linkki|Dosya linkleri", "uploads"),
					Array("Multimedia|Multimedie|Multimedia|Multimedia|Multimedia|Multimedia|Multimedia|MultiMedia|Multimedia|Multimedia|Multimedia|Multimedia|Multimedya", "multimedia"),
					Array("Form|Formular|Formular|Formular|Form|Formulaire|Formulario|Form|Formul��|Formularz|Obrazec|Lomake|Form", "mailform"),
					Array("Search|S�gefelt|Suchen|S�k|Ricerca|Recherche|B�squeda|Zoeken|Hled�n�|Wyszukiwanie|Iskanje|Haku|Ara�t�r", "search"),
	//				Array("__Advanced:__|__Avancerede:__|__Erweitert:__|__Avansert:__|__Avanzate:__|__Avanc�e__:|__Avanzados:__|__Geavenceerd:__|__Pokro�il�:__|__Zaawansowane:__|__Napredno:__|__Laajennettu:__", "--div--"),
					Array("Login|Login|Login|Login|Login|Identifiant|Login|Login|Login|Logowanie|Login|Sis��nkirjoitus:|Giri�", "login"),
					Array("Textbox|Tekstboks|Textbox|Tekstboks|Box di testo|Textbox|Caja de texto|Tekstbox|Textbox|Okienko tekstowe|Polje z besedilom|Tekstiboxi|Metin kutusu", "splash"),
					Array("Menu/Sitemap|Menu/Oversigt|Men�/Sitemap|Meny/Oversikt|Menu / mappa sito|Menu / Plan site|Men� / mapa del sitio|Menu/Sitemap|Menu/Mapa situ|Menu/Mapa witryny||Valikko/Sivustorakenne|Men�/Site haritas�", "menu"),
					Array("Insert records|Inds�t elementer|Datensatz einf�gen|Sett inn emner|Inserimento record|Ins�rer enregistrements|Inserta registros|Record invoegen|Vlo�it z�znamy|Lista rekord�w|Vstavi zapise|Lis�� tietueita|Kay�tlar� ekle", "shortcut"),
					Array("Insert plugin|Inds�t plugin|Plugin einf�gen|Sett inn plugin||||Plugin invoegen||Wtyczka||Lis�� plugin|Mod�l ekle", "list"),
					Array("Script|Script|Skript|Skript|Script|Scripts|Script|Script|Skript|Skrypt|Skript|Skripti|Script", "script"),
					Array("Divider|Adskiller|Trenner|Adskiller||||Scheidslijn||Rozdzielacz||Jako|Ay�r�c�", "div"),
					Array("HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML||HTML|HTML", "html")
				),
				"default" => "text"
			)
		),
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check"
			)
		),
		"starttime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["starttime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["endtime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"fe_group" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["fe_group"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (
					Array("", 0),
					Array($LANG_GENERAL_LABELS["hide_at_login"], -1),
					Array($LANG_GENERAL_LABELS["any_login"], -2),
					Array($LANG_GENERAL_LABELS["usergroups"], "--div--")
				),
				"foreign_table" => "fe_groups"
			)
		),
		"sys_language_uid" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["language"],
			"config" => Array (
				"type" => "select",
				"foreign_table" => "sys_language",
				"foreign_table_where" => "ORDER BY sys_language.title",
				"items" => Array(
					Array($LANG_GENERAL_LABELS["default_value"],0)
				)
			)
		),
		"layout" => Array (
			"exclude" => 1,
			"label" => $LANG_GENERAL_LABELS["layout"],
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["normal"], "0"),
					Array("Layout 1|Layout 1|Layout 1|Layout 1|Layout 1|Pr�paration-type 1|Layout 1|Layout 1|Layout 1|Uk�ad 1|Oblika 1|Malli 1|Sayfa d�zeni 1", "1"),
					Array("Layout 2|Layout 2|Layout 2|Layout 2|Layout 2|Pr�paration-type 2|Layout 2|Layout 2|Layout 2|Uk�ad 2|Oblika 2|Malli 2|Sayfa d�zeni 2", "2"),
					Array("Layout 3|Layout 3|Layout 3|Layout 3|Layout 3|Pr�paration-type 3|Layout 3|Layout 3|Layout 3|Uk�ad 3|Oblika 3|Malli 3|Sayfa d�zeni 3", "3")
				),
				"default" => "0"
			)
		),
		"colPos" => Array (
			"exclude" => 1,	
			"label" => "Columns:|Spalte:|Spalten:|Spalte:|Colonne:|Colonnes:|Columnas:|Kolommen:|Sloupce:|Kolumny:|Stolpci:|Sarakkeet:|S�tunlar:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("Left|Venstre|Links|Venstre|Sinistra|Gauche|Izquierda|Links|Vlevo|Lewa|Levo|Vasen|Sol", "1"),
					Array($LANG_GENERAL_LABELS["normal"], "0"),
					Array("Right|H�jre|Rechts|H�yre|Destra|Droite|Derecha|Rechts|Vpravo|Prawa|Desno|Oikea|Sa�", "2"),
					Array("Border|Margin|Rand|Marg|Bordo|Bordure|Borde|Kader|Okraj|Boczna|Rob|Raja|Kenar", "3")
				),
				"default" => "0"
			)
		),
		"date" => Array (
			"exclude" => 1,	
			"label" => "Date:|Dato:|Datum:|Dato:|Data:|Date:|Fecha:|Datum:|Datum:|Data:|Datum:|P�iv�ys:|Tarih:",
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"header" => Array (
			"label" => "Header:|Overskrift:|�berschrift:|Overskrift:|Intestazione:|Titre:|T�tulo:|Kop:|Nadpis:|Nag��wek:|Naslov:|Otsikko:|Ana ba�l�k:",
			"config" => Array (
				"type" => "input",
				"max" => "256"
			)
		),
		"header_position" => Array (
			"label" => "Align:|Justering:|Justierung:|Justering:|Allineamento:|Alignement:|Alineaci�n:|Uitlijnen:|Zarovn�n�:|Justowanie:|Poravnava:|Tasaus:|Hizalamak:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", ""),
					Array("Center|Center|Mitte|Senter|Centrato|Centr�|Centro|Centreer|Na st�ed|Wy�rodkuj|Sredina|Keskit�|Merkez", "center"),
					Array("Right|H�jre|Rechts|H�yre|Destra|Aligner � droite|Derecha|Rechts|Vpravo|Do prawej|Desno|Oikealle|Sa�", "right"),
					Array("Left|Venstre|Links|Venstre|Sinistra|Aligner � gauche|Izquierda|Links|Vlevo|Do lewej|Levo|Vasemmalle|Sol", "left")
				),
				"default" => ""
			)
		),
		"header_link" => Array (
			"label" => "Link:|Link:|Verweis:|Link:|Link:|Lien:|Liga:|Link:|Odkaz:|Odno�nik:|Povezava:|Tyyppi:|Link:",
			"config" => Array (
				"type" => "input",		
				"size" => "15",
				"max" => "256",
				"checkbox" => "",
				"eval" => "trim",
				"wizards" => Array(
					"_PADDING" => 2,
					"link" => Array(
						"type" => "popup",
						"title" => "Link",
						"icon" => "link_popup.gif",
						"script" => "browse_links.php?mode=wizard",
						"JSopenParams" => "height=300,width=500,status=0,menubar=0,scrollbars=1"
					)
				)
			)
		),
		"header_layout" => Array (
			"exclude" => 1,
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["normal"], "0"),
					Array("Layout 1|Layout 1|Layout 1|Layout 1|Layout 1|Pr�paration-type 1|Layout 1|Layout 1|Layout 1|Uk�ad 1|Oblika 1|Malli 1|Sayfa d�zeni 1", "1"),
					Array("Layout 2|Layout 2|Layout 2|Layout 2|Layout 2|Pr�paration-type 2|Layout 2|Layout 2|Layout 2|Uk�ad 2|Oblika 2|Malli 2|Sayfa d�zeni 2", "2"),
					Array("Layout 3|Layout 3|Layout 3|Layout 3|Layout 3|Pr�paration-type 3|Layout 3|Layout 3|Layout 3|Uk�ad 3|Oblika 3|Malli 3|Sayfa d�zeni 3", "3"),
					Array("Layout 4|Layout 4|Layout 4|Layout 4|Layout 4|Pr�paration-type 4|Layout 4|Layout 4|Layout 4|Uk�ad 4|Oblika 4|Malli 4|Sayfa d�zeni 4", "4"),
					Array("Layout 5|Layout 5|Layout 5|Layout 5|Layout 5|Pr�paration-type 4|Layout 5|Layout 5|Layout 5|Uk�ad 5|Oblika 5|Malli 5|Sayfa d�zeni 5", "5"),
					Array("Hidden|Skjult|Versteckt|Skjult|Nascosto|Cach�|Oculto|Verberg|Skryt�|Ukryty|Skrito|Piiloitettu|Gizli", "100")
				),
				"default" => "0"
			)
		),
		"subheader" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["subheader"],	
			"config" => Array (
				"type" => "input",
				"size" => "30",
				"max" => "256"
			)
		),
		"bodytext" => Array (
			"label" => $LANG_GENERAL_LABELS["text"],
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "5",
				"wizards" => Array(
					"_PADDING" => 4,
					"RTE" => Array(
						"notNewRecords" => 1,
						"RTEonly" => 1,
						"type" => "script",
						"title" => "Full screen Rich Text Editing|Formatteret redigering i hele vinduet",
						"icon" => "wizard_rte2.gif",
						"script" => "wizard_rte.php",
					),
					"table" => Array(
						"notNewRecords" => 1,
						"enableByTypeConfig" => 1,
						"type" => "script",
						"title" => "Table wizard",
						"icon" => "wizard_table.gif",
						"script" => "wizard_table.php",
					),
					"forms" => Array(
						"notNewRecords" => 1,
						"enableByTypeConfig" => 1,
						"type" => "script",
						"title" => "Forms wizard",
						"icon" => "wizard_forms.gif",
						"script" => "wizard_forms.php?special=formtype_mail",
					)
				)
			)
		),
		"text_align" => Array (
			"exclude" => 1,	
			"label" => "Align:|Justering:|Justierung:|Justering:|Allineamento:|Alignement:|Alineaci�n:|Uitlijnen:|Zarovn�n�:|Justowanie:|Poravnava:|Tasaus:|Hizalamak:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", ""),
					Array("Center|Center|Mitte|Senter|Centrato|Centr�|Centro|Centreer|Na st�ed|Wy�rodkuj|Sredina|Keskit�|Merkez", "center"),
					Array("Right|H�jre|Rechts|H�yre|Destra|Aligner � droite|Derecha|Rechts|Vpravo|Do prawej|Desno|Oikealle|Sa�", "right"),
					Array("Left|Venstre|Links|Venstre|Sinistra|Aligner � gauche|Izquierda|Links|Vlevo|Do lewej|Levo|Vasemmalle|Sol", "left")
				),
				"default" => ""
			)
		),
		"text_face" => Array (
			"exclude" => 1,
			"label" => "Fontface:|Skrifttype:|Schrift:|Skrifttype:|Tipo font:|Police de caract�res:|Tipo de letra:|Fontfamilie:|Font:|Czcionka:|Font:|Kirjaisinlaji|Font birimi:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["default_value"], "0"),
					Array("Times", "1"),
					Array("Verdana", "2"),
					Array("Arial", "3")
				),
				"default" => "0"
			)
		),
		"text_size" => Array (
			"exclude" => 1,
			"label" => "Size:|St�rrelse:|Gr�sse:|St�rrelse:|Dimensione:|Taille:|Tama�o:|Grootte:|Velikost:|Wielko��:|Velikost:|Koko:|Ebat:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["default_value"], "0"),
					Array("1: Small|1: Lille|1: Klein|Liten|1: Piccolo|1: Petite|1: Peque�a|1: Klein|1: Mal�|1: Ma�a|1: Majhen|1:Pieni|1: K���k", "1"),
					Array("2: Medium|2: Medium|2: Mittel|Medium|2: Medio|2: Moyenne|2: Mediana|2: Medium|2: St�edn�|2: �rednia|2: Srednji|2.Keskikoko|2: Orta", "2"),
					Array("3: Large|3: Stor|3: Gross|Stor|3: Grande|3: Grande|3: Grande|3: Groot|3: Velk�|3: Du�a|3: Velik|3:Suuri|3: B�y�k", "3"),
					Array("4: Header 1|4: Overskrift 1|4: �berschrift 1|Overskrift 1|4: Intestazione 1|4: Titre 1|4: T�tulo 1|4: Kop 1|4: Nadpis 1|4: Nag��wek 1|4: Naslov 1|4:Otsikko 1|4: Ana ba�l�k 1", "4"),
					Array("5: Header 2|5: Overskrift 2|5: �berschrift 2|Overskrift 2|5: Intestazione 2|5: Titre 2|5: T�tulo 2|5: Kop 2|5: Nadpis 2|5: Nag��wek 2|5: Naslov 2|5:Otsikko 2|5: Ana ba�l�k 2", "5"),
					Array("Default +1|Standard +1|Standard +1|Standard +1|Predefinito +1|Valeur par d�faut +1|Default +1|Standaard +1|Standard +1|Domy�lnie +1|Privzeto +1|Oletus +1|Standart +1", "10"),
					Array("Default -1|Standard -1|Standard -1|Standard -1|Predefinito -1|Valeur par d�faut -1|Default -1|Standaard -1|Standard -1|Domy�lnie -1|Privzeto -1|Oletus +2|Standart -1", "11")
				),
				"default" => "0"
			)
		),
		"text_color" => Array (
			"exclude" => 1,
			"label" => "Color:|Farve:|Farbe:|Farge:|Colore:|Couleur:|Color:|Kleur:|Barva:|Kolor:|Barva:|V�ri:|Renk:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["default_value"], "0"),
					Array("Color 1|Farve 1|Farbe 1|Farge 1|Colore 1|Couleur 1|Color 1|Kleur 1|Barva 1|Kolor 1|Barva 1|V�ri 1|Renk 1", "1"),
					Array("Color 2|Farve 2|Farbe 2|Farge 2|Colore 2|Couleur 2|Color 2|Kleur 2|Barva 2|Kolor 2|Barva 2|V�ri 2|Renk 2", "2"),
					Array("None|Ingen|Keine|Ingen|Nessuno|Aucune|Ninguno|Geen|��dn�|Brak|Brez|Ei mit��n|Hi�biri", "200"),
					Array("-----","--div--"),
					Array("Black|Sort|Schwarz|Svart|Nero|Noir|Negro|Zwart|�ern�|Czarny|�rna|Musta|Siyah", "240"),
					Array("White|Hvid|Weiss|Hvit|Bianco|Blanc|Blanco|Wit|B�l�|Bia�y|Bela|Valkoinen|Beyaz", "241"),
					Array("Dark gray|M�rkegr�|Dunkelgrau|M�rkegr�|Grigio scuro|Gris sombre|Gris obscuro|Donker grijs|Tmav� �ed�|Ciemny szary|Temno siva|Tumman harmaa|Koyu gri", "242"),
					Array("Gray|Gr�|Grau|Gr�|Grigio|Gris clair|Gris claro|Grijs|Sv�tle �ed�|Szary|Siva|Harmaa|Gri", "243"),
					Array("Silver|Lysegr�|Silber|Lysegr�|Argento|Argent|Plata|Zilver|St��brn�|Jasny szary|Srebrna|Hopea|G�m��", "244"),
					Array("Red|R�d|Rot|R�d|Rosso|Rouge|Rojo|Rood|�erven�|Czerwony|Rde�a|Punainen|K�rm�z�", "245"),
					Array("Navy blue|M�rk bl�|Marine Blau|Marinebl�|Blu|Bleu marine|Azul marino|Navy|Modr�|Granatowy|Morsko modra|Laivaston sininen|Lacivert", "246"),
					Array("Yellow|Gul|Gelb|Gul|Giallo|Jaune|Amarillo|Geel|�lut�|��ty|Rumena|Keltainen|Sar�", "247"),
					Array("Green|Gr�n|Gr�n|Gr�nn|Verde|Vert|Verde|Groen|Zelen�|Zielony|Zelena|Vihre�|Ye�il", "248"),
					Array("Olive|Oliven|Olivgr�n|Oliven|Verde oliva|Kaki|Verde olivo|Olijf|Olivov�|Oliwkowy|Olivna|Oliivi|Zeytuni ye�il", "249"),
					Array("Maroon|R�dbrun|Rotbraun|R�dbrun|Marrone|Maron|Marr�n|Kastanje|Ka�tanov�|Wi�niowy|Kostanjevo rjava|Maroon|Maron", "250")
				),
				"default" => "0"
			)
		),
		"text_properties" => Array (
			"exclude" => 1,
			"label" => "Properties:|Egenskaber:|Eigenschaften:|Egenskaper:|Proprieta:|Propri�t�s:|Propiedades:|Eigenschappen:|Vlastnosti:|W�a�ciwo�ci:|Lastnosti:|Ominaisuudet:|�zellikler:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Bold|Fed|Fett|Fet|Grassetto|Gras|Negrillas|Vet|Tu�n�|Pogrubiony|Krepko|Lihavoi|�st� �izili", ""),
					Array("Italics|Kursiv|Kursiv|Kusiv|Italico|Italiques|It�licas|Schuinschrift|Kurz�va|Kursywa|Le�e�e|Kallista|�talik", ""),
					Array("Underline|Understreg|Unterstrichen|Understrek|Sottolineato|Soulign�|Subrayado|Onderstreept|Podtr�en�|Podkre�lony|Pod�rtano|Alleviivaa|Alt��izili", ""),
					Array("Uppercase|Store bogstaver|Grossbuchstaben|Store bokstaver|Maiuscolo|Majuscules|May�sculas|Hoofdletters|Verz�lky|Kapitaliki|Velike �rke|Isoin kirjaimin|�st� �izili", "")
				),
				"cols" => 4
			)
		),
		"image" => Array (
			"label" => $LANG_GENERAL_LABELS["images"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],
				"max_size" => "1000",
				"uploadfolder" => "uploads/pics",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "200",
				"minitems" => "0"
			)
		),
		"imagewidth" => Array (
			"exclude" => 1,	
			"label" => "Width (pixels):|Bredde (pixels):|Breite (pixels):|Bredde (pixels):|Larghezza (pixel):|Largeur (pixels):|Ancho (pixeles):|Breedte (pixels):|���ka (pixely):|Szeroko�� (piksele):|�irina (to�k):|Leveys, (pikselej�:|Geni�lik (piksel):",
			"config" => Array (
				"type" => "input",	
				"size" => "4",
				"max" => "4",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "999",
					"lower" => "25"
				),
				"default" => 0
			)
		),
		"imageheight" => Array (
			"exclude" => 1,	
			"label" => "Height (pixels):|H�jde (pixels):|H�he (Pixel):|H�yde (pixels):|Altezza(pixel):|Hauteur (pixels):|Alto (pixeles):|Hoogte (pixels):|V��ka (pixely):|Wysoko�� (piksele):|Vi�ina (to�k):|Korkeys, (pikselej�);|Y�kseklik (piksel):",
			"config" => Array (
				"type" => "input",	
				"size" => "4",
				"max" => "4",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "700",
					"lower" => "25"
				),
				"default" => 0
			)
		),
		"imageorient" => Array (
			"label" => "Position:|Position:|Position:|Posisjon:|Posizione:|Position:|Posici�n:|Positie:|Pozice:|Pozycja:|Postavitev:|Paikka:|Pozisyon:",
			"config" => Array (
				"type" => "select",	
				"items" => Array (
					Array("Above, center|Over, center|Oben mittig|Over, senter|Centrato|Au dessus, centr�|Arriba al centro|Boven, midden|Nad, na st�ed|Powy�ej, �rodek|Zgoraj, sredina|Yl�s, keskelle|Yukar�, merkez", 0, "selicons/above_center.gif"),
					Array("Above, right|Over, h�jre|Oben rechts|Over, h�yre|Destra|Au dessus, � droite|Arriba a la derecha|Boven, rechts|Nad, vpravo|Powy�ej, z prawej|Zgoraj, desno|Yl�s, oikealle|Yukar�, sa�", 1, "selicons/above_right.gif"),
					Array("Above, left|Over, venstre|Oben links|Over, venstre|Sinistra|Au dessus, � gauche|Arriba a la izquierda|Boven, links|Nad, vlevo|Powyzej, z lewej|Zgoraj, levo|Yl�s, vasemmalle|Yukar�, sol", 2, "selicons/above_left.gif"),
					Array("Below, center|Under, center|Unten mittig|Under, senter|Centrato alla fine|En dessous, centr�|Abajo al centro|Onder, midden|Pod, na st�ed|Poni�ej, �rodek|Spodaj, sredina|Alas, keskelle|A�a��, merkez", 8, "selicons/below_center.gif"),
					Array("Below, right|Under, h�jre|Unten rechts|Under, h�yre|Destra alla fine|En dessous, � droite|Abajo a la derecha|Onder, rechts|Pod, vpravo|Poni�ej, z prawej|Spodaj, desno|Alas, oikealle|A�a��, sa�", 9, "selicons/below_right.gif"),
					Array("Below, left|Under, venstre|Unten links|Under, venstre|Sinistra alla fine|En dessous, � gauche|Abajo a la izquierda|Onder, links|Pod, vlevo|Poni�ej, z lewej|Spodaj, levo|Alas, vasemmalle|A�a��, sol", 10, "selicons/below_left.gif"),
					Array("In text, right|I tekst, h�jre|Im Text rechts|I tekst, h�yre|Destra nel testo|Dans le texte, � droite|En el texto por la derecha|In tekst, rechts|V textu, vpravo|W tek�cie, z prawej|V besedilu, desno|Tekstiss�, oikealle|Metinde, sa�", 17, "selicons/intext_right.gif"),
					Array("In text, left|I tekst, venstre|Im Text links|I tekst, venstre|Sinistra nel testo|Dans le texte, � gauche|En el texto por la izquierda|In tekst, links|V textu, vlevo|W tek�cie, z lewej|V besedilu, levo|Tekstiss�, vasemmalle|Metinde, sol", 18, "selicons/intext_left.gif"),
					Array("__No wrap:__|__Ingen ombryd:__|__Kein Umbruch:__|__Ingen pakning:__|__Senza contorno:__|__Pas de retour � la ligne__|__Sin alrededor:__|__No wrap:__|__Nazalamovat:__|__Bez zachodzenia:__|__Brez preloma:__|__Ei rivityst�:__|__S�zc��� kayd�rma:__", "--div--"),
					Array("In text, right|I tekst, h�jre|Im Text rechts|I tekst, h�yre|Destra nel testo|Dans le texte, � droite|En el texto por la derecha|In tekst, rechts|V textu, vpravo|W tek�cie, z prawej|V besedilu, desno|Tekstiss�, oikealle|Metinde, sa�", 25, "selicons/intext_right_nowrap.gif"),
					Array("In text, left|I tekst, venstre|Im Text links|I tekst, venstre|Sinistra nel testo|Dans le texte, � gauche|En el texto por la izquierda|In tekst, links|V textu, vlevo|W tek�cie, z lewej|V besedilu, levo|Tekstiss�, vasemmalle|Metinde, sol", 26, "selicons/intext_left_nowrap.gif")
				),
				"selicon_cols" => 6,
				"default" => "8"
			)
		),
		"imageborder" => Array (
			"exclude" => 1,	
			"label" => "Border:|Kant:|Rahmen:|Ramme:|Bordo:|Bordure:|Borde:|Rand:|Okraj:|Ramka:|Rob:|Rajat:|Kenar:",
			"config" => Array (
				"type" => "check"
			)
		),
		"image_noRows" => Array (
			"exclude" => 1,	
			"label" => "No rows:|Ingen r�kker:|Keine Reihen:|Ingen rekker:|No colonne:|Pas de ligne:|Sin columnas:|Geen rijen:|��dn� ��dky:|Nie w wierszach:|Ni� vrstic:|Ei rivej�:|Sat�rlar yok:",
			"config" => Array (
				"type" => "check"
			)
		),
		"image_link" => Array (
			"exclude" => 1,	
			"label" => "Link:|Link:|Verweis:|Link:|Link:|Lien:|Liga:|Link:|Odkaz:|Odno�nik:|Povezava:|Linkki:|Link:",
			"config" => Array (
				"type" => "input",		
				"size" => "15",
				"max" => "256",
				"checkbox" => "",
				"eval" => "trim",
				"wizards" => Array(
					"_PADDING" => 2,
					"link" => Array(
						"type" => "popup",
						"title" => "Link",
						"icon" => "link_popup.gif",
						"script" => "browse_links.php?mode=wizard",
						"JSopenParams" => "height=300,width=500,status=0,menubar=0,scrollbars=1"
					)
				)
			)
		),
		"image_zoom" => Array (
			"exclude" => 1,	
			"label" => "Click-enlarge:|Klik-forst�r:|Klick-vergr�ssern:|Klikk-forst�r:|Clicca per allargare:|Cliquer pour agrandir:|Click para agrandar:|Klik-vergroten:|Kliknut�m zv�t�it:|Kliknij-powi�ksz:|Klikni-pove�aj:|N�ps�yt�-suurenna|B�y�tme-tu�u:",
			"config" => Array (
				"type" => "check"
			)
		),
		"image_effects" => Array (
			"exclude" => 1,	
			"label" => "Effects:|Effekter:|Effekte:|Effekter:|Effetti:|Effets:|Efectos:|Effecten:|Efekty:|Efekt:|U�inki:|Efektit:|Efektler:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("(None)|(Ingen)|(kein)|(Ingen)|(Nessuno)|(Aucun)|(Ninguno)|(Geen)|(��dn�)|(Brak)|(Ni�)|(ei mit��n)|(Hi�biri)", 0),
					Array("Rotate 90 CW|Rot�r 90 med uret|Drehen 90 mit Uhr|Roter 90 med klokken|Rotazione 90 gr.|Rotation 90� (sens des aiguilles d'une montre)|Rotar 90� seg�n las manecillas del reloj|Draaien 90 CW|Rotace 90� vpravo|Obr�t 90 w prawo|Obrni za 90 CW|K��nn� 90 kellon suuntaan|90� derece d�nd�r", 1),
					Array("Rotate -90 CCW|Rot�r 90 mod uret|Drehen 90 gegen Uhr|Roter 90 mot klokken|Rotazione -90 gr.|Rotation -90� (sens contraire)|Rotar 90� al lado contrario|Draaien -90 CCW|Rotace 90� vlevo|Obr�t 90 w lewo|Obrni za -90 CCW|K��nn� 90 vasten kellon suuntaa|-90� derece d�nd�r", 2),
					Array("Rotate 180|Rot�r 180|Drehen 180|Roter 180|Rotazione 180 gr.|Rotation 180 � (tour complet)|Rotar 180� (vuelta completa)|Draaien 180|Rotace 180�|Obr�t 180|Obrni 180|K��nn� 180|180� d�nd�r", 3),
					Array("Grayscale|Gr�tone|Graubild|Gr�tone|Scala di grigi|Nuances de gris|Escala de grices|Grijstinten|Stupn� �ed�|Skala szaro�ci|Le sivine|Harmaas�vy|Griscala", 10),
					Array("Sharpen|Skarpere|Sch�rfen|Skarpere|Schiarito|Plus pr�cis|Afocar|Verscherpen|Zaost�it|Wyostrz|Izostri|Ter�v�it�|Keskinle�tir", 11),
					Array("Normalize|Normalis�r|Normalisieren|Normaliser|Normalizzato|Normaliser|Normalizar|Normalizeren|Normalizace|Normalizuj|Normalno|Normaaliksi|Normalle�tirmek", 20),
					Array("Contrast|Kontrast|Kontrast|Kontrast|Contrastato|Plus de contraste|Mas contraste|Contrast|Kontrast|Zwi�ksz kontrast|Kontrast|Kontrasti|De�i�kenlik", 23),
					Array("Brighter|Lysere|Heller|Lysere|Luminoso|Plus clair|Mas brillo|Lichter|Sv�tlej��|Poja�nij|Svetleje|Kirkasta|Parlakla�k", 25),
					Array("Darker|M�rkere|Dunkler|M�rkere|Scuro|Plus sombre|Menos brillo|Donkerder|Tmav��|Pociemnij|Temneje|Tummenna|Karartma", 26)
				)
			)
		),
		"image_frames" => Array (
			"exclude" => 1,	
			"label" => "Frames:|Rammer:|Rahmen:|Ramme:|Frames:|Frames:|Marcos:|Frames:|R�me�ky:|Otoczka:|Okvirji:|Osasivut:|�er�eve:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("(None)|(Ingen)|(kein)|(Ingen)|(Nessuno)|(Aucun)|(Ninguno)|(Geen)|(��dn�)|(Brak)|(Ni�)|(eiosasivuja)|(Hi�biri)", 0),
					Array("Frame 1|Ramme 1|Rahmen 1|Ramme 1|Frame 1|Frame 1|Marco 1|Frame 1|R�me�ek 1|Otoczka 1|Okvir 1|Raami 1|�er�eve 1", 1),
					Array("Frame 2|Ramme 2|Rahmen 2|Ramme 2|Frame 2|Frame 2|Marco 2|Frame 2|R�me�ek 2|Otoczka 2|Okvir 2|Raami 2|�er�eve 2", 2),
					Array("Frame 3|Ramme 3|Rahmen 3|Ramme 3|Frame 3|Frame 3|Marco 3|Frame 3|R�me�ek 3|Otoczka 3|Okvir 3|Raami 3|�er�eve 3", 3),
					Array("Frame 4|Ramme 4|Rahmen 4|Ramme 4|Frame 4|Frame 4|Marco 4|Frame 4|R�me�ek 4|Otoczka 4|Okvir 4|Raami 4|�er�eve 4", 4),
					Array("Frame 5|Ramme 5|Rahmen 5|Ramme 5|Frame 5|Frame 5|Marco 5|Frame 5|R�me�ek 5|Otoczka 5|Okvir 5|Raami 5|�er�eve 5", 5),
					Array("Frame 6|Ramme 6|Rahmen 6|Ramme 6|Frame 6|Frame 6|Marco 6|Frame 6|R�me�ek 6|Otoczka 6|Okvir 6|Raami 6|�er�eve 6", 6),
					Array("Frame 7|Ramme 7|Rahmen 7|Ramme 7|Frame 7|Frame 7|Marco 7|Frame 7|R�me�ek 7|Otoczka 7|Okvir 7|Raami 7|�er�eve 7", 7),
					Array("Frame 8|Ramme 8|Rahmen 8|Ramme 8|Frame 8|Frame 8|Marco 8|Frame 8|R�me�ek 8|Otoczka 8|Okvir 8|Raami 8|�er�eve 8", 8)
				)
			)
		),
		"image_compression" => Array (
			"exclude" => 1,	
	//		"label" => "Compr:|Kompr:|Kompr:|Kompr:|Compress.|Compr:|Compr:|Compr.:|Komprese:",
			"label" => "Quality:|Kvalitet:|Qualit�t:|Kvalitet:|Qualita:|Qualit�:|Compr:|Kwaliteit:||Kompresja:|Kvaliteta:|Laatu:|Kalite:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array($LANG_GENERAL_LABELS["default_value"], 0),
					Array("Dont change!|Ingen �ndringer!|Nicht �ndern|Ikke endre!|Non cambiare !|Ne pas modifier!|�No cambiar!|Niet wijzigen!|Nem�nit!|Bez zmian!|Ne spreminjaj!|�l� muuta!|De�i�tirme!", 1),
					Array("GIF/256", 10),
					Array("GIF/128", 11),
					Array("GIF/64", 12),
					Array("GIF/32", 13),
					Array("GIF/16", 14),
					Array("GIF/8", 15),
					Array("PNG", 39),
					Array("PNG/256", 30),
					Array("PNG/128", 31),
					Array("PNG/64", 32),
					Array("PNG/32", 33),
					Array("PNG/16", 34),
					Array("PNG/8", 35),
					Array("JPG/Very High|JPG/Meget h�j|JPG/sehr hoch|JPG/Meget h�y|JPG/Altissima risoluzione|JPG/Tr�s haute r�solution|JPG/Muy alta|JPG/Heel hoog|JPG/Velmi vysok�|JPG/B. du�a|JPG/Zelo dober|JPG/Korkein|JPG/�ok Y�ksek", 21),
					Array("JPG/High|JPG/H�j|JPG/hoch|JPG/H�y|JPG/Alta risoluzione|JPG/Haute r�solution|JPG/Alta|JPG/ Hoog|JPG/Vysok�|JPG/Du�a|JPG/Dober|JPG/Korkea|JPG/Y�ksek", 22),
					Array("JPG/Medium|JPG/Medium|JPG/mittel|JPG/Medium|JPG/Media risoluzione|JPG/R�solution moyenne|JPG/Media|JPG/Medium|JPG/St�edn�|JPG/�rednia|JPG/Srednji|JPG/Keskim��r�inen|JPG/Orta", 24),
					Array("JPG/Low|JPG/Lav|JPG/niedrig|JPG/Lav|JPG/Bassa risoluzione|JPG/Basse r�solution|JPG/Baja|JPG/Laag|JPG/N�zk�|JPG/Niska|JPG/Slab|JPG/Matala|JPG/D���k", 26),
					Array("JPG/Very Low|JPG/Meget lav|JPG/sehr niedrig|JPG/Meget lav|JPG/Bassissima risoluzione|JPG/Tr�s basse r�solution|JPG/Muy baja|JPG/Heel Laag|JPG/Velmi n�zk�|JPG/B. niska|JPG/Zelo slab|JPG/Matalin|JPG/�ok D���k", 28)
				)
			)
		),
		"imagecols" => Array (
			"label" => "Columns:|Kolonner:|Spalten:|Kolonner:|Colonne:|Colonnes:|Kolommen:|Kolommen:|Sloupce:|Kolumny:|Stolpci:|Sarakkeet:|S�tunlar:",
			"config" => Array (
				"type" => "select",	
				"items" => Array (	
					Array("1", 0),
					Array("2", 2),
					Array("3", 3),
					Array("4", 4),
					Array("5", 5),
					Array("6", 6),
					Array("7", 7),
					Array("8", 8)
				),
				"default" => 0
			)
		),
		"imagecaption" => Array (
			"label" => $LANG_GENERAL_LABELS["caption"],
			"config" => Array (
				"type" => "text",
				"cols" => "30",
				"rows" => "3"
			)
		),
		"imagecaption_position" => Array (
			"exclude" => 1,	
			"label" => "Align:|Justering:|Justierung:|Justering:|Alliniamento:|Alignement:|Alineaci�n:|Uitlijnen:|Zarovn�n�:|Justowanie:|Poravnava:|Tasaa:|Hizala:",
			"config" => Array (
				"type" => "select",
				"items" => Array (
					Array("", ""),
					Array("Center|Center|Mitte|Senter|Centrato|Centr�|Centro|Center|Na st�ed|Wy�rodkuj|Sredina|Keskit�|Merkez", "center"),
					Array("Right|H�jre|Rechts|H�yre|Destra|Aligner � droite|Derecha|Rechts|Vpravo|Do prawej|Desno|Oikealle|Sa�", "right"),
					Array("Left|Venstre|Links|Venstre|Sinistra|Aligner � gauche|Izquierda|Links|Vlevo|Do lewej|Levo|Vasemmalle|Sol", "left")
				),
				"default" => ""
			)
		),
		"cols" => Array (
			"label" => "Table Columns:|Tabelkolonner:|Tabellenspalten:|Tabellkolloner:|Colonne Tabella:|Colonnes du frame:|Columnas:|Tabel kolommen:|Sloupce tabulky:|Kolumny:|Stolpci tabele:|Taulun sarakkeet_|Tablo s�tunlar�:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("Auto|Auto|Auto|Auto|Auto|Auto|Auto|Auto|Auto|Auto|Avto|Auto|Otomatik", "0"),
					Array("1", "1"),
					Array("2", "2"),
					Array("3", "3"),
					Array("4", "4"),
					Array("5", "5"),
					Array("6", "6"),
					Array("7", "7"),
					Array("8", "8"),
					Array("9", "9")
				),
				"default" => "0"
			)
		),
		"pages" => Array (
			"label" => $LANG_GENERAL_LABELS["startingpoint"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "pages",
				"size" => "3",
				"maxitems" => "22",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"recursive" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["recursive"],
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("", "0"),	
					Array("1 level|1 niveau|1 Ebene|1 niv�|1 livello|1 niveau|1 nivel|1 niveau|1 �rove�|1 poziom|1 nivo|Taso 1|Seviye 1", "1"),
					Array("2 levels|2 niveauer|2 Ebenen|2 niv�er|2 livello|2 niveaux|2 niveles|2 niveau's|2 �rovn�|2 poziomy|2 nivoja|Taso 2|Seviye 2", "2"),
					Array("3 levels|3 niveauer|3 Ebenen|3 niv�er|3 livello|3 niveaux|3 niveles|3 niveau's|3 �rovn�|3 poziomy|3 nivoji|Taso 3|Seviye 3", "3"),
					Array("4 levels|4 niveauer|4 Ebenen|4 niv�er|4 livello|4 niveaux|4 niveles|4 niveau's|4 �rovn�|4 poziomy|4 nivoji|Taso 4|Seviye 4", "4"),
					Array("Infinite|Uendeligt|Unendlich|Uendelig|Infinito|Illimit�|Infinito|Onbeperkt|V�echny|bez ograniczenia|Neskon�no|M��rittelem�t�n|S�n�rs�z", "250")
				),
				"default" => "0"
			)
		),
		"menu_type" => Array (
			"label" => "Menu type:|Menutype:|Men� Typ:|Menytype:||||Menu type:||Typ menu:||Valikon tyyppi:|T�r:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("Menu of these pages|Menu af disse sider|Men� dieser Seiten|Meny av disse sider|Menu di questa pagina|Menu des pages|Men� de esas p�ginas|Menu van deze pagina's|Menu z t�chto stran|Menu ze stron|Meni teh strani|N�iden sivujen valikko|Bu sayfalar�n men�s�", "0"),
					Array("Menu of subpages to these pages|Menu af undersider til disse sider|Men� der Unterseiten|Meny av undersider og disse sider|Menu di sottopagina di questa pagina|Menu des sous-pages|Men� de subp�ginas de esas p�ginas|Menu bestaande uit subpagina's van deze pagina's|Menu z podstran t�chto stran|Menu z podstron|Meni podstrani teh strani|N�iden sivujen alasivujen valikko|Bu sayfalarda alt sayfalar�n men�s�", "1"),
					Array("Menu of subpages to these pages (with abstract)|Menu af undersider til disse sider (med sammendrag)|Men� der Unterseiten (mit Inhaltsangabe)|Meny av undersider til disse sidene (med sammendrag)|Menu delle sottopagine di queste pagine|Menu des sous-pages (avec abstract)|Men� de subp�ginas de esas p�ginas (con descripci�n)|Menu bestaande uit subpagina's van deze pagina's (met korte omschrijving)|Menu z podstran t�chto stran (s popisem)|Menu z podstron (z opisem)|Meni podstrani teh strani (z izvle�ki)|N�iden sivujen alasivujen valikko (lyhennelmineen)|Bu sayfalarda alt sayfalar�n men�s� (�zetleriyle)", "4"),
					Array("Menu of subpages to these pages + sections|Menu af undersider til disse sider + sektioner|Men� der Unterseiten (mit Seiteninhalt)|Meny av undersider til disse sidene + seksjoner|Menu delle sottopagine di queste pagine ( con abstract)|Menu des sous-pages (avec section)|Men� de subp�ginas de esas p�ginas (con secciones)|Menu bestaande uit subpagina's van deze pagina + secties|Menu z podstran t�chto stran + odd�ly|Menu z podstron + sekcje|Meni podstrani teh strani + sekcije|N�iden sivujen valikko + kappaleet|Bu sayfalarda alt sayfalar�n men�s� +b�l�mleri", "7"),
					Array("Sitemap|Side-oversigt (Sitemap)|Sitemap|Oversikt|Mappa del sito|Plan du site|Mapa del sitio|Sitemap|Mapa situ|Mapa witryny||Sivuston rakenne|Site haritas�", "2"),
					Array("Section index (pagecontent w/Index checked)|Sektions-oversigt (sideindhold m/Index afkrydset)|Abschnitts�bersicht (mit Seiteninhalt)|Seksjonsoversikt (sideinnhold m/Index avkrysset)|Indice sezione ( contenuto pagina con Indice marcato)|Index des sections (Contenu w/Index coch�)|Mapa de secciones con el �ndice marcado|Pagina-inhoud met Index aangevinkt|P�ehled odd�l�|Lista sekcji|Kazalo sekcij (vsebina strani z ozna�enim kazalom)|Kappaleiden indeksi (sivusis�lt� indeksi tarkistettuna)|B�l�m indeksi (sayfa i�eri�i w/�ndeks kontrol edildi)", "3"),
					Array("Recently updated pages|Senest opdaterede sider|Ge�nderte Seiten|Sist oppdaterte sider|Pagine aggiornate di recente|Pages r�cemment mise � jour|P�ginas actualizadas recientemente|Onlangs aangepaste pagina's|Ned�vno aktualizovan� strany|Ostatnio aktualizowane|Nedavno osve�ene strani|Hiljan p�ivitetyt sivut|Son zamanlarda g�ncellenen sayfalar", "5"),
					Array("Related pages (based on keywords)|Relaterede sider (baseret p� n�gleord)|Verwandte Seiten (nach Stichworten)|Relaterte sider (basert p� n�kkelord)|Pagine in relazione ( su keywords)|Page en relation (bas� sur les mots cl�s)|P�ginas relacionadas (basado en las palabras clave)|Gerelateerde pagina's (gebaseerd op kernwoorden)|Podobn� strany (podle kl��ov�ch slov)|Strony podobne (s�. kluczowe)|Povezane strani (glede na klju�ne besede)|Asiaan liittyv�t sivut (Perustuen avainsanoihin)|�lgili sayfalar (anahtar kelimelere dayal�)", "6")
				),
				"default" => "0"
			)
		),
		"list_type" => Array (
			"label" => "Plugin:|Plugin:|Erweiterung:|Plugin:||||Plugin:||Wtyczka:||Plugin:|Mod�l:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
//					Array("__Lists:__|__Lister:__|__Listen__:|__Lister:__|__Elenchi__|_Listes:_|__Listas:__|__Lijsten:__|__Seznam:__|__Listy:__|__Seznami:__|__Listat:__", "--div--"),
					Array("Guestbook|G�stebog|G�stebuch|Gjestebok|Libro Visitatori|Livre d'or|Libro de visitas|Gastenboek|N�v�t�vn� kniha|Ksi�ga go�ci|Knjiga gostov|Vieraskirja|Ziyaret�i defteri", "3"),
					Array("Board, List|Forum, Liste|Forum, Liste|Forum, Liste||||Forum, Lijst||Forum, Lista||Ilmoitustaulu, lista|�lan tahtasi", "4"),
					Array("Board, Tree|Forum, Tr�|Forum, Baum|Forum, Tre||||Forum, Boom||Forum, Drzewo||Ilmoitustaulu, puurakenne|�lan tahtas�, A�a�", "2"),
					Array("Products|Produkter|Produkte|Produkter|Prodotti|Produits|Productos|Produkt|Produkty|Produkty|Izdelki|Tuotteet|�r�nler", "5"),
					Array("News|Nyheder|News|Nyheter|News|Nouvelles|Foro|Nieuws|Novinky|Newsy|Novice|Uutiset|Haberler", "9"),
					Array("Addresses|Adresser|Adressen|Adresser|Indirizzi|Adresses|Direcciones|Adres|Adresa|Adresy|Naslovi|Osoitteet|Adresler", "0"),
					Array("To-Do|To-Do|To-Do|Oppgave|Promemoria|Liste des t�ches restant � effectuer|Pendientes|Te-Doen|�koly|Zadania|Naloge|To-Do|Yap�lacak i�ler", "6"),
					Array("Calendar|Kalender|Kalender|Kalender|Calendario|Calendrier|Calendario|Kalender|Kalend��|Kalendarz|Koledar|Kalenteri|Takvim", "7"),
					Array("Links|Links|Links|Hyperkobling|Links|Liens|Ligas|Links|Odkazy|Odno�niki|Povezave|Linkit|Linkler", "1"),
//					Array("__Modules:__|__Moduler:__|__Module:__|__Moduler:__|__Moduli:__|_Modules:_|__M�dulos:__|__Modules:__|__Moduly:__|__Modu�y:__|__Moduli:__|__Modulit:__", "--div--"),
					Array("Rating|Vurdering|Bewertung|Vurdering (rangering)|Rating|Sondage|Calificaci�n|Beoordeling|Hodnocen�|Rating|Anketa|Arvostelu|Rating", "8"),
					Array("Indexed search|Indexeret s�gning|Indexsuche|Indeksert s�king|Ricerca indicizzata|Recherche ind�x�e|B�squeda indexada|Geindexeerd zoeken|Indexovan� vyhled�v�n�|Wyszukiwanie|Indeksirano iskanje|Indeksoitu haku|�ndexlenmi� arama", "10"),
					Array("Tip-a-friend|Send-til-en-ven|Tipp geben|Tips en venn|Prendi un amico|Avertir un ami|Avisa a un amigo|Tip-een-vriend|Tip-a-friend|Pole� znajomym|Nasvet prijatelju|Vihje-yst�v�lle|Bir arkada�a t�yo g�nder", "11"),
					Array("__Administration:__|__Administration:__|__Administration:__|__Administrasjon:__|__Amministrazione:__|_Administration:_|__Administraci�n:__|__Administratie:__|__Administrace:__|__Administracja:__|__Administracija:__|__Hallinta:__|__Y�netim:__", "--div--"),
					Array("Frontend User administration|Website-bruger administration|Frontend Benutzer Administration|Webomr�de-bruker administrasjon|Amministrazione utente di Frontend|Administration des utilisateurs Frontend|Administraci�n de usuarios del frontend|Gebruikersbeheer Publieke Site|Administrace u?ivatel� website|U�ytkownik zewn�trzny|Administracija 'frontend' uporabnikov|Frontend k�ytt�j� hallinta|�n plan Kullan�c� y�netimi", "20"),
					Array("DirectMail subscription|Nyhedsbrevstilmelding|Direct Mail Anmeldung|Nyhetsbrevsinnmelding|Sottoscrizione Direct Mail|Inscription DirectMail|Suscripci�n al Correo Directo|DirectMail abonnement|Subscripce Direct mail|Subskrybcja|DirectMail naro�nina|Suora s�hk�posti tilaus|Do�rudan Mail abonman�", "21"),
					Array("__User defined:__|__Brugerdefineret:__|__Benutzerdefiniert:__|__Brukerdefinert:__|__Definizione utente:__|_D�fini par l'utilisateur:_|__Definido por el usuario:__|__Gebruiker gedefinieerd:__|__Definovan� u?ivatelem:__|__Zdefiniowane:__|__Uporabni�ko dolo�eno:__|__K�ytt�j�n m��ritelm�__|__Kullan�c� tan�mland�:__", "--div--"),
					Array("User defined 1|Brugerdefineret 1|Benutzerdefiniert 1|Brukerdefinert 1|Definizione utente 1|D�fini par l'utilisateur 1|Definido por el usuario 1|Gebruiker gedefinieerd 1|Definovan� u?ivatelem 1|Zdefiniowane 1|Uporabni�ko dolo�eno 1|K�ytt�j�n m��ritelm� 1|Kullan�c� tan�mland� 1", "100"),
					Array("User defined 2|Brugerdefineret 2|Benutzerdefiniert 2|Brukerdefinert 2|Definizione utente 2|D�fini par l'utilisateur 2|Definido por el usuario 2|Gebruiker gedefinieerd 2|Definovan� u?ivatelem 2|Zdefiniowane 2|Uporabni�ko dolo�eno 2|K�ytt�j�n m��ritelm� 2|Kullan�c� tan�mland� 2", "101"),
					Array("User defined 3|Brugerdefineret 3|Benutzerdefiniert 3|Brukerdefinert 3|Definizione utente 3|D�fini par l'utilisateur 3|Definido por el usuario 3|Gebruiker gedefinieerd 3|Definovan� u?ivatelem 3|Zdefiniowane 3|Uporabni�ko dolo�eno 3|K�ytt�j�n m��ritelm� 3|Kullan�c� tan�mland� 3", "102"),
					Array("User defined 4|Brugerdefineret 4|Benutzerdefiniert 4|Brukerdefinert 4|Definizione utente 4|D�fini par l'utilisateur 4|Definido por el usuario 4|Gebruiker gedefinieerd 4|Definovan� u?ivatelem 4|Zdefiniowane 4|Uporabni�ko dolo�eno 4|K�ytt�j�n m��ritelm� 4|Kullan�c� tan�mland� 4", "103")
				),
				"default" => "0"
			)
		),
		"select_key" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["code"],
			"config" => Array (
				"type" => "input",		
				"size" => "20",
				"max" => "80",
				"eval" => "trim"
			)
		),
		"table_bgColor" => Array (
			"exclude" => 1,	
			"label" => "Backgr. Color:|Baggr. Farve:|Hintergr. Farbe:|Bakgrunns farge:|Colore di sfondo:|Couleur de fond:|Color de fondo:|Achtergrondkleur:|Barva pozad�:|Kolor t�a:|Barva ozadja:|Taustan v�ri:|Arka zemin rengi:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["default_value"], "0"),
					Array("Color 1|Farve 1|Farbe 1|Farge 1|Colore 1|Couleur 1|Color 1|Kleur 1|Barva 1|Kolor 1|Barva 1|V�ri 1|Renk 1", "1"),
					Array("Color 2|Farve 2|Farbe 2|Farge 2|Colore 2|Couleur 2|Color 2|Kleur 2|Barva 2|Kolor 2|Barva 2|V�ri 2|Renk 2", "2"),
					Array("None|Ingen|Keine|Ingen|Nessuno|Aucune|Ninguno|Geen|��dn�|Brak|Brez|Ei mit��n|Hi�biri", "200"),
					Array("-----","--div--"),
					Array("Black|Sort|Schwarz|Svart|Nero|Noir|Negro|Zwart|�ern�|Czarny|�rna|Musta|Siyah", "240"),
					Array("White|Hvid|Weiss|Hvit|Bianco|Blanc|Blanco|Wit|B�l�|Bia�y|Bela|Valkoinen|Beyaz", "241"),
					Array("Dark gray|M�rkegr�|Dunkelgrau|M�rkegr�|Grigio scuro|Gris sombre|Gris obscuro|Donker grijs|Tmav� �ed�|Ciemny szary|Temno siva|Tumman harmaa|Koyu gri", "242"),
					Array("Gray|Gr�|Grau|Gr�|Grigio|Gris clair|Gris claro|Grijs|�ed�|Szary|Siva|Harmaa|Gri", "243"),
					Array("Silver|Lysegr�|Silber|Lysegr�|Argento|Argent|Plata|Zilver|St��brn�|Jasny szary|Srebrna|Hopea|G�m��", "244")
				),
				"default" => "0"
			)
		),
		"table_border" => Array (
			"exclude" => 1,	
			"label" => "Border:|Ramme:|Rahmen:|Ramme:|Bordo:|Bordure:|Borde:|Kader:|Okraj:|Ramka:|Rob:|Reunus:|Kenar:",
			"config" => Array (
				"type" => "input",	
				"size" => "3",
				"max" => "3",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "20",
					"lower" => "0"
				),
				"default" => 0
			)
		),
		"table_cellspacing" => Array (
			"exclude" => 1,	
			"label" => "Cellspacing:|Cellemellemrum:|Zellenabstand:|Cellemellomrom:|Spazio celle:|Espacement entre cellules:|Espaciado entre celdas:|Cellspacing:|Mezery mezi bu�kami:|Odst�p:|Razmik med celicami:|Solunv�listys:|H�cre bo�lu�u:",
			"config" => Array (
				"type" => "input",	
				"size" => "3",
				"max" => "3",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "200",
					"lower" => "0"
				),
				"default" => 0
			)
		),
		"table_cellpadding" => Array (
			"exclude" => 1,	
			"label" => "Cellpadding:|Cellemargin:|Zellenf�llung:|Cellemellomrom:|Cellpadding:|Espacement inter cellules:|Tama�o de celdas:|Cellpadding:|Cellpadding:|Margines:|Razmik okrog celice:|Solun t�ytt�:|H�cre dolgusu:",
			"config" => Array (
				"type" => "input",	
				"size" => "3",
				"max" => "3",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "200",
					"lower" => "0"
				),
				"default" => 0
			)
		),
		"media" => Array (
			"label" => "Files:|Filer:|Dateien:|Filer:|Files:|Fichiers:|Archivos:|Bestanden:|Soubory:|Pliki:|Datoteke:|Tiedostot:|Dosyalar:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => "",	// Must be empty for disallowed to work.
				"disallowed" => "php,php3",
				"max_size" => "10000",
				"uploadfolder" => "uploads/media",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "10",
				"minitems" => "0"
			)
		),
		"multimedia" => Array (
			"label" => "File:|Fil:|Datei:|Fil:|File:|Fichier:|Archivo:|Bestand:|Soubor:|Plik:|Datoteka:|Tiedsoto:|Dosya:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => "txt,html,htm,class,swf,swa,dcr,wav,avi,au,mov,asf,mpg,wmv,mp3",
				"max_size" => "10000",
				"uploadfolder" => "uploads/media",
				"size" => "2",
				"maxitems" => "1",
				"minitems" => "0"
			)
		),
		"filelink_size" => Array (
			"label" => "Show filesize:|Vis filst�rrelse:|Zeige Dateigr�sse:|Vis filst�rrelse:|Mostra dimensione files:|Afficher taille du fichier:|Muestra el tama�o:|Toon bestandsgrootte:|Uk�zat velikost:|Pokazuj wielko��:|Velikost datoteke:|N�yt�tiedoston koko:|Dosya ebat�n� g�ster:",
			"config" => Array (
				"type" => "check"
			)
		),
		"records" => Array (
			"label" => "Items:|Emner:|Objekte:|Emner:|Items:|El�ments:|Elementos:|Items:|Polo�ky:|Elementy:|Predmeti:|Kohteet|Nesneler:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "tt_content,tt_address,tt_links,tt_board,tt_guest,tt_calender,tt_products,tt_news",
//					"MM" => "tt_content_records_mm",		// Example ...
				"size" => "5",
				"maxitems" => "200",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"spaceBefore" => Array (
			"exclude" => 1,	
			"label" => "Before:|F�r:|Vor:|F�r:|Prima:|Avant:|Antes:|Voor:|P�ed:|Przed:|Pred:|Ennen:|�nce:",
			"config" => Array (
				"type" => "input",	
				"size" => "3",
				"max" => "3",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "50",
					"lower" => "0"
				),
				"default" => 0
			)
		),
		"spaceAfter" => Array (
			"exclude" => 1,	
			"label" => "After:|Efter:|Nach:|Etter:|Dopo:|Apr�s:|Despu�s:|Na:|Po:|Po:|Po:|J�lkeen:|Sonra:",
			"config" => Array (
				"type" => "input",	
				"size" => "3",
				"max" => "3",
				"eval" => "int",
				"checkbox" => "0",
				"range" => Array (
					"upper" => "50",
					"lower" => "0"
				),
				"default" => 0
			)
		),
		"section_frame" => Array (
			"exclude" => 1,	
			"label" => "Frame:|Ramme:|Rahmen:|Ramme:|Frame:|Frame:|Marco:|Frame:|R�me�ek:|Otoczka:|Okvir:|Osasivu:|�er�eve:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("", "0"),
					Array("Invisible|Usynlig|Unsichtbar|Usynlig|Invisibile|Invisible|Invisible|Onzichtbaar|Neviditeln�|Niewidoczna|Nevidno|N�kym�t�n|G�r�nmeyen", "1"),
					Array("Ruler before|Streg f�r|Linie davor|Strek f�r|Separatore prima|R�gle avant|Pleca antes|Lijn (ruler) voor|��ra p�ed|Linia przed|Ravnilo pred|Mittaviiva ennen|Cetvel �ncesi", "5"),
					Array("Ruler after|Streg efter|Line danach|Strek etter|Separatore dopo|R�gle apr�s|Pleca despu�s|Lijn (ruler) na|��ra za|Linia za|Ravnilo po|Mittaviiva j�lkeen|Cetvel sonras�", "6"),
					Array("Indent|Indrykket|Einr�cken|Innrykk|Indent|Indenter|Identar|Inspringen|Odsazen�|Wci�cie|Umik|Sisenn�|Sol paragraf bo�lu�u", "10"),
					Array("Indent, 33/66%|Indrykket, 33/66%|Einr�cken, 33/66%|Innrykket, 33/66%|Indent, 33/66%|Identer, 33/66%|Identar, 33/66%|Inspringen, 33/66%|Odsadit, 33/66%|Wci�cie 1/3|Umik 33/66%|Sisenn�, 33/66%|Sol paragraf bo�lu�u, 33/66%", "11"),
					Array("Indent, 66/33%|Indrykket, 66/33%|Einr�cken, 66/33%|Innrykket, 66/33%|Indent, 66/33%|Identer, 66/33%|Identar, 66/33%|Inspringen, 66/33%|Odsadit, 66/33%|Wci�cie 2/3|Umik 66/33%|Sisenn�, 66/33%|Sol paragraf bo�lu�u, 66/33%", "12"),
					Array("Frame 1|Ramme 1|Rahmen 1|Ramme 1|Frame 1|Frame 1|Marco 1|Frame 1|R�me�ek 1|Otoczka 1|Okvir 1|Osasivu 1|�er�eve 1", "20"),
					Array("Frame 2|Ramme 2|Rahmen 2|Ramme 2|Frame 2|Frame 2|Marco 2|Frame 2|R�me�ek 2|Otoczka 2|Okvir 2|Osasivu 2|�er�eve 2", "21")
				),
				"default" => "0"
			)
		),
		"splash_layout" => Array (
			"exclude" => 1,	
			"label" => "Textbox type:|Tekstboks type:|Textfeld Typ:|Tekstboks type:||||Textvak type:||Typ okna tekstowego:||Tekstilaatikon tyyppi:|T�r:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array($LANG_GENERAL_LABELS["default_value"], "0"),
					Array("Image Shadow|Billedskygge|Schatten|Bildeskygge|Immagine nascosta|Image ombr�e|Sombra de la im�gen|Afbeelding schaduw|St�n obr�zku|Cie� obrazka|Senca slike|Oletus|Resim G�lgesi", "1"),
					Array("Image Frame 1|Billedramme 1|Bildrahmen 1|Bilderamme 1|Immagine frame 1|Image frame 1|Marco de im�gen 1|Afbeelding Frame 1|R�me�ek obr�zku 1|Otoczka 1|1. Okvir s sliko|Kuvaan reunat 1|Resim �er�evesi 1", "2"),
					Array("Image Frame 2|Billedramme 2|Bildrahmen 2|Bilderamme 2|Immagine frame 2|Image frame 2|Marco de im�gen 2|Afbeelding Frame 2|R�me�ek obr�zku 2|Otoczka 2|2. Okvir s sliko|Kuvaan reunat 2|Resim �er�evesi 2", "3"),
					Array("__Graphical:__|__Grafiske:__|__Grafisch:__|__Grafiske:__|__Grafica:__|___Graphique :___|__Gr�ficas:__|__Grafisch:__|__Grafick�:__|__Graficzne:__|__Grafi�no:__|__Graafinen:__|__Kullan�c� tayin edildi:__", "--div--"),
					Array("Postit 1|Postit 1|Postit 1|Postit 1|Postit 1|Post-it 1|Post-it 1|Postit 1|Post-it 1|Karteczka Postit 1||Postit 1|Postala 1", "20"),
					Array("__User defined:__|__Brugerdefineret:__|__Benutzerdefiniert:__|__Brukerdefinert:__|__Definizione utente:__|_D�fini par l'utilisateur:_|__Definido por el usuario:__|__Gebruiker gedefinieerd:__|__Definovan� u?ivatelem:__|__Zdefiniowane:__|__Uporabni�ko dolo�eno:__|__K�ytt�j�n m��ritelm�__|__Kullan�c� tan�mland�:__", "--div--"),
					Array("User defined 1|Brugerdefineret 1|Benutzerdefiniert 1|Brukerdefinert 1|Definizione utente 1|D�fini par l'utilisateur 1|Definido por el usuario 1|Gebruiker gedefinieerd 1|Definovan� u?ivatelem 1|Zdefiniowane 1|Uporabni�ko dolo�eno 1|K�ytt�j�n m��ritelm� 1|Kullan�c� tayin edildi 1", "30"),
					Array("User defined 2|Brugerdefineret 2|Benutzerdefiniert 2|Brukerdefinert 2|Definizione utente 2|D�fini par l'utilisateur 2|Definido por el usuario 2|Gebruiker gedefinieerd 2|Definovan� u?ivatelem 2|Zdefiniowane 2|Uporabni�ko dolo�eno 2|K�ytt�j�n m��ritelm� 2|Kullan�c� tayin edildi 2", "31"),
					Array("User defined 3|Brugerdefineret 3|Benutzerdefiniert 3|Brukerdefinert 3|Definizione utente 3|D�fini par l'utilisateur 3|Definido por el usuario 3|Gebruiker gedefinieerd 3|Definovan� u?ivatelem 3|Zdefiniowane 3|Uporabni�ko dolo�eno 3|K�ytt�j�n m��ritelm� 3|Kullan�c� tayin edildi 3", "32"),
					Array("User defined 4|Brugerdefineret 4|Benutzerdefiniert 4|Brukerdefinert 4|Definizione utente 4|D�fini par l'utilisateur 4|Definido por el usuario 4|Gebruiker gedefinieerd 4|Definovan� u?ivatelem 4|Zdefiniowane 4|Uporabni�ko dolo�eno 4|K�ytt�j�n m��ritelm� 4|Kullan�c� tayin edildi 4", "33")
				),
				"default" => "0"
			)
		),
		"sectionIndex" => Array (
			"exclude" => 1,	
			"label" => "Index:|Index:|Index:|Index:|Indice:|Index:|�ndice:|Index:|Index:|Sekcja:|Kazalo:|Indeksi:|�ndeks:",
			"config" => Array (
				"type" => "check",
				"default" => 1
			)
		),
		"linkToTop" => Array (
			"exclude" => 1,	
			"label" => "To top:|Til top:|Nach Oben:|Til toppen:|Vai su:|Vers la haut:|Al principio de p�gina:|Naar boven:|Nahoru:|Do g�ry:|Na vrh:|Alkuun:|En �ste:",
			"config" => Array (
				"type" => "check"
			)
		),
		"rte_enabled" => Array (
			"exclude" => 1,
			"label" => "Disable Rich Text Editor:|Sl� formatteret redigering fra:|Rich Text Editor abschalten:|Ikke bruk Rik Tekst editoren (tekstbehandleren):|Disabilita Rich Text:|D�sactiver Rich Text Editor:|Desactivar editor RTF:|Deactiveer Tekst Plus Editor (TPE):|Vypnout Rich Text Editor:|Wy��cz RTE:|Izklopi urejevalnik oblikovanega besedila:|Poista RTE k�yt�st�|Zengin Metin D�zenleyiciyi devre d��� b�rak:",
			"config" => Array (
				"type" => "check",
				"showIfRTE" => 1
			)
		),
		"module_sys_dmail_category" => Array("config"=>array("type"=>"passthrough"))
	),
	"types" => Array (	
		"1" => 	Array("showitem" => "CType"),
		"header" => 	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, subheader;;8"),
		"text" => 		Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, bodytext;;9;richtext[paste|bold|italic|underline|formatblock|class|left|center|right|orderedlist|unorderedlist|outdent|indent|link|image]:rte_transform[flag=rte_enabled|mode=ts];3-3-3, rte_enabled, text_properties"),
		"textpic" => 	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, bodytext;;9;richtext[paste|bold|italic|underline|formatblock|class|left|center|right|orderedlist|unorderedlist|outdent|indent|link|image]:rte_transform[flag=rte_enabled|mode=ts];3-3-3, rte_enabled, text_properties, --div--, image;;;;4-4-4, imageorient;;2, imagewidth;;13, 
			--palette--;Image Link|Billedlink|Bild-Link|Bildehyperkobling|Link immagine|Liens sur Image|Liga a im�gen|Afbeelding link|Odkaz obr�zku|Odno�nik obrazka|Povezava slike|Kuvan linkki|Resim Linki;7, 
			--palette--;Image Options|Billedvalg|Bild Optionen|Bildevalg|Opzioni immagine|Options d\'image|Opciones de im�gen|Afbeelding opties|Vlastnosti obr�zku|Parametry obrazka|Nastavitve slike|Kuvan ominaisuudet|Resim Se�enekleri;11, 
			imagecaption;;5"),
		"rte" => 		Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, bodytext;;;nowrap:richtext[*]:rte_transform[mode=ts_images-ts_reglinks];3-3-3"),
		"image" => 		Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, image;;;;4-4-4, imageorient;;2, imagewidth;;13, 
			--palette--;Image Link|Billedlink|Bild-Link|Bildehyperkobling|Link immagine|Liens sur Image|Liga a im�gen|Afbeelding link|Odkaz obr�zku|Odno�nik obrazka|Povezava slike|Kuvan linkki|Resim Linki;7, 
			--palette--;Image Options|Billedvalg|Bild Optionen|Bildevalg|Opzioni immagine|Options d\'image|Opciones de im�gen|Afbeelding opties|Vlastnosti obr�zku|Parametry obrazka|Nastavitve slike|Kuvan ominaisuudet|Resim Se�enekleri;11,
			 imagecaption;;5"),
		"bullets" => 	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, layout;;;;3-3-3, bodytext;;9;nowrap, text_properties"),
		"table" => 		Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, layout;;10;button;3-3-3, cols, bodytext;;9;nowrap:wizards[table], text_properties"),
		"splash" => 	Array("showitem" => "CType;;4;button;1-1-1, header;".$LANG_GENERAL_LABELS["name"].";;;2-2-2, splash_layout, bodytext;;;;3-3-3, image;;6"),
		"uploads" => 	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, media;;;;5-5-5, 
			select_key;Read from path:|L�s fra sti:|Dateipfad:|Les fra sti:|Leggi dal percorso:|Lire depuis le chemin:|Leer de la ruta:|Lees vanuit pad:|Na��st z cesty:|Odczytaj ze �cie�ki:|Beri iz poti:|Luo polusta:|Yoldan oku:, 
			layout;;10;button, filelink_size, 
			imagecaption;Descriptions:|Beskrivelser:|Beschreibungen:|Beskrivelser:|Descrizione:|Descriptions:|Descripci�n:|Omschrijvingen:|Popis:|Opis:|Opisi:|Kuvaukset:|Tan�mlama:;;nowrap"),
		"multimedia" =>	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, multimedia;;;;5-5-5, bodytext;".$LANG_GENERAL_LABELS["parameters"].";;nowrap"),
		"script" =>		Array("showitem" => "CType;;4;button;1-1-1, header;".$LANG_GENERAL_LABELS["name"].";;;2-2-2, select_key;;;;5-5-5, pages;;12, bodytext;".$LANG_GENERAL_LABELS["parameters"].";;nowrap, 
			imagecaption;Comments:|Kommentarer:|Kommentar:|Kommentarer:|Commenti:|Commentaires:|Comentarios:|Commentaar:|Pozn�mky:|Komentarz:|Opombe:|Kommentit:|Yorumlar:"),
		"menu" => 		Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, menu_type;;;;5-5-5, pages"),
		"mailform" => 	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, 
			bodytext;Configuration:|Ops�tning:|Konfiguration:|Oppsett:|Configurazione:|Configuration:|Configuraci�n:|Configuratie:|Konfigurece:|Konfiguracja:|Nastavitve:|Asetukset:|Konfig�rasyon:;;nowrap:wizards[forms];5-5-5, 
			pages;Jump to page:|Spring til side:|Zielseite:|G� til side:|Salta alla pagina:|Aller � la page:|Ir a la p�gina:|Spring naar pagina:|P�ej�t na stranu:|Skocz do strony:|Sko�i na stran:|Mene sivulle:|Sayfaya ge�:, 
			subheader;Recipient-email:|Modtager-email:|Empf.-EMailadr.:|Mottakers-epost:|Contenitore E-mail:|E-mail du destinataire:|Email del destinatario:|Emailadres ontvanger:|E-mail p��jemce:|Email odbiorcy:|Prejemnikov email:|Vastaanottajan s�hk�postiosoite:|Al�c� e-maili:"),
		"search" => 	Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, 
			pages;Send to page:|Send til side:|Zielseite:|Send til side:|Manda alla pagina:|Envoyer � la page:|Enviar a la p�gina:|Stuur naar pagina:|Odeslat na stranu:|Wy�lij do strony:|Po�lji na stran:|L�het� sivulle:|Sayfaya g�nder:;;;5-5-5"),
		"login" => 		Array("showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, 
			pages;Send to page:|Send til side:|Zielseite:|Send til side:|Manda alla pagina:|Envoyer � la page:|Enviar a la p�gina:|Stuur naar pagina:|Odeslat na stranu:|Wy�lij do strony:|Po�lji na stran:|L�het� sivulle:|Sayfaya g�nder:;;;5-5-5"),
		"shortcut" => 	Array("showitem" => "CType;;4;button;1-1-1, header;".$LANG_GENERAL_LABELS["name"].";;;2-2-2, records;;;;5-5-5, layout"),
		"list" => 		Array(
							"showitem" => "CType;;4;button;1-1-1, header;;3;;2-2-2, --div--, list_type;;;;5-5-5, layout, select_key, pages;;12",
							"subtype_value_field" => "list_type",
							"subtypes_excludelist" => Array(
								"3" => "layout",
//								"4" => "layout",	// List type forum
								"2" => "layout",
								"5" => "layout",
								"9" => "layout",
								"0" => "layout",
								"6" => "layout",
								"7" => "layout",
								"1" => "layout",
								"8" => "layout",
								"10" => "layout",
								"11" => "layout",
								"20" => "layout",
								"21" => "layout"
							)
						),
		"div" => 		Array("showitem" => "CType;;14;button;1-1-1, header;".$LANG_GENERAL_LABELS["name"].";;;2-2-2"),
		"html" => 		Array("showitem" => "CType;;4;button;1-1-1, header;".$LANG_GENERAL_LABELS["name"].";;;2-2-2, 
			bodytext;HTML:|HTML-kode:|HTML:|HTML-kode:|HTML:|HTML:|HTML:|HTML:|HTML:|HTML:|HTML:|HTML:|HTML:;;nowrap;3-3-3")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "hidden, starttime, endtime, fe_group"),
		"2" => Array("showitem" => "imagecols, image_noRows, imageborder"),
		"3" => Array("showitem" => "header_position, header_layout, header_link, date"),
		"4" => Array("showitem" => "sys_language_uid, colPos, spaceBefore, spaceAfter, section_frame, sectionIndex, linkToTop"),
		"5" => Array("showitem" => "imagecaption_position"),
		"6" => Array("showitem" => "imagewidth,image_link"),
		"7" => Array("showitem" => "image_link, image_zoom"),
		"8" => Array("showitem" => "layout"),
		"9" => Array("showitem" => "text_align,text_face,text_size,text_color"),
		"10" => Array("showitem" => "table_bgColor, table_border, table_cellspacing, table_cellpadding"),
		"11" => Array("showitem" => "image_compression, image_effects, image_frames"),
		"12" => Array("showitem" => "recursive"),
		"13" => Array("showitem" => "imageheight"),
		"14" => Array("showitem" => "sys_language_uid, colPos")
	)
);



?>