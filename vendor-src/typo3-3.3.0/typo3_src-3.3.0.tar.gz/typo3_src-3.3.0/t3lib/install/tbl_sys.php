<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Dynamic configuation of the system-related tables, typ. sys_* series
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



 
// ******************************************************************
// sys_dmail is for direct mails
// ******************************************************************
$TCA["sys_dmail"] = Array (
	"ctrl" => $TCA["sys_dmail"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "type,plainParams,HTMLParams,subject,from_name,from_email,replyto_name,replyto_email,organisation,attachment,priority,sendOptions,issent,renderedsize"
	),
	"columns" => Array (	
		"subject" => Array (
			"label" => "Subject:|Emne:|Betreff:|Emne:|Soggetto:|Sujet:|Asunto:|Onderwerp:|P�edm�t:|Temat:|Predmet:|Asia:|Konu:",
			"config" => Array (
				"type" => "input",
				"size" => "30",
				"max" => "120",
				"eval" => "trim,required"
			)
		),
		"page" => Array (	
			"label" => "Mail page:|Side med mail:|Seiten senden:|Side med e-post:|Pagina Mail:|Envoyer la page:|P�gina de email:|Email pagina:|Strana s mailem:|Mailowana strona:|Po�lji stran:|S�hk�posti sivu:|Mail sayfas�:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "pages",
				"size" => "3",
				"maxitems" => 1,
				"minitems" => 0
			)
		),
		"from_email" => Array (
			"label" => "Sender email:|Afsender email:|Absender EMail:|Avsender e-post:|E-mail mittente:|E-mail de l\'auteur:|Email del remitente:|Emailadres van afzender:|E-mail odes�latele:|Email nadawcy:|Email po�iljatelja:|L�hett�j�n s�hk�postiosoite:|G�nderenin e-maili:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"max" => "80",
				"eval" => "trim,required"
			)
		),
		"from_name" => Array (
			"label" => "Sender name:|Afsender navn:|Absender Name:|Avsender navn:|Nome mittente:|Pr�nom et nom de l\'auteur:|Nombre del remitente:|Naam van afzender:|Odes�latel:|Nadawca:|Ime po�iljatelja:|L�hett�j�n nimi;|G�nderenin ad�:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"replyto_email" => Array (
			"label" => "Reply email:|Svar email:|Antwort EMail:|Svar e-post:|E-mail di risposta:|E-mail de r�ponse:|Email de respuesta:|Antwoord email:|Odpov�d�t na (e-mail):|Adres zwrotny:|Email za odgovore:|Palautus s�hk�postiosoite:|Cevap e-maili:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"replyto_name" => Array (
			"label" => "Reply name:|Svar navn:|Antwort Name:|Svar navn:|Nome per la risposta:|Pr�nom et nom de r�ponse:|Nombre de respuesta:|Antwoord naam:|Odpov�d�t na (jm�no):|Nazwa zwrotna:|Ime za odgovore:|Palautusnimi:|Cevap ad�:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"return_path" => Array (
			"label" => "Return Path:|Retur sti:|Return Pfad:|Retur sti:|Percorso di ritorno:|Chemin de retour:|Ruta de retorno:|Retour Pad:|Cesta pro odpov��:|�cie�ka zwrotna:|Povratna pot:|Palautusosoite:|Geri d�n�� yolu:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"organisation" => Array (
			"label" => "Organization:|Organisation:|Organisation:|Organisasjon:|Organizzazione:|Organisation:|Organizaci�n:|Organisatie:|Organizace:|Firma:|Organizacija:|Organisaatio|Organizasyon:",
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"priority" => Array (
			"label" => "Priority:|Prioritet:|Priorit�t:|Prioritet:|Priorita\':|Priorit�:|Prioridad:|Prioriteit:|D�le�itost:|Priorytet:|Prioriteta:|Prioriteetti:|�ncelikli:",
			"config" => Array (
				"type" => "select",		
				"items" => Array (
					Array("Low|Lav|Niedrig|Lav|Bassa|Basse|Baja|Laag|N�zk�|Niski:|Nizka|alhainen|D���k:", "5"),
					Array($LANG_GENERAL_LABELS["normal"], "3"),
					Array("High|H�j|Hoch|H�y|Alta|Haute|Alta|Hoog|Vysok�|Wysoki:|Visoka|korkea|Y�ksek:", "1")
				),
				"default" => "3"
			)
		),
		"sendOptions" => Array (
			"label" => "Include:|Medtag:|Einbinden:|Inkluder:|Includi:|Inclure:|Incluir:|Inclusief:|Vlo�it:|W��cz:|Vklju�i:|Sis�lt�en:|Dahil edilen:",
			"config" => Array (
				"type" => "check",
				"items" => Array (
					Array("Plain text|Ren tekst|Normaler Text|Ren tekst|Testo ASCI|Texte simple|Texto simple|Plain tekst|Prost� text|Zwyk�y tekst|Samo besedilo|Pelkk� teksti|HTML", ""),
					Array("HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML|HTML", "")
				),
				"default" => "3"
			)
		),
		"HTMLParams" => Array (
			"label" => "Parameters, HTML:|Parametre, HTML:|Parameter, HTML:|Parametere, HTML:|Parametri HTML:|Param�tre, HTML:|Par�metros, HTML:|Parameters, HTML:|Parametry, HTML:|Parametry, HTML:|Parametri, samo besedilo|Muuttujat, HTML:|Parametreler, HTML:",
			"config" => Array (
				"type" => "input",	
				"size" => "15",
				"max" => "80",
				"eval" => "trim",
				"default" => ""
			)
		),
		"plainParams" => Array (
			"label" => "Parameters, Plain text:|Parametre, Ren tekst:|Parameter, normaler Text:|Parametere, Ren tekst:|Parametri testo ASCI:|Param�tre, Texte simple:|Par�metros, texto simple:|Parameters, Plain tekst:|Parametry, prost� text:|Parametry, zwyk�y tekst:|Parametri, HTML|Muuttujat, pelkk� teksti:|Parametreler, Basit metin:",
			"config" => Array (
				"type" => "input",	
				"size" => "15",
				"max" => "80",
				"eval" => "trim",
				"default" => "&type=99"
			)
		),
		"issent" => Array (	
			"label" => "Is sent:|Sendt:|Gesendet:|Sendt:|Inviato:|Est envoy�:|Enviado:|Is verzonden:|Odesl�no:|Wys�ano:|Je poslano:|L�hetetty:|G�nderilmi�tir:",
			"config" => Array (
				"type" => "none"
			)
		),
		"renderedsize" => Array (	
			"label" => "Compiled size:|Kompileret st�rrelse:|�bertragungsgr�sse:|Kompilert st�rrelse:|Dimensione:|Taille:|Tama�o compilado:|Gecompileerde grootte:|Kompletn� velikost:|Wielko��:|Dejanska velikost:|K�sitelty koko:|Sunulan ebat:",
			"config" => Array (
				"type" => "none"
			)
		),
		"attachment" => Array (
			"label" => "Attachments:|Vedh�ng:|Anh�nge:|Vedlegg:|Allegati:|Annexes:|Anexos:|Bijlage:|P��lohy:|Za��czniki:|Priponke:|Liitetiedostot:|�li�tirmeler:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => "",	// Must be empty for disallowed to work.
				"disallowed" => "php,php3",
				"max_size" => "500",
				"uploadfolder" => "uploads/dmail_att",
				"show_thumbs" => "0",
				"size" => "3",
				"maxitems" => "5",
				"minitems" => "0"
			)
		),
		"type" => Array (
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (	
					Array("Typo3 page|Typo3 side|Typo3 Seite|Typo3 side|Typo3 page|Page Typo3|P�gina Typo3|Typo3 pagina|Strana Typo3|Strona Typo3|Typo3 stran|Typo 3 sivu|Typo3 sayfas�", "0"),
					Array("External URL|Extern URL|Externe URL|Ekstern webadresse (URL)|URL esterno|URL externe|URL Externo|Externe URL|Extern� URL|Zewn�trzny URL|Eksterni URL|Ulkoinen URL|D�� URL", "1")
				),
				"default" => "0"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "type;;;;1-1-1, page, plainParams, HTMLParams, --div--, subject;;;;3-3-3, from_email, from_name, replyto_email, replyto_name, return_path, organisation, attachment;;;;4-4-4, priority;;;;5-5-5, sendOptions, issent, renderedsize"),
		"1" => Array("showitem" => "type;;;;1-1-1, 
			plainParams;URL for plaintext:|URL til \"Ren tekst\"-indhold:|URL f�r normalen Text:|URL til \"Ren tekst\"-innhold:|URL per testo ASCI:|URL pour texte simple:|URL para el texto simple:|URL voor platte tekst:|URL pro prost� text:|URL zwyk�ego tekstu:|URL vklju�enega besedila:|URL pelkistetylle tekstille:|Basit metin i�in URL:, 
			HTMLParams;URL for HTML-content:|URL til HTML-indhold:|URL f�r HTML-Inhalt:|URL til HTML-innhold:|URL per contenuto HTML:|URL pour HTML content:|URL para contenido HTML:|URL voor HMTL-inhoud:|URL pro HTML-obsah:|URL zawarto�ci HTML:|URL vklju�ene HTML vsebine:|URL HTML-sis�ll�lle:|HTML-i�eri�i i�in URL:, 
			--div--, subject;;;;3-3-3, from_email, from_name, replyto_email, replyto_name, return_path, organisation, attachment;;;;4-4-4, priority;;;;5-5-5, sendOptions, issent, renderedsize")
	)
);




// ******************************************************************
// sys_dmail_group
// ******************************************************************
$TCA["sys_dmail_group"] = Array (
	"ctrl" => $TCA["sys_dmail_group"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "type,title,description"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",
				"size" => "30",
				"max" => "120",
				"eval" => "trim,required"
			)
		),
		"description" => Array (
			"label" => $LANG_GENERAL_LABELS["description"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "3"
			)
		),
		"type" => Array (
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (	
					Array("From pages|Fra sider|Von Seiten|Fra sider|Dalla pagina|Depuis la page|De las p�ginas|Van pagina's|Od str�nky|Ze stron|Iz strani|Sivuilta|Sayfalardan", "0"),
					Array("Plain list|Liste|Normale Liste|Liste|Elenco piano|Liste simple|Lista simple|Standaard lijst|Prost� seznam|Lista|Obi�ajen seznam|Pelkistetty lista|Basit liste", "1"),
					Array("Static group|Statisk gruppe|Statische Gruppe|Statisk gruppe|Gruppo Statico|Groupe statique|Grupo est�tico|Statische groep|Statick� skupina|Grupa statyczna|Stati�na skupina|Pysyv� ryhm�|Statik grup", "2"),
					Array("Special query|Specielt opslag|Spezielle Anfrage|Spesielt oppslag|Query speciale|Requ�te sp�ciale|B�squeda especial|Speciale zoekopdracht|Speci�ln� dotaz|Kwerenda|Posebna poizvedba|Erikoiskysely|�zel soru", "3"),
					Array("Other Mail Groups|Andre mail grupper|Andere Mailgruppe|Andre e-post grupper|Altri gruppi di e-mail|Autres groupes de courrier|Otros Grupos de Correo|Andere Mail Groepen|Dal?� mailov� skupiny|Inne grupy mailowe|Druga po�tna skupina|Muut s�hk�posti ryhm�t|Ba�ka mail gruplar�", "4")
				),
				"default" => "0"
			)
		),
		"static_list" => Array (
			"label" => "Recipients:|Modtagere:|Empf�nger:|Mottakere:|Recipienti:|Destinataires:|Destinatarios:|Ontvangers:|P��jemci:|Odbiorcy:|Prejemniki:|Vastaanottajat:|Al�c�lar:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "tt_address,fe_users",
					"MM" => "sys_dmail_group_mm",
				"size" => "20",
				"maxitems" => "100000",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"pages" => Array (
			"label" => $LANG_GENERAL_LABELS["startingpoint"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "pages",
				"size" => "3",
				"maxitems" => "22",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"mail_groups" => Array (
			"label" => "Other mailgroups:|Andre mail grupper:|Andere Mailgruppen:|Andre e-post grupper:|Altri gruppi di e-mail:|Autres groupes de courrier:|Otros grupos de correo:|Andere Mail Groepen:|Dal?� mailov� skupiny:|Inne grupy mailowe:|Druge po�tne skupine:|Muut s�hk�postiryhm�t:|Ba�ka mail gruplar�:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
					"allowed" => "sys_dmail_group",
				"size" => "3",
				"maxitems" => "22",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),
		"recursive" => Array (
			"label" => $LANG_GENERAL_LABELS["recursive"],
			"config" => Array (
				"type" => "check"
			)
		),
		"whichtables" => Array (
			"label" => "Tables:|Tabeller:|Tabellen:|Tabeller:|Tavole:|Tables:|Tablas:|Tabellen:|Tabulky:|Tabele:|Tabele:|Taulut:|Tablolar:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Address|Adresse|Adresse|Adresse|Indirizzo|Adresse|Direcci�n|Adres|Adresa|Adres|Naslov|Osoite|Kullan�c� taraf�ndan belirlenen tablo", ""),
					Array("Website user|Website bruger|Website Benutzer|Webside bruker|Utente Web|Utilisateur website|Usuarios del Website|Webpagina gebruiker|U�ivatel website|U�ytkownik zewn�trzny|Web uporabnik|WWW-sivujen k�ytt�j�|Website kullan�c�s�", ""),
					Array("User Defined Table|Brugerdefineret tabel|Benutzerdefinierte Tabelle|Brukerdefinert tabell|Tavole definite dall'utente|Table d�finie par l'utilisateur|Tabla definida por el usuario|Gebruiker Gedefinieerde Tabel|U?ivatelem definovan� tabulka|Tabela zdefiniowana|Uporabni�ko dolo�ena tabela|K�ytt�j�n m��rittelem� taulu|Kullan�c� tablosu tan�mland�", ""),
				),
				"cols" => 3,
				"default" => 1
			)
		),
		"list" => Array (
			"label" => "Recipients:|Modtagere:|Empf�nger:|Mottakere:|Recipienti:|Destinataires:|Destinatarios:|Ontvangers:|P��jemci:|Odbiorcy:|Prejemniki:|Vastaanottajat:|Al�c�lar:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",	
				"rows" => "10"
			)
		),
		"csv" => Array (
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (
					Array("Separate emails by space/comma/linebreak|Adskil emailadresser med mellemrum/komma/linieskift|Trennung der Emails durch Leerzeichen/Kommata/Zeilenumbruch|Skill e-postadresser med mellomrom/komma/linjeskift|Separate le e-mail con spazio/virgola/linebreak|S�parer les courrier par des espace/virgule/saut � la ligne|Separar direcciones de correo mediante espacio/coma/fin de l�anea|Scheid emailadressen door spatie/komma/harde return|Odd�lovat emaily mezerou/��rkou/zalomen�m ��dky|Oddziel emaile spacj�/przecinkiem/enterem|Lo�i sporo�ila z presledkom/piko/novo vrsto|Erottele emailit tyhj�ll�/pilkulla/rivinvaihdolla|E-maillerin bo�luk/virg�l/sat�r bitimi taraf�ndan ayr�lmas�", "0"),
					Array("CSV [name],[email]|CSV [navn],[email adresse]|CSV [name],[email]|CSV [navn],[e-post adresse]|CVS [Nome],[email]|CSV [name],[email]|CSV [nombre],[email]|CSV [naam],[emailadres]|CSV [name],[email]|CSV [nazwa],[email]|CSV [ime],[email]|CSV[Nimi],[S�hk�postiosoite]|CSV [ad�],[e-maili]", "1")
				),
				"default" => "0"
			)
		),
		"select_categories" => Array (
			"label" => "Must Attend Categories:|Skal tilh�re kategorier:|Kategorien m�ssen �bereinstimmen:|M� tilh�re kategorier:|Deve aver sottoscritto le seguenti categorie:|Doit attendre une cat�gorie:|Categor�as de atenci�n forzada:|Moet in de volgende categorien vallen:|Nutn� kategorie:|Nale�y do kategorii:|Obvezno vklju�ene kategorije:|Luokkaan liitt�minen pakollinen|Haz�r bulunmas� gereken kategoriler:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Cat 0|Kat 0|Kat 0|Kat 0|Cat 0|Cat 0|Cat 0|Cat 0|Cat 0|Kategoria 0|Kat. 0|Luokka 0|Kategori 0",0),
					Array("Cat 1|Kat 1|Kat 1|Kat 1|Cat 1|Cat 1|Cat 1|Cat 1|Cat 1|Kategoria 1|Kat. 1|Luokka 1|Kategori 1",1),
					Array("Cat 2|Kat 2|Kat 2|Kat 2|Cat 2|Cat 2|Cat 2|Cat 2|Cat 2|Kategoria 2|Kat. 2|Luokka 2|Kategori 2",2),
					Array("Cat 3|Kat 3|Kat 3|Kat 3|Cat 3|Cat 3|Cat 3|Cat 3|Cat 3|Kategoria 3|Kat. 3|Luokka 3|Kategori 3",3),
					Array("Cat 4|Kat 4|Kat 4|Kat 4|Cat 4|Cat 4|Cat 4|Cat 4|Cat 4|Kategoria 4|Kat. 4|Luokka 4|Kategori 4",4),
					Array("Cat 5|Kat 5|Kat 5|Kat 5|Cat 5|Cat 5|Cat 5|Cat 5|Cat 5|Kategoria 5|Kat. 5|Luokka 5|Kategori 5",5),
					Array("Cat 6|Kat 6|Kat 6|Kat 6|Cat 6|Cat 6|Cat 6|Cat 6|Cat 6|Kategoria 6|Kat. 6|Luokka 6|Kategori 6",6),
					Array("Cat 7|Kat 7|Kat 7|Kat 7|Cat 7|Cat 7|Cat 7|Cat 7|Cat 7|Kategoria 7|Kat. 7|Luokka 7|Kategori 7",7),
					Array("Cat 8|Kat 8|Kat 8|Kat 8|Cat 8|Cat 8|Cat 8|Cat 8|Cat 8|Kategoria 8|Kat. 8|Luokka 8|Kategori 8",8),
					Array("Cat 9|Kat 9|Kat 9|Kat 9|Cat 9|Cat 9|Cat 9|Cat 9|Cat 9|Kategoria 9|Kat. 9|Luokka 9|Kategori 9",9)
				),
				"cols" => 5
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "type;;;;1-1-1, title;;;;3-3-3, description, --div--,pages;;;;5-5-5,recursive,whichtables,select_categories"),
		"1" => Array("showitem" => "type;;;;1-1-1, title;;;;3-3-3, description, --div--,list;;;;5-5-5,csv"),
		"2" => Array("showitem" => "type;;;;1-1-1, title;;;;3-3-3, description, --div--,static_list;;;;5-5-5"),
		"3" => Array("showitem" => "type;;;;1-1-1, title;;;;3-3-3, description"),
		"4" => Array("showitem" => "type;;;;1-1-1, title;;;;3-3-3, description, --div--,mail_groups;;;;5-5-5")
	)
);





// ******************************************************************
// sys_filemounts
// ******************************************************************
$TCA["sys_filemounts"] = Array (
	"ctrl" => $TCA["sys_filemounts"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,hidden,path,base"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => "LABEL:",
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"max" => "30",
				"eval" => "required,trim"
			)
		),
		"path" => Array (
			"label" => "PATH:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "120",
				"eval" => "required,trim"
			)
		),
		"hidden" => Array (
			"label" => "Disable:",
			"config" => Array (
				"type" => "check"
			)
		),
		"base" => Array (
			"label" => "BASE",
			"config" => Array (
				"type" => "radio",
				"items" => Array (
					Array("absolute (root) / ", 0),
					Array("relative ../fileadmin/", 1)
				),
				"default" => 0
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "hidden;;;;1-1-1,title;;;;3-3-3,path,base")
	)
);





// ******************************************************************
// sys_domain
// ******************************************************************
$TCA["sys_domain"] = Array (
	"ctrl" => $TCA["sys_domain"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "hidden,domainName,redirectTo"
	),
	"columns" => Array (	
		"domainName" => Array (
			"label" => "Domain:|Dom�ne:|Domain:|Domene:|Dominio:|Domaine:|Dominio:|Domein:|Dom�na:|Domena:|Domena:|Domain:|Alan ad�:",
			"config" => Array (
				"type" => "input",	
				"size" => "35",
				"max" => "80",
				"eval" => "required,unique,lower,trim"
			)
		),
		"redirectTo" => Array (
			"label" => "Redirect to:|Henvisning til:|Umleiten zu:|Henvisning til:|Redirigi a:|Rediriger vers:|Redirigir a:|Doorsturen naar:|P�esm�rovat na:|Przekieruj do:|Preusmeri na:|Edelleen v�lit�|Tekrar y�nlendir:",
			"config" => Array (
				"type" => "input",	
				"size" => "35",
				"max" => "120",
				"checkbox" => "",
				"default" => "",
				"eval" => "trim"
			)
		),
		"hidden" => Array (
			"label" => $LANG_GENERAL_LABELS["disable"],
			"exclude" => 1,	
			"config" => Array (
				"type" => "check",
				"default" => "0"
			)
		)
	),
	"types" => Array (					
		"1" => Array("showitem" => "hidden;;;;1-1-1,domainName;;1;;3-3-3")
	),
	"palettes" => Array (					
		"1" => Array("showitem" => "redirectTo")
	)
);






// ******************************************************************
// This is the standard TypoScript Note table , sys_note
// ******************************************************************
$TCA["sys_note"] = Array (
	"ctrl" => $TCA["sys_note"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "category,subject,message,author,email,personal"
	),
	"columns" => Array (	
		"category" => Array (
			"label" => $LANG_GENERAL_LABELS["category"],
			"config" => Array (
				"type" => "select",		
				"items" => Array (	
					Array("", "0"),
					Array("Instructions|Vejledning|Anweisung|Veiledning|Istruzioni|Insctructions|Instructies|Instructies|Instrukce|Instrukcje|Navodila|Ohjeet|K�lavuz", "1"),
					Array("Notes|Noter|Notiz|Notis|Note|Notes|Notas|Opmerkingen|Pozn�mky|Notatki|Opombe|Muistiot|Notlar", "3"),
					Array("To-do|To-do|To-do|Oppgave|Da fare|A Faire|Por hacer|Te-Doen|�koly|Zadanie|Naloge|To-Do|Yap�lacak i�ler", "4"),
					Array("Template|Skabelon|Template|Mal|Template|Gabarit||Template|�ablona|Szablon|Predloga|Malli|�ablon", "2")
				),
				"default" => "0"
			)
		),
		"subject" => Array (
			"label" => "Subject:|Emne:|Titel:|Emne:|Soggetto:|Sujet:|Asunto:|Onderwerp:|P�edm�t:|Temat:|Predmet:|Asia:|Konu:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"max" => "256"
			)
		),
		"message" => Array (
			"label" => "Message:|Indhold:|Inhalt:|Innhold:|Messaggio:|Message:|Mensaje:|Bericht:|Zpr�va:|Wiadomo��:|Sporo�ilo:|Viesti:|Mesaj:",
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "15"
			)
		),
		"author" => Array (
			"label" => $LANG_GENERAL_LABELS["author"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"email" => Array (
			"label" => $LANG_GENERAL_LABELS["email"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"personal" => Array (
			"label" => "Personal:|Personlig:|Pers�nlich:|Personlig:|Personale:|Personnel:|Personal:|Persoonlijk:|Osobn�:|Prywatna:|Osebno:|Henkil�kohtainen:|Ki�isel:",
			"config" => Array (
				"type" => "check"
			)
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "category;;;;2-2-2, author, email, personal, subject;;;;3-3-3, message")
	)
);






// ******************************************************************
// Static file edit table
// ******************************************************************
$TCA["sys_staticfile_edit"] = Array (
	"ctrl" => $TCA["sys_staticfile_edit"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => ""
	),
	"columns" => Array (	
		"edit_file" => Array (
			"exclude" => 1,	
			"label" => "File to be edited:|Fil, som skal redigeres:|Zu bearbeitende Datei:|Fil som skal redigeres:|File ma modificare:|Fichier � �diter:|Archivo para ser editado:|Te bewerken bestand:||Plik do edycji:|Uredi datoteko:|Muokattav tiedosto:|D�zenlenmi� olan dosyaya:",
			"config" => Array (
				"type" => "input",
				"size" => "40",
				"eval" => "trim,required",
				"max" => "256"
			)
		),
		"edit_content" => Array (
			"label" => "Content:|Indhold:|Inhalt:|Innhold:|Contenuto:|Contenu:|Contenido:|Inhoud:||Tre��:|Vsebina:|Sis�lt�:|��erik:",
			"config" => Array (
				"type" => "text",
				"cols" => "40",	
				"rows" => "15"
			)
		),
		"edit_subpart_marker" => Array (
			"exclude" => 1,	
			"label" => "Alternative Subpart marker:|Alternativ sektionsmark�r:|Alternative Abschnittsmarkierung:|Alternativ seksjonsmark�r:|Subpart marker alternativo:||Marcador alternativo de la subparte:|Alternatieve Subpart marker:||Znacznik tre�ci alternatywnej:|Alternativna ozna�itev posameznega dela:|Vaihtoehtoinen osan merkki:|Alternatif Altb�l�m i�aret�isi:",
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"always_reload" => Array (
			"exclude" => 1,	
			"label" => "Always reload content from file:|Hent altid indhold fra fil:|Inhalt immer aus Datei neu laden:|Hent alltid innhold fra fil:|Ricarica sempre il contenuto dal file:|Toujours recharger le contenu depuis le fichier:|Siempre recargar el contenido desde el archivo:|Altijd inhoud vanuit bestand herladen:||Zawsze od�wie� tre�� z pliku:|Zmeraj osve�i vsebino iz datoteke:|Lataa sis�lt� aina tiedostosta:|Herzaman i�eri�i dosyadan y�kle:",
			"config" => Array (
				"type" => "check"
			)
		),
		"rte_enabled" => Array (
			"exclude" => 1,
			"label" => $LANG_GENERAL_LABELS["disableRTE"],
			"config" => Array (
				"type" => "check",
				"showIfRTE" => 1
			)
		),
		"update_status" => Array (	
			"label" => "Update status:|Opdateringsstatus:|Aktualisierungsstatus:|Oppdateringsstatus:|Stato aggiornamento:|Etat de la mise � jour:|Actualizar estado:|Meest recente status:||Status aktualizacji:|Status osve�itve:|P�ivityksen tila:|G�ncel stat�ler:",
			"config" => Array ("type" => "none")
		)
	),
	"types" => Array (	
		"0" => Array("showitem" => "edit_file;;1;;2-2-2,
			edit_content;;;nowrap:richtext[*]:rte_transform[flag=rte_enabled|mode=ts_images-ts_reglinks]:static_write[edit_file|edit_content|edit_subpart_marker|always_reload|update_status];3-3-3,
			rte_enabled,update_status;;;;5-5-5")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "edit_subpart_marker,always_reload")
	)
);






// ******************************************************************
// pages_language_overlay
// ******************************************************************
$TCA["pages_language_overlay"] = Array (
	"ctrl" => $TCA["pages_language_overlay"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,hidden,starttime,endtime,keywords,description,abstract"
	),
	"columns" => Array (	
		"hidden" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["hidden"],
			"config" => Array (
				"type" => "check",
				"default" => "1"
			)
		),
		"starttime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["starttime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"exclude" => 1,	
			"label" => $LANG_GENERAL_LABELS["endtime"],
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"title" => Array (
			"label" => $TCA["pages"]["columns"]["title"]["label"],
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"max" => "256",
				"eval" => "required"
			)
		),
		"subtitle" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["subtitle"]["label"],
			"config" => Array (
				"type" => "input",	
				"size" => "30",
				"max" => "256",
				"eval" => ""
			)
		),
		"keywords" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["keywords"]["label"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"description" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["description"]["label"],
			"config" => Array (
				"type" => "input",		
				"size" => "40",
				"eval" => "trim"
			)
		),
		"abstract" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["abstract"]["label"],
			"config" => Array (
				"type" => "text",
				"cols" => "40",
				"rows" => "3"
			)
		),
		"author" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["author"]["label"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"author_email" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["author"]["label"],
			"config" => Array (
				"type" => "input",
				"size" => "20",
				"eval" => "trim",
				"max" => "80"
			)
		),
		"media" => Array (
			"exclude" => 1,	
			"label" => $TCA["pages"]["columns"]["media"]["label"],
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $TCA["pages"]["columns"]["media"]["config"]["allowed"],
				"max_size" => "2000",
				"uploadfolder" => "uploads/media",
				"show_thumbs" => "1",
				"size" => "3",
				"maxitems" => "5",
				"minitems" => "0"
			)
		),
		"sys_language_uid" => Array (
			"label" => $LANG_GENERAL_LABELS["language"],
			"config" => Array (
				"type" => "select",
				"foreign_table" => "sys_language",
				"foreign_table_where" => "ORDER BY sys_language.title",
				"items" => Array(
					Array($LANG_GENERAL_LABELS["default_value"],0)
				)
			)
		)		
	),
	"types" => Array (					
		"0" => Array("showitem" => "hidden;;;;1-1-1, sys_language_uid, title;;;;2-2-2, subtitle, --div--, abstract;;5;;3-3-3, keywords, description, media;;;;4-4-4")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "starttime,endtime"),
		"5" => Array("showitem" => "author,author_email")
	)
);







// ******************************************************************
// sys_action
// ******************************************************************
$TCA["sys_action"] = Array (
	"ctrl" => $TCA["sys_action"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "hidden,title,type,description,assign_to_groups"
	),
	"columns" => Array (	
		"title" => Array (
			"label" =>  $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",	
				"size" => "25",
				"max" => "256",
				"eval" => "trim,required"
			)
		),
		"description" => Array (
			"label" => $LANG_GENERAL_LABELS["description"],
			"config" => Array (
				"type" => "text",
				"rows" => 10,
				"cols" => 48
			)
		),
		"hidden" => Array (
			"label" => "Deactivated:",
			"config" => Array (
				"type" => "check"
			)
		),
		"type" => Array (
			"label" => $LANG_GENERAL_LABELS["type"],
			"config" => Array (
				"type" => "select",	
				"items" => Array (	
					Array("", "0"),
					Array("Create Backend User", "1"),
					Array("SQL-query", "2"),
					Array("Record list", "3"),
					Array("Edit records", "4")
				)
			)
		),
		"assign_to_groups" => Array (
			"label" => "Assign action to groups:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "be_groups",
				"foreign_table_where" => "ORDER BY be_groups.title",
				"MM" => "sys_action_asgr_mm",
				"size" => "5",
				"minitems" => "0",
				"maxitems" => "200"
			)
		),		
		"t1_userprefix" => Array (
			"label" =>  "User prefix:",
			"config" => Array (
				"type" => "input",	
				"size" => "25",
				"max" => "10",
				"eval" => "trim"
			)
		),
		"t1_allowed_groups" => Array (
			"label" => "Groups which may be assigned through the action:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "be_groups",
				"foreign_table_where" => "ORDER BY be_groups.title",
				"size" => "2",
				"maxitems" => "20"
			)
		),
		"t1_create_user_dir" => Array (
			"label" => "Create User Home Directory:",
			"config" => Array (
				"type" => "check"
			)
		),
		"t1_copy_of_user" => Array (
			"label" => "Template user:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "be_users",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "1",
				"show_thumbs" => "1"
			)
		),


		"t3_listPid" => Array (
			"label" => "List pid:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "pages",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "1",
				"show_thumbs" => "1"
			)
		),
		"t3_tables" => Array (
			"label" => "List only table:",
			"config" => Array (
				"type" => "select",
				"special" => "tables",
				"items" => Array (
					Array("","")
				)
			)
		),
		"t4_recordsToEdit" => Array (
			"label" => "Records to edit:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "*",
				"prepend_tname" => 1,
				"size" => "5",
				"maxitems" => "50",
				"minitems" => "1",
				"show_thumbs" => "1"
			)
		),
		
	),
	"types" => Array (					
		"0" => Array("showitem" => "hidden;;;;1-1-1,type,title;;;;2-2-2"),
		"1" => Array("showitem" => "hidden;;;;1-1-1,type,title;;;;2-2-2,description;;;;3-3-3,assign_to_groups,--div--,t1_userprefix;;;;5-5-5,t1_copy_of_user,t1_allowed_groups,t1_create_user_dir"),
		"2" => Array("showitem" => "hidden;;;;1-1-1,type,title;;;;2-2-2,description;;;;3-3-3,assign_to_groups,--div--,"),
		"3" => Array("showitem" => "hidden;;;;1-1-1,type,title;;;;2-2-2,description;;;;3-3-3,assign_to_groups,--div--,t3_listPid;;;;5-5-5,t3_tables"),
		"4" => Array("showitem" => "hidden;;;;1-1-1,type,title;;;;2-2-2,description;;;;3-3-3,assign_to_groups,--div--,t4_recordsToEdit;;;;5-5-5")
	)
);






// ******************************************************************
// sys_workflows
// ******************************************************************
$TCA["sys_workflows"] = Array (
	"ctrl" => $TCA["sys_workflows"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,description,tablename,working_area,allowed_groups,review_users,final_target,final_unhide,final_set_perms"
	),
	"columns" => Array (	
		"title" => Array (
			"label" =>  $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",	
				"size" => "25",
				"max" => "256",
				"eval" => "trim,required"
			)
		),
		"description" => Array (
			"label" => $LANG_GENERAL_LABELS["description"],
			"config" => Array (
				"type" => "text",
				"rows" => 10,
				"cols" => 48
			)
		),
		"hidden" => Array (
			"label" => "Deactivated:",
			"config" => Array (
				"type" => "check"
			)
		),
		"tablename" => Array (
			"label" => "Table:",
			"config" => Array (
				"type" => "select",
				"special" => "tables",
				"size" => "1",
				"items" => Array(
					Array("","")
				)
			)
		),
		"working_area" => Array (
			"label" => "Draft page:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "pages",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "1",
				"show_thumbs" => "1"
			)
		),
		"allowed_groups" => Array (
			"label" => "Groups allowed to assign workflow:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "be_groups",
				"foreign_table_where" => "ORDER BY be_groups.title",
				"MM" => "sys_workflows_algr_mm",
				"size" => "3",
				"maxitems" => "20"
			)
		),
		"target_groups" => Array (
			"label" => "Target groups for workflow:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "be_groups",
				"foreign_table_where" => "ORDER BY be_groups.title",
				"size" => "3",
				"maxitems" => "20"
			)
		),
		"review_users" => Array (
			"label" => "Review users:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "be_users",
				"MM" => "sys_workflows_rvuser_mm",
				"size" => "3",
				"maxitems" => "200",
				"minitems" => "0",
				"show_thumbs" => "1"
			)
		),		
		"final_unhide" => Array (
			"label" => "Unhide when finalizing:",
			"config" => Array (
				"type" => "check"
			)
		),
		"final_set_perms" => Array (
			"label" => "Set permissions when finalizing (\'page\' only):",
			"config" => Array (
				"type" => "check"
			)
		),
		"final_target" => Array (
			"label" => "Move to page when finalizing:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "pages",
				"size" => "3",
				"maxitems" => "1",
				"minitems" => "1",
				"show_thumbs" => "1"
			)
		),
		"final_perms_userid" => Array (
			"label" => "Owner User:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "be_users",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "0"
			)
		),		
		"final_perms_groupid" => Array (
			"label" => "Owner Group:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "be_groups",
				"foreign_table_where" => "ORDER BY be_groups.title",
				"items" => Array(
					Array("","")
				)
			)
		),		
		"final_perms_user" => Array (
			"exclude" => 1,
			"label" => "Owner User Access:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Show page", ""),
					Array("Edit page", ""),
					Array("Delete page", ""),
					Array("New pages", ""),
					Array("Edit content", "")
				),
				"cols" => 5
			)
		),
		"final_perms_group" => Array (
			"exclude" => 1,
			"label" => "Owner Group Access:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Show page", ""),
					Array("Edit page", ""),
					Array("Delete page", ""),
					Array("New pages", ""),
					Array("Edit content", "")
				),
				"cols" => 5
			)
		),
		"final_perms_everybody" => Array (
			"exclude" => 1,
			"label" => "Everybody Access:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Show page", ""),
					Array("Edit page", ""),
					Array("Delete page", ""),
					Array("New pages", ""),
					Array("Edit content", "")
				),
				"cols" => 5
			)
		)
	),
	"types" => Array (					
		"0" => Array("showitem" => "hidden;;;;1-1-1,title;;;;2-2-2,description,tablename;;;;3-3-3,working_area,allowed_groups,target_groups,review_users,--div--,final_target;;;;5-5-5,final_unhide,final_set_perms;;;;5-5-5"),
		"1" => Array("showitem" => "hidden;;;;1-1-1,title;;;;2-2-2,description,tablename;;;;3-3-3,working_area,allowed_groups,target_groups,review_users,--div--,final_target;;;;5-5-5,final_unhide,final_set_perms;;;;5-5-5,final_perms_userid,final_perms_groupid,final_perms_user,final_perms_group,final_perms_everybody")
	)
);






// ******************************************************************
// sys_language
// ******************************************************************
$TCA["sys_language"] = Array (
	"ctrl" => $TCA["sys_language"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "hidden,title"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["language"],
			"config" => Array (
				"type" => "input",	
				"size" => "35",
				"max" => "80",
				"eval" => "trim,required"
			)
		),
		"hidden" => Array (
			"label" => $LANG_GENERAL_LABELS["disable"],
			"exclude" => 1,	
			"config" => Array (
				"type" => "check",
				"default" => "0"
			)
		)
	),
	"types" => Array (					
		"1" => Array("showitem" => "hidden;;;;1-1-1,title;;;;2-2-2")
	)
);





// ******************************************************************
// sys_dc
// ******************************************************************
$TCA["sys_dc"] = Array (
	"ctrl" => $TCA["sys_dc"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "hidden,title"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => $LANG_GENERAL_LABELS["title"],
			"config" => Array (
				"type" => "input",	
				"size" => "35",
				"max" => "80",
				"eval" => "trim,required"
			)
		),
		"description" => Array (
			"label" => $LANG_GENERAL_LABELS["description"],
			"config" => Array (
				"type" => "text",
				"rows" => 5,
				"cols" => 48
			)
		),
		"tmpl_a_content" => Array (
			"label" => "Template content:|Skabelonindhold:|Template Inhalt:|Mal-innhold:||||Sjabloon inhoud:||Zawarto�� Szablonu:||Mallinteen sis�lt�:|�ablon i�eri�i:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"tmpl_b_content" => Array (
			"label" => "Template content:|Skabelonindhold:|Template Inhalt:|Mal-innhold:||||Sjabloon inhoud:||Zawarto�� Szablonu:||Mallinteen sis�lt�:|�ablon i�eri�i:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"tmpl_c_content" => Array (
			"label" => "Template content:|Skabelonindhold:|Template Inhalt:|Mal-innhold:||||Sjabloon inhoud:||Zawarto�� Szablonu:||Mallinteen sis�lt�:|�ablon i�eri�i:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"component_type" => Array (
			"label" => "Component Type:|Komponenttype:|Komponenten Typ:|Komponenttype:||||Component type:||Typ Komponentu:||Sis�lt� Yyyppi:|Unsur T�r�:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "sys_dc_type",
				"foreign_table_where" => "ORDER BY sys_dc_type.title",
				"neg_foreign_table" => "static_dc_type",
				"neg_foreign_table_where" => "ORDER BY static_dc_type.title",
				"neg_foreign_table_prefix" => "STATIC: |STATISK: ",
				"size" => 1,
				"default" => "",
				"items" => Array(
					Array("",0)
				)
			)
		),
		"hidden" => Array (
			"label" => $LANG_GENERAL_LABELS["disable"],
			"exclude" => 1,	
			"config" => Array (
				"type" => "check",
				"default" => "0"
			)
		)
	),
	"types" => Array (					
		"0" => Array("showitem" => "title;;1;;2-2-2, component_type, description"),
		"-1" => Array("showitem" => "title;;1;;2-2-2, component_type, description, tmpl_a_content;
			Guestbook template:|G�stebogsskabelon:|G�stebuch Template:|Gjestebok mal:||||Gastenboek sjabloon:||Szablon Ksi�gi Go�ci:||Ilmoitustaulun mallinne:|Ziyaret�i defteri �ablonu:
			;;;3-3-3")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "hidden"),
	)
);





// ******************************************************************
// static_dc_type
// ******************************************************************
$TCA["static_dc_type"] = Array (
	"ctrl" => $TCA["static_dc_type"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "hidden,title"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => "Title:",
			"config" => Array (
				"type" => "input",	
				"size" => "35",
				"max" => "80",
				"eval" => "trim,required"
			)
		),
		"description" => Array (
			"label" => "General Description:",
			"config" => Array (
				"type" => "text",
				"rows" => 5,
				"cols" => 48
			)
		),
		"active" => Array (
			"label" => "Active:",
			"config" => Array (
				"type" => "check",
				"items" => array(
					Array("1",""),
					Array("2",""),
					Array("3",""),
//					Array("4",""),
				),
				"cols" => 4
			)
		),
		"tmpl_a_subpart_marker" => Array (
			"label" => "Subpart marker:",
			"config" => Array (
				"type" => "input",	
				"max" => "80",
			)
		),
		"tmpl_a_description" => Array (
			"label" => "Help text:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => 5
			)
		),
		"tmpl_a_content" => Array (
			"label" => "Template content:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"tmpl_a_TSconfig" => Array (
			"label" => "RTE TS config:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "5",
				"wrap" => "OFF"
			)
		),

		
		"tmpl_b_subpart_marker" => Array (
			"label" => "Subpart marker:",
			"config" => Array (
				"type" => "input",	
				"max" => "80",
			)
		),
		"tmpl_b_description" => Array (
			"label" => "Help text:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => 5
			)
		),
		"tmpl_b_content" => Array (
			"label" => "Template content:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"tmpl_b_TSconfig" => Array (
			"label" => "RTE TS config:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "5",
				"wrap" => "OFF"
			)
		),

		
		"tmpl_c_subpart_marker" => Array (
			"label" => "Subpart marker:",
			"config" => Array (
				"type" => "input",	
				"max" => "80",
			)
		),
		"tmpl_c_description" => Array (
			"label" => "Help text:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => 5
			)
		),
		"tmpl_c_content" => Array (
			"label" => "Template content:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"tmpl_c_TSconfig" => Array (
			"label" => "RTE TS config:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "5",
				"wrap" => "OFF"
			)
		),

		
		
	),
	"types" => Array (					
		"1" => Array(
			"showitem" => "title;;;;2-2-2, description, active,
				, tmpl_a_subpart_marker;;;;3-3-3, tmpl_a_description, tmpl_a_content, tmpl_a_TSconfig
				, tmpl_b_subpart_marker;;;;3-3-3, tmpl_b_description, tmpl_b_content, tmpl_b_TSconfig
				, tmpl_c_subpart_marker;;;;3-3-3, tmpl_c_description, tmpl_c_content, tmpl_c_TSconfig
				",
			"bitmask_value_field" => "active",
			"bitmask_excludelist_bits" => Array (
				"-0" => "tmpl_a_subpart_marker,tmpl_a_description,tmpl_a_content,tmpl_a_TSconfig",
				"-1" => "tmpl_b_subpart_marker,tmpl_b_description,tmpl_b_content,tmpl_b_TSconfig",
				"-2" => "tmpl_c_subpart_marker,tmpl_c_description,tmpl_c_content,tmpl_c_TSconfig"
			)
		)
	)
);




$TCA["sys_dc_type"]=array_merge(
	$TCA["static_dc_type"],
	array("ctrl"=>$TCA["sys_dc_type"]["ctrl"])
);



// ******************************************************************
// sys_template
// ******************************************************************
$TCA["sys_template"] = Array (
	"ctrl" => $TCA["sys_template"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,clear,root,include_static,basedOn,nextLevel,resources,sitetitle,description,hidden,starttime,endtime"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => "Template title:",
			"config" => Array (
				"type" => "input",	
				"size" => "25",
				"max" => "256",
				"eval" => "required"
			)
		),
		"hidden" => Array (
			"label" => "Deactivated:",
			"exclude" => 1,	
			"config" => Array (
				"type" => "check",
				"default" => "0"
			)
		),
		"starttime" => Array (
			"label" => "Start:",
			"exclude" => 1,	
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0"
			)
		),
		"endtime" => Array (
			"label" => "Stop:",
			"exclude" => 1,	
			"config" => Array (
				"type" => "input",
				"size" => "8",
				"max" => "20",
				"eval" => "date",
				"checkbox" => "0",
				"default" => "0",
				"range" => Array (
					"upper" => mktime(0,0,0,12,31,2020),
					"lower" => mktime(0,0,0,date("m")-1,date("d"),date("Y"))
				)
			)
		),
		"root" => Array (
			"label" => "Rootlevel:",
			"config" => Array (
				"type" => "check"
			)
		),
		"clear" => Array (
			"label" => "Clear:",
			"config" => Array (
				"type" => "check",
				"items" => Array (	
					Array("Constants", ""),
					Array("Setup", "")
				),
				"cols" => 2
			)
		),
		"sitetitle" => Array (
			"label" => "Website title:",
			"config" => Array (
				"type" => "input",	
				"size" => "25",
				"max" => "256"
			)
		),
		"constants" => Array (
			"label" => "Constants:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"resources" => Array (
			"label" => "Resources:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "file",
				"allowed" => $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"].",html,htm,ttf,txt,css,tmpl,inc,ico",
				"max_size" => "1000",
				"uploadfolder" => "uploads/tf",
				"show_thumbs" => "1",
				"size" => "7",
				"maxitems" => "100",
				"minitems" => "0"
			)
		),
		"nextLevel" => Array (
			"label" => "Template on next level:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "sys_template",
				"show_thumbs" => "1",
				"size" => "1",
				"maxitems" => "1",
				"minitems" => "0",
				"default" => ""
			)
		),
		"include_static" => Array (
			"label" => "Include static:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "static_template",
				"foreign_table_where" => "ORDER BY static_template.title DESC",
				"size" => 10,
				"maxitems" => 20,
				"default" => ""
			)
		),
		"basedOn" => Array (
			"label" => "Include basis template:",
			"config" => Array (
				"type" => "group",
				"internal_type" => "db",
				"allowed" => "sys_template",
				"show_thumbs" => "1",
				"size" => "1",
				"maxitems" => "50",
				"minitems" => "0",
				"default" => ""
			)
		),
		"includeStaticAfterBasedOn" => Array (
			"label" => "Include static AFTER basedOn:",
			"exclude" => 1,	
			"config" => Array (
				"type" => "check",
				"default" => "0"
			)
		),
		"config" => Array (
			"label" => "Setup:",
			"config" => Array (
				"type" => "text",
				"rows" => 10,
				"cols" => 48,
				"wizards" => Array(
					"_PADDING" => 4,
					"0" => Array(
						"type" => "popup",
						"title" => "TSref online",
						"script" => "wizard_tsconfig.php?mode=tsref",
						"icon" => "wizard_tsconfig.gif",
						"JSopenParams" => "height=500,width=780,status=0,menubar=0,scrollbars=1",
					)
				),
				"wrap" => "OFF"
			)
		),
		"description" => Array (
			"label" => "Description:",
			"config" => Array (
				"type" => "text",
				"rows" => 10,
				"cols" => 48
			)
		)
	),
	"types" => Array (					
		"1" => Array("showitem" => "title;;1;;2-2-2, sitetitle, constants;;;;3-3-3, config, resources, clear, root, --div--, include_static;;2;;5-5-5, basedOn;;2, nextLevel, --div--, description;;;;5-5-5")
	),
	"palettes" => Array (
		"1" => Array("showitem" => "hidden,starttime,endtime"),
		"2" => Array("showitem" => "includeStaticAfterBasedOn")
	)
);





// ******************************************************************
// static_template
// ******************************************************************
$TCA["static_template"] = Array (
	"ctrl" => $TCA["static_template"]["ctrl"],
	"interface" => Array (
		"showRecordFieldList" => "title,include_static,description"
	),
	"columns" => Array (	
		"title" => Array (
			"label" => "Template title:",
			"config" => Array (
				"type" => "input",	
				"size" => "25",
				"max" => "256",
				"eval" => "required"
			)
		),
		"constants" => Array (
			"label" => "Constants:",
			"config" => Array (
				"type" => "text",
				"cols" => "48",
				"rows" => "10",
				"wrap" => "OFF"
			)
		),
		"include_static" => Array (
			"label" => "Include static:",
			"config" => Array (
				"type" => "select",
				"foreign_table" => "static_template",
				"foreign_table_where" => "ORDER BY static_template.title",
				"size" => 10,
				"maxitems" => 20,
				"default" => ""
			)
		),
		"config" => Array (
			"label" => "Setup:",
			"config" => Array (
				"type" => "text",
				"rows" => 10,
				"cols" => 48,
				"wrap" => "OFF"
			)
		),
		"description" => Array (
			"label" => "Description:",
			"config" => Array (
				"type" => "text",
				"rows" => 10,
				"cols" => 48
			)
		)
	),
	"types" => Array (					
		"1" => Array("showitem" => "title;;;;2-2-2, constants;;;;3-3-3, config, include_static;;;;5-5-5, description;;;;5-5-5")
	)
);



?>