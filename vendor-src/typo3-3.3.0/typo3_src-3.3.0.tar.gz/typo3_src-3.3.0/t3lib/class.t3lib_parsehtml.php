<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license
*  from the author is found in LICENSE.txt distributed with these scripts.
*
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * Functions for parsing HTML
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_parsehtml {
	var $caseShift_cache=array();

	// *******************************************'
	// COPY FROM class.tslib_content.php: / BEGIN
	// substituteSubpart 
	// *******************************************'
	function getSubpart($content, $marker)	{
		if ($marker && strstr($content,$marker))	{
			$start = strpos($content, $marker)+strlen($marker);
			$stop = @strpos($content, $marker, $start+1);
			$sub = substr($content, $start, $stop-$start);
	
			$reg=Array();		
			ereg("^[^<]*-->",$sub,$reg);
			$start+=strlen($reg[0]);
			
			$reg=Array();		
			ereg("<!--[^>]*$",$sub,$reg);
			$stop-=strlen($reg[0]);
			
			return substr($content, $start, $stop-$start);
		}
	}
	function substituteSubpart($content,$marker,$subpartContent,$recursive=1,$keepMarker=0)	{
			// This function substitutes a subpart in $content with the content of $subpartContent.
			// If $recursive is set, the function calls itself with the content set to the remaining part of the content after the second marker. This means that proceding subparts are ALSO substituted!
			// If $subpartContent happens to be an array, it's [0] and [1] elements are wrapped around the content of the subpart (fetched by getSubpart())
		$start = strpos($content, $marker);
		$stop = @strpos($content, $marker, $start+1)+strlen($marker);
		if ($start && $stop>$start)	{
/*			if ($keepMarker)	{
				$start+=strlen($marker);
				$stop-=strlen($marker);
					// code before
				$before = substr($content, $start);
				$reg=Array();		
				ereg("^[^<]*-->",$before,$reg);
				$start+=strlen($reg[0]);
				$before = substr($content, 0, $start);
					// code after
				$after = substr($content, 0, $stop);
				$reg=Array();		
				ereg("<!--[^>]*$",$after,$reg);
				$stop-=strlen($reg[0]);
				$after = substr($content, $stop);
				
				debug(array($before,$after));
			} else {
	*/				// code before
				$before = substr($content, 0, $start);
				$reg=Array();		
				ereg("<!--[^>]*$",$before,$reg);
				$start-=strlen($reg[0]);
				if ($keepMarker)	{
					$reg_k=Array();
					if ($reg[0])	ereg("^[^>]*-->",substr($content,$start),$reg_k);
					$before_marker = substr($content, $start, strlen($reg_k[0]?$reg_k[0]:$marker));
				}
				$before = substr($content, 0, $start);
					// code after
				$after = substr($content, $stop);
				$reg=Array();		
				ereg("^[^<]*-->",$after,$reg);
				$stop+=strlen($reg[0]);
				if ($keepMarker)	{
					$reg_k=Array();
					if ($reg[0])	ereg("<!--[^<]*$",substr($content,0,$stop),$reg_k);
					$sLen = strlen($reg_k[0]?$reg_k[0]:$marker);
					$after_marker = substr($content, $stop-$sLen,$sLen);
				}
				$after = substr($content, $stop);
//			}	

			
				// replace?
			if (is_array($subpartContent))	{
				$substContent=$subpartContent[0].$this->getSubpart($content,$marker).$subpartContent[1];
			} else {
				$substContent=$subpartContent;
			}

			if ($recursive && strpos($after, $marker))	{
				return $before.($keepMarker?$before_marker:"").$substContent.($keepMarker?$after_marker:"").$this->substituteSubpart($after,$marker,$subpartContent);
			} else {
				return $before.($keepMarker?$before_marker:"").$substContent.($keepMarker?$after_marker:"").$after;
			}
		} else {
			return $content;
		}
	}
	// *******************************************'
	// COPY FROM class.tslib_content.php: / END
	// *******************************************'










	/**
	 * Returns an array with the $content divided by tag-blocks specified with the list of tags, $tag
	 * Even numbers in the array are outside the blocks, Odd numbers are block-content. 
	 * Use ->getAllParts() and ->removeFirstAndLastTag() to process the content if needed.
	 */
	function splitIntoBlock($tag,$content,$eliminateExtraEndTags=0)	{
		$tags=array_unique(t3lib_div::trimExplode(",",$tag,1));
/*		$regEx=array();
		$regEx[]="<(".implode("|",$tags).")>";
		$regEx[]="<(".implode("|",$tags).")[[:space:]][^>]*>";
		$regEx[]="<\/(".implode("|",$tags).")[[:space:]]*>";
*/
//		$regexStr = implode("|",$regEx);
		$regexStr = "</?(".implode("|",$tags).")(>|[[:space:]][^>]*>)";
//debug($regexStr);

		$parts = spliti($regexStr,$content);
//		debug(implode("|",$regEx));
//		debug($parts);
		
		$newParts=array();
		$pointer=strlen($parts[0]);
		$buffer=$parts[0];
		$nested=0;
		reset($parts);
		next($parts);
		while(list($k,$v)=each($parts))	{
			$isEndTag= substr($content,$pointer,2)=="</" ? 1 : 0;
//			$tagLen = ($isEndTag?2:1)+strlen($tag);
			$tagLen = strcspn(substr($content,$pointer),">")+1;

//			debug($isEndTag);
//			debug(substr($content,$pointer,$tagLen),1);
			if (!$isEndTag)	{	// We meet a start-tag:
				if (!$nested)	{	// Ground level:
					$newParts[]=$buffer;	// previous buffer stored
					$buffer="";
				}
				$nested++;	// We are inside now!
				$mbuffer=substr($content,$pointer,strlen($v)+$tagLen);	// New buffer set and pointer increased
				$pointer+=strlen($mbuffer);
				$buffer.=$mbuffer;
			} else {	// If we meet an endtag:
//				debug($pointer);
				$nested--;	// decrease nested-level
				$eliminated=0;
				if ($eliminateExtraEndTags && $nested<0)	{
					$nested=0;
					$eliminated=1;
				} else {
					$buffer.=substr($content,$pointer,$tagLen);	// In any case, add the endtag to current buffer and increase pointer
				}
				$pointer+=$tagLen;
				if (!$nested && !$eliminated)	{	// if we're back on ground level, (and not by eliminating tags...
					$newParts[]=$buffer;
					$buffer="";
				}
				$mbuffer=substr($content,$pointer,strlen($v));	// New buffer set and pointer increased
				$pointer+=strlen($mbuffer);
				$buffer.=$mbuffer;
//				debug($pointer);
			}
			
		}
		$newParts[]=$buffer;
//		debug($newParts);
		return $newParts;
	}

	/**
	 * Returns an array with the $content divided by tag-blocks specified with the list of tags, $tag
	 * Even numbers in the array are outside the blocks, Odd numbers are block-content. 
	 * Use ->getAllParts() and ->removeFirstAndLastTag() to process the content if needed.
	 */
	function splitTags($tag,$content)	{
		$tags=t3lib_div::trimExplode(",",$tag,1);
		$regexStr = "<(".implode("|",$tags).")(>|[[:space:]][^>]*>)";
		$parts = spliti($regexStr,$content);
		
		$pointer=strlen($parts[0]);
		$newParts=array();
		$newParts[]=$parts[0];
		reset($parts);
		next($parts);
		while(list($k,$v)=each($parts))	{
			$tagLen = strcspn(substr($content,$pointer),">")+1;

				// Set tag:
			$tag = substr($content,$pointer,$tagLen);	// New buffer set and pointer increased
			$newParts[]=$tag;
			$pointer+=strlen($tag);

				// Set content:
			$newParts[]=$v;
			$pointer+=strlen($v);
		}
		return $newParts;
	}

	/**
	 * Returns an array with either tag or non-tag content of the result from ->splitIntoBlock()
	 */
	function getAllParts($parts,$tag_parts=1,$include_tag=1)	{
		reset($parts);
		$newParts=array();
		while(list($k,$v)=each($parts))	{
			if (($k+($tag_parts?0:1))%2)	{
				if (!$include_tag)	$v=$this->removeFirstAndLastTag($v);
				$newParts[]=$v;
			}
		}
		return $newParts;
	}

	/**
	 * Removes the first and last tag in the string
	 * Anything before and after the first and last tags respectively is also removed
	 */
	function removeFirstAndLastTag($str)	{
			// First:
		$endLen = strcspn($str,">")+1;
		$str = substr($str,$endLen);
			// Last:
		$str = strrev($str);
		$endLen = strcspn($str,"<")+1;
		$str = substr($str,$endLen);
			// return
		return strrev($str);
	}

	/**
	 * Returns the first tag in $str
	 * Actually everything from the begining of the $str is returned, so you better make sure the tag is the first thing...
	 */
	function getFirstTag($str)	{
			// First:
		$endLen = strcspn($str,">")+1;
		$str = substr($str,0,$endLen);
		return $str;
	}

	/**
	 * Returns the NAME of the first tag in $str
	 * See ->getFirstTag()
	 */
	function getFirstTagName($str)	{
		list($tag) = explode(" ",substr(strtoupper(trim($this->getFirstTag($str))),1,-1));
		return $tag;
	}
	
	/**
	 * Cleans up the input $value for fonttags. 
	 * If keepFace,-Size and -Color is set then font-tags with an allowed property is kept. Else deleted.
	 */
	function cleanFontTags($value,$keepFace=0,$keepSize=0,$keepColor=0)	{
		$fontSplit = $this->splitIntoBlock("font",$value);	// ,1 ??
		reset($fontSplit);
		while(list($k,$v)=each($fontSplit))	{
			if ($k%2)	{	// font:
				$attribArray=$this->get_tag_attributes_classic($this->getFirstTag($v));
				$newAttribs=array();
				if ($keepFace && $attribArray["face"])	$newAttribs[]='face="'.$attribArray["face"].'"';
				if ($keepSize && $attribArray["size"])	$newAttribs[]='size="'.$attribArray["size"].'"';
				if ($keepColor && $attribArray["color"])	$newAttribs[]='color="'.$attribArray["color"].'"';
					
				$innerContent = $this->cleanFontTags($this->removeFirstAndLastTag($v),$keepFace,$keepSize,$keepColor);
				if (count($newAttribs))	{
					$fontSplit[$k]="<FONT ".implode(" ",$newAttribs).">".$innerContent."</FONT>";
				} else {
					$fontSplit[$k]=$innerContent;
				}
			}
		}
		return implode("",$fontSplit);
	}
	
	/**
	 * This is used to map certain tag-names into other names.
	 */
	function mapTags($value,$tags=array(),$ltChar="<",$ltChar2="<")	{
		reset($tags);
		while(list($from,$to)=each($tags))	{
			$value = eregi_replace($ltChar.$from.">",$ltChar2.$to.">",$value);
			$value = eregi_replace($ltChar.$from."[[:space:]]([^>]*)>",$ltChar2.$to." \\1>",$value);
			$value = eregi_replace($ltChar."\/".$from."[^>]*>",$ltChar2."/".$to.">",$value);
		}
		return $value;
	}

	/**
	 * Strips tags except the tags in the list, $tagList
	 */
	function stripTagsExcept($value,$tagList)	{
		$tags=t3lib_div::trimExplode(",",$tagList,1);
		$forthArr=array();
		$backArr=array();
		while(list(,$theTag)=each($tags))	{
			$forthArr[$theTag]=md5($theTag);
			$backArr[md5($theTag)]=$theTag;
		}
			$value = $this->mapTags($value,$forthArr,"<","_");
		//	debug($value,1);
			$value=strip_tags($value);
	//		debug($value,1);
			$value = $this->mapTags($value,$backArr,"_","<");
//			debug($value,1);
		return $value;
	}


	function unprotectTags($content,$tagList="")	{
		$tagsArray = t3lib_div::trimExplode(",",$tagList,1);
		$contentParts = explode("&lt;",$content);
		next($contentParts);	// bypass the first
		while(list($k,$tok)=each($contentParts))	{
			$firstChar = substr($tok,0,1);
			if (strcmp(trim($firstChar),""))	{
				$subparts = explode("&gt;",$tok,2);
				$tagEnd = strlen($subparts[0]);
				if (strlen($tok)!=$tagEnd)	{
					$endTag = $firstChar=="/" ? 1 : 0;
					$tagContent = substr($tok,$endTag,$tagEnd-$endTag);
					$tagParts = split("[[:space:]]",$tagContent,2);
					$tagName = strtolower($tagParts[0]);
					if (!strcmp($tagList,"") || in_array($tagName,$tagsArray))	{
						$contentParts[$k] = "<".$subparts[0].">".$subparts[1];
					} else $contentParts[$k] = "&lt;".$tok;
				} else $contentParts[$k] = "&lt;".$tok;
			} else $contentParts[$k] = "&lt;".$tok;
		}
		
		return implode("",$contentParts);
	}
	/*
	API for 
	HTMLcleaner($content, $tags=array(),$keepAll=0);
		$content; is the HTML-content being processed. This is also the result being returned.	
		$tags; is an array where each key is a tagname in lowercase. Only tags present as keys in this array is preserved. The value of the key can be an array with a vast number of options to configure.
		$keepAll; boolean/"protect", if set, then all tags are kept regardless of tags present as keys in $tags-array. If "protect" then the preserved tags have their <> converted to &lt; and &gt;

		Initializing the $tags array to allow a list of tags (in this case <B>,<I>,<U> and <A>), set it like this:		 $tags = array_flip(explode(",","b,a,i,u"))	
		If the value of the $tags[$tagname] entry is an array, advanced processing of the tags is initialized. These are the options:

		$tags[$tagname] = Array(
			"overrideAttribs" => ""		If set, this string is preset as the attributes of the tag
			"allowedAttribs" =>   '0' (zero) = no attributes allowed, '[commalist of attributes]' = only allowed attributes. If blank, all attributes are allowed.
			"fixAttrib" => Array(
				"[attribute name]" => Array (
					"default" => 	If no attribute exists by this name, this value is set as default value (if this value is not blank)
					"always" => 	Boolean. If set, the attribute is always processed. Normally an attribute is processed only if it exists
					"trim,intval,lower,upper" => 	All booleans. If any of these keys are set, the value is passed through the respective PHP-functions.
					"range" => Array ("[low limit]","[high limit, optional]")		Setting integer range. 
					"list" => Array ("[value1/default]","[value2]","[value3]")		Attribute must be in this list. If not, the value is set to the first element.
					"removeIfFalse" => 	Boolean/"blank".	If set, then the attribute is removed if it is "false". If this value is set to "blank" then the value must be a blank string (that means a "zero" value will not be removed)
					"removeIfEquals" => 	[value]	If the attribute value matches the value set here, then it is removed.
					"casesensitiveComp" => 1	If set, then the removeIfEquals and list comparisons will be case sensitive. Otherwise not.
				)
			),
			"protect" => "",	Boolean. If set, the tag <> is converted to &lt; and &gt;
			"remap" => "",		String. If set, the tagname is remapped to this tagname
			"rmTagIfNoAttrib" => "",	Boolean. If set, then the tag is removed if no attributes happend to be there.
			"nesting" => "",	Boolean/"global". If set true, then this tag must have starting and ending tags in the correct order. Any tags not in this order will be discarded. Thus '</B><B><I></B></I></B>' will be converted to '<B><I></B></I>'. Is the value "global" then true nesting in relation to other tags marked for "global" nesting control is preserved. This means that if <B> and <I> are set for global nesting then this string '</B><B><I></B></I></B>' is converted to '<B></B>'
		)
		
		
	
	*/
	function HTMLcleaner($content, $tags=array(),$keepAll=0,$hSC=0)	{
		$newContent = array();
//		$tok = strtok($content,"<");
		$tokArr = explode("<",$content);
		$newContent[]=$this->bidir_htmlspecialchars(current($tokArr),$hSC);
		next($tokArr);

		$c=1;
		$tagRegister=array();
		$tagStack=array();
//		while ($tok) {
		while(list(,$tok)=each($tokArr))	{
			$firstChar = substr($tok,0,1);
			if (strcmp(trim($firstChar),""))	{
				$tagEnd = strcspn($tok,">");
				if (strlen($tok)!=$tagEnd)	{
					$endTag = $firstChar=="/" ? 1 : 0;
					$tagContent = substr($tok,$endTag,$tagEnd-$endTag);
					$tagParts = split("[[:space:]]",$tagContent,2);
					$tagName = strtolower($tagParts[0]);
					if (isset($tags[$tagName]))	{
						if (is_array($tags[$tagName]))	{
								// Override attributes
							if (strcmp($tags[$tagName]["overrideAttribs"],""))	{
								$tagParts[1]=$tags[$tagName]["overrideAttribs"];
							}
						
								// Allowed tags
							if (strcmp($tags[$tagName]["allowedAttribs"],""))	{
								if (!strcmp($tags[$tagName]["allowedAttribs"],"0"))	{	// No attribs allowed
									$tagParts[1]="";
								} elseif (trim($tagParts[1])) {
									$tagAttrib = $this->get_tag_attributes($tagParts[1]);
									$tagParts[1]="";
									$newTagAttrib = array();
									$tList = t3lib_div::trimExplode(",",strtolower($tags[$tagName]["allowedAttribs"]),1);
									while(list(,$allowTag)=each($tList))	{
										if (isset($tagAttrib[0][$allowTag]))	$newTagAttrib[$allowTag]=$tagAttrib[0][$allowTag];
									}
									$tagParts[1]=$this->compileTagAttribs($newTagAttrib,$tagAttrib[1]);
								}
							}
								
								// Fixed attrib values
							if (is_array($tags[$tagName]["fixAttrib"]))	{
//								debug(array($tagParts[1]));
								$tagAttrib = $this->get_tag_attributes($tagParts[1]);
								$tagParts[1]="";
								reset($tags[$tagName]["fixAttrib"]);
								while(list($attr,$params)=each($tags[$tagName]["fixAttrib"]))	{
									if (strcmp($params["default"],"") && !isset($tagAttrib[0][$attr]))	$tagAttrib[0][$attr]=$params["default"];
									if ($params["always"] || isset($tagAttrib[0][$attr]))	{
										if ($params["trim"])	{$tagAttrib[0][$attr]=trim($tagAttrib[0][$attr]);}
										if ($params["intval"])	{$tagAttrib[0][$attr]=intval($tagAttrib[0][$attr]);}
										if ($params["lower"])	{$tagAttrib[0][$attr]=strtolower($tagAttrib[0][$attr]);}
										if ($params["upper"])	{$tagAttrib[0][$attr]=strtoupper($tagAttrib[0][$attr]);}
										if ($params["range"])	{
											if (isset($params["range"][1]))	{
												$tagAttrib[0][$attr]=t3lib_div::intInRange($tagAttrib[0][$attr],intval($params["range"][0]),intval($params["range"][1]));
											} else {
												$tagAttrib[0][$attr]=t3lib_div::intInRange($tagAttrib[0][$attr],intval($params["range"][0]));
											}
										}
										if (is_array($params["list"]))	{
											if (!in_array($this->caseShift($tagAttrib[0][$attr],$params["casesensitiveComp"]),$this->caseShift($params["list"],$params["casesensitiveComp"],$tagName)))	$tagAttrib[0][$attr]=$params["list"][0];
										}
										if (($params["removeIfFalse"] && $params["removeIfFalse"]!="blank" && !$tagAttrib[0][$attr]) || ($params["removeIfFalse"]=="blank" && !strcmp($tagAttrib[0][$attr],"")))	{
											unset($tagAttrib[0][$attr]);
										}
										if (strcmp($params["removeIfEquals"],"") && !strcmp($this->caseShift($tagAttrib[0][$attr],$params["casesensitiveComp"]),$this->caseShift($params["removeIfEquals"],$params["casesensitiveComp"])))	{
											unset($tagAttrib[0][$attr]);
										}
									}
								}
								$tagParts[1]=$this->compileTagAttribs($tagAttrib[0],$tagAttrib[1]);
							}

								// Protecting the tag by converting < and > to &lt; and &gt; ??
							if ($tags[$tagName]["protect"])	{
								$lt = "&lt;";	$gt = "&gt;";
							} else {
								$lt = "<";	$gt = ">";
							}
								// Remapping tag name?
							if ($tags[$tagName]["remap"])	$tagParts[0] = $tags[$tagName]["remap"];

								// rmTagIfNoAttrib
							if ($endTag || trim($tagParts[1]) || !$tags[$tagName]["rmTagIfNoAttrib"])	{
								$setTag=1;
								
								if ($tags[$tagName]["nesting"])	{
									if (!is_array($tagRegister[$tagName]))	$tagRegister[$tagName]=array();

									if ($endTag)	{
/*										if ($tags[$tagName]["nesting"]=="global")	{
											$lastEl = end($tagStack);
											$correctTag = !strcmp($tagName,$lastEl);
										} else $correctTag=1;
	*/									
										$correctTag=1;
										if ($tags[$tagName]["nesting"]=="global")	{
											$lastEl = end($tagStack);
											if (strcmp($tagName,$lastEl))	{
												if (in_array($tagName,$tagStack))	{
													while(count($tagStack) && strcmp($tagName,$lastEl))	{
														$elPos = end($tagRegister[$lastEl]);
//														debug("popOffEl (".$elPos."): ".$lastEl,1);
														unset($newContent[$elPos]);
														
														array_pop($tagRegister[$lastEl]);
														array_pop($tagStack);
														$lastEl = end($tagStack);
													}
												} else {
													$correctTag=0;	// In this case the 
//													debug($tagName." was not in tagStack - so correctTag=0 (".$c.")",1);
												}
											}
										}
										if (!count($tagRegister[$tagName]) || !$correctTag)	{
											$setTag=0;
										} else {
											array_pop($tagRegister[$tagName]);
											if ($tags[$tagName]["nesting"]=="global")	{array_pop($tagStack);}
										}
									} else {
										array_push($tagRegister[$tagName],$c);
										if ($tags[$tagName]["nesting"]=="global")	{array_push($tagStack,$tagName);}
									}
								}
								
								if ($setTag)	{
										// Setting the tag
									$newContent[$c++]=$lt.($endTag?"/":"").trim($tagParts[0]." ".$tagParts[1]).$gt;
								}
							}
						} else {
							$newContent[$c++]="<".($endTag?"/":"").$tagContent.">";
						}
					} elseif ($keepAll) {
						if (!strcmp($keepAll,"protect"))	{
							$lt = "&lt;";	$gt = "&gt;";
						} else {
							$lt = "<";	$gt = ">";
						}
						$newContent[$c++]=$lt.($endTag?"/":"").$tagContent.$gt;
					}
					$newContent[$c++]=$this->bidir_htmlspecialchars(substr($tok,$tagEnd+1),$hSC);
				} else {
					$newContent[$c++]=$this->bidir_htmlspecialchars("<".$tok,$hSC);
				}
			} else {
				$newContent[$c++]=$this->bidir_htmlspecialchars("<".$tok,$hSC);
			}
//			$tok = strtok("<");
		}
		
		
			// Unsetting tags:
		reset($tagRegister);
		while(list($tag,$positions)=each($tagRegister))	{
			reset($positions);
			while(list(,$pKey)=each($positions))	{
				unset($newContent[$pKey]);
			}
		}

//		debug($tagRegister);
//debug(array($content));
//debug($newContent);
//debug($tags);
//		debug($tagStack);
		
		return implode("",$newContent);
	}
	function bidir_htmlspecialchars($value,$dir)	{
//debug($dir);
		if ($dir>0)	{
			$value = htmlspecialchars($value);
		} elseif ($dir<0) {
			$value = str_replace("&gt;",">",$value);
			$value = str_replace("&lt;","<",$value);
			$value = str_replace("&quot;",'"',$value);
			$value = str_replace("&amp;","&",$value);
		}
		return $value;
	}
	function caseShift($str,$flag,$cacheKey="")	{
		if (is_array($str))	{
			if (!$cacheKey || !isset($this->caseShift_cache[$cacheKey]))	{
				reset($str);
				while(list($k)=each($str))	{
					$str[$k] = strtoupper($str[$k]);
				}
				if ($cacheKey)	$this->caseShift_cache[$cacheKey]=$str;
			} else {
				$str = $this->caseShift_cache[$cacheKey];
			}
		} elseif (!$flag)	$str = strtoupper($str);
		return $str;
	}
	function compileTagAttribs($tagAttrib,$meta=array())	{
		$accu=array();
		reset($tagAttrib);
		while(list($k,$v)=each($tagAttrib))	{	
			$attr=$meta[$k]["origTag"]?$meta[$k]["origTag"]:$k;
			if (strcmp($v,"") || isset($meta[$k]["dashType"]))	{
				$dash=$meta[$k]["dashType"]?$meta[$k]["dashType"]:(t3lib_div::testInt($v)?'':'"');
				$attr.="=".$dash.$v.$dash;
			}
			$accu[]=$attr;
		}
		return implode(" ",$accu);
	}
	function get_tag_attributes_classic($tag,$deHSC=0)	{
		$attr=$this->get_tag_attributes($tag,$deHSC);
		return is_array($attr[0])?$attr[0]:array();
	}

	function get_tag_attributes($tag,$deHSC=0)	{
		// $tag is either a whole tag (eg "<TAG OPTION ATTRIB=VALUE>") or the parameterlist (ex " OPTION ATTRIB=VALUE>")
		// Returns an array with all attributes as keys. Attributes are only lowercase a-z
		// If a attribute is empty (I call it "an option"), then the value for the key is empty. You can check if it existed with isset()

		list($components,$metaC) = $this->split_tag_attributes($tag);
		$name = "";	 // attribute name is stored here
		$valuemode = "";
		$attributes=array();
		$attributesMeta=array();
		if (is_array($components))	{
			while (list($key,$val) = each ($components))	{
				if ($val != "=")	{	// Only if $name is set (if there is an attribute, that waits for a value), that valuemode is enabled. This ensures that the attribute is assigned it's value
					if ($valuemode)	{
						if ($name)	{
							$attributes[$name] = $deHSC?t3lib_div::htmlspecialchars_decode($val):$val;
							$attributesMeta[$name]["dashType"]=$metaC[$key];
							$name = "";
						}
					} else {
						if ($namekey = ereg_replace("[^a-zA-Z0-9]","",$val))	{
							$name = strtolower($namekey);
							$attributesMeta[$name]=array();
							$attributesMeta[$name]["origTag"]=$namekey;
							$attributes[$name] = "";
						}
					}
					$valuemode = "";
				} else {
					$valuemode = "on";
				}
			}
			if (is_array($attributes))	reset($attributes);
			return array($attributes,$attributesMeta);
		}
	}
	function split_tag_attributes($tag)	{
		// Returns an array with the "components" from an attribute list. The result is normally analyzed by get_tag_attributes
		// Removes tag-name if found
		$tag_tmp = trim(eregi_replace ("^[ ]*<[^ ]*","",$tag));
			// Removes any > in the end of the string
		$tag_tmp = trim(eregi_replace (">$","",$tag_tmp));

		$metaValue = array();
		$value = array();
		while (strcmp($tag_tmp,""))	{	// Compared with empty string instead , 030102
			$firstChar=substr($tag_tmp,0,1);
			if (!strcmp($firstChar,'"') || !strcmp($firstChar,"'"))	{
				$reg=explode($firstChar,$tag_tmp,3);
				$value[]=$reg[1];
				$metaValue[]=$firstChar;
				$tag_tmp=trim($reg[2]);
			} elseif (!strcmp($firstChar,"=")) {
				$value[] = "=";
				$metaValue[]="";
				$tag_tmp = trim(substr($tag_tmp,1));		// Removes = chars.
			} else {
				// There are "" around the value. We look for the next " " or ">"
				$reg = split("[[:space:]=]",$tag_tmp,2);
				$value[] = trim($reg[0]);
				$metaValue[]="";
				$tag_tmp = trim(substr($tag_tmp,strlen($reg[0]),1).$reg[1]);
			}
		}
		if (is_array($value))	reset($value);
		return array($value,$metaValue);
	}




	function HTMLparserConfig($TSconfig,$keepTags=array())	{
			// Allow tags (base list, merged with incoming array)
		$alTags = array_flip(t3lib_div::trimExplode(",",strtolower($TSconfig["allowTags"]),1));
		$keepTags = array_merge($alTags,$keepTags);

			// Set config properties.
		if (is_array($TSconfig["tags."]))	{
			reset($TSconfig["tags."]);
			while(list($key,$tagC)=each($TSconfig["tags."]))	{
				if (!is_array($tagC) && $key==strtolower($key))	{
					if (!strcmp($tagC,"0"))	unset($keepTags[$key]);
					if (!strcmp($tagC,"1") && !isset($keepTags[$key]))	$keepTags[$key]=1;
				}
			}

			reset($TSconfig["tags."]);
			while(list($key,$tagC)=each($TSconfig["tags."]))	{
				if (is_array($tagC) && $key==strtolower($key))	{
					$key=substr($key,0,-1);
					if (!is_array($keepTags[$key]))	$keepTags[$key]=array();
					if (is_array($tagC["fixAttrib."]))	{
						reset($tagC["fixAttrib."]);
						while(list($atName,$atConfig)=each($tagC["fixAttrib."]))	{
							if (is_array($atConfig))	{
								$atName=substr($atName,0,-1);
								if (!is_array($keepTags[$key]["fixAttrib"][$atName]))	{
									$keepTags[$key]["fixAttrib"][$atName]=array();
								}
								$keepTags[$key]["fixAttrib"][$atName] = array_merge($keepTags[$key]["fixAttrib"][$atName],$atConfig);
								if ($keepTags[$key]["fixAttrib"][$atName]["range"])	$keepTags[$key]["fixAttrib"][$atName]["range"] = t3lib_div::trimExplode(",",$keepTags[$key]["fixAttrib"][$atName]["range"]);
								if ($keepTags[$key]["fixAttrib"][$atName]["list"])	$keepTags[$key]["fixAttrib"][$atName]["list"] = t3lib_div::trimExplode(",",$keepTags[$key]["fixAttrib"][$atName]["list"]);
							}
						}
					}
					unset($tagC["fixAttrib."]);
					unset($tagC["fixAttrib"]);
					$keepTags[$key] = array_merge($keepTags[$key],$tagC);
				}
			}
		}
			// localNesting
		if ($TSconfig["localNesting"])	{
			$lN = t3lib_div::trimExplode(",",strtolower($TSconfig["localNesting"]),1);
			while(list(,$tn)=each($lN))	{
				if (isset($keepTags[$tn]))	{
					$keepTags[$tn]["nesting"]=1;
				}
			}
		}
		if ($TSconfig["globalNesting"])	{
			$lN = t3lib_div::trimExplode(",",strtolower($TSconfig["globalNesting"]),1);
			while(list(,$tn)=each($lN))	{
				if (isset($keepTags[$tn]))	{
					if (!is_array($keepTags[$tn]))	$keepTags[$tn]=array();
					$keepTags[$tn]["nesting"]="global";
				}
			}
		}
		if ($TSconfig["rmTagIfNoAttrib"])	{
			$lN = t3lib_div::trimExplode(",",strtolower($TSconfig["rmTagIfNoAttrib"]),1);
			while(list(,$tn)=each($lN))	{
				if (isset($keepTags[$tn]))	{
					if (!is_array($keepTags[$tn]))	$keepTags[$tn]=array();
					$keepTags[$tn]["rmTagIfNoAttrib"]=1;
				}
			}
		}
		if ($TSconfig["noAttrib"])	{
			$lN = t3lib_div::trimExplode(",",strtolower($TSconfig["noAttrib"]),1);
			while(list(,$tn)=each($lN))	{
				if (isset($keepTags[$tn]))	{
					if (!is_array($keepTags[$tn]))	$keepTags[$tn]=array();
					$keepTags[$tn]["allowedAttribs"]=0;
				}
			}
		}
		if ($TSconfig["removeTags"])	{
			$lN = t3lib_div::trimExplode(",",strtolower($TSconfig["removeTags"]),1);
			while(list(,$tn)=each($lN))	{
				$keepTags[$tn]=array();
				$keepTags[$tn]["allowedAttribs"]=0;
				$keepTags[$tn]["rmTagIfNoAttrib"]=1;
			}
		}
		
		return array($keepTags, "".$TSconfig["keepNonMatchedTags"], intval($TSconfig["htmlSpecialChars"]));
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_parsehtml.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_parsehtml.php"]);
}
?>