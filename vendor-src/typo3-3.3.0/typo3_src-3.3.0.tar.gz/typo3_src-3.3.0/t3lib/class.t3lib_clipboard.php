<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * PHP implementation of the Typo3 clipboard
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_clipboard {
	var $numberTabs = 3;



	/** 
	 * Clipboard data kept here
	 */
	/*
		Keys:
			"normal"
			"tab_[x]" where x is >=1 and denotes the pad-number
				\	"mode"	:	"copy" means copy-mode, default = moving ("cut")
				\	"el"	:	Array of elements:
								DB: keys = "[tablename]:[uid]"	eg. "tt_content:123" 
								DB: values = 1 (basically insignificant)
								FILE: keys = "_FILE:[shortmd5 of path]"	eg. "_FILE:9ebc7e5c74"
								FILE: values = The full filepath, eg. "/www/htdocs/typo3/32/dummy/fileadmin/sem1_3_examples/alternative_index.php"

			"current" pointer to current tab (among the above...)
			"_setThumb"	boolean: If set, file thumbnails are shown.
			
		The virtual tablename "_FILE" will always indicate files/folders. When checking for elements from eg. "all tables" (by using an empty string) "_FILE" entries are excluded (so in effect only DB elements are counted)
	*/
	var $clipData=array();
	
	var $changed=0;
	var $current="";
	var $backPath="";
	var $lockToNormal=0;
	var $fileMode=0;


	/** 
	 * Initialize the clipboard from the be_user session
	 */
	function initializeClipboard()	{
		global $BE_USER;
			// Get data
		$clipData = $BE_USER->getModuleData("clipboard",$BE_USER->getTSConfigVal("options.saveClipboard")?"":"ses");

			// NumberTabs
		$clNP = $BE_USER->getTSConfigVal("options.clipboardNumberPads");
		if (t3lib_div::testInt($clNP) && $clNP>=0)	{
			$this->numberTabs = t3lib_div::intInRange($clNP,0,20);
		}
		
			// Resets/reinstates the clipboard pads
		$this->clipData["normal"] = is_array($clipData["normal"]) ? $clipData["normal"] : array();
		for ($a=1;$a<=$this->numberTabs;$a++)	{
			$this->clipData["tab_".$a] = is_array($clipData["tab_".$a]) ? $clipData["tab_".$a] : array();
		}
			// Setting the current pad pointer ($this->current) and _setThumb (which determines whether or not do show file thumbnails)
		$this->clipData["current"] = $this->current = isset($this->clipData[$clipData["current"]]) ? $clipData["current"] : "normal";
		$this->clipData["_setThumb"] = $clipData["_setThumb"];
	}
	
	/** 
	 * Call this method after initialization if you want to lock the clipboard to operate on the normal pad only. Trying to switch pad through ->setCmd will not work
	 */
	function lockToNormal()	{
		$this->lockToNormal=1;
		$this->current="normal";
	}

	/** 
	 * The array $cmd may hold various keys which notes some action to take.
	 * Normally perform only one action at a time.
	 * In scripts like db_list.php / file_list.php the GET-var CB is used to control the clipboard.
	 */
	function setCmd($cmd)	{
			// Selecting / Deselecting elements
			// Array $cmd["el"] has keys = element-ident, value = element value (see description of clipData array in header)
			// Selecting elements for "copy" should be done by simultaneously setting setCopyMode.
		if (is_array($cmd["el"]))	{
			reset($cmd["el"]);
			while(list($k,$v)=each($cmd["el"]))	{
				if ($this->current=="normal")	{
					unset($this->clipData["normal"]);
				}
				if ($v)	{
					$this->clipData[$this->current]["el"][$k]=$v;
				} else {
					$this->removeElement($k);
				}
				$this->changed=1;
			}
		}
			// Change clipboard pad (if not locked to normal)
		if ($cmd["setP"])	{
			$this->setCurrentPad($cmd["setP"]);
		}
			// Remove element	(value = item ident: DB; "[tablename]:[uid]"    FILE: "_FILE:[shortmd5 hash of path]"
		if ($cmd["remove"])	{
			$this->removeElement($cmd["remove"]);
			$this->changed=1;
		}
			// Remove all on current pad (value = pad-ident)
		if ($cmd["removeAll"])	{
			$this->clipData[$cmd["removeAll"]]=array();
			$this->changed=1;
		}
			// Set copy mode of the tab
		if (isset($cmd["setCopyMode"]))	{
			$this->clipData[$this->current]["mode"]=$this->isElements()?($cmd["setCopyMode"]?"copy":""):"";
			$this->changed=1;
		}
			// Toggle thumbnail display for files on/off
		if (isset($cmd["setThumb"]))	{
			$this->clipData["_setThumb"]=$cmd["setThumb"];
			$this->changed=1;
		}
	}
	
	/** 
	 * Setting the current pad on clipboard
	 */
	function setCurrentPad($padIdent)	{
			// Change clipboard pad (if not locked to normal)
		if (!$this->lockToNormal && $this->current!=$padIdent)	{
			if (isset($this->clipData[$padIdent]))	$this->clipData["current"] = $this->current = $padIdent;
			if ($this->current!="normal" || !$this->isElements())	$this->clipData[$this->current]["mode"]="";	// Setting mode to default (move) if no items on it or if not "normal"
			$this->changed=1;
		}
	}

	/** 
	 * Call this after initialization and setCmd in order to save the clipboard to the user session. 
	 * The function will check if the internal flag ->changed has been set and if so, save the clipboard. Else not.
	 */
	function endClipboard()	{
		if ($this->changed)	$this->saveClipboard();
		$this->changed=0;
	}	

	/** 
	 * Cleans up an incoming element array $CBarr
	 * $table is the "table which is allowed". Must be set.
	 * $removeDeselected can be set in order to remove entries which are marked for deselection. 
	 */
	function cleanUpCBC($CBarr,$table,$removeDeselected=0)	{
		if (is_array($CBarr))	{
			reset($CBarr);	
			while(list($k,$v)=each($CBarr))	{
				$p=explode(":",$k);
				if ($p[0]!=$table || ($removeDeselected && !$v))	{
					unset($CBarr[$k]);
				}
			}
		}
		return $CBarr;
	}

	/** 
	 * Reports if the current pad has elements (does not check file/DB type OR if file/DBrecord exists or not. Only counting array)
	 */
	function isElements()	{
		return is_array($this->clipData[$this->current]["el"]) && count($this->clipData[$this->current]["el"]);
	}

	/** 
	 * Prints the clipboard
	 */
	function printClipboard()	{
		global $TBE_TEMPLATE,$LANG;
		
//		debug($this->clipData);
		
		$B = $LANG->printButtonsToJS(1);
		// Logout:
		$img=$B["button_clear"];
		$image = @getimagesize($img);
	
		$out=array();
		$elCount = count($this->elFromTable($this->fileMode?"_FILE":""));
		
		$out[]='<tr bgcolor="'.$TBE_TEMPLATE->bgColor2.'">
			<td colspan=3 nowrap align=center><strong>'.t3lib_div::danish_strtoupper($this->clLabel("clipboard","buttons")).'</strong></td>
			</tr>';
		$out[]='<tr bgcolor="#CCCCCC">
			<td>'.
			'<a href="'.t3lib_div::linkThisScript(array("CB"=>array("setThumb"=>$this->clipData["_setThumb"]?0:1))).'#clip_head"><img src="'.$this->backPath.'gfx/thumb_'.($this->clipData["_setThumb"]?"s":"n").'.gif" width="21" height="16" vspace=2 border="0"'.t3lib_BEfunc::titleAttrib($this->clLabel("thumbmode_clip")).'></a>'.
			'<a href="'.t3lib_div::linkThisScript(array("CB"=>array("setCopyMode"=>($this->currentMode()=="copy"?"":"copy")))).'#clip_head"><img src="'.$this->backPath.'gfx/copymode_'.($this->currentMode()=="copy"?"s":"n").'.gif" width="21" height="16" vspace=2 border="0"'.t3lib_BEfunc::titleAttrib($this->clLabel("copymode")).'></a>'.
			'</td>
			<td width=95%><select name="_clipMenu" onChange="eval(this.options[this.selectedIndex].value);this.selectedIndex=0;">
	<option value="" SELECTED>'.$this->clLabel("menu","rm").'</option>
	'.(!$this->fileMode && $elCount?'<option value="'.htmlspecialchars("
		document.location='".$this->editUrl()."&returnUrl='+top.rawurlencode(document.location);
	").'">'.$this->clLabel("edit","rm").'</option>':'').
	($elCount?'
	<option value="'.htmlspecialchars("
		if(confirm(unescape('".rawurlencode(sprintf($LANG->mainLang["mess"]["deleteClip"],$elCount))."'))){
			document.location='".$this->deleteUrl(0,$this->fileMode?1:0)."&redirect='+top.rawurlencode(document.location);
		}
	").'">'.$this->clLabel("delete","rm").'</option>':'').'
</select></td>
			<td><a href="'.t3lib_div::linkThisScript(array("CB"=>array("removeAll"=>$this->current))).'#clip_head"><img src="'.$img.'" '.$image[3].t3lib_BEfunc::titleAttrib($LANG->mainLang["buttons"]["clear"],1).' border=0></a></td>
			</tr>';
		$out[]='<tr bgcolor="'.$TBE_TEMPLATE->bgColor5.'">
			<td colspan=3><a href="'.t3lib_div::linkThisScript(array("CB"=>array("setP"=>"normal"))).'#clip_head"><img src="'.$this->backPath.'gfx/ol/'.($this->current=="normal"?"minus":"plus").'bullet.gif" width="18" height="16" border="0" align=top>'.$this->padTitleWrap("Normal","normal").'</a></td>
			</tr>';
			if ($this->current=="normal")	$out=array_merge($out,$this->printContentFromTab("normal"));
		
		for ($a=1;$a<=$this->numberTabs;$a++)	{
			$out[]='<tr bgcolor="'.$TBE_TEMPLATE->bgColor5.'">
				<td colspan=3><a href="'.t3lib_div::linkThisScript(array("CB"=>array("setP"=>"tab_".$a))).'#clip_head"><img src="'.$this->backPath.'gfx/ol/'.($this->current=="tab_".$a?"minus":"plus").'bullet.gif" width="18" height="16" border="0" align=top>'.$this->padTitleWrap($this->clLabel("cliptabs").$a,"tab_".$a).'</a></td>
				</tr>';
			if ($this->current=="tab_".$a)	$out=array_merge($out,$this->printContentFromTab("tab_".$a));
		}
		
		$output = '<A name="clip_head"></A><table cellpadding=0 cellspacing=1 border=0 width=290>'.implode("",$out).'</table>';
		$output = '<form>'.$output.'</form>';
		return $output;
	}

	/** 
	 * Print the content on a pad. Called from ->printClipboard()
	 */
	function printContentFromTab($pad)	{
		global $TBE_TEMPLATE;
		
		$lines=array();
		if (is_array($this->clipData[$pad]["el"]))	{
			reset($this->clipData[$pad]["el"]);
			while(list($k,$v)=each($this->clipData[$pad]["el"]))	{
				if ($v)	{
					list($table,$uid) = explode(":",$k);
					$bgCol = ($table=="_FILE"&&$this->fileMode)||($table!="_FILE"&&!$this->fileMode) ? t3lib_div::modifyhtmlColor($TBE_TEMPLATE->bgColor4,-20,-20,-20) : $TBE_TEMPLATE->bgColor4;
					if ($table=="_FILE")	{
						if (@file_exists($v))	{
							$fI=pathinfo($v);
							$icon = is_dir($v) ? "folder.gif" : t3lib_BEfunc::getFileIcon(strtolower($fI["extension"]));
							$size=" (".t3lib_div::formatSize(filesize($v))."bytes)";
							$icon = '<img src="gfx/fileicons/'.$icon.'" width=18 height=16 border=0 hspace=20'.t3lib_BEfunc::titleAttrib($fI["basename"].$size).' align=absmiddle>';
							$thumb= $this->clipData["_setThumb"] ? (t3lib_div::inList($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],$fI["extension"]) ? t3lib_BEfunc::getThumbNail($this->backPath."thumbs.php",$v,' vspace=4') : "") :"";

							$lines[]='<tr>
								<td bgcolor="'.$bgCol.'">'.$icon.'</td>
								<td bgcolor="'.$bgCol.'" nowrap width=95%>&nbsp;'.$this->linkItemText(htmlspecialchars(t3lib_div::fixed_lgd(basename($v),$GLOBALS["BE_USER"]->uc["titleLen"])),$v).
									($pad=="normal"?(" <strong>(".($this->clipData["normal"]["mode"]=="copy"?$this->clLabel("copy","cm"):$this->clLabel("cut","cm")).")</strong>"):"").'&nbsp;'.($thumb?"<BR>".$thumb:"").'</td>
								<td bgcolor="'.$bgCol.'" align=center>'.
								'<A HREF="#" onClick="top.launchView(\''.$v.'\', \'\'); return false;"><img src="'.$this->backPath.'gfx/zoom2.gif" width="12" height="12" hspace=2 border="0"'.t3lib_BEfunc::titleAttrib($this->clLabel("info","cm")).'></a>'.
								'<a HREF="'.$this->removeUrl("_FILE",t3lib_div::shortmd5($v)).'#clip_head"><img src="'.$this->backPath.'gfx/close_12h.gif" width="11" height="12" border="0"'.t3lib_BEfunc::titleAttrib($this->clLabel("removeItem")).'></a>'.
								'</td>
							</tr>';
						} else {
							unset($this->clipData[$pad]["el"][$k]);
							$this->changed=1;
						}
					} else {
						$rec=t3lib_BEfunc::getRecord($table,$uid);
						if (is_array($rec))	{
							$lines[]='<tr>
								<td bgcolor="'.$bgCol.'">'.$this->linkItemText(t3lib_iconWorks::getIconImage($table,$rec,$this->backPath,'hspace=20 '.t3lib_BEfunc::titleAttrib(htmlspecialchars(t3lib_BEfunc::getRecordIconAltText($rec,$table)))),$rec,$table).'</td>
								<td bgcolor="'.$bgCol.'" nowrap width=95%>&nbsp;'.$this->linkItemText(htmlspecialchars(t3lib_div::fixed_lgd(t3lib_BEfunc::getRecordTitle($table,$rec),$GLOBALS["BE_USER"]->uc["titleLen"])),$rec,$table).
									($pad=="normal"?(" <strong>(".($this->clipData["normal"]["mode"]=="copy"?$this->clLabel("copy","cm"):$this->clLabel("cut","cm")).")</strong>"):"").'&nbsp;</td>
								<td bgcolor="'.$bgCol.'" align=center>'.
								'<A HREF="#" onClick="top.launchView(\''.$table.'\', \''.$uid.'\'); return false;"><img src="'.$this->backPath.'gfx/zoom2.gif" width="12" height="12" hspace=2 border="0"'.t3lib_BEfunc::titleAttrib($this->clLabel("info","cm")).'></a>'.
								'<a HREF="'.$this->removeUrl($table,$uid).'#clip_head"><img src="'.$this->backPath.'gfx/close_12h.gif" width="11" height="12" border="0"'.t3lib_BEfunc::titleAttrib($this->clLabel("removeItem")).'></a>'.
								'</td>
							</tr>';
						} else {
							unset($this->clipData[$pad]["el"][$k]);
							$this->changed=1;
						}
					}
				}
			}
		}
		if (!count($lines))	{
			$lines[]='<tr>
				<td bgcolor="'.$TBE_TEMPLATE->bgColor4.'"><img src=clear.gif width=56 height=1></td>
				<td colspan=2 bgcolor="'.$TBE_TEMPLATE->bgColor4.'" nowrap width=95%>&nbsp;<em>('.$this->clLabel("clipNoEl").')</em>&nbsp;</td>
			</tr>';
		}
		
		$this->endClipboard();
		return $lines;
	}

	/** 
	 * Wraps title of pad in bold-tags and maybe the number of elements if any.
	 */
	function padTitleWrap($str,$pad)	{
		$el = count($this->elFromTable($this->fileMode?"_FILE":"",$pad));
		if ($el)	{
			return '<strong>'.$str.'</strong> ('.($pad=="normal"?($this->clipData["normal"]["mode"]=="copy"?$this->clLabel("copy","cm"):$this->clLabel("cut","cm")):$el).')';
		} else {
			return dfw($str);
		}
	}

	/** 
	 * Wraps the title of the items listed in link-tags. The items will link to the page/folder where they originate from
	 */
	function linkItemText($str,$rec,$table="")	{
		if (is_array($rec) && $table)	{	
			if ($this->fileMode)	{
				$str=dfw($str);
			} else {
				$str='<a href="'.$this->backPath.'db_list.php?id='.$rec["pid"].'&AB=1">'.$str.'</a>';
			}
		} elseif (@file_exists($rec))	{
			if (!$this->fileMode)	{
				$str=dfw($str);
			} else {
				$str='<a href="'.$this->backPath.'file_list.php?id='.dirname($rec).'&AB=1">'.$str.'</a>';
			}
		}
		return $str;
	}

	/** 
	 * Verifies if the item $table/$uid is on the current pad.
	 * If the pad is "normal", the mode value is returned if the element existed. Thus you'll know if the item was copy or cut moded...
	 */
	function isSelected($table,$uid)	{
		$k=$table.":".$uid;
		return $this->clipData[$this->current]["el"][$k] ? ($this->current=="normal"?$this->currentMode():1) : "";
	}

	/** 
	 * Returns item record $table,$uid if selected on current clipboard
	 */
	function getSelectedRecord($table="",$uid="")	{
		if (!$table && !$uid)	{
			$elArr = $this->elFromTable("");
			reset($elArr);
			list($table,$uid) = explode(":",key($elArr));
		}
		if ($this->isSelected($table,$uid))	{
			$selRec = t3lib_BEfunc::getRecord($table,$uid);
			$selRec["_RECORD_TITLE"] = t3lib_BEfunc::getRecordTitle($table,$selRec);
			return $selRec;
		}
	}

	/** 
	 * Returns the select-url for database elements
	 */
	function selUrlDB($table,$uid,$copy=0,$deselect=0,$baseArray=array())	{
		$CB=array("el"=>array(rawurlencode($table.":".$uid)=>$deselect?0:1));
		if ($copy)	$CB["setCopyMode"]=1;
		$baseArray["CB"]=$CB;
		return t3lib_div::linkThisScript($baseArray);
	}

	/** 
	 * Returns the select-url for files
	 */
	function selUrlFile($path,$copy=0,$deselect=0,$baseArray=array())	{
		$CB=array("el"=>array(rawurlencode("_FILE:".t3lib_div::shortmd5($path))=>$deselect?"":$path));
		if ($copy)	$CB["setCopyMode"]=1;
		$baseArray["CB"]=$CB;
		return t3lib_div::linkThisScript($baseArray);
	}

	/** 
	 * pasteUrl of the element (database and file)
	 * For the meaning of $table and $uid, please read from ->makePasteCmdArray!!!
	 */
	function pasteUrl($table,$uid,$setRedirect=1)	{
		$rU = $this->backPath.($table=="_FILE"?"tce_file.php":"tce_db.php")."?".
			($setRedirect ? "redirect=".rawurlencode(t3lib_div::linkThisScript(array("CB"=>""))) : "").
			"&vC=".$GLOBALS["BE_USER"]->veriCode().
			"&prErr=1&uPT=1".
			"&CB[paste]=".rawurlencode($table.":".$uid).
			"&CB[pad]=".$this->current;
		return $rU;
	}
	
	/** 
	 * deleteUrl of the element (database and file)
	 */
	function deleteUrl($setRedirect=1,$file=0)	{
		$rU = $this->backPath.($file?"tce_file.php":"tce_db.php")."?".
			($setRedirect ? "redirect=".rawurlencode(t3lib_div::linkThisScript(array("CB"=>""))) : "").
			"&vC=".$GLOBALS["BE_USER"]->veriCode().
			"&prErr=1&uPT=1".
			"&CB[delete]=1".
			"&CB[pad]=".$this->current;
		return $rU;
	}
	
	/** 
	 * editUrl of the element (database)
	 */
	function editUrl()	{
		$elements = $this->elFromTable("");	// all records
		reset($elements);
		$editCMDArray=array();
		while(list($tP)=each($elements))	{
			list($table,$uid) = explode(":",$tP);
			$editCMDArray[] = "&edit[".$table."][".$uid."]=edit";
		}
	
		$rU = $this->backPath."alt_doc.php?".implode("",$editCMDArray);
		return $rU;
	}
	
	/** 
	 * Returns the remove-url (file and db, for file $table="_FILE" and $uid = shortmd5 hash of path
	 */
	function removeUrl($table,$uid)	{
		return t3lib_div::linkThisScript(array("CB"=>array("remove"=>$table.":".$uid)));
	}

	/**
	 * This traverses the elements on the current clipboard pane 
	 * and unsets elements which does not exist anymore or are disabled.
	 */
	function cleanCurrent()	{
		if (is_array($this->clipData[$this->current]["el"]))	{
			reset($this->clipData[$this->current]["el"]);
			while(list($k,$v)=each($this->clipData[$this->current]["el"]))	{
				list($table,$uid) = explode(":",$k);
				if ($table!="_FILE")	{
					if (!$v || !is_array(t3lib_BEfunc::getRecord($table,$uid,"uid")))	{
						unset($this->clipData[$this->current]["el"][$k]);
						$this->changed=1;
					}
				} else {
					if (!$v || !@file_exists($v))	{
						unset($this->clipData[$this->current]["el"][$k]);
						$this->changed=1;
					}
				}
			}
		}
	}

	/** 
	 * Counts the number of elements from the table $matchTable. If $matchTable is blank, all tables (except "_FILE" of course) is counted.
	 * $pad can optionally be used to set another pad than the current.
	 */
	function elFromTable($matchTable="",$pad="")	{
		$pad = $pad ? $pad : $this->current;
		$list=array();
		if (is_array($this->clipData[$pad]["el"]))	{
			reset($this->clipData[$pad]["el"]);
			while(list($k,$v)=each($this->clipData[$pad]["el"]))	{
				if ($v)	{
					list($table,$uid) = explode(":",$k);
					if ($table!="_FILE")	{
						if ((!$matchTable || $table==$matchTable) && $GLOBALS["TCA"][$table])	{
							$list[$k]= ($pad=="normal"?$v:$uid);
						}
					} else {
						if ($table==$matchTable)	{
							$list[$k]=$v;
						}
					}
				}
			}
		}
		return $list;
	}
	
	/** 
	 * Returns confirm JavaScript message
	 */
	function confirmMsg($table,$rec,$type,$clElements)	{
		$msg = $GLOBALS["LANG"]->mainLang["mess"][($this->currentMode()=="copy"?"copy":"move").($this->current=="normal"?"":"cb")."_".$type];


		if ($table=="_FILE")	{
			$thisRecTitle = basename($rec);
			if ($this->current=="normal")	{
				reset($clElements);
				$selItem = current($clElements);
				$selRecTitle = basename($selItem);
			} else {
				$selRecTitle=count($clElements);
			}
		} else {
			$thisRecTitle = (
				$table=="pages" && !is_array($rec) ? 
				$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"] : 
				t3lib_BEfunc::getRecordTitle($table,$rec)
			);
				
			if ($this->current=="normal")	{
				$selItem = $this->getSelectedRecord();
				$selRecTitle=$selItem["_RECORD_TITLE"];
			} else {
				$selRecTitle=count($clElements);
			}
		}

			// Message:		
		$conf="confirm(unescape('".rawurlencode(sprintf(
			$msg,
			$selRecTitle,
			$thisRecTitle
			))."'))";
		return $conf;
	}

	/** 
	 * Removes element on clipboard
	 */
	function removeElement($el)	{
		unset($this->clipData[$this->current]["el"][$el]);
		$this->changed=1;
	}

	/** 
	 * Saves the clipboard, no questions asked.
	 * Use ->endClipboard normally (as it checks if changes has been done so saving is necessary)
	 */
	function saveClipboard()	{
		global $BE_USER;
		$BE_USER->pushModuleData("clipboard",$this->clipData);
	}

	/** 
	 * Returns the current mode, "copy" or "cut"
	 */
	function currentMode()	{
		return $this->clipData[$this->current]["mode"]=="copy" ? "copy" : "cut";
	}

	/** 
	 * Clipboard label
	 */
	function clLabel($key,$Akey="labels")	{
		return $GLOBALS["LANG"]->mainLang[$Akey][$key];
	}




	/*****************************************
	 *
	 * FOR USE IN tce_db.php:
	 *
	 ****************************************/
	 
	/**
	 * Applies the proper paste configuration in the $cmd array send to tce_db.php. 
	 * $ref is the target, see description below.
	 * The current pad is pasted
	 */
	function makePasteCmdArray($ref,$CMD)	{
		// $ref: [tablename]:[paste-uid]
		// tablename is the name of the table from which elements *on the current clipboard* is pasted with the "pid" paste-uid. 
		// No tablename means that all items on the clipboard (non-files) are pasted. This requires paste-uid to be positive though.
		// so "tt_content:-3"	means "paste tt_content elements on the clipboard to AFTER tt_content:3 record
		// "tt_content:30"	means "paste tt_content elements on the clipboard into page with id 30
		// ":30"	means "paste ALL database elements on the clipboard into page with id 30
		// ":-30"	not valid.
	
		list($pTable,$pUid) = explode(":",$ref);
		$pUid = intval($pUid);
//		debug($ref);
		if ($pTable || $pUid>=0)	{	// pUid must be set and if pTable is not set (that means paste ALL elements) the uid MUST be positive/zero (pointing to page id)
			$elements = $this->elFromTable($pTable);

			$elements = array_reverse($elements);	// So the order is preserved.
			$mode = $this->currentMode()=="copy" ? "copy" : "move";

				// Traverse elements and make CMD array
			reset($elements);
			while(list($tP)=each($elements))	{
				list($table,$uid) = explode(":",$tP);
				if (!is_array($CMD[$table]))	$CMD[$table]=array();
				$CMD[$table][$uid][$mode]=$pUid;
				if ($mode=="move")	$this->removeElement($tP);
			}
			$this->endClipboard();
//			debug($CMD);
		}
		return $CMD;
	}
	
	/**
	 * Delete cmd array
	 */
	function makeDeleteCmdArray($CMD)	{
		$elements = $this->elFromTable("");	// all records
		reset($elements);
		while(list($tP)=each($elements))	{
			list($table,$uid) = explode(":",$tP);
			if (!is_array($CMD[$table]))	$CMD[$table]=array();
			$CMD[$table][$uid]["delete"]=1;
			$this->removeElement($tP);
		}
		$this->endClipboard();
		return $CMD;
	}
	
	
	
	
	
	/*****************************************
	 *
	 * FOR USE IN tce_file.php:
	 *
	 ****************************************/
	 
	/**
	 * Applies the proper paste configuration in the $file array send to tce_file.php. 
	 * The current pad is pasted
	 */
	function makePasteCmdArray_file($ref,$FILE)	{
		list($pTable,$pUid) = explode(":",$ref);
		$elements = $this->elFromTable("_FILE");
		$mode = $this->currentMode()=="copy" ? "copy" : "move";

			// Traverse elements and make CMD array
		reset($elements);
		while(list($tP,$path)=each($elements))	{
			$FILE[$mode][]=array("data"=>$path,"target"=>$pUid);
			if ($mode=="move")	$this->removeElement($tP);
		}
		$this->endClipboard();
//		debug($FILE);
		return $FILE;
	}
	
	/**
	 * Delete cmd array
	 */
	function makeDeleteCmdArray_file($FILE)	{
		$elements = $this->elFromTable("_FILE");
			// Traverse elements and make CMD array
		reset($elements);
		while(list($tP,$path)=each($elements))	{
			$FILE["delete"][]=array("data"=>$path);
			$this->removeElement($tP);
		}
		$this->endClipboard();
//		debug($FILE);
		return $FILE;
	}	
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_clipboard.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_clipboard.php"]);
}


?>