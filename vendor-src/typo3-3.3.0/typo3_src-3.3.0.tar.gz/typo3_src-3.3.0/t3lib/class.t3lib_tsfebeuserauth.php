<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Typo3 user authentication, backend user authenticated in the TSFE
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_tsfeBeUserAuth extends t3lib_beUserAuth {
	var $formfield_uname = ""; 			// formfield with login-name
	var $formfield_uident = ""; 		// formfield with password
	var $formfield_chalvalue = "";		// formfield with a unique value which is used to encrypt the password and username
	var $security_level = "";				// sets the level of security. *"normal" = clear-text. "challenged" = hashed password/username from form in $formfield_uident. "superchallenged" = hashed password hashed again with username.
	var $writeStdLog = 0;					// Decides if the writelog() function is called at login and logout
	var $writeAttemptLog = 0;				// If the writelog() functions is called if a login-attempt has be tried without success
	var $auth_include = "";						// this is the name of the include-file containing the login form. If not set, login CAN be anonymous. If set login IS needed.

	
/*	
	var $langLabels=array(
	);
*/	
	var $extNeedUpdate=0;
	var $extPublishList="";
	var $extPageInTreeInfo=array();
	var $ext_forcePreview=0;
	var $langSplitIndex=0;
	var $extAdmEnabled = 0;	// General flag which is set if the adminpanel should be displayed at all..
	
	function extGetLL($key)	{
		global $LOCAL_LANG;
		if (!is_array($LOCAL_LANG))	{
			include("typo3/lang/LL_tsfe.php");
			if (!is_array($LOCAL_LANG))		$LOCAL_LANG=array();
		}
		return isset($LOCAL_LANG[$this->uc["lang"]][$key]) ? $LOCAL_LANG[$this->uc["lang"]][$key] : $LOCAL_LANG["default"][$key];
	}
	function extGetHead($pre)	{
		$out.='<IMG src="t3lib/gfx/ol/blank.gif" width="18" height="16" align="absmiddle" border=0>';
		$out.='<IMG src="t3lib/gfx/ol/'.($this->uc["TSFE_adminConfig"]["display_".$pre]?"minus":"plus").'bullet.gif" width="18" height="16" align="absmiddle" border=0>';
		$out.=$this->extFw($this->extGetLL($pre));
		$out=$this->extItemLink($pre,$out);
		return '<tr><td bgColor="#ABBBB4" colspan=4 nowrap>'.$out.'<input type="hidden" name="TSFE_ADMIN_PANEL[display_'.$pre.']" value="'.$this->uc["TSFE_adminConfig"]["display_".$pre].'"></td></tr>';
	}
	function extItemLink($pre,$str)	{
		return '<a href="#" onClick="document.TSFE_ADMIN_PANEL_FORM[\'TSFE_ADMIN_PANEL[display_'.$pre.']\'].value='.($this->uc["TSFE_adminConfig"]["display_".$pre]?"0":"1").'; document.TSFE_ADMIN_PANEL_FORM.submit(); return false;">'.$str.'</a>';
	}
	function extGetItem($pre,$element)	{
		return '<tr>
			<td><img src="clear.gif" width="50" height="1"></td>
			<td nowrap>'.($pre ? $this->extFw($this->extGetLL($pre)) : "&nbsp;").'</td>
			<td><img src="clear.gif" width="10" height="1"></td>
			<td>'.$element.'</td>
		</tr>';
		
	}
	function extFw($str)	{
		return '<font face=verdana size=1 color=black'.($GLOBALS["CLIENT"]["FORMSTYLE"]?' style="color:black;"':"").'>'.$str.'</font>';
	}
	function extGetCategory_preview($out="")	{
		$out.=$this->extGetHead("preview");
		if ($this->uc["TSFE_adminConfig"]["display_preview"])	{
			$this->extNeedUpdate=1;
			$out.=$this->extGetItem("preview_showHiddenPages", '<input type="hidden" name="TSFE_ADMIN_PANEL[preview_showHiddenPages]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[preview_showHiddenPages]" value="1"'.($this->uc["TSFE_adminConfig"]["preview_showHiddenPages"]?" checked":"").'>');
			$out.=$this->extGetItem("preview_showHiddenRecords", '<input type="hidden" name="TSFE_ADMIN_PANEL[preview_showHiddenRecords]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[preview_showHiddenRecords]" value="1"'.($this->uc["TSFE_adminConfig"]["preview_showHiddenRecords"]?" checked":"").'>');
	
				// Simulate data
			$out.=$this->extGetItem("preview_simulateDate", '<input type="checkbox" name="TSFE_ADMIN_PANEL[preview_simulateDate]_cb" onClick="TSFEtypo3FormFieldGet(\'TSFE_ADMIN_PANEL[preview_simulateDate]\', \'datetime\', \'\',1,0,1);"><input type="text" name="TSFE_ADMIN_PANEL[preview_simulateDate]_hr" onChange="TSFEtypo3FormFieldGet(\'TSFE_ADMIN_PANEL[preview_simulateDate]\', \'datetime\', \'\', 1,0);"><input type="hidden" name="TSFE_ADMIN_PANEL[preview_simulateDate]" value="'.$this->uc["TSFE_adminConfig"]["preview_simulateDate"].'">');
			$this->extJSCODE.='TSFEtypo3FormFieldSet("TSFE_ADMIN_PANEL[preview_simulateDate]", "datetime", "", 1,0);';
	
				// Simulate fe_user:
			$query = "select fe_groups.uid, fe_groups.title from fe_groups,pages WHERE pages.uid=fe_groups.pid AND NOT pages.deleted ".t3lib_BEfunc::deleteClause("fe_groups")." AND ".$this->getPagePermsClause(1);
			$res = mysql(TYPO3_db, $query);
			echo mysql_error();
			$options="<option value=0></option>";
			while($row=mysql_fetch_assoc($res))	{
				$options.='<option value="'.$row["uid"].'"'.($this->uc["TSFE_adminConfig"]["preview_simulateUserGroup"]==$row["uid"]?" selected":"").'>'.htmlspecialchars("[".$row["uid"]."] ".$row["title"]).'</option>';
			}
			$out.=$this->extGetItem("preview_simulateUserGroup", '<select name="TSFE_ADMIN_PANEL[preview_simulateUserGroup]">'.$options.'</select>');
		}	
		return $out;
	}	
	function extGetCategory_cache($out="")	{
		$out.=$this->extGetHead("cache");
		if ($this->uc["TSFE_adminConfig"]["display_cache"])	{
			$this->extNeedUpdate=1;
			$out.=$this->extGetItem("cache_noCache", '<input type="hidden" name="TSFE_ADMIN_PANEL[cache_noCache]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[cache_noCache]" value="1"'.($this->uc["TSFE_adminConfig"]["cache_noCache"]?" checked":"").'>');
	
			$options="";
			$options.='<option value="0"'.($this->uc["TSFE_adminConfig"]["cache_clearCacheLevels"]==0?" selected":"").'>'.htmlspecialchars($this->extGetLL("div_Levels_0")).'</option>';
			$options.='<option value="1"'.($this->uc["TSFE_adminConfig"]["cache_clearCacheLevels"]==1?" selected":"").'>'.htmlspecialchars($this->extGetLL("div_Levels_1")).'</option>';
			$options.='<option value="2"'.($this->uc["TSFE_adminConfig"]["cache_clearCacheLevels"]==2?" selected":"").'>'.htmlspecialchars($this->extGetLL("div_Levels_2")).'</option>';
			$out.=$this->extGetItem("cache_clearLevels", '<select name="TSFE_ADMIN_PANEL[cache_clearCacheLevels]">'.$options.'</select>'.'<input type="hidden" name="TSFE_ADMIN_PANEL[cache_clearCacheId]" value="'.$GLOBALS["TSFE"]->id.'"><input type="submit" value="'.$this->extGetLL("update").'">');

				// Generating tree:
			$depth=$this->extGetFeAdminValue("cache","clearCacheLevels");
			$outTable="";
//			$outTable.='<tr><td></td><td></td><td><strong>'.$this->extFw($this->extGetLL("cache_cacheEntries")).'</strong></td></tr>';
			$this->extPageInTreeInfo=array();
			$this->extPageInTreeInfo[]=array($GLOBALS["TSFE"]->page["uid"],$GLOBALS["TSFE"]->page[title],$depth+1);
			$this->extGetTreeList($GLOBALS["TSFE"]->id, $depth,0,$this->getPagePermsClause(1));
			reset($this->extPageInTreeInfo);
			while(list(,$row)=each($this->extPageInTreeInfo))	{
				$outTable.='<tr><td nowrap><img src="clear.gif" width='.(($depth+1-$row[2])*18).' height=1><IMG src="t3lib/gfx/i/pages.gif" width="18" height="16" align="absmiddle" border=0>'.$this->extFw($row[1]).'</td><td><img src="clear.gif" width="10" height="1"></td><td>'.$this->extFw($this->extGetNumberOfCachedPages($row[0])).'</td></tr>';
			}
			$outTable='<BR><table border=0 cellpadding=0 cellspacing=0>'.$outTable.'</table>';
			$outTable.='<input type="submit" name="TSFE_ADMIN_PANEL[action][clearCache]" value="'.$this->extGetLL("cache_doit").'">';
			$out.=$this->extGetItem("cache_cacheEntries", $outTable);

		}		
		return $out;
	}	
	function extGetCategory_publish($out="")	{
		$out.=$this->extGetHead("publish");
		if ($this->uc["TSFE_adminConfig"]["display_publish"])	{
			$this->extNeedUpdate=1;
			$options="";
			$options.='<option value="0"'.($this->uc["TSFE_adminConfig"]["publish_levels"]==0?" selected":"").'>'.htmlspecialchars($this->extGetLL("div_Levels_0")).'</option>';
			$options.='<option value="1"'.($this->uc["TSFE_adminConfig"]["publish_levels"]==1?" selected":"").'>'.htmlspecialchars($this->extGetLL("div_Levels_1")).'</option>';
			$options.='<option value="2"'.($this->uc["TSFE_adminConfig"]["publish_levels"]==2?" selected":"").'>'.htmlspecialchars($this->extGetLL("div_Levels_2")).'</option>';
			$out.=$this->extGetItem("publish_levels", '<select name="TSFE_ADMIN_PANEL[publish_levels]">'.$options.'</select>'.'<input type="hidden" name="TSFE_ADMIN_PANEL[publish_id]" value="'.$GLOBALS["TSFE"]->id.'"><input type="submit" value="'.$this->extGetLL("update").'">');
			
				// Generating tree:
			$depth=$this->extGetFeAdminValue("publish","levels");
			$outTable="";
			$this->extPageInTreeInfo=array();
			$this->extPageInTreeInfo[]=array($GLOBALS["TSFE"]->page["uid"],$GLOBALS["TSFE"]->page[title],$depth+1);
			$this->extGetTreeList($GLOBALS["TSFE"]->id, $depth,0,$this->getPagePermsClause(1));
			reset($this->extPageInTreeInfo);
			while(list(,$row)=each($this->extPageInTreeInfo))	{
				$outTable.='<tr><td nowrap><img src="clear.gif" width='.(($depth+1-$row[2])*18).' height=1><IMG src="t3lib/gfx/i/pages.gif" width="18" height="16" align="absmiddle" border=0>'.$this->extFw($row[1]).'</td><td><img src="clear.gif" width="10" height="1"></td><td>'.$this->extFw("...").'</td></tr>';
			}
			$outTable='<BR><table border=0 cellpadding=0 cellspacing=0>'.$outTable.'</table>';
			$outTable.='<input type="submit" name="TSFE_ADMIN_PANEL[action][publish]" value="'.$this->extGetLL("publish_doit").'">';
			$out.=$this->extGetItem("publish_tree", $outTable);
		}		
		return $out;
	}	
	function extGetCategory_edit($out="")	{
		$out.=$this->extGetHead("edit");
		if ($this->uc["TSFE_adminConfig"]["display_edit"])	{
			$this->extNeedUpdate=1;
			$out.=$this->extGetItem("edit_displayFieldIcons", '<input type="hidden" name="TSFE_ADMIN_PANEL[edit_displayFieldIcons]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[edit_displayFieldIcons]" value="1"'.($this->uc["TSFE_adminConfig"]["edit_displayFieldIcons"]?" checked":"").'>');
			$out.=$this->extGetItem("edit_displayIcons", '<input type="hidden" name="TSFE_ADMIN_PANEL[edit_displayIcons]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[edit_displayIcons]" value="1"'.($this->uc["TSFE_adminConfig"]["edit_displayIcons"]?" checked":"").'>');
			$out.=$this->extGetItem("edit_editFormsOnPage", '<input type="hidden" name="TSFE_ADMIN_PANEL[edit_editFormsOnPage]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[edit_editFormsOnPage]" value="1"'.($this->uc["TSFE_adminConfig"]["edit_editFormsOnPage"]?" checked":"").'>');
			$out.=$this->extGetItem("edit_editNoPopup", '<input type="hidden" name="TSFE_ADMIN_PANEL[edit_editNoPopup]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[edit_editNoPopup]" value="1"'.($this->uc["TSFE_adminConfig"]["edit_editNoPopup"]?" checked":"").'>');

			$out.=$this->extGetItem("", $this->ext_makeToolBar());
			if (!t3lib_div::GPvar("ADMCMD_view"))	{
				$out.=$this->extGetItem("", '<a  href="#" onClick="vHWin=window.open(\'typo3/alt_main.php\',\''.md5("Typo3Backend-".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]).'\',\'status=1,menubar=1,scrollbars=1,resizable=1\');vHWin.focus();return false;">'.$this->extFw($this->extGetLL("edit_openAB")).'</a>');
			}
		}		
		return $out;
	}	
	function ext_makeToolBar()	{
		$toolBar='';		
		$id = $GLOBALS["TSFE"]->id;
		$toolBar.='<a HREF="typo3/show_rechis.php?element='.rawurlencode('pages:'.$id).'&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'#latest"><img src="t3lib/gfx/history2.gif" width="13" height="12" hspace=2 border="0" align=top'.t3lib_BEfunc::titleAttrib($this->extGetLL("edit_recordHistory"),1).'></a>';
		$toolBar.='<A HREF="typo3/db_new_content_el.php?id='.$id.'&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><img src="t3lib/gfx/new_record.gif" hspace=1 width=16 height=12 border=0 align=top align="top"'.t3lib_BEfunc::titleAttrib($this->extGetLL("edit_newContentElement"),1).'></a>';
		$toolBar.='<A HREF="typo3/move_el.php?table=pages&uid='.$id.'&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><img src="t3lib/gfx/move_page.gif" hspace=2 width=11 height=12 border=0 align=top align="top"'.t3lib_BEfunc::titleAttrib($this->extGetLL("edit_move_page"),1).'></a>';
		$toolBar.='<a href="typo3/db_new.php?id='.$id.'&pagesOnly=1&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><img src="t3lib/gfx/new_page.gif" width="13" height="12" hspace=0 border="0" align=top'.t3lib_BEfunc::titleAttrib($this->extGetLL("edit_newPage"),1).'></a>';
		$params="&edit[pages][".$id."]=edit";
		$toolBar.='<a href="typo3/alt_doc.php?'.$params.'&noView=1&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><img src="t3lib/gfx/edit2.gif" width="11" height="12" hspace=2 border="0" align=top'.t3lib_BEfunc::titleAttrib($this->extGetLL("edit_editPageHeader"),1).'></a>';
		if ($this->check("modules","web_list"))	$toolBar.='<a href="typo3/db_list.php?AB=1&id='.$id.'&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><img src="t3lib/gfx/list.gif" width="11" height="11" hspace=2 border="0" align=top'.t3lib_BEfunc::titleAttrib($this->extGetLL("edit_db_list"),1).'></a>';
		return $toolBar;
	}
	function extGetCategory_tsdebug($out="")	{
		$out.=$this->extGetHead("tsdebug");
		if ($this->uc["TSFE_adminConfig"]["display_tsdebug"])	{
			$this->extNeedUpdate=1;
			$out.=$this->extGetItem("tsdebug_tree", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_tree]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_tree]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_tree"]?" checked":"").'>');
			$out.=$this->extGetItem("tsdebug_displayTimes", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_displayTimes]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_displayTimes]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_displayTimes"]?" checked":"").'>');
			$out.=$this->extGetItem("tsdebug_displayMessages", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_displayMessages]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_displayMessages]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_displayMessages"]?" checked":"").'>');
			$out.=$this->extGetItem("tsdebug_LR", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_LR]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_LR]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_LR"]?" checked":"").'>');
			$out.=$this->extGetItem("tsdebug_displayContent", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_displayContent]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_displayContent]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_displayContent"]?" checked":"").'>');
			$out.=$this->extGetItem("tsdebug_displayQueries", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_displayQueries]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_displayQueries]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_displayQueries"]?" checked":"").'>');

			$out.=$this->extGetItem("tsdebug_forceTemplateParsing", '<input type="hidden" name="TSFE_ADMIN_PANEL[tsdebug_forceTemplateParsing]" value="0"><input type="checkbox" name="TSFE_ADMIN_PANEL[tsdebug_forceTemplateParsing]" value="1"'.($this->uc["TSFE_adminConfig"]["tsdebug_forceTemplateParsing"]?" checked":"").'>');
			
			$GLOBALS["TT"]->printConf["flag_tree"] = $this->extGetFeAdminValue("tsdebug","tree");
			$GLOBALS["TT"]->printConf["allTime"] = $this->extGetFeAdminValue("tsdebug","displayTimes");
			$GLOBALS["TT"]->printConf["flag_messages"] = $this->extGetFeAdminValue("tsdebug","displayMessages");
			$GLOBALS["TT"]->printConf["flag_content"] = $this->extGetFeAdminValue("tsdebug","displayContent");
			$GLOBALS["TT"]->printConf["flag_queries"] = $this->extGetFeAdminValue("tsdebug","displayQueries");
			$out.='<tr><td><img src="clear.gif" width="50" height="1"></td><td colspan=3>'.$GLOBALS["TT"]->printTSlog().'</td></tr>';
		}		
		return $out;
	}	
	function extGetCategory_info($out="")	{
		$out.=$this->extGetHead("info");
		if ($this->uc["TSFE_adminConfig"]["display_info"])	{

			if (is_array($GLOBALS["TSFE"]->imagesOnPage) && $this->extGetFeAdminValue("cache","noCache"))	{
				reset($GLOBALS["TSFE"]->imagesOnPage);
				$theBytes=0;
				$count=0;
				$fileTable="";
				while(list(,$file)=each($GLOBALS["TSFE"]->imagesOnPage))	{
					$fs=@filesize($file);
					$fileTable.='<tr><td>'.$this->extFw($file).'</td><td align=right>'.$this->extFw(t3lib_div::formatSize($fs)).'</td></tr>';
					$theBytes+=$fs;
					$count++;
				}
				$fileTable.='<tr><td><strong>'.$this->extFw('Total number of images:').'</strong></td><td>'.$this->extFw($count).'</td></tr>';
				$fileTable.='<tr><td><strong>'.$this->extFw('Total image file sizes:').'</strong></td><td align=right>'.$this->extFw(t3lib_div::formatSize($theBytes)).'</td></tr>';
				$fileTable.='<tr><td><strong>'.$this->extFw('Document size:').'</strong></td><td align=right>'.$this->extFw(t3lib_div::formatSize(strlen($GLOBALS["TSFE"]->content))).'</td></tr>';
				$fileTable.='<tr><td><strong>'.$this->extFw('Total page load:').'</strong></td><td align=right>'.$this->extFw(t3lib_div::formatSize(strlen($GLOBALS["TSFE"]->content)+$theBytes)).'</td></tr>';
				$fileTable.='<tr><td>&nbsp;</td></tr>';
			}

			$fileTable.='<tr><td>'.$this->extFw('id:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->id).'</td></tr>';
			$fileTable.='<tr><td>'.$this->extFw('type:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->type).'</td></tr>';
			$fileTable.='<tr><td>'.$this->extFw('gr_list:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->gr_list).'</td></tr>';
			$fileTable.='<tr><td>'.$this->extFw('no_cache:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->no_cache).'</td></tr>';
			$fileTable.='<tr><td>'.$this->extFw('fe_user, name:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->fe_user->user["username"]).'</td></tr>';
			$fileTable.='<tr><td>'.$this->extFw('fe_user, uid:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->fe_user->user["uid"]).'</td></tr>';
			$fileTable.='<tr><td>&nbsp;</td></tr>';

				// parsetime:
			$fileTable.='<tr><td>'.$this->extFw('Total parsetime:').'</td><td>'.$this->extFw($GLOBALS["TSFE"]->scriptParseTime." ms").'</td></tr>';

			$fileTable='<table border=0 cellpadding=0 cellspacing=0>'.$fileTable.'</table>';

			$out.='<tr><td><img src="clear.gif" width="50" height="1"></td><td colspan=3>'.$fileTable.'</td></tr>';
		}		
		return $out;
	}	
	function extPrintFeAdminDialog()	{
		if ($this->uc["TSFE_adminConfig"]["display_top"])	{
			if ($this->extAdmModuleEnabled("preview"))	$out.= $this->extGetCategory_preview();
			if ($this->extAdmModuleEnabled("cache"))	$out.= $this->extGetCategory_cache();
			if ($this->extAdmModuleEnabled("publish"))	$out.= $this->extGetCategory_publish();
			if ($this->extAdmModuleEnabled("edit"))	$out.= $this->extGetCategory_edit();
			if ($this->extAdmModuleEnabled("tsdebug"))	$out.= $this->extGetCategory_tsdebug();
			if ($this->extAdmModuleEnabled("info"))	$out.= $this->extGetCategory_info();
		}

		$header.='<tr><td bgColor="#9BA1A8" colspan=2 nowrap>';
		$header.=$this->extItemLink("top",'<IMG src="t3lib/gfx/ol/'.($this->uc["TSFE_adminConfig"]["display_top"]?"minus":"plus").'bullet.gif" width="18" height="16" align="absmiddle" border=0>'.
					$this->extFw('<strong>'.$this->extGetLL("adminOptions").'</strong>')).$this->extFw(": ".$this->user["username"]).
					'</td><td bgColor="#9BA1A8"><img src="clear.gif" width="10" height="1"></td><td bgColor="#9BA1A8"><input type="hidden" name="TSFE_ADMIN_PANEL[display_top]" value="'.$this->uc["TSFE_adminConfig"]["display_top"].'">'.($this->extNeedUpdate?'<input type="submit" value="'.$this->extGetLL("update").'">':'').'</td></tr>';

		$out='<table border=0 cellpadding=0 cellspacing=0 bgcolor="#F6F2E6"><form name="TSFE_ADMIN_PANEL_FORM" action="'.getenv("REQUEST_URI").'#TSFE_ADMIN" method="post">'.$header.$out.'</form></table>';			// Old: index.php?'.getenv("QUERY_STRING")
		$out='<a name="TSFE_ADMIN"></a><table border=0 cellpadding=1 cellspacing=0 bgcolor=black><tr><td>'.$out.'</td></tr></table>';
		if ($this->uc["TSFE_adminConfig"]["display_top"])	{
/*			if (!$GLOBALS["JS_INCLUDED_jsfunc_evalfield_js"])	{
				$out.='<SCRIPT LANGUAGE="JavaScript" SRC="t3lib/jsfunc.evalfield.js"></SCRIPT>';
			}
	*/		$out.='<SCRIPT LANGUAGE="JavaScript" SRC="t3lib/jsfunc.evalfield.js"></SCRIPT>';
			$out.='
			<script>
				var evalFunc = new evalFunc();
				function TSFEtypo3FormFieldSet(theField, evallist, is_in, checkbox, checkboxValue)	{
					var theFObj = new evalFunc_dummy (evallist,is_in, checkbox, checkboxValue);
					var theValue = document.TSFE_ADMIN_PANEL_FORM[theField].value;
					if (checkbox && theValue==checkboxValue)	{
						document.TSFE_ADMIN_PANEL_FORM[theField+"_hr"].value="";
						document.TSFE_ADMIN_PANEL_FORM[theField+"_cb"].checked = "";
					} else {
						document.TSFE_ADMIN_PANEL_FORM[theField+"_hr"].value = evalFunc.outputObjValue(theFObj, theValue);
						document.TSFE_ADMIN_PANEL_FORM[theField+"_cb"].checked = "on";
					}
				}
				function TSFEtypo3FormFieldGet(theField, evallist, is_in, checkbox, checkboxValue, checkbox_off)	{
					var theFObj = new evalFunc_dummy (evallist,is_in, checkbox, checkboxValue);
					if (checkbox_off)	{
						document.TSFE_ADMIN_PANEL_FORM[theField].value=checkboxValue;
					}else{
						document.TSFE_ADMIN_PANEL_FORM[theField].value = evalFunc.evalObjValue(theFObj, document.TSFE_ADMIN_PANEL_FORM[theField+"_hr"].value);
					}
					TSFEtypo3FormFieldSet(theField, evallist, is_in, checkbox, checkboxValue);
				}
			</script>
			<script>'.$this->extJSCODE.'</script>';
		}
		return "\n\n\n\n".$out."<BR>";
	}
	function extInitFeAdmin()	{
		$this->extAdminConfig = $this->getTSConfigProp("admPanel");
		if (is_array($this->extAdminConfig["enable."]))	{
			reset($this->extAdminConfig["enable."]);
			while(list($k,$v)=each($this->extAdminConfig["enable."]))	{
				if ($v)	{
					$this->extAdmEnabled=1;
					break;
				}
			}
		}
	}	
	function extPageReadAccess($pageRec)	{
		return $this->isInWebMount($pageRec["uid"]) && $this->doesUserHaveAccess($pageRec,1);
	}
	function extAdmModuleEnabled($key)	{
			// Returns true if the module checked is "preview" and the forcePreview flag is set.
		if ($key=="preview" && $this->ext_forcePreview)	return true;
			// If key is not set, only "all" is checked
		if ($this->extAdminConfig["enable."]["all"])	return true;
		if ($this->extAdminConfig["enable."][$key])	{
			return true;
		}
	}
	function extSaveFeAdminConfig()	{
		if (is_array($GLOBALS["HTTP_POST_VARS"]["TSFE_ADMIN_PANEL"]))	{
	//		debug($GLOBALS["HTTP_POST_VARS"]["TSFE_ADMIN_PANEL"]);
				// Setting
			$input = $GLOBALS["HTTP_POST_VARS"]["TSFE_ADMIN_PANEL"];
			$this->uc["TSFE_adminConfig"] = array_merge(!is_array($this->uc["TSFE_adminConfig"])?array():$this->uc["TSFE_adminConfig"], $input);
			unset($this->uc["TSFE_adminConfig"]["action"]);
			
				// Actions:
			if ($input["action"]["clearCache"] && $this->extAdmModuleEnabled("cache"))	{
				$this->extPageInTreeInfo=array();
				$theStartId = intval($input["cache_clearCacheId"]);
				$GLOBALS["TSFE"]->clearPageCacheContent_pidList($this->extGetTreeList($theStartId, $this->extGetFeAdminValue("cache","clearCacheLevels"),0,$this->getPagePermsClause(1)).$theStartId);
			}
			if ($input["action"]["publish"] && $this->extAdmModuleEnabled("publish"))	{
				$theStartId = intval($input["publish_id"]);
				$this->extPublishList = $this->extGetTreeList($theStartId, $this->extGetFeAdminValue("publish","levels"),0,$this->getPagePermsClause(1)).$theStartId;
			}
		
				// Saving		
			$this->writeUC();
		}
		$GLOBALS["TT"]->LR = $this->extGetFeAdminValue("tsdebug","LR");
		if ($this->extGetFeAdminValue("cache","noCache"))	{$GLOBALS["TSFE"]->set_no_cache();}
	}
	function extGetFeAdminValue($pre,$val="")	{
		if ($this->extAdmModuleEnabled($pre))	{	// Check if module is enabled.
				// Exceptions where the values can be overridden from backend:
			if ($pre."_".$val == "edit_displayIcons" && $this->extAdminConfig["module."]["edit."]["forceDisplayIcons"])	{
				return true;
			}
			if ($pre."_".$val == "edit_displayFieldIcons" && $this->extAdminConfig["module."]["edit."]["forceDisplayFieldIcons"])	{
				return true;
			}

			$retVal = $val ? $this->uc["TSFE_adminConfig"][$pre."_".$val] : 1;

			if ($pre=="preview" && $this->ext_forcePreview)	{
				if (!$val)	{
					return true;
				} else {
					return $retVal;
				}
			}
			
				// regular check:
			if ($this->uc["TSFE_adminConfig"]["display_top"] && $this->uc["TSFE_adminConfig"]["display_".$pre])	{	// See if the menu is expanded!
				return $retVal;
			}
		}
	}

	function extGetTreeList($id,$depth,$begin=0,$perms_clause)	{
		// Generates a list of Page-uid's from $id. List does not include $id itself
		// The only pages excluded from the list is deleted pages
		// returns the list with a comma in the end (if any pages selected!)
		// $begin is an optional integer that determines at which level in the tree to start collecting uid's. Zero means "start right away", 1 = 'next level and out'
		$depth=intval($depth);
		$begin=intval($begin);
		$id=intval($id);
		$theList="";
		
		if ($id && $depth>0)	{
			$query = "SELECT uid,title FROM pages WHERE pid = $id AND doktype IN (1,2,5) AND NOT deleted AND ".$perms_clause;
			$res = mysql(TYPO3_db, $query);
			echo mysql_error();
			while ($row = mysql_fetch_assoc($res))	{
				if ($begin<=0)	{
					$theList.=$row[uid].",";
					$this->extPageInTreeInfo[]=array($row["uid"],$row["title"],$depth);
				}
				if ($depth>1)	{
					$theList.=$this->extGetTreeList($row["uid"], $depth-1,$begin-1,$perms_clause);
				}
			}
		}
		return $theList;
	}
	function extGetNumberOfCachedPages($page_id)	{
		$res = mysql (TYPO3_db, "SELECT count(*) FROM cache_pages WHERE page_id=".$page_id);
		list($num) = mysql_fetch_row($res);
		return $num;
	}
	function extLangSplit()	{		// splitLabel
		$ls = explode("|",TYPO3_languages);
		while(list($i,$v)=each($ls))	{
			if ($v==$this->uc["lang"])	{$this->langSplitIndex=$i;}
		}
	}
	function extSL($input)	{		// splitLabel
		$t = explode("|",$input);
		return $t[$this->langSplitIndex] ? $t[$this->langSplitIndex] : $t[0];
	}
	function extIsEditAction()	{
		$TSFE_EDIT = $GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"];
		if (is_array($TSFE_EDIT))	{
/*			$cmd=(string)$TSFE_EDIT["cmd"];
			if ($cmd!="edit" && $cmd!="new")	{
				return true;
			}*/
			if ($TSFE_EDIT["cancel"])	{
				unset($TSFE_EDIT["cmd"]);
			} elseif (($cmd!="edit" || (is_array($TSFE_EDIT["data"]) && ($TSFE_EDIT["update"] || $TSFE_EDIT["update_close"]))) && $cmd!="new")	{
					// $cmd can be a command like "hide" or "move". If $cmd is "edit" or "new" it's an indication to show the formfields. But if data is sent with update-flag then $cmd = edit is accepted because edit may be sendt because of .keepGoing flag.
				return true;
			}
		}
	}
	function extIsFormShown()	{
		$TSFE_EDIT = $GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"];
		if (is_array($TSFE_EDIT))	{
			$cmd=(string)$TSFE_EDIT["cmd"];
			if ($cmd=="edit" || $cmd=="new")	{
				return true;
			}
		}
	}
	function extEditAction()	{
		global $TCA;
			// Commands:
		$TSFE_EDIT = $GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"];
	//	debug($TSFE_EDIT);
		list($table,$uid) = explode(":",$TSFE_EDIT["record"]);
		if ($TSFE_EDIT["cmd"] && $table && $uid && isset($TCA[$table]))	{
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
			$recData=array();
			$cmdData=array();
			$cmd=$TSFE_EDIT["cmd"];
			switch($cmd)	{
				case "hide":
				case "unhide":
					$hideField = $TCA[$table]["ctrl"]["enablecolumns"]["disabled"];
					if ($hideField)	{
						$recData[$table][$uid][$hideField]=($cmd=="hide"?1:0);
//						debug($recData);
						$tce->start($recData,Array());
						$tce->process_datamap();
					}
				break;
				case "up":
				case "down":
					$sortField = $TCA[$table]["ctrl"]["sortby"];
					if ($sortField)	{
						if ($cmd=="up")	{
							$op= "<";
							$desc=" DESC";
						} else {
							$op= ">";
							$desc="";
						}
							// Get self:
						$fields = array_unique(t3lib_div::trimExplode(",",$TCA[$table]["ctrl"]["copyAfterDuplFields"].",uid,pid,".$sortField,1));
						$query="SELECT ".implode(",",$fields)." FROM ".$table." WHERE uid=".$uid;
						$res = mysql(TYPO3_db,$query);
						if ($row=mysql_fetch_assoc($res))	{
								// record before or after
							$preview = $this->extGetFeAdminValue("preview");
							$copyAfterFieldsQuery = "";
							if ($preview)	{$ignore = array("starttime"=>1, "endtime"=>1, "disabled"=>1, "fe_group"=>1);}
							if ($TCA[$table]["ctrl"]["copyAfterDuplFields"])	{
								$cAFields = t3lib_div::trimExplode(",",$TCA[$table]["ctrl"]["copyAfterDuplFields"],1);
								while(list(,$fN)=each($cAFields))	{
									$copyAfterFieldsQuery.=" AND ".$fN."='".$row[$fN]."'";
								}
							}
							
							$query="SELECT uid,pid FROM ".$table." WHERE pid=".$row["pid"].
								" AND ".$sortField.$op.intval($row[$sortField]).
								$copyAfterFieldsQuery.
								t3lib_pageSelect::enableFields($table,"",$ignore).
								" ORDER BY ".$sortField.$desc.
								" LIMIT 2";
								
							$res = mysql(TYPO3_db,$query);
							if ($row2=mysql_fetch_assoc($res))	{
//								debug($row2);
								if($cmd=="down")	{
									$cmdData[$table][$uid]["move"]= -$row2["uid"];
								} elseif ($row3=mysql_fetch_assoc($res)) {	// Must take the second record above...
									$cmdData[$table][$uid]["move"]= -$row3["uid"];
								} else {	// ... and if that does not exist, use pid
									$cmdData[$table][$uid]["move"]= $row["pid"];
								}
							} elseif ($cmd=="up") {
								$cmdData[$table][$uid]["move"]= $row["pid"];
							}
						}
						if (count($cmdData))	{
//							debug($cmdData);
							$tce->start(Array(),$cmdData);
							$tce->process_cmdmap();
						}
					}
				break;
				case "delete":
					$cmdData[$table][$uid]["delete"]= 1;
					if (count($cmdData))	{
//							debug($cmdData);
						$tce->start(Array(),$cmdData);
						$tce->process_cmdmap();
					}
				break;
			}
		}
			// Data:
		if (($TSFE_EDIT["doSave"] || $TSFE_EDIT["update"] || $TSFE_EDIT["update_close"]) && is_array($TSFE_EDIT["data"]))	{
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
//			debug($TSFE_EDIT["data"]);
			$tce->start($TSFE_EDIT["data"],Array());
			$tce->process_uploads($GLOBALS["HTTP_POST_FILES"]);
			$tce->process_datamap();
		}
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tsfebeuserauth.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tsfebeuserauth.php"]);
}

?>