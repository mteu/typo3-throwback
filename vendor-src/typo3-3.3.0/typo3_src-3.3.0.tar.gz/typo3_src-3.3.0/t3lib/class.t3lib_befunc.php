<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * standard functions available for the Typo3 backend.
 *
 * Expects global vars:
 *
 * $backPath		: 	Back back to the Typo3 diretory. Important in modules that doesn't have the same path as the primery TYpo3 srcipts
 * $TCA				:	The TCA-array
 * $BE_USER			:	The user
 *
 * class t3lib_pageSelect is expected by readPageAccess
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_BEfunc	{

// *****************************
// SQL-related
// ****************************

	function getRecord ($table,$uid,$fields="*",$where="")	{		// Gets record with uid=$uid from $table
		if ($GLOBALS["TCA"][$table])	{
			$del=t3lib_BEfunc::deleteClause($table);
			$query="SELECT ".$fields." FROM ".$table." WHERE uid=".intval($uid).$del.$where;
			$res = mysql(TYPO3_db, $query);
			if ($row = mysql_fetch_assoc($res))	{
				return $row;
			}
		}
	}
	function getRecordRaw($table,$where="",$fields="*")	{		// Gets record with uid=$uid from $table
		$query="SELECT ".$fields." FROM ".$table." WHERE ".$where;
		$res = mysql(TYPO3_db, $query);
		if ($row = mysql_fetch_assoc($res))	{
			return $row;
		}
	}
	function getRecordsByField($theTable,$theField,$theValue,$endClause="")	{
		global $TCA;
		if (is_array($TCA[$theTable])) {
			$del=t3lib_BEfunc::deleteClause($theTable);
			$query = "SELECT * FROM ".$theTable." WHERE ".$theField."='".addslashes($theValue)."'".$del." ".$endClause;
			$res = mysql(TYPO3_db, $query);
			$rows=array();
			while($row = mysql_fetch_assoc($res))	{
				$rows[] = $row;
			}
			if (count($rows))	return $rows;
		}
	}
	function getRecordPath ($uid,$clause,$titleLimit)	{
		// Returns the path of a pagerecord...
		if (!$titleLimit) {$titleLimit=1000;}
		$loopCheck = 100;
		$output="/";
		while ($uid!=0 && $loopCheck>0)	{
			$loopCheck--;
			$query="SELECT pid, title FROM pages WHERE uid=".intval($uid).t3lib_BEfunc::deleteClause("pages")." AND ".$clause;
			$res = mysql(TYPO3_db, $query);
			echo mysql_error();
			if ($row = mysql_fetch_assoc($res))	{
				$uid = $row[pid];
				$output="/".t3lib_div::fixed_lgd(strip_tags($row[title]),$titleLimit).$output;
			} else {
				break;
			}
		}
		return $output;
	}
	function BEgetRootLine ($uid,$clause="")	{		
		// Returns what is called the "RootLine". This is an array with information about title, uid from $uid an back to the root...
		// as default deleted pages are filtered. $clause can be used to select other criteria. It would typically be where-clauses that stops the proces if we meet a page, the user has no reading access to.
		$loopCheck = 100;
		$theRowArray = Array();
		$output=Array();
		while ($uid!=0 && $loopCheck>0)	{
			$loopCheck--;
			$query = "select pid,uid,title,TSconfig,is_siteroot,storage_pid from pages where uid = '$uid' ".t3lib_BEfunc::deleteClause("pages")." ".$clause;
//			debug($query);
			$res = mysql(TYPO3_db, $query);  
			if (mysql_error())	{
				debug($query,1);
				debug(mysql_error(),1);
			}
			if ($row = mysql_fetch_assoc($res))	{
				$uid = $row[pid];
				$theRowArray[]=$row;
			} else {
				break;
			}
		}
		if ($uid==0) {$theRowArray[]=Array("uid"=>0,"title"=>"");}
		if (is_array($theRowArray))	{
			reset($theRowArray);
			$c=count($theRowArray);
			while(list($key,$val)=each($theRowArray))	{
				$c--;
				$output[$c]["uid"]=$val["uid"];
				$output[$c]["title"]=$val["title"];
				$output[$c]["TSconfig"]=$val["TSconfig"];
				$output[$c]["is_siteroot"]=$val["is_siteroot"];
				$output[$c]["storage_pid"]=$val["storage_pid"];
			}
		}
		return $output;
	}
	function getPagesTSconfig($id,$rootLine="",$returnPartArray=0)	{
//debug($id);
		$id=intval($id);
		if (!is_array($rootLine))	{
			$rootLine = t3lib_BEfunc::BEgetRootLine($id,"");
		}
		ksort($rootLine);	// Order correctly, changed 030102
		reset($rootLine);
		$TSdataArray = array();
		$TSdataArray["defaultPageTSconfig"]=$GLOBALS["TYPO3_CONF_VARS"]["BE"]["defaultPageTSconfig"];	// Setting default configuration:
		while(list($k,$v)=each($rootLine))	{
			$TSdataArray["uid_".$v["uid"]]=$v["TSconfig"];
		}
		if ($returnPartArray)	{
			return $TSdataArray;
		}
		
			// Parsing the user TS (or getting from cache)
		$userTS = implode($TSdataArray,chr(10)."[GLOBAL]".chr(10));
		$hash = md5("pageTS:".$userTS);
		$cachedContent = t3lib_BEfunc::getHash($hash,0);
		$TSconfig = array();
		if (isset($cachedContent))	{
			$TSconfig = unserialize($cachedContent);
		} else {
			$parseObj = t3lib_div::makeInstance("t3lib_TSparser");
			$parseObj->parse($userTS);
			$TSconfig = $parseObj->setup;
			t3lib_BEfunc::storeHash($hash,serialize($TSconfig),"PAGES_TSconfig");
		}
		return $TSconfig;
	}
	function updatePagesTSconfig($id,$pageTS,$TSconfPrefix,$impParams="")	{
			// THIS DOES NOT CHECK ANY PERMISSIONS. SHOULD IT?
		$id=intval($id);
		if (is_array($pageTS) && $id>0)	{
			if (!is_array($impParams))	{
//			debug(t3lib_BEfunc::getPagesTSconfig($id));
				$impParams =t3lib_BEfunc::implodeTSParams(t3lib_BEfunc::getPagesTSconfig($id));
	//			debug($impParams);
			}
			reset($pageTS);
			$set=array();
			while(list($f,$v)=each($pageTS))	{
				$f = $TSconfPrefix.$f;
				if ((!isset($impParams[$f])&&trim($v)) || strcmp(trim($impParams[$f]),trim($v)))	{
					$set[$f]=trim($v);
				}
			}
	//			debug($set);
			if (count($set))	{
					// Get page record and TS config lines
				$pRec = t3lib_befunc::getRecord("pages",$id);
				$TSlines = explode(chr(10),$pRec["TSconfig"]);
				$TSlines = array_reverse($TSlines);
					// Reset the set of changes.
				reset($set);
				while(list($f,$v)=each($set))	{
//					$f = $TSconfPrefix.$f;
					reset($TSlines);
					$inserted=0;
					while(list($ki,$kv)=each($TSlines))	{
						if (substr($kv,0,strlen($f)+1)==$f."=")	{
							$TSlines[$ki]=$f."=".$v;
							$inserted=1;
							break;
						}
					}
					if (!$inserted)	{
						$TSlines = array_reverse($TSlines);
						$TSlines[]=$f."=".$v;
						$TSlines = array_reverse($TSlines);
					}
				}
				$TSlines = array_reverse($TSlines);
	//			debug($TSlines);
					// store those changes
				$TSconf = implode(chr(10),$TSlines);
				$q=t3lib_befunc::DBcompileUpdate("pages","uid=".$id,array("TSconfig"=>$TSconf));
				$res=mysql(TYPO3_db,$q);
//				debug($q);
			}
		}
	}
	function makeConfigForm($configArray,$defaults,$dataPrefix)	{
		$params = $defaults;
		if (is_array($configArray))	{
			reset($configArray);
			$lines=array();
			while(list($fname,$config)=each($configArray))	{
				if (is_array($config))	{
					$lines[$fname]='<strong>'.htmlspecialchars($config[1]).'</strong><BR>';
					$lines[$fname].=$config[2]."<BR>";
					switch($config[0])	{
						case "string":
						case "short":
							$formEl = '<input type="text" name="'.$dataPrefix.'['.$fname.']" value="'.$params[$fname].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth($config[0]=="short"?24:48).'>';
						break;
						case "check":
							$formEl = '<input type="hidden" name="'.$dataPrefix.'['.$fname.']" value=0><input type="checkbox" name="'.$dataPrefix.'['.$fname.']" value="1"'.($params[$fname]?" checked":"").'>';
						break;
						case "comment":
							$formEl = '';
						break;
						case "select":
							reset($config[3]);
							$opt=array();
							while(list($k,$v)=each($config[3]))	{
								$opt[]='<option value="'.htmlspecialchars($k).'"'.($params[$fname]==$k?" selected":"").'>'.htmlspecialchars($v).'</option>';
							}
							$formEl = '<select name="'.$dataPrefix.'['.$fname.']">'.implode("",$opt).'</select>';
						break;
						default:
							debug($config);
						break;
					}
					$lines[$fname].=$formEl;
					$lines[$fname].="<BR><BR>";
				} else {
					$lines[$fname]='<HR>';
					if ($config)	$lines[$fname].='<strong>'.strtoupper(htmlspecialchars($config)).'</strong><BR>';
					if ($config)	$lines[$fname].='<BR>';
				}
			}
		}
		$out = implode("",$lines);
		$out.='<input type="submit" name="submit" value="Update configuration">';
		return $out;
	}
	function implodeTSParams($p,$k="")	{
		$implodeParams=array();
		if (is_array($p))	{
			reset($p);
			while(list($kb,$val)=each($p))	{
				if (is_array($val))	{
					$implodeParams = array_merge($implodeParams,t3lib_BEfunc::implodeTSParams($val,$k.$kb));
				} else {
					$implodeParams[$k.$kb]=$val;
				}
			}
		}
		return $implodeParams;
	}
	function getUserNames($fields="username,usergroup,usergroup_cached_list,uid",$where="")	{
		// Returns an array with user records (username, usergroup, uid) of all user NOT DELETED sorted by their username
		$be_user_Array=Array();
		$query = "SELECT ".$fields." FROM be_users WHERE pid=0 ".$where.t3lib_BEfunc::deleteClause("be_users")." ORDER BY username"; 
		$res = mysql(TYPO3_db,$query);
		while($row=mysql_fetch_assoc($res))	{
			$be_user_Array[$row[uid]]=$row;
		}
		return $be_user_Array;
	}
	function getListGroupNames($fields="title,uid")	{
		$exQ=" AND hide_in_lists=0";
		if (!$GLOBALS["BE_USER"]->isAdmin())	{
			$exQ.=" AND uid IN (".($GLOBALS["BE_USER"]->user["usergroup_cached_list"]?$GLOBALS["BE_USER"]->user["usergroup_cached_list"]:0).")";
		}
		return t3lib_BEfunc::getGroupNames($fields,$exQ);
	}
	function getGroupNames($fields="title,uid",$where="")	{
		// Returns an array with group records (title, uid) of all groups NOT DELETED sorted by their title
		$be_group_Array=Array();
		$query = "SELECT title,uid FROM be_groups WHERE pid=0 ".$where.t3lib_BEfunc::deleteClause("be_groups")." ORDER BY title"; 
		$res = mysql(TYPO3_db,$query);
		while($row=mysql_fetch_assoc($res))	{
			$be_group_Array[$row[uid]]=$row;
		}
		return $be_group_Array;
	}
	function blindUserNames($usernames,$groupArray,$excludeBlindedFlag=0)	{
		// Takes $usernames (array made by t3lib_BEfunc::getUserNames()) and a groupArray (array with the groups a certain user is member of)
		// Returns the array $usernames with the names of all users NOT IN $groupArray changed to the uid (hides the usernames!). If excludeBlindedFlag is set, then these records are unset from the array $usernames
		// Is used by the web/perm-submodule
		if (is_array($usernames) && is_array($groupArray))	{
			while(list($uid,$row)=each($usernames))	{
				$userN=$uid;
				$set=0;
				if ($row["uid"]!=$GLOBALS["BE_USER"]->user["uid"])	{
					reset($groupArray);
					while(list(,$v)=each($groupArray))	{
						if ($v && t3lib_div::inList($row["usergroup_cached_list"],$v))	{
							$userN = $row["username"];
							$set=1;
						}
					}
				} else {
					$userN = $row["username"];
					$set=1;
				}
				$usernames[$uid]["username"]=$userN;
				if ($excludeBlindedFlag && !$set) {unset($usernames[$uid]);}
			}
		}
		return $usernames;
	}
	function searchQuery($searchWords,$fields,$option=0)	{
		reset($searchWords);
		$queryParts=array();
		while(list(,$sw)=each($searchWords))	{
			switch($option)	{
				default:
					$like=" LIKE '%".addslashes($sw)."%'";
				break;
			}
			$queryParts[] = implode($like." OR ",$fields).$like;
		}
		$query = "(".implode(") AND (",$queryParts).")";
		return $query ;
	}
	function listQuery($field,$value)	{
		$command=addslashes($value);
		$where="(".$field." LIKE '%,".$command.",%' OR ".$field." LIKE '".$command.",%' OR ".$field." LIKE '%,".$command."' OR ".$field."='".$command."')";
		return $where;
	}	
	function blindGroupNames($groups,$groupArray,$excludeBlindedFlag=0)	{
		// Corresponds to blindUserNames but works for groups instead
		if (is_array($groups) && is_array($groupArray))	{
			while(list($uid,$row)=each($groups))	{
				$groupN=$uid;
				$set=0;
				if (t3lib_div::inArray($groupArray,$uid))	{
					$groupN=$row[title];
					$set=1;
				}
				$groups[$uid]["title"]=$groupN;
				if ($excludeBlindedFlag && !$set) {unset($groups[$uid]);}
			}
		}
		return $groups;
	}
	// IDENTICAL to the function by same name found in t3lib_page:
	function getHash($hash,$expTime)	{
			// if expTime is not set, the hash will never expire
		$expTime = intval($expTime);
		if ($expTime)	{
			$whereAdd = " AND tstamp > ".(time()-$expTime);
		}
		$res = mysql (TYPO3_db, "SELECT content FROM cache_hash WHERE hash = '".$hash."'".$whereAdd);
		if ($row=mysql_fetch_assoc($res))	{
			return $row[content];
		}
	}
	// IDENTICAL to the function by same name found in t3lib_page:
	function storeHash($hash,$data,$ident)	{
			// $ident is just a textual identification in order to inform about the content! May be 20 characters long.
		$res = mysql (TYPO3_db, "DELETE FROM cache_hash WHERE hash = '".$hash."'");
		$res = mysql (TYPO3_db, "INSERT INTO cache_hash (hash, content, ident, tstamp) VALUES ('".$hash."','".addSlashes($data)."','".addSlashes($ident)."','".time()."')");
	}
		
	



// *********************************
// Interface functions	
// *********************************

	function getInterfacePagePositionID($uid)	{
		global $TCA;
			// Finds the Position-ID for this page. This is very handy when we need to update a page in the pagetree in the Typo3 interface.
		$perms_clause = $GLOBALS["BE_USER"]->getPagePermsClause(1);		
		$deleted = $TCA[pages]["ctrl"]["delete"] ? "AND NOT A.".$TCA[pages]["ctrl"]["delete"]." AND NOT pages.".$TCA[pages]["ctrl"]["delete"]." " : "";
		
 		$query="SELECT pages.uid, pages.pid FROM pages A, pages WHERE A.pid=pages.pid AND A.uid = '".$uid."' ".$deleted."AND pages.sorting<=A.sorting AND ".$perms_clause." ORDER BY pages.sorting DESC LIMIT 2";	// This fetches a list of 1 or 2 pages, where - if 2 - the 2nd is the page BEFORE this ($uid). If 1 then the page ($uid) is at the top itself
		$subres = mysql(TYPO3_db,$query);
		echo mysql_error();
		if (mysql_num_rows($subres)==2)	{	// There was a record before
			mysql_data_seek($subres, 1);	// forwards to the second result
			$row=mysql_fetch_assoc($subres);
			return -$row[uid];
		} else {
			$row=mysql_fetch_assoc($subres);
			return $row[pid];
		}
	}
	function pTypes($doktype)	{
		// Returns an array with data for the pageType $doktype.
		// It bases the result on the default data and if any data for the $doktype is found the default data is overwritten
		global $PAGES_TYPES;
		$result = $PAGES_TYPES["default"];
		if (is_array($PAGES_TYPES[$doktype]))	{
			reset ($PAGES_TYPES[$doktype]);
			while(list($key,$val)=each($PAGES_TYPES[$doktype]))	{
				$result[$key]=$val;
			}
		}
		return $result;
	}
	function getExcludeFields()	{
			// Returns an array with the exclude-fields as defined in TCA
		global $TCA;
		$tc_keys = array_keys($TCA);
		$theExcludeArray = Array();
		while (list(,$table)=each($tc_keys))	{
			t3lib_div::loadTCA($table);
			$f_keys = array_keys($TCA[$table]["columns"]);
			while (list(,$field)=each($f_keys))	{
				if ($TCA[$table]["columns"][$field]["exclude"])	{
					if (1!=1)	{
						$Fname=$table.": ".$field;
					} else {
						$Fname=$GLOBALS["LANG"]->sl($TCA[$table]["ctrl"]["title"]).": ".$GLOBALS["LANG"]->sl($TCA[$table]["columns"][$field]["label"]);
					}
					$theExcludeArray[] = Array($Fname , $table.":".$field);
				}
			}
		}
		return $theExcludeArray;
	}
	function getSQLselectableList ($in_list,$tablename,$default_tablename)	{
			// Returns a list of pure integers base on $in_list being a list of records with table-names prepended. 
			// Ex:   pages_4,tt_content_12,45    would result in a list like:  4,45   is $tablename is "pages" and $default_tablename is "pages". $default_tablename denotes what table the number "45" is from (if nothing is prepended on the value)
		$list = Array();
		if ((string)trim($in_list)!="")	{
			$tempItemArray = explode(",",trim($in_list));
			while(list($key,$val)=each($tempItemArray))	{
				$val = strrev($val);
				$parts = explode("_",$val,2);
				if ((string)trim($parts[0])!="")	{
					$theID = intval(strrev($parts[0]));
					$theTable = trim($parts[1]) ? strrev(trim($parts[1])) : $default_tablename;
					if ($theTable==$tablename)	{$list[]=$theID;}
				}
			}
		}
		return implode($list,",");
	}
	function deleteClause($table)	{
			// Returns the proper delete-clause if any for a table from TCA
		global $TCA;
		if ($TCA[$table]["ctrl"]["delete"])	{
			return " AND NOT ".$table.".".$TCA[$table]["ctrl"]["delete"];
		} else {
			return "";
		}
	}
	function mm_query($select,$local_table,$mm_table,$foreign_table,$endClause="")	{
		$query = "SELECT ".$select."
			FROM ".$local_table.",".$mm_table.($foreign_table?",".$foreign_table:"")."
			WHERE ".$local_table.".uid=".$mm_table.".uid_local".($foreign_table?" AND ".$foreign_table.".uid=".$mm_table.".uid_foreign ":" ").$endClause;
		return $query;
	}

	function titleAttribForPages ($row,$perms_clause="",$includeAttrib=1)	{
		global $TCA,$LANG;
		$parts=array();
		$parts[] = 'id='.$row["uid"];
		if ($row["alias"])	$parts[]=$LANG->sL($TCA["pages"]["columns"]["alias"]["label"])." ".$row["alias"];
		if ($row["doktype"]=="3")	{
			$parts[]=$LANG->sL($TCA["pages"]["columns"]["url"]["label"])." ".$row["url"];
		} elseif ($row["doktype"]=="4")	{
			if ($perms_clause)	{
				$label = t3lib_BEfunc::getRecordPath(intval($row["shortcut"]),$perms_clause,20);
			} else {
				$lRec = t3lib_BEfunc::getRecord("pages",intval($row["shortcut"]),"title");
				$label = $lRec["title"];
			}
			$parts[]=$LANG->sL($TCA["pages"]["columns"]["shortcut"]["label"])." ".$label;
		}
		if ($row["hidden"])	$parts[]=$LANG->php3Lang["labels"]["hidden"];
		if ($row["starttime"])	$parts[]=$LANG->sL($TCA["pages"]["columns"]["starttime"]["label"])." ".t3lib_BEfunc::dateTimeAge($row["starttime"],-1,"date");
		if ($row["endtime"])	$parts[]=$LANG->sL($TCA["pages"]["columns"]["endtime"]["label"])." ".t3lib_BEfunc::dateTimeAge($row["endtime"],-1,"date");
		if ($row["fe_group"])	{
			if ($row["fe_group"]<0)	{
				$label = $LANG->sL(t3lib_BEfunc::getLabelFromItemlist("pages","fe_group",$row["fe_group"]));
			} else {
				$lRec = t3lib_BEfunc::getRecord("fe_groups",$row["fe_group"],"title");
				$label = $lRec["title"];
			}
			$parts[]=$LANG->sL($TCA["pages"]["columns"]["fe_group"]["label"])." ".$label;
		}
		$out = htmlspecialchars(implode(" - ",$parts));
		return $includeAttrib ? t3lib_BEfunc::titleAttrib().'="'.$out.'"' : $out;
	}
	function getRecordIconAltText($row,$table="pages")	{
		if ($table=="pages")	{
			$out = t3lib_BEfunc::titleAttribForPages($row,"",0);
		} else {
			$ctrl = $GLOBALS["TCA"][$table]["ctrl"]["enablecolumns"];
			$lang = $GLOBALS["LANG"]->php3Lang["labels"];
	
			$out="id=".$row["uid"];	// Uid is added
			if ($table=="pages" && $row["alias"])	{
				$out.=" / ".$row["alias"];
			}
			if ($ctrl["disabled"])	{		// Hidden ...
				$out.=($row[$ctrl["disabled"]]?" - ".$lang[hidden]:"");
			}
			if ($ctrl["starttime"])	{
				if ($row[$ctrl["starttime"]] > $GLOBALS["EXEC_TIME"])	{
					$out.=" - ".$lang[starttime].":".t3lib_BEfunc::date($row[$ctrl["starttime"]])." (".t3lib_BEfunc::daysUntil($row[$ctrl["starttime"]])." ".$lang[days].")";
				}
			}
			if ($row[$ctrl["endtime"]])	{
				$out.=" - ".$lang[endtime].": ".t3lib_BEfunc::date($row[$ctrl["endtime"]])." (".t3lib_BEfunc::daysUntil($row[$ctrl["endtime"]])." ".$lang[days].")";
			}
		}
		return $out;
	}
	function daysUntil($tstamp)	{
		$delta_t = $tstamp-$GLOBALS["EXEC_TIME"];
		return ceil($delta_t/(3600*24));
	}
	function date($tstamp)	{
		return Date($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["ddmmyy"],$tstamp);
	}
	function datetime($value)	{
		return Date($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["ddmmyy"]." ".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["hhmm"],$value);
	}
	function time($value)	{
		$hh = floor($value/3600);
		$min = floor(($value-$hh*3600)/60);
		$sec = $value-$hh*3600-$min*60;
		$l = sprintf("%02d",$hh).":".sprintf("%02d",$min).":".sprintf("%02d",$sec);
		return $l;
	}	
	function calcAge ($seconds,$labels)	{
		$labelArr = explode("|",$labels);
		$prefix="";
		if ($seconds<0)	{$prefix="-"; $seconds=abs($seconds);}
		if ($seconds<3600)	{
			$seconds = round ($seconds/60).$labelArr[0];
		} elseif ($seconds<24*3600)	{
			$seconds = round ($seconds/3600).$labelArr[1];
		} elseif ($seconds<365*24*3600)	{
			$seconds = round ($seconds/(24*3600)).$labelArr[2];
		} else {
			$seconds = round ($seconds/(365*24*3600)).$labelArr[3];
		}
		return $prefix.$seconds;
	}
	function dateTimeAge($tstamp,$prefix=1,$date="")	{
		return $tstamp ? ($date=="date"?t3lib_BEfunc::date($tstamp):t3lib_BEfunc::datetime($tstamp))." (".t3lib_BEfunc::calcAge($prefix*(time()-$tstamp),$GLOBALS["LANG"]->php3Lang["labels"]["minutesHoursDaysYears"]).")" : "";
	}
	function thumbCode($row,$table,$field,$backPath,$thumbScript="",$uploaddir="",$abs=0,$params="")	{
		global $TCA;
		t3lib_div::loadTCA($table);
		$uploaddir = $uploaddir ? $uploaddir : $TCA[$table]["columns"][$field]["config"]["uploadfolder"];
		$thumbs = explode(",", $row[$field]);
		$thumbData="";
		if (!$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["thumbnails"])	{
			$thumbScript='gfx/notfound_thumb.gif';
		} elseif(!$thumbScript)	{
			$thumbScript="thumbs.php";
		}
		while(list(,$theFile)=each($thumbs))	{
			if (trim($theFile))	{
				$fI = t3lib_div::split_fileref($theFile);
				$ext = $fI["fileext"];
						// New 190201 start
				$max=0;
				if (t3lib_div::inList("gif,jpg,png",$ext)) {
					$imgInfo=@getimagesize(PATH_site.$uploaddir."/".$theFile);
					if (is_array($imgInfo))	{$max = max($imgInfo);}
				}
				if ($max && $max<=56)	{	// 
					$url = $uploaddir."/".trim($theFile);
					$theFile = "../".$url;
					$thumbData.='<a href="#" onClick="top.launchView(\''.$theFile.'\',\'\',\''.$backPath.'\')"><img src="../'.$backPath.$url.'" '.$imgInfo[3].' hspace=2 border=0 title="'.trim($url).'"'.$params.'></a> ';
						// New 190201 stop
				} elseif ($ext=="ttf" || t3lib_div::inList($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],$ext)) {
					$theFile = ($abs?"":"../").$uploaddir."/".trim($theFile);
					$params = "&file=".rawurlencode($theFile);
					$url = $thumbScript.'?&dummy='.$GLOBALS["EXEC_TIME"].$params;
					$thumbData.='<a href="#" onClick="top.launchView(\''.$theFile.'\',\'\',\''.$backPath.'\')"><img src="'.$backPath.$url.'" hspace=2 border=0 title="'.trim($theFile).'"'.$params.'></a> ';
				} else {
					$icon = t3lib_BEfunc::getFileIcon($ext);
					$url = 'gfx/fileicons/'.$icon;
					$thumbData.='<img src="'.$backPath.$url.'" hspace=2 border=0 title="'.trim($theFile).'"'.$params.'> ';
				}
			}
		}
		return $thumbData;
	}
	function getThumbNail($thumbScript,$theFile,$tparams="")	{
		$params = "&file=".rawurlencode($theFile);
		$url = $thumbScript.'?&dummy='.$GLOBALS["EXEC_TIME"].$params;
		$th='<img src="'.$url.'" title="'.trim(basename($theFile)).'"'.($tparams?" ".$tparams:"").'>';
		return $th;
	}
	
// ****************************
// ??
// *****************************	
	

	function readPageAccess($id,$perms_clause)	{
		if ((string)$id!="")	{
			$id=intval($id);
			if (!$id)	{
				if ($GLOBALS["BE_USER"]->isAdmin())	{
					$path="/";
					$pageinfo["_thePath"]=$path;
					return $pageinfo;
				}
			} else {
				$pageinfo = t3lib_BEfunc::getRecord("pages",$id,"*",($perms_clause?" AND ".$perms_clause:""));
				if ($pageinfo["uid"] && $GLOBALS["BE_USER"]->isInWebMount($id,$perms_clause))	{
					$pageinfo["_thePath"]=t3lib_BEfunc::getRecordPath (intval($pageinfo["uid"]),$perms_clause,15);
					return $pageinfo;
				}
			}
		}
		return false;
	}
	function getLabelFromItemlist($table,$col,$key)	{
		global $TCA;
		t3lib_div::loadTCA($table);
		if (is_array($TCA[$table]) && is_array($TCA[$table]["columns"][$col]) && is_array($TCA[$table]["columns"][$col]["config"]["items"]))	{
			reset($TCA[$table]["columns"][$col]["config"]["items"]);
			while(list($k,$v)=each($TCA[$table]["columns"][$col]["config"]["items"]))	{
				if (!strcmp($v[1],$key))	return $v[0];
			}
		}
	}
	function getItemLabel($table,$col,$printAllWrap="")	{
		global $TCA;
		t3lib_div::loadTCA($table);
		if (is_array($TCA[$table]) && is_array($TCA[$table]["columns"][$col]))	{
			return stripslashes($TCA[$table]["columns"][$col]["label"]);
		}
		if ($printAllWrap)	{
			$parts = explode("|",$printAllWrap);
			return $parts[0].$col.$parts[1];
		}
	}
	function getRecordTitle($table,$row,$prep=0)	{
		global $TCA;
		if (is_array($TCA[$table]))	{
			$t = $row[$TCA[$table]["ctrl"]["label"]];
			if ($TCA[$table]["ctrl"]["label_alt"] && ($TCA[$table]["ctrl"]["label_alt_force"] || !strcmp($t,"")))	{
				$altFields=t3lib_div::trimExplode(",",$TCA[$table]["ctrl"]["label_alt"],1);
				$tA=array();
				$tA[]=$t;
				while(list(,$fN)=each($altFields))	{
					$t = $tA[] = trim(strip_tags($row[$fN]));
					if (strcmp($t,"") && !$TCA[$table]["ctrl"]["label_alt_force"])	break;
				}
				if ($TCA[$table]["ctrl"]["label_alt_force"])	$t=implode(", ",$tA);
			}
			if ($prep) 	{
				$t=htmlspecialchars(t3lib_div::fixed_lgd($t,$GLOBALS["BE_USER"]->uc["titleLen"]));
				if (!strcmp(trim($t),""))	$t="<em>[".$GLOBALS["LANG"]->php3Lang["labels"]["no_title"]."]</em>";
			}
			return $t;
		}
	}
	function getFileIcon($ext)	{
		return $GLOBALS["FILEICONS"][$ext] ? $GLOBALS["FILEICONS"][$ext] : $GLOBALS["FILEICONS"]["default"];
	}
	function getProcessedValue($table,$col,$value,$fixed_lgd_chars=0,$defaultPassthrough=0)	{
		global $TCA;
		t3lib_div::loadTCA($table);
		if (is_array($TCA[$table]) && is_array($TCA[$table]["columns"][$col]))	{
			$theColConf = $TCA[$table]["columns"][$col]["config"];
			$l="";
			switch((string)$theColConf["type"])	{
				case "radio":
					$l=t3lib_BEfunc::getLabelFromItemlist($table,$col,$value);
				break;
				case "select":
					if ($theColConf["MM"])	{
						$l="N/A";
					} else {
						$l=t3lib_BEfunc::getLabelFromItemlist($table,$col,$value);
						$l=$GLOBALS["LANG"]->sL($l);
						if ($theColConf["foreign_table"] && !$l && $TCA[$theColConf["foreign_table"]])	{
							$rParts = t3lib_div::trimExplode(",",$value,1);
							reset($rParts);
							$lA=array();
							while(list(,$rVal)=each($rParts))	{
								$rVal = intval($rVal);
								if ($rVal>0) {
									$r=t3lib_BEfunc::getRecord($theColConf["foreign_table"],$rVal);
								} else {
									$r=t3lib_BEfunc::getRecord($theColConf["neg_foreign_table"],-$rVal);
								}
								if (is_array($r))	{
									$lA[]=$GLOBALS["LANG"]->sL($rVal>0?$theColConf["foreign_table_prefix"]:$theColConf["neg_foreign_table_prefix"]).t3lib_BEfunc::getRecordTitle($rVal>0?$theColConf["foreign_table"]:$theColConf["neg_foreign_table"],$r);
								} else {
									$lA[]=$rVal?"[".$rVal."!]":"";
								}
							}
							$l=implode(",",$lA);
						}
					}
				break;
				case "check":
					if (!is_array($theColConf["items"]) || count($theColConf["items"])==1)	{
						$l = $value ? "Yes" : "";
					} else {
						reset($theColConf["items"]);
						$lA=Array();
						while(list($key,$val)=each($theColConf["items"]))	{
							if ($value & pow(2,$key))	{$lA[]=$GLOBALS["LANG"]->sL($val[0]);}
						}
						$l = implode($lA,", ");
					}
				break;
				case "input":
					if ($value)	{
						if (t3lib_div::inList($theColConf["eval"],"date"))	{
							$l = t3lib_BEfunc::date($value)." (".(time()-$value>0?"-":"").t3lib_BEfunc::calcAge(abs(time()-$value), $GLOBALS["LANG"]->php3Lang["labels"]["minutesHoursDaysYears"]).")";
						} elseif (t3lib_div::inList($theColConf["eval"],"time"))	{
							$l = t3lib_BEfunc::time($value);
						} elseif (t3lib_div::inList($theColConf["eval"],"datetime"))	{
							$l = t3lib_BEfunc::datetime($value);
						} else {
							$l = $value;
						}
					}
				break;
				default:
					if ($defaultPassthrough)	{
						$l=$value;
					} elseif ($theColConf["MM"])	{
						$l="N/A";
					} elseif ($value)	{
						$l=t3lib_div::fixed_lgd(strip_tags($value),200);
					}
				break;
			}
			if ($fixed_lgd_chars)	{
				return t3lib_div::fixed_lgd($l,$fixed_lgd_chars);
			} else {
				return $l;
			}
		}
	}
	function getProcessedValueExtra($table,$fN,$fV,$fixed_lgd_chars=0)	{
		global $TCA;
		$fVnew = t3lib_BEfunc::getProcessedValue($table,$fN,$fV,$fixed_lgd_chars);
		if (!isset($fVnew))	{
			if (is_array($TCA[$table]))	{
				if ($fN==$TCA[$table]["ctrl"]["tstamp"] || $fN==$TCA[$table]["ctrl"]["crdate"])	{
					$fVnew = t3lib_BEfunc::datetime($fV);
				} elseif ($fN=="pid"){
					$fVnew = t3lib_BEfunc::getRecordPath ($fV,"1",20);	// Fetches the path with no regard to the users permissions to select pages.
				} else {
					$fVnew = $fV;
				}
			}
		} 
		return $fVnew;
	}
	function getTCAtypeValue($table,$rec)	{
		global $TCA;
		t3lib_div::loadTCA($table);
		if ($TCA[$table])	{
			$field=$TCA[$table]["ctrl"]["type"];
			$fieldValue = $field?($rec[$field]?$rec[$field]:0):0;
			if (!is_array($TCA[$table]["types"][$fieldValue]))	$fieldValue=1;
			return $fieldValue;
		}
	}
	function getTCAtypes($table,$rec,$useFieldNameAsKey=0)	{
		global $TCA;
		// If no field-value, set it to zero. If there is no type matching the field-value (which now may be zero...) test field-value "1" as default.
		t3lib_div::loadTCA($table);
		if ($TCA[$table])	{
			$fieldValue = t3lib_BEfunc::getTCAtypeValue($table,$rec);
//			$field=$TCA[$table]["ctrl"]["type"];
//			$fieldValue = $field?($rec[$field]?$rec[$field]:0):0;
//			if (!is_array($TCA[$table]["types"][$fieldValue]))	=1;
			$typesConf = $TCA[$table]["types"][$fieldValue];
				// Get fields list and traverse it
			$fieldList = explode(",",$typesConf["showitem"]);
			$altFieldList=array();
			reset($fieldList);
			while(list($k,$v)=each($fieldList))	{
				$vParts=explode(";",$v);
				$specConfParts = t3lib_BEfunc::getSpecConfParts($vParts[3]);
				$fieldList[$k]=array(
					"field"=>trim($vParts[0]),
					"title"=>trim($vParts[1]),
					"palette"=>trim($vParts[2]),
					"spec"=>$specConfParts,
					"origString"=>$v
				);
				if ($useFieldNameAsKey)	{
					$altFieldList[$fieldList[$k]["field"]]=$fieldList[$k];
				}
			}
			if ($useFieldNameAsKey)	$fieldList=$altFieldList;
			return $fieldList;
		}
	}
	function getSpecConfParts($str)	{
		if (trim($str))	{
			$specConfParts=explode(":",$str);
			reset($specConfParts);
			while(list($k2,$v2)=each($specConfParts))	{
				if (ereg("(.*)\[(.*)\]",$v2,$reg))	{
					unset($specConfParts[$k2]);
					$specConfParts[$reg[1]]=array(
						"parameters"=>explode("|",$reg[2])
					);
				}
			}
		} else {$specConfParts=array();}
		return $specConfParts;
	}
	function getSpecConfParametersFromArray($pArr)	{
		$out=array();
		if (is_array($pArr))	{
			reset($pArr);
			while(list($k,$v)=each($pArr))	{
				$parts=explode("=",$v,2);
				if (count($parts)==2)	{
					$out[trim($parts[0])]=trim($parts[1]);
				} else {
					$out[$k]=$v;
				}
			}
		}
		return $out;
	}
	function getListOfBackendModules($name,$perms_clause,$backPath="",$script="index.php")	{
		$query = "SELECT * FROM pages where doktype!=255 AND module IN ('".$name."') AND".$perms_clause.t3lib_BEfunc::deleteClause("pages");
		$res = mysql(TYPO3_db,$query);
		if (!mysql_num_rows($res))	return false;
		$out="";
		$theRows=array();
		while($row=mysql_fetch_assoc($res))	{
			$theRows[]=$row;
			$out.='<nobr><a href="'.$script.'?id='.$row[uid].'"><img src="'.$backPath.t3lib_iconWorks::getIcon("pages",$row).'" width=18 height=16 border=0 title="'.htmlspecialchars(t3lib_BEfunc::getRecordPath ($row["uid"],$perms_clause,20)).'" align=top>'.$row["title"].'</a></nobr><BR>';
		}
		return array("rows"=>$theRows,"list"=>$out);
	}	
	function getModuleData($MOD_MENU, $CHANGED_SETTINGS, $modName, $type="", $dontValidateList="", $setDefaultList="")	{
			// MOD_MENU is an array that defines the options in menus. 
			// CHANGED_SETTINGS represents the array used when passing values to the script from the menus.
			// modName is the name of this module. Used to get the correct module data.
			// Returns: The array $settings, which holds a key for each MOD_MENU key and the values of each key will be within the range of values for each menuitem
			// If a key from MOD_MENU is set in the CHANGED_SETTINGS array (eg. a value is passed to the script from the outside), this value is put into the settings-array
			// If type is "ses" then the data is stored as session-lasting data. This means that it'll be wiped out the next time the user logs in.
			// dontValidateList can be used to list variables that should not be checked if their value is found in the MOD_MENU array. Used for dynamically generated menus.

		if ($modName && is_string($modName))	{
					// GETTING stored user-data from this module:
			$settings = $GLOBALS["BE_USER"]->getModuleData($modName,$type);
	
			$changed=0;
			if (!is_array($settings))	{
				$changed=1;
				$settings=array();
			}
			if (is_array($MOD_MENU))	{
				reset($MOD_MENU);
				while(list($key,$var)=each($MOD_MENU))	{
						// If a global var is set before entering here. eg if submitted, then it's substituting the current value the array.
					if (is_array($CHANGED_SETTINGS) && isset($CHANGED_SETTINGS[$key]) && strcmp($settings[$key],$CHANGED_SETTINGS[$key]))	{		
						$settings[$key] = (string)$CHANGED_SETTINGS[$key];
						$changed=1;
					}
						// If the $var is an array, which denotes the existence of a menu, we check if the value is permitted
					if (is_array($var) && (!$dontValidateList || !t3lib_div::inList($dontValidateList,$key)))	{
							// If the setting is an array or not present in the menu-array, MOD_MENU, then the default value is inserted.
						if (is_array($settings[$key]) || !isset($MOD_MENU[$key][$settings[$key]]))	{
							$settings[$key]=(string)key($var);
							$changed=1;
						}
					}
					if ($setDefaultList && !is_array($var))	{	// Sets default values (only strings/chekcboxes, not menus)
						if (t3lib_div::inList($setDefaultList,$key) && !isset($settings[$key]))	{
							$settings[$key]=$var;
						}
					}
				}
			} else {die ("No menu!");}
	
			if ($changed)	{
		//		debug("write!");
				$GLOBALS["BE_USER"]->pushModuleData($modName,$settings);
			}
			
			return  $settings;
		} else {die ("Wrong module name: '".$modName."'");}
	}
	function getTSconfig_pidValue($table,$uid,$pid)	{
			// Find the real PID of the record. This MAY be impossible if the pid is set as a reference to the former record or a page (if two records are created at one time). 
		if (t3lib_div::testInt($pid))	{	// If pid is an integer this takes precedence in our lookup.
			$thePidValue = intval($pid);
			if ($thePidValue<0)	{	// If ref to another record, look that record up.
				$pidRec = t3lib_BEfunc::getRecord($table,abs($thePidValue),"pid");
//debug("lookup <0");
				$thePidValue= is_array($pidRec) ? $pidRec["pid"] : -2;	// Returns -2 if the record did not exist.
			}
			// ... else the pos/zero pid is just returned here.
		} else {	// No integer pid and we are forced to look up the $pid
			$rr = t3lib_BEfunc::getRecord($table,$uid,"pid");	// Try to fetch the record pid from uid. If the uid is "NEW..." then this will of course return nothing...
//debug("lookup rec");
			if (is_array($rr))	{
				$thePidValue = $rr["pid"];	// Returning the "pid" of the record
			} else $thePidValue=-1;	// Returns -1 if the record with the pid was not found.
		}
		return $thePidValue;
	}
	function getPidForModTSconfig($table,$uid,$pid)	{
		$retVal = ($table=="pages" && t3lib_div::testInt($uid)) ? $uid : $pid;
		return $retVal;
	}
	function getTSCpid($table,$uid,$pid)	{
			// Returns the REAL pid of the record, if possible. If both $uid and $pid is strings, then pid=-1 is returned as an error indication.
			// If pid is negative (referring to another record) the pid of the other record is fetched and returned.
		$cPid = t3lib_BEfunc::getTSconfig_pidValue($table,$uid,$pid);	
			// $TScID is the id of $table=pages, else it's the pid of the record.
		$TScID = t3lib_BEfunc::getPidForModTSconfig($table,$uid,$cPid);
//debug(array(array($table,$uid,$pid),array($TScID,$cPid)));
		return array($TScID,$cPid);
	}
	function getModTSconfig($id,$TSref)	{
		$pageTS_modOptions = $GLOBALS["BE_USER"]->getTSConfig($TSref,t3lib_BEfunc::getPagesTSconfig($id));
		$BE_USER_modOptions = $GLOBALS["BE_USER"]->getTSConfig($TSref);
		$modTSconfig = t3lib_div::array_merge_recursive_overrule($pageTS_modOptions,$BE_USER_modOptions);
		return $modTSconfig;
	}
	function unsetMenuItems($modTSconfig,$itemArray,$TSref)	{
			// Getting TS-config options for this module for the Backend User:
		$conf = $GLOBALS["BE_USER"]->getTSConfig($TSref,$modTSconfig);
		if (is_array($conf["properties"]))	{
			reset($conf["properties"]);
			while(list($key,$val)=each($conf["properties"]))	{
				if (!$val)	{
					unset($itemArray[$key]);
				}
			}
		}
		return $itemArray;
	}
	function getFuncMenu($id,$elementName,$currentValue,$menuItems,$script="",$addparams="")	{
		if (is_array($menuItems))	{
			if (!$script) {basename(PATH_thisScript);}
			$options="";
			reset($menuItems);
			while(list($value,$label)=each($menuItems))	{
				$options.='<option value="'.$value.'"'.(!strcmp($currentValue,$value)?" selected":"").'>'.$label.'</option>';
			}
			if ($options)	{
				return '<select name="'.$elementName.'" onChange="jumpToUrl(\''.$script.'?id='.$id.$addparams.'&'.$elementName.'=\'+this.options[this.selectedIndex].value,this);">'.$options.'</select>';
			}
		}
	}
	function getFuncCheck($id,$elementName,$currentValue,$script="",$addparams="",$tagParams="")	{
		if (!$script) {basename(PATH_thisScript);}
		return '<input type="Checkbox" name="'.$elementName.'"'.($currentValue?" checked":"").' onClick="jumpToUrl(\''.$script.'?id='.$id.$addparams.'&'.$elementName.'=\'+(this.checked?1:0),this);"'.($tagParams?" ".$tagParams:"").'>';
	}
	function getFuncInput($id,$elementName,$currentValue,$size=10,$script="",$addparams="")	{
		if (!$script) {basename(PATH_thisScript);}
		return '<input type="Text"'.$GLOBALS["TBE_TEMPLATE"]->formWidth($size).' name="'.$elementName.'" value="'.htmlspecialchars($currentValue).'" onChange="jumpToUrl(\''.$script.'?id='.$id.$addparams.'&'.$elementName.'=\'+escape(this.value),this);">';
	}
	function processParams($params)	{
		$paramArr=array();
		$lines=explode(chr(10),$params);
		while(list(,$val)=each($lines))	{
			$val = trim($val);
			if ($val)	{
				$pair = explode("=",$val,2);
				$paramArr[trim($pair[0])] = trim($pair[1]);
			}
		}
		return $paramArr;
	}	
	function typo3PrintError ($header,$text,$js="",$head=1)	{
		// This prints out a Typo3 error message.
		// If $js is set the message will be output in JavaScript
		if ($js)	{
			echo"alert('".t3lib_div::slashJS($header.'\n'.$text)."');";
		} else {
			echo $head?'<html><head><title>Error!</title></head><body bgcolor="#cccccc" topmargin=0 leftmargin=0 marginwidth=0 marginheight=0>':'';
			echo '<div align="center"><table border=0 cellspacing=0 cellpadding=0 width=333><tr><td>'.($GLOBALS["TBE_STYLES"]["logo_login"]?'<img src="'.$GLOBALS["BACK_PATH"].$GLOBALS["TBE_STYLES"]["logo_login"].'">':'<img src="'.$GLOBALS["BACK_PATH"].'t3lib/typo3logo.gif" width=333 height=43 vspace=10>').'</td></tr><tr><td bgcolor="black"><table width="100%" border=0 cellspacing=1 cellpadding=10><tr><td bgcolor=#F4F0E8><FONT FACE="verdana,arial,helvetica" size=2>';
			echo '<B><center><font size="+1">'.$header.'</font></center></b><BR>'.$text;
			echo '</font></td></tr></table></td></tr></table></div>';
			echo $head?'</body></html>':'';
		}
	}
	function getPathType_web_nonweb($path)	{
		return t3lib_div::isFirstPartOfStr($path,$GLOBALS["HTTP_SERVER_VARS"]["DOCUMENT_ROOT"]) ? "web" : "";
	}
	function DBcompileInsert($table,$fields_values,$slash=1)	{
		if (is_array($fields_values))	{
			if ($slash)	{$fields_values = t3lib_div::slashArray($fields_values, "add");}
			$query = "INSERT INTO ".$table." (".implode(array_keys($fields_values),",").") VALUES ('".implode($fields_values,"','")."')";
			return $query;
		}
	}
	function DBcompileUpdate($table,$where,$fields_values,$slash=1)	{
		if (is_array($fields_values))	{
			if ($slash)	{$fields_values = t3lib_div::slashArray($fields_values, "add");}
			$nArr=array();
			reset($fields_values);
			while(list($k,$v)=each($fields_values))	{
				$nArr[]=$k."='".$v."'";
			}
			$query = "UPDATE ".$table." SET ".implode(",",$nArr)." WHERE ".$where;
			return $query;
		}
	}
	function loadTablesDescriptions($langKey="",$dontGetFromCache=0,$storeInCache=1)	{
		$hash = md5("loadTablesDescriptions:".$langKey);
$dontGetFromCache=1;
		if (!$dontGetFromCache)	{
			$TCA_DESCR = unserialize(t3lib_BEfunc::getHash($hash,0));
		}
		if (!is_array($TCA_DESCR))	{
				// Include ext-language if present (always in typo3conf/):

			if (defined("TYPO3_extTableDef_script") && TYPO3_extTableDef_script)	{	// If "TYPO3_extTableDef_script" is empty PHP4.03 crashed, so must be checked here.
				$pI=pathinfo(TYPO3_extTableDef_script);
				$descrScript=substr(TYPO3_extTableDef_script,0,-strlen(".".$pI["extension"]))."_descr";
					// Include the description file:
				$sPath=PATH_typo3conf.$descrScript.".".$pI["extension"];
				if (@is_file($sPath))	include ($sPath);
			}
				// ADD language if present
			if (is_array($TCA_DESCR) && $langKey)	{
					// language array name:
				$varName = "TCA_DESCR_".strtoupper($langKey);
	
					// If a language key is defined, include the language file too:
				$lsPath = PATH_typo3conf.$descrScript.".".$langKey.".".$pI["extension"];
				if (@is_file($lsPath))	{include ($lsPath);	}
			
					// If the outcome of this inclusion resulted in the presence of a language array, merge the two:
				if (is_array($$varName))	{
					$TCA_DESCR = t3lib_div::array_merge_recursive_overrule($TCA_DESCR,$$varName);
				}
			}
				// Make sure is array:
			if (!is_array($TCA_DESCR))	{
				$TCA_DESCR=array();
			}
				// Cache it:
			if ($storeInCache)	{
				t3lib_BEfunc::storeHash($hash,serialize($TCA_DESCR),"loadTablesDescriptions");
			}
		}
		return $TCA_DESCR;
	}
	function loadSingleTableDescription($table,$LANG)	{
//		$GLOBALS["LANG"]->lang!="default"?$GLOBALS["LANG"]->lang:""
		global $TCA_DESCR;
		if (!isset($TCA_DESCR[$table]))	{
			if ($LANG && $LANG!="default")	{
				$langKey="_".$LANG;
				$query = "SELECT 
						A.*,
						B.description".$langKey.",
						B.details".$langKey.",
						B.syntax".$langKey.",
						B.image_descr".$langKey."
					FROM 
						sys_tabledescr AS A LEFT JOIN sys_tabledescr".$langKey." AS B
					ON 
						A.tablename=B.tablename AND 
						A.fieldname=B.fieldname
					WHERE 
						A.tablename='".$table."'
				";
				$res = @mysql(TYPO3_db,$query);
				$default=0;
			} else {$default=1;}

			if ($default || mysql_error())	{
				$langKey="";
				$query = "SELECT * FROM sys_tabledescr WHERE 
					sys_tabledescr.tablename='".$table."'
				";
				$res = @mysql(TYPO3_db,$query);
			}
			if (!mysql_error())	{
				while($row=mysql_fetch_assoc($res))	{
	//				debug($row);
					$TCA_DESCR[$table]["columns"][$row["fieldname"]] = Array (
						"description" => nl2br(trim(trim($row["description".$langKey])?$row["description".$langKey]:$row["description"])),
						"details" => nl2br(trim(trim($row["details".$langKey])?$row["details".$langKey]:$row["details"])),
						"syntax" => nl2br(trim(trim($row["syntax".$langKey])?$row["syntax".$langKey]:$row["syntax"])),
						"image_descr" => nl2br(trim(trim($row["image_descr".$langKey])?$row["image_descr".$langKey]:$row["image_descr"])),
						"image" => $row["image"],
						"seeAlso" => $row["seeAlso"]
					);
				}
			}

				// Local overlay:
			$query = "SELECT * FROM sys_tabledescr_local WHERE 
				sys_tabledescr_local.tablename='".$table."'
			";
			$res = @mysql(TYPO3_db,$query);
			while($row=mysql_fetch_assoc($res))	{
				if ($row["mode"]==2)	{
					unset($TCA_DESCR[$table]["columns"][$row["fieldname"]]);
				} else {
					if ($row["mode"]==1)	{$TCA_DESCR[$table]["columns"][$row["fieldname"]]=array();}
					if (trim($row["description"]))  $TCA_DESCR[$table]["columns"][$row["fieldname"]]["description"] = nl2br(trim($row["description"]));
					if (trim($row["details"]))  $TCA_DESCR[$table]["columns"][$row["fieldname"]]["details"] = nl2br(trim($row["details"]));
					if (trim($row["syntax"]))  $TCA_DESCR[$table]["columns"][$row["fieldname"]]["syntax"] = nl2br(trim($row["syntax"]));
					if (trim($row["image_descr"]))  $TCA_DESCR[$table]["columns"][$row["fieldname"]]["image_descr"] = nl2br(trim($row["image_descr"]));
					if (trim($row["image"]))  $TCA_DESCR[$table]["columns"][$row["fieldname"]]["image"] = $row["image"];
					if (trim($row["seeAlso"]))  $TCA_DESCR[$table]["columns"][$row["fieldname"]]["seeAlso"] = $row["seeAlso"];
				}
			}
		}
	}
	/**
	 * Returns help-text icon if configured for.
	 */
	function helpTextIcon($table,$field,$BACK_PATH,$force=0)	{
		global $TCA_DESCR,$BE_USER;
		if ($TCA_DESCR[$table]["columns"][$field] && ($BE_USER->uc["edit_showFieldHelp"]=="icon" || $force))	{
			return '<a href="#" onClick="vHWin=window.open(\''.$BACK_PATH.'view_help.php?tfID='.($table.".".$field).'\',\'viewFieldHelp\',\'height=300,width=250,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="'.$BACK_PATH.'gfx/helpbubble.gif" width="14" height="14" hspace=2 border=0 align=absmiddle'.($GLOBALS["CLIENT"]["FORMSTYLE"]?' style="cursor:help;"':'').'></a>';
		}
	}

	/**
	 * Returns help text, if configured for.
	 */
	function helpText($table,$field,$BACK_PATH)	{
		global $TCA_DESCR,$BE_USER;
		if ($TCA_DESCR[$table]["columns"][$field] && $BE_USER->uc["edit_showFieldHelp"]=="text")	{
			$fDat = $TCA_DESCR[$table]["columns"][$field];
			return '<table border=0 cellpadding=2 cellspacing=0 width=90%><tr><td valign=top width=14>'.t3lib_BEfunc::helpTextIcon($table,$field,$BACK_PATH,
				$fDat["details"]||$fDat["syntax"]||$fDat["image_descr"]||$fDat["image"]||$fDat["seeAlso"]
				).'</td><td valign=top>'.$fDat["description"].'</td></tr></table>';		
		}
	}
	
	function splitTable_Uid($str)	{
		list($uid,$table)=explode("_",strrev($str),2);
		return array(strrev($table),strrev($uid));
	}
	function editOnClick($params,$backPath="",$requestUri="",$force=0)	{
		if ($force || $GLOBALS["BE_USER"]->uc["alternativeBackend"] || $GLOBALS["BE_USER"]->uc["localFrameEdit"] || $GLOBALS["AB"])	{// AB is the global var indicating "AlternativeBackend" mode.
			$retUrl = "returnUrl=".($requestUri==-1?"'+T3_THIS_LOCATION+'":rawurlencode($requestUri?$requestUri:getenv("REQUEST_URI")));
			return "document.location='".$backPath."alt_doc.php?".$retUrl.$params."'; return false;";
		} else {
			return "top.editWin.edit('".$params."','".$backPath."'); return false;";
		}
	}
	function viewOnClick($id,$backPath="",$rootLine="",$anchor="")	{
		if ($rootLine)	{
			$parts = parse_url("http://".t3lib_BEfunc::siteUrl());
			if (t3lib_BEfunc::getDomainStartPage($parts["host"],$parts["path"]))	{
				$preUrl_temp = t3lib_BEfunc::firstDomainRecord($rootLine);	
			}
		}
		$preUrl = $preUrl_temp ? "http://".$preUrl_temp : $backPath."..";
//		debug($preUrl);
		return "previewWin=window.open('".$preUrl."/index.php?id=".$id.$anchor."','newTypo3FrontendWindow','status=1,menubar=1,resizable=1,location=1,scrollbars=1,toolbar=1');previewWin.focus();";
	}
	function ADMCMD_previewCmds($pageinfo)	{
		if ($pageinfo["fe_group"]>0)	{
			$simUser = "&ADMCMD_simUser=".$pageinfo["fe_group"];
		}
		if ($pageinfo["starttime"]>time())	{
			$simTime = "&ADMCMD_simTime=".$pageinfo["starttime"];
		}
		if ($pageinfo["endtime"]<time() && $pageinfo["endtime"]!=0)	{
			$simTime = "&ADMCMD_simTime=".($pageinfo["endtime"]-1);
		}
		return $simUser.$simTime;
	}
	function firstDomainRecord($rootLine)	{
		reset($rootLine);
		while(list(,$row)=each($rootLine))	{
			$dRec = t3lib_BEfunc::getRecordsByField("sys_domain","pid",$row["uid"]," AND redirectTo='' AND hidden=0 ORDER BY sorting");
			if (is_array($dRec))	{
				reset($dRec);
				$dRecord = current($dRec);
				return ereg_replace("\/$","",$dRecord["domainName"]);
			}
		}
	}
	function getDomainStartPage($domain, $path="")	{
		$domain = explode(":",$domain);
		$domain = strtolower(ereg_replace("\.$","",$domain[0]));
			// path is calculated.
		$path = trim(ereg_replace("\/[^\/]*$","",$path));
			// stuff:
		$domain.=$path;
		
		$query = "SELECT sys_domain.*".
			"FROM pages,sys_domain where pages.uid=sys_domain.pid 
			AND NOT sys_domain.hidden 
			AND (sys_domain.domainName='".addSlashes($domain)."' or sys_domain.domainName='".addSlashes($domain."/")."') ".
			t3lib_BEfunc::deleteClause("pages").
			" LIMIT 1";
		$res = mysql(TYPO3_db, $query);
		echo mysql_error();
		return mysql_fetch_assoc($res);
	}
	function siteUrl()	{
		$lPath = substr(dirname(PATH_thisScript),strlen(PATH_site))."/";
		$url = t3lib_div::getThisUrl();
		$siteUrl = substr($url,0,-strlen($lPath));
		if (substr($siteUrl,-1)!="/")	$siteUrl.="/";
		return $siteUrl;
	}
	function RTEsetup($RTEprop,$table,$field,$type="")	{
//debug(array($RTEprop,$table,$field,$type));
		$thisConfig = is_array($RTEprop["default."]) ? $RTEprop["default."] : array();
		$thisFieldConf = $RTEprop["config."][$table."."][$field."."];
		if (is_array($thisFieldConf))	{
			unset($thisFieldConf["types."]);
			$thisConfig = t3lib_div::array_merge_recursive_overrule($thisConfig,$thisFieldConf);
		}
		if ($type && is_array($RTEprop["config."][$table."."][$field."."]["types."][$type."."]))	{
			$thisConfig = t3lib_div::array_merge_recursive_overrule($thisConfig,$RTEprop["config."][$table."."][$field."."]["types."][$type."."]);
		}
		return $thisConfig;
	}
	function titleAttrib($content="",$hsc=0)	{
		global $CLIENT;
		$attrib= ($CLIENT["BROWSER"]=="net"&&$CLIENT["VERSION"]<6)||$CLIENT["BROWSER"]=="konqu" ? "alt" : "title";
		return strcmp($content,"")?' '.$attrib.'="'.($hsc?htmlspecialchars($content):$content).'"' : $attrib;
	}
	function lockRecords($table="",$uid=0,$pid=0)	{
		$user_id = intval($GLOBALS["BE_USER"]->user["uid"]);
		if ($table && $uid)	{
			$fields_values=array(
				"userid"=>$user_id,
				"tstamp"=>$GLOBALS["EXEC_TIME"],
				"record_table"=>$table,
				"record_uid"=>$uid,
				"username"=>$GLOBALS["BE_USER"]->user["username"],
				"record_pid"=>$pid
			);
			$query=t3lib_BEfunc::DBcompileInsert("sys_lockedrecords",$fields_values);
		} else {
			$query="DELETE FROM sys_lockedrecords WHERE userid=".$user_id;
		}
//		debug($query);
		$res = mysql(TYPO3_db,$query);
	}
	function isRecordLocked($table,$uid,$msg=1)	{
		global $LOCKED_RECORDS;
		if (!is_array($LOCKED_RECORDS))	{
			$query="SELECT * FROM sys_lockedrecords WHERE ".
				"sys_lockedrecords.userid!=".intval($GLOBALS["BE_USER"]->user["uid"]).
				" AND sys_lockedrecords.tstamp > ".($GLOBALS["EXEC_TIME"]-2*3600);
			$res = mysql(TYPO3_db,$query);
			while($row=mysql_fetch_assoc($res))	{
				$LOCKED_RECORDS[$row["record_table"].":".$row["record_uid"]]=$row;
				$LOCKED_RECORDS[$row["record_table"].":".$row["record_uid"]]["msg"]=sprintf(
					$GLOBALS["LANG"]->php3Lang["labels"]["lockedRecord"],
					$row["username"],
					t3lib_BEfunc::calcAge($GLOBALS["EXEC_TIME"]-$row["tstamp"],$GLOBALS["LANG"]->php3Lang["labels"]["minutesHoursDaysYears"])
				);
				if ($row["record_pid"] && !isset($LOCKED_RECORDS[$row["record_table"].":".$row["record_pid"]]))	{
					$LOCKED_RECORDS["pages:".$row["record_pid"]]["msg"]=sprintf(
						$GLOBALS["LANG"]->php3Lang["labels"]["lockedRecord_content"],
						$row["username"],
						t3lib_BEfunc::calcAge($GLOBALS["EXEC_TIME"]-$row["tstamp"],$GLOBALS["LANG"]->php3Lang["labels"]["minutesHoursDaysYears"])
					);
				}
			}
		}
		return $LOCKED_RECORDS[$table.":".$uid];
	}
	function getCommonSelectFields($table,$prefix)	{
		global $TCA;
		$fields=array();
		$fields[]=$prefix."uid";
		$fields[]=$prefix.$TCA[$table]["ctrl"]["label"];
		if ($TCA[$table]["ctrl"]["label_alt"])	{
			$secondFields = t3lib_div::trimExplode(",",$TCA[$table]["ctrl"]["label_alt"],1);
			while(list(,$fieldN)=each($secondFields))	{
				$fields[]=$prefix.$fieldN;
			}
		}
		if ($TCA[$table]["ctrl"]["selicon_field"])	$fields[]=$prefix.$TCA[$table]["ctrl"]["selicon_field"];
		return implode(",",$fields);
	}
	function foreign_table_where_query($fieldValue,$field="",$TSconfig=array(),$prefix="")	{
		global $TCA;
		$foreign_table = $fieldValue["config"][$prefix."foreign_table"];
		$rootLevel = $TCA[$foreign_table]["ctrl"]["rootLevel"];

		$fTWHERE = $fieldValue["config"][$prefix."foreign_table_where"];
		if (strstr($fTWHERE,"###REC_FIELD_"))	{
			$fTWHERE_parts = explode("###REC_FIELD_",$fTWHERE);
			while(list($kk,$vv)=each($fTWHERE_parts))	{
				if ($kk)	{
					$fTWHERE_subpart = explode("###",$vv,2);
					$fTWHERE_parts[$kk]=$TSconfig["_THIS_ROW"][$fTWHERE_subpart[0]].$fTWHERE_subpart[1];
				}
			}
			$fTWHERE = implode("",$fTWHERE_parts);
		}
		
		$fTWHERE = str_replace("###CURRENT_PID###",intval($TSconfig["_CURRENT_PID"]),$fTWHERE);
		$fTWHERE = str_replace("###THIS_UID###",intval($TSconfig["_THIS_UID"]),$fTWHERE);
		$fTWHERE = str_replace("###STORAGE_PID###",intval($TSconfig["_STORAGE_PID"]),$fTWHERE);
		$fTWHERE = str_replace("###SITEROOT###",intval($TSconfig["_SITEROOT"]),$fTWHERE);
		$fTWHERE = str_replace("###PAGE_TSCONFIG_ID###",intval($TSconfig[$field]["PAGE_TSCONFIG_ID"]),$fTWHERE);
		$fTWHERE = str_replace("###PAGE_TSCONFIG_IDLIST###",implode(",",t3lib_div::intExplode(",",$TSconfig[$field]["PAGE_TSCONFIG_IDLIST"])),$fTWHERE);
		$fTWHERE = str_replace("###PAGE_TSCONFIG_STR###",addslashes($TSconfig[$field]["PAGE_TSCONFIG_STR"]),$fTWHERE);
		
		
			// rootLevel = -1 is not handled "properly" here - it goes as if it was rootLevel = 1 (that is pid=0)
		if ($rootLevel)	{
			$query = "SELECT ".t3lib_BEfunc::getCommonSelectFields($foreign_table,$foreign_table.".")." FROM ".$foreign_table." WHERE ".$foreign_table.".pid=0 ".t3lib_BEfunc::deleteClause($foreign_table)." ".$fTWHERE;
		} else {
			$pageClause = $GLOBALS["BE_USER"]->getPagePermsClause(1);
			if ($foreign_table!="pages")	{
				$query = "SELECT ".t3lib_BEfunc::getCommonSelectFields($foreign_table,$foreign_table.".")." FROM ".$foreign_table.",pages WHERE pages.uid=".$foreign_table.".pid AND NOT pages.deleted ".t3lib_BEfunc::deleteClause($foreign_table)." AND ".$pageClause." ".$fTWHERE;
			} else {
				$query = "SELECT ".t3lib_BEfunc::getCommonSelectFields($foreign_table,$foreign_table.".")." FROM pages WHERE NOT pages.deleted AND ".$pageClause." ".$fTWHERE;
			}
		}
//	debug(array($query));
		return $query;
	}
	function getTCEFORM_TSconfig($table,$row) {
		$res = array();
		$typeVal = t3lib_BEfunc::getTCAtypeValue($table,$row);

			// Get main config for the table
//debug("getTCEFORM_TSconfig");
		list($TScID,$cPid) = t3lib_BEfunc::getTSCpid($table,$row["uid"],$row["pid"]);
		
		$rootLine = t3lib_BEfunc::BEgetRootLine($TScID,"");
		if ($TScID>=0)	{
			$tempConf = $GLOBALS["BE_USER"]->getTSConfig("TCEFORM.".$table,t3lib_BEfunc::getPagesTSconfig($TScID,$rootLine));
			if (is_array($tempConf["properties"]))	{
				while(list($key,$val)=each($tempConf["properties"]))	{
					if (is_array($val))	{
						$fieldN = substr($key,0,-1);
						$res[$fieldN] = $val;
						unset($res[$fieldN]["types."]);
						if (strcmp($typeVal,"") && is_array($val["types."][$typeVal."."]))	{
							$res[$fieldN] = t3lib_div::array_merge_recursive_overrule($res[$fieldN],$val["types."][$typeVal."."]);
						}
					}
				}
			}
		}
		$res["_CURRENT_PID"]=$cPid;
		$res["_THIS_UID"]=$row["uid"];
		$res["_THIS_ROW"]=$row;	// So the row will be passed to foreign_table_where_query()
		reset($rootLine);
		while(list(,$rC)=each($rootLine))	{
			if (!$res["_STORAGE_PID"])	$res["_STORAGE_PID"]=intval($rC["storage_pid"]);
			if (!$res["_SITEROOT"])	$res["_SITEROOT"]=$rC["is_siteroot"]?intval($rC["uid"]):0;
		}
#debug($res);
		return $res;
	}
	function BEenableFields($table,$inv=0)	{
		$ctrl = $GLOBALS["TCA"][$table]["ctrl"];
		$query=array();
		$invQuery=array();
		if (is_array($ctrl))	{
			if (is_array($ctrl["enablecolumns"]))	{
				if ($ctrl["enablecolumns"]["disabled"])	{
					$field = $table.".".$ctrl["enablecolumns"]["disabled"];
					$query[]="NOT ".$field;
					$invQuery[]=$field;
				}
				if ($ctrl["enablecolumns"]["starttime"])	{
					$field = $table.".".$ctrl["enablecolumns"]["starttime"];
					$query[]="(".$field."<=".$GLOBALS["SIM_EXEC_TIME"].")";
					$invQuery[]="(".$field."!=0 AND ".$field.">".$GLOBALS["SIM_EXEC_TIME"].")";
				}
				if ($ctrl["enablecolumns"]["endtime"])	{
					$field = $table.".".$ctrl["enablecolumns"]["endtime"];
					$query[]="(".$field."=0 OR ".$field.">".$GLOBALS["SIM_EXEC_TIME"].")";
					$invQuery[]="(".$field."!=0 AND ".$field."<=".$GLOBALS["SIM_EXEC_TIME"].")";
				}
			}
		}
		$outQ = " AND ".($inv ? "(".implode(" OR ",$invQuery).")" : implode(" AND ",$query));
//		debug($outQ,2);
		return $outQ;
	}
	function getSetUpdateSignal($set="")	{
		global $BE_USER;
		$key = "t3lib_BEfunc::getSetUpdateSignal";
		$out="";
		if ($set)	{
			$modData=array();
			$modData["set"]=$set;
			$BE_USER->pushModuleData($key,$modData);
		} else {
			$modData = $BE_USER->getModuleData($key,"ses");
			if (trim($modData["set"]))	{
				$l=explode(",",$modData["set"]);
				while(list(,$v)=each($l))	{
					switch($v)	{
						case "updatePageTree":
							$out.='<script>
							if (top.content && top.content.nav_frame && top.content.nav_frame.refresh_nav)	{
								top.content.nav_frame.refresh_nav();
							} else if (top.theMenu) {
								top.theWebTreeIsLoaded=0;
								top.theMenu.refresh(true);
							}
							</script>';
						break;
					}
				}
				$modData=array();
				$modData["set"]="";
				$BE_USER->pushModuleData($key,$modData);
			}
		}
		return $out;
	}
}


?>