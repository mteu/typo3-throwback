<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Typo Core Engine - Form generator
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
//include_once(PATH_t3lib."class.t3lib_parsehtml.php");

class t3lib_TCEforms	{
	var $prependFormFieldNames = "data";
	var $prependFormFieldNames_file = "data_files";
	var $doSaveFieldName="";
	var $formName = "editform";
	var $fieldTemplate="<B>###FIELD_NAME###</B><BR>###FIELD_ITEM###<HR>";
	var $palFieldTemplate="";
	var $totalWrap="<HR>|<HR>";
	var $backPath="";
	var $charsPerRow=40;
	var $maxTextareaWidth=48;
	var $maxInputWidth=48;
	var $RTEbgColor= "#F6F2E6";
	var $helpTextFontTag='<font color="#333333">';
	var $RTEpath = 'rte/';
	var $tceFormsEditor=1;
	var $clientInfo=array();
	var $docLarge=0;
	var $fieldOrder="";	// Overrule the field order set in TCA, eg for tt_content this value, "bodytext,image", would make first the 'bodytext' field, then the 'image' field (if set for display)... and then the rest in the old order.
	var $hiddenFieldListArr = array();	// This array of fields will be set as hidden-fields instead of rendered normally!
	var $palFieldArr=array();
	var $doPrintPalette=1;
	var $palettesCollapsed=0;
	var $disableRTE=0;
	var $disableWizards=0;
	var $RTEdivStyle="";
	var $isPalettedoc=0;
	var $paletteMargin=1;
	var $defStyle = ""; // "font-family:Verdana;font-size:10px;";
	var $cachedTSconfig=array();
	var $cachedTSconfig_fieldLevel=array();
	var $commentMessages=array();
	var $perms_clause="";
	var $perms_clause_set=0;

	
	var $RTEenabled=0;
	var $RTEenabled_notReasons="";
	var $transformedRow=array();
	var $extJSCODE="";
	var $requiredFields=array();
	var $requiredElements=array();
	var $excludeElements="";
	var $RTEwindows=array();
	var $palettesRendered=array();
	var $printNeededJS = array();
	var $hiddenFieldAccum=array();
	var $TBE_EDITOR_fieldChanged_func="";
	var $loadMD5_JS=1;
	var $globalShowHelp=1;
	var $colorScheme;
	var $defColorScheme;
	var $fieldStyle;
	var $borderStyle;
	var $prevBorderStyle="[nothing here...]";	// Something unique...

		// Form field compensation:
	var $form_rowsToStylewidth = 9.58;	// Factor from NN4 form field widths to style-aware browsers (like NN6+ and MSIE, with the $CLIENT[FORMSTYLE] value set)
	var $form_NSWidthComp = 1;		// Compensation for NN4 form field widths to other browsers using the cols/size attributes
	var $form_largeComp = 1.33;		// Compensation for large documents, doc-tab (editing)

	/**
	 * Returns parameters to set the width for a <input>-element
	 */
	function formWidth($size=48,$textarea=0) {
			// Input or text-field attribute (size or cols)
		if ($this->docLarge)	$size = round($size*$this->form_largeComp);
		$wAttrib = $textarea?"cols":"size";
		if (!$GLOBALS["CLIENT"]["FORMSTYLE"])	{	// If not setting the width by style-attribute
			$size = ceil($size*$this->form_NSWidthComp);
			$retVal = ' '.$wAttrib.'="'.$size.'"';
		} else {	// Setting width by style-attribute. "cols" MUST be avoided with NN6+
			$pixels = ceil($size*$this->form_rowsToStylewidth);
			$retVal = ' style="width:'.$pixels.'px;'.$this->defStyle.$this->formElStyle($textarea?"text":"input").'"';
		}
		return $retVal;
	}
	function formElStyle($type)	{
		if ($GLOBALS["CLIENT"]["FORMSTYLE"])	{	// If not setting the width by style-attribute
			$style = $this->fieldStyle["all"];
			if (isset($this->fieldStyle[$type]))	{
				$style = $this->fieldStyle[$type];
			}
//			debug(array($type,$style));
			if (trim($style))	{
				return $style;
			}
		}
	}
	/**
	 * Returns parameters to set with for a textarea field
	 */
	function formWidthText($size=48,$wrap="") {
		$wTags = $this->formWidth($size,1);
			// Netscape 6+ seems to have this ODD problem where there WILL ALWAYS be wrapping with the cols-attribute set and NEVER without the col-attribute...
		if (strtolower(trim($wrap))!="off" && $GLOBALS["CLIENT"]["BROWSER"]=="net" && $GLOBALS["CLIENT"]["VERSION"]>6)	{
			$wTags.=' cols="'.$size.'"';
		}
		return $wTags;
	}
	function insertDefStyle($type)	{
		if ($GLOBALS["CLIENT"]["FORMSTYLE"])	{	// If not setting the width by style-attribute
			$style = trim($this->defStyle.$this->formElStyle($type));
			return $style?' style="'.$style.'"':'';
		}
	}

	/**
	 * Initializing
	 */
	function t3lib_TCEforms()	{
		global $CLIENT;
		$this->clientInfo=t3lib_div::clientInfo();
		$this->RTEenabled = $GLOBALS["BE_USER"]->isRTE();
		if (!$this->RTEenabled)	{
			$this->RTEenabled_notReasons=
				($CLIENT["BROWSER"]!="msie" ? "- Browser is not MSIE\n":"").
				($CLIENT["SYSTEM"]!="win" ? "- Client system is not Windows\n":"").
				($CLIENT["VERSION"]<5 ? "- Browser version below 5\n":"").
				(!$this->uc["edit_RTE"] ? "- RTE is not enabled for user!\n":"").
				(!$GLOBALS["TYPO3_CONF_VARS"]["BE"]["RTEenabled"] ? '- RTE is not enabled in $TYPO3_CONF_VARS["BE"]["RTEenabled"]'.chr(10):"");
			$this->commentMessages[]='RTE NOT ENABLED IN SYSTEM due to:'.chr(10).$this->RTEenabled_notReasons;
		}
		
			// Default color scheme
		$this->defColorScheme=array(
			$GLOBALS["SOBE"]->doc->bgColor,	// Background for the field AND palette
			t3lib_div::modifyHTMLColor($GLOBALS["SOBE"]->doc->bgColor,-20,-20,-20),	// Background for the field header
			t3lib_div::modifyHTMLColor($GLOBALS["SOBE"]->doc->bgColor,-10,-10,-10),	// Background for the palette field header
			"black",	// Field header font color
			"#666666"	// Palette field header font color
		);

			// Override / Setting defaults from TBE_STYLES array
		$this->setColorScheme($GLOBALS["TBE_STYLES"]["colorschemes"][0]);	
		$this->fieldStyle = $GLOBALS["TBE_STYLES"]["styleschemes"][0];
		$this->borderStyle = $GLOBALS["TBE_STYLES"]["borderschemes"][0];
			// Setting the current colorScheme to default.
		$this->defColorScheme=$this->colorScheme;
	}
	function setColorScheme($scheme)	{
		$this->colorScheme=$this->defColorScheme;
		$parts = t3lib_div::trimExplode(",",$scheme);
		while(list($key,$col)=each($parts))	{
			if ($col)	$this->colorScheme[$key]=$col;
			if ($col=="-")	$this->colorScheme[$key]="";
		}
	}
	function initDefaultBEmode()	{
		global $BE_USER;
		$this->prependFormFieldNames = "data";
		$this->formName = "editform";
		$this->RTEbgColor = $GLOBALS["SOBE"]->doc->bgColor;
		$this->setNewBEDesign();
		$this->docLarge = $BE_USER->uc["edit_wideDocument"] ? 1 : 0;
		$this->edit_showFieldHelp = $BE_USER->uc["edit_showFieldHelp"];
	}
	
	function getRTypeNum($table,$row)	{
		global $TCA;
		if ($TCA[$table]["ctrl"]["type"])	{
			$typeNum=$row[$TCA[$table]["ctrl"]["type"]];
			if (!strcmp($typeNum,""))	$typeNum=0;
		} else {
			$typeNum = 0;
		}
		$typeNum = (string)$typeNum;		// Necessary for eg "-1" to be recognized as a type value.
		if (!$TCA[$table]["types"][$typeNum])	{
			$typeNum = 1;
		}
//		debug($typeNum);
		return $typeNum;
	}
	function getExcludeElements($table,$row,$typeNum)	{
		global $TCA;
		$excludeElements=array();
		if ($TCA[$table]["types"][$typeNum]["subtype_value_field"])	{
			$sTfield = $TCA[$table]["types"][$typeNum]["subtype_value_field"];
			if (trim($TCA[$table]["types"][$typeNum]["subtypes_excludelist"][$row[$sTfield]]))	{
				$excludeElements=t3lib_div::trimExplode(",",$TCA[$table]["types"][$typeNum]["subtypes_excludelist"][$row[$sTfield]],1);
			}
		}

		if ($TCA[$table]["types"][$typeNum]["bitmask_value_field"])	{
			$sTfield = $TCA[$table]["types"][$typeNum]["bitmask_value_field"];
			$sTValue = t3lib_div::intInRange($row[$sTfield],0);
			if (is_array($TCA[$table]["types"][$typeNum]["bitmask_excludelist_bits"]))	{
				reset($TCA[$table]["types"][$typeNum]["bitmask_excludelist_bits"]);
				while(list($bitKey,$eList)=each($TCA[$table]["types"][$typeNum]["bitmask_excludelist_bits"]))	{
					$bit=substr($bitKey,1);
					if (t3lib_div::testInt($bit))	{
						$bit = t3lib_div::intInRange($bit,0,30);
						if (
								(substr($bitKey,0,1)=="-" && !($sTValue&pow(2,$bit))) ||	
								(substr($bitKey,0,1)=="+" && ($sTValue&pow(2,$bit)))
							)	{
							$excludeElements = array_merge($excludeElements,t3lib_div::trimExplode(",",$eList,1));
						}
					}
				}
			}
		}

		return $excludeElements;
	}	
	
	function getSoloField($table,$row,$theFieldToReturn)	{
		global $TCA,$BE_USER;
		
		if ($TCA[$table])	{
			t3lib_div::loadTCA($table);
			$typeNum = $this->getRTypeNum($table,$row);
			if ($TCA[$table]["types"][$typeNum])	{
				$itemList = $TCA[$table]["types"][$typeNum]["showitem"];
				if ($itemList)	{
					$fields = t3lib_div::trimExplode(",",$itemList,1);
					$excludeElements = $this->excludeElements = $this->getExcludeElements($table,$row,$typeNum);

					reset($fields);
					while(list(,$fieldInfo)=each($fields))	{
						$parts = explode(";",$fieldInfo);
						
						$theField = $parts[0];
						if (!in_array($theField,$excludeElements) && !strcmp($theField,$theFieldToReturn))	{
							if ($TCA[$table]["columns"][$theField])	{
								$sField = $this->getSingleField($table,$theField,$row,$parts[1],1,$parts[3],$parts[2]);
								return $sField["ITEM"];
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Based on the $table and $row of content, this displays the main editform fields
	 * The input-$row is required to be preprocessed if necessary by eg. the t3lib_transferdata class. For instance the RTE content should be transformed through this class first.
	 */
	function getMainFields($table,$row)	{
		global $TCA,$BE_USER;
//debug($row);
		
		$out_array=array();
		$out_pointer=0;
		$this->palettesRendered=array();
		if ($TCA[$table])	{
			t3lib_div::loadTCA($table);
			if ($this->edit_showFieldHelp || $this->doLoadTableDescr($table))	{
				t3lib_BEfunc::loadSingleTableDescription($table,$GLOBALS["LANG"]->lang);
			}
			$typeNum = $this->getRTypeNum($table,$row);
			if ($TCA[$table]["types"][$typeNum])	{
				$itemList = $TCA[$table]["types"][$typeNum]["showitem"];
				if ($itemList)	{
/*						// transforming data in row if needed.
					$this->transformData($table,$row);
					$row=array_merge($row,$this->transformedRow);	// Overriding transformed values.
*/
						//	debug($row);
					$fields = t3lib_div::trimExplode(",",$itemList,1);
					if ($this->fieldOrder)	{
						$fields = $this->rearrange($fields);
					}

					$excludeElements = $this->excludeElements = $this->getExcludeElements($table,$row,$typeNum);

					reset($fields);
					while(list(,$fieldInfo)=each($fields))	{
						$parts = explode(";",$fieldInfo);
						$color_style_parts = t3lib_div::trimExplode("-",$parts[4]);
						if (strcmp($color_style_parts[0],""))	{
							$this->setColorScheme($GLOBALS["TBE_STYLES"]["colorschemes"][intval($color_style_parts[0])]);
						}
						if (strcmp($color_style_parts[1],""))	{
							$this->fieldStyle = $GLOBALS["TBE_STYLES"]["styleschemes"][intval($color_style_parts[1])];
							if (!isset($this->fieldStyle))	$this->fieldStyle = $GLOBALS["TBE_STYLES"]["styleschemes"][0];
						}
						if (strcmp($color_style_parts[2],""))	{
							$this->wrapBorder($out_array,$out_pointer);
							$this->borderStyle = $GLOBALS["TBE_STYLES"]["borderschemes"][intval($color_style_parts[2])];
							if (!isset($this->borderStyle))	$this->borderStyle = $GLOBALS["TBE_STYLES"]["borderschemes"][0];
						}
						
						$theField = $parts[0];
						if (!in_array($theField,$excludeElements))	{
							if ($TCA[$table]["columns"][$theField])	{
								$sFieldPal="";
								if ($parts[2] && !isset($this->palettesRendered[$parts[2]]))	{
									$sFieldPal=$this->getPaletteFields($table,$row,$parts[2]);
									$this->palettesRendered[$parts[2]] = 1;
								}
								$sField = $this->getSingleField($table,$theField,$row,$parts[1],0,$parts[3],$parts[2]);
								if ($sField)	$sField.=$sFieldPal;
								
								$out_array[$out_pointer].= $sField;
							} elseif($theField=="--div--")	{
								$out_array[$out_pointer].=$this->getDivider();
							} elseif($theField=="--palette--")	{
								if ($parts[2] && !isset($this->palettesRendered[$parts[2]]))	{
									$out_array[$out_pointer].=$this->getPaletteFields($table,$row,$parts[2],"","",$this->sL($parts[1]));
									$this->palettesRendered[$parts[2]] = 1;
								}
							}
						}
					}
				}
			}
		}
		
		$this->wrapBorder($out_array,$out_pointer);

			// Resetting.
		$this->setColorScheme("");
		$this->borderStyle = $GLOBALS["TBE_STYLES"]["borderschemes"][0];
		$this->fieldStyle = $GLOBALS["TBE_STYLES"]["styleschemes"][0];

		// Main palette:
		$mP = $TCA[$table]["ctrl"]["mainpalette"];
		if ($mP && !isset($this->palettesRendered[$mP]))	{
			$temp_palettesCollapsed=$this->palettesCollapsed;
			$this->palettesCollapsed=0;
			$out_array[$out_pointer].=$this->getPaletteFields($table,$row,$mP,$this->getLL('l_generalOptions'));
			$this->palettesCollapsed=$temp_palettesCollapsed;
			$this->palettesRendered[$mP] = 1;
		}
		$this->wrapBorder($out_array,$out_pointer);

		return implode("",$out_array);
	}
	function wrapBorder(&$out_array,&$out_pointer)	{
		if ($this->sectionWrap && $out_array[$out_pointer])	{
			$tableAttribs="";
			$tableAttribs.= $this->borderStyle[0] ? ' style="'.$this->borderStyle[0].'"':'';
			$tableAttribs.= $this->borderStyle[2] ? ' background="'.$this->backPath.$this->borderStyle[2].'"':'';
			if ($tableAttribs)	{
				$tableAttribs='border=0 cellspacing=0 cellpadding=0 width=100%'.$tableAttribs;
				$out_array[$out_pointer] = str_replace("###CONTENT###",$out_array[$out_pointer],
					str_replace("###TABLE_ATTRIBS###",$tableAttribs,
						str_replace("###SPACE_BEFORE###",intval($this->borderStyle[1]),$this->sectionWrap)));
			}
			$out_pointer++;
		}
	}

	function getListedFields($table,$row,$list)	{
		global $TCA,$BE_USER;

		t3lib_div::loadTCA($table);
		if ($this->edit_showFieldHelp || $this->doLoadTableDescr($table))	{
			t3lib_BEfunc::loadSingleTableDescription($table,$GLOBALS["LANG"]->lang);
		}

		$out="";
		$types_fieldConfig=t3lib_BEfunc::getTCAtypes($table,$row,1);
		
		$editFieldList=array_unique(t3lib_div::trimExplode(",",$list,1));
		reset($editFieldList);
		while(list(,$theFieldC)=each($editFieldList))	{
			list($theField,$palFields) = split("\[|\]",$theFieldC);
			$theField = trim($theField);
			$palFields = trim($palFields);
			if ($TCA[$table]["columns"][$theField])	{
				$parts = t3lib_div::trimExplode(";",$types_fieldConfig[$theField]["origString"]);
				$sField= $this->getSingleField($table,$theField,$row,$parts[1],0,$parts[3],$parts[2]);
				$out.= $sField;
			} elseif($theField=="--div--")	{
				$out.=$this->getDivider();
			}
			if ($palFields)	{
				$out.=$this->getPaletteFields($table,$row,"","",implode(",",t3lib_div::trimExplode("|",$palFields,1)));
			}
		}
		return $out;
	}

	/**
	 * Based on the $table and $row of content, this displays the main editform fields
	 * The input-$row is required to be preprocessed if necessary by eg. the t3lib_transferdata class. For instance the RTE content should be transformed through this class first.
	 */
	function getPaletteFields($table,$row,$palette,$header="",$itemList="",$collapsedHeader="")	{
		global $TCA;
		if (!$this->doPrintPalette)	return "";
		
		$out="";
		$palParts=array();
		t3lib_div::loadTCA($table);

		if (!is_array($this->excludeElements))	{
			$this->excludeElements = $this->getExcludeElements($table,$row,$this->getRTypeNum($table,$row));
		}
				
		if ($TCA[$table] && (is_array($TCA[$table]["palettes"][$palette]) || $itemList))	{
			$itemList = $itemList?$itemList:$TCA[$table]["palettes"][$palette]["showitem"];
			if ($itemList)	{
				$fields = t3lib_div::trimExplode(",",$itemList,1);
				reset($fields);
				while(list(,$fieldInfo)=each($fields))	{
					$parts = t3lib_div::trimExplode(";",$fieldInfo);
					$theField = $parts[0];

					if (!in_array($theField,$this->excludeElements) && $TCA[$table]["columns"][$theField])	{
						$this->palFieldArr[$palette][] = $theField;
						if ($this->isPalettesCollapsed($table,$palette))	{
							$this->hiddenFieldListArr[] = $theField;
						}
						
						$part=$this->getSingleField($table,$theField,$row,$parts[1],1,"",$parts[2]);
						if (is_array($part))	{
							$palParts[]=$part;
						}
					}
				}
			}
		}
		if (count($palParts))	{
			if ($header)	{
				$out.=	$this->intoTemplate(array(
								"HEADER" => htmlspecialchars($header)
							),
							$this->palFieldTemplateHeader
						);
			}
			$out.=	$this->intoTemplate(array(
							"PALETTE" => $this->printPalette($palParts)
						),
						$this->palFieldTemplate
					);
		}
		if ($this->isPalettesCollapsed($table,$palette) && $collapsedHeader)	{
			$pC=	$this->intoTemplate(array(
							"PALETTE" => $this->wrapOpenPalette('<img src="'.$this->backPath.'gfx/options.gif" width="18" height="16" border="0"'.t3lib_BEfunc::titleAttrib($this->getLL('l_moreOptions')).' align=top><strong>'.$collapsedHeader.'</strong>',$table,$row,$palette),
						),
						$this->palFieldTemplate
					);
			$out.=$pC;
		}
		return $out;
	}
	
	/**
	 * Returns the form field for a single field.
	 */
	function getSingleField($table,$field,$row,$altName="",$palette="",$extra="",$pal=0)	{
		global $TCA,$BE_USER;
		$out="";
		t3lib_div::loadTCA($table);
		$fieldValue = $TCA[$table]["columns"][$field];
		if (	$fieldValue &&
				(!$fieldValue["exclude"] || $BE_USER->check("non_exclude_fields",$table.":".$field)) && 
				$fieldValue["config"]["type"]!="passthrough" &&
				($this->RTEenabled || !$fieldValue["config"]["showIfRTE"])
			)	{
			$fieldTSConfig = $this->setTSconfig($table,$row,$field);
//			debug($fieldTSConfig);
			if (!$fieldTSConfig["disabled"])	{
	
				$uid=$row["uid"];
				$itemName=$this->prependFormFieldNames.'['.$table.']['.$uid.']['.$field.']';
				$itemName_file=$this->prependFormFieldNames_file.'['.$table.']['.$uid.']['.$field.']';
				$itemValue=$row[$field];
				
				if (
						(($TCA[$table]["ctrl"]["type"] && !strcmp($field,$TCA[$table]["ctrl"]["type"])) ||
						($TCA[$table]["ctrl"]["requestUpdate"] && t3lib_div::inList($TCA[$table]["ctrl"]["requestUpdate"],$field)))
						&& !$BE_USER->uc["noOnChangeAlertInTypeFields"])	{
					$alertMsgOnChange="if (confirm('".t3lib_div::slashJS($this->getLL('m_onChangeAlert'))."') && TBE_EDITOR_checkSubmit(-1)){TBE_EDITOR_submitForm()};";
				} else {$alertMsgOnChange="";}
				
				if (in_array($field,$this->hiddenFieldListArr))	{
					$this->hiddenFieldAccum[]='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
				} else {
					if (!$palette)	{
						if ($pal&&$this->isPalettesCollapsed($table,$pal))	{
							list($thePalIcon,$palJSfunc) = $this->wrapOpenPalette('<img src="'.$this->backPath.'gfx/options.gif" width="18" height="16" border="0"'.t3lib_BEfunc::titleAttrib($this->getLL('l_moreOptions')).'>',$table,$row,$pal,1);
						} else {
							$thePalIcon = "";
							$palJSfunc = "";
						}
					}
					$onFocus = $palJSfunc&&!$BE_USER->uc["dontShowPalettesOnFocusInAB"] ? ' onFocus="'.$palJSfunc.'"' : '';
					
					// Find item
					$item="";
					$label = $altName ? $altName : $fieldValue["label"];
					$label = stripslashes($this->sL($label));
					$fieldChangeFunc=array();
					$fieldChangeFunc["TBE_EDITOR_fieldChanged"] = "TBE_EDITOR_fieldChanged('".$table."','".$uid."','".$field."','".$itemName."');";
					$fieldChangeFunc["alert"]=$alertMsgOnChange;
					
					$config = $fieldValue["config"];
					switch($config["type"])	{
						case "text":
							$cols = $config["cols"]?$config["cols"]:30;
							$origRows = $rows = $config["rows"]?$config["rows"]:5;
							$wrap = "virtual";
							if (strlen($itemValue)>$this->charsPerRow*2)	{
								$cols = $this->maxTextareaWidth;
								$rows = t3lib_div::intInRange(round(strlen($itemValue)/$this->charsPerRow),count(explode(chr(10),$itemValue)));
								if ($rows>20)	$rows=20;
								if ($rows<$origRows)	$rows=$origRows;
							}
							$RTEwasLoaded=0;
							$RTEwouldHaveBeenLoaded=0;
							$specConf = $this->getSpecConfForField($table,$row,$field);
							if ($this->RTEenabled) {	// If RTE is generally enabled (TYPO3_CONF_VARS and user settings)
								$RTEWidth = 460+($this->docLarge ? 150 : 0);
								$p=t3lib_BEfunc::getSpecConfParametersFromArray($specConf["rte_transform"]["parameters"]);
								if (isset($specConf["richtext"]) && (!$p["flag"] || !$row[$p["flag"]]))	{	// If the field is configured for RTE and if any flag-field is not set to disable it.
//debug("tceforms");
									list($tscPID,$thePidValue)=$this->getTSCpid($table,$row["uid"],$row["pid"]);
//debug(array($table,$tscPID));
									if ($thePidValue>=0)	{	// If the pid-value is not negative (that is, a pid could NOT be fetched)
//debug("RTEsetup");
										$RTEsetup = $GLOBALS["BE_USER"]->getTSConfig("RTE",t3lib_BEfunc::getPagesTSconfig($tscPID));
										$RTEtypeVal = t3lib_BEfunc::getTCAtypeValue($table,$row);
										$thisConfig = t3lib_BEfunc::RTEsetup($RTEsetup["properties"],$table,$field,$RTEtypeVal);
										if (!$thisConfig["disabled"])	{
											if (!$this->disableRTE)	{
												$RTEdivStyle = $this->RTEdivStyle ? $this->RTEdivStyle : 'position:relative; left:0px; top:0px; height:380; width:'.$RTEWidth.';border:solid 0px;';
												$item.='<input type=hidden name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
												$item.='<DIV id="cdiv'.count($this->RTEwindows).'" style="'.$RTEdivStyle.'">';
												$item.='<IFRAME src="'.$this->backPath.$this->RTEpath.'rte.php?elementId='.$itemName.'&pid='.$row["pid"].'&typeVal='.rawurlencode($RTEtypeVal).'&bgColor='.rawurlencode($this->colorScheme[0]).'&sC='.rawurlencode($extra).($this->tceFormsEditor?'&TCEformsEdit=1':'').'&formName='.rawurlencode($this->formName).'" id="'.$itemName.'_RTE" style="visibility: visible; position: absolute; left: 0px; top: 0px; height=100%; width=100%"></IFRAME>';
												$item.='</DIV>';
	
												$altItem='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
												$item=$this->renderWizards(array($item,$altItem),$config["wizards"],$table,$row,$field,$itemName,$fieldChangeFunc,$specConf,1);
												$this->RTEwindows[]=$itemName;
												$RTEwasLoaded=1;
											} else {
												$RTEwouldHaveBeenLoaded=1;
												$this->commentMessages[]=$itemName.': RTE is disabled by the on-page RTE-flag (probably you can enable it by the check-box in the bottom of this page!)';
											}
										} else $this->commentMessages[]=$itemName.': RTE is disabled by the Page TSconfig, "RTE"-key (eg. by RTE.default.disabled=0 or such)';
									} else $this->commentMessages[]=$itemName.': PID value could NOT be fetched. Seldom error, normally with new records.';
								} else {
									if (!isset($specConf["richtext"]))	$this->commentMessages[]=$itemName.': RTE was not configured for this field in TCA-types';
									if (!(!$p["flag"] || !$row[$p["flag"]]))	 $this->commentMessages[]=$itemName.': Field-flag ('.$p["flag"].') has been set to disable RTE!';
								}
							}
							if (!$RTEwasLoaded) {	// Display ordinary field if RTE was not loaded.
								if (strstr($extra,"nowrap"))	$wrap="OFF"; else $wrap=($config["wrap"]?$config["wrap"]:"VIRTUAL");
								$item.='<textarea name="'.$itemName.'"'.$this->formWidthText($cols,$wrap).' rows="'.$rows.'" wrap="'.$wrap.'" onChange="'.implode("",$fieldChangeFunc).'"'.$onFocus.'>'.t3lib_div::formatForTextarea($itemValue).'</textarea>';
								$altItem='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
								$item=$this->renderWizards(array($item,$altItem),$config["wizards"],$table,$row,$field,$itemName,$fieldChangeFunc,$specConf,$RTEwouldHaveBeenLoaded);
							}
						break;
						case "input":
		// typo3FormFieldSet(theField, evallist, is_in, checkbox, checkboxValue)
		// typo3FormFieldGet(theField, evallist, is_in, checkbox, checkboxValue, checkbox_off)
		
							$specConf = $this->getSpecConfForField($table,$row,$field);
							$size = $config["size"]?$config["size"]:$this->maxInputWidth;
							$evalList = t3lib_div::trimExplode(",",$config["eval"],1);
							if (in_array("required",$evalList))	{
								$this->requiredFields[$table."_".$uid."_".$field]=$itemName;
							}
		
							$paramsList = "'".$itemName."','".implode(",",$evalList)."','".trim($config["is_in"])."',".(isset($config["checkbox"])?1:0).",'".$config["checkbox"]."'";
							if (isset($config["checkbox"]))	{
								$nextMidNight = mktime (0,0,0)+1*3600*24;
								$checkSetValue = in_array("date",$evalList) ? $nextMidNight : "";
								$checkSetValue = in_array("datetime",$evalList) ? $nextMidNight+12*3600 : $checkSetValue;
	
								$item.='<input type="checkbox" name="'.$itemName.'_cb" onClick="typo3FormFieldGet('.$paramsList.',1,\''.$checkSetValue.'\');'.implode("",$fieldChangeFunc).'">';
							}
							$fieldChangeFunc = array_merge(array('typo3FormFieldGet'=>'typo3FormFieldGet('.$paramsList.');'), $fieldChangeFunc);
							$item.='<input type="Text" name="'.$itemName.'_hr" value=""'.$this->formWidth($size).' maxlength="'.($config["max"]?$config["max"]:256).'" onChange="'.implode("",$fieldChangeFunc).'"'.$onFocus.'>';
							$item.='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
							$this->extJSCODE.='typo3FormFieldSet('.$paramsList.');';

							$altItem='<input type="hidden" name="'.$itemName.'_hr" value="">';
							$altItem.='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
							$item= $this->renderWizards(array($item,$altItem),$config["wizards"],$table,$row,$field,$itemName."_hr",$fieldChangeFunc,$specConf);

							/*
								This is fixed in tcemain, so not important. Only for display I guess.
								if (isset($fieldValue[config]['range']['upper']))	{echo " range_upper = '".$fieldValue[config]['range']['upper']."';";}
								if (isset($fieldValue[config]['range']['lower']))	{echo " range_lower = '".$fieldValue[config]['range']['lower']."';";}
							*/
						break;
						case "select":
							$selItems = $this->addSelectOptionsToItemArray($this->initItemArray($fieldValue),$fieldValue,$this->setTSconfig($table,$row),$field);
							$selItems = $this->addItems($selItems,$fieldTSConfig["addItems."]);
							if ($config["itemsProcFunc"]) $selItems = $this->procItems($selItems,$fieldTSConfig["itemsProcFunc."],$config,$table,$row,$field);
							
							$removeItems=t3lib_div::trimExplode(",",$fieldTSConfig["removeItems"],1);
							reset($selItems);
							while(list($tk,$p)=each($selItems))	{
								if (in_array($p[1],$removeItems))	{
									unset($selItems[$tk]);
								} else if (isset($fieldTSConfig["altLabels."][$p[1]])) {
									$selItems[$tk][0]=$this->sL($fieldTSConfig["altLabels."][$p[1]]);
								}
							}
							
							$nMV_label = isset($fieldTSConfig["noMatchingValue_label"]) ? $this->sL($fieldTSConfig["noMatchingValue_label"]) : "[ ".sprintf($this->getLL("l_noMatchingValue"),$itemValue)." ]";
							
							$maxitems = intval($config["maxitems"]);
							$minitems = intval($config["minitems"]);
							$size = intval($config["size"]);
							if ($maxitems<=1)	{
								$c=0;
								$sI=0;
								$noMatchingValue=1;
								$opt=array();
								$selicons=array();
								reset($selItems);
								while(list(,$p)=each($selItems))	{
									$sM = (!strcmp($itemValue,$p[1])?" selected":"");
									if ($sM)	{
										$sI=$c;
										$noMatchingValue=0;
									}
									$opt[]= '<option value="'.htmlspecialchars($p[1]).'"'.$sM.'>'.htmlspecialchars($p[0]).'</option>';
									if ($p[2])	{
										list($selIconFile,$selIconInfo)=$this->getIcon($p[2]);
										$selicons[]=array('<a href="#" onClick="'.$this->elName($itemName).'.selectedIndex='.$c.'; '.implode("",$fieldChangeFunc).$this->blur().'return false;"><img src="'.$selIconFile.'" '.$selIconInfo[3].' vspace=2 border=0'.t3lib_BEfunc::titleAttrib($p[0],1).'></a>',$c,$sM);
									}
									$c++;
								}
								if ($itemValue && $noMatchingValue && !$fieldTSConfig["disableNoMatchingValueElement"])	{
									$opt[]= '<option value="'.htmlspecialchars($itemValue).'" SELECTED>'.htmlspecialchars($nMV_label).'</option>';
								}
								$item.= '<input type="hidden" name="'.$itemName.'_selIconVal" value="'.$sI.'">';	// MUST be inserted before the selector - else is the value of the hiddenfield here mysteriously submitted...
								$item.= '<select name="'.$itemName.'"'.$this->insertDefStyle("select").($size?" size=".$size:"").' OnChange="if (this.options[this.selectedIndex].value==\'--div--\') {this.selectedIndex='.$sI.';} '.implode("",$fieldChangeFunc).'"'.$onFocus.'>';
								$item.= implode("",$opt);
								$item.= '</select>';
			
								if (count($selicons))	{
									$item.='<table border=0 cellpadding=0 cellspacing=0>';
									$selicon_cols = intval($config["selicon_cols"]);
									if (!$selicon_cols)	$selicon_cols=count($selicons);
									$sR = ceil(count($selicons)/$selicon_cols);
									$selicons = array_pad($selicons,$sR*$selicon_cols,"");
									for($sa=0;$sa<$sR;$sa++)	{
										$item.='<tr>';
										for($sb=0;$sb<$selicon_cols;$sb++)	{
											$sk=($sa*$selicon_cols+$sb);
											$item.='<td><img name="selIcon_'.$table.'_'.$uid.'_'.$field.'_'.$selicons[$sk][1].'" src="'.($selicons[$sk][2]?$this->backPath."gfx/content_selected.gif":"clear.gif").'" width=7 height=10></td>';
											$item.='<td>'.$selicons[$sk][0].'</td>';
										}
										$item.='</tr>';
									}
									$item.='</table>';
								}
							} else {
								$item.= '<input type="hidden" name="'.$itemName.'_mul" value="'.($config["multiple"]?1:0).'">';
		
								$maxitems = t3lib_div::intInRange($config["maxitems"],0);
								if (!$maxitems)	$maxitems=100000;
								$minitems = t3lib_div::intInRange($config["minitems"],0);
								$this->requiredElements[$itemName] = array($minitems,$maxitems,"imgName"=>$table."_".$uid."_".$field);
	
								$thumbnails='<select style="width:200 px;" name="'.$itemName.'_sel"'.$this->insertDefStyle("select").($size?" size=".$size:"").' OnChange="setFormValueFromBrowseWin(\''.$itemName.'\',this.options[this.selectedIndex].value,this.options[this.selectedIndex].text); '.implode("",$fieldChangeFunc).'"'.$onFocus.'>';
								reset($selItems);
								while(list(,$p)=each($selItems))	{
									$thumbnails.= '<option value="'.htmlspecialchars($p[1]).'">'.htmlspecialchars($p[0]).'</option>';
								}
								$thumbnails.= '</select>';

								$itemArray = t3lib_div::trimExplode(",",$itemValue,1);
								reset($itemArray);
								while(list($tk,$tv)=each($itemArray))	{
									$tvP=explode("|",$tv,2);
									if (in_array($tvP[0],$removeItems) && !$fieldTSConfig["disableNoMatchingValueElement"])	{
										$tvP[1]=rawurlencode($nMV_label);
									} else if (isset($fieldTSConfig["altLabels."][$tvP[0]])) {
										$tvP[1]=rawurlencode($this->sL($fieldTSConfig["altLabels."][$tvP[0]]));
									}
									$itemArray[$tk]=implode("|",$tvP);
								}
								
								
								$params=array(
									"size" => $size,
									"info" => "",
									"headers" => array(
										"selector" => $this->getLL('l_selected').':<BR>',
										"items" => $this->getLL('l_items').':<BR>'
									),
									"noBrowser" => 1,
									"thumbnails" => $thumbnails
								);
								$item.= $this->dbFileIcons($itemName,"","",$itemArray,"",$params,$onFocus);
							}

								// Wizards:
							$altItem='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
							$item = $this->renderWizards(array($item,$altItem),$config["wizards"],$table,$row,$field,$itemName,$fieldChangeFunc,$specConf);
						break;
						case "check":
							$selItems = $this->initItemArray($fieldValue);
							if (!count($selItems))	{
								$selItems[]=array("","");
							}
							$thisValue = intval($itemValue);
		
							$cols = intval($config["cols"]);
							if ($cols > 1)	{
								$item.= '<table border=0 cellspacing=0 cellpadding=0>';
								for ($c=0;$c<count($selItems);$c++) {
									$p = $selItems[$c];
									if(!($c%$cols))	{$item.='<tr>';}
									$item.= '<td nowrap><input type="Checkbox"'.$this->insertDefStyle("check").' value=1 name="'.$itemName.'_'.$c.'"'.$this->checkBoxParams($itemName,$thisValue,$c,count($selItems),implode("",$fieldChangeFunc)).'>'.$this->wrapLabels(htmlspecialchars($p[0]).'&nbsp;').'</td>';
									if(($c%$cols)+1==$cols)	{$item.='</tr>';}
								}
								if ($c%$cols)	{
									$rest=$cols-($c%$cols);
		//		debug($rest);
									for ($c=0;$c<$rest;$c++) {
										$item.= '<td></td>';
									}
									if ($c>0)	{$item.= '</tr>';}
								}
								$item.= '</table>';
							} else {
								for ($c=0;$c<count($selItems);$c++) {
									$p = $selItems[$c];
									$item.= ($c>0?'<BR>':'').'<input type="Checkbox"'.$this->insertDefStyle("check").' value=1 name="'.$itemName.'_'.$c.'"'.$this->checkBoxParams($itemName,$thisValue,$c,count($selItems),implode("",$fieldChangeFunc)).''.$onFocus.'>'.htmlspecialchars($p[0]);
								}
							}
							$item.='<input type="hidden" name="'.$itemName.'" value="'.$thisValue.'">';
						break;
						case "group":
							$internal_type = $config["internal_type"];
							$show_thumbs = $config["show_thumbs"];
		//	??				$multiple = $config["multiple"];
							$size = $config["size"];
							$maxitems = t3lib_div::intInRange($config["maxitems"],0);
							if (!$maxitems)	$maxitems=100000;
							$minitems = t3lib_div::intInRange($config["minitems"],0);
							$allowed = $config["allowed"];
							$disallowed = $config["disallowed"];	// 	??  not implemented this check. Only in backend.
		//	??				$max_size = $config["max_size"];
	
							$item.= '<input type="hidden" name="'.$itemName.'_mul" value="'.($config["multiple"]?1:0).'">';
							$this->requiredElements[$itemName] = array($minitems,$maxitems,"imgName"=>$table."_".$uid."_".$field);
							$info="";
							if ($config["internal_type"]=="file")	{
								$tempFT = t3lib_div::trimExplode(",",$allowed,1);
								reset($tempFT);
								if (!count($tempFT))	{$info.='*';}
								while(list(,$ext)=each($tempFT))	{
									if ($ext)	{
										$info.=strtoupper($ext)." ";
									}
								}
								$tempFT_dis = t3lib_div::trimExplode(",",$disallowed,1);
								reset($tempFT_dis);
								if (count($tempFT_dis))	{$info.='<BR>';}
								while(list(,$ext)=each($tempFT_dis))	{
									if ($ext)	{
										$info.="-".strtoupper($ext)." ";
									}
								}
				
								$itemArray=t3lib_div::trimExplode(",",$itemValue,1);
								$thumbsnail="";
								if ($show_thumbs)	{
									reset($itemArray);
									$imgs=array();
									while(list(,$imgRead)=each($itemArray))	{
										$imgP = explode("|",$imgRead);
		
										$rowCopy=array();
										$rowCopy[$field] = $imgP[0];
										$imgs[]= '<nobr>'.t3lib_BEfunc::thumbCode($rowCopy,$table,$field,$this->backPath,"thumbs.php",$config["uploadfolder"],0,' align=middle').$imgP[0].'</nobr>';
									}
									$thumbsnail = implode("<BR>",$imgs);
								}
								$params=array(
									"size" => $size,
									"info" => $info,
									"thumbnails" => $thumbsnail
								);
								$item.= $this->dbFileIcons($itemName,"file",implode(",",$tempFT),$itemArray,"",$params,$onFocus);
								if ($GLOBALS["BE_USER"]->uc["edit_docModuleUpload"])	$item.='<input type="file" name="'.$itemName_file.'"'.$this->formWidth().'>';
							}
							if ($config["internal_type"]=="db")	{
								$tempFT = t3lib_div::trimExplode(",",$allowed,1);
								if (!strcmp(trim($tempFT[0]),"*"))	{
									$info.='<NOBR>&nbsp;&nbsp;&nbsp;&nbsp;'.$this->getLL('l_allTables').'</NOBR><BR>';
								} else {
									while(list(,$theT)=each($tempFT))	{
										if ($theT)	{
											$info.='<NOBR>&nbsp;&nbsp;&nbsp;&nbsp;<img src="'.$this->backPath.t3lib_iconWorks::getIcon($theT).'" width=18 height=16 align="top"> '.$this->sL($TCA[$theT]["ctrl"]["title"]).'</NOBR><BR>';
										}
									}
								}

		
								$temp_itemArray = t3lib_div::trimExplode(",",$itemValue,1);
								$itemArray=array();
								$perms_clause = $BE_USER->getPagePermsClause(1);
								$imgs=array();
								reset($temp_itemArray);
								while(list(,$dbRead)=each($temp_itemArray))	{
									$recordParts = explode("|",$dbRead);
									list($this_table,$this_uid) = t3lib_BEfunc::splitTable_Uid($recordParts[0]);
									$itemArray[] = array("table"=>$this_table, "id"=>$this_uid);
									if ($show_thumbs)	{
										$rr = t3lib_BEfunc::getRecord($this_table,$this_uid);
										$imgs[]="<nobr>".t3lib_iconWorks::getIconImage($this_table,$rr,$this->backPath,'align=top title="'.htmlspecialchars(t3lib_BEfunc::getRecordPath($rr["pid"],$perms_clause,15)).'"')."&nbsp;".$this->noTitle($rr[$TCA[$this_table]["ctrl"]["label"]],array("<em>","</em>"))."</nobr>";
									}
								}
								$thumbsnail="";
								if ($show_thumbs)	{
									$thumbsnail = implode("<BR>",$imgs);
								}
								$params=array(
									"size" => $size,
									"info" => $info,
									"thumbnails" => $thumbsnail
								);
								$item.= $this->dbFileIcons($itemName,"db",implode(",",$tempFT),$itemArray,"",$params,$onFocus);
							}

								// Wizards:
							$altItem='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
							$item = $this->renderWizards(array($item,$altItem),$config["wizards"],$table,$row,$field,$itemName,$fieldChangeFunc,$specConf);
						break;
						case "radio":
							$selItems = $this->initItemArray($fieldValue);
		//						debug($row);
							for ($c=0;$c<count($selItems);$c++) {
								$p = $selItems[$c];
								$item.= '<input type="Radio"'.$this->insertDefStyle("radio").' name="'.$itemName.'" value="'.htmlspecialchars($p[1]).'" onClick="'.implode("",$fieldChangeFunc).'"'.(!strcmp($p[1],$itemValue)?" checked":"").''.$onFocus.'>'.htmlspecialchars($p[0]).'<BR>';
							}
						break;
						case "none":
							$item=htmlspecialchars($itemValue);
						break;
						default:
							$item="Unknown type: ".$config["type"]."<BR>";
						break;
					}


					if (t3lib_div::testInt($row["uid"]) && $fieldTSConfig["linkTitleToSelf"])	{
						$label = '<a href="'.$this->backPath.'alt_doc.php?edit['.$table.']['.$row["uid"].']=edit&columnsOnly='.$field.
							($fieldTSConfig["linkTitleToSelf."]["returnUrl"]?'&returnUrl='.rawurlencode(t3lib_div::linkThisScript()):'').
							'">'.$label.'</a>';
					}
					if ($palette)	{
						$out=array(
							"NAME"=>$label,
							"ID"=>$row["uid"],
							"FIELD"=>$field,
							"TABLE"=>$table,
							"ITEM"=>$item,
							"HELP_ICON" => $this->helpTextIcon($table,$field,1)
						);
					} else {
						$out=$this->intoTemplate(
							array(
								"NAME"=>$label,
								"ITEM"=>$item,
			//					"PALETTEICON"=>$palette?'<img src="'.$this->backPath.'gfx/options.gif" width="18" height="16" border="0" title="" align=absmiddle hspace=2>':'',
								"TABLE"=>$table,
								"ID"=>$row["uid"],
								"HELP_ICON"=>$this->helpTextIcon($table,$field),
								"HELP_TEXT"=>$this->helpText($table,$field),
								"PAL_LINK_ICON"=>$thePalIcon,
								"FIELD"=>$field
							),
							$altTemplate
						);
					}
				}
			} else $this->commentMessages[]=$this->prependFormFieldNames.'['.$table.']['.$uid.']['.$field.']: Disabled by TSconfig';
		}
		return $out;
	}
	function getSpecConfForField($table,$row,$field)	{
		$types_fieldConfig=t3lib_BEfunc::getTCAtypes($table,$row);
		if (is_array($types_fieldConfig))	{
			reset($types_fieldConfig);
			while(list(,$vconf)=each($types_fieldConfig))	{
				if ($vconf["field"]==$field)	return $vconf["spec"];
			}
		}
	}
	function checkBoxParams($itemName,$thisValue,$c,$iCount,$addFunc="")	{
		$str = ' OnClick="'.$this->elName($itemName).'.value=this.checked?('.$this->elName($itemName).'.value|'.pow(2,$c).'):('.$this->elName($itemName).'.value&'.(pow(2,$iCount)-1-pow(2,$c)).');'.$addFunc.'"'.(($thisValue&pow(2,$c))?" checked":"");
		return $str;
	}
	function elName($itemName)	{
		return "document.".$this->formName."['".$itemName."']";
	}
	
	/**
	 * Initialize item array
	 */
	function initItemArray($fieldValue)	{
		$items = array();
		if (is_array($fieldValue["config"]["items"]))	{
			reset ($fieldValue["config"]["items"]);
			while (list($itemName,$itemValue) = each($fieldValue["config"]["items"]))	{
				$items[] = array($this->sL($itemValue[0]), $itemValue[1], $itemValue[2]);
			}
		}
		return $items;
	}


	/**
	 */
	function addItems($items,$iArray)	{
		global $TCA,$BE_USER;
		if (is_array($iArray))	{
			reset($iArray);
			while(list($value,$label)=each($iArray))	{
				$items[]=array($this->sl($label),$value);
			}
		}
		return $items;
	}
	/**
	 */
	function procItems($items,$iArray,$config,$table,$row,$field)	{
		global $TCA,$BE_USER;
		
		$params=array();
		$params["items"] = &$items;
		$params["config"] = $config;
		$params["TSconfig"] = $iArray;
		$params["table"] = $table;
		$params["row"] = $row;
		$params["field"] = $field;
	
		t3lib_div::callUserFunction($config["itemsProcFunc"],$params,$this);
		return $items;
	}
	
	function foreignTable($items,$fieldValue,$TSconfig,$field,$pFFlag=0)	{
		global $TCA,$BE_USER;	
		$pF=$pFFlag?"neg_":"";

		$f_table = $fieldValue["config"][$pF."foreign_table"];
		$uidPre = $pFFlag?"-":"";

		$query= t3lib_BEfunc::foreign_table_where_query($fieldValue,$field,$TSconfig,$pF);
//	debug($query,2);
//	debug($TSconfig);
		$res = @mysql (TYPO3_db, $query);
		if (mysql_error())	{ 
			debug(array(mysql_error()."\n\nQuery:\n ".$query."\n\nThis may indicate a table defined in tables.php is not existing in the database!"));
			exit;
		}
		$lPrefix = $this->sL($fieldValue["config"][$pF."foreign_table_prefix"]);

		$iField = $TCA[$f_table]["ctrl"]["selicon_field"];
		$iPath = trim($TCA[$f_table]["ctrl"]["selicon_field_path"]);
		while ($row = mysql_fetch_assoc($res))	{
			if ($iField && $iPath && $row[$iField])	{
				$iParts = t3lib_div::trimExplode(",",$row[$iField],1);
				$icon = "../".$iPath."/".trim($iParts[0]);
			} else $icon="";
			$items[] = array(t3lib_div::fixed_lgd($lPrefix.strip_tags(t3lib_BEfunc::getRecordTitle($f_table,$row)),$BE_USER->uc["titleLen"]), $uidPre.$row["uid"], $icon);
		}
		return $items;
	}	
	
	
	/**
	 * addSelect options
	 * This code is PARALLEL to the one found in main.php. If anything is changed here, consider the same change in main.php
	 */
	function addSelectOptionsToItemArray($items,$fieldValue,$TSconfig,$field)	{
		global $TCA,$BE_USER;
		if ($fieldValue["config"]["foreign_table"])	{
			$items = $this->foreignTable($items,$fieldValue,$TSconfig,$field);
			if ($fieldValue["config"]["neg_foreign_table"])	{
				$items = $this->foreignTable($items,$fieldValue,$TSconfig,$field,1);
			}
		}
//debug($items);
		if ($fieldValue["config"]["special"])	{
			switch ($fieldValue["config"]["special"])	{
				case "tables":
					$temp_tc = array_keys($TCA);
					reset($temp_tc);
					while (list(,$theTableNames)=each($temp_tc))	{
						if (!$TCA[$theTableNames]["ctrl"]["adminOnly"])	{
							$items[] = array(
								$this->sL($TCA[$theTableNames]["ctrl"]["title"]),
								$theTableNames
							);
						}
					}
				break;
				case "pagetypes":
					$theTypes = $TCA["pages"]["columns"]["doktype"]["config"]["items"];
					reset($theTypes);
					while (list(,$theTypeArrays)=each($theTypes))	{
						$items[] = array(
							$this->sL($theTypeArrays[0]),
							$theTypeArrays[1]
						);
					}
				break;
				case "exclude":
					$theTypes = t3lib_BEfunc::getExcludeFields();
					reset($theTypes);
					while (list(,$theTypeArrays)=each($theTypes))	{
						$items[] = array(
							$this->sL(ereg_replace(":$","",stripslashes($theTypeArrays[0]))),
							$theTypeArrays[1]
						);
					}
				break;
				case "modListGroup":
				case "modListUser":
					if (!is_object($loadModules))	{
						$loadModules = t3lib_div::makeInstance("t3lib_loadModules");
						$loadModules->load($GLOBALS["TBE_MODULES"]);
					}
					$modList = $fieldValue["config"]["special"]=="modListUser" ? $loadModules->modListUser : $loadModules->modListGroup;
					if (is_array($modList))	{
						reset($modList);
						while (list(,$theMod)=each($modList))	{
							$items[] = array(
								$theMod,
								$theMod
							);
						}
					}
				break;
			}
		}
		return $items;
	}
	
	/**
	 * Returns the form field for a single HIDDEN field.
	 */
	function getSingleHiddenField($table,$field,$row)	{
		global $TCA;
		$out="";
		t3lib_div::loadTCA($table);
		if ($TCA[$table]["columns"][$field])	{

			$uid=$row["uid"];
			$itemName=$this->prependFormFieldNames.'['.$table.']['.$uid.']['.$field.']';
			$itemValue=$row[$field];
			$item.='<input type="hidden" name="'.$itemName.'" value="'.htmlspecialchars($itemValue).'">';
			$out = $item;
		}
		return $out;
	}

	/**
	 * Returns help-text icon if configured for.
	 */
	function helpTextIcon($table,$field,$force=0)	{
		if ($this->globalShowHelp && $GLOBALS["TCA_DESCR"][$table]["columns"][$field] && (($this->edit_showFieldHelp=="icon"&&!$this->doLoadTableDescr($table)) || $force))	{
			return '<a href="#" onClick="vHWin=window.open(\''.$this->backPath.'view_help.php?tfID='.($table.".".$field).'\',\'viewFieldHelp\',\'height=300,width=250,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="'.$this->backPath.'gfx/helpbubble.gif" width="14" height="14" hspace=2 border=0 align=absmiddle'.($GLOBALS["CLIENT"]["FORMSTYLE"]?' style="cursor:help;"':'').'></a>';
		} else return '&nbsp;';
	}

	/**
	 * Returns help text, if configured for.
	 */
	function helpText($table,$field)	{
		if ($this->globalShowHelp && $GLOBALS["TCA_DESCR"][$table]["columns"][$field] && ($this->edit_showFieldHelp=="text" || $this->doLoadTableDescr($table)))	{
			$fDat = $GLOBALS["TCA_DESCR"][$table]["columns"][$field];
			return '<table border=0 cellpadding=2 cellspacing=0 width=90%><tr><td valign=top width=14>'.$this->helpTextIcon($table,$field,
				$fDat["details"]||$fDat["syntax"]||$fDat["image_descr"]||$fDat["image"]||$fDat["seeAlso"]
				).'</td><td valign=top>'.$this->helpTextFontTag.$fDat["description"].'</font></td></tr></table>';		
		}
	}

	/**
	 * This inserts the content of $inArr into the field-template
	 */
	function intoTemplate($inArr,$altTemplate="")	{
				// Put into template_
		$fieldTemplateParts = explode("###FIELD_",$this->colorScheme($altTemplate?$altTemplate:$this->fieldTemplate));
		reset($fieldTemplateParts);
		$out=current($fieldTemplateParts);
		while(list(,$part)=each($fieldTemplateParts))	{
			list($key,$val)=explode("###",$part,2);
			$out.=$inArr[$key];
			$out.=$val;
		}
		return $out;
	}

	/**
	 * Returns divider
	 */
	function getDivider()	{
		//return "<HR>";
	}

	/**
	 * This sets the fancy front-end design of the editor. Should it?
	 */
	function setFancyDesign()	{
		$this->fieldTemplate='
	<tr>
		<td nowrap bgColor="#F6F2E6">###FIELD_HELP_ICON###<font face=verdana size=1 color=black><B>###FIELD_NAME###</B></font>###FIELD_HELP_TEXT###</td>
	</tr>
	<tr>
		<td nowrap bgColor="#ABBBB4"><img name="req_###FIELD_TABLE###_###FIELD_ID###_###FIELD_FIELD###" src="clear.gif" width=10 height=10><img name="cm_###FIELD_TABLE###_###FIELD_ID###_###FIELD_FIELD###" src="clear.gif" width=7 height=10><font face=verdana size=1 color=black>###FIELD_ITEM###</font>###FIELD_PAL_LINK_ICON###</td>
	</tr>	';
	
		$this->totalWrap='<table border=0 cellpadding=1 cellspacing=0 bgcolor=black><tr><td><table border=0 cellpadding=2 cellspacing=0>|</table></td></tr></table>';

		$this->palFieldTemplate='
	<tr>
		<td nowrap bgColor="#ABBBB4"><font face=verdana size=1 color=black>###FIELD_PALETTE###</font></td>
	</tr>	';
		$this->palFieldTemplateHeader='
	<tr>
		<td nowrap bgColor="#F6F2E6"><font face=verdana size=1 color=black><b>###FIELD_HEADER###</b></font></td>
	</tr>	';
	}
	function wrapLabels($str)	{
		return $str;
	}

	/**
	 * This sets the design to the old document layout.
	 */
	function setDocDesign()	{	// For Alternative backend, original Document tab design, not used anymore.
		$L_CLOSE="Close";

		$this->totalWrap='<table border=0 cellspacing=0 cellpadding=0 width='.($this->docLarge?750:600).'>'.
			'<tr><td></td><td><A HREF="#" onClick="alert(\'Main palette...\'); return false;">###RECORD_ICON###</A>###MAIN_PALETTE_ICON###</td><td></td>'.
			'<td><font color="#333366"><b>###TABLE_TITLE###</b>###ID_NEW_INDICATOR###</font>'.
			' - ###RECORD_LABEL###</td><td>'.
			'<a href="#" onClick="alert(\'Close...\'); return false;"><img src="'.$this->backPath.'gfx/close.gif" width=11 height=10 border=0 title="'.$L_CLOSE.'" align="top"></a>'.
			'</td></tr>'.
			'|'.
			'<tr><td><img src="clear.gif" width=2 height=1></td><td><img src="clear.gif" width=110 height=1></td><td><img src="clear.gif" width=17 height=1></td><td><img src="clear.gif" width='.($this->docLarge?440+150:440).' height=1></td><td><img src="clear.gif" width=31 height=1></td></tr></table>';

		$this->fieldTemplate='<tr><td></td><td align="right"><font color="#666666"><b>###FIELD_NAME###</b></font></td><td>'.
			'<img name="req_###FIELD_TABLE###_###FIELD_ID###_###FIELD_FIELD###" src="clear.gif" width=10 height=10><img name="cm_###FIELD_TABLE###_###FIELD_ID###_###FIELD_FIELD###" src="clear.gif" width=7 height=10>'.
			'</td><td colspan=2>###FIELD_ITEM######FIELD_PAL_LINK_ICON###</td></tr>';
	}

	/**
	 * This sets the design to the New Alternative backend design.
	 */
	function setNewBEDesign()	{	// For Alternative backend
		$light=0;
		$this->totalWrap='
		<table border=0 cellspacing=0 cellpadding=0 width='.($this->docLarge?440+150:440).'>'.
			'<tr bgColor="'.t3lib_div::modifyHTMLColor($GLOBALS["SOBE"]->doc->bgColor2,$light,$light,$light).'">	
				<td>&nbsp;</td>
				<td>###RECORD_ICON### <font color="#333366"><b>###TABLE_TITLE###</b></font> ###ID_NEW_INDICATOR### - ###RECORD_LABEL###</td>
			</tr>'.
			'|'.
			'<tr>
				<td>&nbsp;</td>
				<td><img src="clear.gif" width='.($this->docLarge?440+150:440).' height=1></td>
			</tr>
		</table>';

		$this->fieldTemplate='
			<tr ###BGCOLOR_HEAD###>
				<td>###FIELD_HELP_ICON###</td>
				<td width=99%><font color="###FONTCOLOR_HEAD###"><b>###FIELD_NAME###</b></font>###FIELD_HELP_TEXT###</td>
			</tr>
			<tr ###BGCOLOR###>
				<td nowrap><img name="req_###FIELD_TABLE###_###FIELD_ID###_###FIELD_FIELD###" src="clear.gif" width=10 height=10><img name="cm_###FIELD_TABLE###_###FIELD_ID###_###FIELD_FIELD###" src="clear.gif" width=7 height=10></td>
				<td valign=top>###FIELD_ITEM######FIELD_PAL_LINK_ICON###</td>
			</tr>';

		$this->palFieldTemplate='
			<tr ###BGCOLOR###>
				<td>&nbsp;</td>
				<td nowrap valign=top>###FIELD_PALETTE###</td>
			</tr>';
		$this->palFieldTemplateHeader='
			<tr ###BGCOLOR_HEAD###>
				<td>&nbsp;</td>
				<td nowrap valign=top><strong>###FIELD_HEADER###</strong></td>
			</tr>';
			
		$this->sectionWrap='
			<tr>
				<td colspan=2><img src=clear.gif width=1 height=###SPACE_BEFORE###></td>
			</tr>			
			<tr>
				<td colspan=2><table ###TABLE_ATTRIBS###>###CONTENT###</table></td>
			</tr>
			';
	}
	
	function colorScheme($inTemplate)	{
		$inTemplate = str_replace("###BGCOLOR###",$this->colorScheme[0]?' bgColor="'.$this->colorScheme[0].'"':'',$inTemplate);
		$inTemplate = str_replace("###BGCOLOR_HEAD###",$this->colorScheme[1]?' bgColor="'.$this->colorScheme[1].'"':'',$inTemplate);
		$inTemplate = str_replace("###FONTCOLOR_HEAD###",$this->colorScheme[3],$inTemplate);
		return $inTemplate;
	}
	function printPalette($palArr)	{
		$out="";
		reset($palArr);
		$bgColor=' bgColor="'.$this->colorScheme[2].'"';
		while(list(,$content)=each($palArr))	{

			$hRow[]='<td'.$bgColor.'>&nbsp;</td><td nowrap'.$bgColor.'><font color="'.$this->colorScheme[4].'">'.$content["NAME"].'</font></td>';
			$iRow[]='<td valign=top><img name="req_'.$content["TABLE"].'_'.$content["ID"].'_'.$content["FIELD"].'" src="clear.gif" width=10 height=10 vspace=4><img name="cm_'.$content["TABLE"].'_'.$content["ID"].'_'.$content["FIELD"].'" src="clear.gif" width=7 height=10 vspace=4></td><td nowrap valign=top>'.$content["ITEM"].$content["HELP_ICON"].'</td>';
		}
		$out='<table border=0 cellpadding=0 cellspacing=0>
		<tr><td><img src=clear.gif width='.intval($this->paletteMargin).' height=1></td>'.implode("",$hRow).'</tr>
		<tr><td></td>'.implode("",$iRow).'</tr>
		</table>';

		return $out;
	}

	/**
	 * Wraps all the field-parts with the total table wrap.
	 */
	function wrapTotal($c,$rec,$table)	{
		$parts = $this->replaceTableWrap(explode("|",$this->totalWrap,2),$rec,$table);
		return $parts[0].$c.$parts[1].implode("",$this->hiddenFieldAccum);
	}

	/**
	 * This replaces markers in the total wrap
	 */
	function replaceTableWrap($arr,$rec,$table)	{
		global $TCA;
		reset($arr);
		while(list($k,$v)=each($arr))	{
			$arr[$k]=str_replace("###ID_NEW_INDICATOR###",(strstr($rec["uid"],"NEW")?" <font color=red><b>".$GLOBALS["LANG"]->mainLang["labels"]["new"]."</b></font>":" [".$rec["uid"]."]"),$arr[$k]);
			$rLabel = trim(t3lib_div::fixed_lgd(t3lib_BEfunc::getRecordTitle($table,$rec),40));
//			debug($rLabel);
			$arr[$k]=str_replace("###RECORD_LABEL###",$rLabel,$arr[$k]);
			$arr[$k]=str_replace("###TABLE_TITLE###",$this->sL($TCA[$table]["ctrl"]["title"]),$arr[$k]);

			$titleA=t3lib_BEfunc::titleAttrib($this->getRecordPath($table,$rec),1);
			$arr[$k]=str_replace("###RECORD_ICON###",t3lib_iconWorks::getIconImage($table,$rec,$this->backPath,"align=absmiddle".$titleA),$arr[$k]);
		}
		return $arr;
	}
	function getRecordPath($table,$rec)	{
		list($tscPID,$thePidValue)=$this->getTSCpid($table,$rec["uid"],$rec["pid"]);
		if ($thePidValue>=0)	{
			return t3lib_BEfunc::getRecordPath($tscPID,$this->readPerms(),15);
		}
	}
	function readPerms()	{
		if (!$this->perms_clause_set)	{
			$this->perms_clause = $GLOBALS["BE_USER"]->getPagePermsClause(1);
			$this->perms_clause_set=1;
		}
		return $this->perms_clause;
	}
	
	/**
	 * Split language label
	 */
	function sL($str)	{
		if (is_object($GLOBALS["LANG"]))	{
			return $GLOBALS["LANG"]->sL($str);
		} else {
			return $GLOBALS["BE_USER"]->extSL($str);
		}
	}

	/**
	 * Returns language label
	 */
	function getLL($str)	{
		switch(substr($str,0,2))	{
			case "l_":
				return $GLOBALS["LANG"]->mainLang["labels"][substr($str,2)];
			break;
			case "m_":
				return $GLOBALS["LANG"]->mainLang["mess"][substr($str,2)];
			break;
		} 
	}

	/**
	 * Gets default record. Maybe not used anymore. FE-editor?
	 */
	function getDefaultRecord($table,$pid=0)	{
		global $TCA;
		if ($TCA[$table])	{
			t3lib_div::loadTCA($table);
			$row=array();
			if ($pid<0 && $TCA[$table]["ctrl"]["useColumnsForDefaultValues"])	{
					// Fetches the previous record:
				$query = "select * from $table where uid='".abs($pid)."'".t3lib_BEfunc::deleteClause($table);
				$res = mysql(TYPO3_db,$query);
				echo mysql_error();
				if ($drow = mysql_fetch_assoc($res))	{
						// Gets the list of fields to copy from the previous record.
					$fArr=explode(",",$TCA[$table]["ctrl"]["useColumnsForDefaultValues"]);
					while(list(,$theF)=each($fArr))	{
						if ($TCA[$table]["columns"][$theF])	{
							$row[$theF]=$drow[$theF];
						}
					}
				}
			}
			reset($TCA[$table]["columns"]);
			while(list($field,$info)=each($TCA[$table]["columns"]))	{
				if (isset($info["config"]["default"]))	{
					$row[$field]=$info["config"]["default"];
				}
			}
			return $row;
		}
	}

	/**
	 * JavaScript code used for input-field evaluation.
	 */
	function JStop($formname="forms[0]")	{
		if (count($this->RTEwindows))	{
			$out.='
				<script>
					var TBE_RTE_WINDOWS=new Array();
					function TBE_EDITOR_setRTEref(RTEobj,theField,loadContent)	{
						TBE_RTE_WINDOWS[theField]=RTEobj;
						if (loadContent)	{
							RTEobj.setHTML(document.'.$formname.'[theField].value);
						}
					}
				</script>
			';
		}
		return $out;
	}
	/**
	 * JavaScript code used for input-field evaluation.
	 */
	function JSbottom($formname="forms[0]")	{
		/*
		Example use:
		
		$msg.='Distribution time (hh:mm dd-mm-yy):<BR><input type="text" name="send_mail_datetime_hr'.'" onChange="typo3FormFieldGet(\'send_mail_datetime\', \'datetime\', \'\', 0,0);"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(20).'><input type="hidden" value="'.time().'" name="send_mail_datetime"><BR>';
		$this->extJSCODE.='typo3FormFieldSet("send_mail_datetime", "datetime", "", 0,0);';
		
		... and then include the result of this function after the form
		
		*/
	
			$GLOBALS["JS_INCLUDED_jsfunc_evalfield_js"]=1;
				// required
			$reqLines=array();
			$reqLinesCheck=array();
			$reqLinesSet=array();
			reset($this->requiredFields);
			while(list($itemImgName,$itemName)=each($this->requiredFields))	{
				$reqLines[]="					TBE_REQUIRED['".$itemName."']=1;";
				$reqLinesCheck[]="					if (!document.".$formname."['".$itemName."'].value)	{OK=0;}";
				$reqLinesSet[]="					if (!document.".$formname."['".$itemName."'].value)	{TBE_EDITOR_setImage('req_".$itemImgName."','TBE_EDITOR_req');}";
			}

			$reqRange=array();
			$reqRangeCheck=array();
			$reqRangeSet=array();
			reset($this->requiredElements);
			while(list($itemName,$range)=each($this->requiredElements))	{
				$reqRange[]="					TBE_RANGE['".$itemName."']=1;";
				$reqRange[]="					TBE_RANGE_lower['".$itemName."']=".$range[0].";";
				$reqRange[]="					TBE_RANGE_upper['".$itemName."']=".$range[1].";";
				$reqRangeCheck[]="					if (!TBE_EDITOR_checkRange(document.".$formname."['".$itemName."_list'],".$range[0].",".$range[1]."))	{OK=0;}";
				$reqRangeSet[]="					if (!TBE_EDITOR_checkRange(document.".$formname."['".$itemName."_list'],".$range[0].",".$range[1]."))	{TBE_EDITOR_setImage('req_".$range["imgName"]."','TBE_EDITOR_req');}";
			}
//	debug($reqRange);

			$RTEwinArr = array();
			$RTEwinArrTransfer = array();
			reset($this->RTEwindows);
			while(list(,$itemName)=each($this->RTEwindows))	{
				$RTEwinArr[]="					TBE_RTE_WINDOWS['".$itemName."']=0;";
				$RTEwinArrTransfer[]="					if(TBE_RTE_WINDOWS['".$itemName."'])	{document.".$formname."['".$itemName."'].value = TBE_RTE_WINDOWS['".$itemName."'].getHTML();}else{OK++;}";
			}			

			$this->TBE_EDITOR_fieldChanged_func='TBE_EDITOR_fieldChanged_fName(fName,formObj[fName+"_list"]);';
			
			if ($this->loadMD5_JS)	{
			$out.='
			<SCRIPT LANGUAGE="JavaScript" SRC="'.$this->backPath.'md5.js"></SCRIPT>';
			}
			$out.='
			<SCRIPT LANGUAGE="JavaScript" SRC="'.$this->backPath.'t3lib/jsfunc.evalfield.js"></SCRIPT>
			<script>
				
				var TBE_EDITOR_req=new Image(); 	TBE_EDITOR_req.src = "'.$this->backPath.'gfx/required_h.gif"; 
				var TBE_EDITOR_cm=new Image(); 		TBE_EDITOR_cm.src = "'.$this->backPath.'gfx/content_client.gif"; 
				var TBE_EDITOR_sel=new Image(); 	TBE_EDITOR_sel.src = "'.$this->backPath.'gfx/content_selected.gif"; 
				var TBE_EDITOR_clear=new Image(); 	TBE_EDITOR_clear.src = "'.$this->backPath.'clear.gif"; 
				var TBE_REQUIRED=new Array();
'.implode(chr(10),$reqLines).'

				var TBE_RANGE=new Array();
				var TBE_RANGE_lower=new Array();
				var TBE_RANGE_upper=new Array();
'.implode(chr(10),$reqRange).'

'.implode(chr(10),$RTEwinArr).'				

				var TBE_EDITOR_loadTime = 0;
				var TBE_EDITOR_isChanged = 0;

				function TBE_EDITOR_loginRefreshed()	{
					var date = new Date();
					TBE_EDITOR_loadTime = Math.floor(date.getTime()/1000);
					if (top.busy && top.busy.loginRefreshed)	{top.busy.loginRefreshed();}
				}
				function TBE_EDITOR_checkLoginTimeout()	{
					var date = new Date();
					var theTime = Math.floor(date.getTime()/1000);
					if (theTime > TBE_EDITOR_loadTime+'.intval($GLOBALS["BE_USER"]->auth_timeout_field).'-10)	{
						return true;
					}
				}
				function TBE_EDITOR_setHiddenContent(RTEcontent,theField)	{
					document.'.$formname.'[theField].value = RTEcontent;
					alert(document.'.$formname.'[theField].value);
				}
				function TBE_EDITOR_fieldChanged_fName(fName,el)	{
					var idx='.(2+substr_count ($this->prependFormFieldNames,"[")).';
					var table = TBE_EDITOR_split(fName, "[", idx);
					var uid = TBE_EDITOR_split(fName, "[", idx+1);
					var field = TBE_EDITOR_split(fName, "[", idx+2);

					table = table.substr(0,table.length-1);
					uid = uid.substr(0,uid.length-1);
					field = field.substr(0,field.length-1);

					TBE_EDITOR_fieldChanged(table,uid,field,el);
				}
				function TBE_EDITOR_fieldChanged(table,uid,field,el)	{
					var theField = "'.$this->prependFormFieldNames.'["+table+"]["+uid+"]["+field+"]";
					TBE_EDITOR_isChanged = 1;

						// Set change image:
					var imgObjName = "cm_"+table+"_"+uid+"_"+field;
					TBE_EDITOR_setImage(imgObjName,"TBE_EDITOR_cm");
					
						// Set change image
					if (document.'.$formname.'[theField].type=="select-one" && document.'.$formname.'[theField+"_selIconVal"])	{
						var imgObjName = "selIcon_"+table+"_"+uid+"_"+field+"_";
						TBE_EDITOR_setImage(imgObjName+document.'.$formname.'[theField+"_selIconVal"].value,"TBE_EDITOR_clear");
						document.'.$formname.'[theField+"_selIconVal"].value = document.'.$formname.'[theField].selectedIndex;
						TBE_EDITOR_setImage(imgObjName+document.'.$formname.'[theField+"_selIconVal"].value,"TBE_EDITOR_sel");
					}
					
						// Set required flag:
					var imgReqObjName = "req_"+table+"_"+uid+"_"+field;
					if (TBE_REQUIRED[theField] && document.'.$formname.'[theField])	{
						if (document.'.$formname.'[theField].value)	{
							TBE_EDITOR_setImage(imgReqObjName,"TBE_EDITOR_clear");
						} else {
							TBE_EDITOR_setImage(imgReqObjName,"TBE_EDITOR_req");
						}
					}
					if (TBE_RANGE[theField] && document.'.$formname.'[theField])	{
						if (TBE_EDITOR_checkRange(document.'.$formname.'[theField+"_list"],TBE_RANGE_lower[theField],TBE_RANGE_upper[theField]))	{
							TBE_EDITOR_setImage(imgReqObjName,"TBE_EDITOR_clear");
						} else {
							TBE_EDITOR_setImage(imgReqObjName,"TBE_EDITOR_req");
						}
					}
					'.(!$this->isPalettedoc?'':'
					TBE_EDITOR_setOriginalFormFieldValue(theField);
					').'
				}
				'.($this->isPalettedoc?'
				function TBE_EDITOR_setOriginalFormFieldValue(theField)	{
					if ('.$this->isPalettedoc.' && '.$this->isPalettedoc.'.'.$formname.' && '.$this->isPalettedoc.'.'.$formname.'[theField]) {
						'.$this->isPalettedoc.'.'.$formname.'[theField].value = document.'.$formname.'[theField].value;
					}
				}
				':'').'
				function TBE_EDITOR_isFormChanged(noAlert)	{
					if (TBE_EDITOR_isChanged && !noAlert && confirm(unescape("'.rawurlencode($GLOBALS["LANG"]->php3Lang["labels"]["fieldsChanged"]).'")))	{
						return 0;
					}
					return TBE_EDITOR_isChanged;
				}
				function TBE_EDITOR_checkAndDoSubmit(sendAlert)	{
					if (TBE_EDITOR_checkSubmit(sendAlert))	{
						TBE_EDITOR_submitForm();
					}
				}
				function TBE_EDITOR_checkSubmit(sendAlert)	{
					if (TBE_EDITOR_checkLoginTimeout() && confirm("'.t3lib_div::slashJS($this->getLL("m_refresh_login")).'"))	{
						vHWin=window.open(\''.$this->backPath.'login_frameset.php?\',\'relogin\',\'height=300,width=400,status=0,menubar=0\');
						vHWin.focus();
						return false;
					}
					var OK=1;
//alert();
'.implode(chr(10),$RTEwinArrTransfer).'
					if(!OK)	{
						alert(unescape("SYSTEM ERROR: The Rich Text Editors ("+OK+") content could not be read. This IS an error, although it should not be regular.\nThe form is not saved. Try again.o\n\nPlease report the error to your administrator if it persists."));
					}
					
'.implode(chr(10),$reqLinesCheck).'
'.implode(chr(10),$reqRangeCheck).'
					
					if (OK || sendAlert==-1)	{
						return true;
					} else {
						if(sendAlert)	alert(unescape("'.rawurlencode($GLOBALS["LANG"]->php3Lang["labels"]["fieldsMissing"]).'"));
						return false;
					}
				}
				function TBE_EDITOR_checkRange(el,lower,upper)	{
					if (el && el.length>=lower && el.length<=upper) {
						return true;
					} else {
						return false;
					}
				}
				function TBE_EDITOR_initRequired()	{
'.implode(chr(10),$reqLinesSet).'
'.implode(chr(10),$reqRangeSet).'
				}
				function TBE_EDITOR_setImage(name,imgName)	{
					if (document[name]) {document[name].src = eval(imgName+".src");}
				}
				function TBE_EDITOR_submitForm()	{
					'.($this->doSaveFieldName?"document.".$this->formName."['".$this->doSaveFieldName."'].value=1;":"").'
					document.'.$this->formName.'.submit();
				}
				function typoSetup	()	{
					this.passwordDummy = "********";
					this.decimalSign = ".";
				}
				var TS = new typoSetup();
				var evalFunc = new evalFunc();
				function typo3FormFieldSet(theField, evallist, is_in, checkbox, checkboxValue)	{
					if (document.'.$formname.'[theField])	{
						var theFObj = new evalFunc_dummy (evallist,is_in, checkbox, checkboxValue);
						var theValue = document.'.$formname.'[theField].value;
						if (checkbox && theValue==checkboxValue)	{
							document.'.$formname.'[theField+"_hr"].value="";
							if (document.'.$formname.'[theField+"_cb"])	document.'.$formname.'[theField+"_cb"].checked = "";
						} else {
							document.'.$formname.'[theField+"_hr"].value = evalFunc.outputObjValue(theFObj, theValue);
							if (document.'.$formname.'[theField+"_cb"])	document.'.$formname.'[theField+"_cb"].checked = "on";
						}
					}
				}
				function typo3FormFieldGet(theField, evallist, is_in, checkbox, checkboxValue, checkbox_off, checkSetValue)	{
					if (document.'.$formname.'[theField])	{
						var theFObj = new evalFunc_dummy (evallist,is_in, checkbox, checkboxValue);
						if (checkbox_off)	{
							if (document.'.$formname.'[theField+"_cb"].checked)	{
								document.'.$formname.'[theField].value=checkSetValue;
							} else {
								document.'.$formname.'[theField].value=checkboxValue;
							}
						}else{
							document.'.$formname.'[theField].value = evalFunc.evalObjValue(theFObj, document.'.$formname.'[theField+"_hr"].value);
						}
						typo3FormFieldSet(theField, evallist, is_in, checkbox, checkboxValue);
					}
				}
				function TBE_EDITOR_split(theStr1, delim, index) {	
					var theStr = ""+theStr1;
					var lengthOfDelim = delim.length;
					sPos = -lengthOfDelim;
					if (index<1) {index=1;}
					for (var a=1; a<index; a++)	{
						sPos = theStr.indexOf(delim, sPos+lengthOfDelim);
						if (sPos==-1)	{return null;}
					}
					ePos = theStr.indexOf(delim, sPos+lengthOfDelim);
					if(ePos == -1)	{ePos = theStr.length;}	
					return (theStr.substring(sPos+lengthOfDelim,ePos));
				}
				function TBE_EDITOR_palUrl(inData,fieldList,fieldNum,table,uid,isOnFocus) {	
					var url = "'.$this->backPath.'alt_palette.php?inData="+inData+"&formName='.rawurlencode($this->formName).'"+"&prependFormFieldNames='.rawurlencode($this->prependFormFieldNames).'";
					var field = "";
					var theField="";
					for (var a=0; a<fieldNum;a++)	{
						field = TBE_EDITOR_split(fieldList, ",", a+1);
						theField = "'.$this->prependFormFieldNames.'["+table+"]["+uid+"]["+field+"]";
						if (document.'.$formname.'[theField])		url+="&rec["+field+"]="+TBE_EDITOR_rawurlencode(document.'.$formname.'[theField].value);
					}
					if (top.topmenuFrame)	{
						top.topmenuFrame.document.location = url+"&backRef="+(top.content.db_list_frame?"top.content.db_list_frame":(top.content.list_frame?"top.content.list_frame":"top.content"));
					} else if (!isOnFocus) {
						var vHWin=window.open(url,"palette","height=300,width=200,status=0,menubar=0,scrollbars=1");
						vHWin.focus();
					}
				}
				function TBE_EDITOR_curSelected(theField)	{
					var fObjSel = document.'.$formname.'[theField];
					var retVal="";
					if (fObjSel && fObjSel.type=="select-multiple")	{
						var l=fObjSel.length;
						for (a=0;a<l;a++)	{
							if (fObjSel.options[a].selected==1)	{
								retVal+=fObjSel.options[a].value+",";
							}
						}
					}
					return retVal;
				}
				function TBE_EDITOR_rawurlencode(str,maxlen)	{
					var output = str;
					if (maxlen)	output = output.substr(0,200);
					output = escape(output);
					output = TBE_EDITOR_str_replace("*","%2A", output);
					output = TBE_EDITOR_str_replace("+","%2B", output);
					output = TBE_EDITOR_str_replace("/","%2F", output);
					output = TBE_EDITOR_str_replace("@","%40", output);
					return output;
				}
				function TBE_EDITOR_str_replace(match,replace,string)	{
					var input = ""+string;
					var matchStr = ""+match;
					if (!matchStr)	{return string;}
					var output = "";
					var pointer=0;
					var pos = input.indexOf(matchStr);
					while (pos!=-1)	{
						output+=""+input.substr(pointer, pos-pointer)+replace;
						pointer=pos+matchStr.length;
						pos = input.indexOf(match,pos+1);
					}
					output+=""+input.substr(pointer);
					return output;
				}
			</script>
			<script>
				'.$this->extJSCODE.'
				
				TBE_EDITOR_initRequired();
				TBE_EDITOR_loginRefreshed();
			</script>';
			return $out;
	}

	/**
	 *  Used to connect the db/file browser with this document and the formfields on it!
	 */
	function dbFileCon($formObj="document.forms[0]")	{
		$str='	

	// ***************
	// Used to connect the db/file browser with this document and the formfields on it!
	// ***************

	var browserWin="";
	function setFormValueOpenBrowser (mode,params) {
		var url = "'.$this->backPath.'browser.php?mode="+mode+"&bparams="+params;
		if (!browserWin)	{
			browserWin = window.open(url,"Typo3WinBrowser","height=350,width="+(mode=="db"?650:600)+",status=0,menubar=0,resizable=1,scrollbars=1");
			browserWin.typoWin = self;
			browserWin.focus();
		} else {
			browserWin.content.document.location=url;
			browserWin.typoWin = self;
			browserWin.focus();
		}
	}
	function setFormValueFromBrowseWin(fName,value,label)	{
		var formObj = setFormValue_getFObj(fName)
		if (formObj)	{
			fObj = formObj[fName+"_list"];
				// Inserting element
			var l=fObj.length;
			var setOK=1;
			if (!formObj[fName+"_mul"] || formObj[fName+"_mul"].value==0)	{
				for (a=0;a<l;a++)	{
					if (fObj.options[a].value==value)	{
						setOK=0;
					}
				}
			}
			if (setOK)	{
				fObj.length++;
				fObj.options[l].value=value;
				fObj.options[l].text=label;

					// Traversing list and set the hidden-field
				setHiddenFromList(fObj,formObj[fName]);
				'.$this->TBE_EDITOR_fieldChanged_func.'
			}
		}
	}
	function setHiddenFromList(fObjSel,fObjHid)	{
		l=fObjSel.length;
		fObjHid.value="";
		for (a=0;a<l;a++)	{
			fObjHid.value+=fObjSel.options[a].value+",";
		}
	}
	function setFormValueManipulate(fName,type)	{
		var formObj = setFormValue_getFObj(fName)
		if (formObj)	{
			var localArray_V = new Array();
			var localArray_L = new Array();
			var fObjSel = formObj[fName+"_list"];
			var l=fObjSel.length;
			var c=0;
			var cS=0;
			if (type=="Remove" || type=="Up")	{
				if (type=="Up")	{
					for (a=0;a<l;a++)	{
						if (fObjSel.options[a].selected==1)	{
							localArray_V[c]=fObjSel.options[a].value;
							localArray_L[c]=fObjSel.options[a].text;
							c++;
							cS++;
						}
					}
				}
				for (a=0;a<l;a++)	{
					if (fObjSel.options[a].selected!=1)	{
						localArray_V[c]=fObjSel.options[a].value;
						localArray_L[c]=fObjSel.options[a].text;
						c++;
					}
				}
			}
			fObjSel.length = c;
			for (a=0;a<c;a++)	{
				fObjSel.options[a].value = localArray_V[a];
				fObjSel.options[a].text = localArray_L[a];
				fObjSel.options[a].selected=(a<cS)?1:0;
			}
			setHiddenFromList(fObjSel,formObj[fName]);
			'.$this->TBE_EDITOR_fieldChanged_func.'
		}
	}
	function setFormValue_getFObj(fName)	{
		var formObj = '.$formObj.';
		if (formObj)	{
			if (formObj[fName] && formObj[fName+"_list"] && formObj[fName+"_list"].type=="select-multiple")	{
				return formObj;
			} else {	
				alert("Formfields missing:\n fName: "+formObj[fName]+"\n fName_list:"+formObj[fName+"_list"]+"\n type:"+formObj[fName+"_list"].type+"\n fName:"+fName);
			}
		}
		return "";
	}

	// END: dbFileCon parts.
';	
		return $str;
	}

	/**
	 * Prints the form-field for the db/file connection
	 */
	function dbFileIcons($fName,$mode,$allowed,$itemArray,$selector="",$params=array(),$onFocus="")	{
		$this->printNeededJS["dbFileIcons"]=1;
		$uidList=array();
		$opt=array();
		$itemArrayC=0;
		if (is_array($itemArray))	{
			$itemArrayC=count($itemArray);
			reset($itemArray);
			switch($mode)	{
				case "db":
					while(list(,$pp)=each($itemArray))	{
						$pRec = t3lib_BEfunc::getRecord($pp["table"],$pp["id"]);
						if (is_array($pRec))	{
							$pTitle = t3lib_div::fixed_lgd($this->noTitle($pRec[$GLOBALS["TCA"][$pp["table"]]["ctrl"]["label"]]),$GLOBALS["BE_USER"]->uc["titleLen"]);
							$pUid = $pp["table"].'_'.$pp["id"];
							$uidList[]=$pUid;
							$opt[]='<option value="'.$pUid.'">'.htmlspecialchars($pTitle).'</option>';
						}
					}
				break;
				case "file":
					while(list(,$pp)=each($itemArray))	{
						$pParts = explode("|",$pp);
						$uidList[]=$pUid=$pTitle = $pParts[0];
						$opt[]='<option value="'.htmlspecialchars(rawurldecode($pParts[0])).'">'.htmlspecialchars(rawurldecode($pParts[0])).'</option>';
					}
				break;
				default:
					while(list(,$pp)=each($itemArray))	{
						$pParts = explode("|",$pp);
						$uidList[]=$pUid=$pParts[0];
						$pTitle = $pParts[1];
						$opt[]='<option value="'.htmlspecialchars(rawurldecode($pUid)).'">'.htmlspecialchars(rawurldecode($pTitle)).'</option>';
					}
				break;
			}
		}
		if (!$selector)	{
			$selector = '<select size='.t3lib_div::intInRange($itemArrayC+1,t3lib_div::intInRange($params["size"],1)).$this->insertDefStyle("group").' multiple name="'.$fName.'_list" style="width:200px;"'.$onFocus.'>'.implode("",$opt).'</select>';
	//		debug(implode(",",$uidList),1);
		}
		$icons=array();
		if (!$params["noBrowser"])	{
			$icons[]='<a href="#" onClick="setFormValueOpenBrowser(\''.$mode.'\',\''.($fName.'|||'.$allowed.'|').'\'); return false;"><img src="'.$this->backPath.'gfx/insert3.gif" width="14" height="14" border="0" title="'.$this->getLL("l_browse_".($mode=="file"?"file":"db")).'"></a>';
		}
		$icons[]='<a href="#" onClick="setFormValueManipulate(\''.$fName.'\',\'Up\'); return false;"><img src="'.$this->backPath.'gfx/group_totop.gif" width="14" height="14" border="0" title="'.$this->getLL("l_move_to_top").'"></a>';
		$icons[]='<a href="#" onClick="setFormValueManipulate(\''.$fName.'\',\'Remove\'); return false;"><img src="'.$this->backPath.'gfx/group_clear.gif" width="14" height="14" border="0" title="'.$this->getLL("l_remove_selected").'"></a>';
		$str='<table border=0 cellpadding=0 cellspacing=0 width=1>
			'.($params["headers"]?'<tr><td>'.$this->wrapLabels($params["headers"]["selector"]).'</td><td></td><td></td><td>'.$this->wrapLabels($params["headers"]["items"]).'</td></tr>':'').'
			<tr><td valign=top>'.$selector.'<BR>'.$this->wrapLabels($params["info"]).'</td><td valign=top>'.implode("<BR>",$icons).'</td><td><img src=clear.gif width=5 height=1></td><td valign=top>'.$this->wrapLabels($params["thumbnails"]).'</td></tr>
		</table>';
		$str.='<input type="hidden" name="'.$fName.'" value="'.htmlspecialchars(implode(",",$uidList)).'">';
		return $str;
	}
	
	function printNeededJSFunctions()	{
			// JS evaluation:
		$out = $this->JSbottom($this->formName);
			// 
		if ($this->printNeededJS["dbFileIcons"])	{
			$out.= '<script>
			'.$this->dbFileCon("document.".$this->formName).'
			</script>';
		}
		return $out;
	}
	function printNeededJSFunctions_top()	{
			// JS evaluation:
		$out = $this->JStop($this->formName);
		return $out;
	}
	function noTitle($str,$wrapParts=array())	{
		return $str ? $str : $wrapParts[0]."[".$GLOBALS["LANG"]->php3Lang["labels"]["no_title"]."]".$wrapParts[1];
	}
	function rearrange($fields)	{
		$fO = array_flip(t3lib_div::trimExplode(",",$this->fieldOrder,1));
		reset($fields);
		$newFields=array();
		while(list($cc,$content)=each($fields))	{
			$cP = t3lib_div::trimExplode(";",$content);
			if (isset($fO[$cP[0]]))	{
				$newFields[$fO[$cP[0]]] = $content;
				unset($fields[$cc]);
			}
		}
		ksort($newFields);
		$fields=array_merge($newFields,$fields);
		return $fields;
	}
	function setTSconfig($table,$row,$field="")	{
//debug("setTSconfig",-1);
		$mainKey = $table.":".$row["uid"];
		if (!isset($this->cachedTSconfig[$mainKey]))	{
			$this->cachedTSconfig[$mainKey]=t3lib_BEfunc::getTCEFORM_TSconfig($table,$row);
		}
		if ($field)	{
			return $this->cachedTSconfig[$mainKey][$field];
		} else {
			return $this->cachedTSconfig[$mainKey];
		}
	}
	function blur()	{
		return $GLOBALS["CLIENT"]["FORMSTYLE"] ? 'this.blur();':'';
	}
	function renderWizards($itemKinds,$wizConf,$table,$row,$field,$itemName,$fieldChangeFunc,$specConf,$RTE=0)	{
		$item = $itemKinds[0];
		$outArr=array();
		$fName='['.$table.']['.$row["uid"].']['.$field.']';
		$md5ID = t3lib_div::shortmd5($itemName);

		if (is_array($wizConf) && !$this->disableWizards)	{
			reset($wizConf);
			while(list($wid,$wConf)=each($wizConf))	{
				if (substr($wid,0,1)!="_" 
						&& (!$wConf["enableByTypeConfig"] || @in_array($wid,$specConf["wizards"]["parameters"]))
						&& ($RTE || !$wConf["RTEonly"])
					)	{
				
						// Title / icon:
					$iTitle = htmlspecialchars($this->sL($wConf["title"]));
					if ($wConf["icon"])	{
						$iDat = $this->getIcon($wConf["icon"]);
						$icon = '<img src="'.$iDat[0].' '.$iDat[3].'" border=0'.t3lib_BEfunc::titleAttrib($iTitle).'>';
					} else $icon=$iTitle;
					
					$colorBoxLinks=array();
					switch((string)$wConf["type"])	{
						case "userFunc":
						case "script":
						case "popup":
						case "colorbox":
							if (!$wConf["notNewRecords"] || t3lib_div::testInt($row["uid"]))	{
								$params = array();
								$params["params"] = $wConf["params"];
								$params["table"] = $table;
								$params["uid"] = $row["uid"];
								$params["pid"] = $row["pid"];
								$params["field"] = $field;
								$params["md5ID"] = $md5ID;
								$params["returnUrl"] = t3lib_div::linkThisScript();
								$url = $this->backPath.$wConf["script"].(strstr($wConf["script"],"?") ? "" : "?");


								if ((string)$wConf["type"]=="colorbox" && !$wConf["script"])	{
									break;
								}
								if ((string)$wConf["type"]=="script")	{
									$outArr[]='<a href="'.$url.t3lib_div::implodeArrayForUrl("",array("P"=>$params)).'" onClick="'.$this->blur().'return !TBE_EDITOR_isFormChanged();">'.$icon.'</a>';
								}

								$params["formName"]=$this->formName;
								$params["itemName"]=$itemName;
								$params["fieldChangeFunc"]=$fieldChangeFunc;
								if ((string)$wConf["type"]=="popup" || (string)$wConf["type"]=="colorbox")	{
										// Current form value is passed as P[currentValue]!
									$curSelectedValues='+\'&P[currentSelectedValues]=\'+TBE_EDITOR_curSelected(\''.$itemName.'_list\')';
									$colorBoxLinks=Array('<a href="#" onClick="'.$this->blur().'vHWin=window.open(\''.$url.t3lib_div::implodeArrayForUrl("",array("P"=>$params)).'\'+\'&P[currentValue]=\'+TBE_EDITOR_rawurlencode('.$this->elName($itemName).'.value,200)'.$curSelectedValues.',\'popUp'.$md5ID.'\',\''.$wConf["JSopenParams"].'\');vHWin.focus();return false;">','</a>');
									if ((string)$wConf["type"]=="popup")	{
										$outArr[] = $colorBoxLinks[0].$icon.$colorBoxLinks[1];
									}
								} elseif ((string)$wConf["type"]=="userFunc")	{
									$params["item"]=&$item;
									$params["icon"]=$icon;
									$params["iTitle"]=$iTitle;
									$params["wConf"]=$wConf;
									$params["row"]=$row;
									$outArr[]=t3lib_div::callUserFunction($wConf["userFunc"],$params,$this);
								}
							}
						break;
						case "select":
							$fieldValue=array("config"=>$wConf);
							$TSconfig = $this->setTSconfig($table,$row);
							$TSconfig[$field] = $TSconfig[$field]["wizards."][$wid."."];
							$selItems = $this->addSelectOptionsToItemArray($this->initItemArray($fieldValue),$fieldValue,$TSconfig,$field);
							
							reset($selItems);
							$opt=array();
							$opt[]='<option>'.$iTitle.'</option>';
							while(list(,$p)=each($selItems))	{
								$opt[]='<option value="'.htmlspecialchars($p[1]).'">'.htmlspecialchars($p[0]).'</option>';
							}
							if ($wConf["mode"]=="append")	{
								$assignValue = $this->elName($itemName).'.value=\'\'+this.options[this.selectedIndex].value+'.$this->elName($itemName).'.value';
							} elseif ($wConf["mode"]=="prepend")	{
								$assignValue = $this->elName($itemName).'.value+=\'\'+this.options[this.selectedIndex].value';
							} else {
								$assignValue = $this->elName($itemName).'.value=this.options[this.selectedIndex].value';
							}
							$outArr[]='<select name="_WIZARD'.$fName.'" onChange="
								'.$assignValue.';
								this.selectedIndex=0;
								'.implode("",$fieldChangeFunc).'">'.implode("",$opt).'</select>';
						break;
					}
					if ((string)$wConf["type"]=="colorbox")	{
						$dim = t3lib_div::intExplode("x",$wConf["dim"]);
						$dX=t3lib_div::intInRange($dim[0],1,200,20);
						$dY=t3lib_div::intInRange($dim[1],1,200,20);
						$color = $row[$field] ? ' bgcolor="'.htmlspecialchars($row[$field]).'"' : "";
						$outArr[] = '<table border=0 cellpadding=0 cellspacing=0 id="'.$md5ID.'"'.$color.' style="'.$wConf["tableStyle"].'"><tr><td>'.$colorBoxLinks[0].'<img src=clear.gif width='.$dX.' height='.$dY.t3lib_BEfunc::titleAttrib(trim($iTitle." ".$row[$field])).' border=0>'.$colorBoxLinks[0].'</td></tr></table>';
					}
				}
			}
			if (count($outArr))	{
				if ($wizConf["_HIDDENFIELD"])	$item = $itemKinds[1];
			
				$outStr="";
				$vAlign = $wizConf["_VALIGN"] ? ' valign="'.$wizConf["_VALIGN"].'"' : '';
				if (count($outArr)>1 || $wizConf["_PADDING"])	{
					$dist=intval($wizConf["_DISTANCE"]);
					if ($wizConf["_VERTICAL"])	{
						$dist=$dist?'<tr><td><img src=clear.gif width=1 height='.$dist.'></td></tr>':'';
						$outStr='<tr><td>'.implode('</td></tr>'.$dist.'<tr><td>',$outArr).'</td></tr>';
					} else {
						$dist=$dist?'<td><img src=clear.gif height=1 width='.$dist.'></td>':'';
						$outStr='<tr><td'.$vAlign.'>'.implode('</td>'.$dist.'<td'.$vAlign.'>',$outArr).'</td></tr>';
					}
					$outStr='<table border=0 cellpadding='.intval($wizConf["_PADDING"]).' cellspacing=0>'.$outStr.'</table>';
				} else {
					$outStr=implode("",$outArr);
				}

				if (!strcmp($wizConf["_POSITION"],"left"))	{
					$outStr = '<tr><td'.$vAlign.'>'.$outStr.'</td><td'.$vAlign.'>'.$item.'</td></tr>';
				} elseif (!strcmp($wizConf["_POSITION"],"top"))	{
					$outStr = '<tr><td>'.$outStr.'</td></tr><tr><td>'.$item.'</td></tr>';
				} elseif (!strcmp($wizConf["_POSITION"],"bottom"))	{
					$outStr = '<tr><td>'.$item.'</td></tr><tr><td>'.$outStr.'</td></tr>';
				} else {
					$outStr = '<tr><td'.$vAlign.'>'.$item.'</td><td'.$vAlign.'>'.$outStr.'</td></tr>';
				}

				$item='<table border=0 cellpadding=0 cellspacing=0>'.$outStr.'</table>';
			}
		}
		return $item;
	}
	function getIcon($icon)	{
		if (substr($icon,0,3)=="../")	{
			$selIconFile=$this->backPath.$icon;
			$selIconInfo = @getimagesize(PATH_site.substr($icon,3));
		} else {
			$selIconFile='t3lib/gfx/'.$icon;
			$selIconInfo = @getimagesize(PATH_t3lib."gfx/".$icon);
		}
		return array($selIconFile,$selIconInfo);
	}
	function wrapOpenPalette($header,$table,$row,$palette,$retFunc=0)	{
		$fieldL=array();
		if (!is_array($this->palFieldArr[$palette]))	{$this->palFieldArr[$palette]=array();}
		$palFieldN = is_array($this->palFieldArr[$palette]) ? count($this->palFieldArr[$palette]) : 0;
		$palJSFunc = 'TBE_EDITOR_palUrl(\''.($table.":".$row["uid"].":".$palette).'\',\''.implode(",",$this->palFieldArr[$palette]).'\','.$palFieldN.',\''.$table.'\',\''.$row["uid"].'\',1);';
		$iconCode = '<a href="#" onClick="'.$this->blur().substr($palJSFunc,0,-3).'0);return false;"'.t3lib_BEfunc::titleAttrib($table).'>'.$header.'</a>';
		return $retFunc ? array($iconCode,$palJSFunc) : $iconCode;
	}
	function isPalettesCollapsed($table,$palette)	{
		global $TCA;
		
		if ($TCA[$table]["ctrl"]["canNotCollapse"]) return 0;
		if (is_array($TCA[$table]["palettes"][$palette]) && $TCA[$table]["palettes"][$palette]["canNotCollapse"])	return 0;
		return $this->palettesCollapsed;
	}
	function doLoadTableDescr($table)	{
		global $TCA;
		return $TCA[$table]["interface"]["always_description"];
	}
	function getTSCpid($table,$uid,$pid)	{
		$key = $table.":".$uid.":".$pid;
		if (!isset($this->cache_getTSCpid[$key]))	{
			$this->cache_getTSCpid[$key] = t3lib_BEfunc::getTSCpid($table,$uid,$pid);
		}
		return $this->cache_getTSCpid[$key];
	}
}










class t3lib_TCEforms_FE extends t3lib_TCEforms {
	function wrapLabels($str)	{
		return '<font face=verdana size=1 color=black>'.$str.'</font>';
	}
	function printPalette($palArr)	{
		$out="";
		reset($palArr);
		$bgColor=' bgColor="#D6DAD0"';
		while(list(,$content)=each($palArr))	{
			$hRow[]='<td'.$bgColor.'><font face=verdana size=1>&nbsp;</font></td><td nowrap'.$bgColor.'><font color=#666666 face=verdana size=1>'.$content["NAME"].'</font></td>';
			$iRow[]='<td valign=top><img name="req_'.$content["TABLE"].'_'.$content["ID"].'_'.$content["FIELD"].'" src="clear.gif" width=10 height=10><img name="cm_'.$content["TABLE"].'_'.$content["ID"].'_'.$content["FIELD"].'" src="clear.gif" width=7 height=10></td><td nowrap valign=top>'.$content["ITEM"].$content["HELP_ICON"].'</td>';
		}
		$out='<table border=0 cellpadding=0 cellspacing=0>
		<tr><td><img src=clear.gif width='.intval($this->paletteMargin).' height=1></td>'.implode("",$hRow).'</tr>
		<tr><td></td>'.implode("",$iRow).'</tr>
		</table>';

		return $out;
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tceforms.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tceforms.php"]);
}

?>