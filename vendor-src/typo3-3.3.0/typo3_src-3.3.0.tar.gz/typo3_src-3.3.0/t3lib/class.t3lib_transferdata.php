<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Generate data for a record, transfer to Backend interface...
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

include_once(PATH_t3lib."class.t3lib_loadmodules.php");
include_once(PATH_t3lib."class.t3lib_parsehtml_proc.php");

class t3lib_transferData {
	var $formname = "loadform";
	var $loading = 1;	// updating or updating data
	var $lockRecords=0;		// If set, the records requested are locked.
	var $disableRTE=0;
	
		// Internal
	var $HTML_code = "";
	var $JS_code = "";
	var $JS_code_RTEflag = "";
	var $prevPageID = "";		// If the pid in the command is "prev" then $prevPageID is used as pid for the record. This is used to attach new records to other previous records eg. new pages.
	var $recCount = 0;
	var $regTableItems = Array();	// Used to register, which items are already loaded!!
	var $regTableItems_data = Array();	// This stores the record data of the loaded records

	var $tt_content_limit = 10;
		// Bruges, hvis der kun er �n record!!
	var $lastTable=""; 
	var $lastID=0; 
	var $lastPID=0;	
	
	var $loadModules="";

	function start($edit)	{
		global $TCA;
		if (is_array($edit))	{
			reset ($edit);
			while (list($key,$val) = each($edit))	{
				while(list($key2,$val2)=each($val))	{
					$table = $key;
					$id = $key2;
					$operation = $val2;
					$this->fetchRecord($table,$id,$operation);
				}
			}
		}
	}
	function fetchRecord($table,$idList,$operation)	{
		global $TCA;
		$idList=$idList."";
		if ($idList == "prev")	{$idList = $this->prevPageID;}
		if ($TCA[$table])	{
			t3lib_div::loadTCA($table);
			$ids = explode(",",$idList);
			while (list(,$id)=each($ids)){
				$id=trim($id);
//			echo '<script>alert("'.$idList.'");</script>';
				if (strcmp($id,""))	{
					if($operation=="new")	{
							// Default values:
						$newRow = Array();
						$newValues=0;
							// Default values as set in userTS:
						$TCAdefaultOverride = $GLOBALS["BE_USER"]->getTSConfigProp("TCAdefaults");
						if (is_array($TCAdefaultOverride[$table."."]))	{
							reset($TCAdefaultOverride[$table."."]);
							while(list($theF,$theV)=each($TCAdefaultOverride[$table."."]))	{
								if ($TCA[$table]["columns"][$theF])	{
									$newRow[$theF]=$theV;
									$newValues=1;
								}
							}
						}
							// Default values as submitted:
						if (is_array($GLOBALS["defVals"][$table]))	{
							reset($GLOBALS["defVals"][$table]);
							while(list($theF,$theV)=each($GLOBALS["defVals"][$table]))	{
								if ($TCA[$table]["columns"][$theF])	{
									$newRow[$theF]=$theV;
									$newValues=1;
								}
							}
						}
							// Fetch default values if a previous record exists
						if ($id<0 && $TCA[$table]["ctrl"]["useColumnsForDefaultValues"])	{
								// Fetches the previous record:
							$query = "select * from $table where uid='".abs($id)."'".t3lib_BEfunc::deleteClause($table);
							$res = mysql(TYPO3_db,$query);
							echo mysql_error();
							if ($row = mysql_fetch_assoc($res))	{
									// Gets the list of fields to copy from the previous record.
								$fArr=explode(",",$TCA[$table]["ctrl"]["useColumnsForDefaultValues"]);
								while(list(,$theF)=each($fArr))	{
									if ($TCA[$table]["columns"][$theF])	{
										$newRow[$theF]=$row[$theF];
										$newValues=1;
									}
								}
							}
						}
						$this->renderRecord($table, uniqid("NEW"), $id, $newRow, $newValues);
					} else {
						$id=intval($id);
						// Fetch database values
						$res = mysql(TYPO3_db,"select * from $table where uid='$id'".t3lib_BEfunc::deleteClause($table));
						echo mysql_error();
						if ($row = mysql_fetch_assoc($res))	{
							$this->renderRecord($table, $id, $row["pid"], $row);
							$contentTable = $GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"];
							$this->lockRecord($table, $id, $contentTable==$table?$row["pid"]:0);	// Loggin the pid if the table edited is the content table.
							if ($table == "pages" && $GLOBALS["edit_content"] && $TCA[$contentTable])	{		// Fetches all tt_content on a page if it exist!!
								$tableName = $contentTable;
								$parentCol = "pid";
								$orderBy = ($TCA[$contentTable]["ctrl"]["sortby"]) ? "order by ".$TCA[$contentTable]["ctrl"]["sortby"] : $TCA[$contentTable]["ctrl"]["default_sortby"];
								$limit = " LIMIT ".$this->tt_content_limit;
								$theHidden = $TCA[$contentTable]["ctrl"]["enablecolumns"]["disabled"] ? "AND NOT ".$TCA[$contentTable]["ctrl"]["enablecolumns"]["disabled"] : "";
		
								$query = sprintf("select * from %s where %s = '%s' %s %s %s %s",		$tableName, $parentCol, $id, t3lib_BEfunc::deleteClause($tableName), $theHidden, $orderBy, $limit );
							
								$res = mysql(TYPO3_db,$query);
								while ($row = mysql_fetch_assoc($res))	{
									$this->renderRecord($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"], $row["uid"], $id, $row);
									$this->lockRecord($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"], $row["uid"],$id);
								}
							}
						}
					}
				}
			}
		}
	}
	function lockRecord($table, $id, $pid=0)	{
		if ($this->lockRecords)	{
			t3lib_BEfunc::lockRecords($table,$id,$pid);
		}
	}
	function renderRecord($table, $id, $pid, $row, $newValues=0)	{
		global $TCA;
		$uniqueItemRef = $table.'_'.$id;
		t3lib_div::loadTCA($table);
		
//		debug(array_merge($row,array("uid"=>$id,"pid"=>$pid)));
//debug("transfer");
		list($tscPID)=t3lib_BEfunc::getTSCpid($table,$id,$pid);	// Fetches the true PAGE TSconfig pid to use later, if needed. (Until now, only for the RTE, but later..., who knows?)
//debug(array($table,$tscPID));

		$TSconfig = t3lib_BEfunc::getTCEFORM_TSconfig($table,array_merge($row,array("uid"=>$id,"pid"=>$pid)));

		
		if (!$this->regTableItems[$uniqueItemRef])	{		// Load record only once!!
			$this->regTableItems[$uniqueItemRef] = 1;
	
			if ($table == "pages")	{$this->prevPageID = $id;}
			$this->recCount++;
			if ($this->loading)	{
					$this->addToJS("\n parent.editWin.docs[docNum].addRec('".t3lib_div::slashJS($table)."','".t3lib_div::slashJS($id)."','".t3lib_div::slashJS($pid)."');");
				$typeField = $TCA[$table]["ctrl"]["type"];
					$this->addToJS("\n parent.data.create('".t3lib_div::slashJS($table)."','".t3lib_div::slashJS($id)."','".t3lib_div::slashJS($pid)."','".t3lib_div::slashJS($typeField)."','');");
				$this->lastTable=$table; 
				$this->lastID=$id; 
				$this->lastPID=$pid; 
			}
			$this->addToJS("\n parent.data.setImage('".t3lib_div::slashJS($table)."','".t3lib_div::slashJS($id)."','".t3lib_div::slashJS(t3lib_iconWorks::getIcon($table,$row))."');");
			$totalRecordContent=array();
			$newFieldCache=array();
			$copyOfColumns = $TCA[$table]["columns"];
			reset($copyOfColumns);
			while (list($field,$content) = each($copyOfColumns))	{
				$newField=0;
				if (isset($row[$field]))	{
					$data = $row[$field];
					if ($newValues)	$newField=1;
				} else {
 					$data = $content["config"]["default"];
				}
				if ($content["config"]["type"]=="group") {
					switch ($content["config"]["internal_type"])	{
						case "file":
							if ($content["config"]["MM"])	{
								$data="";
								$loadDB = t3lib_div::makeInstance("t3lib_loadDBGroup");
								$loadDB->start("", "files", $content["config"]["MM"], $row["uid"]);	// Setting dummy startup
//								debug($loadDB->itemArray);
	//							debug($loadDB->tablesArray);
								reset($loadDB->itemArray);
								while (list($somekey,$someval)=each($loadDB->itemArray))	{
									if ($someval["id"])	{
										$data.=rawurlencode($someval["id"]).'|'.rawurlencode($someval["id"]).',';
									}
								}
//								debug($data);
							} else {
								$temp = explode(",",$data);
								$data="";
								while (list($somekey,$someval)=each($temp))	{
									if ($someval)	{
										$data.=rawurlencode($someval).'|'.rawurlencode($someval).',';
	//									$data.=rawurlencode($someval).'|'.rawurlencode($someval).'|'.rawurlencode("path to file").',';
									}
								}
							}
						break;
						case "db":
							$loadDB = t3lib_div::makeInstance("t3lib_loadDBGroup");
							$loadDB->start($data, $content["config"]["allowed"], $content["config"]["MM"], $row["uid"]);
							$loadDB->getFromDB();
							$data = $loadDB->readyForInterface();
							$this->addToJS($loadDB->thumbsForInterface());
							$this->addToJS($loadDB->pathRefsForInterface());
						break;
					}
				}
				if ($content["config"]["type"]=="select") {
					if ($content["config"]["maxitems"]>1)	{
						$elements = explode(",",$data);
						$oldData=$data;
						$data="";
						switch ($content["config"]["special"])	{
							case "tables":
								while (list($somekey,$someval)=each($elements))	{
									if ($TCA[$someval])	{
										$data.=rawurlencode($someval).'|'.rawurlencode($this->sL($TCA[$someval]["ctrl"]["title"])).',';
									}
								}
							break;
							case "pagetypes":
								$theTypes = $TCA["pages"]["columns"]["doktype"]["config"]["items"];
								if (is_array($theTypes))	{
									while (list($somekey,$someval)=each($elements))	{
										reset($theTypes);
										while (list(,$theTypesArrays)=each($theTypes))	{
											if ($theTypesArrays[1]==$someval)	{
												$data.=rawurlencode($someval).'|'.rawurlencode($this->sL($theTypesArrays[0])).',';
												break;
											}
										}
									}
								}
							break;
							case "exclude":
								$theTypes = t3lib_BEfunc::getExcludeFields();
								if (is_array($theTypes))	{
									while (list($somekey,$someval)=each($elements))	{
										reset($theTypes);
										while (list(,$theTypesArrays)=each($theTypes))	{
											if ($theTypesArrays[1]==$someval)	{
												$data.=rawurlencode($someval).'|'.rawurlencode(ereg_replace(":$","",stripslashes($theTypesArrays[0]))).',';
												break;
											}
										}
									}
								}
							break;
							case "modListGroup":
								if (!$this->loadModules)	{
									$this->loadModules = t3lib_div::makeInstance("t3lib_loadModules");
									$this->loadModules->load($GLOBALS["TBE_MODULES"]);
								}
								while (list(,$someval)=each($elements))	{
									reset($this->loadModules->modListGroup);
									while(list(,$theModName)=each($this->loadModules->modListGroup))	{
										if ($theModName==$someval)	{
											$data.=rawurlencode($someval).'|'.rawurlencode($someval).',';
											break;
										}
									}
								}
							break;
							case "modListUser":
								if (!$this->loadModules)	{
									$this->loadModules = t3lib_div::makeInstance("t3lib_loadModules");
									$this->loadModules->load($GLOBALS["TBE_MODULES"]);
								}
								while (list(,$someval)=each($elements))	{
									reset($this->loadModules->modListUser);
									while(list(,$theModName)=each($this->loadModules->modListUser))	{
										if ($theModName==$someval)	{
											$data.=rawurlencode($someval).'|'.rawurlencode($someval).',';
											break;
										}
									}
								}
							break;
							default:
								if (is_array($content["config"]["items"]))	{
									$content["config"]["items"] = $this->procesItemArray($content["config"]["items"], $content["config"], $TSconfig[$field], $table,$row,$field);
									reset($content["config"]["items"]);
									$data="";
									while(list(,$pvpv)=each($content["config"]["items"]))	{
										if (t3lib_div::inList($oldData,$pvpv[1]))	{
											$data.=rawurlencode($pvpv[1]).'|'.rawurlencode($pvpv[0]).',';
										}
									}
								} else {
									$data=$oldData;
								}
							break;
						}
						if ($TCA[$content["config"]["foreign_table"]])	{

								// foreign_table
							$tempArr = Array();
							$query= t3lib_BEfunc::foreign_table_where_query($content,$field,$TSconfig);
							$subres = mysql(TYPO3_db,$query);
							if (mysql_error())	debug($query);
							while ($subrow = mysql_fetch_assoc($subres))	{
								$tempArr[$subrow["uid"]] = t3lib_BEfunc::getRecordTitle($content["config"]["foreign_table"],$subrow);
							}
								// neg_foreign_table
							if ($TCA[$content["config"]["neg_foreign_table"]])	{
								$query= t3lib_BEfunc::foreign_table_where_query($content,$field,$TSconfig,"neg_");
								$subres = mysql(TYPO3_db,$query);
								if (mysql_error())	debug($query);
								while ($subrow = mysql_fetch_assoc($subres))	{
									$tempArr[-$subrow["uid"]] = t3lib_BEfunc::getRecordTitle($content["config"]["neg_foreign_table"],$subrow);
								}
							}

							// Getting the data
							$loadDB = t3lib_div::makeInstance("t3lib_loadDBGroup");
							$loadDB->start($data, $content["config"]["foreign_table"].",".$content["config"]["neg_foreign_table"], $content["config"]["MM"], $row["uid"]);
							$temp = $loadDB->convertPosNeg($loadDB->getValueArray(),$content["config"]["foreign_table"]);
							$data="";
							reset($temp);
							while (list(,$someval)=each($temp))	{
								if (isset($tempArr[$someval]))	{
									$lPrefix = $this->sL($content["config"][($someval>0?"":"neg_")."foreign_table_prefix"]);
									$data.=rawurlencode($someval).'|'.rawurlencode(t3lib_div::fixed_lgd($lPrefix.strip_tags($tempArr[$someval]),$GLOBALS["BE_USER"]->uc["titleLen"])).',';
								}
							}
						}
					} else {	// Normal, <= 1 -> value without title on it
						if ($TCA[$content["config"]["foreign_table"]])	{
							// Getting the data
							$loadDB = t3lib_div::makeInstance("t3lib_loadDBGroup");
							$loadDB->start($data, $content["config"]["foreign_table"].",".$content["config"]["neg_foreign_table"], $content["config"]["MM"], $row["uid"]);
							$temp = $loadDB->convertPosNeg($loadDB->getValueArray(),$content["config"]["foreign_table"]);
							if (!count($temp))	$temp=array(0);
							reset($temp);
						} else {
							$temp = explode(",",$data,2);
						}
						$data = $temp[0];
					}
				}
				$totalRecordContent[$field]=isset($data)?$data:"";
				$newFieldCache[$field]=$newField;
			}

				// First, find the REAL pid (page-id) of the new record, if the pid is negative,
/*			$fetchConfigPid=$pid;
			if ($fetchConfigPid<0)	{
				$temp_pidRecord=t3lib_BEfunc::getRecord($table,abs($fetchConfigPid),"pid");
				$fetchConfigPid=$temp_pidRecord["pid"];
			}
*/				// Check types_fieldConfig if there is any rte_transform config
			$types_fieldConfig=t3lib_BEfunc::getTCAtypes($table,$totalRecordContent);
			if (is_array($types_fieldConfig))	{
				reset($types_fieldConfig);
				while(list(,$vconf)=each($types_fieldConfig))	{
						// Write file configuration:
					$eFile=t3lib_parsehtml_proc::evalWriteFile($vconf["spec"]["static_write"],$totalRecordContent);
					if (is_array($eFile))	{
						if ($eFile["loadFromFileField"] && $totalRecordContent[$eFile["loadFromFileField"]])	{
							$SW_fileContent = t3lib_div::getUrl($eFile["editFile"]);
							$parseHTML = t3lib_div::makeInstance("t3lib_parsehtml_proc");
							$parseHTML->init("","");
							$totalRecordContent[$vconf["field"]] = $parseHTML->getSubpart(
								$SW_fileContent,
								$eFile["markerField"]&&trim($totalRecordContent[$eFile["markerField"]]) 
									? trim($totalRecordContent[$eFile["markerField"]]) 
									: "###TYPO3_STATICFILE_EDIT###",
								chr(10).$totalRecordContent[$eFile["contentField"]].chr(10),
								1,1);
						}
					}
						// RTE transformation
					if ($vconf["spec"]["rte_transform"] && !$this->disableRTE)	{
						$p=t3lib_BEfunc::getSpecConfParametersFromArray($vconf["spec"]["rte_transform"]["parameters"]);
						if ($p["mode"])	{	// There must be a mode set for transformation
							if (isset($totalRecordContent[$vconf["field"]]))	{
								if ($tscPID>=0)	{
//debug("RTEsetup");
									$RTEsetup = $GLOBALS["BE_USER"]->getTSConfig("RTE",t3lib_BEfunc::getPagesTSconfig($tscPID));
									$thisConfig = t3lib_BEfunc::RTEsetup($RTEsetup["properties"],$table,$vconf["field"],t3lib_BEfunc::getTCAtypeValue($table,$totalRecordContent));
									if (!$thisConfig["disabled"] && (!$p["flag"] || !$totalRecordContent[$p["flag"]]) && $GLOBALS["BE_USER"]->isRTE())	{	// ... and any disable flag should not be set!
										$parseHTML = t3lib_div::makeInstance("t3lib_parsehtml_proc");
										$parseHTML->init($table.":".$vconf["field"],$pid);
										if (is_array($eFile))	{$parseHTML->setRelPath(dirname($eFile["relEditFile"]));}
										$totalRecordContent[$vconf["field"]]=$parseHTML->RTE_transform($totalRecordContent[$vconf["field"]],$vconf["spec"],"rte",$thisConfig);
	
										$this->JS_code_RTEflag.="
			parent.data.setRTEFlag('".$table."','".$id."','".$vconf["field"]."');	";
									}
									$newFieldCache[$vconf["field"]]=1;	// Setting newField true will force the value to be set in the TBE interface.
								}
							}
						}
					}
				}
			}
				// Register items
			reset($totalRecordContent);
			while(list($field,$data)=each($totalRecordContent))	{
				$newField = $newFieldCache[$field];
//				debug($field.": ".$newField,1);
				$this->regItem($table,$id,$field,$data,$newField);
			}
			reset($totalRecordContent);
			$this->regTableItems_data[$uniqueItemRef]=$totalRecordContent;
		}
	}
	function procesItemArray($selItems,$config,$fieldTSConfig,$table,$row,$field)	{
		$selItems = $this->addItems($selItems,$fieldTSConfig["addItems."]);
		if ($config["itemsProcFunc"]) $selItems = $this->procItems($selItems,$fieldTSConfig["itemsProcFunc."],$config,$table,$row,$field);
		return $selItems;
	}
	/**
	 */
	function addItems($items,$iArray)	{
		if (is_array($iArray))	{
			reset($iArray);
			while(list($value,$label)=each($iArray))	{
				$items[]=array($label,$value);
			}
		}
		return $items;
	}
	/**
	 */
	function procItems($items,$iArray,$config,$table,$row,$field)	{
		$params=array();
		$params["items"] = &$items;
		$params["config"] = $config;
		$params["TSconfig"] = $iArray;
		$params["table"] = $table;
		$params["row"] = $row;
		$params["field"] = $field;
	
		t3lib_div::callUserFunction($config["itemsProcFunc"],$params,$this);
		return $items;
	}
	
	
	
	function getJSCode ()	{
		$result = "
function load(table,id,field,newF)	{
	var theValue = document.".$this->formname."['load['+table+']['+id+']['+field+']'].value;
	var rec = parent.data.rec[table+'_'+id];
	var stringID = ''+id;
//	var newRec = stringID.indexOf('NEW');
	var newRec = (newF) ? 1 : -1;		// Added 24-10-00
	var testVal='';
	if (rec)	{
		if (rec.field[field])	{
			testVal = rec.field[field].data['client'];
			testVal_unescaped = unescape(testVal);
			if (rec.field[field].pointer == 'client' 
				&& testVal != theValue 
				&& !newF	// Added 21.11.01, needed to force RTE-values in (and new values in general)
				&& testVal
				&& !(parent.TCA.tables[table].fields[field].internal_type=='file' && testVal_unescaped.indexOf('/')!=-1)
				)	{		// If client and the dbvalue and loaded values are different AND if the value is set at all, then make it fresh
				parent.data.update(table, id, field, theValue, 'fresh', 1);		// 'fresh' seems to mean that the value is different on server, but not inserted in interface...
			} else {
				parent.data.load(table, id, field, theValue, 'server');	
			}
		} else {
			parent.data.load(table, id, field, theValue, ((newRec!=-1)?'client':'server'));	
		}
	}
}
";
		return $result.$this->JS_code.$this->JS_code_RTEflag;
	}
	function getHTMLCode ()	{
		$result = '<form action="" method="POST" name="'.$this->formname.'">';
		$result.= $this->HTML_code;
		$result.= "\n</form>\n";
		return $result;
	}
	function addToJS ($JScode)	{
		$this->JS_code.=$JScode;
	}
	function regItem($table, $id, $field, $content, $newF)	{
		$this->HTML_code.= '
	<input type="Hidden" name="load['.$table.']['.$id.']['.$field.']" value="'.HTMLSpecialChars($content).'">';
		$this->JS_code.="
	load('".t3lib_div::slashJS($table)."','".t3lib_div::slashJS($id)."','".t3lib_div::slashJS($field)."',".$newF.");";
	}
	function sL($in)	{
		if (is_object($GLOBALS["LANG"]))	{
			return $GLOBALS["LANG"]->sL($in);
		} else {
			return $GLOBALS["BE_USER"]->extSL($in);
		}
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_transferdata.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_transferdata.php"]);
}

?>