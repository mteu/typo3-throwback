<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Typo3 user authentication, backend and frontend
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
class t3lib_beUserAuth extends t3lib_userAuthGroup {
	var $session_table = "be_sessions"; 		// Table to use for session data.
	var $name = "be_typo_user";                 // Session/Cookie name

	var $user_table = "be_users"; 					// Table in database with userdata
	var $username_column = "username"; 			// Column for login-name
	var $userident_column = "password"; 		// Column for password
	var $userid_column = "uid"; 					// Column for user-id
	var $lastLogin_column = "lastlogin";
	var $notifyHeader = "From: Typo3 Login notify <no_reply@no_reply.no_reply>";
	
	var $enablecolumns = Array (
		"rootLevel" => 1,
		"deleted" => "deleted",
		"disabled" => "disable",
		"starttime" => "starttime",
		"endtime" => "endtime"
	);
	
	var $formfield_uname = "username"; 			// formfield with login-name
	var $formfield_uident = "userident"; 		// formfield with password
	var $formfield_chalvalue = "challenge";		// formfield with a unique value which is used to encrypt the password and username
	var $formfield_status = "login_status"; 	// formfield with status: *"login", "logout"
	var $security_level = "challenged";				// sets the level of security. *"normal" = clear-text. "challenged" = hashed password/username from form in $formfield_uident. "superchallenged" = hashed password hashed again with username.

	var $writeStdLog = 1;					// Decides if the writelog() function is called at login and logout
	var $writeAttemptLog = 1;				// If the writelog() functions is called if a login-attempt has be tried without success
	
	var $auth_include = "";						// this is the name of the include-file containing the login form. If not set, login CAN be anonymous. If set login IS needed.
	
	var $auth_timeout_field = 6000;				// if > 0 : session-timeout in seconds. if false/<0 : no timeout. if string: The string is fieldname from the usertable where the timeout can be found.
	var $lifetime = 0;                  		// 0 = Session-cookies. If session-cookies, the browser will stop session when the browser is closed. Else it keeps the session for $lifetime seconds.



		// User Config:
	var $uc;

		// User Config Default values:
		
		/*
		Reserved keys for other storage of session data:
		
			moduleData		
			interfaceSetup
			moduleSessionID
		
		*/
	var $uc_default = Array (
//		"lang" => "dk",		// this value will be transferred from $BE_USER->user[lang] if not set...
		"interfaceSetup" => "",	// serialized content that is used to store interface pane and menu positions. Set by the logout.php-script
		"moduleData" => Array(),	// user-data for the modules
		"pane_clip_count" => 3,
		"pane_web" => "Pages",
		"pane_file" => "Folders",
		"thumbnailsByDefault" => 0,
		"emailMeAtLogin" => 0,
		"openDirectly" => 1,
		"alternativeBackend" => 0,
		"condensedMode" => 0,
		"noMenuMode" => 0,
		"startInTaskCenter" => 0,
		"localFrameEdit" => 0,
		"saveTreePositions" => 1,
		"dontEditInPageModule" => 0,
		"hideSubmoduleIcons" => 0,
		"helpText" => 1,
		"titleLen" => 30,
		"edit_wideDocument" => "0",
		"edit_showFieldHelp" => "icon",
		"edit_RTE" => "1",
		"edit_maxRecords" => "5",		// default is 10, changed to 5 14-12-01 because the RTE is introduced and takes some more power here.
		"edit_docModuleUpload" => "1",
		"disableCMlayers" => 0,
		"navFrameWidth" => "",	// Default is 245 pixels
		"winH" => 0,	// Old: 550
		"winW" => 0	// Standard is 655, latest is 775
	);

	function trackBeUser($flag)	{
		if ($flag)	{
			$query = "INSERT INTO sys_trackbeuser (userid,tstamp,script) VALUES (".$this->user["uid"].",".time().",'".addslashes(getenv("REQUEST_URI"))."')";
			$res = mysql(TYPO3_db,$query);
		}
	}
	function checkLockToIP()	{
		global $TYPO3_CONF_VARS;
		$out=1;
		if ($TYPO3_CONF_VARS["BE"]["enabledBeUserIPLock"])	{
			$IPList = $this->getTSConfigVal("options.lockToIP");
			if (trim($IPList))	{
				$baseIP = getenv("REMOTE_ADDR");
				$out=t3lib_div::cmpIP($baseIP, $IPList);
			}
		}
		return $out;
	}
	function backendCheckLogin()	{
		// Check if user is logged in.
		if (!$this->user["uid"])	{
			if (!defined("TYPO3_PROCEED_IF_NO_USER") || !TYPO3_PROCEED_IF_NO_USER)	{
				t3lib_BEfunc::typo3PrintError ("Login-error","No user logged in! Sorry, I can't proceed then!",0);
				exit;
			}
		} else {	// ...and if that's the case, call these functions
			$this->fetchGroupData();	//	The groups are fetched and ready for permission checking in this initialization.	Tables.php must be read before this because stuff like the modules has impact in this 
			if ($this->checkLockToIP())	{
				$this->backendSetUC();		// Setting the UC array. It's needed with fetchGroupData first, due to default/overriding of values.
				$this->emailAtLogin();		// email at login - if option set.
			} else {
				t3lib_BEfunc::typo3PrintError ("Login-error","IP locking prevented you from being authorized. Can't proceed, sorry.",0);
				exit;
			}
		}
	}
	function resetUC()	{
		$this->user[uc]="";
		$this->uc="";
		$this->backendSetUC();
	}
	function backendSetUC()	{
			// UC - user configuration is a serialized array inside the userobject
		$temp_theSavedUC=unserialize($this->user[uc]);		// if there is a saved uc we implement that instead of the default one.
		if (is_array($temp_theSavedUC))	{
			$this->unpack_uc($temp_theSavedUC);
		}
			// Setting defaults if uc is empty
		if (!is_array($this->uc))	{
			$this->uc = array_merge($this->uc_default,$TYPO3_CONF_VARS["BE"]["defaultUC"],$this->getTSConfigProp("setup.default"));
			$this->overrideUC();
			$U=1;
		}
			// If TSconfig is updated, update the defaultUC.
		if ($this->userTSUpdated)	{
			$this->overrideUC();
			$U=1;
		}
			// Setting default lang from be_user record.
		if (!isset($this->uc[lang]))	{
			$this->uc[lang]=$this->user[lang];
			$U=1;
		}
			// Saving if updated.
		if ($U)	{
			$this->writeUC();
		}
	}
	function overrideUC()	{
			// Override: Call this function every time the uc is updated. That is 1) by reverting to default values, 2) in the setup-module, 3) userTS changes (userauthgroup)
		$this->uc = array_merge($this->uc,$this->getTSConfigProp("setup.override"));
	}
	function emailAtLogin()	{
			// Send notify-mail
		$subject = "At '".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]."' from ".getenv("REMOTE_ADDR").(getenv("REMOTE_HOST") ? " (".getenv("REMOTE_HOST").")" : "");
		$msg = sprintf ("User '%s' logged in from %s (%s) at '%s' (%s)", 
			$this->user["username"],
			getenv("REMOTE_ADDR"),
			getenv("REMOTE_HOST"),
			$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"],
			getenv("HTTP_HOST")
		);

			// warning address:		
		if ($this->loginSessionStarted)	{
			if ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_email_addr"])	{
				$warn=0;
				$prefix="";
				if (intval($GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_mode"]) & 1)	{	// first bit
					$warn=1;
					$prefix= $this->user["admin"] ? "[AdminLoginWarning]" : "[LoginWarning]";
				}
				if ($this->user["admin"] && (intval($GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_mode"]) & 2))	{	// first bit
					$warn=1;
					$prefix="[AdminLoginWarning]";
				}
				if ($warn)	{
					mail($GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_email_addr"],
						$prefix." ".$subject,
						$msg,
						$this->notifyHeader
					);
				}
			}
			if ($this->uc["emailMeAtLogin"] && strstr($this->user[email],"@"))	{
				mail($this->user[email],
					$subject,
					$msg,
					$this->notifyHeader
				);
			}
		}
	}
	/**
	 * VeriCode returns 10 first chars of a md5 hash of the session cookie AND the encryptionKey from TYPO3_CONF_VARS. 
	 * This code is used as an alternative verification when the JavaScript interfacee executes cmd's to tce_db.php from eg. MSIE 5.0 because the proper referer is not passed with this browser...
	 */
	function veriCode()	{
		return substr(md5($this->id.$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["encryptionKey"]),0,10);
	}
}





if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_beuserauth.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_beuserauth.php"]);
}


?>