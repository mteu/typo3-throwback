<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Template object that is responsible for generating the template
 *
 * @see		t3lib_tsparser.php, t3lib_matchcondition.php
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

include_once(PATH_t3lib."class.t3lib_tsparser.php");
include_once(PATH_t3lib."class.t3lib_matchcondition.php");


class t3lib_TStemplate	{
	var $whereClause = "";	// This MUST be initialized by the init() function
	var $tt_track = 1;		// If set, the global tt-timeobject is used to log the performance.
	var $matchAlternative=array();		// This array is passed on to matchObj by generateConfig(). If it holds elements, they are used for matching instead. See commment at the match-class. Used for backend modules only. Never frontend!
	var $matchAll=0;		// If set the match-class mateches everything! Used for backend modules only. Never frontend!
	var $forceTemplateParsing=0;	// If set, the template is always rendered
	var $parserErrors=array();
	
	var $uplPath = "uploads/tf/";
	var $tempPath = "typo3temp/";
	var $menuclasses = "gmenu,tmenu,imgmenu,jsmenu";
	var $debug = 0;
	var $allowedPaths = Array ("media/","fileadmin/","uploads/","typo3temp/");			// This is the only paths (relative!!) that are allowed for resources in TypoScript. Should all prepended with "/". You can extend these by the global array TYPO3_CONF_VARS. See init() function.
	var $currentPageData = "";
	var $getFileName_backPath="";		// Set from the backend - used to set an absolute path (PATH_site) so that relative resources are properly found with getFileName()
	
	var $ext_constants_BRP=0;
	var $ext_config_BRP=0;
		// internal
	var $loaded = 0;
	var $setup = Array(
		"styles." => Array (
			"insertContent" => "CONTENT",
			"insertContent." => Array (
				"table" => "tt_content",
				"select." => Array (
					"orderBy" => "sorting",
					"where" => "colPos=0"
				)
			)
		),
		"config." => Array (
			"extTarget" => "_top",
			"stat" => 1,
			"stat_typeNumList" => "0,1"
		)
	);
	var $flatSetup = Array (
	);
	var $const = Array (
		"_clear" => '<img src="clear.gif" width=1 height=1>',
		"_blackBorderWrap" => '<table border=0 bgColor="black" cellspacing=0 cellpadding=1><tr><td> | </td></tr></table>',
		"_tableWrap" => '<table border=0 cellspacing=0 cellpadding=0> | </table>',
		"_tableWrap_DEBUG" => '<table border=1 cellspacing=0 cellpadding=0> | </table>',
		"_stdFrameParams" => 'frameborder="NO" marginheight="0" marginwidth="0" noresize',
		"_stdFramesetParams" => 'border="0" framespacing="0" frameborder="NO"'
	);
	
	
	var $fileCache = Array();
	
	var $rootId;
	var $rootLine;
	var $frames = Array();	// Keys bliver her frame-names og values er type-v�rdierne, som skal bruges til at referere korrekt til framens indhold. Dette s�ttes op i main.php under skabelonerne
	
	
		// ts_analyzer
	var $clearList_const=array();
	var $clearList_setup=array();
	var $backend_info = 0;
	var $setup_constants = array();
	var $simulationHiddenOrTime=0;

	function init()	{
		// init() MUST be run directly after creating a new template-object
		// whereClause is used only to select templates from sys_template.
		// sim_exec_time is used so that we're able to simulate a later time as a test...
		$this->whereClause="AND NOT deleted ";
		if (!$GLOBALS["TSFE"]->showHiddenRecords)	{
			$this->whereClause.="AND NOT hidden ";
		}
		if ($GLOBALS["TSFE"]->showHiddenRecords || $GLOBALS["SIM_EXEC_TIME"]!=$GLOBALS["EXEC_TIME"])	{	// Set the simulation flag, if simulation is detected!
			$this->simulationHiddenOrTime=1;
		}
		$this->whereClause.= "AND (starttime<=".$GLOBALS["SIM_EXEC_TIME"].") AND (endtime=0 OR endtime>".$GLOBALS["SIM_EXEC_TIME"].")";
		if (!$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"])	{
			$this->menuclasses="tmenu,jsmenu";
		}
		if ($GLOBALS["TYPO3_CONF_VARS"]["FE"]["addAllowedPaths"])	{
			$pathArr = t3lib_div::trimExplode(",",$GLOBALS["TYPO3_CONF_VARS"]["FE"]["addAllowedPaths"],1);
			while(list(,$p)=each($pathArr))	{	
					// Once checked for path, but as this may run from typo3/mod/web/ts/ dir, that'll not work!! So the paths ar uncritically included here.
				$this->allowedPaths[] = $p;
			}
		}
	}
	function getCurrentPageData()	{
		/*
		NOTE about currentPageData:
			It holds from information about the TYpoScript conditions along with the list of template uid's which is used on the page.
			In the getFromCache function in TSFE, currentPageData is used to evaluate if there is a template and if the matching conditions are alright

			Unfortunately this does not take into account if the templates in the rowSum of currentPageData has changes composition, eg due to hidden fields or start/end time.
			So if a template is hidden or times out, it'll not be discovered unless the page is regenerated - at least the this->start function must be called, because this will make a new portion of data in currentPageData string
		*/
		$res = mysql(TYPO3_db, "SELECT content FROM cache_pagesection WHERE page_id = '".$GLOBALS["TSFE"]->id."'");
		if ($row=mysql_fetch_assoc($res))	{
			$this->currentPageData = unserialize($row["content"]);
		} else {
			$this->currentPageData = "none";
		}
//		debug($this->currentPageData);
		return $this->currentPageData;
	}
	function matching($cc)	{	
			// this function fetches data about which TypoScript-matches there are at this page. Then it performs a matchingtest.
		if (is_array($cc["all"]))	{
			reset($cc["all"]);
			$matchObj = t3lib_div::makeInstance("t3lib_matchCondition");
			$matchObj->altRootLine=$cc["rootLine"];
			while(list($key,$pre)=each($cc["all"]))	{
				if ($matchObj->match($pre))	{
					$sectionsMatch[$key]=$pre;
				}
			}
			$cc["match"]=$sectionsMatch;
		}
		return $cc;
	}
	function start($theRootLine)	{
			// This is all about fetching the right template. If it's not cached then it must be generated and cached!
		if (is_array($theRootLine))	{
			$setupData="";
			$cc=Array();
			$hash="";
			$this->runThroughTemplates($theRootLine);
			
				// Getting the currentPageData if not already found
			if (!$this->currentPageData)	{
				$this->getCurrentPageData();
			}
			

			// This is about getting the hash string which is used to fetch the cached TypoScript template.
			// If there was some cached currentPageData that's good (it gives us the hash), 
			// however if the actual rowSum and the rowSum of currentPageData is different from each other, thats a problem, and we should re-make the current page data.
			if (is_array($this->currentPageData) &&
					!strcmp(serialize($this->rowSum), serialize($this->currentPageData["rowSum"]))	// The two ROWsums must NOT be different from each other - which they will be if start/endtime or hidden has changed!
			)	{	
					// If currentPageData was actually there, we match the result...
				$cc["all"] = $this->currentPageData["all"];
				$cc["rowSum"] = $this->currentPageData["rowSum"];
				$cc = $this->matching($cc);
				$hash = md5(serialize($cc));
			} else {	
					// If currentPageData was not there, we first find $rowSum (freshly generated). After that we try to see, if rowSum is stored with a list of all matching-parameters. If so we match the result
				$rowSumHash = md5("ROWSUM:".serialize($this->rowSum));
				$result = t3lib_pageSelect::getHash($rowSumHash, 0);
				if ($result)	{
					$cc["all"] = unserialize($result);
					$cc["rowSum"] = $this->rowSum;
					$cc = $this->matching($cc);
					$hash = md5(serialize($cc));
				}
			}

//debug(md5(serialize($this->rowSum)),1);
//debug(md5(serialize($this->currentPageData["rowSum"])),1);
//debug($hash);

			if ($hash)	{
					// Get setup
				$setupData = t3lib_pageSelect::getHash($hash, 0);
			}

			if ($hash && $setupData && !$this->forceTemplateParsing)		{
					// If cached setup
				$this->setup = unserialize($setupData);
//debug("Fetch from cache...");
			} else {
					// Make configuration
				$this->generateConfig();

					// This stores the template hash thing
				$cc=Array();
				$cc["all"]=$this->sections;	// All sections in the template at this point is found
				$cc["rowSum"]=$this->rowSum;	// The line of templates is collected
				$cc = $this->matching($cc);

				$hash = md5(serialize($cc));

					// This stores the data.
				t3lib_pageSelect::storeHash($hash, serialize($this->setup), "TS TEMPLATE");	

				if ($this->tt_track)	$GLOBALS["TT"]->setTSlogMessage("TS template size, serialized: ".strlen(serialize($this->setup))." bytes");
				
				$rowSumHash = md5("ROWSUM:".serialize($this->rowSum));
				t3lib_pageSelect::storeHash($rowSumHash, serialize($cc["all"]), "TMPL CONDITIONS - ALL");			
			}
				// Add rootLine
			$cc["rootLine"] = $this->rootLine;
				// Make global and save.
			$GLOBALS["TSFE"]->all=$cc;

			if (!$this->simulationHiddenOrTime)	{	// Only save currentPageData, if we're not simulating by hidden/starttime/endtime
				$res = mysql (TYPO3_db, "DELETE FROM cache_pagesection WHERE page_id = '".$GLOBALS["TSFE"]->id."'");
				$res = mysql(TYPO3_db, "INSERT INTO	cache_pagesection (page_id, content, tstamp) VALUES ('".$GLOBALS["TSFE"]->id."', '".AddSlashes(serialize($cc))."', ".$GLOBALS["EXEC_TIME"].")");
			}
				// If everything OK.
			if ($this->rootId && $this->rootLine && $this->setup)	{
				$this->loaded = 1;
			}
		}
	}
	function runThroughTemplates($theRootLine,$start_template_uid=0)	{
			// This function traverses the rootLine from the root and out. For each page it checks if there is a template. If there is a template, $this->processTemplate() is called.
			// It returns nothing.
			// get database-content
		$this->constants = Array();
		$this->config = Array();
		$this->rowSum = Array();
		reset ($theRootLine);
		$c=count($theRootLine);
		for ($a=0;$a<$c;$a++)	{
			if ($this->nextLevel)	{	// If some template loaded before has set a template-id for the next level, then load this template first!
				$res = mysql(TYPO3_db, "select * from sys_template where uid = '".$this->nextLevel."' ".$this->whereClause);
				$this->nextLevel = 0;
				if ($row = mysql_fetch_assoc($res))	{
					$this->processTemplate($row,"sys_".$row["uid"],$theRootLine[$a][uid],"sys_".$row["uid"]);
				}
			}
			$addC="";
			if ($a==($c-1) && $start_template_uid)	{	// If first loop AND there is set an alternative template uid, use that
				$addC=" AND uid=".intval($start_template_uid);
			}
			$query = "select * from sys_template where pid = ".$theRootLine[$a][uid].$addC." ".$this->whereClause." ORDER BY sorting LIMIT 1";
//			debug($query,1);
			$res = mysql(TYPO3_db, $query);
			if ($row = mysql_fetch_assoc($res))	{
				$this->processTemplate($row,"sys_".$row["uid"],$theRootLine[$a][uid],"sys_".$row["uid"]);
			}
			$this->rootLine[] = $theRootLine[$a];
		}
	}
	function generateConfig()	{
			// Generates the configuration array by replacing constants and parsing the whole thing.
			// Depends on $this->config and $this->constants to be set prior to this! (done by processTemplate)

			// These vars are also set lateron...
		$this->setup["resources"]= $this->resources;
		$this->setup["sitetitle"]= $this->sitetitle;

			// parse constants
		$constants = t3lib_div::makeInstance("t3lib_TSparser");
		$constants->breakPointLN=intval($this->ext_constants_BRP);
		$constants->setup = $this->const;
		$matchObj = t3lib_div::makeInstance("t3lib_matchCondition");
		$matchObj->matchAlternative = $this->matchAlternative;
		$matchObj->matchAll = $this->matchAll;		// Matches ALL conditions in TypoScript
		
		array_unshift($this->constants,"".$GLOBALS["TYPO3_CONF_VARS"]["FE"]["defaultTypoScript_constants"]);	// Adding default TS/constants
		reset($this->constants);
		while (list(,$str)=each($this->constants))	{
			$constants->parse($str,$matchObj);
		}
		$this->parserErrors["constants"]=$constants->errors;
		
		$this->flatSetup = Array();
		$this->flattenSetup($constants->setup,"","");
		
			// piece config together to one var.
		$config = t3lib_div::makeInstance("t3lib_TSparser");
		$config->breakPointLN=intval($this->ext_config_BRP);
		$config->setup = $this->setup;
		
		$config->sections = $constants->sections;		
		$config->sectionsMatch = $constants->sectionsMatch;		

		array_unshift($this->config,"".$GLOBALS["TYPO3_CONF_VARS"]["FE"]["defaultTypoScript_setup"]);	// Adding default TS/constants
		reset($this->config);
		$all="";
		while (list(,$str)=each($this->config))	{
			$all.="\n[GLOBAL]\n".$str;
		}
		

		if ($this->tt_track)	$GLOBALS["TT"]->push("Substitute Constants (".count($this->flatSetup).")");
			// substitute constants in config
		$all = $this->substituteConstants($all);

		if ($this->tt_track)	$GLOBALS["TT"]->pull();
		if (strstr($all,'{$'))	{
			$findConst = explode('{$',$all);
			$theConstList=Array();
			next($findConst);
			while(list(,$constVal)=each($findConst))	{
				$constLen=t3lib_div::intInRange(strcspn($constVal,"}"),0,50);
				$theConstList[]='{$'.substr($constVal,0,$constLen+1);
			}
//			t3lib_div::print_array($theConstList);
			if ($this->tt_track)	$GLOBALS["TT"]->setTSlogMessage(implode($theConstList,",").": Constants may remain un-substituted!!",2);
		}
//	echo $all;

		if ($this->tt_track)	$GLOBALS["TT"]->setTSlogMessage("TypoScript template size as textfile: ".strlen($all)." bytes");
		
			// parse Config
		$config->parse($all,$matchObj);
		$this->parserErrors["config"]=$config->errors;
		$this->setup = $config->setup;
		if ($this->backend_info)	{
			$this->setup_constants = $constants->setup;		// Used for backend purposes only
		}
		
			// These vars are allready set after "processTemplate", but because $config->setup overrides them (in the line above!), we set them again. They are not changed compared to the value they had in the top of the page!
		unset($this->setup["resources"]);
		unset($this->setup["resources."]);
		$this->setup["resources"]= implode(",",t3lib_div::trimExplode(",",$this->resources,1));

		unset($this->setup["sitetitle"]);
		unset($this->setup["sitetitle."]);
		$this->setup["sitetitle"]= $this->sitetitle;
			
			// Unsetting some vars...
		unset($this->setup["types."]);
		unset($this->setup["types"]);
		if (is_array($this->setup)) {
			reset ($this->setup);
			while(list($theKey,)=each($this->setup))	{
				if ($this->setup[$theKey]=="PAGE")	{
					$tN = $this->setup[$theKey."."]["typeNum"];
					if (isset($tN))	{
						$this->setup["types."][$tN] = $theKey;
					}
				}
			}
		}
		unset($this->setup["styles."]);
		unset($this->setup["temp."]);
		unset($constants);
		
		$this->sections = $config->sections;
		$this->sectionsMatch = $config->sectionsMatch;
	}
	function substituteConstants($all)	{
		if ($this->tt_track)	$GLOBALS["TT"]->setTSlogMessage("Constants to substitute: ".count($this->flatSetup));
		reset($this->flatSetup);
		while (list($const,$val)=each($this->flatSetup))	{
			if (!is_array($val))	{
				$all = str_replace('{$'.$const.'}',$val,$all);
			}
		}
		return $all;	
	}
	function processTemplate($row, $idList,$pid,$templateID="",$templateParent="")	{
		// this function checks if the template ($row) has some included templates and after including them it fills the arrays with the setup
		$this->rowSum[]=Array($row["uid"],$row["title"],$row["tstamp"]);
		if ($row["clear"])	{
			$clConst = $row["clear"]&1;
			$clConf = $row["clear"]&2;
			if ($clConst)	{
				$this->constants = Array();
				$this->clearList_const=array();
			}
			if ($clConf)	{
				$this->config = Array();
				$this->clearList_setup=array();
			}
		}

		if (!$row["includeStaticAfterBasedOn"])		{		// NORMAL inclusion, The EXACT same code is found below the basedOn inclusion!!!
			if (trim($row["include_static"]))	{		// include_static is a list of static templates to include
				$include_staticArr = t3lib_div::intExplode(",",$row["include_static"]);
	//			t3lib_div::print_array($include_staticArr);
				reset($include_staticArr);
				while(list(,$id)=each($include_staticArr))	{	// traversing list
					if (!t3lib_div::inList($idList,"static_".$id))	{	// if $id is not allready included ...
						$res = mysql(TYPO3_db, "select * from static_template where uid = ".$id);
						echo mysql_error();
						if ($subrow = mysql_fetch_assoc($res))	{	// there was a template, then we fetch that
							$this->processTemplate($subrow,$idList.",static_".$id,$pid, "static_".$id,$templateID);
						}
					} else {
						//debug($id);debug($idList);
					}
				}
			}
		}
		if (trim($row["basedOn"]))	{		// "basedOn" is a list of templates to include
				// Manually you can put this value in the field and then the based_on ID will be taken from the HTTP_GET_VARS var defined by "=....".
				// Example: If $row["basedOn"] is "EXTERNAL_BASED_ON_TEMPLATE_ID=based_on_uid", then the global var, based_on_uid - given by the URL like "&based_on_uid=999" - is included instead!
				// This feature allows us a hack to test/demonstrate various included templates on the same set of content bearing pages.
			$basedOn_hackFeature = explode("=",$row["basedOn"]);
			if ($basedOn_hackFeature[0]=="EXTERNAL_BASED_ON_TEMPLATE_ID" && $basedOn_hackFeature[1])		{	
				$id=intval($GLOBALS["HTTP_GET_VARS"][$basedOn_hackFeature[1]]);
				if ($id && !t3lib_div::inList($idList,"sys_".$id))	{	// if $id is not allready included ...
					$res = mysql(TYPO3_db, "select * from sys_template where uid = ".$id." ".$this->whereClause);
					echo mysql_error();
					if ($subrow = mysql_fetch_assoc($res))	{	// there was a template, then we fetch that
						$this->processTemplate($subrow,$idList.",sys_".$id,$pid, "sys_".$id,$templateID);
					}
				}
			} else {	// NORMAL OPERATION:
				$basedOnArr = t3lib_div::intExplode(",",$row["basedOn"]);
				while(list(,$id)=each($basedOnArr))	{	// traversing list
					if (!t3lib_div::inList($idList,"sys_".$id))	{	// if $id is not allready included ...
						$res = mysql(TYPO3_db, "select * from sys_template where uid = ".$id." ".$this->whereClause);
						echo mysql_error();
						if ($subrow = mysql_fetch_assoc($res))	{	// there was a template, then we fetch that
							$this->processTemplate($subrow,$idList.",sys_".$id,$pid, "sys_".$id,$templateID);
						}
					}
				}
			}
		}
		if ($row["includeStaticAfterBasedOn"])		{
				// EXACT copy of the code from above!!!
			if (trim($row["include_static"]))	{		// include_static is a list of static templates to include
				$include_staticArr = t3lib_div::intExplode(",",$row["include_static"]);
	//			t3lib_div::print_array($include_staticArr);
				reset($include_staticArr);
				while(list(,$id)=each($include_staticArr))	{	// traversing list
					if (!t3lib_div::inList($idList,"static_".$id))	{	// if $id is not allready included ...
						$res = mysql(TYPO3_db, "select * from static_template where uid = ".$id);
						echo mysql_error();
						if ($subrow = mysql_fetch_assoc($res))	{	// there was a template, then we fetch that
							$this->processTemplate($subrow,$idList.",static_".$id,$pid, "static_".$id,$templateID);
						}
					} else {debug($id);debug($idList);}
				}
			}
		}

		$this->hierarchyInfo[] = array("root"=>trim($row["root"]), "next"=>$row["nextLevel"], "clConst"=>$clConst, "clConf"=>$clConf, "templateID"=>$templateID, "templateParent"=>$templateParent, "title"=>$row["title"], "uid"=>$row["uid"], "pid"=>$row["pid"]);
		
		$this->constants[] = $row["constants"];
		$this->config[] = $row["config"];
		$this->clearList_const[]=$templateID;
		$this->clearList_setup[]=$templateID;

		if (trim($row["resources"]))	{
			$this->resources = $row["resources"].",".$this->resources;
		}
		if (trim($row["sitetitle"]))	{
			$this->sitetitle = $row["sitetitle"];
		}
		if (trim($row["root"]))	{
			$this->rootId = $pid;
			$this->rootLine = Array();
		}
		if ($row["nextLevel"])	{
			$this->nextLevel = $row["nextLevel"];
		} else {
			$this->nextLevel = 0;
		}
	}
	function flattenSetup($setupArray, $prefix, $resourceFlag)	{
		// This flattens a hierarchical setuparray to $this->flatSetup
	
		if (is_array($setupArray))	{
			reset($setupArray);
			while(list($key,$val)=each($setupArray))	{
				if ($prefix || substr($key,0,16)!="TSConstantEditor")	{		// We don't want "TSConstantEditor" in the flattend setup on the first level (190201)
					if (is_array($val))	{
						$this->flattenSetup($val,$prefix.$key, ($key=="file."));
					} elseif ($resourceFlag) {
						$this->flatSetup[$prefix.$key] = $this->getFileName($val);
					} else {
						$this->flatSetup[$prefix.$key] = $val;
					}
				}
			}
		}
	}
	function splitConfArray($conf,$splitCount)	{
		$splitCount = intval($splitCount);
		$conf2 = Array();
		if ($splitCount && is_array($conf))	{
			while (list($cKey,$val)=each($conf))	{
				if (is_array($val))	{
					$tempConf = $this->splitConfArray($val,$splitCount);
					while (list($aKey,$val)=each($tempConf))	{
						$conf2[$aKey][$cKey] = $val;
					}
				}
			}			
			reset($conf);
			while (list($cKey,$val)=each($conf))	{
				if (!is_array($val))	{
					if (!strstr($val,"|*|") && !strstr($val,"||"))	{
						for ($aKey=0;$aKey<$splitCount;$aKey++)	{
							$conf2[$aKey][$cKey] = $val;
						}
					} else {
						$main = explode ("|*|",$val);
						$mainCount = count($main);
	
						$lastC = 0;
						$middleC = 0;
						$firstC = 0;
	
						if ($main[0])	{
							$first = explode("||",$main[0]);
							$firstC = count($first);
						}
						if ($main[1])	{
							$middle = explode("||",$main[1]);
							$middleC = count($middle);
						}
						if ($main[2])	{
							$last = explode("||",$main[2]);
							$lastC = count($last);
							$value = $last[0];
						}
	
						for ($aKey=0;$aKey<$splitCount;$aKey++)	{
							if ($firstC && isset($first[$aKey])) {
								$value = $first[$aKey];
							} elseif ($middleC) {
								$value = $middle[($aKey-$firstC)%$middleC];
							}
							if ($lastC && $lastC>=($splitCount-$aKey))	{
								$value = $last[$lastC-($splitCount-$aKey)];
							}
							$conf2[$aKey][$cKey] = trim($value);
						}	
					}
				}
			}
		}
		return $conf2;
	}
	function getFileName($fileFromSetup)	{
			// Returns the reference to a "resource" in TypoScript. 
			// This could be from the filesystem if "/" is found in the value $fileFromSetup, else from the resource-list
		$file = trim($fileFromSetup);
		if (!$file)	return;
			// cache
		$hash = md5($file);
		if (isset($this->fileCache[$hash]))	{
			return $this->fileCache[$hash];
		}
			// find
		if (strstr($file,"/")) {	// here it is manual media
			if (@is_file($this->getFileName_backPath.$file))	{
				$outFile = $file;
				$fileInfo = t3lib_div::split_fileref($outFile);
				reset($this->allowedPaths);
				$OK=0;
				while(list(,$val)=each($this->allowedPaths))	{
					if (substr($fileInfo["path"],0,strlen($val))==$val){$OK=1; break;}
				}
				if ($OK)	{
					$this->fileCache[$hash]=$outFile;
					return $outFile;
				} elseif ($this->tt_track) $GLOBALS["TT"]->setTSlogMessage("'".$file."' was not located in the allowed paths: (".implode($this->allowedPaths,",").")",3);
			} elseif ($this->tt_track) $GLOBALS["TT"]->setTSlogMessage("'".$this->getFileName_backPath.$file."' is not a file (non-uploads/.. resource, did not exist).",3);
		} else {		// Here it is uploaded media:
			$outFile = $this->extractFromResources($this->setup["resources"],$file);
			if ($outFile)	{
			 	if (@is_file($this->uplPath.$outFile))	{
					$this->fileCache[$hash] = $this->uplPath.$outFile;
					return $this->uplPath.$outFile;
				} elseif ($this->tt_track) $GLOBALS["TT"]->setTSlogMessage("'".$this->uplPath.$outFile."' is not a file (did not exist).",3);
			} elseif ($this->tt_track) $GLOBALS["TT"]->setTSlogMessage("'".$file."' is not a file (uploads/.. resource).",3); 
		}
	}
	function extractFromResources($res,$file)	{
		if (t3lib_div::inList($res,$file))	{
			$outFile = $file;
		} elseif (strstr($file,"*")) {
			$fileparts=explode("*",$file);
			$c=count($fileparts);
			$files = explode(",",$res);
			while(list(,$val)=each($files))	{
				$test = trim($val);
				if (ereg("^".quotemeta($fileparts[0]).".*".quotemeta($fileparts[$c-1])."$", $test))	{
					$outFile = $test;
					break;
				}
			}
		}
		return $outFile;
	}
	function checkFile($name,$menuArr)	{
		// CheckFile runs through the $menuArr and checks every file-reference in $name
		reset ($menuArr);
		while (list($aKey,)=each($menuArr))	{
			$menuArr[$aKey][$name] = $this->getFileName($menuArr[$aKey][$name]);
		}
		return $menuArr;
	}
	function printTitle($title,$no_title=0)	{
		$st = trim($this->setup["sitetitle"]) ? $this->setup["sitetitle"]:"";
		$title = $no_title ? "" : $title;
		if ($title && $st)	{
			return $st.": ".$title;
		} else {
			return $st.$title;
		}
	}
	function fileContent($fName)	{
		// reads the fileContent of $fName and returns it
		$incFile = $this->getFileName($fName);
		if ($incFile && $fd=fopen($incFile,"r"))	{
			$content = "";
			while (!feof($fd))	{
				$content.=fread( $fd, 5000 );
			}
			fclose( $fd );
			return $content;
		}
	}
	function wrap($content,$wrap)	{
		if ($wrap)	{
			$wrapArr = explode("|", $wrap);
			return trim($wrapArr[0]).$content.trim($wrapArr[1]);
		} else return $content;
	}
	function linkData($page,$oTarget,$no_cache,$script,$overrideArray="",$addParams="",$typeOverride="")	{
		$LD = Array();
//		$addParams="";
		if (is_array($overrideArray))	{
			reset($overrideArray);
			while(list($theKey,$theNewVal)=each($overrideArray))	{
				$addParams.="&real_".$theKey."=".rawurlencode($page[$theKey]);
				$page[$theKey] = $theNewVal;
			}
		}
		
			// id
		if (!$script)	{$script = $GLOBALS["TSFE"]->config["mainScript"];}
		if ($page["alias"])	{
			$LD["url"]=$script.'?'.$page["alias"];
		} else {
			$LD["url"]=$script.'?id='.$page["uid"];
		}
			// target
		$target= trim($page["target"]);
		$LD["target"]= $target ? trim($page["target"]) : $oTarget;
			// typeNum
		$typeNum = $this->setup[$LD["target"]."."][typeNum];
		if (!$typeOverride && intval($GLOBALS["TSFE"]->config["config"]["forceTypeValue"]))	{
			$typeOverride=intval($GLOBALS["TSFE"]->config["config"]["forceTypeValue"]);
		}
		if (strcmp($typeOverride,""))	{$typeNum=$typeOverride;}	// Override...
		if ($typeNum)	{
			$LD["type"]='&type='.intval($typeNum);
		} else {
			$LD["type"]="";
		}
		$LD["orig_type"] = $LD["type"];		// Will not be cleared if simulateStaticDocuments.
			// noCache
		$LD["no_cache"] = (trim($page["no_cache"]) || $no_cache) ? "&no_cache=1" : "";
			//linkVars
		$LD["linkVars"]= $GLOBALS["TSFE"]->linkVars;
			// If simulateStaticDocuments is enabled:
		if ($GLOBALS["TSFE"]->config["config"]["simulateStaticDocuments"])	{
			$LD["type"]="";
			$LD["url"]="";
			$LD["url"].=$GLOBALS["TSFE"]->makeSimulFileName($page["title"],
							$page["alias"] ? $page["alias"] : $page["uid"],
							intval($typeNum));
			if ($GLOBALS["TSFE"]->config["config"]["simulateStaticDocuments"]=="PATH_INFO")	{
				$LD["url"] = str_replace(".","/",$LD["url"]);
				$LD["url"] = "index.php/".$LD["url"]."/?";
			} else {
				$LD["url"].= ".html?";
			}
		}
		$LD["url"] = $GLOBALS["TSFE"]->absRefPrefix.$LD["url"];		// Add absRefPrefix if exists.
		$LD["sectionIndex"] = $page["sectionIndex_uid"] ? "#".$page["sectionIndex_uid"] : "";		// If the special key "sectionIndex_uid" (added "manually" in tslib/menu.php to the page-record) is set, then the link jumps directly to a section on the page.
			// Compile the normal total url
		$LD["totalURL"]= $this->removeQueryString($LD["url"].$LD["type"].$LD["no_cache"].$LD["linkVars"].$addParams.$GLOBALS["TSFE"]->getMethodUrlIdToken).$LD["sectionIndex"];
			// Return the LD-array	
		return $LD;
	}
	function removeQueryString($url)	{
		if (substr($url,-1)=="?")	{
			return substr($url,0,-1);
		} else {
			return $url;
		}
	}
	function sortedKeyList($setupArr)	{
		reset($setupArr);
		$keyArr=Array();
		while(list($key,)=each($setupArr))	{
			$ikey=intval($key);
			if (!strcmp($ikey,$key))	{
				$keyArr[]=$ikey;
			}
		}
		sort($keyArr);
		return $keyArr;
	}
}




if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tstemplate.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tstemplate.php"]);
}

?>