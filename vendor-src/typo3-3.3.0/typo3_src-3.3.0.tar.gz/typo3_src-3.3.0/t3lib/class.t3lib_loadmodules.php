<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Load backend Interface modules
 *
 * This document provides a class that loads the interface modules for the Typo3 interface.
 * It's used in documents like  ti_inc.php, palettes.php and propframe.php under Typo3-interface
 * 
 * REMEMBER when making modules: All foldernames must consist only of A-Za-z0-9 (these are used in JavaScript later on)
 * 
 * Modifications by Rene Fritz, 2001
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_loadModules {

	var $modules = Array();
	var $errormsg = Array();
	
	var $modListGroup= Array();		// this array will hold the elements that should go into the select-list of modules for groups...
	var $modListUser= Array();		// this array will hold the elements that should go into the select-list of modules for users...

	var $BE_USER="";
	
	function load($modulesArray,$BE_USER="")	{
		if (is_object($BE_USER))	{
			$this->BE_USER=$BE_USER;
		} else {
			$this->BE_USER = $GLOBALS["BE_USER"];
		}
		$theMods = $this->parseModulesArray($modulesArray);

		$paths["defMods"] = PATH_typo3."mod/";	// Path of static modules
		$paths["userMods"] = PATH_typo3."../typo3conf/";  // local modules (maybe frontend specific)

		while(list($mods,$subMod)=each($theMods))	{
			unset ($path);
			$theMainMod = $this->checkMod($mods,$paths["defMods"].$mods);	
			if (is_array($theMainMod) || $theMainMod!="notFound")	{		// default module
				$path = $paths["defMods"];
			} else {
					// user defined module in typo3conf/ 
				$theMainMod = $this->checkMod($mods,$paths["userMods"].$mods);
				if (is_array($theMainMod) || $theMainMod!="notFound")	{
					$path = $paths["userMods"];
				}
			}
				// if $theMainMod is not set (false) there is no access to the module !(?)
			if ($theMainMod && isset($path))	{
				$this->modules[$mods]=$theMainMod;
					// submodules - if any - are loaded
				if ($mods!="doc" && is_array($subMod))	{
					while(list(,$valsub)=each($subMod))	{
						$theTempSubMod=$this->checkMod($mods."_".$valsub,$path.$mods."/".$valsub);
						if (is_array($theTempSubMod))	{	// default sub-module in either main-module-path, be it the default or the userdefined.
							$this->modules[$mods]["sub"][$valsub]=$theTempSubMod;
						} elseif ($path == $paths["defMods"])	{		// If the submodule did not exist in the default module path, then check if there is a submodule in the submodule path!
							$theTempSubMod=$this->checkMod($mods."_".$valsub,$paths["userMods"].$mods."/".$valsub);
							if (is_array($theTempSubMod))	{	
								$this->modules[$mods]["sub"][$valsub]=$theTempSubMod;
							}
						}
					}
				}
			} else {	// This must be done in order to fill out the select-lists for modules correctly!!
				if ($theMainMod=="spacer")	{
					$this->modules[$mods]="spacer";
				}
				if ($mods!="doc" && is_array($subMod))	{
					while(list(,$valsub)=each($subMod))	{
						$this->checkMod($mods."_".$valsub,$path.$mods."/".$valsub);
					}
				}
			}
		}
	}
	function checkMod($name, $fullpath)	{
		/* Here we check for the module. If not a conf-file is set then it's regarded to be a spacer
			 Return values:
			 	"notFound":	If the module was not found in the path
				"spacer":	If the 'module' was a spacer in the tab-pane OR if the module had no conf.php file
			 	false:		If no access to the module
				array():	Configuration array, in case a valid module where access IS granted exists.
		*/
		$modconf=Array();
		$path = ereg_replace ("/[^/.]+/\.\./", "/", $fullpath); // because 'path/../path' does not work
		if (!@is_dir($path)) 	{
			if (substr($name,0,6)=="spacer"){
				$modconf="spacer";
			} else {
				$modconf="notFound";
			}
		} else {
			if (@file_exists($path."/conf.php"))	{
				include($path."/conf.php");	// The conf-file is included. This must be valid PHP.
				if ($this->checkModAccess($name,$MCONF))	{
					$modconf[name]=$name;
						// language processing
					if (is_object($GLOBALS["LANG"]))	{
						if ($MLANG["default"][tabs_images][tab])	{
							$MLANG["default"][tabs_images][tab]=$this->getRelativePath(PATH_typo3,$fullpath."/".$MLANG["default"][tabs_images][tab]);
							if (substr($MLANG["default"][tabs_images][tab],0,3)=="../")	{
								$MLANG["default"][tabs_images][tab] = PATH_site.substr($MLANG["default"][tabs_images][tab],3);
							}
						}
						$GLOBALS["LANG"]->addLanguage($MLANG["default"],$name."_");
						$GLOBALS["LANG"]->addLanguage($MLANG[$GLOBALS["LANG"]->lang],$name."_");
					}
				
						// Default script setup
					if ($MCONF["script"] && @file_exists($path."/".$MCONF["script"]))	{
						$modconf[script]= $this->getRelativePath(PATH_typo3,$fullpath."/".$MCONF["script"]);
					} else {
						$modconf[script]="dummy.html";
					}
						// Default script setup
					if ($MCONF["cpalScript"] && @file_exists($path."/".$MCONF["cpalScript"]))	{
						$modconf[cpalScript]= $this->getRelativePath(PATH_typo3,$fullpath."/".$MCONF["cpalScript"]);
					}
						// Default tab setting
					if ($MCONF["defaultMod"])	{
						$modconf[defaultMod]=$MCONF["defaultMod"];
					}
				} else return false;
			} else {
				$modconf="spacer";
			}
		}
		return $modconf;
	}
	function checkModAccess($name,$MCONF)	{
		if ($MCONF["access"])	{
			$access=strtolower($MCONF["access"]);
				// Checking if admin-access is required
			if (strstr($access,"admin"))	{	// If admin-permissions is required then return true if user is admin
				if ($this->BE_USER->isAdmin())	{return true;}
			}
				// This will add modules to the select-lists of user and groups
			if (strstr($access,"user"))	{	$this->modListUser[]=$name;		}
			if (strstr($access,"group"))	{	$this->modListGroup[]=$name;	}
				// This checks if a user is permitted to access the module
			if ($this->BE_USER->isAdmin() || $this->BE_USER->check("modules",$name))	{return true;}	// If admin you can always access a module

		} else return true;	// If conf[access] is not set, then permission IS granted!
	}
	function moduleAccess ($mod,$submod)	{
		if (isset($this->modules[$mod]))	{
			if ($submod)	{
				if (isset($this->modules[$mod][sub][$submod]))	{
					return 1;
				}
			} else { return 1; }
		}
	}
	function parseModulesArray ($arr)	{
		// Returns an array where the keys are names of the module and the values may be true (only module) or an array (of submodules)
		$theMods = Array();
		if (is_array($arr))	{
			reset($arr);
			while(list($mod,$subs)=each($arr))	{
				$mod=$this->cleanName($mod);		// clean module name to alphanum
				if ($mod)	{
					if ($subs)	{
						$temp=explode(",",$subs);
						while(list(,$subMod)=each($temp))	{
							$subMod=$this->cleanName($subMod);
							if ($subMod)	{
								$theMods[$mod][]=$subMod;
							}
						}
					} else {
						$theMods[$mod]=1;
					}
				}
			}
		}
		return $theMods;
	}
	function cleanName ($str)	{
		// The $str is cleaned so that it contains alphanumerical characters only. Modules must only consist of these characters
		return ereg_replace("[^A-Za-z0-9]*","",$str);
	}
	function readDir($path)	{
		$newdirs=Array();
		if ($path)	{
			$dirs=t3lib_div::get_dirs($path);
			if (is_array($dirs))	{
				sort($dirs);
				while(list(,$val)=each($dirs))	{
					$modName = ereg_replace("^[0-9]*","",$val);	// This removes any number and spacer + lines that is used to sort the listing
					$modName = strtolower(ereg_replace(" ","_",$modName));	// This turns spaces into _ and lowercases
					$newdirs[]=Array($val,$modName);
				}
			}
		}
		return $newdirs;
	}
	function error($msg)	{
		$this->errormsg[]=$msg;
	}
	function getRelativePath($baseDir,$destDir){
		// By Rene Fritz
		// a special case , the dirs are equals
		if ($baseDir == $destDir){
			return "./";
		}
		
		$baseDir = ereg_replace ("^/", "", $baseDir); 	// remove beginning
		$destDir = ereg_replace ("^/", "", $destDir);
		
		$found = true;
		$slash_pos=0;
		
		do {
			$slash_pos = strpos ($destDir, '/');
			if (substr($destDir, 0, $slash_pos) == substr($baseDir, 0, $slash_pos)){ 
				$baseDir = substr($baseDir, $slash_pos+1);
				$destDir = substr($destDir, $slash_pos+1); 
			} else {
				$found = false;
			}
		} while($found == true);
		
		$slashes = strlen ($baseDir) - strlen (str_replace("/", "", $baseDir));
		for($i=0;$i < $slashes;$i++)	{
			$destDir = "../".$destDir;
		}
		return $destDir;
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_loadmodules.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_loadmodules.php"]);
}

?>