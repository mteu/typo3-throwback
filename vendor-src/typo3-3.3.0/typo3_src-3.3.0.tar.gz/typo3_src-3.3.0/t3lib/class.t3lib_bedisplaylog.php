<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This class holds some functions used to display the sys_log table-content.
 *
 * Used in the status-scripts and the log-module.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_BEDisplayLog {
	var $lastTimeLabel="";
	var $lastUserLabel="";
	var $lastTypeLabel="";
	var $lastActionLabel="";
	
	var $detailsOn = 1;	// If detailsOn, %s is substituted with values from the data-array (see getDetails())
	var $stripPath = 1;	// This strips the path from any value in the data-array when the data-array is parsed through stripPath()
	var $errorSign = Array(
		1 => "!",
		2 => "Sys!",
		3 => "Secur!"
	);

	function getTimeLabel($code)	{
		$t=$GLOBALS["SOBE"]->doc->formatTime($code,1);
		if ($this->lastTimeLabel!=$t)	{
			$this->lastTimeLabel=$t;
			return $t;
		} else return ".";
		
	}
	function getUserLabel($code)	{
		if ($this->lastUserLabel!=$code)	{
			$this->lastUserLabel=$code;
			$label=$GLOBALS["be_user_Array"][$code]["username"];
			return $label ? $label : "[".$code."]";
		} else return ".";
	}
	function getTypeLabel($code)	{
		if ($this->lastTypeLabel!=$code)	{
			$this->lastTypeLabel=$code;
			$label=$GLOBALS["LANG"]->getLL("type_".$code);
			return $label ? $label : "[".$code."]";
		} else return ".";
	}
	function getActionLabel($code)	{
		if ($this->lastActionLabel!=$code)	{
			$this->lastActionLabel=$code;
			$label=$GLOBALS["LANG"]->getLL("action_".$code);
			return $label ? $label : "[".$code."]";
		} else return ".";
	}
	function getDetails($code,$text,$data,$sys_log_uid=0)	{
			// $code is used later on to substitute errormessages with language-corrected values...
		if (is_array($data))	{
			if ($this->detailsOn)	{
				if (is_object($GLOBALS["LANG"]))	{
					$label=$GLOBALS["LANG"]->getLL("msg_".$code);
				} else {
					list($label)=explode(",",$text);
				}
				if ($label)	{$text=$label;}
				$text = sprintf($text, $data[0],$data[1],$data[2],$data[3],$data[4]);
			} else {
				$text = str_replace("%s","",$text);
			}
		}
		
			// Finding the history for the record
		$query="SELECT uid,fieldlist FROM sys_history WHERE sys_log_uid=".intval($sys_log_uid);
		$res = mysql(TYPO3_db,$query);
		$newRow = mysql_fetch_assoc($res);
		if (is_array($newRow))	{
			$text.=' Changes in fields: <em>'.$newRow["fieldlist"]."</em>.";
			$text.=' <a href="'.$GLOBALS["BACK_PATH"].'show_rechis.php?sh_uid='.$newRow["uid"].'&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><B>->His</B></a>';
//			debug($newRow);
		}

		return $text;
	}
	function stripPath($inArr)	{
		if ($this->stripPath && is_array($inArr))	{
			while(list($key,$val)=each($inArr))	{
				$inArr[$key]=basename($val);
			}
		}	
		return $inArr;
	}
	function reset()	{
		$this->lastTimeLabel="";
		$this->lastUserLabel="";
		$this->lastTypeLabel="";
		$this->lastActionLabel="";
	}
	function initArray()	{
		$codeArr=Array();
		$codeArr[$i][]="Time";	// Time
		$codeArr[$i][]="User";
		$codeArr[$i][]="Type";
		$codeArr[$i][]="E";
		$codeArr[$i][]="Action";
		$codeArr[$i][]="Details";
		return $codeArr;
	}
	function getErrorFormatting($sign)	{
		return '<font color="red"><b>'.$sign.'</b></font>';
	}
	function formatDetailsForList($row)	{
		$data = unserialize($row["log_data"]);
		if ($row["type"]==2)	{
			$data=$this->stripPath($data);
		}

		return $this->getDetails($row["type"]."_".$row["action"]."_".$row["details_nr"],$row["details"],$data,$row["uid"])." (".$row["details_nr"].")";
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_bedisplaylog.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_bedisplaylog.php"]);
}


?>