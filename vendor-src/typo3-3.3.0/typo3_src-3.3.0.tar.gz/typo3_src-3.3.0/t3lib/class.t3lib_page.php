<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Page functions 
 *
 * t3lib_pageSelect class that has a lot of sql/pages-related functions
 * 
 * It's important to set the right $where_hid_del in the object so that the functions 
 * operate properly
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_pageSelect {
	var $urltypes = Array("","http://","ftp://","mailto:");
	var $where_hid_del = " AND NOT pages.deleted";	// This is not the final clauses. You MUST initialize the object by the init() function
	var $sys_language_uid=0;

	function init($show_hidden)	{
		// init() MUST be run directly after creating a new template-object	
		// if $show_hidden is true, the hidden-field is ignored!! Normally this should be false
		$this->where_hid_del = " AND NOT pages.deleted ";
		if (!$show_hidden)	{
			$this->where_hid_del.= "AND NOT pages.hidden ";
		}
		$this->where_hid_del.= "AND (pages.starttime<=".$GLOBALS["SIM_EXEC_TIME"].") AND (pages.endtime=0 OR pages.endtime>".$GLOBALS["SIM_EXEC_TIME"].") ";
	}
	function getPage ($uid)	{
			// Return the $row for the page with uid = $uid 
		$query="select * from pages where uid=".intval($uid).$this->where_hid_del;
		$res = mysql(TYPO3_db, $query);
		if ($row = mysql_fetch_assoc($res))	{
			return $this->getPageOverlay($row);
		}
		return Array();
	}
	function getPage_noCheck ($uid)	{
			// Return the $row for the page with uid = $uid WITHOUT checking for anything like start- and endtime or hidden. Only deleted is checked!
		$query="select * from pages where uid=".intval($uid)." AND NOT pages.deleted";
		$res = mysql(TYPO3_db, $query);
		if ($row = mysql_fetch_assoc($res))	{
			return $this->getPageOverlay($row);
		}
		return Array();
	}
	function getMenu ($uid,$fields="*",$sortField="sorting")	{
			// Returns an array with pagerows for subpages with pid=$uid (which is pid here!). This is used for menus
		$output = Array();
		$res = mysql(TYPO3_db, "select ".$fields." from pages where pid=".intval($uid).$this->where_hid_del." ORDER BY ".$sortField);
		while ($row = mysql_fetch_assoc($res))	{
			$output[$row[uid]]=$this->getPageOverlay($row);
		}
		return $output;
	}
	function getFirstWebPage ($uid)	{
			// Returns the $row of the first web-page in the tree (for the default menu...)
		$output;
		$res = mysql(TYPO3_db, "select * from pages where pid=".intval($uid).$this->where_hid_del." ORDER BY sorting LIMIT 1");
		if ($row = mysql_fetch_assoc($res))	{
			$output=$this->getPageOverlay($row);
		}
		return $output;
	}
	function getDomainStartPage($domain, $path="")	{
			// Returns the $row of the first webpage under the domain
		$domain = explode(":",$domain);
		$domain = strtolower(ereg_replace("\.$","",$domain[0]));
			// path is calculated.
		$path = trim(ereg_replace("\/[^\/]*$","",$path));
			// stuff:
		$domain.=$path;
		
		$res = mysql(TYPO3_db, "select pages.uid, sys_domain.redirectTo from pages,sys_domain where pages.uid=sys_domain.pid AND NOT sys_domain.hidden AND (sys_domain.domainName='".addSlashes($domain)."' or sys_domain.domainName='".addSlashes($domain."/")."') ".$this->where_hid_del." LIMIT 1");
		echo mysql_error();
		if ($row = mysql_fetch_assoc($res))	{
			if ($row["redirectTo"])	{
				Header("Location: ".$row["redirectTo"]);
				exit;
			} else {
				return $row[uid];
			}
		}
	}
	function getRootLine ($uid)	{		
			// Returns array with uid/title of the pages from here and back to the root
			// Be aware that this function does only take deleted pages into account! 
			// CORRECTION 20-9-2000: Now pages of the type Recycler (doktype=255) is also blocked
		$selFields = t3lib_div::uniqueList("pid,uid,title,nav_title,media,layout,hidden,starttime,endtime,fe_group,extendToSubpages,doktype,TSconfig,".$GLOBALS["TYPO3_CONF_VARS"]["FE"]["addRootLineFields"]);
		
		$loopCheck = 20;
		$theRowArray = Array();
		$output=Array();
		$uid = intval($uid);		// added 010800
		while ($uid!=0 && $loopCheck>0)	{
			$loopCheck--;
			$res = mysql(TYPO3_db, "select ".$selFields." from pages where uid=".intval($uid)." AND NOT pages.deleted AND pages.doktype!=255");   // $this->where_hid_del was formerly appended, but I think we should not...  Version 2  20-02-00: pages.deleted added - this MUSt be a requirement
			if ($row = mysql_fetch_assoc($res))	{
				$uid = $row["pid"];
				$theRowArray[]=$this->getPageOverlay($row);
			} else {
				$theRowArray="";
				break;
			}
		}
		if (is_array($theRowArray))	{
			reset($theRowArray);
			$c=count($theRowArray);
			while(list($key,$val)=each($theRowArray))	{
				$c--;
				$output[$c]=$val;
			}
		}
		return $output;
	}
	function getPageIdFromAlias($alias)	{
			// Returns a pagerow for the page with alias $alias
		$alias=strtolower($alias);
		$res = mysql(TYPO3_db, "select uid from pages where alias='".addslashes($alias)."'".$this->where_hid_del);
		if ($row = mysql_fetch_assoc($res))	{
			return $row[uid];
		}
		return "";
	}
	function getExtURL($pagerow,$disable=0)	{
		if ($pagerow[doktype]==3 && !$disable)	{
			return $this->urltypes[$pagerow[urltype]].$pagerow[url];
		}
	}
	function getPathFromRootline($rl)	{
			// Calculates the page based on the rootLine (as input)
		if (is_array($rl))	{
			$c=count($rl);
			$path = "";
			for ($a=0;$a<$c;$a++)	{
				if ($rl[$a][uid])	{
					$path.="/".t3lib_div::fixed_lgd(strip_tags($rl[$a][title]),20);
				}
			}
			return $path;
		}
	}
	function checkRecord($table,$uid,$checkPage=0)	{
			// Checks if a record exists and is accessible. 
			// If checkPage is set, it's also required that the page on which the record resides is accesible
			// The row is returned if everything's OK.
		global $TCA;
		$uid=intval($uid);
		if (is_array($TCA[$table])) {
			$query = "SELECT * FROM ".$table." WHERE uid=".intval($uid).$this->enableFields($table);
			$res = mysql(TYPO3_db, $query);
			if ($row = mysql_fetch_assoc($res))	{
				if ($checkPage)	{
					$pid=$row["pid"];
					$query="select uid from pages where uid=".intval($pid).$this->enableFields("pages");
					$res = mysql(TYPO3_db, $query);
					if (mysql_num_rows($res))	{
						return $row;
					} else {
						return 0;
					}
				} else {
					return $row;
				} 
			}
		}
	}
	function getRawRecord($table,$uid)	{
			// Returns record no matter what - except if record is deleted
		global $TCA;
		$uid=intval($uid);
		if (is_array($TCA[$table])) {
			$query = "SELECT * FROM ".$table." WHERE uid=".intval($uid).$this->deleteClause($table);
			$res = mysql(TYPO3_db, $query);
			if ($row = mysql_fetch_assoc($res))	{
				return $row;
			}
		}
	}
	function getRecordsByField($theTable,$theField,$theValue,$endClause="")	{
		global $TCA;
		if (is_array($TCA[$theTable])) {
			$query = "SELECT * FROM ".$theTable." WHERE ".$theField."='".addslashes($theValue)."'".$this->deleteClause($theTable)." ".$endClause;
			$res = mysql(TYPO3_db, $query);
			$rows=array();
			while($row = mysql_fetch_assoc($res))	{
				$rows[] = $row;
			}
			if (count($rows))	return $rows;
		}
	}
	function deleteClause($table)	{
		global $TCA;
		return $TCA[$table]["ctrl"]["delete"] ? " AND NOT ".$TCA[$table]["ctrl"]["delete"] : "";
	}
	/** 
	 * Returns the relevant page overlay record fields
	 * If $pageInput is an integer, it's the pid of the pageOverlay record and thus the page overlay record is returned.
	 * If $pageInput is an array, it's a page-record and based on this page record the language record is found and OVERLAYED before the page record is returned.
	 */
	function getPageOverlay($pageInput,$lUid=-1)	{
		if ($lUid<0)	$lUid=$this->sys_language_uid;
		if ($lUid)	{
			$fieldArr=explode(",","title,subtitle,media,keywords,description,abstract,author,author_email");
			if (is_array($pageInput))	{
				$page_id=$pageInput["uid"];	// Was the whole record
				$fieldArr=array_intersect($fieldArr,array_keys($pageInput));		// Make sure that only fields which exist in the incoming record are overlaid!
//				debug($fieldArr);
			} else {
				$page_id=$pageInput;	// Was the id
			}
			$query = "SELECT ".implode(",",$fieldArr)." 
			FROM pages_language_overlay 
			WHERE pid=".intval($page_id)." 
				AND sys_language_uid=".intval($lUid).
				$this->enableFields("pages_language_overlay")." LIMIT 1";
			/*
				NOTE to enabledFields("pages_language_overlay"):
				Currently the showHiddenRecords of TSFE set will allow pages_language_overlay records to be selected as they are child-records of a page.
				However you may argue that the showHiddenField flag should determine this. But that's not how it's done right now.
			*/
				
//				debug($query);
			$res = mysql(TYPO3_db,$query);
			$row = mysql_fetch_assoc($res);
		}
		
		if (is_array($pageInput))	{
			return is_array($row) ? array_merge($pageInput,$row) : $pageInput;	// If the input was an array, simply overlay the newfound array and return...
		} else {
			return is_array($row) ? $row : array();	// always an array in return
		}
	}


	
	
	
		// General

	function getHash($hash,$expTime)	{
			// if expTime is not set, the hash will never expire
		$expTime = intval($expTime);
		if ($expTime)	{
			$whereAdd = " AND tstamp > ".(time()-$expTime);
		}
		$res = mysql (TYPO3_db, "SELECT content FROM cache_hash WHERE hash='".$hash."'".$whereAdd);
		if ($row=mysql_fetch_assoc($res))	{
			return $row[content];
		}
	}
	function storeHash($hash,$data,$ident)	{
			// $ident is just a textual identification in order to inform about the content! May be 20 characters long.
		$res = mysql (TYPO3_db, "DELETE FROM cache_hash WHERE hash='".$hash."'");
		$res = mysql (TYPO3_db, "INSERT INTO cache_hash (hash, content, ident, tstamp) VALUES ('".$hash."','".addSlashes($data)."','".addSlashes($ident)."','".time()."')");
	}
	function enableFields($table,$show_hidden=-1,$ignore_array=array())	{
			// if $show_hidden is set (0/1), any hidden-fields in records are ignored
			// NOTICE: If you call this function, consider what to do with the show_hidden parameter. Maybe it should be set?
			// See tslib_cObj->enableFields where it's implemented correctly.
		if ($show_hidden==-1 && is_object($GLOBALS["TSFE"]))	{	// If show_hidden was not set from outside and if TSFE is an object, set it based on showHiddenPage and showHiddenRecords from TSFE
			$show_hidden = $table=="pages" ? $GLOBALS["TSFE"]->showHiddenPage : $GLOBALS["TSFE"]->showHiddenRecords;
//			debug($table." - ".$show_hidden);
		} 
		if ($show_hidden==-1)	$show_hidden=0;	// If show_hidden was not changed during the previous evaluation, do it here.
			
		$ctrl = $GLOBALS["TCA"][$table]["ctrl"];
		$query="";
		if (is_array($ctrl))	{
			if ($ctrl["delete"])	{
				$query.=" AND NOT ".$table.".".$ctrl["delete"];
			}
			if (is_array($ctrl["enablecolumns"]))	{
				if ($ctrl["enablecolumns"]["disabled"] && !$show_hidden && !$ignore_array["disabled"])	{
					$field = $table.".".$ctrl["enablecolumns"]["disabled"];
					$query.=" AND NOT ".$field;
				}
				if ($ctrl["enablecolumns"]["starttime"] && !$ignore_array["starttime"])	{
					$field = $table.".".$ctrl["enablecolumns"]["starttime"];
					$query.=" AND (".$field."<=".$GLOBALS["SIM_EXEC_TIME"].")";
				}
				if ($ctrl["enablecolumns"]["endtime"] && !$ignore_array["endtime"])	{
					$field = $table.".".$ctrl["enablecolumns"]["endtime"];
					$query.=" AND (".$field."=0 OR ".$field.">".$GLOBALS["SIM_EXEC_TIME"].")";
				}
				if ($ctrl["enablecolumns"]["fe_group"] && !$ignore_array["fe_group"])	{
					$field = $table.".".$ctrl["enablecolumns"]["fe_group"];
					$gr_list = $GLOBALS["TSFE"]->gr_list;
					if (!strcmp($gr_list,""))	$gr_list=0;
					$query.=" AND ".$field." IN (".$gr_list.")";
				}
			}
		} else {die ("NO entry in the \$TCA-array for '".$table."'");}
//		debug($query,1);
		return $query;
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_page.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_page.php"]);
}

?>