<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * Generates a thumbnail and returns mimetype, GIF
 *
 * $this->file :		relative or absolute reference to an imagefile...
 * $this->size:		integer-values defining size of thumbnail, format "[int]" or "[int]x[int]"
 *
 * relative paths MUST BE the first two characters ONLY: eg: "../dir/file.gif"			
 *
 * @author		Kasper Sk�rh�j	<kasper@typo3.com>
 */


// *******************************
// Set error reporting 
// *******************************
error_reporting (E_ALL ^ E_NOTICE); 


 
// ******************
// Constants defined
// ******************
define("TYPO3_OS", stristr(PHP_OS,"win")&&!stristr(PHP_OS,"darwin")?"WIN":"");
define("TYPO3_MODE","BE");
define("PATH_thisScript",
	TYPO3_OS=="WIN" ?
	str_replace('//','/',str_replace('\\','/', $HTTP_SERVER_VARS["PATH_TRANSLATED"]?$HTTP_SERVER_VARS["PATH_TRANSLATED"]:getenv("PATH_TRANSLATED"))) :
	(php_sapi_name()=="cgi"?(getenv("PATH_TRANSLATED")?getenv("PATH_TRANSLATED"):getenv("SCRIPT_FILENAME")):$HTTP_SERVER_VARS["PATH_TRANSLATED"])
);
define("PATH_site", ereg_replace("[^/]*.[^/]*$","",PATH_thisScript));		// the path to the website folder (see init.php)
define("PATH_typo3conf", PATH_site."typo3conf/");
define("PATH_t3lib", PATH_site."t3lib/");

// ******************
// Including config
// ******************
include(PATH_t3lib."config_default.php");		
if (!defined ("TYPO3_db")) 	die ("The configuration file was not included.");
if (!$TYPO3_CONF_VARS["GFX"]["image_processing"])	die ("ImageProcessing was disabled!");


// ***************************
// Script Classes
// ***************************
class SC_t3lib_thumbs {
	var $include_once=array();

	var $outdir = "typo3temp/";		// The output directory of temporary files in PATH_site
	var $output = "";
	var $sizeDefault="56x56";

	var $file;
	var $size;
	var $imageList;
	var $outdir;
	var $output;
	var $input;

	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// ******************
		// Wrong referer?
		// ******************
		$refInfo=parse_url(getenv("HTTP_REFERER"));
		list($httpHost) = explode(":",getenv("HTTP_HOST"));
		if ($httpHost!=$refInfo["host"] && !$TYPO3_CONF_VARS["SYS"]["doNotCheckReferer"])	die ("Referer host was wrong!");
		
		
		$this->imageList = $TYPO3_CONF_VARS["GFX"]["imagefile_ext"];			// valid extensions. OBS: No spaces in the list, all lowercase...
		$this->file = $HTTP_GET_VARS["file"];
		$this->size = $HTTP_GET_VARS["size"];
		
		// if the filereference $this->file is relative, we correct the path
		if (substr($this->file,0,3)=="../")	{
			$this->input = PATH_site.ereg_replace("^\.\./","",$this->file);
		} else {
			$this->input = $this->file;
		}
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// if file exists, we make a thumbsnail of the file.
		if (@file_exists($this->input))	{
				// Check extension:
			if (	ereg("(.*)\.([^\.]*$)",$this->input,$reg)	)	{
				$ext=strtolower($reg[2]);
				if ($ext=="ttf")	{
					$this->fontGif($this->input);
				} elseif (!$this->inList($this->imageList, $ext))	{
					$this->errorGif("Not imagefile!",$ext,$this->input);
				}
			} else {
				$this->errorGif("Not imagefile!","No ext!",$this->input);	
			}
			
				// Init
			$mtime = filemtime($this->input);
			$outpath = PATH_site.$this->outdir;
			$outfile = "tmb_".substr(md5($this->input.$mtime),0,10).".".($TYPO3_CONF_VARS["GFX"]["gdlib_png"] ? "gif" : "gif");		// Should be - ? "png" : "gif" - , but doesn't work (ImageMagick prob.?)
			$this->output = $outpath.$outfile;
		
			if ($TYPO3_CONF_VARS["GFX"]["im"])	{
					// If thumbnail does not exist, we generate it
				if (!@file_exists($this->output))	{
					if ($this->size=="") {
						$this->size=$this->sizeDefault;	// default
					} else {
						// - I added extra check, so that the size input option could not be fooled to pass other values. That means the value is exploded, evaluated to an integer and the imploded to [value]x[value]. Further more you can specify: size=340 and it'll be translated to 340x340.
						$sizeParts = explode("x", $this->size."x".$this->size);
						$this->size = implode(array($this->intInRange($sizeParts[0],1,1000),$this->intInRange($sizeParts[1],1,1000)),"x");
					}
					if (strstr($this->input," ") || strstr($this->output," "))	{
						$this->errorGif("Spaces in","filepath",$this->input);
					}
					$cmd = ($TYPO3_CONF_VARS["GFX"]["im_path_lzw"] ? $TYPO3_CONF_VARS["GFX"]["im_path_lzw"] : $TYPO3_CONF_VARS["GFX"]["im_path"]).'convert -sample '.$this->size.' -colors 16 '.$this->input.'[0] '.$this->output;
		//			echo $cmd;
					exec($cmd);
					if (!@file_exists($this->output))	{
						$this->errorGif("No thumb","generated!",$this->input);
					}
				}
					// The thumbnail is read and output to the browser
				if($fd = @fopen($this->output,"r"))	{		
					if ($TYPO3_CONF_VARS["GFX"]["gdlib_png"])	{
						Header("Content-type: image/gif");		// Should be image/png, but doesn't work (ImageMagick prob.?)
					} else {
						Header("Content-type: image/gif");
					}
					while (!feof($fd))	{
						echo fread( $fd, 10000 );
					}
					fclose( $fd );
				} else {
					$this->errorGif("Read problem!","",$this->output);
				}
			} else exit;
		} else {
			$this->errorGif("No valid","inputfile!",$this->input);
		}
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
	function errorGif($l1,$l2,$l3)	{	
		global $TYPO3_CONF_VARS;

		if (!$TYPO3_CONF_VARS["GFX"]["gdlib"])	die($l1." ".$l2." ".$l3);
		
			// Prints an errormessage on the gif-file...
		if ($TYPO3_CONF_VARS["GFX"]["gdlib_png"])	{
			Header("Content-type: image/png");
			$im = imagecreatefrompng("gfx/notfound_thumb.png");
		} else {
			Header("Content-type: image/gif");
			$im = imagecreatefromgif("gfx/notfound_thumb.gif");
		}
	    $white = ImageColorAllocate($im, 0,0,0);
	    $black = ImageColorAllocate($im, 255,255,0);
		$x=0; 
		$font=0;
		if ($l1)	{
			imagefilledrectangle($im, $x, 9, 56, 16, $black);
	    	ImageString($im,$font,$x,9,$l1,$white);	
		}
		if ($l2)	{
			imagefilledrectangle($im, $x, 19, 56, 26, $black);
	    	ImageString($im,$font,$x,19,$l2,$white);	
		}
		if ($l3)	{
			imagefilledrectangle($im, $x, 29, 56, 36, $black);
	    	ImageString($im,$font,$x,29,substr($l3,-14),$white);	
		}
	
		if ($TYPO3_CONF_VARS["GFX"]["gdlib_png"])	{
			imagePng($im);
		} else {
			imageGif($im);
		}
		imagedestroy($im);
		exit;
	}
	function fontGif($font)	{	
		global $TYPO3_CONF_VARS;

		if (!$TYPO3_CONF_VARS["GFX"]["gdlib"])	die("");
	
			// Prints an errormessage on the gif-file...
		$im = ImageCreate(250,76);
	    $white = ImageColorAllocate($im, 255,255,255);
	    $col = ImageColorAllocate($im, 0,0,0);
	
		$string = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz������";
		$x=13;
	
		imagestring ($im, 1, 0, 2, "10", $col);
		imagestring ($im, 1, 0, 15, "12", $col);
		imagestring ($im, 1, 0, 30, "14", $col);
		imagestring ($im, 1, 0, 47, "18", $col);
		imagestring ($im, 1, 0, 68, "24", $col);
	
		imagettftext ($im, 10, 0, $x, 8, $col, $font, $string);
		imagettftext ($im, 12, 0, $x, 21, $col, $font, $string);
		imagettftext ($im, 14, 0, $x, 36, $col, $font, $string);
		imagettftext ($im, 18, 0, $x, 53, $col, $font, $string);
		imagettftext ($im, 24, 0, $x, 74, $col, $font, $string);
	
		if ($TYPO3_CONF_VARS["GFX"]["gdlib_png"])	{
			imagePng($im);
		} else {
			imageGif($im);
		}
		imagedestroy($im);
		exit;
	}
	function inList($in_list,$item)	{
		// Returns true if $item is in $in_list (which is comma-separated)
		return strstr(",".$in_list.",", ",".$item.",");
	}
	function intInRange($theInt,$min,$max)	{
		// Returns $theInt as an integer in the integerspace from $min to $max
		$theInt = intval($theInt);
		if ($theInt<$min){$theInt=$min;}
		if ($theInt>$max){$theInt=$max;}
		return $theInt;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/thumbs.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/thumbs.php"]);
}








// Must set here because t3lib_div is not included.
function makeInstance($className)	{
	$className = class_exists("ux_".$className)?"ux_".$className:$className;
	return new $className;
}

// Make instance:
$SOBE = makeInstance("SC_t3lib_thumbs");
$SOBE->init();
$SOBE->main();
?>