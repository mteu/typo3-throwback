<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * generate a page-tree. OBS: remember $clause
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
include_once(PATH_t3lib."class.t3lib_pagetree.php");

class t3lib_browseTree extends t3lib_pageTree {
	var $stored = array();
	var $bank=0;
	var $thisScript="";
	var $expandAll=0;
	var $expandFirst=0;
	
	var $BE_USER="";
	var $WEBMOUNTS="";
	var $FILEMOUNTS="";
	
	var $addSelfId = 0;
	var $titleAttrib="title";
	
	
	function PMicon($row,$a,$c,$nextCount,$exp)	{
		$PM = $nextCount ? ($exp?"minus":"plus") : "join";
		$BTM = ($a==$c)?"bottom":"";
		$icon = '<IMG src="'.$this->backPath.'t3lib/gfx/ol/'.$PM.$BTM.'.gif" width="18" height="16" align="top" border=0>';

		if ($nextCount)	{
			$cmd=$this->bank."_".($exp?"0_":"1_").$row["uid"];
			$bMark=($this->bank."_".$row["uid"]);
			$icon = $this->PM_ATagWrap($icon,$cmd,$bMark);
		}
		return $icon;
	}
	function PM_ATagWrap($icon,$cmd,$bMark="")	{
		if ($bMark)	{
			$anchor = "#".$bMark;
			$name=' name="'.$bMark.'"';
		}
		return '<a href="'.$this->thisScript.'?PM='.$cmd.$anchor.'"'.$name.'>'.$icon.'</a>';
	}
	function expandNext($id)	{
		return ($this->stored[$this->bank][$id] || $this->expandAll)? 1 : 0;
	}
	function wrapTitle($title,$v)	{
		$title= (!strcmp(trim($title),"")) ? "<em>[".$GLOBALS["LANG"]->php3Lang["labels"]["no_title"]."]</em>" : htmlspecialchars($title);
		return $title;
	}
	function printTree($treeArr="")	{
		$titleLen=intval($this->BE_USER->uc["titleLen"]);	
		if (!is_array($treeArr))	$treeArr=$this->tree;
		reset($treeArr);
		$out="";
		
		while(list($k,$v)=each($treeArr))	{
			$out.="<nobr>".$v["HTML"].$this->wrapTitle(t3lib_div::fixed_lgd($v["row"]["title"],$titleLen),$v["row"])."</nobr><BR>";
		}
		return $out;
	}
	function t3lib_browseTree()	{
		$this->BE_USER = $GLOBALS["BE_USER"];
		$this->WEBMOUNTS = $GLOBALS["WEBMOUNTS"];
		$this->FILEMOUNTS = $GLOBALS["FILEMOUNTS"];
	}
	function permsC()	{
		return $this->BE_USER->getPagePermsClause(1);
	}
	function getBrowsableTree($addClause="")	{
		$this->init(" AND ".$this->permsC().$addClause);
	
			// Get stored tree structure:
		$this->stored=unserialize($this->BE_USER->uc["browsePages"]);
			// PM action:
		$PM = t3lib_div::intExplode("_",t3lib_div::GPvar("PM"));
		if (count($PM)==3)	{
			if (isset($this->WEBMOUNTS[$PM[0]]))	{
				if ($PM[1])	{	// set
					$this->stored[$PM[0]][$PM[2]]=1;
					$this->savePosition();
				} else {	// clear
					unset($this->stored[$PM[0]][$PM[2]]);
					$this->savePosition();
				}
			}
		}

			// traverse mounts:
//		debug($this->WEBMOUNTS);
		$titleLen=intval($this->BE_USER->uc["titleLen"]);	
		$treeArr=array();
		reset($this->WEBMOUNTS);
		while(list($idx,$pid)=each($this->WEBMOUNTS))	{
				// Set first:
			$this->bank=$idx;
			$isOpen = $this->stored[$idx][$pid] || $this->expandFirst;

			$curIds = $this->ids;	// save ids
			$this->reset();
			$this->ids = $curIds;

				// Set PM icon:
			$cmd=$this->bank."_".($isOpen?"0_":"1_").$pid;
			$icon='<IMG src="'.$this->backPath.'t3lib/gfx/ol/'.($isOpen?"minus":"plus").'only.gif" width="18" height="16" align="top" border=0></a>';
			$firstHtml= $this->PM_ATagWrap($icon,$cmd);

			if ($pid>0)	{
				$rootRec=t3lib_befunc::getRecord("pages",$pid);
				$firstHtml.=$this->wrapIcon('<IMG src="'.$this->backPath.t3lib_iconWorks::getIcon("pages",$rootRec).'" width="18" height="16" align="top">',$rootRec);
			} else {
				$rootRec=array(
					"title"=>$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"],
					"uid"=>0
				);
				$firstHtml.=$this->wrapIcon('<IMG src="'.$this->backPath.'gfx/i/_icon_website.gif" width="18" height="16" align="top">',$rootRec);
			}
			$this->tree[]=array("HTML"=>$firstHtml,"row"=>$rootRec);
			if ($isOpen)	{
					// Set depth:
				$depthD='<IMG src="'.$this->backPath.'t3lib/gfx/ol/blank.gif" width="18" height="16" align="top">';
				if ($this->addSelfId)	$this->ids[] = $pid;
				$this->getTree($pid,999,$depthD);
			}

				// Add tree:
			$treeArr=array_merge($treeArr,$this->tree);
		}
		return $this->printTree($treeArr);
	}
	function savePosition($which="browsePages")	{
		$this->BE_USER->uc[$which] = serialize($this->stored);
		$this->BE_USER->writeUC();
//debug(unserialize($this->BE_USER->uc["browsePages"]));
	}
	function getBrowsableFolderTree()	{
			// Get stored tree structure:
		$this->stored=unserialize($this->BE_USER->uc["browseFolders"]);
		
			// Mapping md5-hash to shorter number:
//			debug($this->FILEMOUNTS);
		$hashMap=array();
		reset($this->FILEMOUNTS);
		while (list($key,$val) = each($this->FILEMOUNTS))	{
			$nkey = hexdec(substr($key,0,4));
			$hashMap[$nkey]=$key;
			$this->FILEMOUNTS[$key]["nkey"]=$nkey;
		}
//		debug($hashMap);

			// PM action:
		$PM = t3lib_div::intExplode("_",t3lib_div::GPvar("PM"));
		if (count($PM)==3)	{
			if (isset($this->FILEMOUNTS[$hashMap[$PM[0]]]))	{
				if ($PM[1])	{	// set
					$this->stored[$PM[0]][$PM[2]]=1;
					$this->savePosition("browseFolders");
				} else {	// clear
					unset($this->stored[$PM[0]][$PM[2]]);
					$this->savePosition("browseFolders");
				}
			}
		}


			// traverse mounts:
//		debug($this->FILEMOUNTS);
		$titleLen=intval($this->BE_USER->uc["titleLen"]);	
		$treeArr=array();
		reset($this->FILEMOUNTS);
		while (list($key,$val) = each($this->FILEMOUNTS))	{
			$md5_uid = md5($val["path"]);
			$specUID=hexdec(substr($md5_uid,0,6));
			$this->specUIDmap[$specUID]=$val["path"];

				// Set first:
			$this->bank=$val["nkey"];
			$isOpen = $this->stored[$val["nkey"]][$specUID] || $this->expandFirst;
			$this->reset();

				// Set PM icon:
			$cmd=$this->bank."_".($isOpen?"0_":"1_").$specUID;
			$icon='<IMG src="'.$this->backPath.'t3lib/gfx/ol/'.($isOpen?"minus":"plus").'only.gif" width="18" height="16" align="top" border=0></a>';
			$firstHtml= $this->PM_ATagWrap($icon,$cmd);

			switch($val["type"])	{
				case "user":	$icon = "gfx/i/_icon_ftp_user.gif";	break;
				case "group":	$icon = "gfx/i/_icon_ftp_group.gif"; break;
				default:		$icon = "gfx/i/_icon_ftp.gif"; break;
			}
			
			$firstHtml.=$this->wrapIcon('<IMG src="'.$this->backPath.$icon.'" width="18" height="16" align="top">',$val);
				$row=array();
				$row["path"]=$val["path"];
				$row["uid"]=$specUID;
				$row["title"]=$val["name"];
//				debug($val);
			$this->tree[]=array("HTML"=>$firstHtml,"row"=>$row);

			if ($isOpen)	{
					// Set depth:
				$depthD='<IMG src="'.$this->backPath.'t3lib/gfx/ol/blank.gif" width="18" height="16" align="top">';
				$this->getFolderTree($val["path"],999,$depthD);
			}
				// Add tree:
			$treeArr=array_merge($treeArr,$this->tree);
		}
		return $this->printTree($treeArr);
	}
	function titleAttribForPages($row)	{
		return t3lib_BEfunc::titleAttribForPages ($row,"1=1".$this->clause,0);
	}
}
 
 
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_browsetree.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_browsetree.php"]);
}

?>