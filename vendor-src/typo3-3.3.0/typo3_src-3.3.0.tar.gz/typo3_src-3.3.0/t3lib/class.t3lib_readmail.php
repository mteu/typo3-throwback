<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license
*  from the author is found in LICENSE.txt distributed with these scripts.
*
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * Functions used to read email content
 *
 * The class is still just a bunch of miscellaneous functions used to 
 * read content out of emails
 *
 * Used by the returnmail.phpsh script eg.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_readmail {

	function find_MIDfromReturnPath($to)	{
		$parts = explode("mid",strtolower($to));
		$moreParts=explode("_",$parts[1]);
		$out=array(
			"mid" => $moreParts[0],
			"rtbl" => substr($moreParts[1],0,1),
			"rid" => intval(substr($moreParts[1],1))
		);
		if ($out["rtbl"]=="p")		$out["rtbl"]="P";
//		debug($to);
		return($out);
	}
	function find_XTypo3MID($content)	{
		if (strstr($content,"X-Typo3MID:"))	{
			$p=explode("X-Typo3MID:",$content,2);
			$l=explode(chr(10),$p[1],2);
			list($mid,$hash)=t3lib_div::trimExplode("-",$l[0]);
			if (md5($mid)==$hash)	{
				$moreParts=explode("_",substr($mid,3));
				$out=array(
					"mid" => $moreParts[0],
					"rtbl" => substr($moreParts[1],0,1),
					"rid" => substr($moreParts[1],1)
				);
				return($out);
			}
		}
//		debug(array($content));
	}
	function extractMailHeader($content,$limit=0)	{
		if ($limit)	$content = substr($content,0,$limit);
		
		$lines=explode(chr(10),ltrim($content));
		$headers=array();
		$p="";
		while(list($k,$str)=each($lines))		{
			if (!trim($str))	break;
			$parts = explode(" ",$str,2);
			if ($parts[0] && substr($parts[0],-1)==":")	{
				$p=strtolower(substr($parts[0],0,-1));
				if (isset($headers[$p]))	{
					$headers[$p."."][]=$headers[$p];
					$headers[$p]="";
				}
				$headers[$p]=trim($parts[1]);
			} else {
				$headers[$p].=" ".trim($str);
			}
			unset($lines[$k]);
		}
		if (!$limit)	$headers["CONTENT"]=ltrim(implode(chr(10),$lines));
		return $headers;
	}
	function getMessage($mailParts)	{
		if ($mailParts["content-type"])	{
			$CType = $this->getCType($mailParts["content-type"]);
			if ($CType["boundary"])	{
				$parts = $this->getMailBoundaryParts($CType["boundary"],$mailParts["CONTENT"]);
				$c=$this->getTextContent($parts[0]);
			} else {
				$c=$this->getTextContent(
					"Content-Type: ".$mailParts["content-type"]."
					".$mailParts["CONTENT"]
				);
			}
		} else {
			$c = $mailParts["CONTENT"];
		}
		return $c;
	}
	function getTextContent($content)	{
		$p=$this->extractMailHeader($content);
		// Here some decoding might be needed...
		// However we just return what is believed to be the proper notifycation:
		return $p["CONTENT"];
	}
	function getMailBoundaryParts($boundary,$content)	{
		$mParts = explode("--".$boundary,$content);
		unset($mParts[0]);
		reset($mParts);
		$new=array();
		while(list(,$val)=each($mParts))	{
			if (trim($val)=="--") break;
			$new[] = ltrim($val);
		}
		return $new;
	}
	function getCType($str)	{
		$parts = explode(";",$str);
		$cTypes=array();
		$cTypes["ContentType"]=$parts[0];
		next($parts);
		while(list(,$ppstr)=each($parts))	{
			$mparts = explode("=",$ppstr,2);
			if (count($mparts)>1)	{
				$cTypes[strtolower(trim($mparts[0]))]=ereg_replace('^"','',trim(ereg_replace('"$','',trim($mparts[1]))));
			} else {
				$cTypes[]=$ppstr;
			}
		}
		return $cTypes;
	}
	function analyseReturnError($c)	{
		$cp=array();
		if (strstr($c,"--- Below this line is a copy of the message."))	{		// QMAIL
			list($c)=explode("--- Below this line is a copy of the message.",$c);	// Splits by the QMAIL divider
			$cp["content"]=trim($c);
			$parts = explode(">:",$c,2);
			$cp["reason_text"]=trim($parts[1]);
			$cp["mailserver"]="Qmail";
			if (eregi("550|no mailbox|account does not exist",$cp["reason_text"]))	{
				$cp["reason"]=550;	// 550 Invalid recipient
			} elseif (stristr($cp["reason_text"],"couldn't find any host named")) {
				$cp["reason"]=2;	// Bad host
			} elseif (eregi("Error in Header|invalid Message-ID header",$cp["reason_text"])) {
				$cp["reason"]=554;
			} else {
				$cp["reason"]=-1;
			}
		} elseif (strstr($c,"The Postfix program"))	{		// Postfix
			$cp["content"]=trim($c);
			$parts = explode(">:",$c,2);
			$cp["reason_text"]=trim($parts[1]);
			$cp["mailserver"]="Postfix";
			if (stristr($cp["reason_text"],"550"))	{
				$cp["reason"]=550;	// 550 Invalid recipient, User unknown
			} elseif (stristr($cp["reason_text"],"553")) {
				$cp["reason"]=553;	// No such user
			} elseif (stristr($cp["reason_text"],"551")) {
				$cp["reason"]=551;	// Mailbox full
			} else {
				$cp["reason"]=-1;
			}
		} else {	// No-named:
			$cp["content"]=trim($c);
			$cp["reason_text"]=trim(substr($c,0,1000));
			$cp["mailserver"]="unknown";
			if (eregi("Unknown Recipient|Delivery failed 550|Receiver not found|User not listed|recipient problem|Delivery to the following recipients failed|User unknown|recipient name is not recognized",$cp["reason_text"]))	{
				$cp["reason"]=550;	// 550 Invalid recipient, User unknown
			} elseif (eregi("over quota|mailbox full",$cp["reason_text"]))	{
				$cp["reason"]=551;	
			} elseif (eregi("Error in Header",$cp["reason_text"]))	{
				$cp["reason"]=554;	
			} else {
				$cp["reason"]=-1;
			}
		}
//		unset($cp["content"]);
		return $cp;	
	}
}

if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_readmail.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_readmail.php"]);
}

?>