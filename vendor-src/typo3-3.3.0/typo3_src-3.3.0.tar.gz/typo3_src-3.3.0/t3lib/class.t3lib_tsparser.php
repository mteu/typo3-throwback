<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TypoScript parser
 *
 * Parses TypoScript
 *
 * @see		t3lib_tstemplate.php, t3lib_matchcondition.php
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_TSparser {
	var $strict = 1;
	var $setup = Array();
	var $raw; // raw data
	var $rawP; // pointer 
	var $lastComment="";	
	var $regComments = 0;		// DO NOT register the comments. This is default for the ordinary sitetemplate!
	var $commentSet=0;			//
	var $multiLineEnabled=0;		// Internally set, when multiline value is accumulated
	var $multiLineObject="";		// Internally set, when multiline value is accumulated
	var $multiLineValue=array();		// Internally set, when multiline value is accumulated
	var $inBrace = 0;		// Internally
	var $errors=array();		
	var $lineNumberOffset=0;
	var $breakPointLN=0;	
	
	var $lastConditionTrue = 1;	// For each condition this falg is set, if the condition is true, else it's cleared. Then it's used by the [ELSE] condition to determine if the next part should be parsed.

	function parse($string,$matchObj="")	{		// If matchObj not specified, then no conditions will work!
//debug($this->breakPointLN);

		$this->raw = explode(chr(10),$string);
		$this->rawP = 0;
//debug($this->raw);
		
		$pre = "[GLOBAL]";
		while($pre)	{
			if ($this->breakPointLN && $pre=="[_BREAK]")	{
				$this->error("Breakpoint at ".($this->lineNumberOffset+$this->rawP-2).": Line content was '".$this->raw[$this->rawP-2]."'",1);	
				break;
			}

			if (strtoupper($pre)=="[GLOBAL]" || strtoupper($pre)=="[END]" || (!$this->lastConditionTrue && strtoupper($pre)=="[ELSE]"))	{
				$pre = trim($this->parseSub($this->setup));
				$this->lastConditionTrue=1;
			} else {
				if (strtoupper($pre)!="[ELSE]")	{$this->sections[md5($pre)]=$pre;}	// we're in a specific section. Therefore we log this section
				if (is_object($matchObj) && $matchObj->match($pre))	{
					if (strtoupper($pre)!="[ELSE]")	{$this->sectionsMatch[md5($pre)]=$pre;}
					$pre = trim($this->parseSub($this->setup));
					$this->lastConditionTrue=1;
				} else {
					$pre = trim($this->nextDivider());
					$this->lastConditionTrue=0;
				}
			}
		}
		if ($this->inBrace)	{$this->error("Line ".($this->lineNumberOffset+$this->rawP-1).": The script is short of ".$this->inBrace." end brace(s)",1);	}
		$this->lineNumberOffset+=count($this->raw)+1;
	}
	function nextDivider()	{
		while (isset($this->raw[$this->rawP]))	{
			$line = ltrim($this->raw[$this->rawP]);
			$this->rawP++;
			if ($line && substr($line,0,1)=="[")	{
				return $line;
			}
		}
	}
	function parseSub(&$setup)	{
		while (isset($this->raw[$this->rawP]))	{
			$line = ltrim($this->raw[$this->rawP]);
			$this->rawP++;

				// Breakpoint?
			if ($this->breakPointLN && ($this->lineNumberOffset+$this->rawP-1)==($this->breakPointLN+1))	{	// by adding 1 we get that line processed
				return "[_BREAK]";
			}

				// Set comment flag?
			if (!$this->multiLineEnabled && substr($line,0,2)=="/*")	{
				$this->commentSet=1;
			}
				
			if (!$this->commentSet && ($line || $this->multiLineEnabled))	{	// If $this->multiLineEnabled we will go and get the line values here because we know, the first if() will be true.
				if ($this->multiLineEnabled) {	// If multiline is enabled. Escape by ")"
					if (substr($line,0,1)==")")	{	// Multiline ends...
						$this->multiLineEnabled=0;	// Disable multiline
						$theValue = implode($this->multiLineValue,chr(10));
						if (strstr($this->multiLineObject,"."))	{	
							$this->setVal($this->multiLineObject,$setup,array($theValue));	// Set the value deeper.
						} else {
							$setup[$this->multiLineObject] = $theValue;	// Set value regularly
							if ($this->lastComment && $this->regComments)	{
								$setup[$this->multiLineObject.".."].=$this->lastComment;
							}
						}
					} else{
						$this->multiLineValue[]=$this->raw[($this->rawP-1)];
					}
				} elseif ($this->inBrace==0 && substr($line,0,1)=="[")	{	// Beginning of condition (only on level zero compared to brace-levels
					return $line;
				} else {
					if (substr($line,0,1)=="[" && strtoupper(trim($line))=="[GLOBAL]")	{		// Return if GLOBAL condition is set - no matter what.
						$this->error("Line ".($this->lineNumberOffset+$this->rawP-1).": On return to [GLOBAL] scope, the script was short of ".$this->inBrace." end brace(s)",1);
						$this->inBrace=0;
						return $line;
					} elseif (strcspn($line,"}#/")!=0)	{	// If not brace-end or comment
						$varL = strcspn($line," {=<>(");		// Find object name string until we meet an operator	VER2: Added '>'!!
						$objStrName=trim(substr($line,0,$varL));
						if ($objStrName)	{
							if ($this->strict && eregi("[^[:alnum:]_\.-]",$objStrName,$r))	{
								$this->error("Line ".($this->lineNumberOffset+$this->rawP-1).": Object Name String, '".htmlspecialchars($objStrName)."' contains invalid character '".$r[0]."'. Must be alphanumeric or one of: '_-.'");
							} else {
								$line = ltrim(substr($line,$varL));
								switch(substr($line,0,1))	{
									case "=":
										if (strstr($objStrName,"."))	{
											$value = Array();
											$value[0] = trim(substr($line,1));
											$this->setVal($objStrName,$setup,$value);
										} else {
											$setup[$objStrName] = trim(substr($line,1));
											if ($this->lastComment && $this->regComments)	{	// Setting comment..
												$setup[$objStrName.".."].=$this->lastComment;
											}
										}
									break;
									case "{":
										$this->inBrace++;
										if (strstr($objStrName,"."))	{
											$exitSig=$this->rollParseSub($objStrName,$setup);
											if ($exitSig)	return $exitSig;
										} else {
											if (!isset($setup[$objStrName."."])) {$setup[$objStrName."."] = Array();}
											$exitSig=$this->parseSub($setup[$objStrName."."]);
											if ($exitSig)	return $exitSig;
										}
									break;
									case "(":
										$this->multiLineObject = $objStrName;
										$this->multiLineEnabled=1;
										$this->multiLineValue=array();
									break;
									case "<":
										$theVal = trim(substr($line,1));
										if (substr($theVal,0,1)==".") {
											$res = $this->getVal(substr($theVal,1),$setup);
										} else {
											$res = $this->getVal($theVal,$this->setup);
										}
										$this->setVal($objStrName,$setup,unserialize(serialize($res)),1);
									break;
									case ">":
										$this->setVal($objStrName,$setup,"UNSET");
									break;
									default:
										$this->error("Line ".($this->lineNumberOffset+$this->rawP-1).": Object Name String, '".htmlspecialchars($objStrName)."' was not preceeded by any operator, =<>({");
									break;
								}
							}
							$this->lastComment="";
						}
					} elseif (substr($line,0,1)=="}")	{
						$this->inBrace--;
						$this->lastComment="";
						if ($this->inBrace<0)	{
							$this->error("Line ".($this->lineNumberOffset+$this->rawP-1).": An end brace is in excess.",1);
							$this->inBrace=0;
						} else {
							break;
						}
					} elseif ($this->regComments) {
						// Comment. The comments are concatenated in this temporary string:
						$this->lastComment.= trim($line).chr(10);
					}
				}
			}
			
				// Unset comment
			if ($this->commentSet && substr($line,0,2)=="*/")	{
				$this->commentSet=0;
			}
		}
	}
	function rollParseSub($string,&$setup)	{
		if ((string)$string!="")	{
			$keyLen = strcspn($string,".");
			if ($keyLen==strlen($string))	{
				$key = $string.".";
				if (!isset($setup[$key])){$setup[$key]=Array();}
				$exitSig=$this->parseSub($setup[$key]);
				if ($exitSig)	return $exitSig;
			} else {
				$key = substr($string,0,$keyLen).".";
				if (!isset($setup[$key])){$setup[$key]=Array();}
				$exitSig=$this->rollParseSub(substr($string,$keyLen+1),$setup[$key]);
				if ($exitSig)	return $exitSig;
			}
		}
	}
	function getVal($string,$setup)	{
		if ((string)$string!="")	{
			$keyLen = strcspn($string,".");
			if ($keyLen==strlen($string))	{
				if (isset($setup[$string]))	{$retArr[0]=$setup[$string];	}
				if (isset($setup[$string."."]))	{$retArr[1]=$setup[$string."."];	}
				return $retArr;
			} else {
				$key = substr($string,0,$keyLen).".";
				if ($setup[$key])	{
					return $this->getVal(substr($string,$keyLen+1),$setup[$key]);
				}
			}
		}
	}
	function setVal($string,&$setup,$value,$wipeOut=0)	{
		if ((string)$string!="")	{
			$keyLen = strcspn($string,".");
			if ($keyLen==strlen($string))	{
				if ($value=="UNSET")	{
					unset($setup[$string]);
					unset($setup[$string."."]);
				} else {
					if ($wipeOut && $this->strict)	{
						if ((isset($setup[$string]) && !isset($value[0])) || (isset($setup[$string."."]) && !isset($value[1]))) {$this->error("Line ".($this->lineNumberOffset+$this->rawP-1).": Object copied in this line '".ltrim($this->raw[($this->rawP-1)])."' would leave either the value or properties untouched in TypoScript ver1. Please check that this is not a problem for you.",1);}
						unset($setup[$string]);
						unset($setup[$string."."]);
					}
					if (isset($value[0])) {$setup[$string] = $value[0];}
					if (isset($value[1])) {$setup[$string."."] = $value[1];}
					if ($this->lastComment && $this->regComments)	{
						$setup[$string.".."].=$this->lastComment;
					}
				}
			} else {
				$key = substr($string,0,$keyLen).".";
				if (!isset($setup[$key])){$setup[$key]=Array();}
				$this->setVal(substr($string,$keyLen+1),$setup[$key],$value);
			}
		}
	}
	function error($err,$num=2)	{
		if (is_object($GLOBALS["TT"]))	$GLOBALS["TT"]->setTSlogMessage($err,$num);
		$this->errors[]=array($err,$num);
//debug($err,1);
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tsparser.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_tsparser.php"]);
}

?>