<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Load database groups (relations)
 *
 * Used to fetch information from the database when loading values for records
 * This is VERY OFTEN used with transferdata.php that takes care of the main operation
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_loadDBGroup	{
	var $fromTC = 1;		// Means that only uid and the label-field is returned
	//internal
	var $tableArray=Array();	// Indeholder tabellernes navne som keys. Values er id'numre under hver tabel
	var $itemArray=Array();		// Indeholder items i lige linie
	var $additionalWhere=array();
	var $checkIfDeleted = 1;		// deleted-column is added to additionalWhere... if this is set...
	var $dbPaths=Array();
	
	function start ($itemlist,$tablelist, $MMtable="",$MMuid=0)	{
/*		$this->results[pages][0][title] = $GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"];
		$this->results[pages][0][uid] = 0;
			// Disabled this so that the non-existing root page is never selected and transfered as a record
*/
		if (!strcmp(trim($tablelist),"*"))	{
			$tablelist = implode(",",array_keys($GLOBALS["TCA"]));
		}

		// Array med tabellerne oprettes
		$tempTableArray = t3lib_div::trimExplode(",",$tablelist,1);
		while(list($key,$val)=each($tempTableArray))	{
			$tName = trim($val);
			$this->tableArray[$tName] = Array();
			if ($this->checkIfDeleted && $GLOBALS["TCA"][$tName]["ctrl"]["delete"])	{
				$fieldN = $tName.".".$GLOBALS["TCA"][$tName]["ctrl"]["delete"];
				$this->additionalWhere[$tName].=" AND NOT ".$fieldN;
			}
		}
		if (is_array($this->tableArray))	{
			reset($this->tableArray);
		} else {return "No tables!";}
		$this->firstTable = key($this->tableArray);		// Is the first table
		next($this->tableArray);
		$this->secondTable = key($this->tableArray);	// If the second table is set and the ID number is less than zero (later) then the record is regarded to come from the second table...
		if ($MMtable)	{
			$this->readMM($MMtable,$MMuid);
//			debug($this->tableArray);
//			debug($this->itemArray);
		} else {
			// Array med Items findes
			if ((string)trim($itemlist)!="")	{
				$tempItemArray = explode(",",$itemlist);
				while(list($key,$val)=each($tempItemArray))	{
					$val = strrev($val);
					$parts = explode("_",$val,2);
					$theID = strrev($parts[0]);
					if ($this->testInt($theID))	{	// Be sure
						$theTable = trim($parts[1]) ? strrev(trim($parts[1])) : ($this->secondTable&&$theID<0 ? $this->secondTable : $this->firstTable);
						if ((string)$theID!="" && $theID && $theTable && isset($this->tableArray[$theTable]))	{		// OLD: ($theID || $theTable=="pages") ... where pages=0 would go !
							$theID = $this->secondTable ? abs(intval($theID)) : intval($theID);
							$this->itemArray[$key]["id"] = $theID;
							$this->itemArray[$key]["table"] = $theTable;
							$this->tableArray[$theTable][]=$theID;
						}
					}
				}
			}
		}		
	}
	function getValueArray($prependTableName="")	{
		$valueArray=Array();
		$tableC = count($this->tableArray);
		if ($tableC)	{
			$prep = ($tableC>1||$prependTableName) ? 1 : 0;
			reset($this->itemArray);
			while (list(,$val)=each($this->itemArray))	{
				$valueArray[]=(($prep)?$val["table"]."_":"").$val["id"];
			}
		}
		return $valueArray;	
	}
	function convertPosNeg($valueArray,$fTable)	{
//debug($valueArray);
		if (is_array($valueArray) && $fTable)	{
			reset($valueArray);
			while (list($key,$val)=each($valueArray))	{
				$val = strrev($val);
				$parts = explode("_",$val,2);
				$theID = strrev($parts[0]);
				$theTable = strrev($parts[1]);
				$valueArray[$key]= $theTable&&strcmp($theTable,$fTable) ? $theID*-1 : $theID;
			}
		}
//debug($valueArray);
		return $valueArray;	
	}
	function readMM($tableName,$uid)	{	// You can call this function after start if you supply no list to start()
			// delete all relations:
		$uid = intval($uid);
		$query="SELECT * FROM ".$tableName." WHERE uid_local=".$uid." ORDER BY sorting";
		$res=mysql(TYPO3_db,$query);
		echo mysql_error();
		$key=0;
		while($row=mysql_fetch_assoc($res))	{
			$theTable = $row["tablenames"] ? $row["tablenames"] : $this->firstTable;		// If tablesnames columns exists and contain a name, then this value is the table, else it's the the firstTable...
			if (($row["uid_foreign"] || $theTable=="pages") && $theTable && isset($this->tableArray[$theTable]))	{
				$this->itemArray[$key][id] = $row["uid_foreign"];
				$this->itemArray[$key][table] = $theTable;
				$this->tableArray[$theTable][]= $row["uid_foreign"];
			}
			$key++;
		}
	}
	function writeMM($tableName,$uid,$prependTableName=0)	{
			// delete all relations:
		$uid = intval($uid);
		$query="DELETE FROM ".$tableName." WHERE uid_local=".$uid;
		$res=mysql(TYPO3_db,$query);
		$valueArray=Array();
		$tableC = count($this->tableArray);
		if ($tableC)	{
			$prep = ($tableC>1||$prependTableName) ? 1 : 0;
			reset($this->itemArray);
			$c=0;
			$tName=array();
			while (list(,$val)=each($this->itemArray))	{
				$c++;
				if ($prep)	{
					$tName=array(",tablenames", ",'".addslashes($val["table"])."'");
				}
				$query="INSERT INTO ".$tableName." (uid_local,uid_foreign,sorting".$tName[0].") VALUES ('".$uid."','".addslashes($val["id"])."',".$c.$tName[1].")";
//				debug($query,1);
				$res=mysql(TYPO3_db,$query);
			}
		}
	}
	function getFromDB()	{
		// Henter fra databasen
		reset ($this->tableArray);
		while (list($key,$val)=each($this->tableArray))	{
			if ($val)	{
				$itemList = implode($val,",");
				if ($itemList)	{
					$from = "*";
					if ($this->fromTC)	{
						$from = "uid,pid";
						if ($GLOBALS["TCA"][$key]["ctrl"]["label"])	{
							$from.= ",".$GLOBALS["TCA"][$key]["ctrl"]["label"];	// Titel
						}
						if ($GLOBALS["TCA"][$key]["ctrl"]["thumbnail"])	{
							$from.= ",".$GLOBALS["TCA"][$key]["ctrl"]["thumbnail"];	// Thumbnail
						}
					}
					$query="SELECT ".$from." FROM $key WHERE uid IN ($itemList)".$this->additionalWhere[$key];
					$res=mysql(TYPO3_db,$query);
					while($row = mysql_fetch_assoc($res))	{
						$this->results[$key][$row[uid]]=$row;
					}
				}
			}
		}
		return $this->results;
	}
	function readyForInterface()	{
		// kr�ver at $TCA findes GLOBALT
		if (!is_array($this->itemArray))	{return false;}
		reset ($this->itemArray);
		$value="";
		$perms_clause = $GLOBALS["BE_USER"]->getPagePermsClause(1);		// For use when getting the paths....
		$titleLen=intval($GLOBALS["BE_USER"]->uc[titleLen]);
		while(list($key,$val)=each($this->itemArray))	{
			$theRow = $this->results[$val[table]][$val[id]];
			if ($theRow)	{
				$label = t3lib_div::fixed_lgd(strip_tags($theRow[$GLOBALS["TCA"][$val["table"]]["ctrl"]["label"]]),$titleLen);
				$label = ($label)?$label:"[...]";
				$this->dbPaths[$val[table]."_".$theRow[uid]]= $GLOBALS["LANG"]->sL($GLOBALS["TCA"][$val["table"]]["ctrl"]["title"])." [".$theRow[uid]."] - ".t3lib_BEfunc::getRecordPath ($theRow[pid],$perms_clause,20);
				$value.=$val[table].'_'.$val[id].'|'.rawurlencode($label).',';
			}
		}
		return $value;
	}
	function thumbsForInterface()	{
		// kr�ver at $TCA findes GLOBALT
		if (!is_array($this->itemArray))	{return false;}
		reset ($this->itemArray);
		$value="";
		while(list($key,$val)=each($this->itemArray))	{
			$theRow = $this->results[$val["table"]][$val["id"]];
			if ($theRow)	{
				$thumbcol = $GLOBALS["TCA"][$val["table"]]["ctrl"]["thumbnail"];
				if ($thumbcol)	{
					t3lib_div::loadTCA($val["table"]);
					$value.= "parent.thumbRef.add('".$val["table"]."_".$val["id"]."','".$theRow[$thumbcol]."','../".$GLOBALS["TCA"][$val["table"]]["columns"][$thumbcol]["config"]["uploadfolder"]."/');\n";
				}
			}
		}
		return $value;
	}
	function pathRefsForInterface()	{
		// kr�ver at $TCA findes GLOBALT
		if (!is_array($this->dbPaths))	{return false;}
		reset ($this->dbPaths);
		$value="";
		while(list($key,$val)=each($this->dbPaths))	{
			$value.= "parent.dbPathRef.add('".$key."','".rawurlencode($val)."','');\n";
		}
		return $value;
	}
	function testInt($var)	{
		// returns true if string is an integer
		return !strcmp($var,intval($var));
	}
}




if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_loaddbgroup.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_loaddbgroup.php"]);
}


?>