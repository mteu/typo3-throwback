The "t3lib".


The "t3lib" contains PHP4-classes providing core 
functionalities of Typo3 such as manipulation the 
database (tce_main.php), providing user authentication 
and datatransfer to the Typo3 standard interface to name a few.