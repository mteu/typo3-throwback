<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Used to setup localconf.php and verify the Typo3 installation
 *
 * This script should reduce the number of questions on the mailing with more than 50%... :-)
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 

class t3lib_install {
	var $getGD_start_string='<H2 align="center"><A NAME="module_gd">gd</A></H2>';	// Used to identify the GD section in the output from phpinfo()
	var $getGD_end_string = '</TABLE>';	// Used to identify the end of the GD section (found with getGD_start_string) in the output from phpinfo()
	var $getTTF_string = 'with TTF library';	// Used to identify whether TTF-lib is included with GD
	var $getTTF_string_alt = 'with freetype';       // Used to identify whether TTF-lib is included with GD
	var $action = "";		// The url that calls this script
	var $scriptSelf = "index.php";		// The url that calls this script
	var $fontTag2='<font face="verdana,sans-serif" size=2 color=black>';
	var $fontTag1='<font face="verdana,sans-serif" size=1 color=black>';
	var $headerStyle ='';
	var $contentBeforeTable="";

	var $allowFileEditOutsite_typo3conf_dir=0;

	var $INSTALL =array();		// In constructor: is set to global GET/POST var TYPO3_INSTALL
	var $messages = array();	// Used to set (error)messages from the executing functions like mail-sending, writing Localconf and such
	var $checkIMlzw = 0;		// If set, lzw capabilities of the available ImageMagick installs are check by actually writing a gif-file and comparing size
	var $checkIM = 0;			// If set, ImageMagick is checked.
	var $localconf_addLinesOnly=0;	// If this is set, modifications to localconf.php is done by adding new lines to the array only. If unset, existing values are recognized and changed.
	var $localconf_editPointToken="INSTALL SCRIPT EDIT POINT TOKEN - all lines after this points may be changed by the install script!";		// If set and addLinesOnly is disabled, lines will be change only if they are after this token (on a single line!) in the file
	var $allowUpdateLocalConf=0;	// If set, this class will allow the user to update the localconf.php file. Is set true in the init.php file.
	var $dumpImCommands=1;			// If set, the image Magick commands are always outputted in the image processing checker
	var $deletedPrefixKey="zzz_deleted_";	//
	var $backPath="../";
	var $mysqlVersion = "3.22";		// 3.22 or 3.23	If set to 3.23, then the expected format of the incoming sql-dump files are changed. 'DEFAULT' and 'NOT NULL' are reversed in order and 'DEFAULT' is lowercase. Also auto_incremented fields are without default definitions.
	var $mode = "";	// If set to "123" then only most vital information is displayed.
	var $step = 0;	// If set to 1,2,3 or GO it signifies various functions.
	
	// internal
	var $passwordOK=0;			// This is set, if the password check was ok. The function init() will exit if this is not set
	var $silent=1;				// If set, the check routines don't add to the message-array
	var $messageFunc_nl2br=1;
	var $setLocalconf=0;		// Used to indicate that a value is change in the line-array of localconf and that it should be written.
	var $sections=array();		// Used to gather the message information.
	var $fatalError=0;			// This is set if some error occured that will definitely prevent TYpo3 from running.
	var $sendNoCacheHeaders=1;	
	var $config_array = array(	// Flags are set in this array if the options are available and checked ok.
		"gd"=>0,
		"gd_gif"=>0,
		"gd_png"=>0,
		"gd_jpg"=>0,
		"freetype" => 0,
		"safemode" => 0,
		"dir_typo3temp" => 0,
		"dir_temp" => 0,
		"im_versions" => array(),
		"im" => 0,
		"sql.safe_mode_user" => "",
		"mysqlConnect" => 0,
		"no_database" => 0
	);
	var $typo3temp_path="";
	
	var $menuitems = array(
		"config" => "Basic Configuration",
		"database" => "Database Analyser",
		"images" => "Image Processing",
		"extConfig" => "All Configuration",
		"typo3temp" => "typo3temp/",
		"phpinfo" => "phpinfo()",
		"typo3conf_edit" => "Edit files in typo3conf/",
		"about" => "About"
	);
	var $cookie_name = "Typo3InstallTool";

	/**
	 * Constructor
	 */
	function t3lib_install()	{
		if (!$GLOBALS["TYPO3_CONF_VARS"]["BE"]["installToolPassword"])	die("Install Tool deactivated.<BR>You must enable it by setting a password in typo3conf/localconf.php. If you insert the line below, the password will be 'joh316':<BR><BR>\$TYPO3_CONF_VARS[\"BE\"][\"installToolPassword\"] = \"bacb98acf97e0b6112b1d1b650b84971\";<BR><BR>See the document 'installing_upgrading_32b1.pdf' for more info.");

		if ($this->sendNoCacheHeaders)	{
			header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
			header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
			header("Expires: 0");
			header("Cache-Control: no-cache, must-revalidate");
			header("Pragma: no-cache");
		}
		
			// ****************************
			// Initializing incoming vars.
			// ****************************
		$this->INSTALL = t3lib_div::GPvar("TYPO3_INSTALL");
		$this->mode = t3lib_div::GPvar("mode");
		$this->step = t3lib_div::GPvar("step");
		if ($GLOBALS["HTTP_GET_VARS"]["TYPO3_INSTALL"]["type"])	$this->INSTALL["type"] = $GLOBALS["HTTP_GET_VARS"]["TYPO3_INSTALL"]["type"];

		if ($this->step==3)	{
			$this->INSTALL["type"]="database";
		}
		
		if ($this->mode=="123")	{
			$tempItems = $this->menuitems;
			unset($this->menuitems);
			$this->menuitems["config"] = $tempItems["config"];
			$this->menuitems["database"] = $tempItems["database"];
			if (!$this->INSTALL["type"] || !isset($this->menuitems[$this->INSTALL["type"]]))	$this->INSTALL["type"] = "config";
		} else {
			if (!$this->INSTALL["type"] || !isset($this->menuitems[$this->INSTALL["type"]]))	$this->INSTALL["type"] = "about";
		}

		$this->action = $this->scriptSelf."?TYPO3_INSTALL[type]=".$this->INSTALL["type"].($this->mode?"&mode=".rawurlencode($this->mode):"").($this->step?"&step=".rawurlencode($this->step):"");
		$this->typo3temp_path = PATH_site."typo3temp/";


			// ****************
			// Check password
			// ****************
			// Getting a unique session key, used to encode the session-access cookie later...
		$uKey = $GLOBALS["HTTP_COOKIE_VARS"][$this->cookie_name."_key"];
		if (!$uKey)	{
			$uKey = md5(uniqid(microtime()));
			SetCookie($this->cookie_name."_key", $uKey, 0, "/");		// Cookie is set
		}
			// Check if the password from TYPO3_CONF_VARS combined with uKey matches the sKey cookie. If not, ask for password.
		$sKey = $GLOBALS["HTTP_COOKIE_VARS"][$this->cookie_name];
		
		if (md5($GLOBALS["TYPO3_CONF_VARS"]["BE"]["installToolPassword"]."|".$uKey) == $sKey || $this->checkPassword($uKey))	{
			$this->passwordOK=1;
		}
		
		if ($GLOBALS["CLIENT"]["SYSTEM"]=="unix" && $GLOBALS["CLIENT"]["BROWSER"]=="konqu")	{
			$this->fontTag2='<font face="verdana,sans-serif" size=4 color=black>';
			$this->fontTag1='<font face="verdana,sans-serif" size=3 color=black>';
		}
	}


	/**
	 * Returns true if submitted password is ok. Else displays a form in which to enter password.
	 */
	function checkPassword($uKey)	{
		$p = t3lib_div::GPvar("password");

		if ($p && md5($p)==$GLOBALS["TYPO3_CONF_VARS"]["BE"]["installToolPassword"])	{
			$sKey = md5($GLOBALS["TYPO3_CONF_VARS"]["BE"]["installToolPassword"]."|".$uKey);
			SetCookie($this->cookie_name, $sKey, 0, "/");

				// Sending warning email
			$wEmail = $GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_email_addr"];
			if ($wEmail)	{
				$subject="Install Tool Login at '".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]."'";
				$email_body="There has been a Install Tool login at Typo3 site '".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]."' (".getenv("HTTP_HOST").") from remote address '".getenv("REMOTE_ADDR")."' (".getenv("REMOTE_HOST").")";
				mail($wEmail,
					$subject,
					$email_body,
					"From: Typo3 Install Tool WARNING <>"
				);
			}
			return true;
		} else {
			$this->messageFunc_nl2br=0;
			$this->silent=0;
			$content = '<form action="'.$this->action.'" method="POST">
			<input type="password" name="password"><BR>
			<input type="submit" value="Log in"><br>
			<br>
			
			'.$this->fw('The Install Tool Password is <i>not</i> the admin password of Typo3.<BR>
				If you don\'t know the current password, you can set a new one by setting the value of $TYPO3_CONF_VARS["BE"]["installToolPassword"] in typo3conf/localconf.php to the md5() hash value of the password you desire.'.
				($p?"<BR><BR>The password you just tried has this md5-value: <BR><BR>".md5($p):"")
				).'
			</form>';

			$this->message("Password", "Enter the Install Tool Password", $content,3);
			echo $this->outputWrapper($this->printAll());
				// Bad password, send warning:
			if ($p)	{
				$wEmail = $GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_email_addr"];
				if ($wEmail)	{
					$subject="Install Tool Login ATTEMPT at '".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]."'";
					$email_body="There has been a Install Tool login attempt at Typo3 site '".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]."' (".getenv("HTTP_HOST")."). 
Password tried was '".$p."'
REMOTE_ADDR was '".getenv("REMOTE_ADDR")."' (".getenv("REMOTE_HOST").")";
					mail($wEmail,
						$subject,
						$email_body,
						"From: Typo3 Install Tool WARNING <>"
					);
				}
			}

			return false;
		}
	}
	
	
	/**
	 * Calling function that checks system, IM, GD, dirs, database and lets you alter localconf.php
	 */
	function init()	{
		if (!defined("PATH_typo3"))	exit;		// Must be called after inclusion of init.php (or from init.php)
		if (!$this->passwordOK)	exit;
//		debug($GLOBALS["HTTP_COOKIE_VARS"]);
	
			// Setting stuff...
		$this->check_mail();
		$this->setupGeneral();
		$this->generateConfigForm();
		if (count($this->messages))	debug($this->messages);

		if ($this->step)	{
			echo $this->outputWrapper($this->stepOutput());
		} else {
				// Menu...
			switch($this->INSTALL["type"])	{
				case "images":
					$this->checkIM=1;
					$this->checkTheConfig();
					$this->silent=0;
					$this->checkTheImageProcessing();
				break;
				case "database":
					$this->checkTheConfig();
					$this->silent=0;
					$this->checkTheDatabase();				
				break;
				case "config":
					$this->silent=0;
					$this->checkIM=1;
					$this->message("About configuration","How to configure Typo3",$this->generallyAboutConfiguration());
					$this->checkTheConfig();
					
					$ext = "Write config to localconf.php";
					if ($this->fatalError)	{
						if ($this->config_array["no_database"] || !$this->config_array["mysqlConnect"])	{
							$this->message($ext, "Database not configured yet!", "
								You need to specify database username, password and host as one of the first things. 
								Next you'll have to select a database to use with Typo3.
								Use the form below:
							",2);
						} else {
							$this->message($ext, "Fatal error encountered!", "
								Somewhere above a fatal configuration problem is encountered. Please make sure that you've fixed this error before you submit the configuration. Typo3 will not run if this problem is not fixed!
								You should also check all warnings that may appear.
							",2);
						}
					} elseif ($this->mode=="123") {	
						if (!$this->fatalError)	{
							$this->message($ext, "Basic configuration completed", '
								You have no fatal errors in your basic configuration. You may have warnings though. Please pay attention to them! However you may continue and install the database.
	
								<B><font color=red>Step 2:</font></B> <a href="'.$this->scriptSelf.'?TYPO3_INSTALL[type]=database'.($this->mode?"&mode=".rawurlencode($this->mode):"").'">Click here to install the database.</a>
							',-1,1);
						}
					}
					$this->message($ext, "Very Important: Changing Image Processing settings", "
						When you change the settings for Image Processing you <i>must</i> take into account that <u>old images</u> may still be in typo3temp/ folder and prevent new files from being generated! This is especially important to know, if you're trying to set up image processing for the very first time.
						The problem is solved by <a href=\"".$this->setScriptName("typo3temp")."\">clearing the typo3temp/ folder</a>. Also make sure to clear the cache_pages table.
						",1,1);
					$this->message($ext, "Update localconf.php", "
						This form updates the localconf.php file with the suggested values you see below. The values are based on the analysis above.
						You can change the values in case you have alternatives to the suggested defaults.
						By this final step you will configure Typo3 for immediate use provided that you have no fatal errors left above."
						.$this->setupGeneral("get_form"),0,1);
			
					echo $this->outputWrapper($this->printAll());
			//		debug($this->config_array);
				break;
				case "extConfig":
					$this->silent=0;
					
					$this->generateConfigForm("get_form");
					
					$content = $this->printAll();
					$content = '<form action="'.$this->action.'" method="POST">'.$content.'<input type="submit" value="Write to localconf.php"><BR><BR>
					'.$this->fw("<strong>NOTICE: </strong>By clicking this button, localconf.php is updated with new values for the parameters listed above!<BR>").'
					</form>';
					echo $this->outputWrapper($content);
				break;
				case "typo3temp":
					$this->checkTheConfig();
					$this->silent=0;
					$this->typo3TempManager();			
				break;
				case "phpinfo":
					$this->silent=0;
					$this->phpinformation();			
				break;
				case "typo3conf_edit":
					$this->silent=0;
					$this->typo3conf_edit();			
				break;
				case "about":
				default:
					$this->silent=0;
					$this->message("About", "Warning - very important!", $this->securityRisk().$this->alterPasswordForm(),2);
	
					$this->message("About", "Using this script", "
					Installing Typo3 has always been a hot topic on the mailing list and forums. Therefore we've developed this tool which will help you through configuration and testing.
					There are three primary steps for you to take:
					
					<strong>1: Basic Configuration</strong>
					In this step your PHP-configuration is checked. If there are any settings that will prevent Typo3 from running correctly you'll get warnings and errors with a description of the problem.
					You'll have to enter a database username, password and hostname. Then you can choose to create a new database or select an existing one.
					Finally the image processing settings are entered and verified and you can choose to let the script update the configuration file, typo3conf/localconf.php with the suggested settings.
	
					<strong>2: Database Analyser</strong>
					In this step you can either install a new database or update the database from any previous Typo3 version. 
					You can also get an overview of extra/missing fields/tables in the database compared to a raw sql-file. 
					The database is also verified agains your 'tables.php' configuration (\$TCA) and you can even see suggestions to entries in \$TCA or new fields in the database.
					
					<strong>3: Image Processing</strong>
					This step is a visual guide to verify your configuration of the image processing software.
					You'll be presented to a list of images that should all match in pairs. If some irregularity appears, you'll get a warning. Thus you're able to track an error before you'll discover it on your website.				
	
					<strong>4: All Configuration</strong>
					This gives you access to any of the configuration options in the TYPO3_CONF_VARS array. Every option is also presented with a comment explaining what it does.
	
					<strong>5: typo3temp/</strong>
					Here you can manage the files in typo3temp/ folder in a simple manner. typo3temp/ contains temporary files, which may still be used by the website, but some may not. By searching for files with old access-dates, you can possibly manage to delete unused files rather than files still used. However if you delete a temporary file still in use, it's just regenerated as long as you make sure to clear the cache tables afterwards.
					");
	
					$this->message("About", "Why is this script stand-alone?", "
					You would think that this script should rather be a module in the backend and access-controlled to only admin-users from the database. But that's not how it works.
					The reason is, that this script must not be depending on the success of the configuration of Typo3 and whether or not there is a working database behind. Therefore the script is invoked from the backend init.php file, which allows access if the constant 'TYPO3_enterInstallScript' has been defined and is not false. That is and should be the case <i>only</i> when calling the script 'typo3/install/index.php' - this script!
					");
	
	
					$headCode="Header legend";
					$this->message($headCode, "Just information", "
					This is a simple message with some information about something.
					");
					$this->message($headCode, "Check was successful", "
					Indicates that something was checked and returned an expected result.
					",-1);
					$this->message($headCode, "Notice!", "
					Indicates that something is important to be aware of.
					This does <em>not</em> indicate an error.
					",1);
					$this->message($headCode, "Warning!", "
					Indicates that something may very well cause trouble and you should definitely look into it before proceeding.
					This indicates a <em>potential</em> error.
					",2);
					$this->message($headCode, "Error!", "
					Indicates that something is definitely wrong and that Typo3 will most likely not perform as expected if this problem is not solved.
					This indicates an actual error.
					",3);
	
					echo $this->outputWrapper($this->printAll());			
				break;
			}
		}
	}
	
	/**
	 * Controls the step 1-2-3-go process
	 */
	function stepOutput()	{
		$this->checkTheConfig();
		$error_missingConnect='<br>
			'.$this->fontTag2.'<img src="../t3lib/gfx/icon_fatalerror.gif" width=18 height=16 align=absmiddle>
			There is no connection to the database!<br>
			(Username: <i>'.TYPO3_db_username.'</i>, Password: <i>'.TYPO3_db_password.'</i>, Host: <i>'.TYPO3_db_host.'</i>).<BR>
			<br>
			<strong>Go to Step 1</strong> and enter a proper username/password!</font>
			<br>
			<br>
		';
		$error_missingDB='<br>
			'.$this->fontTag2.'<img src="../t3lib/gfx/icon_fatalerror.gif" width=18 height=16 align=absmiddle>
			There is no access to the database (<i>'.TYPO3_db.'</i>)!<br>
			<br>
			<strong>Go to Step 2</strong> and select an accessible database!</font>
			<br>
			<br>
		';

		$whichTables=$this->getListOfTables();
		$dbInfo='
					<table border=0 cellpadding=1 cellspacing=0>
					   	<tr>
					   		<td valign="top" nowrap colspan=2 align=center>'.$this->fontTag2.'<strong><img src="../t3lib/gfx/icon_note.gif" hspace=5 width=18 height=16 align=absmiddle>Database summary:</strong></font></td>
						</tr>
					   	<tr>
					   		<td valign="top" nowrap>'.$this->fontTag1.'Username:</font></td>
					   		<td valign="top" nowrap><strong>'.$this->fontTag1.''.TYPO3_db_username.'</font></strong></td>
						</tr>
					   	<tr>
					   		<td valign="top" nowrap>'.$this->fontTag1.'Password:</font></td>
					   		<td valign="top" nowrap><strong>'.$this->fontTag1.''.TYPO3_db_password.'</font></strong></td>
						</tr>
					   	<tr>
					   		<td valign="top" nowrap>'.$this->fontTag1.'Host:</font></td>
					   		<td valign="top" nowrap><strong>'.$this->fontTag1.''.TYPO3_db_host.'</font></strong></td>
						</tr>
					   	<tr>
					   		<td valign="top" nowrap>'.$this->fontTag1.'Database:</font></td>
					   		<td valign="top" nowrap><strong>'.$this->fontTag1.''.TYPO3_db.'</font></strong></td>
						</tr>
					   	<tr>
					   		<td valign="top" nowrap>'.$this->fontTag1.'# of tables:</font></td>
					   		<td valign="top" nowrap><strong>'.$this->fontTag1.''.(count($whichTables)?'<font color=red>'.count($whichTables).'</font>':count($whichTables)).'</font></strong></td>
						</tr>
					</table>
		';
		$error_emptyDB='<br>
			'.$this->fontTag2.'<img src="../t3lib/gfx/icon_fatalerror.gif" width=18 height=16 align=absmiddle>
			The database is still empty. There are no tables!<br>
			<br>
			<strong>Go to Step 3</strong> and import a database!</font>
			<br>
			<br>
		';

		switch(strtolower($this->step))	{
			case 1:
				$msg='
<br>
<br>
					<table border=0>
					   <form action="'.$this->action.'" method="POST">
					   	<tr>
					   		<td valign="top" nowrap><strong>   		   
					   		   '.$this->fontTag2.'Username:</font></strong>
					   		</td>
					   		<td>	&nbsp;
					   		</td>
					   		<td valign="top">   		   
					   		   '.$this->fontTag2.'
					   		   <input type="text" name="TYPO3_INSTALL[localconf.php][typo_db_username]" value="'.TYPO3_db_username.'"></font><BR>
					   		</td>
					   	</tr>
					   	<tr>
					   		<td valign="top" nowrap><strong>   		   
					   		   '.$this->fontTag2.'Password:</font></strong>
					   		</td>
					   		<td>	&nbsp;
					   		</td>
					   		<td valign="top">   		   
					   		   '.$this->fontTag2.'
					   		   <input type="text" name="TYPO3_INSTALL[localconf.php][typo_db_password]" value="'.TYPO3_db_password.'"></font><BR>
					   		</td>
					   	</tr>
					   	<tr>
					   		<td valign="top" nowrap><strong>   		   
					   		   '.$this->fontTag2.'Host:</font></strong>
					   		</td>
					   		<td>	&nbsp;
					   		</td>
					   		<td valign="top">   		   
					   		   '.$this->fontTag2.'
					   		   <input type="text" name="TYPO3_INSTALL[localconf.php][typo_db_host]" value="'.(TYPO3_db_host?TYPO3_db_host:'localhost').'"></font><BR>
					   		</td>
					   	</tr>
					   	<tr>
					   		<td valign="top" nowrap><strong>   		   
					   		   '.$this->fontTag1.'</font></strong>
					   		</td>
					   		<td>	&nbsp;
					   		</td>
					   		<td valign="top">   		   
					   		   '.$this->fontTag1.'<BR>
							   <input type="hidden" name="step" value="2">
					   		   <input type="submit" value="Update localconf.php"><BR><br/><strong>NOTICE: </strong>By clicking this button, typo3conf/localconf.php is updated with new values for the parameters listed above!</font><BR>
					   		</td>
					   	</tr>
					   </form>
					</table>      				
<br>
<br>
				';
			break;
			case 2:
				if ($result = @mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
					$dbArr = $this->getDatabaseList();
					reset($dbArr);
					$options="";
					$dbIncluded=0;
					while(list(,$dbname)=each($dbArr))	{
						$options.='<option value="'.htmlspecialchars($dbname).'"'.($dbname==TYPO3_db?' selected':'').'>'.htmlspecialchars($dbname).'</option>';
						if ($dbname==TYPO3_db)	$dbIncluded=1;
					}
					if (!$dbIncluded && TYPO3_db)	{
						$options.='<option value="'.htmlspecialchars(TYPO3_db).'" selected>'.htmlspecialchars(TYPO3_db).' (NO ACCESS!)</option>';
					}
					$select='<select name="TYPO3_INSTALL[localconf.php][typo_db]">'.$options.'</select>';
					$msg='
<br>
<br>
					<table border=0>
					   <form action="'.$this->action.'" method="POST">
					   	<tr>
					   		<td valign="top" nowrap><strong>   		   
					   		   '.$this->fontTag2.'
							   You have two options:<br>
							   <br><br>
							   
							   1: Select an existing <u>EMPTY</u> database:</font></strong>
					   		</td>
						</tr>
						<tr>
					   		<td valign="top">   		   
					   		   '.$this->fontTag1.'Any existing tables which are used by Typo3 will be overwritten in Step 3. So make sure this database is empty:<BR>'.$select.'</font><BR>
					   		</td>
					   	</tr>
					   	<tr>
					   		<td valign="top" nowrap><br>
							<br>
<strong>   		   
					   		   '.$this->fontTag2.'2: Create new database (recommended):</font></strong>
					   		</td>
						</tr>
						<tr>
					   		<td valign="top">   		   
					   		   '.$this->fontTag1.'Enter the desired name of the database here:<BR><input type="text" name="TYPO3_INSTALL[localconf.php][NEW_DATABASE_NAME]" value=""></font><BR>
					   		</td>
					   	</tr>
					   	<tr>
					   		<td valign="top">   		   <br>
							
					   		   '.$this->fontTag1.'<BR>
							   <input type="hidden" name="step" value="3">
					   		   <input type="submit" value="Update localconf.php"><BR><br/><strong>NOTICE: </strong>By clicking this button, typo3conf/localconf.php is updated with new values for the parameters listed above!</font><BR>
					   		</td>
					   	</tr>
					   </form>
					</table>      				
<br>
<br>
				';
				} else {
					$msg=$error_missingConnect;
				}
			break;
			case 3:
				if ($result = @mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
					if (mysql_select_db(TYPO3_db))	{
						$sqlfile='/www/htdocs/typo3/32/testsite/typo3conf/t32_testsite-32a1.sql';
						$sFiles = t3lib_div::getFilesInDir(PATH_typo3conf,"sql",1,1);
						reset($sFiles);
						$opt="";
						while(list(,$f)=each($sFiles))	{
							$opt.='<option value="import|'.htmlspecialchars($f).'">'.htmlspecialchars(basename($f)).'</option>';
						}
						
						
						$content='
							'.$this->fontTag2.'Databases in typo3conf/ directory:</font><BR>
							<input type="hidden" name="TYPO3_INSTALL[database_import_all]" value=1>
						   <input type="hidden" name="step" value="">
						   <input type="hidden" name="goto_step" value="go">
							<select name="TYPO3_INSTALL[database_type]">'.$opt.'</select><BR>';

						$content = $this->getUpdateDbFormWrap("import", $content, "Import database");

						$msg='
						<br>
						'.$dbInfo.'<br>
						<br>
						'.$content.'

						';
						
					} else {
						$msg=$error_missingDB;
					}
				} else {
					$msg=$error_missingConnect;
				}
			break;
			case "go":
				if ($result = @mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
					if (mysql_select_db(TYPO3_db))	{
						if (count($whichTables))	{
							$msg='
							<br>
							'.$this->fontTag2.'
							'.nl2br($this->messageBasicFinished()).'
							<br>
							<hr>
							<div align="center"><strong><img src="../t3lib/gfx/icon_warning.gif" hspace=5 width=18 height=16 align=absmiddle>IMPORTANT</strong></div><br>
							<font size=1>'.nl2br($this->securityRisk()).'
							<br>
							<strong>Enter <a href="'.$this->scriptSelf.'">"Normal" mode for the Install Tool</a> to change this!</strong><br>
														
							</font>
							</font><BR>
							';
						} else {
							$msg=$error_emptyDB;
						}
					} else {
						$msg=$error_missingDB;
					}
				} else {
					$msg=$error_missingConnect;
				}
			break;
			default:
			break;
		}
		return $msg;
	}

	/**
	 * Calling the functions that checks the system
	 */
	function checkTheConfig()	{
			// Order important:	
		$this->checkDirs();
		$this->checkConfiguration();
		$this->checkExtensions();

		if (TYPO3_OS=="WIN")	{
			$paths=array($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"], $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path"], "c:\\php\\imagemagick\\");
		} else {
			$paths=array($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"], $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path"], "/usr/local/bin/","/usr/bin/","/usr/X11R6/bin/");
		}
		
		asort($paths);
		if (ini_get("safe_mode"))	{
			$paths=array(ini_get("safe_mode_exec_dir"),"/usr/local/php/bin/");
		}
		if ($this->INSTALL["checkIM"]["lzw"])	{
			$this->checkIMlzw=1;
		}
		if ($this->INSTALL["checkIM"]["path"])	{
			$paths[]=trim(stripslashes($this->INSTALL["checkIM"]["path"]));
		}
		if ($this->checkIM)	$this->checkImageMagick($paths);
		$this->checkDatabase();
	}
	
	function typo3conf_edit()	{
		
		$EDIT_path = PATH_typo3conf;	// default:
		if ($this->allowFileEditOutsite_typo3conf_dir && $this->INSTALL["FILE"]["EDIT_path"])	{
			if (!strstr($this->INSTALL["FILE"]["EDIT_path"],"..") && substr($this->INSTALL["FILE"]["EDIT_path"],-1)=="/")	{
				$tmp_path = PATH_site.$this->INSTALL["FILE"]["EDIT_path"];
				if (is_dir($tmp_path))	{
					$EDIT_path=$tmp_path;
				} else {debug("'".$tmp_path."' was not dir");}
			} else {
				debug("BAD DIR_NAME (must be like t3lib/ or media/script/)");
			}
		}
		
		$headCode = "Edit files in ".basename($EDIT_path)."/";
		$this->contentBeforeTable="";
		
		if ($this->INSTALL["SAVE_FILE"])	{
			$save_to_file = $this->INSTALL["FILE"]["name"];
			if (@is_file($save_to_file))	{
				$save_to_file_md5 = md5($save_to_file);
				if (isset($this->INSTALL["FILE"][$save_to_file_md5]) && t3lib_div::isFirstPartOfStr($save_to_file,$EDIT_path."") && substr($save_to_file,-1)!="~")	{
					$this->INSTALL["typo3conf_files"] = $save_to_file;
					$save_fileContent = stripslashes($this->INSTALL["FILE"][$save_to_file_md5]);

					if ($this->INSTALL["FILE"]["win_to_unix_br"])	{
						$save_fileContent = str_replace(chr(13).chr(10),chr(10),$save_fileContent);
					}
					if ($this->INSTALL["FILE"]["backup"])	{
						if (@is_file($save_to_file."~"))	unlink($save_to_file."~");
						rename($save_to_file,$save_to_file."~");
						$this->contentBeforeTable.='Backup written to <strong>'.$save_to_file.'~</strong><BR>';
					} else {
						if (@is_file($save_to_file."~"))	{
							unlink($save_to_file."~");
							$this->contentBeforeTable.='Backup REMOVED! (<strong>'.$save_to_file.'~</strong>)<BR>';
						}
					}

					t3lib_div::writeFile($save_to_file,$save_fileContent);
					$this->contentBeforeTable.='
						File saved: <strong>'.$save_to_file.'</strong><BR>
						MD5-sum: '.$this->INSTALL["FILE"]["prevMD5"].' (prev)<BR>
						MD5-sum: '.md5($save_fileContent).' (new)<BR>
					';
				}
			}
		}
		
		
			// Filelist:
		$typo3conf_files = t3lib_div::getFilesInDir($EDIT_path,"",1,1);
		reset($typo3conf_files);
		$lines=array();
		$fileFound = 0;
		while(list($k,$file)=each($typo3conf_files))	{
			if ($this->INSTALL["typo3conf_files"] && !strcmp($this->INSTALL["typo3conf_files"],$file))	{
				$wrap=array('<strong><font color=navy>','</font></strong>');
				$fileFound = 1;
			} else {$wrap=array();}
			$lines[]='<tr><td nowrap><a href="'.$this->action.'&TYPO3_INSTALL[typo3conf_files]='.rawurlencode($file).($this->allowFileEditOutsite_typo3conf_dir?'&TYPO3_INSTALL[FILE][EDIT_path]='.rawurlencode($this->INSTALL["FILE"]["EDIT_path"]):"").'">'.$this->fw($wrap[0].basename($file).$wrap[1]."&nbsp;&nbsp;&nbsp;").'</a></td><td>'.$this->fw(t3lib_div::formatSize(filesize($file))).'</td></tr>';
		}
		$fileList='<table border=0 cellpadding=0 cellspacing=0>'.implode("",$lines).'</table>';
		$fileList.="<BR>(".$EDIT_path.")";
		
		if ($this->allowFileEditOutsite_typo3conf_dir)	{
			$fileList.='<BR><form action="'.$this->action.'" method="POST">
			'.PATH_site.'<input type="text" name="TYPO3_INSTALL[FILE][EDIT_path]" value="'.$this->INSTALL["FILE"]["EDIT_path"].'"><input type="submit" name="" value="Set">
			</form>';
		}

		if ($fileFound && @is_file($this->INSTALL["typo3conf_files"]))	{
			$this->headerStyle = '
			<style type="text/css"><!--
				SELECT {font-family: Verdana,Arial,Helvetica,Sans-serif; font-size: 10px;}
				TEXTAREA  {font-family: Verdana,Arial,Helvetica,Sans-serif; font-size: 10px;} 
				INPUT {font-family: Verdana,Arial,Helvetica,Sans-serif; font-size: 10px;}
			//--></style>
			';

			$fileContent = t3lib_div::getUrl($this->INSTALL["typo3conf_files"]);
			$this->contentBeforeTable.= '<form action="'.$this->action.'" method="POST">
				'.(substr($this->INSTALL["typo3conf_files"],-1)!="~"?'<input type="submit" name="TYPO3_INSTALL[SAVE_FILE]" value="Save file">&nbsp;':'').'<input type="submit" name="_close" value="Close">
				<BR>File: '.$this->INSTALL["typo3conf_files"].'
				<BR>MD5-sum: '.md5($fileContent).'
				<BR>
				
				<input type="hidden" name="TYPO3_INSTALL[FILE][name]" value="'.$this->INSTALL["typo3conf_files"].'">
				'.($this->allowFileEditOutsite_typo3conf_dir?'<input type="hidden" name="TYPO3_INSTALL[FILE][EDIT_path]" value="'.$this->INSTALL["FILE"]["EDIT_path"].'">':'').'
				<input type="hidden" name="TYPO3_INSTALL[FILE][prevMD5]" value="'.md5($fileContent).'">
				<textarea rows="30" name="TYPO3_INSTALL[FILE]['.md5($this->INSTALL["typo3conf_files"]).']" wrap="off"'.$this->formWidthText(48,"width:98%;height:80%").'>'.t3lib_div::formatForTextarea($fileContent).'</textarea><BR>
				<input type="checkbox" name="TYPO3_INSTALL[FILE][win_to_unix_br]" value="1"'.(TYPO3_OS=="WIN"?"":" CHECKED").'> Convert windows linebreaks (13-10) to unix (10)<BR>
				<input type="checkbox" name="TYPO3_INSTALL[FILE][backup]" value="1"'.(@is_file($this->INSTALL["typo3conf_files"]."~") ? " CHECKED":"").'> Make backup copy (else remove any backup copy, prepended by "~")<BR>
				'.
			'</form>';
		}
		
		if ($this->contentBeforeTable)	{
			$this->contentBeforeTable = $this->fw($this->contentBeforeTable);
		}

		$this->message($headCode,"Files in folder",$fileList);
	
		echo $this->outputWrapper($this->printAll());			
	}
	function phpinformation()	{
		$headCode = "PHP information";

		$getEnvArray = array();
		$gE_keys = explode(",","QUERY_STRING,HTTP_ACCEPT,HTTP_ACCEPT_ENCODING,HTTP_ACCEPT_LANGUAGE,HTTP_CONNECTION,HTTP_COOKIE,HTTP_HOST,HTTP_USER_AGENT,REMOTE_ADDR,REMOTE_HOST,REMOTE_PORT,SERVER_ADDR,SERVER_ADMIN,SERVER_NAME,SERVER_PORT,SERVER_SIGNATURE,SERVER_SOFTWARE,GATEWAY_INTERFACE,SERVER_PROTOCOL,REQUEST_METHOD,SCRIPT_NAME,PATH_TRANSLATED,HTTP_REFERER,PATH_INFO");
		while(list(,$k)=each($gE_keys))	{
			$getEnvArray[$k] = getenv($k);
		}
		$this->message($headCode,"getenv()",t3lib_div::view_array($getEnvArray));

		$this->message($headCode,"HTTP_ENV_VARS",t3lib_div::view_array($GLOBALS["HTTP_ENV_VARS"]));
		$this->message($headCode,"HTTP_SERVER_VARS",t3lib_div::view_array($GLOBALS["HTTP_SERVER_VARS"]));
		$this->message($headCode,"HTTP_COOKIE_VARS",t3lib_div::view_array($GLOBALS["HTTP_COOKIE_VARS"]));
		$this->message($headCode,"HTTP_GET_VARS",t3lib_div::view_array($GLOBALS["HTTP_GET_VARS"]));

		ob_start();
		phpinfo();
		$contents = explode("<body>",ob_get_contents());
		ob_end_clean();
		$contents = explode("</body>",$contents[1]);

		$this->message($headCode,"phpinfo()",$contents[0]);


		
$this->headerStyle = '
<style type="text/css"><!--
a { text-decoration: none; }
a:hover { text-decoration: underline; }
h1 { font-family: verdana,arial, helvetica, sans-serif; font-size: 14pt; font-weight: bold;}
h2 { font-family: verdana,arial, helvetica, sans-serif; font-size: 12pt; font-weight: bold;}
body, td { font-family: verdana,arial, helvetica, sans-serif; font-size: 10pt; }
th { font-family: verdana,arial, helvetica, sans-serif; font-size: 10pt; font-weight: bold; }
//--></style>
';
		
		echo $this->outputWrapper($this->printAll());			
	}	
	
	// *******************************
	// typo3temp/ manager
	// *******************************
	
	function typo3TempManager()	{
		$headCode = "typo3temp/ directory";
		$this->message($headCode,"What is it?","
		Typo3 uses this directory for temporary files, mainly processed and cached images.
		The filenames are very cryptic; They are unique representations of the file properties made by md5-hashing a serialized array with information.
		Anyway this directory may contain many thousand files and a lot of them may be of no use anymore.
		
		With this test you can delete the files in this folder. When you do that, you should also clear the cache database tables afterwards.
		");
	
		if (!$this->config_array["dir_typo3temp"])	{
			$this->message("typo3temp/ directory","typo3temp/ not writeable!","
				You must make typo3temp/ write enabled before you can proceed with this test.
			",2);
			echo $this->outputWrapper($this->printAll());
			return;
		}

			// Run through files 
		$fileCounter=0;
		$deleteCounter=0;
		$criteriaMatch=0;
		$tmap=array("day"=>1,"week"=>7,"month"=>30);
		$tt=$this->INSTALL["typo3temp_delete"];
		$action=$this->INSTALL["typo3temp_action"];
		$d = @dir($this->typo3temp_path);
		if (is_object($d))	{
			while($entry=$d->read()) {
				$theFile = $this->typo3temp_path.$entry;
				if (@is_file($theFile))	{	
					$ok=0;
					$fileCounter++;
					if ($tt)	{
						if (t3lib_div::testInt($tt))	{
							if (filesize($theFile) > $tt*1024)	$ok=1;
						} else {
							if (fileatime($theFile) < time()-(intval($tmap[$tt])*60*60*24))	$ok=1;
						}
					} else {
						$ok=1;
					}
					if ($ok)	{
						$hashPart=substr(basename($theFile),-14,10);
						if (!ereg("[^a-f0-9]",$hashPart))	{		// This is a kind of check that the file being deleted has a 10 char hash in it
							if ($action && $deleteCounter<$action)	{
								$deleteCounter++;
								unlink($theFile);
							} else {
								$criteriaMatch++;
							}
						}
					}
				}
			}
			$d->close();
		}

		
		$deleteType=array(
			"0" => "All",
			"day" => "Last access more than a day ago",
			"week" => "Last access more than a week ago",
			"month" => "Last access more than a month ago",
			"10" => "Filesize greater than 10 kb",
			"50" => "Filesize greater than 50 kb",
			"100" => "Filesize greater than 100 kb"
		);
		$actionType=array(
			"0" => "Don't delete, just display statistics",
			"100" => "Delete 100",
			"500" => "Delete 500",
			"1000" => "Delete 1000"
		);
		$content='<select name="TYPO3_INSTALL[typo3temp_delete]">'.$this->getSelectorOptions($deleteType,$tt).'</select>
		<br>
Number of files at a time:
		<select name="TYPO3_INSTALL[typo3temp_action]">'.$this->getSelectorOptions($actionType).'</select>';

		$form = '<form action="'.$this->action.'" method="POST">'.$content.'
		
		<input type="submit" value="Execute">
		</form>
		This tool will delete files only if the last 10 characters before the extension (3 chars+\'.\') are hexadecimal valid ciphers, which are lowercase a-f and 0-9.';
	
		$this->message($headCode,"Statestics","
		Number of temporary files: <strong>".($fileCounter-$deleteCounter)."</strong>
		Number matching '".htmlspecialchars($deleteType[$tt])."': <strong>".$criteriaMatch."</strong>
		Number deleted: <strong>".$deleteCounter."</strong>
		<BR>
		".$form,1);
	
		echo $this->outputWrapper($this->printAll());			
	}




	function getSelectorOptions($deleteType,$tt="")	{
		$out="";
		if (is_array($deleteType))	{
			reset($deleteType);
			while(list($v,$l)=each($deleteType))	{
				$out.='<option value="'.htmlspecialchars($v).'"'.(!strcmp($v,$tt)?" selected":"").'>'.htmlspecialchars($l).'</option>';
			}
		}
		return $out;
	}
	
	
	// *******************************
	// CONFIGURATION FORM
	// *******************************
	function generateConfigForm($type="")	{
		switch($type)	{
			case "get_form":
				$default_config_content = t3lib_div::getUrl(PATH_t3lib."config_default.php");
				$commentArr = $this->getDefaultConfigArrayComments($default_config_content);
/*			
				$localconf_content = t3lib_div::getUrl(PATH_typo3conf."localconf.php");
				$commentArr2 = $this->getConfigArrayComments($localconf_content);
				debug($commentArr2);
*/				
				reset($GLOBALS["TYPO3_CONF_VARS"]);
				$this->messageFunc_nl2br=0;
				while(list($k,$va)=each($GLOBALS["TYPO3_CONF_VARS"]))	{
					$ext="[".$k."]";
					$this->message($ext, '$TYPO3_CONF_VARS["'.$k.'"]',$commentArr[0][$k],1);
					while(list($vk,$value)=each($va))	{
						if (!is_array($value) && $this->checkForBadString($value))	{
							$k2="[".$vk."]";
							$description = trim($commentArr[1][$k][$vk]);
							$msg=$description."<BR><BR><em>".$ext.$k2." = ".htmlspecialchars($value)."</em><BR>";
							
							if (strstr($value,chr(10)))	{
										// Never used at this point:
								$form='<textarea name="TYPO3_INSTALL[extConfig]['.$k.']['.$vk.']" cols=40 rows=5 wrap="off">'.htmlspecialchars($value).'</textarea>';
							} elseif (eregi("^boolean",$description)) {
								$form='<input type="hidden" name="TYPO3_INSTALL[extConfig]['.$k.']['.$vk.']" value="0">';
								$form.='<input type="checkbox" name="TYPO3_INSTALL[extConfig]['.$k.']['.$vk.']"'.($value?" checked":"").' value="'.($value&&strcmp($value,"0")?htmlspecialchars($value):1).'">';
							} else {
								$form='<input type="text" size=40 name="TYPO3_INSTALL[extConfig]['.$k.']['.$vk.']" value="'.htmlspecialchars($value).'">';
							}
							$this->message($ext, $k2,$msg.$form);
						}
					}
				}
			break;
			default:
//				debug($this->INSTALL["extConfigs"]);
				if (is_array($this->INSTALL["extConfig"]))		{
					reset($this->INSTALL["extConfig"]);
					$lines = $this->writeToLocalconf_control();
					while(list($k,$va)=each($this->INSTALL["extConfig"]))	{
						if (is_array($GLOBALS["TYPO3_CONF_VARS"][$k]))	{
							while(list($vk,$value)=each($va))	{
								if (isset($GLOBALS["TYPO3_CONF_VARS"][$k][$vk]))	{
									$doit=1;
									if ($k=="BE" && $vk=="installToolPassword")	{
										if (t3lib_div::GPvar("installToolPassword_check") && strcmp(t3lib_div::GPvar("installToolPassword_check"),$value))	$doit=0;
										if (t3lib_div::GPvar("installToolPassword_md5"))	$value =md5($value);
									}
									if ($doit && strcmp($GLOBALS["TYPO3_CONF_VARS"][$k][$vk],stripslashes($value)))	$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["'.$k.'"]["'.$vk.'"]', $value);
								}
							}
						}
					}
					$this->writeToLocalconf_control($lines);
				}
			break;
		}
	}
	function getDefaultConfigArrayComments($string,$mainArray=array(),$commentArray=array())	{
		$lines = explode(chr(10),$string);
		$in=0;
		$mainKey="";
		while(list(,$lc)=each($lines))	{
			$lc = trim($lc);
			if ($in) {
				if (!strcmp($lc,");"))	{
					$in=0;
				} else {
					if (eregi('"([[:alnum:]_-]*)"[[:space:]]*=>(.*)',$lc,$reg))	{
						list(,$theComment)=explode("//",$reg[2],2);
						if (substr(strtolower(trim($reg[2])),0,5)=="array" && !strcmp($reg[1],strtoupper($reg[1])))	{
							$mainKey=trim($reg[1]);
							$mainArray[$mainKey]=trim($theComment);
						} elseif ($mainKey) {
							$commentArray[$mainKey][$reg[1]]=trim($theComment);
						}
					} else {
						//debug($lc,1);
					}
				}
			}
			if (!strcmp($lc,'$TYPO3_CONF_VARS = Array('))	{
				$in=1;
			}
		}
		return array($mainArray,$commentArray);
	}
	
	// *******************************
	// CHECK CONFIGURATION FUNCTIONS
	// *******************************

	
	
	/**
	 * Checking php.ini configuration and set appropriate messages and flags.
	 */
	function checkConfiguration()	{
		$ext="php.ini configuration checked";
		$this->message($ext);

			// *****************
			// Incoming values:
			// *****************
		if (!get_cfg_var("track_vars"))	{
			$this->message($ext, "Tracking Vars not set","
				<i>track_vars=".get_cfg_var("track_vars")."</i>
				Tracking vars are essential for almost any PHP-application. 
				The fact that the value is not set may not impose a problem, because it's always set in version 4.03+ of PHP.
			",1);
		} else $this->message($ext, "Tracking Vars enabled","",-1);
		if (!ini_get("register_globals"))	{
			$this->message($ext, "Register globals disabled","
				<i>register_globals=".ini_get("register_globals")."</i>
				Incoming values by GET or POST method are not registered as globals. Typo3 is designed to cope with that - actually we encourage that setting - but you should be aware if your included PHP-scripts (or TypoScript configurations) are compatible with this setting.
				You should always use the function t3lib_div::GPvar(\"<i>[the_var_name_from_GET_or_POST]</i>\") to retrieve values passed to your script from outside.
			",1);
		} else $this->message($ext, "Register globals enabled","You should always use the function t3lib_div::GPvar(\"<i>[the_var_name_from_GET_or_POST]</i>\") to retrieve values passed to your script from outside.",1);
		if (!ini_get("magic_quotes_gpc"))	{
			$this->message($ext, "magic_quotes_gpc","
				<i>magic_quotes_gpc=".ini_get("magic_quotes_gpc")."</i>
				Incoming \" and ' chars in values by GET or POST method are currently <i>not</i> escaped. Typo3 is designed to cope with that but it may be on the expense of a minor performance loss, because all incoming values are addslashes()'ed.
			",1);
		} else $this->message($ext, "magic_quotes_gpc","<i>magic_quotes_gpc=".ini_get("magic_quotes_gpc")."</i>",-1);
		if (ini_get("magic_quotes_runtime"))	{
			$this->message($ext, "Magic Quotes Runtime is enabled","
				<i>magic_quotes_runtime=".ini_get("magic_quotes_runtime")."</i>
				Typo3 is depending on this option NOT being enabled! 
			",3);
		} else $this->message($ext, "magic_quotes_runtime","<i>magic_quotes_runtime=".ini_get("magic_quotes_runtime")."</i>",-1);
		if (ini_get("gpc_order")!="GPC")	{
			$this->message($ext, "GPC order non-standard","
				<i>gpc_order=".ini_get("gpc_order")."</i>
				The order of GET, POST and COOKIE vars are non-standard. The value should be \"GPC\".
			",2);
		} else $this->message($ext, "GPC order","",-1);

			// *****************
			// File uploads
			// *****************
		if (!ini_get("file_uploads"))	{
			$this->message($ext, "File uploads not allowed","
				<i>file_uploads=".ini_get("file_uploads")."</i>
				Typo3 uses the ability to upload files from the browser in various cases.
				As long as this flag is disabled, you'll not be able to upload files.
			",2);
		} else $this->message($ext, "File uploads allowed","",-1);
		$upload_max_filesize = $this->convertByteSize(ini_get("upload_max_filesize"));
		if ($upload_max_filesize<10000*1024)	{
			$this->message($ext, "Max Upload filesize too small?","
				<i>upload_max_filesize=".ini_get("upload_max_filesize")."</i>
				By default Typo3 supports uploading, copying and moving files of sizes up to 10000 kb (10 MB) (You can alter the Typo3 defaults by the config option TYPO3_CONF_VARS[BE][maxFileSize]).
				Your current value is below this, so at this point, PHP sets the limits for uploaded filesizes and not Typo3. 
				<strong>Notice:</strong> The limits for filesizes attached to database records are set in the tables.php configuration file (\$TCA) for each group/file field.
			",1);
		}

			// *****************
			// Memory and functions
			// *****************
		$memory_limit_value = $this->convertByteSize(get_cfg_var("memory_limit"));
		if ($memory_limit_value<8*1024*1024)	{
			$this->message($ext, "Memory Limit below default 8 MB","
				<i>memory_limit=".get_cfg_var("memory_limit")."</i>
				May impose problems if too low.
			",1);
		} else $this->message($ext, "Memory Limit","<i>memory_limit=".get_cfg_var("memory_limit")."</i>",-1);
		if (ini_get("max_execution_time")<30)	{
			$this->message($ext, "Max Execution Time below default 30 seconds","
				<i>max_execution_time=".ini_get("max_execution_time")."</i>
				May impose problems if too low.
			",1);
		} else $this->message($ext, "Max Execution Time","<i>max_execution_time=".ini_get("max_execution_time")."</i>",-1);
		if (ini_get("disable_functions"))	{
			$this->message($ext, "Functions disabled!","
				<i>disable_functions=".ini_get("disable_functions")."</i>
				The above list of functions are disabled. If Typo3 use any of these there might be trouble.
				Typo3 is designed to use the default set of PHP4.0.3+ functions plus the functions from GDLib. 
				Possibly these functions are disabled due to security risks and most likely the list would include a function like <i>exec()</i> which is use by Typo3 to access ImageMagick.
			",2);
		} else $this->message($ext, "Functions disabled: none","",-1);
		if (!ini_get("sendmail_path"))	{
			$this->message($ext, "Sendmail path not defined!","
				<i>sendmail_path=".ini_get("sendmail_path")."</i>
				This may be critical to Typo3's use of the mail() function. Please be sure that the mail() function in your php-installation works!
			".$this->check_mail("get_form"),1);
		} else {
			list($prg) = explode(" ",ini_get("sendmail_path"));
			if (!@is_executable($prg))	{
				$this->message($ext, "Sendmail program not found or not executable?","
					<i>sendmail_path=".ini_get("sendmail_path")."</i>
					This may be critical to Typo3's use of the mail() function. Please be sure that the mail() function in your php-installation works!
				".$this->check_mail("get_form"),1);
			} else {
				$this->message($ext, "Sendmail OK","
					<i>sendmail_path=".ini_get("sendmail_path")."</i>
					You may check the mail() function by entering your emailaddress here:
				".$this->check_mail("get_form"),-1);
			}
		}
		
			// *****************
			// Safe mode related
			// *****************
		if (ini_get("safe_mode"))	{
			$this->message($ext, "Safe mode turned on","
				<i>safe_mode=".ini_get("safe_mode")."</i>
				In safe_mode PHP is restricted in several ways. This is a good thing because it adds protection to your (and others) scripts. But it may also introduce problems. In Typo3 this <em>may be</em> a problem in two areas: File administration and execution of external programs, in particular ImageMagick.
				If you just ignore this warning, you'll most likely find, that Typo3 seems to work except from the image-generation. The problem in that case is that the external ImageMagick programs are not allowed to be executed from the regular paths like \"/usr/bin/\" or \"/usr/X11R6/bin/\".
				If you use safe_mode with Typo3, you should disable use of external programs ([BE][disable_exec_function]=1).
				In safe mode you must ensure that all the php-scripts and upload folders are owned by the same user.
				For general information about safe-mode restrictions, refer to this website: ".$this->linkIt("http://www.wrox.com/Consumer/Store/Books/2963/29632002.htm")."

					<i>safe_mode_exec_dir=".ini_get("safe_mode_exec_dir")."</i>
					If the ImageMagick utilities are located in this directory, everything is fine. Below on this page, you can see if ImageMagick is found here. If not, ask you ISP to put the three ImageMagick programs, 'convert', 'combine'/'composite' and 'identify' there (eg. with symlinks if Unix server)
					

					<strong>Example of safe_mode settings:</strong>
					Set this in the php.ini file:

					; Safe Mode
					safe_mode               =       On
					safe_mode_exec_dir      = /usr/bin/

					...and the ImageMagick '/usr/bin/convert' will be executable.
					The last slash is important (..../) and you can only specify one directory.

					<strong>Notice: </strong>
					ImageMagick 4.2.9 is recommended and the binaries are normally installed by RPM in /usr/X11R6/bin or by compiling in /usr/local/bin. Please look in the \"Inside Typo3\" pdf-document for extensive information about ImageMagick issues.
					Paths to ImageMagick are defined in localconf.php and may be something else than /usr/bin/, but this is default for ImageMagick 5+
					
			
			",2);
			if (ini_get("doc_root"))	{
				$this->message($ext, "doc_root set","
					<i>doc_root=".ini_get("doc_root")."</i>
					PHP cannot execute scripts outside this directory. If that is a problem is please correct it.
				",1);
			}
			$this->config_array["safemode"]=1;
		} else $this->message($ext, "safe_mode: off","",-1);
		if (ini_get("sql.safe_mode"))	{
			$this->message($ext, "sql.safe_mode is enabled","
				<i>sql.safe_mode=".ini_get("sql.safe_mode")."</i>
				This means that you can only connect to the database with a username corresponding to the user of the webserver process or fileowner. Consult your ISP for information about this. Also see ".$this->linkIt("http://www.wrox.com/Consumer/Store/Books/2963/29632002.htm")."
				The owner of the current file is: <strong>".get_current_user ()."</strong>
			",1);
			$this->config_array["sql.safe_mode_user"] = get_current_user();
		} else $this->message($ext, "sql.safe_mode: off","",-1);
		if (ini_get("open_basedir"))	{
			$this->message($ext, "open_basedir set","
				<i>open_basedir=".ini_get("open_basedir")."</i>
				This restricts Typo3 to open and include files only in this path. Please make sure that this does not prevent Typo3 from running.
				<strong>Notice (UNIX):</strong> Before checking a path according to open_basedir, PHP resolves all symbolic links.
			",1);
//	????			If this option was set falsely you probably didn't see this page in the first place, but this option <B>may spoil this configuration test</B> when checking for such as ImageMagick executables.
		} else $this->message($ext, "open_basedir: off","",-1);
	
	}

	/**
	 * Check if php function mail() works
	 *
	 * @param	string	$cmd	If "get_form" then a formfield for the mail-address is shown. If not, it's checked if "check_mail" was in the INSTALL array and if so a test mail is sent to the recipient given.
	 */
	function check_mail($cmd="")	{
		switch($cmd)	{
			case "get_form":
				$out='
				You can check the mail() function by entering your email address here and press the button. You should then receive a testmail from test@test.test.
				<form action="'.$this->action.'" method="POST"><input type="text" name="TYPO3_INSTALL[check_mail]">
					<input type="submit" value="Send test mail"></form>';
			break;
			default:
				if (trim($this->INSTALL["check_mail"]))	{
					mail(trim($this->INSTALL["check_mail"]), "TEST SUBJECT", "TEST CONTENT", "From: test@test.test");
					$this->messages[]= "MAIL WAS SENT TO: ".$this->INSTALL["check_mail"];
				}
			break;
		}
		return $out;
	}

	/**
	 * Checking php extensions, specifically GDLib and Freetype
	 */
	function checkExtensions()	{
		$ext = "GDLib";
		$this->message($ext);

		$software_info=1;
		if (extension_loaded("gd") && $this->isGD())	{
			$this->config_array["gd"]=1;
			$this->message($ext, "GDLib found","",-1);
			if (ImageTypes() & IMG_PNG) {
				$this->config_array["gd_png"]=1;
				$this->message($ext, "PNG supported","",-1);
			}
			if ($this->isGIF()) {
				$this->config_array["gd_gif"]=1;
				$this->message($ext, "GIF supported","",-1);
			}
			if (ImageTypes() & IMG_JPG) {
				$this->config_array["gd_jpg"]=1;
				$this->message($ext, "JPG supported (not used by Typo3)","");
			}
			if (!$this->config_array["gd_gif"] && !$this->config_array["gd_png"])	{
				$this->message($ext, "PNG or GIF not supported", nl2br(trim("
					Your GDLib supports either GIF nor PNG. It must support either one of them.
				")), 2);
			} else {
				$msg=array();
				if ($this->config_array["gd_gif"] && $this->config_array["gd_png"])		{
					$msg[0]="You can choose between generating GIF or PNG files, as your GDLib supports both.";
				}
				if ($this->config_array["gd_gif"])		{
					$msg[10]="You should know that generating GIF files are covered by a UNISYS patent. <a target=\"_blank\" href=\"http://www.boutell.com/gd/\">Read more for details.</a>";
					$msg[11]="In addition you should watch out for the generated size of the GIF-files because GDLib does not compress them with LZW, but RLE and ImageMagick is subsequently used to compress with LZW. But in the case of ImageMagick failing this task (eg. not being compiled with LZW which is the case with newer versions) you'll end up with GIF-filesizes all too big! 
					This install tool tests what kinds of GIF compression are available in the ImageMagick installations by a physical test. You can also check it manually by opening a Typo3 generated gif-file with Photoshop and save it in a new file. If the file sizes of the original and the new file are almost the same, you're having LZW compression and everything is fine.";
				}
				if ($this->config_array["gd_png"])		{
					$msg[20]="Typo3 prefers the use of GIF-files and most likely your visitors on your website does too as not all browsers support PNG yet.";
				}
				$this->message($ext, "GIF / PNG issues", nl2br(trim(implode($msg,chr(10)))), 1);
			}
			if (!$this->isTTF())	{
				$this->message($ext, "FreeType is apparently not installed", "
					It looks like the FreeType library is not compiled into GDLib. This is required when Typo3 uses GDLib and you'll most likely get errors like 'ImageTTFBBox is not a function' or 'ImageTTFText is not a function'.
				", 2);
			} else {
				$this->message($ext, "FreeType Quick-test (".($this->isGIF()?"as GIF":"as PNG").")", '<img src="'.getenv("REQUEST_URI").'&testingTrueTypeSupport=1">', -1);
				$this->config_array["freetype"]=1;
			}
		} else {
			$this->message($ext, "GDLib not found", "
				GDLib is required if you want to use the GIFBUILDER object in TypoScript. GIFBUILDER is in charge of all advanced image generation in TypoScript, including graphical menuitems. 
				GDLib is also used in the Typo3 Backend (TBE) to generate record icons and new module tabs.
				It's highly recommended to install this library. Remember to compile GD with FreeType which is also required.
				If you choose not to install GDLib, you can disable it in the configuration with [GFX][gdlib]=0;.
			", 2);
		}
		$this->message($ext, "GDLib software information", nl2br(trim($this->getGDSoftwareInfo())));
	}

	/**
	 * Checking and testing that the required writable directories are writable.
	 */
	function checkDirs()	{
		// Check typo3/temp/
		$ext="Directories";
		$this->message($ext);

		$uniqueName = md5(uniqid(microtime()));
		$mainDir = defined("TYPO3_mainDir")?TYPO3_mainDir:"typo3/";
		$path = PATH_temp;
		$general_message = "The folder is used by the backend interface only (TBE) for icons, pane tabs and click-menu items. The directory is usually not empty in the distribution, but you should be able to clear it out and Typo3 should generate new files automatically.";
		if (!@is_dir($path))	{
			$this->message($ext, $mainDir."temp/ directory does not exist","
			<em>Full path: ".$path."</em>
			This error may occur if you don't use '".$mainDir."' as your administration directory.
			".$general_message."
			",2);
		} else {
			$file = $path.$uniqueName;
			@touch($file);
			if (@is_file($file))	{
				unlink($file);
				$this->config_array["dir_temp"]=1;
				$this->message($ext, $mainDir."temp/ writeable","",-1);
			} else {
				$this->message($ext, $mainDir."temp/ directory not writeable","
				<em>Full path: ".$file."</em>
				Tried to write this file (with touch()) but didn't succeed.
				The directory ".$mainDir."temp/ must be writable for temporary files!
				".$general_message."
				",3);
			}
		}


		// Check typo3temp/
		$path = $this->typo3temp_path;
		$general_message = "The folder is used by both the frontend (FE) and backend interface (TBE) for image manipulated files.";
		if (!@is_dir($path))	{
			$this->message($ext, "typo3temp/ directory does not exist","
			<em>Full path: ".$path."</em>
			This error should not occur as typo3temp/ must always be accessible in the root of a Typo3 website. 
			".$general_message."
			",3);
		} else {
			$file = $path.$uniqueName;
			@touch($file);
			if (@is_file($file))	{
				unlink($file);
				$this->config_array["dir_typo3temp"]=1;
				$this->message($ext, "typo3temp/ writeable","",-1);
			} else {
				$this->message($ext, "typo3temp/ directory not writeable","
				<em>Full path: ".$file."</em>
				Tried to write this file (with touch()) but didn't succeed.
				The directory typo3temp/ must be writable for temporary files!
				".$general_message."
				",3);
			}
		}
		
	}

	/**
	 * Checking for existing ImageMagick installs.
	 *
	 * This tries to find available ImageMagick installations and tries to find the version numbers by executing "convert" without parameters. If the ->checkIMlzw is set, LZW capabilities of the IM installs are check also.
	 */
	function checkImageMagick($paths)	{
		$ext="Check Image Magick";
		$this->message($ext);

		$paths = array_unique($paths);

		$programs = explode(",","convert,combine,composite,identify");	// Added composite (substitution for combine in newer versions?)
		$isExt = TYPO3_OS=="WIN" ? ".exe" : "";
		$this->config_array["im_combine_filename"]="combine";
		reset($paths);
		while(list($k,$v)=each($paths))	{
			reset($programs);
			while(list(,$filename)=each($programs))	{
				if (@file_exists($v) && @is_file($v.$filename.$isExt))    {       // file_exists was necessary on windows, because is_file issued a warning if the path was not correct.
					$index[$v][$filename]=$this->_checkImageMagick_getVersion($v.$filename.$isExt);
				}
			}
			if (count($index[$v])>=3)	{$this->config_array["im"]=1;}
			if ($index[$v]["composite"] && !$index[$v]["combine"])	{
				$this->config_array["im_combine_filename"]="composite";
			}
			if (isset($index[$v]["convert"]) && $this->checkIMlzw)	{
				$index[$v]["gif_capability"] = "".$this->_checkImageMagickGifCapability($v);
			}
		}
		$this->config_array["im_versions"]=$index;
		if (!$this->config_array["im"])	{
			$this->message($ext, "No ImageMagick install available","
			It seems that there is no adequate ImageMagick installation available at the checked locations (".implode($paths, ", ").")
			An 'adequate' installation for requires 'convert', 'combine'/'composite' and 'identify' to be available
			",2);
		} else {
			$theCode="";
			reset($this->config_array["im_versions"]);
			while(list($p,$v)=each($this->config_array["im_versions"]))	{
				$ka=array();
				reset($v);
				while(list($ka[])=each($v)){}
				$theCode.='<tr><td>'.$this->fw($p).'</td><td>'.$this->fw(implode($ka,"<BR>")).'</td><td>'.$this->fw(implode($v,"<BR>")).'</td></tr>';
			}
			$this->message($ext, "Available ImageMagick installations:",'<table border=1 cellpadding=2 cellspacing=2>'.$theCode.'</table>',-1);
		}
		$this->message($ext, "Search for ImageMagick:",'
			<form action="'.$this->action.'" method="POST">'.$content.'<input type="checkbox" name="TYPO3_INSTALL[checkIM][lzw]" value="1"'.($this->INSTALL["checkIM"]["lzw"]?" checked":"").'> Check LZW capabilities.

				Check this path for ImageMagick installation:
				<input type="text" name="TYPO3_INSTALL[checkIM][path]" value="'.htmlspecialchars(stripslashes($this->INSTALL["checkIM"]["path"])).'"> 
				(Eg. "D:\wwwroot\im537\ImageMagick\" for windows or "/usr/bin/" for Unix)<br>
				
				<input type="submit" value="Send">
			</form>		
		',0);
		
	}

	/**
	 * Checking GIF-compression capabilities of ImageMagick install
	 */
	function _checkImageMagickGifCapability($file)	{
		if ($this->config_array["dir_typo3temp"])	{		//  && !$this->config_array["safemode"]
			$path = $this->typo3temp_path;
			$uniqueName = md5(uniqid(microtime()));
			$dest = $path.$uniqueName.".gif";
			$src = PATH_t3lib."typo3logo.gif";
			if (@is_file($src) && !strstr($src," ") && !strstr($dest," "))	{
				$cmd = $file.'convert '.$src.' '.$dest;
				exec($cmd);
			} else die("No t3lib/typo3logo.gif file!");
			$out="";
			if (@is_file($dest))	{
				$new_info = @getimagesize($dest);
				clearstatcache();
				$new_size = filesize($dest);
				$src_info = @getimagesize($src);
				clearstatcache();
				$src_size = @filesize($src);
				
				if ($new_info[0]!=$src_info[0] || $new_info[1]!=$src_info[1] || !$new_size || !$src_size)	{
					$out="error";
				} else {
					if ($new_size/$src_size > 4) {	// NONE-LZW ratio was 5.5 in test
						$out="NONE";
					} elseif ($new_size/$src_size > 1.5) {	// NONE-RLE ratio was not tested
						$out="RLE";
					} else {
						$out="LZW";
					}
				}
				unlink($dest);
			}
			return $out;
		}
	}

	/**
	 * Extracts the version number for imagemagick
	 *
	 * @param	string	$file	This is the path to the convert-program to execute in order to find the version number
	 */
	function _checkImageMagick_getVersion($file)	{
		exec($file, $retVal);
		$string = $retVal[0];
		list(,$ver) = explode("ImageMagick", $string);
		list($ver) = explode(" ",trim($ver));
		return trim($ver);
	}

	/**
	 * Checks database username/password/host/database
	 */
	function checkDatabase()		{
		$ext="Check database";
		$this->message($ext);

		if (!extension_loaded("mysql"))	{
			$this->message($ext, "MySQL not available","
				PHP does not feature MySQL support (which is pretty unusual).
			",2);
		} else {
			$cInfo="
				Username: <strong>".TYPO3_db_username."</strong>
				Password: <strong>".TYPO3_db_password."</strong>
				Host: <strong>".TYPO3_db_host."</strong>
			";
			if (!TYPO3_db_host || !TYPO3_db_username)	{
				$this->message($ext, "Username, password or host not set","
					You may need to enter data for these values:
					".trim($cInfo)."
					
					Use the form below.
				",2);
			}
			if ($result = @mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
				$this->message($ext, "Connected to MySQL successfully","
				".trim($cInfo)."
				",-1,1);
				$this->config_array["mysqlConnect"]=1;
				if (!TYPO3_db)	{
					$this->message($ext, "No database selected","
						Currently you have no database selected.
						Please select one or create a new database.
					",3);
					$this->config_array["no_database"]=1;
				} elseif (!mysql_select_db(TYPO3_db))  {
					$this->message($ext, "Database","
						'".TYPO3_db."' could not be selected as database!
						Please select another one or create a new database.
					",3,1);
					$this->config_array["no_database"]=1;
				} else  {
					$this->message($ext, "Database","
						<strong>".TYPO3_db."</strong> is selected as database.
					",1,1);
				}
			} else {
				$this->message($ext, "Could not connect to MySQL!","
				Connecting to MySQL failed with these settings:
				".trim($cInfo)."
				
				Make sure you're using the correct set of data.".($this->config_array["sql.safe_mode_user"]? "
				<strong>Notice:</strong> <em>sql.safe_mode</em> is turned on, so apparently your username to the database is the same as the scriptowner, which is '".$this->config_array["sql.safe_mode_user"]."'":"")."
				",3);
			}
		}
	}

	/**
	 * Prints form for updating localconf.php or updates localconf.php depending on $cmd
	 *
	 * @param	string	$cmd	If "get_form" it outputs the form. Default is to write "localconf.php" based on input in ->INSTALL[localconf.php] array and flag ->setLocalconf
	 */
	function setupGeneral($cmd="")	{
		switch($cmd)	{
			case "get_form":
					// Database:				
				$out='
				<table border=0 cellpadding=0 cellspacing=0>
				<form action="'.$this->action.'" method="POST">';
				
				$out.=$this->wrapInCells("Username:", '<input type="text" name="TYPO3_INSTALL[localconf.php][typo_db_username]" value="'.htmlspecialchars(TYPO3_db_username?TYPO3_db_username:($this->config_array["sql.safe_mode_user"]?$this->config_array["sql.safe_mode_user"]:"")).'">'.($this->config_array["sql.safe_mode_user"]?"<BR>sql.safe_mode_user: <strong>".$this->config_array["sql.safe_mode_user"]."</strong>":""));
				$out.=$this->wrapInCells("Password:", '<input type="text" name="TYPO3_INSTALL[localconf.php][typo_db_password]" value="'.htmlspecialchars(TYPO3_db_password).'">');
				$out.=$this->wrapInCells("Host:", '<input type="text" name="TYPO3_INSTALL[localconf.php][typo_db_host]" value="'.htmlspecialchars(TYPO3_db_host).'">');
				if ($this->config_array["mysqlConnect"])	{
					$dbArr = $this->getDatabaseList();
					reset($dbArr);
					$options="";
					$dbIncluded=0;
					while(list(,$dbname)=each($dbArr))	{
						$options.='<option value="'.htmlspecialchars($dbname).'"'.($dbname==TYPO3_db?' selected':'').'>'.htmlspecialchars($dbname).'</option>';
						if ($dbname==TYPO3_db)	$dbIncluded=1;
					}
					if (!$dbIncluded && TYPO3_db)	{
						$options.='<option value="'.htmlspecialchars(TYPO3_db).'" selected>'.htmlspecialchars(TYPO3_db).' (NO ACCESS!)</option>';
					}
					$theCode='<select name="TYPO3_INSTALL[localconf.php][typo_db]">'.$options.'</select><BR>Create database? (Enter name):<BR><input type="text" name="TYPO3_INSTALL[localconf.php][NEW_DATABASE_NAME]" value="">';
				} else {
					$theCode='<strong>'.htmlspecialchars(TYPO3_db).'</strong><BR>(Can only select database if username/password/host is correctly set first)<input type="hidden" name="TYPO3_INSTALL[localconf.php][typo_db]" value="'.htmlspecialchars(TYPO3_db).'">';
				}
				$out.=$this->wrapInCells("", "<BR>");
				$out.=$this->wrapInCells("Database:", $theCode);
				$out.=$this->wrapInCells("", "<BR>");

				if ($this->mode!="123")	{
					$out.=$this->wrapInCells("Site name:", '<input type="text" name="TYPO3_INSTALL[localconf.php][sitename]" value="'.htmlspecialchars($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]).'">');
					$out.=$this->wrapInCells("", "<BR>");
	
						// Other
					$fA = $this->setupGeneralCalculate();
	//				debug($fA);
					if (is_array($fA["disable_exec_function"]))	{
						$out.=$this->wrapInCells("[BE][disable_exec_function]=", $this->getFormElement($fA["disable_exec_function"], $fA["disable_exec_function"], 'TYPO3_INSTALL[localconf.php][disable_exec_function]', $GLOBALS["TYPO3_CONF_VARS"]["BE"]["disable_exec_function"]));
					} 
					if (is_array($fA["gdlib"]))	{
						$out.=$this->wrapInCells("[GFX][gdlib]=", $this->getFormElement($fA["gdlib"], $fA["gdlib"], 'TYPO3_INSTALL[localconf.php][gdlib]', $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"]));
						if (is_array($fA["gdlib_png"]) && $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"])	{
							$out.=$this->wrapInCells("[GFX][gdlib_png]=", $this->getFormElement($this->setLabelValueArray($fA["gdlib_png"],2), $fA["gdlib_png"], 'TYPO3_INSTALL[localconf.php][gdlib_png]', $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib_png"]));
						} 
					} 
					if (is_array($fA["im"]))	{
						$out.=$this->wrapInCells("[GFX][im]=", $this->getFormElement($fA["im"], $fA["im"], 'TYPO3_INSTALL[localconf.php][im]', $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im"]));
						$out.=$this->wrapInCells("[GFX][im_combine_filename]=", $this->getFormElement($fA["im_combine_filename"], ($fA["im_combine_filename"]?$fA["im_combine_filename"]:"combine"), 'TYPO3_INSTALL[localconf.php][im_combine_filename]', $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_combine_filename"]));
						if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im"])	{
							if (is_array($fA["im_path"]))	{
								$out.=$this->wrapInCells("[GFX][im_path]=", $this->getFormElement($this->setLabelValueArray($fA["im_path"],1), $this->setLabelValueArray($fA["im_path"],0), 'TYPO3_INSTALL[localconf.php][im_path]', $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path"]));
							} 
							if (is_array($fA["im_path_lzw"]))	{
								$out.=$this->wrapInCells("[GFX][im_path_lzw]=", $this->getFormElement($this->setLabelValueArray($fA["im_path_lzw"],1), $this->setLabelValueArray($fA["im_path_lzw"],0), 'TYPO3_INSTALL[localconf.php][im_path_lzw]', $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"]));
							} 
						}					
					} 
				}				

					
				$out.=$this->wrapInCells("", '<BR><input type="submit" value="Update localconf.php"><BR>
				<strong>NOTICE: </strong>By clicking this button, localconf.php is updated with new values for the parameters listed above!');
				$out.='
				</form>
				</table>';
			break;
			default:
				if (is_array($this->INSTALL["localconf.php"]))		{
					$lines = $this->writeToLocalconf_control();
						
						// New database?
					if (trim($this->INSTALL["localconf.php"]["NEW_DATABASE_NAME"]))	{
						$newdbname=trim($this->INSTALL["localconf.php"]["NEW_DATABASE_NAME"]);
						if (!ereg("[^[:alnum:]_]",$newdbname))	{
							if ($result = @mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
								if (mysql_create_db($newdbname))	{
									$this->INSTALL["localconf.php"]["typo_db"]=$newdbname;
									$this->messages[]= "Database '".$newdbname."' created";
								} else $this->messages[]= "Could not create database '".$newdbname."' (...not created)";
							} else $this->messages[]= "Could not connect to database when creating database '".$newdbname."' (...not created)";
						} else $this->messages[]= "The NEW database name '".$newdbname."' was not alphanumeric, a-zA-Z0-9_ (...not created)";
					}
						
						// Parsing values
					reset($this->INSTALL["localconf.php"]);
					while(list($key,$value)=each($this->INSTALL["localconf.php"]))		{
						switch((string)$key)	{
							case "typo_db_username":
								if (!ereg("[^[:alnum:]_]",$value) && strlen($value)<50)	{
									if (strcmp(TYPO3_db_username,$value))		$this->setValueInLocalconfFile($lines, '$typo_db_username', $value);
								} else $this->messages[]= "Username '".$value."' was not alphanumeric, a-zA-Z0-9_, or longer than 50 chars (...not saved)";
							break;
							case "typo_db_password":
								if (!ereg("[^[:alnum:]_]",$value) && strlen($value)<50)	{
									if (strcmp(TYPO3_db_password,$value))		$this->setValueInLocalconfFile($lines, '$typo_db_password', $value);
								} else $this->messages[]= "Password '".$value."' was not alphanumeric, a-zA-Z0-9_, or longer than 50 chars (...not saved)";
							break;
							case "typo_db_host":
								if (!ereg("[^[:alnum:]_\.-]",$value) && strlen($value)<50)	{
									if (strcmp(TYPO3_db_host,$value))		$this->setValueInLocalconfFile($lines, '$typo_db_host', $value);
								} else $this->messages[]= "Host '".$value."' was not alphanumeric, a-zA-Z0-9_-., or longer than 50 chars (...not saved)";
							break;
							case "typo_db":
								if (!ereg("[^[:alnum:]_]",$value) && strlen($value)<50)	{
									if (strcmp(TYPO3_db,$value))		$this->setValueInLocalconfFile($lines, '$typo_db', $value);
								} else $this->messages[]= "Database '".$value."' was not alphanumeric, a-zA-Z0-9_, or longer than 50 chars (...not saved)";
							break;
							case "disable_exec_function":
								if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["BE"]["disable_exec_function"],$value))	$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["BE"]["disable_exec_function"]', $value?1:0);
							break;
							case "sitename":
								if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"],$value))	$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["SYS"]["sitename"]', $value);
							break;
							case "im_combine_filename":
								if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_combine_filename"],$value))	$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["GFX"]["im_combine_filename"]', $value);
							break;
							case "gdlib":
							case "gdlib_png":
							case "im":
								if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["GFX"][$key],$value))	$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["GFX"]["'.$key.'"]', $value?1:0);
							break;
							case "im_path":
								list($value,$version) = explode("|",$value);
								if (!ereg("[[:space:]]",$value,$reg) && strlen($value)<100)	{
									if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["GFX"][$key],$value))	{
										$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["GFX"]["'.$key.'"]', $value);
									}
									$value_ext = (doubleval($version)<5)?0:1;
									if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_version_5"],$value_ext))	{
										$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["GFX"]["im_version_5"]', $value_ext);
									}
								} else $this->messages[]= "Path '".$value."' contains spaces or is longer than 100 chars (...not saved)";
							break;
							case "im_path_lzw":
								list($value) = explode("|",$value);
								if (!ereg("[[:space:]]",$value) && strlen($value)<100)	{
									if (strcmp($GLOBALS["TYPO3_CONF_VARS"]["GFX"][$key],$value))	$this->setValueInLocalconfFile($lines, '$TYPO3_CONF_VARS["GFX"]["'.$key.'"]', $value);
								} else $this->messages[]= "Path '".$value."' contains spaces or is longer than 100 chars (...not saved)";
							break;
						}
						
						
					}
					
					$this->writeToLocalconf_control($lines);
				}
			break;
		}
		return $out;
	}
	
	function writeToLocalconf_control($lines="")	{
		$this->writeToLocalconf_dat["file"] = PATH_typo3conf."localconf.php";
		if (!$this->allowUpdateLocalConf)	{
			die("->allowUpdateLocalConf flag in the install object is not set and therefore 'localconf.php' cannot be altered.");
		}
		if (!@is_writeable($this->writeToLocalconf_dat["file"]))	{
			die($this->writeToLocalconf_dat["file"]." is not writeable!");
		}
		if (!is_array($lines))	{
				// Getting configuration
			$lines = explode(chr(10),trim(t3lib_div::getUrl($this->writeToLocalconf_dat["file"])));
			$this->writeToLocalconf_dat["endLine"]=array_pop($lines);
	
			$updatedLine=array_pop($lines);
			$this->writeToLocalconf_dat["updatedText"] = "// Updated by Typo3 Install tool ";
			if (!strstr($updatedLine, $this->writeToLocalconf_dat["updatedText"]))	{
				array_push($lines,$updatedLine);
			}
			return $lines;
		} else {
				// Setting configuration
			$updatedLine=$this->writeToLocalconf_dat["updatedText"].date("d-m-Y H:i:s");
			array_push($lines,$updatedLine);
			array_push($lines,$this->writeToLocalconf_dat["endLine"]);
			//debug($lines);
			if ($this->setLocalconf)	{
				t3lib_div::writeFile($this->writeToLocalconf_dat["file"],implode($lines,chr(10)));
				$this->messages[]= "Configuration written to typo3conf/localconf.php";

				$content = $this->fw("<BR><BR>".implode($this->messages,"<HR>").'<BR><BR><a href="'.$this->action.'">Click to continue...</a>');
				$this->outputExitBasedOnStep($content);
			} else {
				$content = $this->fw('<strong>Writing to \'localconf.php\':</strong><BR><BR>No values were changed, so nothing is updated!<BR><BR><a href="'.$this->action.'">Click to continue...</a>');
				$this->outputExitBasedOnStep("<BR>".$content);
			}
		}
	}
	function outputExitBasedOnStep($content)	{
		if ($this->step)	{
			Header("Location: ".$this->action);
		} else {
			echo $this->outputWrapper($content);
		}
		exit;
	}

	function checkForBadString($string)	{
//		if (ereg("[".chr(10).chr(13)."\$\"\\]|//",$string)){
		if (ereg("[".chr(10).chr(13)."]|//",$string)){
			return 0;
		} else return 1;
	}
	
	/**
	 * This functions takes an array with lines from localconf.php, finds a variable and inserts the new value.
	 *
	 * @param	array	$lime_array	the localconf.php file exploded into an array by linebreaks.
	 * @param	string	$variable	The variable name to find and substitute. This string must match the first part of a trimmed line in the line-array. Matching is done backwards so the last appearing line will be substituted.
	 * @param	string	$value		Is the value to be insert for the variable
	 */
	function setValueInLocalconfFile(&$line_array, $variable, $value)	{
		$value = stripslashes($value);
		if (!$this->checkForBadString($value))	return 0;
		$found=0;
		$commentKey = "## ";
		$inArray = in_array($commentKey.$this->localconf_editPointToken,$line_array);
		$tokenSet = ($this->localconf_editPointToken && !$inArray);		// Flag is set if the token should be set but is not yet...
		$stopAtToken = ($this->localconf_editPointToken && $inArray);
		
		$comment = ' Modified or inserted by Typo3 Install tool. ';
		if (!$this->localconf_addLinesOnly && !$tokenSet)	{
			$line_array = array_reverse($line_array);
			reset($line_array);
			while(list($k,$v)=each($line_array))	{
				$v2=trim($v);
				if ($stopAtToken && !strcmp($v2,$commentKey.$this->localconf_editPointToken))	break;		// If stopAtToken and token found, break out of the loop..
				if (!strcmp(substr($v2,0,strlen($variable." ")),$variable." "))	{
					$mainparts = explode($variable,$v,2);
					if (count($mainparts)==2)	{	// should ALWAYS be....
						$subparts = explode("//",$mainparts[1],2);
						$line_array[$k] = $mainparts[0].$variable." = '".str_replace("'","\'",str_replace('\\','\\\\',$value))."';       ".("//".$comment.str_replace($comment,"",$subparts[1]));
						$found=1;
						break;
					}
				}
			}
			$line_array = array_reverse($line_array);
		}
		if (!$found)	{
			if ($tokenSet)		{
				$line_array[] = $commentKey.$this->localconf_editPointToken;
				$line_array[] = "";
			}
			$line_array[] = $variable.' = "'.addslashes($value).'";	// '.$comment;
		}
		$this->messages[]= $variable." = '".htmlspecialchars($value)."'";
		$this->setLocalconf=1;
//		debug($line_array);
	}

	/**
	 * This appends something to value in the input array based on $type. Private.
	 */
	function setLabelValueArray($arr,$type)	{
		reset($arr);
		while(list($k,$v)=each($arr))	{
			switch($type)	{
				case 0:	// value, im
					$arr[$k].="|".$this->config_array["im_versions"][$v]["convert"];
				break;
				case 1:	// labels, im
					$arr[$k].=$this->config_array["im_versions"][$v]["convert"] ? " (".$this->config_array["im_versions"][$v]["convert"].($this->config_array["im_versions"][$v]["gif_capability"]?", ".$this->config_array["im_versions"][$v]["gif_capability"]:"").")" : "";
				break;
				case 2: // labels, gd
					$arr[$k].=" (".($v==1?"PNG":"GIF").")";
				break;
			}
		}
		return $arr;
	}

	/**
	 * Returns a form-element for the localconf.php update form
	 */
	function getFormElement($labels,$values,$fieldName,$default,$msg="")	{
		$out.='<strong>'.htmlspecialchars(current($labels)).'</strong><BR>current value is '.htmlspecialchars($default).($msg?"<BR>".$msg:"");
		if (count($labels)>1)		{
			reset($labels);
			while(list($k,$v)=each($labels))	{
				list($cleanV) =explode("|",$values[$k]);
				$options.='<option value="'.htmlspecialchars($values[$k]).'"'.(!strcmp($default,$cleanV)?" selected":"").'>'.htmlspecialchars($v).'</option>';
			}
			$out.='<BR><select name="'.$fieldName.'">'.$options.'</select>';
		} else {
			$out.='<input type="hidden" name="'.$fieldName.'" value="'.htmlspecialchars(current($values)).'">';
		}
		return $out."<BR>";
	}

	/**
	 * Returns the list of available databases (with access-check based on username/password)
	 */
	function getDatabaseList()	{
		$dbArr=array();
		if ($result = @mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
			$db_list = mysql_list_dbs();
			while ($row = mysql_fetch_object($db_list)) {
				if (mysql_select_db($row->Database))	{
					$dbArr[]=$row->Database;
				}
			}
		}	      		
		return $dbArr;
	}

	/**
	 * Calculates the suggested setup that should be written to localconf.php
	 */
	function setupGeneralCalculate()	{
	/*
If safe_mode
- disable_exec_function = 1
- im = 0

if PNG/GIF/GD
- disable gdlib if nothing
	- select png/gif if only one of them is available, else PNG/GIF selector, defaulting to GIF
- (safe_mode is on)
	- im_path (default to 4.2.9, preferable with LZW)		im_ver5-flag is set based on im_path being 4.2.9 or 5+
	- im_path_lzw (default to LZW version, pref. 4.2.9)

*/
		$formArray["disable_exec_function"]=array(0);
		$formArray["im_path"]=array("");
		$formArray["im_path_lzw"]=array("");
		$formArray["im_combine_filename"]=array("");
		$formArray["im"]=array(1);
		$formArray["gdlib"]=array(1);
		if ($this->config_array["gd"] && ($this->config_array["gd_gif"] || $this->config_array["gd_png"]))	{
			if ($this->config_array["gd_gif"] && !$this->config_array["gd_png"])	{
				$formArray["gdlib_png"]=array(0);
			} elseif (!$this->config_array["gd_gif"] && $this->config_array["gd_png"])	{
				$formArray["gdlib_png"]=array(1);
			} else {
				$formArray["gdlib_png"]=array(0,1);
			}
		} else {
			$formArray["gdlib"]=array(0);
		}
		if ($this->config_array["safemode"])	{
			$formArray["disable_exec_function"]=array(1);
		}
		if ($this->config_array["im"])	{
			$formArray["im"]=array(1);
			$LZW_found=0;
			$found=0;
			reset($this->config_array["im_versions"]);
			$totalArr=array();
			while(list($path,$dat)=each($this->config_array["im_versions"]))	{
				if (count($dat)>=3)	{
					if (doubleval($dat["convert"])<5)	{
						if ($dat["gif_capability"]=="LZW")	{
							$formArray["im_path"]=array($path);
							$found=2;
						} elseif ($found<2)	{
							$formArray["im_path"]=array($path);
							$found=1;
						}
					} elseif (!$found)	{
						$formArray["im_path"]=array($path);
						$found=1;
					}
				}
				if ($dat["gif_capability"]=="LZW")	{
					if (doubleval($dat["convert"])<5)	{
						$formArray["im_path_lzw"]=array($path);
						$LZW_found=1;
					} elseif (!$LZW_found) {
						$formArray["im_path_lzw"]=array($path);
						$LZW_found=1;
					}
				} elseif ($dat["gif_capability"]=="RLE" && !$LZW_found)	{
					$formArray["im_path_lzw"]=array($path);
				}
				$totalArr[]=$path;
			}
			$formArray["im_path"]=array_unique(array_merge($formArray["im_path"],$totalArr));
			$formArray["im_path_lzw"]=array_unique(array_merge($formArray["im_path_lzw"],$totalArr));
			$formArray["im_combine_filename"]=array($this->config_array["im_combine_filename"]);
		} else {
			$formArray["im"]=array(0);
		}
		return $formArray;
	}

	/**
	 * Returns the part of phpinfo() output that tells about GD library (HTML-code)
	 */
	function getGDPartOfPhpinfo()	{
		ob_start();
		phpinfo();
		$contents = ob_get_contents(); 
		ob_end_clean();
		$start_string = $this->getGD_start_string;
		$end_string = $this->getGD_end_string;
		list(,$gdpart_tmp) = explode($start_string,$contents,2);
		list($gdpart) = explode($end_string,$start_string.$gdpart_tmp,2);
		$gdpart.=$end_string;
		return $gdpart;
	}

	/**
	 * Returns true if TTF lib is install according to phpinfo(). If $phpinfo supply as parameter that string is searched instead.
	 */
	function isTTF($phpinfo="")	{
/*		$phpinfo = $phpinfo?$phpinfo:$this->getGDPartOfPhpinfo();
		if (stristr($phpinfo, $this->getTTF_string))    return 1;
		if (stristr($phpinfo, $this->getTTF_string_alt))        return 1;
		*/
		
			// try, print truetype font:
		$im = @imagecreate (300, 50);
		$background_color = imagecolorallocate ($im, 255, 255, 55);
		$text_color = imagecolorallocate ($im, 233, 14, 91);

		$test = @imagettftext($im, 20, 0, 10, 20, $text_color, PATH_t3lib."/fonts/verdana.ttf", "Testing Truetype support");
		if (t3lib_div::GPvar("testingTrueTypeSupport"))	{
			if ($this->isGIF())	{
				header ("Content-type: image/gif");
				imagegif ($im);
			} else {
				header ("Content-type: image/png");
				imagepng ($im);
			}
			exit;
		}
		return is_array($test)?1:0;
	}
	function isGD()	{
		if (@imagecreate (50, 100))	return 1;
	}
	
	function isGIF()	{
		$im = @imagecreatefromgif(PATH_t3lib."install/imgs/jesus.gif");
		return $im?1:0;
//		return ImageTypes() & IMG_GIF;	// Does not work with PHP 4.1.2
	}

	/**
	 * Returns general information about GDlib
	 */
	function getGDSoftwareInfo()	{
		return trim("
		You can get GDLib in the PNG version from ".$this->linkIt("http://www.boutell.com/gd/")." or you can get the patched GIF version from ".$this->linkIt("http://www.typo3.com/?software").".<BR>FreeType is for download at ".$this->linkIt("http://www.freetype.org/")."</a>.
		If you're using a Windows server, you'll be happy to know that all this is compiled into a PHP4-distribution for download at ".$this->linkIt("http://www.php4win.de/")."</a>.
		");
	}

	/**
	 * Returns general information about configuration of Typo3.
	 */
	function generallyAboutConfiguration()	{
		$out='
		Local configuration is done by overriding default values in the included file, typo3conf/localconf.php. In this file you enter the database information along with values in the global array TYPO3_CONF_VARS.
		The options in the TYPO3_CONF_VARS array and how to use it for your own purposes is discussed in the base configuration file, t3lib/config_default.php. This file sets up the default values and subsequently includes the localconf.php file in which you can then override values.
		See this page for '.$this->linkIt("http://www.typo3.com/index.php/Server_software_and/1051/0/","more information about system requirements.").'
		';
		return trim($out);
	}



	
	
	
	
	
	
	
	
	
	
	// **********************
	// IMAGE processing
	// **********************
/*

jesus.TIF:	IBM/LZW
jesus.GIF:	Save for web, 32 colors
jesus.JPG:	Save for web, 30 quality
jesus.PNG:	Save for web, PNG-24
jesus.tga	24 bit TGA file
jesus.pcx	
jesus.bmp	24 bit BMP file
jesus_ps6.PDF:	PDF w/layers and vector data
typo3logo.ai:	Illustrator 8 file
pdf_from_imagemagick.PDF	PDF-file made by Acrobat Distiller from InDesign PS-file


Imagemagick
- Read formats
- Write png, gif, jpg

Problems may arise from the use of safe_mode (eg. png)
In safemode you will automatically execute the program convert in the safe_mode_exec_path no matter what other path you specify
check fileexist before anything...

- compare gif size
- scaling (by stdgraphic)
- combining (by stdgraphic)

GDlib: 
- create from:....
- ttf text

From TypoScript: (GD only, GD+IM, IM)

*/
	
	function checkTheImageProcessing()	{
		$this->message("Image Processing","What is it?","
		Typo3 is known for its ability to process images on the server.
		In the backend interface (TBE) thumbnails are automatically generated (by ImageMagick in thumbs.php) as well as icons, menu items and pane tabs (by GDLib).
		In the TypoScript enabled frontend all kinds of graphical elements are processed. Typically images are scaled down to fit the pages (by ImageMagick) and menu items, graphical headers and such are generated automatically (by GDLib + ImageMagick).
		In addition Typo3 is able to handle many file formats (thanks to ImageMagick), for example TIF, BMP, PCX, TGA, AI and PDF in addition to the standard web formats; JPG, GIF, PNG.
		
		In order to do this, Typo3 uses two sets of tools:
		
		<B>ImageMagick:</B>
		For conversion of non-web formats to webformats, combining images with alpha-masks, performing image-effects like blurring and sharpening.
		ImageMagick is a collection of external programs on the server called by the exec() function in PHP. Typo3 uses three of these, namely 'convert' (converting fileformats, scaling, effects), 'combine'/'composite' (combining images with masks) and 'identify' (returns image information).
		Because ImageMagick are external programs, two requirements must be met: 1) The programs must be installed on the server and working and 2) if safe_mode is enabled, the programs must be located in the folder defined by the php.ini setting, <em>safe_mode_exec_dir</em> (else they are not executed).
		ImageMagick is available for both Windows and Unix. The current version is 5+, but Typo3 enthusiasts prefer an old version 4.2.9 because that version has three main advantages: It's faster in some operations, the blur-function works, the sharpen-function works. Anyway you do it, you must tell Typo3 by configuration whether you're using version 5+ or 4.2.9. (flag: [GFX][im_version_5])
		ImageMagick homepage is at ".$this->linkIt("http://www.imagemagick.org/")."
		
		<B>GDLib:</B>
		For drawing boxes and rendering text on images with truetype fonts. Also used for icons, menuitems and generally the TypoScript GIFBUILDER object is based on GDlib, but extensively utilizing ImageMagick to process intermediate results.
		GDLib is accessed through internal functions in PHP, so in this case, you have no safe_mode problems, but you'll need a version of PHP with GDLib compiled in. Also in order to use TrueType fonts with GDLib you'll need FreeType compiled in as well.
		".$this->getGDSoftwareInfo()."
		
		You can disable all image processing options in Typo3 ([GFX][image_processing]=0), but that would seriously disable Typo3.
		");
		
		$this->message("Image Processing","Verifying the image processing capabilities of your server","
		This page performs image processing and displays the result. It's a thorough check that everything you've configured is working correctly.
		It's quite simple to verify your installation; Just look down the page, the images in pairs should look like each other. If some images are not alike, something is wrong. You may also notice warnings and errors if this tool found signs of any problems.

		The image to the right is the reference image (how it should be) and to the left the image made by your server. 
		The reference images are made with the classic ImageMagick install based on the 4.2.9 RPM and 5.2.3 RPM. If the version 5 flag is set, the reference images are made by the 5.2.3 RPM.
		
		This test will work only if your ImageMagick/GDLib configuration allows it to. The typo3temp/ folder must be writable for all the temporary image files. They are all prefixed 'install_' so they are easy to recognize and delete afterwards.
		");		
		
//		debug($this->config_array);
		$im_path = $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path"];
		$im_path_version = $this->config_array["im_versions"][$im_path]["convert"];
		$im_path_lzw = $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"];
		$im_path_lzw_version = $this->config_array["im_versions"][$im_path_lzw]["convert"];
		$msg = "
		ImageMagick enabled: <strong>".$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im"]."</strong>
		ImageMagick path: <strong>".$im_path."</strong> (".$im_path_version.")
		ImageMagick path/LZW: <strong>".$im_path_lzw."</strong>  (".$im_path_lzw_version.")
		Version 5 flag: <strong>".$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_version_5"]."</strong>

		GDLib enabled: <strong>".$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"]."</strong>
		GDLib using PNG: <strong>".$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib_png"]."</strong>

		File Formats: <strong>".$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"]."</strong>
		";
		if (($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_version_5"]?true:false) != (doubleval($im_path_version)>=5))	{
			$msg.="Warning: Mismatch between the version of ImageMagick (".$im_path_version.") and the configuration of [GFX][im_version_5] (".$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_version_5"].")";
			$etype=2;
		} else $etype=1;
		
		$this->message("Image Processing","Current configuration",$msg,$etype);	
		

		
		
		if (!$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["image_processing"])	{
			$this->message("Image Processing","Image Processing disabled!","
				Image Processing is disabled by the config flag <nobr>[GFX][image_processing]</nobr> set to false (zero)
			",2);
			echo $this->outputWrapper($this->printAll());
			return;
		} 
		if (!$this->config_array["dir_typo3temp"])	{
			$this->message("Image Processing","typo3temp/ not writeable!","
				You must make typo3temp/ write enabled before you can proceed with this test.
			",2);
			echo $this->outputWrapper($this->printAll());
			return;
		} 


		
		$msg='<a name="testmenu"></a>Click each of these links in turn to test a topic. <B>Please be aware that each test may take several seconds!</B>:
		
		'.$this->imagemenu();
		$this->message("Image Processing","Testmenu",$msg,"");	

	
		$this->messageFunc_nl2br=0;
		$parseStart = microtime();
		$imageProc = t3lib_div::makeInstance("t3lib_stdGraphic");
		$imageProc->init();
		$imageProc->tempPath=$this->typo3temp_path;
		$imageProc->dontCheckForExistingTempFile=1;
//		$imageProc->filenamePrefix="install_".($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_version_5"]?"v5":"");
		$imageProc->filenamePrefix="install_";	
		$imageProc->dontCompress=1;
		$imageProc->alternativeOutputKey="TYPO3_INSTALL_SCRIPT";
		$imageProc->noFramePrepended=$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_noFramePrepended"];
		
		// Very temporary!!!
		$imageProc->dontUnlinkTempFiles=0;
		
		
		$imActive = ($this->config_array["im"] && $im_path);
		$gdActive = ($this->config_array["gd"] && $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"]);

		switch($this->INSTALL["images_type"])	{
			case "read":
				$refParseTime="5600";	// 4.2.9
				$refParseTime="3300";	// 5.2.3
				$headCode = "Reading and converting images";
				$this->message($headCode,"Supported file formats","
				This verifies that your ImageMagick installation is able to read the nine default file formats; JPG, GIF, PNG, TIF, BMP, PCX, TGA, PDF, AI.
				The tool 'identify' will be used to read the pixeldimensions of non-web formats.
				The tool 'convert' is used to read the image and write a temporary JPG-file
				");

				if ($imActive)	{
						// Reading formats - writing JPG
			
					$extArr = explode(",","jpg,gif,png,tif,bmp,pcx,tga");
					while(list(,$ext)=each($extArr))	{
						if ($this->isExtensionEnabled($ext, $headCode, "Read ".strtoupper($ext)))	{
							$imageProc->IM_commands=array();
							$theFile = PATH_t3lib."install/imgs/jesus.".$ext;
							if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");

							$imageProc->imageMagickConvert_forceFileNameBody="read_".$ext;
							$fileInfo = $imageProc->imageMagickConvert($theFile,"jpg","","","","","",1);
							$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
							$this->message($headCode,"Read ".strtoupper($ext),$result[0],$result[1]);
						}
					}
			
					if ($this->isExtensionEnabled("pdf", $headCode, "Read PDF"))	{
						$imageProc->IM_commands=array();
						$theFile = PATH_t3lib."install/imgs/pdf_from_imagemagick.pdf";
						if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");

						$imageProc->imageMagickConvert_forceFileNameBody="read_pdf";
						$fileInfo = $imageProc->imageMagickConvert($theFile,"jpg","170","","","","",1);
						$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
						$this->message($headCode,"Read PDF",$result[0],$result[1]);
					}
					if ($this->isExtensionEnabled("ai", $headCode, "Read AI"))	{
						$imageProc->IM_commands=array();
						$theFile = PATH_t3lib."install/imgs/typo3logotype.ai";
						if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");

						$imageProc->imageMagickConvert_forceFileNameBody="read_ai";
						$fileInfo = $imageProc->imageMagickConvert($theFile,"jpg","170","","","","",1);
						$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
						$this->message($headCode,"Read AI",$result[0],$result[1]);
					}			
				} else {
					$this->message($headCode,"Test skipped","
					Use of ImageMagick has been disabled in the configuration.
					Refer to section 'Basic Configuration' to change or review you configuration settings
					",2);
				}
			break;		
			case "write":
				$refParseTime="300";
		
					// Writingformats - writing JPG
				$headCode = "Writing images";
				$this->message($headCode,"Writing GIF and PNG","
				This verifies that ImageMagick is able to write GIF and PNG files.
				The GIF-file is attempted compressed with LZW by the t3lib_div::gif_compress() function.
				");
			
				if ($imActive)	{
						// Writing GIF
					$imageProc->IM_commands=array();
					$theFile = PATH_t3lib."install/imgs/jesus.gif";
					if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");

					$imageProc->imageMagickConvert_forceFileNameBody="write_gif";
					$fileInfo = $imageProc->imageMagickConvert($theFile,"gif","","","","","",1);
					if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gif_compress"])	{
						clearstatcache();
						$prevSize=t3lib_div::formatSize(@filesize($fileInfo[3]));
						$returnCode = t3lib_div::gif_compress($fileInfo[3],"");
						clearstatcache();
						$curSize=t3lib_div::formatSize(@filesize($fileInfo[3]));
						$note = array("Note on gif_compress() function:","The 'gif_compress' method used was '".$returnCode."'.<BR>Previous filesize: ".$prevSize.". Current filesize:".$curSize);
					} else  $note=array("Note on gif_compress() function:","<em>Not used! Disabled by [GFX][gif_compress]</em>");
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands, $note);
					$this->message($headCode,"Write GIF",$result[0],$result[1]);
					
					
						// Writing PNG
					$imageProc->IM_commands=array();
					$theFile = PATH_t3lib."install/imgs/jesus.gif";

					$imageProc->imageMagickConvert_forceFileNameBody="write_png";
					$fileInfo = $imageProc->imageMagickConvert($theFile,"png","","","","","",1);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"Write PNG",$result[0],$result[1]);
				} else {
					$this->message($headCode,"Test skipped","
					Use of ImageMagick has been disabled in the configuration.
					Refer to section 'Basic Configuration' to change or review you configuration settings
					",2);
				}
			break;		
			case "scaling":
				$refParseTime="650";
		
					// Scaling
				$headCode = "Scaling images";
				$this->message($headCode,"Scaling transparent images","
				This shows how ImageMagick reacts when scaling transparent GIF and PNG files.
				");
				
				if ($imActive)	{
						// Scaling transparent image
					$imageProc->IM_commands=array();
					$theFile = PATH_t3lib."install/imgs/jesus2_transp.gif";
					if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");

					$imageProc->imageMagickConvert_forceFileNameBody="scale_gif";
					$fileInfo = $imageProc->imageMagickConvert($theFile,"gif","150","","","","",1);
					if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gif_compress"])	{
						clearstatcache();
						$prevSize=t3lib_div::formatSize(@filesize($fileInfo[3]));
						$returnCode = t3lib_div::gif_compress($fileInfo[3],"");
						clearstatcache();
						$curSize=t3lib_div::formatSize(@filesize($fileInfo[3]));
						$note = array("Note on gif_compress() function:","The 'gif_compress' method used was '".$returnCode."'.<BR>Previous filesize: ".$prevSize.". Current filesize:".$curSize);
					} else $note=array("Note on gif_compress() function:","<em>Not used! Disabled by [GFX][gif_compress]</em>");
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands,$note);
					$this->message($headCode,"GIF to GIF, 150 pixels wide",$result[0],$result[1]);
			
					$imageProc->IM_commands=array();
					$theFile = PATH_t3lib."install/imgs/jesus2_transp.png";
					if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");

					$imageProc->imageMagickConvert_forceFileNameBody="scale_png";
					$fileInfo = $imageProc->imageMagickConvert($theFile,"png","150","","","","",1);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"PNG to PNG, 150 pixels wide",$result[0],$result[1]);
			
					$imageProc->IM_commands=array();
					$theFile = PATH_t3lib."install/imgs/jesus2_transp.gif";
					if (!@is_file($theFile))	die("Error: ".$theFile." was not a file");
					$imageProc->imageMagickConvert_forceFileNameBody="scale_jpg";
					$fileInfo = $imageProc->imageMagickConvert($theFile,"jpg","150","","","","",1);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"GIF to JPG, 150 pixels wide",$result[0],$result[1]);
				} else {
					$this->message($headCode,"Test skipped","
					Use of ImageMagick has been disabled in the configuration.
					Refer to section 'Basic Configuration' to change or review you configuration settings
					",2);
				}
			break;		
			case "combining":
				$refParseTime="150";	// 4.2.9
				$refParseTime="250";	// 5.2.3
									// Combine
				$headCode = "Combining images";
				$this->message($headCode,"Combining images","
				This verifies that the ImageMagick tool, 'combine'/'composite', is able to combine two images through a grayscale mask.
				");
		
				if ($imActive)	{
					$imageProc->IM_commands=array();
					$input = PATH_t3lib."install/imgs/greenback.gif";
					$overlay = PATH_t3lib."install/imgs/jesus.jpg";
					$mask = PATH_t3lib."install/imgs/blackwhite_mask.gif";
						if (!@is_file($input))	die("Error: ".$input." was not a file");
						if (!@is_file($overlay))	die("Error: ".$overlay." was not a file");
						if (!@is_file($mask))	die("Error: ".$mask." was not a file");

					$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5($imageProc->alternativeOutputKey."combine1").".jpg";
					$imageProc->combineExec($input,$overlay,$mask,$output);
					$fileInfo = $imageProc->getImageDimensions($output);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"Combine using a GIF mask with only black and white",$result[0],$result[1]);
			
					// Combine
					$imageProc->IM_commands=array();
					$input = PATH_t3lib."install/imgs/combine_back.jpg";
					$overlay = PATH_t3lib."install/imgs/jesus.jpg";
					$mask = PATH_t3lib."install/imgs/combine_mask.jpg";
						if (!@is_file($input))	die("Error: ".$input." was not a file");
						if (!@is_file($overlay))	die("Error: ".$overlay." was not a file");
						if (!@is_file($mask))	die("Error: ".$mask." was not a file");
					$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5($imageProc->alternativeOutputKey."combine2").".jpg";
					$imageProc->combineExec($input,$overlay,$mask,$output);
					$fileInfo = $imageProc->getImageDimensions($output);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"Combine using a JPG mask with graylevels",$result[0],$result[1]);
				} else {
					$this->message($headCode,"Test skipped","
					Use of ImageMagick has been disabled in the configuration.
					Refer to section 'Basic Configuration' to change or review you configuration settings
					",2);
				}
			break;		
			case "gdlib":
				$refParseTime="1800";	// GIF / 4.2.9 / LZW (5.2.3)
				$refParseTime="2700";	// PNG / 4.2.9 / LZW (5.2.3)
				$refParseTime="1600";	// GIF / 5.2.3 / LZW (5.2.3)
					// GDLibrary
				$headCode = "GDLib";
				$this->message($headCode,"Testing GDLib","
				This verifies that the GDLib installation works properly.
				");
		
		
				if ($gdActive)	{
					// GD with box
					$imageProc->IM_commands=array();
					$im = imageCreate(170,136);
					ImageColorAllocate ($im, 0, 0, 0);
					$workArea=array(0,0,170,136);
					$conf=array(
						"dimensions" => "10,50,150,36",
						"color" => "olive"
					);
					$imageProc->makeBox($im,$conf,$workArea);
					$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5("GDbox").".".$imageProc->gifExtension;
					$imageProc->ImageGif ($im,$output);
					$fileInfo = $imageProc->getImageDimensions($output);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"Create simple image",$result[0],$result[1]);
			
			
					// GD from image with box
					$imageProc->IM_commands=array();
					$input = PATH_t3lib."install/imgs/jesus.".$imageProc->gifExtension;
						if (!@is_file($input))	die("Error: ".$input." was not a file");
					$im = $imageProc->imageCreateFromGif($input);
					$workArea=array(0,0,170,136);
					$conf=array();
					$conf["dimensions"]="10,50,150,36";
					$conf["color"]="olive";
					$imageProc->makeBox($im,$conf,$workArea);
					$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5("GDfromImage+box").".".$imageProc->gifExtension;
					$imageProc->ImageGif ($im,$output);
					$fileInfo = $imageProc->getImageDimensions($output);
					$GDWithBox_filesize = @filesize($output);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"Create image from file",$result[0],$result[1]);
			
			
					// GD with text
					$imageProc->IM_commands=array();
					$im = imageCreate(170,136);
					ImageColorAllocate ($im, 128,128,150);
					$workArea=array(0,0,170,136);
					$conf=array(
						"iterations" => 1,
						"angle" => 0,
						"antiAlias" => 1,
						"text" => "HELLO WORLD",
						"fontColor" => "#003366",
						"fontSize" => 18,
						"fontFile" => $this->backPath."t3lib/fonts/verdana.ttf",
						"offset" => "17,40"
					);
					$conf["BBOX"] = $imageProc->calcBBox($conf);
					$imageProc->makeText($im,$conf,$workArea);
			
					$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5("GDwithText").".".$imageProc->gifExtension;
					$imageProc->ImageGif ($im,$output);
					$fileInfo = $imageProc->getImageDimensions($output);
					$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands);
					$this->message($headCode,"Render text with TrueType font",$result[0],$result[1]);
		
					if ($imActive)	{
							// extension: GD with text, niceText
						$conf["offset"] = "17,65";
						$conf["niceText"] = 1;
						$imageProc->makeText($im,$conf,$workArea);
				
						$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5("GDwithText-niceText").".".$imageProc->gifExtension;
						$imageProc->ImageGif ($im,$output);
						$fileInfo = $imageProc->getImageDimensions($output);
						$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands, array("Note on 'niceText':","'niceText' is a concept that tries to improve the antialiasing of the rendered type by actually rendering the textstring in double size on a black/white mask, downscaling the mask and masking the text onto the image through this mask. This involves ImageMagick 'combine'/'composite' and 'convert'."));
						$this->message($headCode,"Render text with TrueType font using 'niceText' option",$result[0],$result[1]);
					} else {
						$this->message($headCode,"Render text with TrueType font using 'niceText' option","
						<strong>Test is skipped!</strong><BR><BR>
						
						Use of ImageMagick has been disabled in the configuration. ImageMagick is needed to generate text with the niceText option.
						Refer to section 'Basic Configuration' to change or review you configuration settings
						",2);
					}
					
					if ($imActive)	{
							// extension: GD with text, niceText AND shadow
						$conf["offset"] = "17,90";
						$conf["niceText"] = 1;
						$conf["shadow."] = array(
							"offset"=>"2,2",
							"blur" => "90",
							"opacity" => "50",
							"color" => "black"
						);
						$imageProc->makeShadow($im,$conf["shadow."],$workArea,$conf);
						$imageProc->makeText($im,$conf,$workArea);
				
						$output = $imageProc->tempPath.$imageProc->filenamePrefix.t3lib_div::shortMD5("GDwithText-niceText-shadow").".".$imageProc->gifExtension;
						$imageProc->ImageGif ($im,$output);
						$fileInfo = $imageProc->getImageDimensions($output);
						$result = $this->displayTwinImage($fileInfo[3],$imageProc->IM_commands, array("Note on drop shadows:","Drop shadows are done my using ImageMagick to blur a mask through which the drop shadow is generated. The blurring of the mask only works in ImageMagick 4.2.9 and <i>not</i> ImageMagick 5 - which is why you may see a hard and not soft shadow."));
						$this->message($headCode,"Render 'niceText' with a shadow under",$result[0],$result[1]);
					} else {
						$this->message($headCode,"Render 'niceText' with a shadow under","
						<strong>Test is skipped!</strong><BR><BR>
						
						Use of ImageMagick has been disabled in the configuration. ImageMagick is needed to generate shadows.
						Refer to section 'Basic Configuration' to change or review you configuration settings
						",2);
					}
					
					if ($imageProc->gifExtension=="gif")	{
						$buffer=20;
						$assess = "This assessment is based on the filesize from 'Create image from file' test, which were ".$GDWithBox_filesize." bytes";
						$goodNews = "If the image was LZW compressed you would expect to have a size of less than 9000 bytes. If you open the image with Photoshop and saves it from Photoshop, you'll a filesize like that.<BR>The good news is (hopefully) that your [GFX][im_path_lzw] path is correctly set so the gif_compress() function will take care of the compression for you!";
						if ($GDWithBox_filesize<8784+$buffer)	{
							$msg="<strong>Your GDLib appears to have LZW compression!</strong><BR>
								This assessment is based on the filesize from 'Create image from file' test, which were ".$GDWithBox_filesize." bytes.<BR>
								This is a real advantage for you because you don't need to use ImageMagick for LZW compressing. In order to make sure that GDLib is used, <strong>please set the config option [GFX][im_path_lzw] to an empty string!</strong><BR>
								When you disable the use of ImageMagick for LZW compressing, you'll see that the gif_compress() function has a return code of 'GD' (for GDLib) instead of 'IM' (for ImageMagick)
								";
						} elseif ($GDWithBox_filesize>19000)	{
							$msg="<strong>Your GDLib appears to have no compression at all!</strong><BR>
								".$assess."<br>".$goodNews;
						} else {
							$msg="Your GDLib appears to have RLE compression<BR>
								".$assess."<br>".$goodNews;
						}
						$this->message($headCode,"GIF compressing in GDLib","
						".$msg."
						",1);
					}
					
				} else {
					$this->message($headCode,"Test skipped","
					Use of GDLib has been disabled in the configuration.
					Refer to section 'Basic Configuration' to change or review you configuration settings
					",2);
				}
			break;
		}		

		if ($this->INSTALL["images_type"])	{
			// End info
			if ($this->fatalError)	{
				$this->message("Info","Errors","
				It seems that you had some fatal errors in this test. Please make sure that your ImageMagick and GDLib settings are correct. 
				Refer to the 'Basic Configuration' section for more information and debugging of your settings.
				");
			}

			$parseStop = microtime();
			$parseMS = t3lib_div::convertMicrotime($parseStop)-t3lib_div::convertMicrotime($parseStart);
			$this->message("Info","Parsetime",$parseMS." ms");
		}	
		echo $this->outputWrapper($this->printAll());
	}	
	function isExtensionEnabled($ext, $headCode, $short)	{
		if (!t3lib_div::inList($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"],$ext))	{
			$this->message($headCode,$short,"Skipped - extension not in the list of allowed extensions ([GFX][imagefile_ext]).",1);
		} else {
			return 1;
		}
	}
	function displayTwinImage ($imageFile, $IMcommands=array(), $note="")	{
		$ex_rows="";
		$errorLevels=array(-1);
		if ($imageFile)	{
			$verifyFile = PATH_t3lib."install/verify_imgs/".basename($imageFile);
			$destImg = @getImageSize($imageFile);
			$destImgCode ='<img src="'.$this->backPath.'../typo3temp/'.basename($imageFile).'" '.$destImg[2].'>';
			$verifyImg = @getImageSize($verifyFile);
			$verifyImgCode = '<img src="'.$this->backPath.'t3lib/install/verify_imgs/'.basename($verifyFile).'" '.$verifyImg[2].'>';
			if (!$verifyImg)	{
				$gifVersion=1;
				$verifyFile_alt = substr($verifyFile,0,-3)."gif";
				$verifyImg = @getImageSize($verifyFile_alt);
				if ($verifyImg)	{
					$verifyImgCode = '<img src="'.$this->backPath.'t3lib/install/verify_imgs/'.basename($verifyFile_alt).'" '.$verifyImg[2].'>';
					$verifyImgCode= '<table border=0 cellpadding=4 cellspacing=0 bgcolor=red><tr><td align=center>'.$verifyImgCode.'<BR>'.$this->fw("<strong>NO REFERENCE FOUND!</strong><BR><BR>GIF version looks like this.").'</td></tr></table>';
				} else {
					$verifyImgCode= '<table border=0 cellpadding=4 cellspacing=0 bgcolor=red><tr><td align=center>'.$this->fw("<strong>NO REFERENCE FOUND!</strong><BR><BR>".basename($verifyFile)).'</td></tr></table>';
				}
			}
			
			clearstatcache();
			$destImg["filesize"] = @filesize($imageFile);
			clearstatcache();
			$verifyImg["filesize"] = @filesize($verifyFile);
			
			$ex_rows.='<tr>';
			$ex_rows.='<td>'.$destImgCode.'</td>';
			$ex_rows.='<td><img src=clear.gif width=30 height=1></td>';
			$ex_rows.='<td>'.$verifyImgCode.'</td>';
			$ex_rows.='</tr>';
	
			$ex_rows.=$this->getTwinImageMessage("", t3lib_div::formatSize($destImg["filesize"]).", ".$destImg[0]."x".$destImg[1]." pixels", t3lib_div::formatSize($verifyImg["filesize"]).", ".$verifyImg[0]."x".$verifyImg[1]." pixels");
	
			if ($destImg["filesize"]!=$verifyImg["filesize"])	{
				if (intval($destImg["filesize"]) && abs(($verifyImg["filesize"]/$destImg["filesize"])-1) < 0.05)	{
//					debug(abs(($verifyImg["filesize"]/$destImg["filesize"])-1));
					$ex_rows.=$this->getTwinImageMessage("File size is a bit different from reference", $destImg["filesize"], $verifyImg["filesize"]);
					$errorLevels[]=1;
				} else {
					$ex_rows.=$this->getTwinImageMessage("File size is very different from reference", $destImg["filesize"], $verifyImg["filesize"]);
					$errorLevels[]=2;
				}
			}
			if ($destImg[0]!=$verifyImg[0] || $destImg[1]!=$verifyImg[1])	{
				$ex_rows.=$this->getTwinImageMessage("Pixel dimension are not equal!");
				$errorLevels[]=2;
			}
			if ($note)	{
				$ex_rows.=$this->getTwinImageMessage($note[0],$note[1]);
			}
			if ($this->dumpImCommands && count($IMcommands))	{
				$ex_rows.=$this->getTwinImageMessage("ImageMagick commands executed:",$this->formatImCmds($IMcommands));
			}
		} else {
			$ex_rows.=$this->getTwinImageMessage("There was no result from the ImageMagick operation", "Below there's a dump of the ImageMagick commands executed:<BR>".$this->formatImCmds($IMcommands));
			$errorLevels[]=3;
		}			
		$out='<table border=0 cellpadding=0 cellspacing=0 align=center width=300>'.$ex_rows.'</table>';
		
		return array($out,max($errorLevels));
	}
	function getTwinImageMessage($message, $label_1="", $label_2="")	{
		if ($message)	$out.='<tr><td colspan=3><strong>'.$this->fw($message).'</strong></td></tr>';
		if ($label_1 && !$label_2)	{
			$out.='<tr><td colspan=3>'.$this->fw($label_1).'</td></tr>';
		} elseif ($label_1 || $label_2)	{
			$out.='<tr><td>'.$this->fw($label_1).'</td><td></td><td>'.$this->fw($label_2).'</td></tr>';
		}
		return $out;
	}
	function formatImCmds($arr)	{
		$out=array();
		if (is_array($arr))	{
			reset($arr);
			while(list($k,$v)=each($arr))	{
				$out[]=$v[1];
				if ($v[2])	$out[]="   RETURNED: ".$v[2];
			}
		}
		if (count($out))	{
			$col = t3lib_div::intInRange(count($out),2,10);
			$outputStr = '<textarea cols=40 rows='.$col.' wrap="off">'.htmlspecialchars(implode($out,chr(10))).'</textarea>';
			return "<form>".$outputStr."</form>";
		};
	}
	function imagemenu()	{
		$menuitems = array(
			"read" => "Reading image formats",
			"write" => "Writing GIF and PNG",
			"scaling" => "Scaling images",
			"combining" => "Combining images",
			"gdlib" => "GD library functions"
		);
		reset($menuitems);
		$c=0;
		$out=array();
		while(list($k,$v)=each($menuitems))	{
			$bgColor = ($this->INSTALL["images_type"]==$k ? ' bgColor="#ABBBB4"' : ' bgColor="#F4F0E8"');
			$c++;
			$out[]='<tr><td'.$bgColor.'><a href="'.$this->action.'&TYPO3_INSTALL[images_type]='.$k.'#testmenu">'.$this->fw($c.': '.$v).'</a></td></tr>';
		}
		
		$code = '<table border=0 cellpadding=0 cellspacing=1>'.implode($out,"").'</table>';
		$code = '<table border=0 cellpadding=0 cellspacing=0 bgColor="#ABBBB4"><tr><td>'.$code.'</td></tr></table>';
		return '<div align="center">'.$code.'</div>';
	}
	
	
	
	
	
	
	
	
	
	
	
	
	// **********************
	// DATABASE analysing
	// **********************

	function checkTheDatabase()	{
		if (!$this->config_array["mysqlConnect"])	{
			$this->message("Database Analyser","Your database connection failed","
				Please go to the 'Basic Configuration' section and correct this problem first.
			",2);
			echo $this->outputWrapper($this->printAll());
			return;
		} 
		if ($this->config_array["no_database"])	{
			$this->message("Database Analyser","No database selected","
				Please go to the 'Basic Configuration' section and correct this problem first.
			",2);
			echo $this->outputWrapper($this->printAll());
			return;
		} 

			// Getting current tables
		$whichTables=$this->getListOfTables();


			// Getting number of static_template records
		if ($whichTables["static_template"])	{
			$res_static = mysql(TYPO3_db,"SELECT count(*) FROM static_template");
			list($static_template_count) = mysql_fetch_assoc($res_static);
		}
		$static_template_count=intval($static_template_count);

		$headCode ="Database Analyser";
		$this->message($headCode,"What is it?","
			In this section you can get an overview of your currently selected database compared to sql-files. You can also import sql-data directly into the database or upgrade tables from earlier versions of Typo3.
		",0);

		$cInfo="
			Username: <strong>".TYPO3_db_username."</strong>
			Password: <strong>".TYPO3_db_password."</strong>
			Host: <strong>".TYPO3_db_host."</strong>
		";
		$this->message($headCode, "Connected to MySQL successfully","
		".trim($cInfo)."
		",-1,1);
		$this->message($headCode, "Database","
			<strong>".TYPO3_db."</strong> is selected as database. 
			Has <strong>".count($whichTables)."</strong> tables.
		",-1,1);


		// Menu		

		$this->messageFunc_nl2br = 0;
		
		$sql_files = array_merge(t3lib_div::getFilesInDir(PATH_typo3conf,"sql",1,1),t3lib_div::getFilesInDir(PATH_t3lib."install/","sql",1,1));
		
		$action_type = $this->INSTALL["database_type"];
		$actionParts = explode("|",$action_type);
		if (count($actionParts)<2)	{
			$action_type="";
		}

		$out='';
		reset($sql_files);
		$directJump="";
		while(list($k,$file)=each($sql_files))	{
			if ($this->mode=="123" && !count($whichTables) && strstr($file,"_testsite"))	{
				$directJump = $this->action.'&TYPO3_INSTALL[database_type]=import|'.rawurlencode($file);
			}
			$lf=t3lib_div::testInt($k);
			$fShortName = substr($file,strlen(PATH_site));
/*			$spec1 = (!count($whichTables) && $fShortName=="typo3/t3lib/install/tables_".str_replace(".","",$GLOBALS["TYPO_VERSION"]).".sql" ? " <font color=#000066>(1)</font>" : "");
			$spec2 = (count($whichTables) && !$static_template_count && $fShortName=="typo3/t3lib/install/static_template_".str_replace(".","",$GLOBALS["TYPO_VERSION"])."+adt.sql" ? " <font color=#000066>(2)</font>" : "");
			*/
			$out.='<tr>
				<td nowrap>'.$this->fw($fShortName." (".t3lib_div::formatSize(filesize($file)).")").'</td>
				<td'.($action_type=="cmpFile|".$file?' bgColor="#D9D5C9"':'').'>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=cmpFile|'.rawurlencode($file).'#bottom"><strong>COMPARE</strong></a>').'</td>
				<td nowrap'.($action_type=="import|".$file?' bgColor="#D9D5C9"':'').'>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=import|'.rawurlencode($file).'#bottom"><strong>IMPORT'.$spec1.$spec2.'</strong></a>').'</td>
				<td nowrap'.($action_type=="view|".$file?' bgColor="#D9D5C9"':'').'>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=view|'.rawurlencode($file).'#bottom"><strong>VIEW'.$spec1.$spec2.'</strong></a>').'</td>
			</tr>';
		}
			// TCA
		$out.='<tr>
			<td></td>
			<td colspan=3'.($action_type=="cmpTCA|"?' bgColor="#D9D5C9"':'').'><strong>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=cmpTCA|#bottom">Compare with $TCA</a>').'</strong></td>
		</tr>';
		$out.='<tr>
			<td></td>
			<td colspan=3'.($action_type=="adminUser|"?' bgColor="#D9D5C9"':'').'><strong>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=adminUser|#bottom">Create "admin" user</a>').'</strong></td>
		</tr>';
		$out.='<tr>
			<td></td>
			<td colspan=3'.($action_type=="UC|"?' bgColor="#D9D5C9"':'').'><strong>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=UC|#bottom">Reset user preferences</a>').'</strong></td>
		</tr>';
		$out.='<tr>
			<td></td>
			<td colspan=3'.($action_type=="cache|"?' bgColor="#D9D5C9"':'').'><strong>'.$this->fw('<a href="'.$this->action.'&TYPO3_INSTALL[database_type]=cache|#bottom">Clear tables</a>').'</strong></td>
		</tr>';

		$theForm='<table border=0 cellpadding=2 cellspacing=2>'.$out.'</table>';
		$theForm.='<a name="bottom"></a>';

		if ($directJump)	{
			if (!$action_type)	{
				$this->message($headCode, "Menu",'
				<script>
				document.location = "'.$directJump.'";
				</script>',0,1);
			}
		} else {
			$this->message($headCode, "Menu","
			From this menu you can select which of the available SQL files you want to either compare or import/merge with the existing database.<BR><BR>
			<strong>COMPARE:</strong> Compares the tables and fields of the current database and the selected file. It also offers to 'update' the difference found.<BR>
			<strong>IMPORT:</strong> Imports the SQL-dump file into the current database. You can either dump the raw file or choose which tables to import. In any case, you'll see a new screen where you must confirm the operation.<BR>
			<strong>VIEW:</strong> Shows the content of the SQL-file, limiting characters on a single line to a reader-friendly amount.<BR><BR>
			The SQL-files are selected from typo3conf/ (here you can put your own) and t3lib/install/ (Typo3 distribution). The SQL-files should be made by the <em>mysqldump</em> tool or at least be formatted like that tool would do.
	<br>
			<BR>
			".$theForm."
			",0,1);
		}
		
		
	// Install user
	// clear uc
		if ($action_type)	{
			switch($actionParts[0])	{
				case "cmpFile":
					if (@is_file($actionParts[1]))	{
						$fileContent = implode(
							$this->getStatementArray(t3lib_div::getUrl($actionParts[1]),1,"^CREATE TABLE "),
							chr(10)
						);
						$FDfile = $this->getFieldDefinitions_sqlContent($fileContent);
						if (!count($FDfile))	{
							die ("Error: There were no 'CREATE TABLE' definitions in the provided file");
						}

							// Updating database...
						if (is_array($this->INSTALL["database_update"]))	{
							$FDdb = $this->getFieldDefinitions_database(TYPO3_db);
							$diff = $this->getDatabaseExtra($FDfile, $FDdb);
							$update_statements = $this->getUpdateSuggestions($diff);
							$diff = $this->getDatabaseExtra($FDdb, $FDfile);
							$remove_statements = $this->getUpdateSuggestions($diff,"remove");

							$this->preformUpdateQueries($update_statements["add"],$this->INSTALL["database_update"]);
							$this->preformUpdateQueries($update_statements["change"],$this->INSTALL["database_update"]);
							$this->preformUpdateQueries($remove_statements["change"],$this->INSTALL["database_update"]);
							$this->preformUpdateQueries($remove_statements["drop"],$this->INSTALL["database_update"]);

							$this->preformUpdateQueries($update_statements["create_table"],$this->INSTALL["database_update"]);
							$this->preformUpdateQueries($remove_statements["change_table"],$this->INSTALL["database_update"]);
							$this->preformUpdateQueries($remove_statements["drop_table"],$this->INSTALL["database_update"]);
						}
						
							// Init again / first time depending...
						$FDdb = $this->getFieldDefinitions_database(TYPO3_db);
						$diff = $this->getDatabaseExtra($FDfile, $FDdb);
						$update_statements = $this->getUpdateSuggestions($diff);
						$diff = $this->getDatabaseExtra($FDdb, $FDfile);
						$remove_statements = $this->getUpdateSuggestions($diff,"remove");
						$tLabel = "Update database tables and fields";
						
						if ($remove_statements || $update_statements)	{
							$formContent = $this->generateUpdateDatabaseForm("get_form",$update_statements,$remove_statements,$action_type);
							$this->message($tLabel,"Table and field definitions should be updated","
							There seems to be a number of differencies between the database and the selected SQL-file.
							Please select which statements you want to execute in order to update your database:<BR><BR>
							".$formContent."
							",2);
						} else {
							$formContent = $this->generateUpdateDatabaseForm("get_form",$update_statements,$remove_statements,$action_type);
							$this->message($tLabel,"Table and field definitions are OK.","
							The tables and fields in the current database corresponds perfectly to the database in the selected SQL-file.
							",-1);
						}
					}
				break;
				case "cmpTCA":
					$this->includeTCA();
					$this->mysqlVersion = "3.23";	// Set this previously to calling the function below in order to make the rendering right for the comparison.
					$FDdb = $this->getFieldDefinitions_database(TYPO3_db);

						// Displaying configured fields which are not in the database
					$tLabel="Tables and fields in \$TCA, but not in database";
					$cmpTCA_DB = $this->compareTCAandDatabase($GLOBALS["TCA"],$FDdb);
					if (!count($cmpTCA_DB["extra"]))	{
						$this->message($tLabel,"Table and field definitions OK","
						All fields and tables configured in $TCA appeared to exist in the database as well
						",-1);
					} else {
						$this->message($tLabel,"Invalid table and field definitions in \$TCA!","
						There are some tables and/or fields configured in the \$TCA array which does not exist in the database!
						This will most likely cause you trouble with the Typo3 backend interface!
						",3);
						while(list($tableName, $conf)=each($cmpTCA_DB["extra"]))	{
							$this->message($tLabel, $tableName,$this->displayFields($conf["fields"],0,"Suggested database field:"),2);
						}
					}
					
						// Displaying tables that are not setup in 
					$cmpDB_TCA = $this->compareDatabaseAndTCA($FDdb,$GLOBALS["TCA"]);
					$excludeTables="be_sessions,fe_session_data,fe_sessions";
					if (TYPO3_OS=="WIN")	{$excludeTables = strtolower($excludeTables);}
					$excludeFields = array(
						"be_users" => "uc,lastlogin,usergroup_cached_list",
						"fe_users" => "uc,lastlogin,fe_cruser_id",
						"pages" => "SYS_LASTCHANGED",
						"sys_dmail" => "mailContent",
						"tt_board" => "doublePostCheck",
						"tt_guest" => "doublePostCheck",
						"tt_products" => "ordered"
					);
					$tCount=0;
					$fCount=0;
					$tLabel="Tables from database, but not in \$TCA";
					$fLabel="Fields from database, but not in \$TCA";
					$this->message($tLabel);
					if (is_array($cmpDB_TCA[extra]))	{
						while(list($tableName, $conf)=each($cmpDB_TCA[extra]))	{
							if (!t3lib_div::inList($excludeTables,$tableName) 
									&& substr($tableName,0,4)!="sys_" 
									&& substr($tableName,-3)!="_mm" 
									&& substr($tableName,0,6)!="index_" 
									&& substr($tableName,0,6)!="cache_")	{
								if ($conf["whole_table"])	{
									$this->message($tLabel, $tableName,$this->displayFields($conf["fields"]),1);
									$tCount++;
								} else {
									list($theContent, $fC)	= $this->displaySuggestions($conf["fields"],$excludeFields[$tableName]);
									$fCount+=$fC;
									if ($fC)	$this->message($fLabel, $tableName,$theContent,1);
								}	
							}
						}
					}
					if (!$tCount)	{
						$this->message($tLabel,"Correct number of tables in the database","
						There are no extra tables in the database compared to the configured tables in the \$TCA array.
						",-1);
					} else {
						$this->message($tLabel,"Extra tables in the database","
						There are some tables in the database which are not configured in the \$TCA array. 
						You should probably not worry about this, but please make sure that you know what these tables are about and why they are not configured in \$TCA.
						",2);
					}

					if (!$fCount)	{
						$this->message($fLabel,"Correct number of fields in the database","
						There are no additional fields in the database tables compared to the configured fields in the \$TCA array.
						",-1);
					} else {
						$this->message($fLabel,"Extra fields in the database","
						There are some additional fields the database tables which are not configured in the \$TCA array. 
						You should probably not worry about this, but please make sure that you know what these fields are about and why they are not configured in \$TCA.
						",2);
					}
					
						// Displaying actual and suggested field database defitions
					if (is_array($cmpTCA_DB["matching"]))	{
						$tLabel="Comparison between database and \$TCA";
					
						$this->message($tLabel,"Actual and suggested field definitions","
						This table shows you the suggested field definitions which are calculated based on the configuration in \$TCA. 
						If the suggested value differs from the actual current database value, you should not panic, but simply check if the datatype of that field is sufficient compared to the data, you want Typo3 to put there.
						",0);
						while(list($tableName, $conf)=each($cmpTCA_DB["matching"]))	{
							$this->message($tLabel, $tableName,$this->displayFieldComp($conf["fields"], $FDdb[$tableName]["fields"]),1);
						}
					}
				break;
				case "import":
					$mode123Imported=0;
					if (@is_file($actionParts[1]))	{
						$tLabel="Import SQL dump";
							// Getting statement array from
						$statements = $this->getStatementArray(t3lib_div::getUrl($actionParts[1]),1);
						list($statements_table, $insertCount) = $this->getCreateTables($statements,1);

							// Updating database...
						if ($this->INSTALL["database_import_all"])	{
							reset($statements);
							$r=0;
							while(list($k,$v)=each($statements))	{
								$res=mysql(TYPO3_db, $v);
								$err =mysql_error();
								if ($err)	echo $err."<BR>";
								$r++;
							}
							$this->message($tLabel,"Imported ALL","
								Queries: ".$r."
							",1,1);
							if (t3lib_div::GPvar("goto_step"))	{
								$this->action.="&step=".t3lib_div::GPvar("goto_step");
								Header("Location: ".$this->action);
								exit;
							}
						} elseif (is_array($this->INSTALL["database_import"]))	{
								// Traverse the tables
							reset($this->INSTALL["database_import"]);
							while(list($table,$md5str)=each($this->INSTALL["database_import"]))	{
								if ($md5str==md5($statements_table[$table]))	{
									$res=mysql(TYPO3_db, "DROP TABLE IF EXISTS ".$table);
									$err =mysql_error();
									if ($err)	echo $err."<BR>";
									
									$res=mysql(TYPO3_db, $statements_table[$table]);
									$err =mysql_error();
									if ($err)	echo $err."<BR>";

									if ($insertCount[$table])	{
										$statements_insert = $this->getTableInsertStatements($statements, $table);
										reset($statements_insert);
										while(list($k,$v)=each($statements_insert))	{
											$res=mysql(TYPO3_db, $v);
											$err =mysql_error();
											if ($err)	echo $err."<BR>";
										}
									}

									$this->message($tLabel,"Imported '".$table."'","
										Rows: ".$insertCount[$table]."
									",1,1);
								}
							}
						}

						$mode123Imported=$this->isBasicComplete($tLabel);

						if (!$mode123Imported)	{
								// Re-Getting current tables - may have been changed during import
							$whichTables=$this->getListOfTables();
	
							if (count($statements_table))	{
								reset($statements_table);
								$out='';
								while(list($table,$definition)=each($statements_table))	{
									$exist=isset($whichTables[$table]);
									$out.='<tr>
										<td><input type="checkbox" name="TYPO3_INSTALL[database_import]['.$table.']" value="'.md5($definition).'"></td>
										<td><strong>'.$this->fw($table).'</strong></td>
										<td><img src=clear.gif width=10 height=1></td>
										<td nowrap>'.$this->fw($insertCount[$table]?"Rows: ".$insertCount[$table]:"").'</td>
										<td><img src=clear.gif width=10 height=1></td>
										<td nowrap>'.($exist?'<img src="'.$this->backPath.'t3lib/gfx/icon_warning.gif" width=18 height=16 align=top>'.$this->fw("Table exists!"):'').'</td>
										</tr>';
								}
								
								$content ='';
								if ($this->mode!="123")	{
									$content.='<table border=0 cellpadding=0 cellspacing=0>'.$out.'</table>
									<HR>
									';
								}
								$content.='<input type="checkbox" name="TYPO3_INSTALL[database_import_all]" value="1"'.($this->mode=="123"||t3lib_div::GPvar("presetWholeTable")?" checked":"").'>'.$this->fw("Import the whole file '".basename($actionParts[1])."' directly (ignores selections above):").'<BR>
	
								';
								$form = $this->getUpdateDbFormWrap($action_type, $content);
								$this->message($tLabel,"Select tables to import","
								This is an overview of the CREATE TABLE definitions in the SQL file.
								Select which tables you want to dump to the database.
								Any table you choose dump to the database is dropped from the database first, so you'll loose all data in existing tables.
								".$form,1,1);
							} else {
								$this->message($tLabel,"No tables","
								There seems to be no CREATE TABLE definitions in the SQL file. 
								This tool is intelligently creating one table at a time and not just dumping the whole content of the file uncritically. That's why there must be defined tables in the SQL file.
								",3,1);
							}
						}
					}					
				break;
				case "view":
					if (@is_file($actionParts[1]))	{
						$tLabel="Import SQL dump";
							// Getting statement array from
						$sqlContent = t3lib_div::getUrl($actionParts[1]);
						$statements = $this->getStatementArray($sqlContent,1);
						$maxL=1000;
						$strLen = strlen($sqlContent);
						$maxlen = 200+($maxL-t3lib_div::intInRange(($strLen-20000)/100,0,$maxL));
//						debug($maxlen);
						if (count($statements))	{
							reset($statements);
							$out='';
							while(list(,$statement)=each($statements))	{
								$out.=nl2br(htmlspecialchars(t3lib_div::fixed_lgd($statement,$maxlen)).chr(10).chr(10));
							}
						}
						$this->message($tLabel,"Content of ".basename($actionParts[1]),$out,1);
					}					
				break;
				case "adminUser":
					if ($whichTables["be_users"])	{
						if (is_array($this->INSTALL["database_adminUser"]))	{
							$username = ereg_replace("[^[:alnum:]_-]","",trim($this->INSTALL["database_adminUser"]["username"]));
							$username = str_replace(" ","_",$username);
							$pass = trim($this->INSTALL["database_adminUser"]["password"]);
							if ($username && $pass)	{
								$query = "SELECT uid FROM be_users WHERE username='".$username."'";
								$res = mysql(TYPO3_db,$query);
								echo mysql_error();
								if (!mysql_num_rows($res))	{
									$query = "INSERT INTO be_users (username,password,admin,uc,fileoper_perms) VALUES ('".$username."','".md5($pass)."',1,'',7)";
									$res = mysql(TYPO3_db,$query);
									echo mysql_error();
								
									$this->isBasicComplete($headCode);

									$this->message($headCode,"User created",'
									Username: <strong>'.stripslashes($username).'</strong><BR>
									Password: <strong>'.stripslashes($pass).'</strong><BR>
									'.$query
									,1,1);
								} else {
									$this->message($headCode,"Username not unique!",'
									The username, <strong>'.stripslashes($username).'</strong>, was not unique.<BR><BR>
									'.$query
									,2,1);
								}
							}
						}
						$content = '
						<input type="text" name="TYPO3_INSTALL[database_adminUser][username]"> username - unique, no space, lowercase<BR>
						<input type="text" name="TYPO3_INSTALL[database_adminUser][password]"> password
						';
						$form = $this->getUpdateDbFormWrap($action_type, $content);
						$this->message($headCode,"Create admin user","
						Enter username and password for a new admin user.<BR>
						You should use this function only if there are no admin users in the database, for instance if this is a blank database.<BR>
						After you've created the user, log in and add the rest of the user information, like email and real name.<BR>
						<BR>
						".$form."
						",0,1);
					} else {
						$this->message($headCode,"Required table not in database","
						'be_users' must be a table in the database!
						",3,1);
					}
				break;
				case "UC":
					if ($whichTables["be_users"])	{
						if (!strcmp($this->INSTALL["database_UC"],1))	{
							$query = "UPDATE be_users SET uc = ''";
							$res = mysql(TYPO3_db,$query);
							echo mysql_error();
							$this->message($headCode,"Clearing be_users.uc",'
								The following SQL query was preformed:<BR><BR>
								'.$query
								,1);
						}
						$content = '
						<input type="checkbox" name="TYPO3_INSTALL[database_UC]" value=1 checked> Clear be_users preferences ("uc" field)
						';
						$form = $this->getUpdateDbFormWrap($action_type, $content);
						$this->message($headCode,"Clear user preferences","
						If you press this button all backend users from the tables be_users will have their user preferences cleared (field 'uc' set to an empty string).<BR>
						This may come in handy in rare cases where that configuration may be corrupt.<BR>
						Clearing this will clear all user settings from the 'Setup' module.<BR>
						<BR>
						".$form);
					} else {
						$this->message($headCode,"Required table not in database","
						'be_users' must be a table in the database!
						",3);
					}
				break;
				case "cache":
					$tableListArr = explode(",","cache_pages,cache_pagesection,cache_hash,--div--,index_words,index_rel,index_phash,index_grlist,index_section,index_fulltext,--div--,sys_log,sys_stat,sys_history,--div--,be_sessions,fe_sessions,fe_session_data,--div--,sys_dmail_maillog,--div--,sys_products_orders,sys_products_orders_mm_tt_products");
					
					if (is_array($this->INSTALL["database_clearcache"]))	{
						$qList=array();
						reset($tableListArr);
						while(list(,$table)=each($tableListArr))	{
							if ($table!="--div--")	{
								$table_c = TYPO3_OS=="WIN" ? strtolower($table) : $table;
								if ($this->INSTALL["database_clearcache"][$table] && $whichTables[$table_c])	{
									$query = "DELETE FROM ".$table;
									$qList[] = $query;
									$res = mysql(TYPO3_db,$query);
									echo mysql_error();
								}
							}
						}
						if (count($qList))	{
							$this->message($headCode,"Clearing cache",'
							The following SQL queries were preformed:<BR><BR>
							'.implode($qList,"<BR>")
							,1);
						}
					}
						// Count entries and make checkboxes
					$labelArr = array(
						"cache_pages" => "Pages",
						"cache_pagesection" => "TS template related information",
						"cache_hash" => "Multipurpose md5-hash cache",
						"sys_log" => "Backend action logging",
						"sys_stat" => "Page hit statistics",
						"sys_history" => "Addendum to the sys_log which tracks ALL changes to content through TCE. May become huge by time. Is used for rollback (undo) and the WorkFlow engine.",
						"be_sessions" => "Backend User sessions",
						"fe_sessions" => "Frontend User sessions",
						"fe_session_data" => "Frontend User sessions data",
						"sys_dmail_maillog" => "Direct Mail log",
						"sys_products_orders" => "tt_product orders",
						"sys_products_orders_mm_tt_products" => "relations between tt_products and sys_products_orders"
					);

					$checkBoxes=array();
					$countEntries=array();
					reset($tableListArr);
					while(list(,$table)=each($tableListArr))	{
						if ($table!="--div--")	{
							$table_c = TYPO3_OS=="WIN" ? strtolower($table) : $table;
							if ($whichTables[$table_c])	{
								$query = "SELECT count(*) FROM ".$table;
								$res = mysql(TYPO3_db,$query);
								list($countEntries[$table]) = mysql_fetch_row($res);
									// Checkboxes:
								$checkBoxes[]= '<input type="checkbox" name="TYPO3_INSTALL[database_clearcache]['.$table.']" value="1"'.($this->INSTALL["database_clearcache"][$table]||$GLOBALS["HTTP_GET_VARS"]["PRESET"]["database_clearcache"][$table]?" checked":"").'> <strong>'.$table.'</strong> ('.$countEntries[$table].' rows) - '.$labelArr[$table];
							}
						} else {
								$checkBoxes[]= 	'<HR>';
						}
					}

					$content = implode("<BR>",$checkBoxes)."<BR><BR>";
					
					$form = $this->getUpdateDbFormWrap($action_type, $content);
					$this->message($headCode,"Clear out selected tables",'
					Pressing this button will delete all records from the selected tables.<BR>
					<BR>
					'.$form.'
					');
				break;
			}
		}

		echo $this->outputWrapper($this->printAll());			
	}
	function isBackendAdminUser() {
		$query="SELECT count(*) FROM be_users WHERE admin";
		$res=mysql(TYPO3_db,$query);
		$row = mysql_fetch_assoc($res);
		return current($row);
	}
	function isStaticTemplates()	{
		$query="SELECT count(*) FROM static_template";
		$res=mysql(TYPO3_db,$query);
		$row = mysql_fetch_assoc($res);
		return current($row);
	}
	function isBasicComplete($tLabel)	{
		if ($this->mode=="123")	{
			$tables = $this->getListOfTables();

			if (count($tables))	{
				$beuser = $this->isBackendAdminUser();
				$static = $this->isStaticTemplates();
			}
			if (count($tables) && $beuser && $static)	{
				$mode123Imported=1;
				$this->message($tLabel,"Basic Installation Completed",nl2br($this->messageBasicFinished()),-1,1);
				$this->message($tLabel,"Security Risk!",nl2br($this->securityRisk().$this->alterPasswordForm()),2,1);
			} else {
				$this->message($tLabel,"Still missing something?",nl2br("
				You may be missing one of these points before your Typo3 installation is complete:

				".(count($tables)?"":"- You haven't imported any tables yet.
				")
				.($static?"":"- You haven't imported the static_template table.
				")
				.($beuser?"":"- You haven't created an admin-user yet.
				")
				."
				
				You you're about to import a database with a complete site in it, these three points should be met.
				"),-1,1);
			}
		}
		return $mode123Imported;
	}
	function getListOfTables()	{
		$whichTables=array();
		$tables_result=mysql_list_tables(TYPO3_db); 
		if (!mysql_error())	{
			while ($theTable=mysql_fetch_assoc($tables_result)) {
				$whichTables[current($theTable)]=current($theTable);
			}
		}
		return $whichTables;
	}
	function generateUpdateDatabaseForm($type, $arr_update, $arr_remove, $action_type)	{
		switch($type)	{
			case "get_form":
				$content="";
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_update["add"],"Add fields");
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_update["change"],"Changing fields",1,0,$arr_update["change_currentValue"]);
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_remove["change"],"Remove unused fields (rename with prefix)",0,1);
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_remove["drop"],"Drop fields (really!)",0);
				
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_update["create_table"],"Add tables");
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_remove["change_table"],"Removing tables (rename with prefix)",0,1);
				$content.=$this->generateUpdateDatabaseForm_checkboxes($arr_remove["drop_table"],"Drop tables (really!)",0);

				$form = $this->getUpdateDbFormWrap($action_type, $content);
				return $form;
			break;
			default:
			
			break;
		}
	}
	function getUpdateDbFormWrap($action_type, $content, $label="Write to database")	{
		$form = '<form action="'.$this->action.'#bottom" method="POST"><input type="hidden" name="TYPO3_INSTALL[database_type]" value="'.htmlspecialchars($action_type).'">'.$content.'<BR><input type="submit" value="'.$label.'">';
		return $form;
	}
	function generateUpdateDatabaseForm_checkboxes($arr,$label,$checked=1,$iconDis=0,$currentValue=array())	{
		$out="";
		if (is_array($arr))	{
			reset($arr);
			while(list($key,$string)=each($arr))	{
				$ico="";
				if ($iconDis)	{
					if (stristr($string,"user_"))	{
						$ico.= '<img src="'.$this->backPath.'t3lib/gfx/icon_warning.gif" width=18 height=16 align=top><strong>(USER) </strong>';
					}
					if (stristr($string," app_"))	{
						$ico.= '<img src="'.$this->backPath.'t3lib/gfx/icon_warning.gif" width=18 height=16 align=top><strong>(APP) </strong>';
					}
					if (stristr($string," ttx_"))	{
						$ico.= '<img src="'.$this->backPath.'t3lib/gfx/icon_warning.gif" width=18 height=16 align=top><strong>(EXT) </strong>';
					}
				}
				$out.='<tr><td valign=top><input type="checkbox" name="TYPO3_INSTALL[database_update]['.$key.']" value="1"'.($checked?' checked':'').'></td><td nowrap>'.$this->fw(nl2br($ico.$string)).'</td></tr>';
				if (isset($currentValue[$key]))	{
					$out.='<tr><td valign=top></td><td nowrap>'.$this->fw(nl2br("<font color=#666666>Current value: <em>".$currentValue[$key]."</em></font>")).'</td></tr>';
				}
			}
			$content.='<BR><div align="center"><strong>'.$this->fw($label,3).'</strong></div><BR><table border=0 cellpadding=2 cellspacing=2>'.$out.'</table>';
		}
		return $content;
	}
	function preformUpdateQueries($arr,$keyArr)	{
		if (is_array($arr))	{
			reset($arr);
			while(list($key,$string)=each($arr))	{
				if (isset($keyArr[$key]) && $keyArr[$key])	{
					$res = mysql(TYPO3_db,$string);
					$err = mysql_error();
					if ($err)	echo $err."<BR>";
				}
			}
		}
	}
	function displayFields($arr, $pre=0, $label="")	{
		$out="";
		$out.='<tr><td bgcolor="#9BA1A8" align=center><strong>'.$this->fw("Field name:").'</strong></td><td bgcolor="#9BA1A8" align=center><strong>'.$this->fw($label?$label:"Info:").'</strong></td></tr>';
		if (is_array($arr))	{
			reset($arr);
			while(list($fieldname, $fieldContent)=each($arr))	{
				if ($pre)	{
					$fieldContent = '<pre>'.trim($fieldContent).'</pre>';
				} else {
					$fieldContent = $this->fw($fieldContent);
				}
				$out.='<tr><td bgcolor="#ABBBB4">'.$this->fw($fieldname).'</td><td bgcolor="#ABBBB4">'.$fieldContent.'</td></tr>';
			}
		}
		$out= '<table border=0 cellpadding=0 cellspacing=0>'.$out.'</table>';
		return $out;
	}	
	function displayFieldComp($arr, $arr_db)	{
		$out="";
		$out.='<tr><td bgcolor="#9BA1A8" align=center><strong>'.$this->fw("Field name:").'</strong></td>
			<td bgcolor="#9BA1A8" align=center><strong>'.$this->fw("Suggested value from \$TCA:").'</strong></td>
			<td bgcolor="#9BA1A8" align=center><strong>'.$this->fw("Actual value from database:").'</strong></td>
			</tr>';
		if (is_array($arr))	{
			reset($arr);
			while(list($fieldname, $fieldContent)=each($arr))	{
					// This tries to equalize the types tinyint and int
				$str1 = $fieldContent;
				$str2 = trim($arr_db[$fieldname]);
				$str1 = str_replace("tinyint(3)","tinyint(4)",$str1);
				$str2 = str_replace("tinyint(3)","tinyint(4)",$str2);
				$str1 = str_replace("int(10)","int(11)",$str1);
				$str2 = str_replace("int(10)","int(11)",$str2);
					// Compare:
				if (strcmp($str1,$str2))	{
					$bgColor=' bgcolor="#ABBBB4"';
				} else {
					$bgColor=' bgcolor="#D9D5C9"';
				}
				$fieldContent = $this->fw($fieldContent);
				$fieldContent_db = $this->fw($arr_db[$fieldname]);
				$out.='<tr>
					<td bgcolor="#D9D5C9">'.$this->fw($fieldname).'</td>
					<td'.$bgColor.'>'.$fieldContent.'</td>
					<td'.$bgColor.'>'.$fieldContent_db.'</td>
					</tr>';
			}
		}
		$out= '<table border=0 cellpadding=2 cellspacing=2>'.$out.'</table>';
		return $out;
	}	
	function displaySuggestions($arr, $excludeList="")	{
		$out="";
		$out.='<tr><td bgcolor="#9BA1A8" align=center><strong>'.$this->fw("Field name:").'</strong></td><td bgcolor="#9BA1A8" align=center><strong>'.$this->fw("Info / Suggestion for the field:").'</strong></td></tr>';
		$fC=0;
		if (is_array($arr))	{
			reset($arr);
			while(list($fieldname, $fieldContent)=each($arr))	{
				if (!t3lib_div::inList($excludeList,$fieldname) && substr($fieldname,0,strlen($this->deletedPrefixKey))!=$this->deletedPrefixKey && substr($fieldname,-1)!=".")	{
					$fieldContent = $this->fw($fieldContent);
					if ($arr[$fieldname."."])	{
						$fieldContent.= '<HR>';
						$fieldContent.= '<pre>'.trim($arr[$fieldname."."]).'</pre>';
					}
					$out.='<tr><td bgcolor="#ABBBB4">'.$this->fw($fieldname).'</td><td bgcolor="#ABBBB4">'.$fieldContent.'</td></tr>';
					$fC++;
				}
			}
		}
		$out= '<table border=0 cellpadding=2 cellspacing=2>'.$out.'</table>';
		return array($out,$fC);
	}	

	
	function getCreateTables($statements, $insertCountFlag=0)	{
		reset($statements);
		$crTables=array();
		while(list($line,$linecontent)=each($statements))	{
			if (eregi("^create[[:space:]]*table[[:space:]]*([[:alnum:]_]*)",substr($linecontent,0,100),$reg))	{
				$table = trim($reg[1]);
				if ($table)	{
					if (TYPO3_OS=="WIN")	{$table=strtolower($table);}	// tablenames are always lowercase on windows!
					$crTables[$table] = $linecontent;
				}
			} elseif ($insertCountFlag && eregi("^insert[[:space:]]*into[[:space:]]*([[:alnum:]_]*)",substr($linecontent,0,100),$reg))	{
				$nTable = trim($reg[1]);
				$insertCount[$nTable]++;
			}
		}
		return array($crTables,$insertCount);
	}

	function getTableInsertStatements($statements, $table)	{
		reset($statements);
//		$str="INSERT INTO ".strtoupper($table);
		$outStatements=array();
		while(list($line,$linecontent)=each($statements))	{
			if (eregi("^insert[[:space:]]*into[[:space:]]*([[:alnum:]_]*)",substr($linecontent,0,100),$reg))	{
				$nTable = trim($reg[1]);
				if ($nTable && !strcmp($table,$nTable))	{
					$outStatements[]=$linecontent;
				}
			}
/*			if (strtoupper(substr(trim($linecontent),0,strlen($str)))==$str)	{
				$outStatements[]=$linecontent;
			}*/
		}
		return $outStatements;
	}
	/**
	 * Returns an array where every entry is a single sql-statement. Input must be formatted like an ordinary MySQL-dump files
	 *
	 * @param	string	$sqlcode	The sql-file content. Provided that 1) every query in the input is ended with ";" and that a line in the file contains only one query or a part of a query.
	 */
	function getStatementArray($sqlcode,$removeNonSQL=0,$query_regex="")	{
		$sqlcodeArr = explode(chr(10),$sqlcode);
		
		// Based on the assumption that the sql-dump has 
		$statementArray=array();
		$statementArrayPointer=0;
		reset($sqlcodeArr);
		while(list($line,$linecontent)=each($sqlcodeArr))	{
			if (substr(trim($linecontent),0,16)=="# Server version")	{
				$this->mysqlVersion=doubleval(substr(trim($linecontent),16));
			}
			$is_set=0;
			if (!$removeNonSQL || (strcmp(trim($linecontent),"") && substr(trim($linecontent),0,1)!="#"))	{
				$statementArray[$statementArrayPointer].=$linecontent;
				$is_set=1;
			}
			if (substr(trim($linecontent),-1)==";")	{
				if (isset($statementArray[$statementArrayPointer]))	{
					if (!trim($statementArray[$statementArrayPointer]) || ($query_regex && !eregi($query_regex,trim($statementArray[$statementArrayPointer]))))	{
						unset($statementArray[$statementArrayPointer]);
					}
				}
				$statementArrayPointer++;
			} elseif ($is_set) {
				$statementArray[$statementArrayPointer].=chr(10);
			}
		}
		return $statementArray;
	}
	
	/**
	 * Converts a result row with field information into the SQL field definition string
	 */
	function assembleFieldDefinition($row)	{
		$field[] = $row["Type"];
		if ($this->mysqlVersion=="3.23" && !$row["Null"])	{
			$field[] = "NOT NULL";
		}
		if (!strstr($row["Type"],"blob") && !strstr($row["Type"],"text"))	{
			// This code will return a default value if the sql-file version is not 3.23 and the field is not auto-incremented. In 3.23 files, the auto-incremented fields do not have a default definition.
			// Furthermore if the file is 3.22 the default value of auto-incremented fields are expected to always be zero which is why the default value is passed through intval(). Thus it should work on 3.23 MySQL servers.
			if ($this->mysqlVersion!="3.23" || !stristr($row["Extra"],"auto_increment"))	{
				$field[] = ($this->mysqlVersion=="3.23"?"default":"DEFAULT")." '".(stristr($row["Extra"],"auto_increment")?intval($row["Default"]):addslashes($row["Default"]))."'";	
			}
		}
		if ($this->mysqlVersion!="3.23" && !$row["Null"])	{
			$field[] = "NOT NULL";
		}
		if ($row["Extra"])	{
			$field[] = $row["Extra"];
		}
		return implode($field," ");
	}
	
	/**
	 * Reads the field definitions for the current database
	 *
	 * @param	string	$database	database name to get content from.
	 */
	function getFieldDefinitions_database($database)	{
		$total=array();
		mysql_select_db($database); 
		echo mysql_error();
		$tables=mysql_list_tables($database); 
		while ($tableRow=mysql_fetch_assoc($tables))	{
				// Fields:
			$columns_res = mysql($database, "show columns from ".current($tableRow));
			while($fieldRow=mysql_fetch_assoc($columns_res))	{
				$total[current($tableRow)]["fields"][$fieldRow["Field"]] = $this->assembleFieldDefinition($fieldRow);
			}
				// Keys:
			$keyRes = mysql(TYPO3_db, "show keys from ".current($tableRow));
			while($keyRow=mysql_fetch_assoc($keyRes))	{
				$tempKeys[current($tableRow)][$keyRow["Key_name"]][$keyRow["Seq_in_index"]] = $keyRow["Column_name"];
				$tempKeysPrefix[current($tableRow)][$keyRow["Key_name"]]= ($keyRow["Key_name"]=="PRIMARY"?"PRIMARY KEY":($keyRow["Non_unique"]?"KEY":"UNIQUE")." ".$keyRow["Key_name"]);
//				debug($keyRow);
			}
		}
			// Compile information:
//		debug($tempKeys);
		if (is_array($tempKeys))	{
			reset($tempKeys);
			while(list($table,$keyInf)=each($tempKeys))	{
				reset($keyInf);
				while(list($kName,$index)=each($keyInf))	{
					ksort($index);
					$total[$table]["keys"][$kName]=$tempKeysPrefix[$table][$kName]." (".implode($index,",").")";
				}
			}
		}
//		debug($total["index_phash"]);
		return $total;
	}

	/**
	 * Reads the field definitions for the input sql-file string
	 *
	 * @param	string	$sqlContent		Should be a string read from an sql-file made with 'mysqldump [database_name] -d'
	 */
	function getFieldDefinitions_sqlContent($sqlContent)	{
		$lines = t3lib_div::trimExplode(chr(10), $sqlContent,1);
		reset($lines);
		$isTable="";
		while(list(,$value)=each($lines))	{
			if ($value[0]!="#")	{
				if (!$isTable)	{
					$parts = explode(" ",$value);
					if ($parts[0]=="CREATE" && $parts[1]=="TABLE")	{
						$isTable=$parts[2];
						if (TYPO3_OS=="WIN")	{$isTable=strtolower($isTable);}	// tablenames are always lowercase on windows!
					}
				} else {
					if (substr($value,0,1)==")" && substr($value,-1)==";")	{
						$isTable="";
					} else {
						$lineV=ereg_replace(",$","",$value);
						$parts = explode(" ",$lineV,2);
						if ($parts[0]!="PRIMARY" && $parts[0]!="KEY" && $parts[0]!="UNIQUE")	{
							$total[$isTable]["fields"][$parts[0]]=$parts[1];
						} else {
							$newParts=explode(" ",$parts[1],2);
							$total[$isTable]["keys"][($parts[0]=="PRIMARY"?$parts[0]:$newParts[0])]=$lineV;
						}
					}
				}
			}
		}
//		debug("sql");
//		debug($total["index_phash"]);
		return $total;
	}

	/**
	 * Compares two arrays with field information
	 * 
	 * Returns an array with 1) all elements from $FSsrc that is not in $FDcomp (in key "extra") and 2) all elements from $FSsrc that is difference from the ones in $FDcomp
	 */
	function getDatabaseExtra($FDsrc, $FDcomp)	{
		$extraArr=array();
		$diffArr=array();
		if (is_array($FDsrc))	{
			reset($FDsrc);
			while(list($table,$info)=each($FDsrc))	{
				if (!isset($FDcomp[$table]))	{
					$extraArr[$table]=$info;		// If the table was not in the FDcomp-array, the result array is loaded with that table.
					$extraArr[$table]["whole_table"]=1;
				} else {
					$keyTypes = explode(",","fields,keys");
					while(list(,$theKey)=each($keyTypes))	{
						if (is_array($info[$theKey]))	{
							reset($info[$theKey]);
							while(list($fieldN,$fieldC)=each($info[$theKey]))	{
								if (!isset($FDcomp[$table][$theKey][$fieldN]))	{
									$extraArr[$table][$theKey][$fieldN]=$fieldC;
								} elseif (strcmp($FDcomp[$table][$theKey][$fieldN], $fieldC)){
									$diffArr[$table][$theKey][$fieldN]=$fieldC;
									$diffArr_cur[$table][$theKey][$fieldN]=$FDcomp[$table][$theKey][$fieldN];
								}
							}
						}
					}
				}
			}
		}
		return array("extra"=>$extraArr, "diff"=>$diffArr, "diff_currentValues"=>$diffArr_cur);
	}

	/**
	 * Compares an array with field definitions with $TCA array
	 */
	function compareDatabaseAndTCA($FDsrc, $TCA, $onlyFields=0)	{
		$extraArr=array();
		if (is_array($FDsrc))	{
			reset($FDsrc);
			while(list($table,$info)=each($FDsrc))	{
				t3lib_div::loadTCA($table);
				if (!isset($TCA[$table]))	{
					if (!$onlyFields)	{
						$extraArr[$table]=$info;		// If the table was not in the FDcomp-array, the result array is loaded with that table.
						$extraArr[$table]["whole_table"]=1;
						unset($extraArr[$table]["keys"]);
					}
				} else {
					$theKey="fields";
					$excludeListArr=array();
					if (is_array($TCA[$table]["ctrl"]["enablecolumns"]))	$excludeListArr[]=$TCA[$table]["ctrl"]["enablecolumns"];
					$excludeListArr[]=$TCA[$table]["ctrl"]["tstamp"];
					$excludeListArr[]=$TCA[$table]["ctrl"]["sortby"];
					$excludeListArr[]=$TCA[$table]["ctrl"]["delete"];
					$excludeListArr[]=$TCA[$table]["ctrl"]["cruser_id"];
					$excludeListArr[]=$TCA[$table]["ctrl"]["crdate"];
					$excludeListArr[]="uid";
					$excludeListArr[]="pid";
					if ($table=="pages")	{
						$excludeListArr[]="perms_userid";
						$excludeListArr[]="perms_groupid";
						$excludeListArr[]="perms_user";
						$excludeListArr[]="perms_group";
						$excludeListArr[]="perms_everybody";
					}
					if ($table=="sys_dmail")	{
						$excludeListArr[]="scheduled";
						$excludeListArr[]="scheduled_begin";
						$excludeListArr[]="scheduled_end";
						$excludeListArr[]="query_info";
					}
					
					if (is_array($info[$theKey]))	{
						reset($info[$theKey]);
						while(list($fieldN,$fieldC)=each($info[$theKey]))	{
							if (!isset($TCA[$table]["columns"][$fieldN]) && !in_array($fieldN,$excludeListArr))	{
								$extraArr[$table][$theKey][$fieldN] = $info["fields"][$fieldN];
								$extraArr[$table][$theKey][$fieldN."."]=$this->suggestTCAFieldDefinition($fieldN,$fieldC);
							}
						}
					}
				}
			}
		}
		return array("extra"=>$extraArr);
	}

	/**
	 * Compares the $TCA array with a field definition array
	 */
	function compareTCAandDatabase($TCA, $FDcomp)	{
		$extraArr=array();
		$matchingArr=array();
		if (is_array($TCA))	{
			reset($TCA);
			while(list($table)=each($TCA))	{
				t3lib_div::loadTCA($table);
				$info=$TCA[$table];
				if (!isset($FDcomp[$table]))	{
//					$extraArr[$table]=$info;		// If the table was not in the FDcomp-array, the result array is loaded with that table.
					$extraArr[$table]["whole_table"]=1;
				} else {
					reset($info["columns"]);
					while(list($fieldN,$fieldC)=each($info["columns"]))	{
						$fieldDef = $this->suggestFieldDefinition($fieldC);
						if (!is_array($fieldDef))	{
							if (!isset($FDcomp[$table]["fields"][$fieldN]))	{
								$extraArr[$table]["fields"][$fieldN]=$fieldDef;
							} else {
								$matchingArr[$table]["fields"][$fieldN]=$fieldDef;
							}
						}
					}
				}
			}
		}
		return array("extra"=>$extraArr, "matching"=>$matchingArr);
	}

	/**
	 * Returns an array with SQL-statements that is needed to update according to the diff-array
	 */
	function getUpdateSuggestions($diffArr,$keyList="extra,diff")	{
		$statements=array();
		$deletedPrefixKey=$this->deletedPrefixKey;
		$remove=0;
		if ($keyList == "remove")	{
			$remove=1;
			$keyList="extra";
		}
		$keyList = explode(",",$keyList);
		while(list(,$theKey)=each($keyList))	{
			if (is_array($diffArr[$theKey]))	{
				reset($diffArr[$theKey]);
				while(list($table,$info)=each($diffArr[$theKey]))	{
					$whole_table=array();
					if (is_array($info["fields"]))	{
						reset($info["fields"]);
						while(list($fN,$fV)=each($info["fields"]))	{
							if ($info["whole_table"])	{
								$whole_table[]=$fN." ".$fV;
							} else {
								if ($theKey=="extra")	{
									if ($remove)	{
										if (substr($fN,0,strlen($deletedPrefixKey))!=$deletedPrefixKey)	{
											$statement = "ALTER TABLE ".$table." CHANGE ".$fN." ".$deletedPrefixKey.$fN." ".$fV.";";
											$statements["change"][md5($statement)] = $statement;
										} else {
											$statement = "ALTER TABLE ".$table." DROP ".$fN.";";
											$statements["drop"][md5($statement)] = $statement;
										}
									} else {
										$statement = "ALTER TABLE ".$table." ADD ".$fN." ".$fV.";";
										$statements["add"][md5($statement)] = $statement;
									}
								} elseif ($theKey=="diff") {
									$statement = "ALTER TABLE ".$table." CHANGE ".$fN." ".$fN." ".$fV.";";
									$statements["change"][md5($statement)] = $statement;
									$statements["change_currentValue"][md5($statement)] = $diffArr["diff_currentValues"][$table]["fields"][$fN];
								}
							}
						}
					}
					if (is_array($info["keys"]))	{
						reset($info["keys"]);
						while(list($fN,$fV)=each($info["keys"]))	{
							if ($info["whole_table"])	{
								if ($fN=="PRIMARY")	{
//									$whole_table[]="PRIMARY KEY ".$fV;
									$whole_table[]=$fV;
								} else {
//									$whole_table[]="KEY ".$fN." ".$fV;
									$whole_table[]=$fV;
								}
							} else {
								if ($theKey=="extra")	{
									if ($remove)	{
										$statement = "ALTER TABLE ".$table." DROP KEY ".$fN.";";
										$statements["drop"][md5($statement)] = $statement;
									} else {
//										$statement = "ALTER TABLE ".$table." ADD KEY ".$fN." ".$fV.";";
										$statement = "ALTER TABLE ".$table." ADD ".$fV.";";
										$statements["add"][md5($statement)] = $statement;
									}
								} elseif ($theKey=="diff") {
									$statement = "ALTER TABLE ".$table." DROP KEY ".$fN.";";
									$statements["change"][md5($statement)] = $statement;
//									$statement = "ALTER TABLE ".$table." ADD KEY ".$fN." ".$fV.";";
									$statement = "ALTER TABLE ".$table." ADD ".$fV.";";
									$statements["change"][md5($statement)] = $statement;
								}
							}
						}
					}
					if ($info["whole_table"])	{
						if ($remove)	{
							if (substr($table,0,strlen($deletedPrefixKey))!=$deletedPrefixKey)	{
								$statement = "ALTER TABLE ".$table." RENAME ".$deletedPrefixKey.$table.";";
								$statements["change_table"][md5($statement)]=$statement;
							} else {
								$statement = "DROP TABLE ".$table.";";
								$statements["drop_table"][md5($statement)]=$statement;
							}
						} else {
							$statement = "CREATE TABLE ".$table." (\n".implode($whole_table,",\n")."\n) TYPE=MyISAM;";
							$statements["create_table"][md5($statement)]=$statement;
						}
					}
				}
			}
		}
		return $statements;
	}
	
	/**
	 * Suggests a field definition for a TCA config array.
	 */
	function suggestFieldDefinition($fieldInfo)	{
		$out="";
		switch($fieldInfo["config"]["type"])	{
			case "input":
				if (ereg("date|time|int|year",$fieldInfo["config"]["eval"]))	{
					$us=ereg("date|time",$fieldInfo["config"]["eval"]) ? " unsigned" : "";
					$out = "int(11)".$us." NOT NULL default '0'";
				} else {
					$max = intval($fieldInfo["config"]["max"]);
					if ($max>0 && $max<200)	{
						$out = "varchar(".$max.") NOT NULL default ''";
					} else {
						$out = "tinytext NOT NULL";
					}
				}
			break;
			case "text":
				$out = "text NOT NULL";
			break;
			case "check":
				if (is_array($fieldInfo["config"]["items"]) && count($fieldInfo["config"]["items"])>8)	{
					$out = "int(11) unsigned NOT NULL default '0'";
				} else {
					$out = "tinyint(3) unsigned NOT NULL default '0'";
				}
			break;
			case "radio":
				if (is_array($fieldInfo["config"]["items"]))	{
					$out = $this->getItemArrayType($fieldInfo["config"]["items"]);
				} else {
					$out = "ERROR: Radiobox did not have items!";
				}
			break;
			case "group":
				if ($fieldInfo["config"]["internal_type"]=="db")	{
					$max = t3lib_div::intInRange($fieldInfo["config"]["maxitems"],1,10000);
					if (count(explode(",",$fieldInfo["config"]["allowed"]))>1)	{
						$len = $max*(10+1+5+1);		// Tablenames are 10, "_" 1, uid's 5, comma 1
						$out=$this->getItemBlobSize($len);
					} elseif ($max<=1) {
						$out = "int(11) unsigned NOT NULL default '0'";
					} else {
						$len = $max*(5+1);		// uid's 5, comma 1
						$out=$this->getItemBlobSize($len);
					}
				}
				if ($fieldInfo["config"]["internal_type"]=="file")	{
					$max = t3lib_div::intInRange($fieldInfo["config"]["maxitems"],1,10000);
					$len = $max*(30+1);		// Filenames is 30+ chars....
					$out=$this->getItemBlobSize($len);
				}
			break;
			case "select":
				$max = t3lib_div::intInRange($fieldInfo["config"]["maxitems"],1,10000);
				if ($max<=1)	{
					if ($fieldInfo["config"]["foreign_table"])	{
						$out = "int(11) unsigned NOT NULL default '0'";
					} else {
						$out = $this->getItemArrayType($fieldInfo["config"]["items"]);
					}
				} else {
						// five chars (special=10) + comma:
					$len = $max*(($fieldInfo["config"]["special"]?10:5)+1);
					$out=$this->getItemBlobSize($len);
				}
			break;
			default:
			break;
		}
		return $out?$out:$fieldInfo;
	}

	/**
	 * Private
	 */
	function getItemArrayType($arr)	{
		if (is_array($arr))	{
			reset($arr);
			$type[]=0;
			$intSize[]=0;
			while(list(,$item)=each($arr))	{
				if (!t3lib_div::testInt($item[1]) && $item[1]!="--div--")	{
					$type[]=strlen($item[1]);
				} else {
					$intSize[]=$item[1];
				}
			}
			$us = min($intSize)>=0 ? " unsigned" : "";
			if (max($type)>0)	{
				$out = "varchar(".max($type).") NOT NULL default ''";
			} elseif (max($intSize)>(!$us?127:255))	{
				$out = "int(11)".$us." NOT NULL default '0'";
			} else {
				$out = "tinyint(3)".$us." NOT NULL default '0'";
			}
		}
		return $out;
	}

	/**
	 * Private
	 */
	function getItemBlobSize($len)	{
		return ($len>255 ? "tiny" : "")."blob NOT NULL";
	}

	/**
	 * Should suggest a TCA configuration for a specific field.
	 */
	function suggestTCAFieldDefinition($fieldName,$fieldInfo)	{
		list($type,$len) = split(" |\(|\)",$fieldInfo,3);
		switch($type)	{
			case "int":
$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "input",
		"size" => "8",
		"max" => "20",
		"eval" => "date",
		"default" => "0",
		"checkbox" => "0"
	)
),

----- OR -----

"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "select",	
		"items" => Array (
			Array("[nothing]", 0),
			Array("Extra choice! Only negative values here.", -1),
			Array("__Divider:__", "--div--")
		),
		"foreign_table" => "[some_table_name]"
	)
),';
			break;
			case "varchar":
				if ($len>10)	{
					$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "input",
		"size" => "8",
		"max" => "'.$len.'",
		"eval" => "trim",
		"default" => ""
	)
),';
				} else {
					$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "select",	
		"items" => Array (	
			Array("Item number 1", "key1"),
			Array("Item number 2", "key2"),
			Array("-----", "--div--"),
			Array("Item number 3", "key3")
		),
		"default" => "1"
	)
),';
				}
			break;
			case "tinyint":
					$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "select",	
		"items" => Array (	
			Array("Item number 1", "1"),
			Array("Item number 2", "2"),
			Array("-----", "--div--"),
			Array("Item number 3", "3")
		),
		"default" => "1"
	)
),

----- OR -----

"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "check",
		"default" => "1"
	)
),';
			break;
			case "tinytext":
$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "input",
		"size" => "40",
		"max" => "255",
		"eval" => "",
		"default" => ""
	)
),';
			break;
			case "text":
			case "mediumtext":
$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"config" => Array (
		"type" => "text",
		"cols" => "48",
		"rows" => "5"
	)
),';
			break;
			default:
				$out='
"'.$fieldName.'" => Array (
	"label" => "'.strtoupper($fieldName).':",
	"exclude" => 0,	
	"config" => Array (
		"type" => "input",
		"size" => "30",
		"max" => "",
		"eval" => "",
		"default" => ""
	)
),';
			break;
		}
		return $out?$out:$fieldInfo;
	}

	/**
	 * Includes TCA
	 */
	function includeTCA()	{
		global $TCA;
		
		include (TYPO3_tables_script ? PATH_typo3conf.TYPO3_tables_script : PATH_t3lib."install/tables.php");
		if (TYPO3_extTableDef_script)	{
			include (PATH_typo3conf.TYPO3_extTableDef_script);
		}
	}

	
	
	
	
	
	
	
	
	


	// **********************
	// GENERAL FUNCTIONS
	// **********************


	/**
	 * This creates a link to the given $url. If $link is set, that'll be the link-text
	 */
	function linkIt($url,$link="")	{
		return '<a href="'.$url.'" target="_blank">'.($link?$link:$url).'</a>';
	}

	/**
	 * Setting a message in the message-log and sets the fatalError flag if error type is 3. 
	 */
	function message($head, $short_string="", $long_string="", $type=0, $force=0)	{		// type: -1=OK sign, 0=message, 1=notification, 2=warning , 3=error
		if (!$force && $this->mode=="123" && $type<2)	{return;}	// Return directly if mode-123 is enabled.
		
		if ($type==3)	{$this->fatalError=1;}
		if ($this->messageFunc_nl2br)	{
			$long_string = nl2br(trim($long_string));  
		} else {
			$long_string = trim($long_string);  
		}
		if (!$this->silent)	$this->printSection($head, $short_string, $long_string, $type);
	}

	/**
	 * This "prints" a section with a message to the ->sections array
	 */
	function printSection($head, $short_string, $long_string, $type)	{
		$icon="";

		$bgCol =' bgcolor=#D9D5C9';
		switch($type)	{
			case "3":
				$bgCol =' bgcolor=red';
				$icon = 't3lib/gfx/icon_fatalerror.gif';
			break;
			case "2":
//				$bgCol =' bgcolor=#9BA1A8';
				$icon = 't3lib/gfx/icon_warning.gif';
			break;
			case "1":
//				$bgCol =' bgcolor=#ABBBB4';
				$icon = 't3lib/gfx/icon_note.gif';
			break;
			case "-1":
//				$bgCol =' bgcolor=yellow';
				$icon = 't3lib/gfx/icon_ok.gif';
			break;
			default:
				$bgCol =' bgcolor='.t3lib_div::modifyHTMLcolor("#ABBBB4",+40,+30,+40);
			break;
		}
		if (!trim($short_string))	{
			$this->sections[$head][]="";
		} else {
			$this->sections[$head][]='
			<tr><td'.$bgCol.' nowrap>'.($icon?'<img src="'.$this->backPath.$icon.'" width=18 height=16 align=top>':'').'<strong>'.$this->fw($short_string).'</strong></td></tr>'.(trim($long_string)?'
			<tr><td>'.$this->fw($long_string).'<BR><BR></td></tr>' : '');
		}
	}

	/**
	 * Wraps the str in a font-tag with verdana 1
	 */
	function fw($str,$size=1)	{
		if ($GLOBALS["CLIENT"]["SYSTEM"]=="unix" && $GLOBALS["CLIENT"]["BROWSER"]=="konqu")	{
			return '<font face="sans-serif" size='.($size+2).' color=black>'.$str.'</font>';
		}
		return '<font face="verdana,sans-serif" size='.$size.' color=black>'.$str.'</font>';
	}

	/**
	 * Wrapping labal/content in a table-row.
	 */
	function wrapInCells($label,$content)	{
		return '<tr><td valign=top nowrap><strong>'.$this->fw($label).'</strong></td><td>&nbsp;</td><td valign=top>'.$this->fw($content).'<BR></td></tr>';
	}

	/**
	 * This prints all the messages in the ->section array
	 */
	function printAll()	{
		reset($this->sections);
		$out="";
		while(list($header,$valArray)=each($this->sections))	{
			$out.='
			<tr><td>&nbsp;</td></tr>
			<tr><td><strong><div align="center">'.$this->fw($header.":",2).'</div></strong></td></tr>
			';
			$out.=implode($valArray,chr(10));
		}
		return '<table border=0 cellpadding=2 cellspacing=2>'.$out.'</table>';
	}

	/**
	 * This wraps and returns the main content of the page into proper html-code.
	 */
	function outputWrapper($content)	{
		$out='
<html>


<STYLE TYPE="text/css">
<!--
A:link {text-decoration: none}
A:visited {text-decoration: none}
A:active {text-decoration: none}
A:hover {color: #000066}
-->
</STYLE>
'.$this->headerStyle.'
	<head>
 		<title>Typo3 Install Tool</title>
	</head>
	<body bgcolor="#cccccc" alink="maroon" link="maroon" vlink="maroon">'.$this->contentBeforeTable.'
		<div align="center">
		<table border=0 cellspacing=0 cellpadding=0 width=333 bgcolor="#cccccc">
		<tr>
			<td><img src="'.$this->backPath.'t3lib/typo3logo.gif" width=333 height=43 vspace=10 hspace=50></td>
		</tr>
		<tr>
			<td bgcolor="black">
				<table width="100%" border=0 cellspacing=1 cellpadding=10>
					<tr>
						<td bgcolor=#F4F0E8>
						<font face="verdana,sans-serif" size=4 color=black><strong><div align="center">Typo'.$GLOBALS["TYPO_VERSION"].' Install Tool</div></strong></font>
						<font face="verdana,sans-serif" size=2 color=navy><strong><div align="center">Site: '.$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"].'</div></strong></font><br>
						
'.($this->step?$this->stepHeader():$this->menu()).$content.'<HR>'.$this->note123().$this->endNotes().'						
						</td>
					</tr>
				</table>
			</td>
		</tr>
		</table>
		</div>
	</body>
</html>';
	return $out;
	
	}
	function menu()	{
		if (!$this->passwordOK)	return;
		
		reset($this->menuitems);
		$c=0;
		$out=array();
		while(list($k,$v)=each($this->menuitems))	{
			$bgColor = ($this->INSTALL["type"]==$k ? ' bgColor="#ABBBB4"' : ' bgColor="#F4F0E8"');
			$c++;
			$out[]='<tr><td'.$bgColor.'><a href="'.$this->scriptSelf.'?TYPO3_INSTALL[type]='.$k.($this->mode?"&mode=".rawurlencode($this->mode):"").'">'.$this->fw($c.': '.$v).'</a></td></tr>';
		}
		
		$code = '<table border=0 cellpadding=0 cellspacing=1>'.implode($out,chr(10)).'</table>';
		$code = '<table border=0 cellpadding=0 cellspacing=0 bgColor="#ABBBB4"><tr><td>'.$code.'</td></tr></table>';
		return '<div align="center">'.$code.'</div>';
	}
	function stepHeader()	{
		$msg1='Type in your database parameters here:';
		$msg2='Database';
		$msg3='Import the database sql-file';
		$msg4='You\'re done!';
		$out='<img src="../t3lib/gfx/123_'.$this->step.'.png" width="402" height="73" border="0" alt="" usemap="#id123_print_Map">
<MAP NAME="id123_print_Map">
<AREA title="'.$msg4.'" SHAPE="poly" ALT="" COORDS="299,35, 303,19, 313,9, 335,5, 366,6, 379,11, 388,21, 392,35, 390,47, 381,58, 376,64, 359,67, 320,66, 307,60, 302,51, 300,44" HREF="'.$this->scriptSelf.'?mode='.$this->mode.'&step=go">
<AREA title="'.$msg3.'" SHAPE="circle" ALT="" COORDS="234,36,32" HREF="'.$this->scriptSelf.'?mode='.$this->mode.'&step=3">
<AREA title="'.$msg2.'" SHAPE="circle" ALT="" COORDS="136,37,30" HREF="'.$this->scriptSelf.'?mode='.$this->mode.'&step=2">
<AREA title="'.$msg1.'" SHAPE="circle" ALT="" COORDS="40,36,29" HREF="'.$this->scriptSelf.'?mode='.$this->mode.'&step=1">
</MAP>
		
		
		<BR>';
		$msg="";
		switch(strtolower($this->step))	{
			case 1:
				$msg=$msg1;
			break;
			case 2:
				$msg=$msg2;
			break;
			case 3:
				$msg=$msg3;
			break;
			case "go":
				$msg=$msg4;
			break;
			default:
			break;
		}
		$out.='<BR><div align="center"><strong>'.$this->fw($msg,2).'</strong></div>';
		
		return $out;
	}
	function note123()	{
		if ($this->mode=="123")	{
			$c='<table border=0 cellpadding=0 cellspacing=0 width=100%>
				<tr><td bgcolor=#D9D5C9 nowrap><img src="../t3lib/gfx/icon_note.gif" width=18 height=16 align=top><strong>'.$this->fontTag1.'NOTICE: Install Tool is running in \'123\' mode. <a href="'.$this->scriptSelf.'">Click here to disable.</a></font></strong></td></tr>		
			</table>';
			return $c;
		}
	}
	function endNotes()	{
		if ($this->mode!="123" && $this->passwordOK)	{
			$c.="OS detected: <strong>".(TYPO3_OS=="WIN"?"WIN":"UNIX")."</strong><BR>";
			$c.="UNIX/CGI detected: <strong>".(php_sapi_name()=="cgi" ? "YES" : "NO")."</strong><BR>";
			$c.="PATH_thisScript: <strong>".PATH_thisScript."</strong><BR>";
			$c.="<BR>";
			$c.="<a href='../' target='install_backend'>Backend admin in new window.</a><BR>";
			$c.="<a href='../../' target='install_frontend'>Frontend website in new window.</a><BR>";
		
			return $this->fw($c);
		}
	}
	function convertByteSize($bytes)	{
		if (stristr($bytes,"m"))	{
			$bytes=doubleval($bytes)*1024*1024;
		} elseif (stristr($bytes,"k"))	{
			$bytes=doubleval($bytes)*1024;
		}
		return $bytes;
	}
	function securityRisk()	{
		$c="This script is a <strong>great danger to the security of Typo3</strong> if you don't secure it somehow. 
			We suggest one of the following:
			
			- change the password as defined by the md5-hash in TYPO3_CONF_VARS[BE][installToolPassword].
			- delete the folder 'typo3/install/' with this script in or just insert an 'exit;' line in the script-file there.
			- password protect the 'typo3/install/' folder, eg. with a .htaccess file
			
			The TYPO3_CONF_VARS[BE][installToolPassword] is always active, but choosing one of the other options will improve security and is recommended highly.
		";	
		return $c;
	}
	function alterPasswordForm()	{
			$content = '<form action="'.$this->scriptSelf.'?TYPO3_INSTALL[type]=extConfig" method="POST">
			Enter new password:
			<input type="password" name="TYPO3_INSTALL[extConfig][BE][installToolPassword]"><BR>Enter again:
			<input type="password" name="installToolPassword_check">
			<input type="hidden" name="installToolPassword_md5" value=1>
			<input type="submit" value="Set new password"><br>
			</form>';
			return $content;
	}
	function messageBasicFinished()	{
		$msg ="
				Apparently you have completed the basic setup of the Typo3 database. 
				Now you can choose between these options:
				
				- <a href='../../'><strong>Go to the frontend pages</strong></a>

				- <a href='../?u=admin&p=password'><strong>Go to the backend login</strong></a>
				 (username may be: <i>admin</i>, password may be: <i>password</i>.)

				- <a href='".$this->scriptSelf."'><strong>Continue to configure Typo3</strong></a> (Recommended).
				 This will let you analyse and verify that everything in your PHP installation is alright. Also if you want to configure Typo3 to use all the cool features, you <em>must</em> dig into the this!
				";
		return $msg;
	}
	function setScriptName($type)	{
		$value = $this->scriptSelf."?TYPO3_INSTALL[type]=".$type.($this->mode?"&mode=".rawurlencode($this->mode):"").($this->step?"&step=".rawurlencode($this->step):"");
		return $value;
	}



	function formWidth($size=48,$textarea=0,$styleOverride="") {
			// Input or text-field attribute (size or cols)
		$wAttrib = $textarea?"cols":"size";
		if (!$GLOBALS["CLIENT"]["FORMSTYLE"])	{	// If not setting the width by style-attribute
			$size = ceil($size*1);
			$retVal = ' '.$wAttrib.'="'.$size.'"';
		} else {	// Setting width by style-attribute. "cols" MUST be avoided with NN6+
			$pixels = ceil($size*10);
			$retVal = $styleOverride ? ' style="'.$styleOverride.'"' : ' style="width:'.$pixels.'px;"';
		}
//		debug($retVal);
		return $retVal;
	}
	function formWidthText($size=48,$styleOverride="") {
		return $this->formWidth($size,1,$styleOverride);
	}

}





if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_install.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_install.php"]);
}

?>