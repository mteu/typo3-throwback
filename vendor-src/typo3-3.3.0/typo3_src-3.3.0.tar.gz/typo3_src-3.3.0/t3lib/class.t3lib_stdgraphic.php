<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Standard graphical functions
 *
 * Contains a bunch of cool functions for manipulating graphics with GDlib and ImageMagick
 * Please see another class like gifbuilder / template
 * 
 * VERY OFTEN used with gifbuilder that extends this class and provides a kind of api to using these functions
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_stdGraphic	{
	// This class contains some standard functions for manipulation graphics. It uses ImageMagick and GDlib with FreeType
	var $imageMagickPath = "";		// path to imageMagick, eg: /usr/lib/
	var $tempPath = "typo3temp/";
	var $filenamePrefix="";
	var $imageMagickConvert_forceFileNameBody="";

	var $imageFileExt = "gif,jpg,jpeg,png,tif,bmp,tga,pcx,ai,pdf";
	var $webImageExt = "gif,jpg,jpeg,png";
	var $scalecmd = "-geometry";		//-geometry eller -sample
	var $cmds = Array (
		"jpg" => "-colorspace RGB -sharpen 50 -quality 60",
		"jpeg" => "-colorspace RGB -sharpen 50 -quality 60",
		"gif" => "-colors 64",
		"png" => "-colors 64"
	);
	var $pixelLimitGif = 10000;
	var $mayScaleUp = 1;
	var $maskNegate = "";		// Will be " -negate" if ImageMagick ver 5.2+. See init();
	var $NO_IM_EFFECTS = "";
	var $NO_IMAGE_MAGICK = "";
	var $combineScript = "combine";

	var $dontCheckForExistingTempFile = 0;		// This flag should always be false. If set true, imageMagickConvert will always write a new file to the tempdir! Used for debugging.
	var $dontCompress=0;			// prevents imageMagickConvert() from compressing the gif-files with t3lib_div::gif_compress()
	var $dontUnlinkTempFiles=0;		// for debugging ONLY!
	var $alternativeOutputKey="";		// for debugging only. Filenames will not be based on mtime and only filename (not path) will be used. This key is also included in the hash of the filename...
	
	var $gifExtension = "gif";		// THis should be changed to "png" if you want this class to read/make PNG-files instead!
	var $TTFLocaleConv = "";		// Used to recode input to TTF-functions for other charsets.
	var $enable_typo3temp_db_tracking = 0;
	var $noFramePrepended=0;		// If set, there is no frame pointer prepended to the filenames.
	
	// internal
	var $IM_commands = Array();
	
	var $colMap = Array (
		"aqua" => Array(0,255,255),
		"black" => Array(0,0,0),
		"blue" => Array(0,0,255),
		"fuchsia" => Array(255,0,255),
		"gray" => Array(128,128,128),
		"green" => Array(0,128,0),
		"lime" => Array(0,255,0),
		"maroon" => Array(128,0,0),
		"navy" => Array(0,0,128),
		"olive" => Array(128,128,0),
		"purple" => Array(128,0,128),
		"red" => Array(255,0,0),
		"silver" => Array(192,192,192),
		"teal" => Array(0,128,128),
		"yellow" => Array(255,255,0),
		"white" => Array(255,255,255)
	);

	function prependAbsolutePath($fontFile)	{
		// Checks if the $fontFile is already at an absolute path and if not, prepends the correct path.
		// Use PATH_site unless we are in the backend.
		$absPath = defined("PATH_typo3") ? dirname(PATH_thisScript)."/" :PATH_site;
		$fontFile = substr($fontFile,0,1)=="/" ? $fontFile : $absPath.$fontFile;
		return $fontFile;
	}
	function init()	{
		$gfxConf = $GLOBALS["TYPO3_CONF_VARS"]["GFX"];

		if ($gfxConf["im_combine_filename"])	$this->combineScript=$gfxConf["im_combine_filename"];
		if ($gfxConf["im_noFramePrepended"])	$this->noFramePrepended=1;
		
//	debug($gfxConf);
		if ($gfxConf["gdlib_png"])	{
			$this->gifExtension="png";
		}
		if ($gfxConf["TTFLocaleConv"]) {
			$this->TTFLocaleConv = $gfxConf["TTFLocaleConv"];
		}
		if ($gfxConf["enable_typo3temp_db_tracking"]) {
			$this->enable_typo3temp_db_tracking = $gfxConf["enable_typo3temp_db_tracking"];
		}
		
		$this->imageMagickPath = $gfxConf["im_path"];
		$this->imageFileExt = $gfxConf["imagefile_ext"];
		
			// This should be set if ImageMagick ver. 5+ is used.
		if ($gfxConf["im_negate_mask"])	{
				// Boolean. Indicates if the mask images should be inverted first. 
				// This depends of the ImageMagick version. Below ver. 5.1 this should be false. 
				// Above ImageMagick version 5.2+ it should be true. 
				// Just set the flag if the masks works opposite the intension!
			$this->maskNegate = " -negate";
		}
		if ($gfxConf["im_no_effects"])	{	
				// Boolean. This is necessary if using ImageMagick 5+. 
				// Approved version for using effects is version 4.2.9. 
				// Effects in Imagemagick 5+ tends to render very slowly!! 
				// - therefore must be disabled in order not to perform sharpen, blurring and such.
			$this->NO_IM_EFFECTS = 1;
			$this->cmds["jpg"]  = "-colorspace RGB -quality 60";
			$this->cmds["jpeg"] = "-colorspace RGB -quality 60";
		}
		if (!$gfxConf["im"])	{
			$this->NO_IMAGE_MAGICK = 1;
		}
			// Secures that images are not scaled up.
		if ($gfxConf["im_noScaleUp"]) {
			$this->mayScaleUp=0;
		}
	}
	function randomName()	{
		return $this->tempPath."temp_".md5(uniqid(""));
	}
	function applyOffset($cords,$OFFSET)	{
		$cords[0] = intval($cords[0])+intval($OFFSET[0]);
		$cords[1] = intval($cords[1])+intval($OFFSET[1]);
		return $cords;
	}
	function convertColor($string)	{
		// converts a color to rgb-values. Input-definitions can be "red", "#ffeedd" or "255,0,255"
		// default is 0,0,0
		$col=array();
		$cParts = explode(":",$string,2);
		$string=$cParts[0];
		if (strstr($string,"#"))	{
			$string = ereg_replace("[^A-Fa-f0-9]*","",$string);
			$col[]=HexDec(substr($string,0,2));
			$col[]=HexDec(substr($string,2,2));
			$col[]=HexDec(substr($string,4,2));
		} elseif (strstr($string,","))	{
			$string = ereg_replace("[^,0-9]*","",$string);
			$strArr = explode(",",$string);
			$col[]=intval($strArr[0]);
			$col[]=intval($strArr[1]);
			$col[]=intval($strArr[2]);
		} else {
			$string = strtolower(trim($string));
			if ($this->colMap[$string])	{
				$col = $this->colMap[$string];
			} else {
				$col = Array(0,0,0);
			}
		}
		if (trim($cParts[1]))	{	// calculate it... (260201)
			$cParts[1]=trim($cParts[1]);
			if (substr($cParts[1],0,1)=="*")	{
				$val=doubleval(substr($cParts[1],1));
				$col[0]=t3lib_div::intInRange($col[0]*$val,0,255);
				$col[1]=t3lib_div::intInRange($col[1]*$val,0,255);
				$col[2]=t3lib_div::intInRange($col[2]*$val,0,255);
			} else {
				$val=intval($cParts[1]);
				$col[0]=t3lib_div::intInRange($col[0]+$val,0,255);
				$col[1]=t3lib_div::intInRange($col[1]+$val,0,255);
				$col[2]=t3lib_div::intInRange($col[2]+$val,0,255);
			}
		}
		return $col;
	}	
	function autolevels(&$im)	{
		$totalCols = ImageColorsTotal($im);
		$min=255;
		$max=0;
		for ($c=0; $c<$totalCols; $c++)	{
			$cols = ImageColorsForIndex($im,$c);
			$grayArr[] = round(($cols[red]+$cols[green]+$cols[blue])/3);
		}
		$min=min($grayArr);
		$max=max($grayArr);
		$delta = $max-$min;
		if ($delta)	{
			for ($c=0; $c<$totalCols; $c++)	{
				$cols = ImageColorsForIndex($im,$c);
				$cols[red] = floor(($cols[red]-$min)/$delta*255);
				$cols[green] = floor(($cols[green]-$min)/$delta*255);
				$cols[blue] = floor(($cols[blue]-$min)/$delta*255);
				ImageColorSet($im,$c,$cols[red],$cols[green],$cols[blue]);
			}
		}
	}
	function outputLevels(&$im,$low,$high)	{
		if ($low<$high){
			$low = t3lib_div::intInRange($low,0,255);
			$high = t3lib_div::intInRange($high,0,255);
			$delta = $high-$low;
			$totalCols = ImageColorsTotal($im);
			for ($c=0; $c<$totalCols; $c++)	{
				$cols = ImageColorsForIndex($im,$c);
				$cols[red] = $low+floor($cols[red]/255*$delta);
				$cols[green] = $low+floor($cols[green]/255*$delta);
				$cols[blue] = $low+floor($cols[blue]/255*$delta);
				ImageColorSet($im,$c,$cols[red],$cols[green],$cols[blue]);
			}
		}
	}
	function inputLevels(&$im,$low,$high)	{
		if ($low<$high){
			$low = t3lib_div::intInRange($low,0,255);
			$high = t3lib_div::intInRange($high,0,255);
			$delta = $high-$low;
			$totalCols = ImageColorsTotal($im);
			for ($c=0; $c<$totalCols; $c++)	{
				$cols = ImageColorsForIndex($im,$c);
				$cols[red] = t3lib_div::intInRange(($cols[red]-$low)/$delta*255, 0,255);
				$cols[green] = t3lib_div::intInRange(($cols[green]-$low)/$delta*255, 0,255);
				$cols[blue] = t3lib_div::intInRange(($cols[blue]-$low)/$delta*255, 0,255);
				ImageColorSet($im,$c,$cols[red],$cols[green],$cols[blue]);
			}
		}
	}
	function maskImageOntoImage(&$im,$conf,$workArea)	{
		if ($conf["file"] && $conf[mask])	{
			$BBimage = $this->imageMagickConvert($conf["file"],$this->gifExtension,"","","","","");
			$BBmask = $this->imageMagickConvert($conf["mask"],$this->gifExtension,"","","","","");
			if ($BBimage && $BBmask)	{
				$w = imagesx($im);
				$h = imagesy($im);
				$tmpStr = $this->randomName();
				$theImage = $tmpStr."_img.".$this->gifExtension;
				$theDest = $tmpStr."_dest.".$this->gifExtension;
				$theMask = $tmpStr."_mask.".$this->gifExtension;
				$theMask2 = $tmpStr."_mask2.miff";
						// prepare overlay image
				$cpImg = $this->imageCreateFromGif($BBimage[3]);
				$destImg = imagecreate($w,$h);
				ImageColorAllocate($destImg, 0,0,0);
				$this->copyGifOntoGif($destImg,$cpImg,$conf,$workArea);
				$this->ImageGif($destImg, $theImage);
				imageDestroy($cpImg);
				imageDestroy($destImg);
						// prepare mask image
				$cpImg = $this->imageCreateFromGif($BBmask[3]);
				$destImg = imagecreate($w,$h);
				ImageColorAllocate($destImg, 0,0,0);
				$this->copyGifOntoGif($destImg,$cpImg,$conf,$workArea);
				$this->ImageGif($destImg, $theMask);
				imageDestroy($cpImg);
				imageDestroy($destImg);
					// treat the mask
				$this->imageMagickExec($theMask,$theMask2,"-colorspace GRAY".$this->maskNegate);
					// mask the images
				$this->ImageGif($im, $theDest);


				$this->combineExec($theDest,$theImage,$theMask2,$theDest);

				$backIm = $this->imageCreateFromGif($theDest);	// The main image is loaded again...
				if ($backIm)	{	// ... and if nothing went wrong we load it onto the old one.
					ImageColorTransparent($backIm,-1);
					$im = $backIm;
				}
					// unlink files from process
				if (!$this->dontUnlinkTempFiles)	{
					unlink($theDest);
					unlink($theImage);
					unlink($theMask);
					unlink($theMask2);
				}
			}
		}
	}
	function copyImageOntoImage(&$im,$conf,$workArea)	{
		if ($conf["file"])	{
			if ($conf[BBOX][2]!=$this->gifExtension)	{
				$conf[BBOX]=$this->imageMagickConvert($conf[BBOX][3],$this->gifExtension,"","","","","");
				$conf["file"]=$conf[BBOX][3];
			}
			$cpImg = $this->imageCreateFromGif($conf["file"]);
			$this->copyGifOntoGif($im,$cpImg,$conf,$workArea);
			imageDestroy($cpImg);
		}
	}
	function copyGifOntoGif (&$im,$cpImg,$conf,$workArea)	{
		$cpW = imagesx($cpImg);
		$cpH = imagesy($cpImg);
		$tile = t3lib_div::intExplode(",",$conf["tile"]);
		$tile[0] = t3lib_div::intInRange($tile[0],1,20);
		$tile[1] = t3lib_div::intInRange($tile[1],1,20);
		$cpOff = $this->objPosition($conf,$workArea,Array($cpW*$tile[0],$cpH*$tile[1]));

		for ($xt=0;$xt<$tile[0];$xt++)	{
			$Xstart=$cpOff[0]+$cpW*$xt;
			if ($Xstart+$cpW > $workArea[0])	{	// if this image is inside of the workArea, then go on
	// X:
				if ($Xstart < $workArea[0])	{
					$cpImgCutX = $workArea[0]-$Xstart;
					$Xstart = $workArea[0];
				} else {
					$cpImgCutX = 0;
				}
				$w = $cpW-$cpImgCutX;
				if ($Xstart > $workArea[0]+$workArea[2]-$w)	{
					$w = $workArea[0]+$workArea[2]-$Xstart;
				}
				if ($Xstart < $workArea[0]+$workArea[2])	{	// if this image is inside of the workArea, then go on
		// Y:
					for ($yt=0;$yt<$tile[1];$yt++)	{
						$Ystart=$cpOff[1]+$cpH*$yt;
						if ($Ystart+$cpH > $workArea[1])	{	// if this image is inside of the workArea, then go on
							if ($Ystart < $workArea[1])	{
								$cpImgCutY = $workArea[1]-$Ystart;
								$Ystart = $workArea[1];
							} else {
								$cpImgCutY = 0;
							}
							$h = $cpH-$cpImgCutY;
							if ($Ystart > $workArea[1]+$workArea[3]-$h)	{
								$h = $workArea[1]+$workArea[3]-$Ystart;
							}
							if ($Ystart < $workArea[1]+$workArea[3])	{	// if this image is inside of the workArea, then go on
								imagecopyresized($im, $cpImg, $Xstart, $Ystart, $cpImgCutX, $cpImgCutY, $w, $h, $w, $h);
							}
						}
					}  // Y:
				}
			}
		}
	}
	function reduceColors(&$im,$limit, $cols)	{
		if (ImageColorsTotal($im)>=$limit)	{
			$this->makeEffect($im, Array("value"=>"colors=".$cols) );
		}
	}
	function recodeString($string)	{
		return $this->TTFLocaleConv ? recode_string($this->TTFLocaleConv,$string) : $string;
	}
	function SpacedImageTTFText(&$im, $fontSize, $angle, $x, $y, $Fcolor, $fontFile, $text, $spacing, $wordSpacing)	{
		if (!$spacing && $wordSpacing)	{
			$bits = explode(" ",$text);
			while(list(,$word)=each($bits))	{
				$word.=" ";
				$word = $this->recodeString($word);
				$wordInf = ImageTTFBBox($fontSize, $angle, t3lib_stdGraphic::prependAbsolutePath($fontFile), $word);
				$wordW = ($wordInf[2]-$wordInf[0]);
				ImageTTFText($im, $fontSize, $angle, $x, $y, $Fcolor, t3lib_stdGraphic::prependAbsolutePath($fontFile), $word);
				$x+=$wordW+$wordSpacing;
			}
		} else {
			$c=strlen($text);
			for ($a=0;$a<$c;$a++)	{
				$char = substr($text,$a,1);
				$char = $this->recodeString($char);
				$charInf = ImageTTFBBox($fontSize, $angle, t3lib_stdGraphic::prependAbsolutePath($fontFile), $char);
				$charW = ($charInf[2]-$charInf[0]);
				ImageTTFText($im, $fontSize, $angle, $x, $y, $Fcolor, t3lib_stdGraphic::prependAbsolutePath($fontFile), $char);
				$x+=$charW+(($char==" ")?$wordSpacing:$spacing);
			}
		}
	}
	function objPosition($conf,$workArea,$BB) {
			// offset, align, valign, workarea
		$result=Array();	// [0]=x, [1]=y, [2]=w, [3]=h
		$result[2] = $BB[0];
		$result[3] = $BB[1];
		$w=$workArea[2];
		$h=$workArea[3];
		
		$align = explode(",",$conf[align]);
		$align[0] = strtolower(substr(trim($align[0]),0,1));
		$align[1] = strtolower(substr(trim($align[1]),0,1));
		
		switch($align[0])	{
			case "r":
				$result[0]=$w-$result[2];
			break;
			case "c":
				$result[0] = round(($w-$result[2])/2);
			break;
			default:
				$result[0] = 0;
			break;
		}
		switch($align[1])	{
			case "b":
				$result[1] = $h-$result[3];	// y pos
			break;
			case "c":
				$result[1] = round(($h-$result[3])/2);
			break;
			default:
				$result[1]=0;
			break;
		}
		$result = $this->applyOffset($result,t3lib_div::intExplode(",",$conf[offset]));
		$result = $this->applyOffset($result,$workArea);
		return $result;
	}
	function txtPosition($conf,$workArea,$BB) {
		$bbox = $BB[2];
		$angle=intval($conf[angle])/180*pi();
		$conf[angle]=0;
		$straightBB = $this->calcBBox($conf);

			// offset, align, valign, workarea
		$result=Array();	// [0]=x, [1]=y, [2]=w, [3]=h
		$result[2] = $BB[0];
		$result[3] = $BB[1];
		$w=$workArea[2];
		$h=$workArea[3];

		switch($conf[align])	{
			case "right":
			case "center":
				$factor=abs(cos($angle));
				$sign=(cos($angle)<0)?-1:1;
				$len1 = $sign*$factor*$straightBB[0];
				$len2= $sign*$BB[0];
				$result[0] = $w-ceil($len2*$factor+(1-$factor)*$len1);

				$factor=abs(sin($angle));
				$sign=(sin($angle)<0)?-1:1;
				$len1= $sign*$factor*$straightBB[0];
				$len2= $sign*$BB[1];
				$result[1]=ceil($len2*$factor+(1-$factor)*$len1);
			break;
		}
		switch($conf[align])	{
			case "right":
			break;			
			case "center":
				$result[0] = round(($result[0])/2);
				$result[1] = round(($result[1])/2);
			break;			
			default:
				$result[0]=0;
				$result[1]=0;
			break;
		}
		$result = $this->applyOffset($result,t3lib_div::intExplode(",",$conf[offset]));
		$result = $this->applyOffset($result,$workArea);
		return $result;
	}
	function fontResize ($conf) {
		// you have to use +calc options like [10.h] in 'offset' to get the right position of your text-image, if you use +calc in XY height!!!!
		// By Rene Fritz <r.fritz@colorcube.de>
		$maxWidth = intval($conf["maxWidth"]);
		if ($maxWidth)	{
			if ($spacing || $wordSpacing)	{		// If any kind of spacing applys, we use this function:
				return $conf[fontSize];
				//  ################no calc for spacing yet !!!!!!
			} else {
				$fontSize = $conf[fontSize];
				do {
					$conf[fontSize] = $fontSize;
					// determine bounding box.
					$bounds = ImageTTFBBox($conf[fontSize], $conf[angle], t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $this->recodeString($conf[text]));
					if ($conf[angle]< 0) {
						$pixelWidth = abs($bounds[4]-$bounds[0]);
						//$height = abs($bounds[3]-$bounds[7]);
						//$offset_y = abs($bounds[7]-$bounds[1]);
						//$offset_x = 0;
					} elseif ($conf[angle] > 0) {
						$pixelWidth = abs($bounds[2]-$bounds[6]);
						//$height = abs($bounds[1]-$bounds[5]);
						//$offset_y = abs($bounds[7]-$bounds[5])+abs($bounds[1]-$bounds[7]);
						//$offset_x = abs($bounds[0]-$bounds[6]);
					} else {
						$pixelWidth = abs($bounds[4]-$bounds[6]);
						//$height = abs($bounds[7]-$bounds[1]);
						//$offset_y = abs($bounds[7]-$bounds[1]);
						//$offset_x = 0;
					}
					//this is a very raw calculation but it makes it in one step
					$fontSize=(int)($maxWidth*$fontSize/$pixelWidth);
					if ($fontSize >= $conf[fontSize])	{
						$fontSize = $conf[fontSize]-1;
					}
				} while ($pixelWidth > $maxWidth);
			}//if spacing
		}
		return $conf[fontSize];
	}
	function calcBBox($conf)	{
		if (!$conf["niceText"]) {
			$sF = 1;
		} else {		// NICETEXT::
			$sF = t3lib_div::intInRange($conf["niceText."]["scaleFactor"],2,5);
		}

		$spacing = intval($conf[spacing]);
		$wordSpacing = intval($conf[wordSpacing]);
		$wordSpacing = $wordSpacing?$wordSpacing:$spacing*2;
		
		$spacing*=$sF;
		$wordSpacing*=$sF;
		
		$charInf = ImageTTFBBox($sF*$conf[fontSize], $conf[angle], t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $this->recodeString($conf[text]));
		$theBBoxInfo = $charInf;
		if ($conf[angle])	{
			$xArr = Array($charInf[0],$charInf[2],$charInf[4],$charInf[6]);
			$yArr = Array($charInf[1],$charInf[3],$charInf[5],$charInf[7]);
			$x=max($xArr)-min($xArr);
			$y=max($yArr)-min($yArr);
		} else {
			$x = ($charInf[2]-$charInf[0]);
			$y = ($charInf[1]-$charInf[7]);
		}
		if ($spacing || $wordSpacing)	{		// If any kind of spacing applys, we use this function:
			$x=0;
			if (!$spacing && $wordSpacing)	{
				$bits = explode(" ",$conf[text]);
				while(list(,$word)=each($bits))	{
					$word.=" ";
					$wordInf = ImageTTFBBox($sF*$conf[fontSize], $conf[angle], t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $this->recodeString($word));
					$wordW = ($wordInf[2]-$wordInf[0]);
					$x+=$wordW+$wordSpacing;
				}
			} else {
				$c=strlen($conf[text]);
				for ($a=0;$a<$c;$a++)	{
					$char = substr($conf[text],$a,1);
					$charInf = ImageTTFBBox($sF*$conf[fontSize], $conf[angle], t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $this->recodeString($char));
					$charW = ($charInf[2]-$charInf[0]);
					$x+=$charW+(($char==" ")?$wordSpacing:$spacing);
				}
			}
		}
		
		if ($sF>1) {
			$x = ceil($x/$sF);
			$y = ceil($y/$sF);
			if (is_array($theBBoxInfo))	{
				reset($theBBoxInfo);
				while(list($key,$val)=each($theBBoxInfo))	{
					$theBBoxInfo[$key]=ceil($theBBoxInfo[$key]/$sF);
				}
			}
		}
		return Array($x,$y,$theBBoxInfo);
	}
	function circleOffset($distance, $iterations)	{
		$res = Array();
		if ($distance && $iterations)	{
			for ($a=0;$a<$iterations;$a++)	{
				$yOff = round(sin(2*pi()/$iterations*($a+1))*100*$distance);
				if ($yOff)	{$yOff = intval(ceil(abs($yOff/100))*($yOff/abs($yOff)));}
				$xOff = round(cos(2*pi()/$iterations*($a+1))*100*$distance);
				if ($xOff)	{$xOff = intval(ceil(abs($xOff/100))*($xOff/abs($xOff)));}
				$res[$a] = Array($xOff,$yOff);
			}
		}
		return $res;
	}
	function makeOutline(&$im,$conf,$workArea,$txtConf)	{
			// Outline
		$thickness = intval($conf["thickness"]);
		if ($thickness)	{
			$txtConf[fontColor] = $conf[color];
			$outLineDist = t3lib_div::intInRange($thickness,1,2);
			for ($b=1;$b<=$outLineDist;$b++)	{
				if ($b==1)	{
					$it = 8;
				} else {
					$it = 16;
				}
				$outL = $this->circleOffset($b, $it);
				for ($a=0;$a<$it;$a++)	{
					$this->makeText($im,$txtConf,$this->applyOffset($workArea,$outL[$a]));
				}
			}
		}
	}
	function makeBox(&$im,$conf,$workArea)	{
		$cords = t3lib_div::intExplode(",",$conf["dimensions"].",,,");
		$conf[offset]=$cords[0].",".$cords[1];
		$cords = $this->objPosition($conf,$workArea,Array($cords[2],$cords[3]));
		$cols=$this->convertColor($conf["color"]);
		$this->reduceColors($im,256, 255);
		$tmpColor = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
		imagefilledrectangle($im, $cords[0], $cords[1], $cords[0]+$cords[2]-1, $cords[1]+$cords[3]-1, $tmpColor);
	}
	function calcTextCordsForMap($cords,$offset, $conf)	{
		$pars = t3lib_div::intExplode(",",$conf["explode"].",");

		$newCords[0] = $cords[0]+$offset[0]-$pars[0];
		$newCords[1] = $cords[1]+$offset[1]+$pars[1];
		$newCords[2] = $cords[2]+$offset[0]+$pars[0];
		$newCords[3] = $cords[3]+$offset[1]+$pars[1];
		$newCords[4] = $cords[4]+$offset[0]+$pars[0];
		$newCords[5] = $cords[5]+$offset[1]-$pars[1];
		$newCords[6] = $cords[6]+$offset[0]-$pars[0];
		$newCords[7] = $cords[7]+$offset[1]-$pars[1];

		return $newCords;
	}
	function addToMap($cords,$conf)	{
		$JS = $conf["noBlur"] ? '' : ' onFocus="blurLink(this);"';
		$this->map.='<area shape="poly" coords="'.implode($cords,",").'" href="'.$conf["url"].'" target="'.$conf["target"].'"'.$JS.'>';
	}
	function makeText(&$im,$conf,$workArea)	{
			// Spacing
		$spacing = intval($conf[spacing]);
		$wordSpacing = intval($conf[wordSpacing]);
		$wordSpacing = $wordSpacing?$wordSpacing:$spacing*2;
			// Position
		$txtPos = $this->txtPosition($conf,$workArea,$conf[BBOX]);

		if ($conf["imgMap"] && is_array($conf["imgMap."]))	{
			$this->addToMap($this->calcTextCordsForMap($conf[BBOX][2],$txtPos, $conf["imgMap."]), $conf["imgMap."]);
		}
		if (!$conf["hideButCreateMap"])	{
				// Font Color:
			$cols=$this->convertColor($conf["fontColor"]);
				// NiceText is calculated
			if (!$conf["niceText"]) {
					// Font Color is reserved:
				$this->reduceColors($im,256, 200);
				$Fcolor = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
					// antiAliasing is setup:
				$Fcolor = ($conf[antiAlias]) ? $Fcolor : -$Fcolor;
				
				for ($a=0; $a<$conf[iterations]; $a++)	{
					if ($spacing || $wordSpacing)	{		// If any kind of spacing applys, we use this function:
						$this->SpacedImageTTFText($im, $conf[fontSize], $conf[angle], $txtPos[0], $txtPos[1], $Fcolor, t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $conf[text], $spacing, $wordSpacing);
					} else {
						ImageTTFText($im, $conf[fontSize], $conf[angle], $txtPos[0], $txtPos[1], $Fcolor, t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $this->recodeString($conf[text]));
					}
				}
			} else {		// NICETEXT::
					// options anti_aliased and iterations is NOT available when doing this!!
				$w = imagesx($im);
				$h = imagesy($im);
				$tmpStr = $this->randomName();
//				debug($this->tempPath);
//				debug($tmpStr);
//				echo "<BR>";
				
				$fileMenu = $tmpStr."_menuNT.".$this->gifExtension;
				$fileColor = $tmpStr."_colorNT.".$this->gifExtension;
				$fileMask = $tmpStr."_maskNT.".$this->gifExtension;
					// Scalefactor
				$sF = t3lib_div::intInRange($conf["niceText."]["scaleFactor"],2,5);
				$newW = ceil($sF*imagesx($im));
				$newH = ceil($sF*imagesy($im));
	
					// Make mask
				$maskImg = imagecreate($newW, $newH);
				ImageColorAllocate($maskImg, 255,255,255);
				$Fcolor = ImageColorAllocate($maskImg, 0,0,0);
				if ($spacing || $wordSpacing)	{		// If any kind of spacing applys, we use this function:
					$this->SpacedImageTTFText($maskImg, ceil($sF*$conf[fontSize]), $conf[angle], ceil($sF*$txtPos[0]), ceil($sF*$txtPos[1]), $Fcolor, t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $conf[text], ceil($sF*$spacing), ceil($sF*$wordSpacing));
				} else {
					ImageTTFText($maskImg, ceil($sF*$conf[fontSize]), $conf[angle], ceil($sF*$txtPos[0]), ceil($sF*$txtPos[1]), $Fcolor, t3lib_stdGraphic::prependAbsolutePath($conf["fontFile"]), $this->recodeString($conf[text]));
				}
				$this->ImageGif($maskImg, $fileMask);
				ImageDestroy($maskImg);

					// Downscales the mask
				if ($this->NO_IM_EFFECTS)	{
					if ($this->maskNegate)	{
						$command = trim($this->scalecmd." ".$w."x".$h."!");		// Negate 2 times makes no negate...
					} else {
						$command = trim($this->scalecmd." ".$w."x".$h."! -negate");
					}
				} else {
					if ($this->maskNegate)	{
						$command = trim($conf["niceText."]["before"]." ".$this->scalecmd." ".$w."x".$h."! ".$conf["niceText."]["after"]);
					} else {
						$command = trim($conf["niceText."]["before"]." ".$this->scalecmd." ".$w."x".$h."! ".$conf["niceText."]["after"]." -negate");
					}
					if ($conf["niceText."]["sharpen"]) {
						$command.=" -sharpen ".t3lib_div::intInRange($conf["niceText."]["sharpen"],1,99);
					}
				}
				$this->imageMagickExec($fileMask,$fileMask,$command);
	
					// Make the color-file
				$colorImg = imagecreate($w,$h);
				ImageColorAllocate($colorImg, $cols[0],$cols[1],$cols[2]);
				$this->ImageGif($colorImg, $fileColor);
				ImageDestroy($colorImg);
	
					// The mask is applied
				$this->ImageGif($im, $fileMenu);	// The main pictures is saved temporarily
	
				$this->combineExec($fileMenu,$fileColor,$fileMask,$fileMenu);
				
				$backIm = $this->imageCreateFromGif($fileMenu);	// The main image is loaded again...
				if ($backIm)	{	// ... and if nothing went wrong we load it onto the old one.
					ImageColorTransparent($backIm,-1);
					$im = $backIm;
				}
	
				// Deleting temporary files;
				if (!$this->dontUnlinkTempFiles)	{
					unlink($fileMenu);	
					unlink($fileColor);
					unlink($fileMask);	
				}
			}
		}
	}
	function makeEmboss(&$im,$conf,$workArea,$txtConf)	{
		$conf[color]=$conf[highColor];
		$this->makeShadow($im,$conf,$workArea,$txtConf);
		$newOffset = t3lib_div::intExplode(",",$conf[offset]);
		$newOffset[0]*=-1;
		$newOffset[1]*=-1;
		$conf[offset]=implode($newOffset,",");
		$conf[color]=$conf[lowColor];
		$this->makeShadow($im,$conf,$workArea,$txtConf);
	}
	function adjust(&$im, $conf)	{
		$setup = $conf[value];
		if (!trim($setup)){return "";}
		$effects = explode("|", $setup);
		while(list(,$val)=each($effects))	{
			$pairs=explode("=",$val,2);
			$value = trim($pairs[1]);
			$effect = strtolower(trim($pairs[0]));
			switch($effect)	{
				case "inputlevels":	// low,high
					$params = t3lib_div::intExplode(",",$value);
					$this->inputLevels($im,$params[0],$params[1]);
				break;
				case "outputlevels":
					$params = t3lib_div::intExplode(",",$value);
					$this->outputLevels($im,$params[0],$params[1]);
				break;
				case "autolevels":
					$this->autoLevels($im);
				break;
			}
		}
	}
	function makeEffect(&$im, $conf)	{
		$commands = $this->IMparams($conf[value]);
		if ($commands)	{
			$this->applyImageMagickToPHPGif($im, $commands);
		}
	}
	function IMparams($setup)	{
		if (!trim($setup)){return "";}
		$effects = explode("|", $setup);
		$commands = "";
		while(list(,$val)=each($effects))	{
			$pairs=explode("=",$val,2);
			$value = trim($pairs[1]);
			$effect = strtolower(trim($pairs[0]));
			switch($effect)	{
				case "gamma":
					$commands.=" -gamma ".doubleval($value);
				break;		
				case "blur":
					if (!$this->NO_IM_EFFECTS)	{
						$commands.=" -blur ".t3lib_div::intInRange($value,1,99);
					}
				break;		
				case "sharpen":
					if (!$this->NO_IM_EFFECTS)	{
						$commands.=" -sharpen ".t3lib_div::intInRange($value,1,99);
					}
				break;		
				case "rotate":
					$commands.=" -rotate ".t3lib_div::intInRange($value,0,360);
				break;		
				case "solarize":
					$commands.=" -solarize ".t3lib_div::intInRange($value,0,99);
				break;		
				case "swirl":
					$commands.=" -swirl ".t3lib_div::intInRange($value,0,1000);
				break;		
				case "wave":
					$params = t3lib_div::intExplode(",",$value);
					$commands.=" -wave ".t3lib_div::intInRange($params[0],0,99)."x".t3lib_div::intInRange($params[1],0,99);
				break;		
				case "charcoal":
					$commands.=" -charcoal ".t3lib_div::intInRange($value,0,100);
				break;		
				case "gray":
					$commands.=" -colorspace GRAY";
				break;		
				case "edge":
					$commands.=" -edge ".t3lib_div::intInRange($value,0,99);
				break;		
				case "emboss":
					$commands.=" -emboss";
				break;		
				case "flip":
					$commands.=" -flip";
				break;		
				case "flop":
					$commands.=" -flop";
				break;		
				case "colors":
					$commands.=" -colors ".t3lib_div::intInRange($value,2,255);
				break;		
				case "shear":
					$commands.=" -shear ".t3lib_div::intInRange($value,-90,90);
				break;		
				case "invert":
					$commands.=" -negate";
				break;		
			}
		}
		return $commands;
	}
	function makeShadow(&$im,$conf,$workArea,$txtConf)	{
		$workArea = $this->applyOffset($workArea,t3lib_div::intExplode(",",$conf[offset]));
		$blurRate = t3lib_div::intInRange(intval($conf[blur]),0,99);

		if (!$blurRate || $this->NO_IM_EFFECTS)	{		// No effects if ImageMagick ver. 5+
			$txtConf[fontColor] = $conf[color];
			$this->makeText($im,$txtConf,$workArea);
		} else {
			$w = imagesx($im);
			$h = imagesy($im);
			$blurBorder= 3;	// area around the blur used for cropping something
			$tmpStr = $this->randomName();
			$fileMenu = $tmpStr."_menu.".$this->gifExtension;
			$fileColor = $tmpStr."_color.".$this->gifExtension;
			$fileMask = $tmpStr."_mask.".$this->gifExtension;

				// BlurColor Image laves
			$blurColImg = imagecreate($w,$h);
			$bcols=$this->convertColor($conf[color]);
			ImageColorAllocate($blurColImg, $bcols[0],$bcols[1],$bcols[2]);
			$this->ImageGif($blurColImg, $fileColor);
			ImageDestroy($blurColImg);
	
				// The mask is made: BlurTekxtImage
			$blurTextImg = imagecreate($w+$blurBorder*2,$h+$blurBorder*2);
			ImageColorAllocate($blurTextImg, 0,0,0);		// black background
			$txtConf[fontColor] = "white";
			$blurBordArr = Array($blurBorder,$blurBorder);
			$this->makeText($blurTextImg,$txtConf,  $this->applyOffset($workArea,$blurBordArr));
			$this->ImageGif($blurTextImg, $fileMask);	// dump to temporary file
			ImageDestroy($blurTextImg);	// destroy


			$command="";
			$command.=$this->maskNegate;
				// Blurring of the mask
			$times = ceil($blurRate/10);	// How many blur-commands that is executed. Min = 1;
			$newBlurRate = $blurRate*4;		// Her booster vi blur-rate, s� at den allerede ved 25 er p� 100. Resten op til 99 g�r p� iterationer af blur-kommandoen
			$newBlurRate = t3lib_div::intInRange($newBlurRate,1,99);
			for ($a=0;$a<$times;$a++)	{		// Building blur-command
				$command.=" -blur ".$blurRate;
			}
			$this->imageMagickExec($fileMask,$fileMask,$command);
			
			$blurTextImg_tmp = $this->imageCreateFromGif($fileMask);	// the mask is loaded again
			if ($blurTextImg_tmp)	{	// if nothing went wrong we continue with the blurred mask
					// cropping the border from the mask
				$blurTextImg = imagecreate($w,$h);
				imagecopyresized($blurTextImg, $blurTextImg_tmp, 0, 0, $blurBorder, $blurBorder, $w, $h, $w, $h);
				ImageDestroy($blurTextImg_tmp);	// Destroy the temporary mask
					// adjust the mask
				//$this->autoLevels($blurTextImg);	// We perform autolevels on the mask
	
				$intensity = 40;
				if ($conf["intensity"])	{
					$intensity = t3lib_div::intInRange($conf["intensity"],0,100);
				}
				$intensity = ceil(255-($intensity/100*255));
				$this->inputLevels($blurTextImg,0,$intensity);
				
				$opacity = t3lib_div::intInRange(intval($conf["opacity"]),0,100);
				if ($opacity && $opacity<100)	{
					$this->outputLevels($blurTextImg,0,ceil(255*$opacity/100));	// reducing levels as the opacity demands
				}
				$this->ImageGif($blurTextImg, $fileMask);	// Dump the mask again
				ImageDestroy($blurTextImg);	// Destroy the mask
	
					// The pictures are combined
				$this->ImageGif($im, $fileMenu);	// The main pictures is saved temporarily

				$this->combineExec($fileMenu,$fileColor,$fileMask,$fileMenu);

				$backIm = $this->imageCreateFromGif($fileMenu);	// The main image is loaded again...
				if ($backIm)	{	// ... and if nothing went wrong we load it onto the old one.
					ImageColorTransparent($backIm,-1);
					$im = $backIm;
				}
			}
				// Deleting temporary files;
			if (!$this->dontUnlinkTempFiles)	{
				unlink($fileMenu);	
				unlink($fileColor);
				unlink($fileMask);	
			}
		}
	}
	function checkFile($file)	{
		if (@is_file($file))	{
			return $file;
		} else {
			return "";
		}
	}
	function applyImageMagickToPHPGif (&$im, $command)	{
		$tmpStr = $this->randomName();
		$theFile = $tmpStr.".".$this->gifExtension;
		$this->ImageGif($im, $theFile);
		$this->imageMagickExec($theFile,$theFile,$command);
		$tmpImg = $this->imageCreateFromGif($theFile);
		if ($tmpImg)	{
			ImageDestroy($im);
			$im = $tmpImg;
			$this->w = imagesx($im);
			$this->h = imagesy($im);
		}	
		if (!$this->dontUnlinkTempFiles)	{
			unlink($theFile);
		}
	}
	function crop (&$im,$conf)	{
		$this->setWorkArea("");	// clears workArea to total image
		$cords = t3lib_div::intExplode(",",$conf["crop"].",,,");
		$conf[offset]=$cords[0].",".$cords[1];
		$cords = $this->objPosition($conf,$this->workArea,Array($cords[2],$cords[3]));

		$newIm = imagecreate($cords[2],$cords[3]);
		$cols=$this->convertColor($conf["backColor"]?$conf["backColor"]:$this->setup["backColor"]);
		ImageColorAllocate($newIm, $cols[0],$cols[1],$cols[2]);

		$newConf = Array();
		$workArea = Array(0,0,$cords[2],$cords[3]);
		if ($cords[0]<0) {$workArea[0]=abs($cords[0]);} else {$newConf[offset]=-$cords[0];}
		if ($cords[1]<0) {$workArea[1]=abs($cords[1]);} else {$newConf[offset].=",".-$cords[1];}
		
		$this->copyGifOntoGif ($newIm,$im,$newConf,$workArea);
		$im = $newIm;
		$this->w = imagesx($im);
		$this->h = imagesy($im);
		$this->setWorkArea("");	// clears workArea to total image
	}
	function scale (&$im,$conf)	{
		if ($conf[width] || $conf[height] || $conf[params])	{
			$tmpStr = $this->randomName();
			$theFile = $tmpStr.".".$this->gifExtension;
			$this->ImageGif($im, $theFile);
			$theNewFile = $this->imageMagickConvert($theFile,$this->gifExtension,$conf[width],$conf[height],$conf[params],"","");
			$tmpImg = $this->imageCreateFromGif($theNewFile[3]);
			if ($tmpImg)	{
				ImageDestroy($im);
				$im = $tmpImg;
				$this->w = imagesx($im);
				$this->h = imagesy($im);
				$this->setWorkArea("");	// clears workArea to total image
			}	
			if (!$this->dontUnlinkTempFiles)	{
				unlink($theFile);
				if ($theNewFile[3] && $theNewFile[3]!=$theFile)	{
					unlink($theNewFile[3]);
				}
			}
		}
	}
	function getImageDimensions ($imagefile)	{
		// returns an array where [0]/[1] is w/h, [2] is extension and [3] is the filename.
		ereg("([^\.]*)$",$imagefile,$reg);
		if (@file_exists($imagefile) && t3lib_div::inList($this->imageFileExt,strtolower($reg[0])))	{
			if ($temp = @getImageSize($imagefile))	{
				return Array($temp[0], $temp[1], strtolower($reg[0]), $imagefile);
			} else {
				return $this->imageMagickIdentify($imagefile);
			}
		}
	}
	function getImageScale($info,$w,$h,$options) {
		if (strstr($w.$h, "m")) {$max=1;} else {$max=0;}
		$w=intval($w);
		$h=intval($h);
			// if there are max-values...
		if ($options["maxW"])	{
			if ($w) {	// if width is given...
				if ($w>$options["maxW"]) {
					$w=$options["maxW"];
					$max=1;	// height should follow
				}
			} else {
				if ($info[0]>$options["maxW"]) {
					$w=$options["maxW"];
					$max=1; // height should follow
				}
			}
		}
		if ($options["maxH"])	{
			if ($h) {	// if height is given...
				if ($h>$options["maxH"]) {
					$h=$options["maxH"];
					$max=1;	// height should follow
				}
			} else {
				if ($info[1]>$options["maxH"]) {	// Changed [0] to [1] 290801
					$h=$options["maxH"];
					$max=1; // height should follow
				}
			}
		}
		$out["origW"]=$w;
		$out["origH"]=$h;
		$out["max"] = $max;
		
		if (!$this->mayScaleUp) {
			if ($w>$info[0]){$w=$info[0];}
			if ($h>$info[1]){$h=$info[1];}
		}
		if ($w || $h)	{	// if scaling should be performed
			if ($w && !$h)	{
				$info[1] = ceil($info[1]*($w/$info[0]));
				$info[0] = $w;
			}
			if (!$w && $h)	{
				$info[0] = ceil($info[0]*($h/$info[1]));
				$info[1] = $h;
			}
			if ($w && $h)	{
				if ($max)	{
					$ratio = $info[0]/$info[1];
					if ($h*$ratio > $w) {
						$h = round($w/$ratio);
					} else {
						$w = round($h*$ratio);
					}
				}
				$info[0] = $w;
				$info[1] = $h;
			}
		}
		$out[0]=$info[0];
		$out[1]=$info[1];
			// Set minimum-measures!
		if ($options[minW] && $out[0]<$options[minW])	{
			if ($max && $out[0])	{
				$out[1]= round($out[1]*$options[minW]/$out[0]);
			}
			$out[0]=$options[minW];
		}
		if ($options[minH] && $out[1]<$options[minH])	{
			if ($max && $out[1])	{
				$out[0]= round($out[0]*$options[minH]/$out[1]);
			}
			$out[1]=$options[minH];
		}
//debug($out)		;
		
		return $out;
	}
	function imageMagickConvert($imagefile,$newExt="",$w="",$h="",$params="",$frame="",$options="",$mustCreate=0)	{
			// Converts $imagefile to another file in temp-dir of type $newExt (extension). $w / $h is optional. If only one is given the image is scaled proportionally. $params is additional ImageMagick parameters. If $newExt is NOT set, the new imagefile will be of the original format
			// returns an array where [0]/[1] is w/h, [2] is extension and [3] is the filename.
			// $frame refers to which frame-number to select in the image. "" or 0 will select the first frame, 1 will select the next and so on...
			// if newExt = "WEB" then one of the web-formats is applied.
			// if an "m" exists in the $w or $h and if both are present the $w and $h is regarded as the Maximum w/h and the proportions will be kept
			
		if ($this->NO_IMAGE_MAGICK)	{
/*				// Because a new extension may have been requested due to png-only settings, it's checked whether the current file extension is not the wished. In case they don't match, nothing is returned.
			$imgInf = pathinfo($imagefile);
			$newExt = strtolower($newExt);
			if ($newExt && strtolower($imgInf["extension"])!=$newExt && t3lib_div::inList("gif,png", $newExt))	{
				$imagefile="";
			}*/
				// Returning file info right away
			return $this->getImageDimensions($imagefile);
		}
		
		if($info=$this->getImageDimensions($imagefile))	{
			$newExt=strtolower(trim($newExt));
			if (!$newExt)	{	// If no extension is given the original extension is used
				$newExt = $info[2];
			}
			if ($newExt=="web")	{
				if (t3lib_div::inList($this->webImageExt,$info[2]))	{
					$newExt = $info[2];
				} else {
					$newExt = $this->gif_or_jpg($info[2],$info[0],$info[1]);
					if (!$params)	{
						$params = $this->cmds[$newExt];
					}
				}
			}
			if (t3lib_div::inList($this->imageFileExt,$newExt))	{
				if (strstr($w.$h, "m")) {$max=1;} else {$max=0;}

				$data = $this->getImageScale($info,$w,$h,$options);
				$w=$data[origW];
				$h=$data[origH];
				
					// if no convertion should be performed
/*
				t3lib_div::print_array($data);
				t3lib_div::print_array($info);
				debug($this->mayScaleUp);
					debug($w);
					debug($h);
					debug($params);
					debug($frame?1:"");
					debug($newExt==$info[2]);
*/

				$wh_noscale = (!$w && !$h) || ($data[0]==$info[0] && $data[1]==$info[1]);		// this flag is true if the width / height does NOT dictate the image to be scaled!! (that is if no w/h is given or if the destination w/h matches the original image-dimensions....
					
				if ($wh_noscale && !$params && !$frame && $newExt==$info[2] && !$mustCreate) {	
					$info[3] = $imagefile;
					return $info;
				}
				$info[0]=$data[0];
				$info[1]=$data[1];

				$frame = $this->noFramePrepended ? "" : "[".intval($frame)."]";
				

// Added 17-06-00				
				if (!$params)	{
					$params = $this->cmds[$newExt];
				}
				
				$command = $this->scalecmd." ".$info[0]."x".$info[1]."! ".$params." ";
				
				if ($this->alternativeOutputKey)	{
					$theOutputName = t3lib_div::shortMD5($command.basename($imagefile).$this->alternativeOutputKey.$frame);
				} else {
					$theOutputName = t3lib_div::shortMD5($command.$imagefile.filemtime($imagefile).$frame);
				}
				if ($this->imageMagickConvert_forceFileNameBody)	{
					$theOutputName = $this->imageMagickConvert_forceFileNameBody;
					$this->imageMagickConvert_forceFileNameBody="";
				}
				$output = $this->tempPath.$this->filenamePrefix.$theOutputName.".".$newExt;
				$GLOBALS["TEMP_IMAGES_ON_PAGE"][]=$output;

				if (!$this->file_exists_typo3temp_file($output,$imagefile) || $this->dontCheckForExistingTempFile)	{
					$this->imageMagickExec($imagefile.$frame,$output,$command);
				}
				if (@file_exists($output))	{
					$info[3] = $output;
					$info[2] = $newExt;
					if ($params)	{	// params could realisticly change som imagedata!
						$info=$this->getImageDimensions($info[3]);
					}
					if ($info[2]==$this->gifExtension && !$this->dontCompress)	{
						t3lib_div::gif_compress($info[3],"");		// Compress with IM (lzw) or GD (rle)  (Workaround for the absence of lzw-compression in GD)
					}
					return $info;
				}
			}
		}
	}
	function file_exists_typo3temp_file($output,$orig="")	{
		if ($this->enable_typo3temp_db_tracking)	{
			if (@file_exists($output))	{	// If file exists, then we return immediately
//				debug("OK, return..");
				return 1;
			} else {	// If not, we look up in the cache_typo3temp_log table to see if there is a image being rendered right now.
				$md5Hash=md5($output);
				$query="SELECT md5hash FROM cache_typo3temp_log WHERE md5hash='".$md5Hash."' AND tstamp>".(time()-30);
				$res=mysql(TYPO3_db,$query);
				echo mysql_error();
				if ($row=mysql_fetch_assoc($res))	{	// If there was a record, the image is being generated by another proces (we assume)
					if (is_object($GLOBALS["TSFE"]))	$GLOBALS["TSFE"]->set_no_cache();	// ...so we set no_cache, because we dont want this page (which will NOT display an image...!) to be cached! (Only a page with the correct image on...)
					if (is_object($GLOBALS["TT"]))	$GLOBALS["TT"]->setTSlogMessage("typo3temp_log: Assume this file is being rendered now: ".$output);
					return 2;	// Return "success - 2"
				} else {		// If the current time is more than 30 seconds since this record was written, we clear the record, write a new and render the image. 
					$query="DELETE FROM cache_typo3temp_log WHERE md5hash='".$md5Hash."'";
					$res=mysql(TYPO3_db,$query);
					$query="INSERT INTO cache_typo3temp_log (md5hash,tstamp,filename,orig_filename) VALUES ('".$md5Hash."',".time().",'".addslashes($output)."','".addslashes($orig)."')";
					$res=mysql(TYPO3_db,$query);
					if (is_object($GLOBALS["TT"]))	$GLOBALS["TT"]->setTSlogMessage("typo3temp_log: The row did not exist, so a new is written and file is being processed: ".$output);
					return 0;
				}
			}
		} else {
			return @file_exists($output);
		}
	}
	function wrapFileName($inputName)	{
		if (strstr($inputName," "))	{
			$inputName='"'.$inputName.'"';
			
		}
		return $inputName;
	}
	function imageMagickIdentify($imagefile)	{
		// returns an array where [0]/[1] is w/h, [2] is extension and [3] is the filename.
		if (!$this->NO_IMAGE_MAGICK)	{
			$cmd = $this->imageMagickPath.'identify '.$this->wrapFileName($imagefile);
			exec($cmd, $returnVal);
			$splitstring=$returnVal[0];
			$this->IM_commands[] = Array ("identify",$cmd,$returnVal[0]);
			if ($splitstring)	{
				ereg("([^\.]*)$",$imagefile,$reg);
				$splitinfo = explode(" ", $splitstring);
				while (list($key,$val) = each($splitinfo))	{
					$temp = "";
					if ($val) {$temp = explode("x", $val);}
					if (intval($temp[0]) && intval($temp[1]))	{
						$dim=$temp;
						break;
					}
				}
				if ($dim[0] && $dim[1])	{
					return Array($dim[0], $dim[1], strtolower($reg[0]), $imagefile);
				}
			}
		}
	}
	function imageMagickExec($input,$output,$params)	{
		if (!$this->NO_IMAGE_MAGICK)	{
			$cmd = $this->imageMagickPath.'convert '.$params.' '.$this->wrapFileName($input).' '.$this->wrapFileName($output);
			$this->IM_commands[] = Array ($output,$cmd);
			return exec($cmd);	
		}
	}
	function combineExec($input,$overlay,$mask,$output)	{
		if (!$this->NO_IMAGE_MAGICK)	{
			$cmd = $this->imageMagickPath.$this->combineScript.' -compose over '.$this->wrapFileName($input).' '.$this->wrapFileName($overlay).' '.$this->wrapFileName($mask).' '.$this->wrapFileName($output);
			$this->IM_commands[] = Array ($output,$cmd);
			exec($cmd);	
		}
	}
	function gif_or_jpg($type,$w,$h)	{
		if ($type=="ai" || $w*$h < $this->pixelLimitGif)	{
			return $this->gifExtension;
		} else {
			return "jpg";
		}
	}
	function output ($file)	{
		if ($file)	{
			ereg("([^\.]*)$",$file,$reg);
			$ext=strtolower($reg[0]);
			switch($ext)	{
				case $this->gifExtension:
					if ($this->ImageGif($this->im, $file))	{
						// ImageMagick operations
						if($this->setup[reduceColors])	{
							$this->imageMagickExec($file,$file," -colors ".t3lib_div::intInRange($this->setup[reduceColors],2,255));
							t3lib_div::gif_compress($file,"");	// Compress with IM (lzw) or GD (rle)      (Workaround for the absence of lzw-compression in GD)
						} else {
							t3lib_div::gif_compress($file, "IM");		// Compress with IM! (adds extra compression, LZW from ImageMagick)     (Workaround for the absence of lzw-compression in GD)
						}
					}
				break;
				case "jpg":
				case "jpeg":
					$tmpStr = $this->randomName();
					$theFile = $tmpStr.".".$this->gifExtension;
					if ($this->ImageGif($this->im, $theFile))	{
						// ImageMagick operations
						$operations="";
						if($this->setup[quality])	{
							$operations.=" -quality ".t3lib_div::intInRange($this->setup[quality],10,100);
						}
						$this->imageMagickExec($theFile,$file,$operations);
						if (!$this->dontUnlinkTempFiles)	{
							unlink($theFile);
						}
					}
				break;
			}
			$GLOBALS["TEMP_IMAGES_ON_PAGE"][]=$file;
		}
		return $file;
	}
	function destroy ()	{
		ImageDestroy($this->im);
	}
	function imgTag ($imgInfo) {
		return '<img src="'.$imgInfo[3].'" width="'.$imgInfo[0].'" height="'.$imgInfo[1].'" border=0>';
	}
	function ImageGif ($destImg, $theImage)	{
		imageinterlace ($destImg,0);
		if ($this->gifExtension=="gif")	{
			return ImageGif($destImg, $theImage);
		}
		if ($this->gifExtension=="png")	{
			return ImagePng($destImg, $theImage);
		}
	}
	function imageCreateFromGif($sourceImg)	{
		$imgInf = pathinfo($sourceImg);
		$ext = strtolower($imgInf["extension"]);

//		if ($ext=="gif" && (ImageTypes() & IMG_GIF))	{
		if ($ext=="gif")	{
			return imageCreateFromGif($sourceImg);
		}
		if ($ext=="png" && (ImageTypes() & IMG_PNG))	{
			return imageCreateFromPng($sourceImg);
		}
		if (($ext=="jpg" || $ext=="jpeg") && (ImageTypes() & IMG_JPG))	{
			return imageCreateFromJpg($sourceImg);
		}

		// If non of the above:
		$i = @getimagesize($sourceImg);
		$im = imagecreate($i[0],$i[1]);
		ImageColorAllocate($im, 128,128,128);
		return $im;

	// Old way...
/*		if ($this->gifExtension=="gif")	{
			return imageCreateFromGif($sourceImg);
		}
		if ($this->gifExtension=="png")	{
			return imageCreateFromPng($sourceImg);
		}
		*/
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_stdgraphic.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_stdgraphic.php"]);
}
?>