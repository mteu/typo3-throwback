<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license
*  from the author is found in LICENSE.txt distributed with these scripts.
*
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * Diverse functions for general purpose.
 *
 * The class is intended to be user without creating an instance of it.
 * So use t3lib_div::[function-name] to refer to the functions.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class t3lib_div {

	/**
	 * milliseconds
	 *
	 * microtime recalculated to t3lib_div::milliseconds(1/1000 sec)
	 *
	 * @return 	integer
	 */
	function milliseconds()	{
		$p=explode(" ",microtime());
		return round(($p[0]+$p[1])*1000);
	}
	
	/**
	 * Sets global variables from HTTP_POST_VARS or HTTP_GET_VARS
	 *
	 */
	function setGPvars($list,$strip=0)	{
		$vars = t3lib_div::trimExplode(",",$list,1);
		while(list(,$var)=each($vars))	{
			$GLOBALS[$var] = t3lib_div::GPvar($var,$strip);
		}
	}

	/**
	 * GET/POST variable
	 *
	 * Returns the 'GLOBAL' value of incoming data from POST or GET, with priority to POST (that is equalent to 'GP' order)
	 * Strips slashes of
	 */
	function GPvar($var,$strip=0)	{
		$value = isset($GLOBALS["HTTP_POST_VARS"][$var]) ? $GLOBALS["HTTP_POST_VARS"][$var] : $GLOBALS["HTTP_GET_VARS"][$var];
		if (isset($value) && is_string($value))	{$value=stripslashes($value);}	// Originally check "&& get_magic_quotes_gpc() " but the values of HTTP_GET_VARS are always slashed regardless of get_magic_quotes_gpc() because HTTP_POST/GET_VARS are run through addSlashesOnArray in the very beginning of index_ts.php eg.
		if ($strip && isset($value) && is_array($value)) {t3lib_div::stripSlashesOnArray($value);}
		return $value;
	}

	function gif_compress($theFile, $type)	{
		// This function is a workaround for the fact that ImageMagick and/or GD does not compress GIF-files to their minimun size (that is RLE or no compression used)
		// The function takes a file-reference, $theFile, and saves it again through GD or ImageMagick in order to compress the file
		// GIF:
		// If $type is not set, the compression is done with ImageMagick (provided that $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"] is pointing to the path of a lzw-enabled version of 'convert') else with GD (should be RLE-enabled!)
		// If $type is set to either "IM" or "GD" the compression is done with ImageMagick and GD respectively
		// PNG:
		// No changes.

		// $theFile is expected to be a valid GIF-file!
		// The function returns a code for the operation.

		$gfxConf = $GLOBALS["TYPO3_CONF_VARS"]["GFX"];
		$returnCode="";
		if ($gfxConf["gif_compress"] && strtolower(substr($theFile,-4,4))==".gif")	{	// GIF...
			if (($type=="IM" || !$type) && $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im"] && $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"])	{	// IM
				exec($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"].'convert "'.$theFile.'" "'.$theFile.'"');
				$returnCode="IM";
			} elseif (($type=="GD" || !$type) && $gfxConf["gdlib"] && !$gfxConf["gdlib_png"])	{	// GD
				$tempImage = imageCreateFromGif($theFile);
				imageGif($tempImage, $theFile);
				imageDestroy($tempImage);
				$returnCode="GD";
			}
		}
		return $returnCode;
	}

	/**
	 *  Converts a png file to gif
	 *
	 * This converts a png file to gif IF the FLAG $GLOBALS["TYPO3_CONF_VARS"]["FE"]["png_to_gif"] is set true.
	 *
	 * @param 	string $theFile	the filename with path
	 * @return 	string 	new filename
	 */
	function png_to_gif_by_imagemagick($theFile)	{
		if ($GLOBALS["TYPO3_CONF_VARS"]["FE"]["png_to_gif"]
			&& $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im"]
			&& $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"]
			&& strtolower(substr($theFile,-4,4))==".png"
			&& @is_file($theFile))	{	// IM
				$newFile = substr($theFile,0,-4).".gif";
				exec($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_path_lzw"].'convert "'.$theFile.'" "'.$newFile.'"');
				$theFile = $newFile;
					// unlink old file?? May be bad idea bacause Typo3 would then recreate the file every time as Typo3 thinks the file is not generated because it's missing!! So do not unlink $theFile here!!
		}
		return $theFile;
	}

	/**
	 * Client Information
	 *
	 * @return 	string 	false (bool) on non-4+ browsers, "msie" if browser is IE, "net" if browser is navigator, "opera" if opera.
	 */
	function clientInfo($useragent="")	{
		if (!$useragent) $useragent=getenv("HTTP_USER_AGENT");

		$bInfo=array();
			// Which browser?
		if (strstr($useragent,"Konqueror"))	{
			$bInfo["BROWSER"]= "konqu";
		} elseif (strstr($useragent,"Opera"))	{
			$bInfo["BROWSER"]= "opera";
		} elseif (strstr($useragent,"MSIE 4") || strstr($useragent,"MSIE 5") || strstr($useragent,"MSIE 6"))	{
			$bInfo["BROWSER"]= "msie";
		} elseif (strstr($useragent,"Mozilla/4") || strstr($useragent,"Mozilla/5"))	{
			$bInfo["BROWSER"]="net";
		}
		if ($bInfo["BROWSER"])	{
				// Browser version
			switch($bInfo["BROWSER"])	{
				case "net":
					$bInfo["VERSION"]= doubleval(substr($useragent,8));
					if (strstr($useragent,"Netscape6/")) {$bInfo["VERSION"]=doubleval(substr(strstr($useragent,"Netscape6/"),10));}
				break;
				case "msie":
					$tmp = strstr($useragent,"MSIE");
					$bInfo["VERSION"] = doubleval(substr($tmp,4));
				break;
				case "opera":
					$tmp = strstr($useragent,"Opera");
					$bInfo["VERSION"] = doubleval(substr($tmp,5));
				break;
				case "konqu":
					$tmp = strstr($useragent,"Konqueror/");
					$bInfo["VERSION"] = doubleval(substr($tmp,10));
				break;
			}
				// Client system
			if (strstr($useragent,"Win"))	{
				$bInfo["SYSTEM"] = "win";
			} elseif (strstr($useragent,"Mac"))	{
				$bInfo["SYSTEM"] = "mac";
			} elseif (strstr($useragent,"Linux") || strstr($useragent,"X11") || strstr($useragent,"SGI") || strstr($useragent," SunOS ") || strstr($useragent," HP-UX "))	{
				$bInfo["SYSTEM"] = "unix";
			}
		}
			// Is true if the browser supports css to format forms, especially the width
		$bInfo["FORMSTYLE"]=($bInfo["BROWSER"]=="msie" || ($bInfo["BROWSER"]=="net"&&$bInfo["VERSION"]>=6) || $bInfo["BROWSER"]=="opera" || $bInfo["BROWSER"]=="konqu");
		return $bInfo;
	}

	/**
	 * Match IP number with list of numbers with wildcard
	 * $baseIP is the current remote IP address for instance and $list is a comma-list of IP-addresses to match with. *-wildcard allowed instead of number, plus leaving out parts in the IP number is accepted as wildcard (eg. 192.168.*.* equals 192.168)
	 */
	function cmpIP($baseIP, $list)	{
		$IPpartsReq = explode(".",$baseIP);
		if (count($IPpartsReq)==4)	{
			$values = t3lib_div::trimExplode(",",$list,1);
			reset($values);
			while(list(,$test)=each($values))	{
				$IPparts = explode(".",$test);
				$yes = 1;
				reset($IPparts);
				while(list($index,$val)=each($IPparts))	{
					$val = trim($val);
					if ($val!="*" && strcmp($IPpartsReq[$index],$val))	{
						$yes=0;
					}
				}
				if ($yes) return true;
			}
		}
	}




	/*
	 * STRING FUNCTIONS:
	 */


	/**
	 * Truncate string
	 *
	 * Returns a new string of max. $chars length.
	 * If the string is longer, it will be truncated and appended with "...".
	 *
	 * @param 	string $string 	string to truncate
	 * @param 	integer $chars 	must be an integer of at least 4
	 * @return 	string 	new string
	 */
	function fixed_lgd($string,$chars)	{
		if ($chars >= 4)	{
			if(strlen($string)>$chars)  {
				return trim(substr($string, 0, $chars-3))."...";
			}
		}
		return $string;
	}

	/**
	 * Truncate string
	 *
	 * Returns a new string of max. $chars length.
	 * If the string is longer, it will be truncated and prepended with "...".
	 *
	 * This works like fixed_lgd, but is truncated in the start of the string instead of the end
	 *
	 * @param 	string $string 	string to truncate
	 * @param 	integer $chars 	must be an integer of at least 4
	 * @return 	string 	new string
	 */
	function fixed_lgd_pre($string,$chars)	{
		return strrev(t3lib_div::fixed_lgd(strrev($string),$chars));
	}

	/**
	 * " " -> &nbsp;
	 *
	 * Replaces all chr(32)-characters (spaces) with "$nbsp;".
	 *
	 * @param 	string $string
	 * @return 	string 	new string
	 */
	function hardspace($string)		{
		return ereg_replace(" ", "&nbsp;", $string);
	}

	/**
	 *
	 *
	 * Inserts a "\n"-character (return-character) for each $interval character. Used for breaking up a base64 encoded string.
	 *
	 * @param  	string $inputstr
	 * @param 	char $interval 	character to replace with "\n"
	 * @return 	string 	new string
	 */
	function break_text($inputstr, $interval)	{
		$returncode = "\n";
		return chunk_split($inputstr,$interval,$returncode);
	}

	/**
	 * Breaks up the text for emails
	 */
	function breakTextForEmail($str,$implChar="\n",$charWidth=76)	{
		$lines = explode(chr(10),$str);
		$outArr=array();
		while(list(,$lStr)=each($lines))	{
			$outArr = array_merge($outArr,t3lib_div::breakLinesForEmail($lStr,$implChar,$charWidth));
		}
		return implode(chr(10),$outArr);
	}

	/**
	 * Breaks up the text for emails
	 */
	function breakLinesForEmail($str,$implChar="\n",$charWidth=76)	{
		$lines=array();
		$l=$charWidth;
		$p=0;
		while(strlen($str)>$p)	{
			$substr=substr($str,$p,$l);
			if (strlen($substr)==$l)	{
				$count = count(explode(" ",trim(strrev($substr))));
//				debug($parts);
//				debug($count);
//				if (count($parts)>1)	{	// OK...
				if ($count>1)	{	// OK...
					$parts = explode(" ",strrev($substr),2);
					$theLine = strrev($parts[1]);
				} else {
					$afterParts = explode(" ",substr($str,$l+$p),2);
					$theLine = $substr.$afterParts[0];
	//				debug($theLine);
				}
				if (!strlen($theLine))	{break; }	// Error, because this would keep us in an endless loop.
			} else {
				$theLine=$substr;
			}

			$lines[]=trim($theLine);
			$p+=strlen($theLine);
			if (!trim(substr($str,$p,$l)))	break;	// added...
		}
		return implode($implChar,$lines);
	}	
	
	/**
	 * Removes linebreaks
	 *
	 * Removes all "\n" characters (return-char) from $inputstr.
	 *
	 * @param  	string $inputstr
	 * @return 	string 	new string
	 */
	function unbreak_text($inputstr)	{
		return ereg_replace(chr(10),"",$inputstr);
	}

	/**
	 * Check for item in list
	 *
	 * Check if an item exists in a comma-separated list of items.
	 *
	 * @param 	string $in_list 	comma-separated list of items (string)
	 * @param 	string $item 	item to check for
	 * @return 	bool 		true if $item is in $in_list
	 */
	function inList($in_list,$item)	{
		return strstr(",".$in_list.",", ",".$item.",");
	}

	/**
	 * Check if an item exists in an array
	 *
	 * Please note that the order of parameters is reverse compared to the php4-function in_array()!!!
	 *
	 * @param 	array  $in_array		one-dimensional array of items
	 * @param  	string $item 	item to check for
	 * @return 	bool 		true if $item is in the one-dimensional array $in_array
	 */
	function inArray($in_array,$item)	{
		if (is_array($in_array))	{
			while (list(,$val)=each($in_array))	{
				if (!is_array($val) && !strcmp($val,$item)) return true;
			}
		}
	}

	/**
	 *
	 *
	 * Removes an item from a comma-separated list of items.
	 *
	 * @param 	string $element  	element to remove
	 * @param 	string $list 	comma-separated list of items (string)
	 * @return 	string 	new comma-separated list of items
	 */
	function rmFromList($element,$list)	{
		$items = explode(",",$list);
		while(list($k,$v)=each($items))	{
			if ($v==$element)	{unset($items[$k]);}
		}
		return implode($items,",");
	}

	function intInRange($theInt,$min,$max=2000000000,$zeroValue=0)	{
		// Returns $theInt as an integer in the integerspace from $min to $max
		$theInt = intval($theInt);
		if ($zeroValue && !$theInt)	{$theInt=$zeroValue;}	// If the input value is zero after being converted to integer, zeroValue may set another default value for it.
		if ($theInt<$min){$theInt=$min;}
		if ($theInt>$max){$theInt=$max;}
		return $theInt;
	}
	function intval_positive($theInt)	{
		$theInt = intval($theInt);
		if ($theInt<0){$theInt=0;}
		return $theInt;
	}
	function intExplode($delim, $string)	{
		// This explodes a comma-list into an array where the values are parsed through intval();
		$temp = explode($delim,$string);
		while(list($key,$val)=each($temp))	{
			$temp[$key]=intval($val);
		}
		reset($temp);
		return $temp;
	}
	function revExplode($delim, $string, $count=0)	{
		$temp = explode($delim,strrev($string),$count);
		while(list($key,$val)=each($temp))	{
			$temp[$key]=strrev($val);
		}
		$temp=array_reverse($temp);
		reset($temp);
		return $temp;
	}
	function trimExplode($delim, $string, $onlyNonEmptyValues=0)	{
		// This explodes a comma-list into an array where the values are parsed through trim();
		$temp = explode($delim,$string);
		$newtemp=array();
		while(list($key,$val)=each($temp))	{
			if (!$onlyNonEmptyValues || strcmp("",trim($val)))	{
				$newtemp[]=trim($val);
			}
		}
		reset($newtemp);
		return $newtemp;
	}
	function extParseUrl($path)	{
		// This returns something like t3lib_div::split_fileref(not sure...)
		$res = parse_url($path);
		$res["fullpath"] = $path;
		ereg("(.*/)([^/]*)$",$res[path],$reg);
		$res["filepath"]=$reg[1];
		$res["filename"]=$reg[2];
		return $res;
	}
	function split_fileref($fileref)	{
		// Splits a reference to a file in 5 parts
		// returns and array: [path], [file], [filebody], [fileext], [realFileext]
		if (	ereg("(.*/)(.*)$",$fileref,$reg)	)	{
			$info["path"] = $reg[1];
			$info["file"] = $reg[2];
		} else {
			$info["path"] = "";
			$info["file"] = $fileref;
		}
		$reg="";
		if (	ereg("(.*)\.([^\.]*$)",$info[file],$reg)	)	{
			$info["filebody"] = $reg[1];
			$info["fileext"] = strtolower($reg[2]);
			$info["realFileext"] = $reg[2];
		} else {
			$info["filebody"] = $info[file];
			$info["fileext"] = "";
		}
		reset($info);	
		return $info;
	}
	function modifyHTMLColor($color,$R,$G,$B)	{
		// This takes a hex-color (# included!) and adds $R, $G and $B to the HTML-color (format: #xxxxxx) and returns the new color
		$nR = t3lib_div::intInRange(hexdec(substr($color,1,2))+$R,0,255);
		$nG = t3lib_div::intInRange(hexdec(substr($color,3,2))+$G,0,255);
		$nB = t3lib_div::intInRange(hexdec(substr($color,5,2))+$B,0,255);
		return "#".dechex($nR).dechex($nG).dechex($nB);
	}
	function rm_endcomma($string)	{
		// This removes the comma in the end of a list
		return ereg_replace(",$","",$string);
	}
	function danish_strtoupper($string)	{
		// strToUpper with danish and other characters
		$value = strtoupper($string);
		return strtr($value, "���������������", "���������������");
	}
	function split_attributes($tag, $specchars="+-")	{
		// Returns an array with the components from a attribute-list. The result is normally analyzed by get_tag_attributes.
		// Removes tag if present
		$tag_tmp = $tag;
		$specs = "[".quotemeta($specchars)."]";

		while ($tag_tmp)	{
			if (ereg("^\"",$tag_tmp))	{
				// Der er g�se�jne omkring v�rdien. Der ledes efter n�ste "
				$tag_tmp = ereg_replace("^\"","",$tag_tmp);		// Fjerner f�rst g�se�je.
				ereg("^[^\"]*",$tag_tmp,$reg);  // Tager alt indtil n�ste g�se�je
				$value[] = $reg[0];  // reg[0] er lig med v�rdien!! Skal ikke trimmes
				$tag_tmp = ereg_replace("^".quotemeta($reg[0]),"",$tag_tmp);
				$tag_tmp = trim(ereg_replace("^\"","",$tag_tmp));		// Fjerner det sidste g�se�je.
			} elseif (ereg("^$specs",$tag_tmp,$reg)) {
				$value[] = $reg[0];
				$tag_tmp = trim(ereg_replace("^$specs","",$tag_tmp));		// Fjerner = tegn.
			} else {
				// Der er ikke g�se�jne om v�rdien. Der ledes efter n�ste " " eller ">"
				ereg("^[^ ".quotemeta($specchars)."]*",$tag_tmp,$reg);
				$value[] = trim($reg[0]);
				$tag_tmp = trim(ereg_replace("^".quotemeta($reg[0]),"",$tag_tmp));
			}
		}
		reset($value);
		return $value;
	}
	function splitCalc($string,$operators)	{
		// This splits a string by the chars in $operators (typical +-*/) and returns an array with them in
		$res = Array();
		$sign="+";
//		debug($string);
		while($string)	{
			$valueLen=strcspn($string,$operators);
			$value=substr($string,0,$valueLen);
			$res[] = Array($sign,trim($value));
			$sign=substr($string,$valueLen,1);
			$string=substr($string,$valueLen+1);
		}
		reset($res);
		return $res;
	}

	/**
	 * Calculates the input by +,-,*,/,%,^ with priority to + and -
	 */
	function calcPriority ($string)	{
//		$string = "-5*-3446.234*-7*8 + 9 ^ - 3 +-20%-3 /-2 / 3";
		$string=ereg_replace("[[:space:]]*","",$string);	// removing all whitespace
		$string="+".$string;	// Ensuring an operator for the first entrance
		$qm="\*\/\+-^%";
		$regex = "([$qm])([$qm]?[0-9\.]*)";
			// split the expression here:
		preg_match_all("/".$regex."/",$string,$reg);
//		debug($reg);	// This is the numbers and their operators
		
		reset($reg[2]);
		$number=0;
		$Msign="+";
		$err="";	
		$buffer=doubleval(current($reg[2]));
		next($reg[2]);	// Advance pointer
		while(list($k,$v)=each($reg[2]))	{
			$v=doubleval($v);
			$sign = $reg[1][$k];
			if ($sign=="+" || $sign=="-")	{
				$number = $Msign=="-" ? $number-=$buffer : $number+=$buffer;
				$Msign = $sign;
				$buffer=$v;
			} else {
				if ($sign=="/")	{if ($v) $buffer/=$v; else $err="dividing by zero";}
				if ($sign=="%")	{if ($v) $buffer%=$v; else $err="dividing by zero";}
				if ($sign=="*")	{$buffer*=$v;}
				if ($sign=="^")	{$buffer=pow($buffer,$v);}
			}
		}
		$number = $Msign=="-" ? $number-=$buffer : $number+=$buffer;
		return $err ? "ERROR: ".$err : $number;
	}

	/**
	 * Calculates the input with parenthesis levels
	 */
	function calcParenthesis ($string)	{
		$securC=100;
		do {
			$valueLenO=strcspn($string,"(");
			$valueLenC=strcspn($string,")");
			if ($valueLenC==strlen($string) || $valueLenC < $valueLenO)	{
				$value = t3lib_div::calcPriority(substr($string,0,$valueLenC));
				$string = $value.substr($string,$valueLenC+1);
				return $string;
			} else {
				$string = substr($string,0,$valueLenO).t3lib_div::calcParenthesis(substr($string,$valueLenO+1));
			}
				// Security:
			$securC--;
			if ($securC<=0)	break;
		} while($valueLenO<strlen($string));
		return $string;
	}
	function uniqueArray($valueArray)	{
		// Takes a one-dimensional array and returns an array where the values are unique
		// The keys in the array are substituted with some md5-hashes
		// If the value is trim(empty), the value is ignored.
		// Values are trimmed
		$array_out=array();
		if (is_array($valueArray))	{
			while (list($key,$val)=each($valueArray)) {
				$val=trim($val);
				if ((string)$val!="")	{
					$array_out[md5($val)]=$val;
				}
			}
		}
		reset($array_out);
		return $array_out;
	}
	function uniqueList($in_list)	{
		// $in_list is a comma-separated list of values.
		// This function returns the list without any duplicates of values
		// space around values are trimmed
		$theTempArray = explode(",",$in_list);
		return implode(t3lib_div::uniqueArray($theTempArray),",");
	}
	function removeArrayEntryByValue($array,$cmpValue)	{
		if (is_array($array))	{
			reset($array);
			while(list($k,$v)=each($array))	{
				if (is_array($v))	{
					$array[$k] = t3lib_div::removeArrayEntryByValue($v,$cmpValue);
				} else {
					if (!strcmp($v,$cmpValue))	{
						unset($array[$k]);
					}
				}
			}
		}
		reset($array);
		return $array;
	}
	function shortMD5($input, $len=10)	{
		// Returns the first 10 positions of the MD5-hash		(changed from 6 to 10 recently)
		// This is used for filenames...
		return substr(md5($input),0,$len);
	}
	function testInt($var)	{
		// returns true if string is an integer
		return !strcmp($var,intval($var));
	}
	function isFirstPartOfStr($str,$partStr)	{
		// Returns true, if the first part of a $str equals $partStr and $partStr is not ""
		$psLen = strlen($partStr);
		if ($psLen)	{
			return substr($str,0,$psLen)==(string)$partStr;
		} else return false;
	}
	function formatSize($sizeInBytes)	{
		// Formats a number to Mb or Kb or just bytes
		if ($sizeInBytes>900)	{
			if ($sizeInBytes>900000)	{	// MB
				$val = $sizeInBytes/(1024*1024);
				return number_format($val, (($val<20)?1:0), ".", "")." M";
			} else {	// KB
				$val = $sizeInBytes/(1024);
				return number_format($val, (($val<20)?1:0), ".", "")." K";
			}
		} else {	// Bytes
			return $sizeInBytes."&nbsp;&nbsp;";
		}
	}

	/** 
	 * Returns microtime input to milliseconds
	 */
	function convertMicrotime($microtime)	{
		$parts = explode(" ",$microtime);
		return round(($parts[0]+$parts[1])*1000);
	}

	/** 
	 * implodes a multidim-array into URL-params
	 */
	function implodeArrayForUrl($name,$theArray,$str="")	{	
		if (is_array($theArray))	{
			reset($theArray);
			while(list($Akey,$AVal)=each($theArray))	{
				$thisKeyName = $name ? $name."[".$Akey."]" : $Akey;
				if (is_array($AVal))	{
					$str=t3lib_div::implodeArrayForUrl($thisKeyName,$AVal,$str);
				} else {
					$str.="&".$thisKeyName."=".rawurlencode(stripslashes($AVal));	// strips slashes because HTTP_POST_VARS / GET_VARS input is with slashes...
				}
			}
		}
		return $str;
	}

	function compileSelectedGetVarsFromArray($varList,$getArray,$GPvarAlt=1)	{
		$keys = t3lib_div::trimExplode(",",$varList,1);
		$outArr=array();
		while(list(,$v)=each($keys))	{
			if (isset($getArray[$v]))	{
				$outArr[$v]=$getArray[$v];
			} elseif ($GPvarAlt) {
				$outArr[$v]=t3lib_div::GPvar($v);
			}
		}
		return $outArr;
	}	
	/** 
	 * Returns the link-url to the current script. In $getParams you can set associative keys corresponding to the get-vars you wish to add to the url. If you set them empty, they will remove existing get-vars from the current url.
	 */
	function linkThisScript($getParams=array())	{	
		$parts = t3lib_div::getIndpEnv("SCRIPT_NAME");
		$params = $GLOBALS["HTTP_GET_VARS"];
		reset($getParams);
		while(list($k,$v)=each($getParams))	{
			if (strcmp($v,""))	{
				$params[$k]=$v;
			} else unset($params[$k]);
		}
		$pString = t3lib_div::implodeArrayForUrl("",$params);
		return $pString ? $parts."?".ereg_replace("^&","",$pString) : $parts;
	}
	
	function linkThisUrl($url,$getParams=array())	{
		$parts = parse_url($url);
		if ($parts["query"])	{
			parse_str($parts["query"],$getP);
		} else $getP=array();
		$getP=t3lib_div::array_merge_recursive_overrule($getP,$getParams);
		$uP = explode("?",$url);
		$outurl = $uP[0]."?".t3lib_div::implodeArrayForUrl("",$getP);
		return $outurl;
	}

	/**
	* AddSlash array
	*
	* This function traverses a multidimentional array and adds slashes to the values.
	* NOTE that the input array is and argument by reference.!!
	* Twin-function to stripSlashesOnArray
	*/
	function addSlashesOnArray(&$theArray)	{
		if (is_array($theArray))	{
			reset($theArray);
			while(list($Akey,$AVal)=each($theArray))	{
				if (is_array($AVal))	{
					t3lib_div::addSlashesOnArray($theArray[$Akey]);
				} else {
					$theArray[$Akey] = addslashes($AVal);
				}
			}
			reset($theArray);
		}
	}

	/**
	* StripSlash array
	*
	* This function traverses a multidimentional array and strips slashes to the values.
	* NOTE that the input array is and argument by reference.!!
	* Twin-function to addSlashesOnArray
	*/
	function stripSlashesOnArray(&$theArray)	{
		if (is_array($theArray))	{
			reset($theArray);
			while(list($Akey,$AVal)=each($theArray))	{
				if (is_array($AVal))	{
					t3lib_div::stripSlashesOnArray($theArray[$Akey]);
				} else {
					$theArray[$Akey] = stripslashes($AVal);
				}
			}
			reset($theArray);
		}
	}

	function slashArray($arr,$cmd)	{
		if ($cmd=="strip")	t3lib_div::stripSlashesOnArray($arr);
		if ($cmd=="add")	t3lib_div::addSlashesOnArray($arr);
		return $arr;
	}

	function slashJS($string,$extended=0)	{
		// This function is used to escape any ' -characters when transferring text to JavaScript!
		if ($extended)	{$string = str_replace ("\\", "\\\\", $string);}
		return str_replace ("'", "\'", $string);
	}	
	function rawUrlEncodeJS($str)	{
		return str_replace("%20"," ",rawurlencode($str));
	}
	
	
	/*
	 *  Merges two arrays recursively, overruling the values of the first array
	 *  in case of identical keys, ie. keeping the values of the second.
	 */

	function array_merge_recursive_overrule ($arr0,$arr1) {
		reset($arr1);
		while(list($key,$val) = each($arr1)) {
			if(is_array($arr0[$key])) {
				if (is_array($arr1[$key]))	{
					$arr0[$key] = t3lib_div::array_merge_recursive_overrule($arr0[$key],$arr1[$key]);
				}
			} else {
				$arr0[$key] = $val;
			}
		}
		reset($arr0);
		return $arr0;
	}
	
	/*
	* functions that does stuff with HTML-tags
	*
	*/
	function get_tag_attributes($tag)	{
		// $tag is either a whole tag (eg "<TAG OPTION ATTRIB=VALUE>") or the parameterlist (ex " OPTION ATTRIB=VALUE>")
		// Returns an array with all attributes as keys. Attributes are only lowercase a-z
		// If a attribute is empty (I call it "an option"), then the value for the key is empty. You can check if it existed with isset()

		$components = t3lib_div::split_tag_attributes($tag);
		$name = "";	 // attribute name is stored here
		$valuemode = "";
		if (is_array($components))	{
			while (list($key,$val) = each ($components))	{
				if ($val != "=")	{	// Only if $name is set (if there is an attribute, that waits for a value), that valuemode is enabled. This ensures that the attribute is assigned it's value
					if ($valuemode)	{
						if ($name)	{
							$attributes[$name] = $val;
							$name = "";
						}
					} else {
						if ($key = strtolower(ereg_replace("[^a-zA-Z0-9]","",$val)))	{
							$attributes[$key] = "";
							$name = $key;
						}
					}
					$valuemode = "";
				} else {
					$valuemode = "on";
				}
			}
			if (is_array($attributes))	reset($attributes);
			return $attributes;
		}
	}
	function split_tag_attributes($tag)	{
		// Returns an array with the "components" from an attribute list. The result is normally analyzed by get_tag_attributes
		// Removes tag-name if found
		$tag_tmp = trim(eregi_replace ("^[ ]*<[^ ]*","",$tag));
			// Removes any > in the end of the string
		$tag_tmp = trim(eregi_replace (">$","",$tag_tmp));

		while (strcmp($tag_tmp,""))	{	// Compared with empty string instead , 030102
			$firstChar=substr($tag_tmp,0,1);
			if (!strcmp($firstChar,'"') || !strcmp($firstChar,"'"))	{
				$reg=explode($firstChar,$tag_tmp,3);
				$value[]=$reg[1];
				$tag_tmp=trim($reg[2]);
			} elseif (!strcmp($firstChar,"=")) {
				$value[] = "=";
				$tag_tmp = trim(substr($tag_tmp,1));		// Removes = chars.
			} else {
				// There are "" around the value. We look for the next " " or ">"
				$reg = split("[[:space:]=]",$tag_tmp,2);
				$value[] = trim($reg[0]);
				$tag_tmp = trim(substr($tag_tmp,strlen($reg[0]),1).$reg[1]);
			}
		}
		if (is_array($value))	reset($value);
		return $value;
	}
	function implodeParams($arr)	{
		if (is_array($arr))	{
			reset($arr);
			$list = array();
			while(list($p,$v)=each($arr))	{
				if (strcmp($v,""))	{$list[]=$p.'="'.$v.'"';}
			}
			return implode(" ",$list);
		}
	}
	function imagefinder($html_code)	{
		// Finds all (unique) image-references in $html_code's IMG-tags
		// Does not cover JavaScript, background images and images in form-buttons

		// returns a two-dim array with all the pictures:
		// $images[$i][filename][fullpath]
		// $images[$i][filename][name]
		// $images[$i][filename][path]
		// $images[$i][width]
		// $images[$i][height]
		// $images[$i][alt]

		$codepieces = split(sql_regcase("<img "), $html_code, 1000000 );
		$pieces = count($codepieces);
		$image_fullpath_list = "";

		for($i=1; $i < $pieces; $i++)	{
			$dummy = eregi("[^>]*", $codepieces[$i], $reg);
			$image = $reg[0];
			$attributes = t3lib_div::get_tag_attributes($image);
			$img_pathname = split_path_and_name ($attributes[src]);
			if (!strstr($image_fullpath_list,"|".$img_pathname[fullpath]."|") )
			{
				$image_fullpath_list.="|".$img_pathname[fullpath]."|";
				$images[$i][filename]=$img_pathname;
				$images[$i][width]=$attributes[width];
				$images[$i][height]=$attributes[height];
				$images[$i][alt]=$attributes[alt];
			}
		}
		if (is_array($images))	reset($images);		
		return $images;
	}
	function linkfinder($html_code)	{
		// Finds all links in $html_code
		$codepieces = split(sql_regcase("<a "), $html_code, 1000000 );
		$pieces = count($codepieces);
		$image_fullpath_list = "";

		for($i=1; $i < $pieces; $i++)	{
			$dummy = eregi("[^>]*", $codepieces[$i], $reg);
			$link = $reg[0];
			$attributes = t3lib_div::get_tag_attributes($link);
			$link_pathname = split_path_and_name ($attributes[href]);
			if (!strstr($link_fullpath_list,"|".$link_pathname[fullpath]."|") )
			{
				$link_fullpath_list.="|".$link_pathname[fullpath]."|";
				$links[$i][filename]=$link_pathname;
			}
		}
		if (is_array($links))	reset($links);
		return $links;
	}


	/*
	* functions that helps your to work with files on the server
	*
	*/

	function getURL($url)	{
		// Reads the file or url $url and returns the content
		if($fd = fopen($url,"r"))	{
			$content = "";
			while (!feof($fd))	{
				$content.=fread($fd, 5000);
			}
			fclose($fd);
			return $content;
		}
	}
	function getStrippedURL($url)	{
		// Reads the file or url $url and returns the content. Any HTML is stripped
		if($fd = fopen($url,"r"))	{
			$content = "";
			while (!feof($fd))	{
				$content.=trim(fgetss($fd,5000));
			}
			fclose($fd);
			return $content;
		}
	}
	function getMimeType($url)	{
		// This functions tries to open a url and decide the mime-type of that url
		$pathInfo = parse_url($url);
		$getAdr = ($pathInfo[query])?$pathInfo[path]."?".$pathInfo[query]:$pathInfo[path];
		$fp = fsockopen($pathInfo[host], 80, $errno, $errstr);
		if(!$fp) {
			return false;
		} else {
	        fputs($fp,"GET ".$getAdr." HTTP/1.0\n\n");
	        while(!feof($fp)) {
				$thePortion= fgets($fp,128);
				if (eregi("(^Content-Type: )(.*)",trim($thePortion), $reg))	{
					$res = trim($reg[2]);
					break;
				}
	        }
	        fclose($fp);
		}
		return $res;
	}
	function writeFile($file,$content)	{
		// Writes $content to the file $file
		if($fd = fopen($file,"w"))	{
			fwrite( $fd, $content);
			fclose( $fd );
			return true;
		}
	}
	function get_dirs($path)	{
		// Returns an array with the names of folders in a specific path
		if ($path)	{
			$d = @dir($path);
			if (is_object($d))	{
				while($entry=$d->read()) {
					if (@is_dir($path."/".$entry) && $entry!= ".." && $entry!= ".")	{
					    $filearray[]=$entry;
					}
				}
				$d->close();
			} else return "error";
			return $filearray;
		}
	}
	function getFilesInDir($path,$extensionList="",$prependPath=0,$order="")	{
		// Returns an array with the names of files in a specific path
		$filearray=array();
		$sortarray=array();
		if ($path)	{
			$path = ereg_replace("/$","",$path);
			$extensionList = strtolower($extensionList);
			$d = @dir($path);
			if (is_object($d))	{
				while($entry=$d->read()) {
					if (@is_file($path."/".$entry))	{	
						$fI = pathinfo($entry);
						$key = md5($path."/".$entry);
						if (!$extensionList || t3lib_div::inList($extensionList,strtolower($fI["extension"])))	{
						    $filearray[$key]=($prependPath?$path."/":"").$entry;
							if ($order=="mtime") {$sortarray[$key]=filemtime($path."/".$entry);}
								elseif ($order)	{$sortarray[$key]=$entry;}
						}
					}
				}
				$d->close();
			} else return "error";
		}
		if ($order) {
			asort($sortarray);
			reset($sortarray);
			$newArr=array();
			while(list($k,$v)=each($sortarray))	{
				$newArr[$k]=$filearray[$k];
			}
			$filearray=$newArr;
		}
		reset($filearray);
		return $filearray;
	}




	/**
	* debug-functions
	*/
	function debug_white_space($string)	{
		// Returns a string with a list of ascii-values for all whitespace in the beginning of $string
		if(eregi("^[ ".chr(13).chr(10)."]*",$string,$reg))	{
			return debug_print_ordvalue($reg[0],strlen($reg[0]));
		}
	}
	function debug_ordvalue($string,$characters=100)	{
		// Returns a string with a list of ascii-values for the first $characters characters in $string
		if(strlen($string) < $characters)
			$characters = strlen($string);
		for ($i=0; $i<$characters; $i++)	{
			$valuestring .= " ".ord(substr($string,$i,1));
		}
		return ereg_replace("^ ","",$valuestring);
	}
	function debug_code($string)	{
		echo "<hr>";
		echo nl2br(HTMLSpecialChars($string));
		echo "<hr>";
	}
	function parsetime($starttime)	{
		// Prints the difference in milliseconds between the current time and $starttime (milliseconds)
		// This is useful for measuring the execution speed by first loading the time in t3lib_div::milliseconds($pretime=t3lib_div::milliseconds()) and after a function-call pass $pretime to t3lib_div::parsetime()
		echo '<font face="Verdana" size="1" color="Black"><b>Parsetime: '.(t3lib_div::milliseconds()-$starttime).' ms</b></font>';
	}
	function view_array($array_in)	{
		// Returns HTML-code, which is a visual representation of a multidimensional array
		// use t3lib_div::print_array() in order to print an array
		// Returns false if $array_in is not an array
		if (is_array($array_in))	{
			$result='<table border=1 cellpadding=1 cellspacing=0 bgcolor=white>';
			if (!count($array_in))	{$result.= '<tr><td><font face="Verdana,Arial" size="1"><b>'.HTMLSpecialChars("EMPTY!").'</b></font></td></tr>';}
			while (list($key,$val)=each($array_in))	{
				$result.= '<tr><td><font face="Verdana,Arial" size="1">'.HTMLSpecialChars($key).'</font></td><td>';
				if (is_array($array_in[$key]))	{
					$result.=t3lib_div::view_array($array_in[$key]);
				} else
					$result.= '<font face="Verdana,Arial" size="1" color=red>'.nl2br(HTMLSpecialChars($val)).'<BR></font>';
				$result.= '</td></tr>';
			}
			$result.= '</table>';
		} else	{
			$result  = false;
		}
		return $result;
	}
	function print_array($array_in)	{
		// Prints an array
		echo t3lib_div::view_array($array_in);
	}

	/**
	* makes debug output
	*
	* Prints $var in bold between two vertical lines
	* If not $var the word "debug" is printed
	* If $var is an array, the array is printed by t3lib_div::print_array()
	*/
	function debug($var="",$br=0)	{
		// Prints $var in bold between two vertical lines
		// If not $var the word "debug" is printed
		// If $var is an array, the array is printed by t3lib_div::print_array()

		if ($br<0) {for($a=0;$a<abs(intval($br));$a++){echo "<BR>";}}
		if (is_array($var))	{
			t3lib_div::print_array($var);
		} elseif ((string)$var!="")
			echo "<B>|".HTMLSpecialChars($var)."|</B>";
		else
			echo "<B>| debug |</B>";

		if ($br>0) {for($a=0;$a<intval($br);$a++){echo "<BR>";}}
	}
	
	function getThisUrl()	{
		$p=parse_url("http://".getenv("HTTP_HOST").t3lib_div::getIndpEnv("SCRIPT_NAME"));		// Url of this script
		$dir=dirname($p["path"]);	// Strip file
		if (substr($dir,-1)!="/")	{
			$dir.="/";
		}
		$url = str_replace("//","/",$p["host"].($p["port"]?":".$p["port"]:"").$dir);
		return $url;
	}
	function validEmail($email)	{
		if (strstr($email," "))	 return 0;
		return ereg("^[A-Za-z0-9\._-]*[@][A-Za-z0-9\._-]*[\.].[A-Za-z0-9]*$",$email) ? 1 : 0;
	}
	function stdAuthCode($uid_or_record,$fields="")	{
		if (is_array($uid_or_record))	{	
			$recCopy_temp=array();
			if ($fields)	{
				$fieldArr = t3lib_div::trimExplode(",",$fields,1);
				reset($fieldArr);
				while(list($k,$v)=each($fieldArr))	{
					$recCopy_temp[$k]=$recCopy[$v];
				}
			} else {
				$recCopy_temp=$recCopy;
			}
			$preKey = implode("|",$recCopy_temp);
		} else {
			$preKey = $uid_or_record;
		}

		$authCode = $preKey."||".$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["encryptionKey"];
		$authCode = substr(md5($authCode),0,8);
		return $authCode;
	}	

	function loadTCA($table)	{
		global $TCA,$LANG_GENERAL_LABELS;
			// 1) must be configured table (the ctrl-section configured), 
			// 2) columns must not be an array (which it is always if whole table loaded, and
			// 3) there is a value for dynamicConfigFile (filename in typo3conf)
		if (isset($TCA[$table]) && !is_array($TCA[$table]["columns"]) && $TCA[$table]["ctrl"]["dynamicConfigFile"])	{
			if (!strcmp(substr($TCA[$table]["ctrl"]["dynamicConfigFile"],0,6),"T3LIB:"))	{
				include_once(PATH_t3lib."install/".substr($TCA[$table]["ctrl"]["dynamicConfigFile"],6));
			} else include(PATH_typo3conf.$TCA[$table]["ctrl"]["dynamicConfigFile"]);
	//	debug($table,1);
		}
	//	$GLOBALS["loadTCA_tables"][$table]++;
	//	debug($table,1);
	}

	function csvValues($row,$delim=",",$quote='"')	{
		reset($row);
		$out=array();
		while(list(,$value)=each($row))	{
			list($valPart) = explode(chr(10),$value);
			$valPart = trim($valPart);
			$out[]=str_replace($quote,$quote.$quote,$valPart);
		}
		$str = $quote.implode($quote.$delim.$quote,$out).$quote;
		return $str;
	}
	/**
	 * All content outputted in a textarea form should be passed through this function
	 * Not only is the content htmlspecialchar'ed on output but there is also a single newline added in the top. The newline is necessary because browsers will ignore the first newline after <textarea> if that is the first character. Therefore better set it!
	 */
	function formatForTextarea($content)	{
//		debug(md5($content));
		return chr(10).htmlspecialchars($content);
	}
	
	
	function callUserFunction($funcName,&$params,&$ref,$checkPrefix="user_",$silent=0)	{
		if ($checkPrefix && strcmp(substr(trim($funcName),0,strlen($checkPrefix)),$checkPrefix))	{
			if (!$silent)	debug("Function '".$funcName."' was not prepended with '".$checkPrefix."'",1);
			return $content;
		}

		$parts = explode("->",$funcName);
		if (count($parts)==2)	{	// Class
			if (class_exists($parts[0]))	{
				$classObj = new $parts[0];
				if (method_exists($classObj, $parts[1]))	{
				 	$content = call_user_method($parts[1], $classObj, $params, $ref);
				} else {
					if (!$silent)	debug("<strong>ERROR:</strong> No method name '".$parts[1]."' in class ".$parts[0],1);
				}
			} else {
				if (!$silent)	debug("<strong>ERROR:</strong> No class named: ".$parts[0],1);
			}
		} else {	// Function
			if (function_exists($funcName))	{
			 	$content = call_user_func($funcName, $params, $ref);
			} else {
				if (!$silent)	debug("<strong>ERROR:</strong> No function named: ".$funcName,1);
			}
		}
		return $content;
	}
	
	
	
	function makeInstance($className)	{
		$className = class_exists("ux_".$className)?"ux_".$className:$className;
		return new $className;
	}
	function makeInstanceClassName($className)	{
		return class_exists("ux_".$className)?"ux_".$className:$className;
	}
	function htmlspecialchars_decode($value)	{
		$value = str_replace("&gt;",">",$value);
		$value = str_replace("&lt;","<",$value);
		$value = str_replace("&quot;",'"',$value);
		$value = str_replace("&amp;","&",$value);
		return $value;
	}
	function getIndpEnv($getEnvName)	{
		switch((string)$getEnvName)	{
			case "SCRIPT_NAME":
				$uI=parse_url(getenv("REQUEST_URI"));
				//debug($uI["path"],1);
				//debug(getenv($getEnvName),2);
				// Only problem seems to be that the $uI["path"] does not contain the script-name if the script name is NOT in the REQUEST_URI - which it is not, if you call a index.php scrip like "/.../../"
				// return $uI["path"];
				// Reports has said that the problem is solved on some systems (eg. Typo3 installation (Windows XP, apache 1.3.22, php 4.1.2 (CGI version)) by using getenv("PATH_INFO") - but that will not work on my UNIX I tell you! 
				// So what is the general solution, working on all platforms?
				return getenv("SCRIPT_NAME");
			break;
			default:
				return getenv($getEnvName);
			break;
		}
	}
}


?>