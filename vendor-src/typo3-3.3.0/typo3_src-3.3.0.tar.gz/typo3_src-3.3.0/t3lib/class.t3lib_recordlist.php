<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Library with a single function addElement that returns tablerows based on some input.
 * 
 * See db_list.php / file_list.php
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_recordList {
	var $iLimit = 10;			// default Max items shown 
	var $leftMargin = 0;					// leftMargin
	var $fixedL = 50;						// Max length of strings
	var $headLineCol = "#dddddd";			// Head line color
	var $subHeadLineCol = "#eeeeee";
	var $script = "";
	var $showIcon = 1;
	var $no_noWrap = 0;
	var $oddColumnsTDParams ="";		// If set this is <td>-params for odd columns in addElement. Used with db_layout / pages section
	var $thumbScript = "thumbs.php";
	var $setLMargin=1;		// Set to zero, if you don't want a left-margin with addElement function	
	
		// internal
	var $counter=0;		// Counter increased for each element. Used to index elements for the JavaScript-code that transfers to the clipboard
	var $backPath="";	
	var $fieldArray = Array();		// Decides the columns shown. Filled with values that refers to the keys of the data-array.
	var $totalItems = "";			// This could be set to the total number of items. Used by the fwd_rew_navigation...
	var $firstElementNumber=0;

	var $addElement_tdParams=array();		// Keys are fieldnames and values are td-parameters to add in addElement();
	
	
	function addElement($h,$icon,$data,$tdParams="",$lMargin="",$altLine="")	{
			// Returns a table-row...
			// $h is an integer >=1 and denotes how tall a element is. Set to "0" makes a halv line, -1 = full line, Set to 1 makes a "join" and above makes "line"
			// $icon is the image+<A> if the record. If not supplied the first "join"-icon will be a "line" instead
			// $data is the dataarray
			// $tdParams is insert in the <TD>-tags. Must carry a " " as first character
			// $lMargin is the leftMargin (integer)
			// $altLine is the HTML for an alternative "line"-icon (used in the top)
			// OBS: $this->fieldArray MUST be set!!!
		$noWrap = ($this->no_noWrap) ? "" : " nowrap";
		
		$out="<tr>";
		if ($this->setLMargin)	{
			$out.='<td width=1>'.($lMargin?'<img src="clear.gif" width='.$lMargin.' height=1>':'').'</td>';
		}
		if ($this->showIcon)	{
			$out.='<td valign="top" align="left" nowrap'.$tdParams.'>';
			
			if (!$h)	{
				$out.='<img src="'.$this->backPath.'t3lib/gfx/ol/halfline.gif" width=18 height=8>';
			} else {
				for ($a=0;$a<$h;$a++)	{
					if (!$a)	{
						if ($icon)	{
							$out.= ($altLine ? $altLine : '<img src="'.$this->backPath.'t3lib/gfx/ol/join.gif" width=18 height=16>').$icon;
						} else {
							$out.= $altLine ? $altLine : '<img src="'.$this->backPath.'t3lib/gfx/ol/line.gif" width=18 height=16>';
						}
					} else {
						$out.= $altLine ? $altLine :'<BR><img src="'.$this->backPath.'t3lib/gfx/ol/line.gif" width=18 height=16>';
					}
				}
			}
			$out.='</td>';
		}
		reset($this->fieldArray);
		$colsp="";
		$lastKey="";
		$c=0;

		$ccount=0;
		$tdP[0]= $this->oddColumnsTDParams ? $this->oddColumnsTDParams : $tdParams;
		$tdP[1]=$tdParams;

		while(list(,$vKey)=each($this->fieldArray))	{
			if (isset($data[$vKey]))	{
				if ($lastKey)	{	$out.='<td valign="top"'.$noWrap.$tdP[($ccount%2)].$colsp.$this->addElement_tdParams[$lastKey].'>'.$data[$lastKey].'</td>';	}
				$lastKey=$vKey;
				$c=1;
				$ccount++;
			} else {
				if (!$lastKey) {$lastKey=$vKey;}
				$c++;
			}
			if ($c>1)	{$colsp=' colspan="'.$c.'"';} else {$colsp='';}
		}
		if ($lastKey)	{	$out.='<td valign="top"'.$noWrap.$tdP[($ccount%2)].$colsp.$this->addElement_tdParams[$lastKey].'>'.$data[$lastKey].'</td>';	}

		$out.='</tr>';
		return $out;
	}
	function writeTop()	{
	}
	function writeBottom()	{
			// Finishes the list with the "stopper"-gif
		$this->HTMLcode.="<table border=0 cellpadding=0 cellspacing=0>";
		$theIcon='<img src="'.$this->backPath.'t3lib/gfx/ol/stopper.gif" width=18 height=16>';
		$this->HTMLcode.=$this->addElement(1,'','','',$this->leftMargin,$theIcon);
		$this->HTMLcode.="</table>";	
	}
	function fwd_rwd_nav($table="")	{
		$code="";
		if ($this->eCounter >= $this->firstElementNumber   &&   $this->eCounter < $this->firstElementNumber+$this->iLimit)	{
			if ($this->firstElementNumber && $this->eCounter==$this->firstElementNumber)	{
					// 	reverse
				$theData = Array();
				$titleCol=$this->fieldArray[0];
				$theData[$titleCol] = $this->fwd_rwd_HTML("fwd",$this->eCounter,$table);
				$code=$this->addElement(1,"",$theData);
			}
			return Array(1,$code);
		} else {
			if ($this->eCounter==$this->firstElementNumber+$this->iLimit)	{
					// 	forw
				$theData = Array();
				$titleCol=$this->fieldArray[0];
				$theData[$titleCol] = $this->fwd_rwd_HTML("rwd",$this->eCounter,$table);
				$code=$this->addElement(1,"",$theData);
			}
			return Array(0,$code);
		}
		
	}
	function fwd_rwd_HTML($type,$pointer,$table="")	{
		$tParam = $table ? "&table=".rawurlencode($table) : "";
		switch($type)	{
			case "fwd":
				return fw('&nbsp;<A href="'.$this->listURL().'&pointer='.($pointer-$this->iLimit).$tParam.'"><img src="'.$this->backPath.'gfx/pilup.gif" width=14 height=14 valign="top" border=0></a> <i>[1 - '.$pointer.']</i>');
			break;
			case "rwd":
				return fw('&nbsp;<A href="'.$this->listURL().'&pointer='.$pointer.$tParam.'"><img src="'.$this->backPath.'gfx/pildown.gif" width=14 height=14 valign="top" border=0></a> <i>['.($pointer+1).' - '.$this->totalItems.']</i>');
			break;
		}
	}
	function listURL()	{
		return 'dummy.php?';
	}
	function CBfunctions()	{
		return '
		
	function checkOffCB(listOfCBnames)	{
		var notChecked=0;
		var total=0;
		
			// Checking how many is checked, how many is not
		var pointer=0;
		var pos = listOfCBnames.indexOf(",");
		while (pos!=-1)	{
			if (!cbValue(listOfCBnames.substr(pointer,pos-pointer))) notChecked++;
			total++;
			pointer=pos+1;
			pos = listOfCBnames.indexOf(",",pointer);
		}
		if (!cbValue(listOfCBnames.substr(pointer))) notChecked++;
		total++;

			// Setting the status...		
		var flag = notChecked*2>total;
		pointer=0;
		pos = listOfCBnames.indexOf(",");
		while (pos!=-1)	{
			setcbValue(listOfCBnames.substr(pointer,pos-pointer),flag);

			pointer=pos+1;
			pos = listOfCBnames.indexOf(",",pointer);
		}
		setcbValue(listOfCBnames.substr(pointer),flag);
	}
	function cbValue(CBname)	{
		var CBfullName = "CBC["+CBname+"]";
		return (document.dblistForm[CBfullName] && document.dblistForm[CBfullName].checked ? 1 : 0);
	}
	function setcbValue(CBname,flag)	{
		CBfullName = "CBC["+CBname+"]";
		document.dblistForm[CBfullName].checked = flag ? "on" : 0;
	}
		
		';	
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_recordlist.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_recordlist.php"]);
}

?>