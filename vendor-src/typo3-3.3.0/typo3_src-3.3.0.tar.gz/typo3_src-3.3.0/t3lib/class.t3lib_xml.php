<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * XML class, output
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



class t3lib_xml {

	var $topLevelName = "typo3_test";
	var $XMLIndent=0;
	var $Icode="";
	var $XML_recFields = array();
	var $XMLdebug=0;
	var $includeNonEmptyValues=0;	// if set, all fields from records are rendered no matter their content. If not set, only "true" (that is "" or zero) fields make it to the document.
	var $lines=array();

	function t3lib_xml($topLevelName)	{
		$this->topLevelName = $topLevelName;
	}
	function setRecFields($table,$list)	{
		$this->XML_recFields[$table]=$list;
	}
	function getResult()	{
		$content = implode(chr(10),$this->lines);
		return $this->output($content);
	}
	function WAPHeader()	{
		$this->lines[]='<?xml version="1.0"?>';
		$this->lines[]='<!DOCTYPE '.$this->topLevelName.' PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">';
		$this->newLevel($this->topLevelName,1);
	}
	function renderHeader()	{
		$this->lines[]='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
		$this->lines[]='<!DOCTYPE '.$this->topLevelName.'>';
		$this->newLevel($this->topLevelName,1);
	}
	function renderFooter()	{
		$this->newLevel($this->topLevelName,0);
	}
	function newLevel($name,$beginEndFlag=0,$params=array())	{
		if ($beginEndFlag)	{
			$pList="";
			if (count($params))	{
				$par=array();
				reset($params);
				while(list($key,$val)=each($params))	{
					$par[]=$key.'="'.htmlspecialchars($val).'"';
				}
				$pList=" ".implode(" ",$par);
			}
			$this->lines[]=$this->Icode.'<'.$name.$pList.'>';
			$this->indent(1);
		} else {
			$this->indent(0);
			$this->lines[]=$this->Icode.'</'.$name.'>';
		}
	}
	function output($content)	{
		if ($this->XMLdebug)	{
			return '<pre>'.htmlspecialchars($content).'</pre>
			<hr><font color=red>Size: '.strlen($content).'</font>';
		} else {
			return $content;
		}
	}
	function indent($b)	{
		if ($b)	$this->XMLIndent++; else $this->XMLIndent--;
		$this->Icode="";
		for ($a=0;$a<$this->XMLIndent;$a++)	{
			$this->Icode.=chr(9);
		}
		return $this->Icode;
	}
	function renderRecords($table,$res) {
		while($row = mysql_fetch_assoc($res))	{
			$this->addRecord($table,$row);
		}
	}
	function addRecord($table,$row)	{
		$this->lines[]=$this->Icode.'<'.$table.' uid="'.$row["uid"].'">';
			$this->indent(1);
			$this->getRowInXML($table,$row);
			$this->indent(0);
		$this->lines[]=$this->Icode.'</'.$table.'>';
	}
	function getRowInXML($table,$row)	{
		$fields = t3lib_div::trimExplode(",",$this->XML_recFields[$table],1);
		reset($fields);
		while(list(,$field)=each($fields))	{
			if ($row[$field] || $this->includeNonEmptyValues)	{
//				$this->lines[]=$this->Icode.$this->fieldWrap($field,$this->substNewline(htmlspecialchars($row[$field])));
				$this->lines[]=$this->Icode.$this->fieldWrap($field,$this->substNewline($this->utf8(htmlspecialchars($row[$field]))));
//				$this->lines[]=$this->Icode.$this->fieldWrap($field,utf8_encode($row[$field]));
			}
		}
	}
	function utf8($content)	{
		return utf8_encode($content);
	}
	function substNewline($string)	{
		return ereg_replace(chr(10),"<newline/>",$string);
	}
	function fieldWrap($field,$value)	{
		return '<'.$field.'>'.$value.'</'.$field.'>';
	}
	
	function WAPback()	{
		$this->newLevel("template",1);
			$this->newLevel("do",1,array("type"=>"accept","label"=>"Back"));
			$this->addLine('<prev/>');
			$this->newLevel("do");
		$this->newLevel("template");
	}
	function addLine($str)	{
		$this->lines[]=$this->Icode.$str;
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_xml.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_xml.php"]);
}

?>