<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Authentication of users in Typo3




 
This class is used to authenticate a login user.
The class is used by both the frontend and backend.
The backend would normally extend the class with userauth_group, that has functions related to the Typo3 backend.





Interesting vars in the class:

user, Array()			This holds all information from the user-record + session-record






Session-variables:

user[uc], Array()		

"uc" should be a text-field in the table. 
The field "uc" is used by writeUC($variable) to store a serialized version of $variable. 
When the page is hit the next time you can easily store and get data.
Store by calling $userObj->writeUC($variable) and $variable will be stored (typically an array...)
Get by doing this: $variable = unserialize($userObj->user[uc]);

 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class t3lib_userAuth {
	var $global_database = "";     	// Which global database to connect to
	var $session_table = ""; 		// Table to use for session data.
	var $name = "";                 // Session/Cookie name
	var $get_name = "";                 // Session/GET-var name

	var $user_table = ""; 			// Table in database with userdata
	var $username_column = ""; 		// Column for login-name
	var $userident_column = ""; 	// Column for password
	var $userid_column = ""; 		// Column for user-id
	var $lastLogin_column = "";

	var $enablecolumns = Array (
		"rootLevel" => "",			// Boolean: If true, "AND pid=0" will be a part of the query...
		"disabled" => "",
		"starttime" => "",
		"endtime" => "",
		"deleted" => ""
	);
	
	var $formfield_uname = ""; 			// formfield with login-name
	var $formfield_uident = ""; 		// formfield with password
	var $formfield_chalvalue = "";		// formfield with a unique value which is used to encrypt the password and username
	var $formfield_status = ""; 		// formfield with status: *"login", "logout". If empty login is not verified.
	var $security_level = "";			// sets the level of security. *"normal" = clear-text. "challenged" = hashed password/username from form in $formfield_uident. "superchallenged" = hashed password hashed again with username.

	var $auth_include = "";				// this is the name of the include-file containing the login form. If not set, login CAN be anonymous. If set login IS needed.
	
	var $auth_timeout_field = 0;		// if > 0 : session-timeout in seconds. if false/<0 : no timeout. if string: The string is fieldname from the usertable where the timeout can be found.
	var $lifetime = 0;                  // 0 = Session-cookies. If session-cookies, the browser will stop session when the browser is closed. Else it keeps the session for $lifetime seconds.
	var $gc_time  = 24;               	// GarbageCollection. Purge all session data older than $gc_time hours.
	var $gc_probability = 1;			// Possibility (in percent) for GarbageCollection to be run.
	var $writeStdLog = 0;					// Decides if the writelog() function is called at login and logout
	var $writeAttemptLog = 0;				// If the writelog() functions is called if a login-attempt has be tried without success
	var $sendNoCacheHeaders = 1;		// If this is set, headers is sent to assure, caching is NOT done
	var $getFallBack = 0;				// If this is set, authentication is also accepted by the HTTP_GET_VARS. Notice that the identification is NOT 128bit MD5 hash but reduced. This is done in order to minimize the size for mobile-devices, such as WAP-phones
	var $hash_length = 32;				// The ident-hash is normally 32 characters and should be! But if you are making sites for WAP-devices og other lowbandwidth stuff, you may shorten the length. Never let this value drop below 6. A length of 6 would give you more than 16 mio possibilities. 
	var $getMethodEnabled = 0;			// Setting this flag true lets user-authetication happen from GET_VARS if POST_VARS are not set. Thus you may supply username/password from the URL.
	
	var $warningEmail = "";				// warning -emailaddress:
	var $warningPeriod = 3600;			// Period back in time (in seconds) in which number of failed logins are collected
	var $warningMax = 3;					// The maximum accepted number of warnings before an email is sent
	var $checkPid=1;					// If set, the user-record must $checkPid_value as pid
	var $checkPid_value=0;				// The pid, the user-record must have as page-id
	
		// Internals
	var $id;							// Internal: Will contain session_id (MD5-hash)
	var $cookieId;						// Internal: Will contian the session_id gotten from cookie or GET method. THis is used in statistics as a reliable cookie.
	var $loginSessionStarted = 0;		// Will be set to 1 if the login session is actually written during auth-check.

	var $user;							// Internal: Will contain user- AND session-data from database (joined tables)
	var $get_URL_ID = "";	// Internal: Will will be set to the url--ready (eg. "&login=ab7ef8d...") GET-auth-var if getFallBack is true. Should be inserted in links!
	
	var $forceSetCookie=0;
	var $dontSetCookie=0;
	
	function start() {
		global $HTTP_COOKIE_VARS, $HTTP_GET_VARS;
		
			// Init vars.
		$mode="";
		$new_id = false;				// Default: not a new session
		$id = isset($HTTP_COOKIE_VARS[$this->name]) ? $HTTP_COOKIE_VARS[$this->name] : "";	// $id is set to ses_id if cookie is present. Else set to false, which will start a new session
		$this->hash_length = t3lib_div::intInRange($this->hash_length,6,32);
//debug(array($HTTP_COOKIE_VARS, $HTTP_GET_VARS));
			// If fallback to get mode....
		if (!$id && $this->getFallBack && $this->get_name)	{	
			$id = isset($HTTP_GET_VARS[$this->get_name]) ? $HTTP_GET_VARS[$this->get_name] : "";
			if (strlen($id)!=$this->hash_length)	$id="";
			$mode="get";
		}
		$this->cookieId = $id;
		
		if (!$id)	{					// If new session...
    		$id = substr(md5(uniqid("")),0,$this->hash_length);		// New random session-$id is made
			$new_id = true;				// New session
		}
			// Internal var "id" is set
		$this->id = $id;				
		if ($mode=="get" && $this->getFallBack && $this->get_name)	{	// If fallback to get mode....
			$this->get_URL_ID = "&".$this->get_name."=".$id;
		}
		$this->user = "";				// Make certain that NO user is set initially
		
			// Setting cookies
        if (($new_id || $this->forceSetCookie) && $this->lifetime==0 ) {		// If new session and the cookie is a sessioncookie, we need to set it only once!
          if (!$this->dontSetCookie)	SetCookie($this->name, $id, 0, "/");		// Cookie is set
        }
        if ($this->lifetime > 0) {		// If it is NOT a session-cookie, we need to refresh it. 
          if (!$this->dontSetCookie)	SetCookie($this->name, $id, time()+$this->lifetime, "/");
        }

		// Check to see if anyone has submitted login-information and if so register the user with the session. $this->user[uid] may be used to write log...
		if ($this->formfield_status)	{
			$this->check_authentication();
		}
		unset($this->user);				// Make certain that NO user is set initially
		
		
		// The session_id is used to find user in the database. Two tables are joined: The session-table with user_id of the session and the usertable with its primary key
		$dbres=mysql(TYPO3_db,sprintf("SELECT * FROM %s, %s WHERE ses_id = '%s' AND ses_name = '%s' AND ses_userid = %s %s",
					$this->session_table, $this->user_table, $this->id, $this->name, $this->userid_column, $this->user_where_clause()));		// In order for this to work, no fields in the user-table should be named "ses_..."
		echo mysql_error();
		if ($this->user = mysql_fetch_assoc($dbres))	{
			// A user was found
			if (is_string($this->auth_timeout_field))	{
				$timeout = intval($this->user[$this->auth_timeout_field]);		// Get timeout-time from usertable
			} else {
				$timeout = intval($this->auth_timeout_field);					// Get timeout from object
			}
		// If timeout > 0 (true) and currenttime has not exceeded the latest sessions-time plus the timeout in seconds then accept user
		// Option later on: We could check that last update was at least x seconds ago in order not to update twice in a row if one script redirects to another...
			if ($timeout>0 && ($GLOBALS["EXEC_TIME"] < ($this->user[ses_tstamp]+$timeout) ))	{
					$dbres=mysql(TYPO3_db,sprintf("update %s set ses_tstamp = '%s' where ses_id = '%s' and ses_name = '%s'",
							$this->session_table, $GLOBALS["EXEC_TIME"], $this->id, $this->name));
					$this->user[ses_tstamp]=$GLOBALS["EXEC_TIME"];	// Make sure that the timestamp is also updated in the array
			} else {
				$this->user = "";
				$this->logoff();		// delete any user set...			
			}
		} else {
			$this->logoff();		// delete any user set...
		}

		$this->redirect();		// If any redirection (inclusion of file) then it will happen in this function
		
			// Set all posible headers that could ensure that the script is not cached on the client-side

		if ($this->sendNoCacheHeaders)	{
			header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
			header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
			header("Expires: 0");
			header("Cache-Control: no-cache, must-revalidate");
			header("Pragma: no-cache");
		}


			// If we're lucky we'll get to clean up old sessions....
		if ((rand()%100) <= $this->gc_probability) {
			$this->gc();
		}
	}
	function check_authentication() {
		// Checks if a submission of username and password is given
		global $HTTP_POST_VARS, $HTTP_GET_VARS;
		if ($this->getMethodEnabled)	{
			$F_status = isset($HTTP_POST_VARS[$this->formfield_status]) ? $HTTP_POST_VARS[$this->formfield_status] : $HTTP_GET_VARS[$this->formfield_status];
			$F_uname = isset($HTTP_POST_VARS[$this->formfield_uname]) ? $HTTP_POST_VARS[$this->formfield_uname] : $HTTP_GET_VARS[$this->formfield_uname];
			$F_uident = isset($HTTP_POST_VARS[$this->formfield_uident]) ? $HTTP_POST_VARS[$this->formfield_uident] : $HTTP_GET_VARS[$this->formfield_uident];
			$F_chalvalue = isset($HTTP_POST_VARS[$this->formfield_chalvalue]) ? $HTTP_POST_VARS[$this->formfield_chalvalue] : $HTTP_GET_VARS[$this->formfield_chalvalue];
		} else {
			$F_status = $HTTP_POST_VARS[$this->formfield_status];
			$F_uname = $HTTP_POST_VARS[$this->formfield_uname];
			$F_uident = $HTTP_POST_VARS[$this->formfield_uident];
			$F_chalvalue = $HTTP_POST_VARS[$this->formfield_chalvalue];
		}
//debug($HTTP_POST_VARS);
//debug($HTTP_GET_VARS);
		switch ($F_status)	{
			case "login":
				$refInfo=parse_url(getenv("HTTP_REFERER"));
				list($httpHost) = explode(":",getenv("HTTP_HOST"));
				if (!$this->getMethodEnabled && ($httpHost!=$refInfo["host"] && !$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["doNotCheckReferer"]))	{
					die("Error: This host address ('".$httpHost."') and the referer host ('".$refInfo[host]."') mismatches!<BR>It's possible that the environment variable HTTP_REFERER is not passed to the script because of a proxy.<BR>The site administrator can disable this check in the configuration (flag: TYPO3_CONF_VARS[SYS][doNotCheckReferer]).");
				}
				if ($F_uident && $F_uname)	{
					$this->logoff();		// delete old user
					$query = sprintf("SELECT * FROM %s WHERE %s%s = '%s' %s",
								$this->user_table, 
								($this->checkPid?"pid=".intval($this->checkPid_value)." AND ":""),
								$this->username_column, $F_uname, $this->user_where_clause()	);
					$dbres=mysql(TYPO3_db,$query);
					$loginFailure=1;
					if ($tempuser = mysql_fetch_assoc($dbres))	{
						$this->user = $tempuser;

						$OK = false;
						// check the password
						switch ($this->security_level)	{
							case "superchallenged":		// If superchallenged the password in the database ($tempuser[$this->userident_column]) must be a md5-hash of the original password.
							case "challenged":
								if ($F_uident == md5($tempuser[$this->username_column].":".$tempuser[$this->userident_column].":".$F_chalvalue))	{
									$OK = true;
								};
							break;
							default:	// normal
								if ($F_uident == $tempuser[$this->userident_column])	{
									$OK = true;
								};
							break;
						}
							// Write session-record in case user was verified OK
						if ($OK)	{
								// Checking the domain (lockToDomain)
							if ($this->user["lockToDomain"] && $this->user["lockToDomain"]!=getenv("HTTP_HOST"))	{
								if ($this->writeAttemptLog) {
									$this->writelog(255,3,3,1,"Login-attempt from %s (%s), username '%s', locked domain '%s' did not match '%s'!",Array(getenv("REMOTE_ADDR"),getenv("REMOTE_HOST"),$F_uname,$this->user["lockToDomain"],getenv("HTTP_HOST")));	// Logout written to log
									$loginFailure=1;
								}
							} else {	// The loginsession is started.
								$this->loginSessionStarted = 1;
								$dbres=mysql(TYPO3_db,sprintf("insert into %s (ses_id, ses_name, ses_userid, ses_tstamp) values ('%s','%s','%s','%s')",
										$this->session_table, $this->id, $this->name, $tempuser[$this->userid_column], $GLOBALS["EXEC_TIME"]));
								if ($this->lastLogin_column)	{
									$dbres=mysql(TYPO3_db,sprintf("UPDATE %s SET %s='%s' WHERE %s='%s';", $this->user_table, $this->lastLogin_column, $GLOBALS["EXEC_TIME"], $this->userid_column, $tempuser[$this->userid_column]));
								}
								
								if ($this->writeStdLog) {
									$this->writelog(255,1,0,1,"User %s logged in from %s (%s)",Array($this->user[username],getenv("REMOTE_ADDR"),getenv("REMOTE_HOST")));	
								}
							}						
						} else {
							if ($this->writeAttemptLog) {
								$this->writelog(255,3,3,1,"Login-attempt from %s (%s), username '%s', password not accepted!",Array(getenv("REMOTE_ADDR"),getenv("REMOTE_HOST"),$F_uname));	// Logout written to log
								$loginFailure=1;
							}
						}
						unset($this->user);		// Make sure to clear the user again!!
					} else {
						if ($this->writeAttemptLog) {
							$this->writelog(255,3,3,2,"Login-attempt from %s (%s), username '%s' not found!!",Array(getenv("REMOTE_ADDR"),getenv("REMOTE_HOST"),$F_uname));	// Logout written to log						
						}
					}
					if ($loginFailure)	{ 
						$this->checkLogFailures($this->warningEmail, $this->warningPeriod, $this->warningMax);
					}
				}
				return "login";
			break;
			case "logout":
				if ($this->writeStdLog) 	$this->writelog(255,2,0,2,"User %s logged out",Array($this->user[username]));	// Logout written to log
				$this->logoff();
				return "logout";
			break;
		}
	}
	function redirect() {
		if (!$this->userid && $this->auth_url)	{	 // if no userid AND an include-document for login is given
			include ($this->auth_include);
			exit;
		}
	}
	function logoff() {
		$dbres=mysql(TYPO3_db,sprintf("delete from %s where ses_id = '%s' and ses_name = '%s'",
					$this->session_table, $this->id, $this->name));
		$this->user = "";
	}
	function gc() {
		// Garbage-collection function. 
		$dbres=mysql(TYPO3_db,sprintf("delete from %s where ses_tstamp < '%s' and ses_name = '%s'",
					$this->session_table, time()-($this->gc_time*60*60), $this->name));
	}
	function user_where_clause()	{
			// This returns the where-clause needed to select the user with respect flags like deleted, hidden, starttime, endtime
		return  (($this->enablecolumns[rootLevel]) ? "AND pid=0 " : "").
				(($this->enablecolumns[disabled]) ? " AND NOT ".$this->enablecolumns[disabled] : "").
				(($this->enablecolumns[deleted]) ? " AND NOT ".$this->enablecolumns[deleted] : "").
				(($this->enablecolumns[starttime]) ? " AND (".$this->enablecolumns[starttime]."<=".time().")" : "").
				(($this->enablecolumns[endtime]) ? " AND (".$this->enablecolumns[endtime]."=0 OR ".$this->enablecolumns[endtime].">".time().")" : "");
	}
	function writeUC($variable="")	{
			// This writes $variable to the user-record. This is a way of providing session-data.
			// You can fetch the data again through $this->uc in this class!
			// If $variable is not an array, $this->uc is saved!
		if ($this->user && $this->user[uid])	{
			if (!is_array($variable)) {$variable=$this->uc;}
			$query="update ".$this->user_table." set uc ='".addslashes(serialize($variable))."' where uid=".$this->user[uid];
			$dbres=mysql(TYPO3_db,$query);
		}
	}
	function writelog($type,$action,$error,$details_nr,$details,$data,$tablename,$recuid,$recpid)	{
		// Dummy...
	}
	function checkLogFailures()	{
		// Dummy...
	}
	function unpack_uc($theUC) {
		if (!$theUC) 	$theUC=unserialize($this->user[uc]);
		if (is_array($theUC))	{
			$this->uc=$theUC;
		}
	}
	function pushModuleData($module,$data,$noSave=0)	{
			// $module is the name of the module ($MCONF["name"])
			// $data is the data-array/string to be stored
			// $noSave set will prevent the function from saving also.
		$this->uc["moduleData"][$module] = $data;
		$this->uc["moduleSessionID"][$module] = $this->id;
		if (!$noSave) $this->writeUC();
	}
	function getModuleData($module,$type="")	{
			// $module is the name of the module ($MCONF["name"])
			// if $type = "ses" then it's session lasting data.
		if ($type!="ses" || $this->uc["moduleSessionID"][$module]==$this->id) {
			return $this->uc["moduleData"][$module];
		}
	}
	function setBeUserByUid($uid)	{
		$dbres=mysql(TYPO3_db,sprintf("SELECT * FROM %s WHERE uid='%s' %s", $this->user_table, intval($uid), $this->user_where_clause()));
		echo mysql_error();
		$this->user = mysql_fetch_assoc($dbres);
	}
	function setBeUserByName($name)	{
		$dbres=mysql(TYPO3_db,sprintf("SELECT * FROM %s WHERE username='%s' %s", $this->user_table, $name, $this->user_where_clause()));
		echo mysql_error();
		$this->user = mysql_fetch_assoc($dbres);
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_userauth.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_userauth.php"]);
}

?>