<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Basic file functions
 *


COMMENT:

init($mounts, $f_ext) - constructor
( This function should be called to initialise the internal arrays $this->mounts and $this->f_ext);


A typical example of the array $f_ext is this:


		$f_ext["webspace"]["allow"]="";
		$f_ext["webspace"]["deny"]="php3,php";
		
		$f_ext["ftpspace"]["allow"]="*";
		$f_ext["ftpspace"]["deny"]="";
		
		The control of fileextensions goes in two catagories. Webspace and Ftpspace. Webspace is folders accessible from a webbrowser (below $DOCUMENT_ROOT) and ftpspace is everything else.
		The control is done like this: If an extension matches "allow" then the check returns true. If not and an extension matches "deny" then the check return false. If no match at all, returns true.
		You list extensions comma-separated. If the value is a "*" every extension is allowed
		The list is case-insensitive when used in this class (see init())
	
	
A typical example of the array $mounts is this:

	$mounts[xx][path] = (..a mounted path..)
	
	the "xx"-keys is just numerical from zero. There are also a [name] and [type] value that just denotes the mountname and type. Not used for athentication here.
	$this->mounts is traversed in the function checkPathAgainstMounts($thePath), and it is checked that $thePath is actually below one of the mount-paths
	The mountpaths are with a trailing "/". $thePath must be with a trailing "/" also!
	As you can see, $this-mounts is very critical! This is the array that decides where the used will be allowed to copy files!!

	

Dependencies:
t3lib_div

 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
 


class t3lib_basicFileFunctions	{
	var $getUniqueNamePrefix = "";	// prefix which will be prepended the file when using the getUniqueName-function
	var $maxNumber = 20;		// This number decides the highest allowed appended number used on a filename before we use naming with unique strings
	var $uniquePrecision = 6;	// This number decides how many characters out of a unique MD5-hash that is appended to a filename if getUniqueName is asked to find an available filename.
	var $maxInputNameLen = 30;	// This is the maximum length of names treated by cleanFileName()
	var $tempFN = "_temp_";		// Temp-foldername. A folder in the root of one of the mounts with this name is regarded a TEMP-folder (used for upload from clipboard)

		// internal
	var $f_ext = Array();		// See comment in header
	var $mounts = Array();				// See comment in header
	var $webPath ="";					// Set to DOCUMENT_ROOT. 
	var $isInit=0;						// Set to true after start();

		// *********************
		// checking functions
		// *********************

	function init($mounts, $f_ext)	{
			// Constructor
		$this->f_ext["webspace"]["allow"] = t3lib_div::uniqueList(strtolower($f_ext["webspace"]["allow"]));
		$this->f_ext["webspace"]["deny"] = t3lib_div::uniqueList(strtolower($f_ext["webspace"]["deny"]));
		$this->f_ext["ftpspace"]["allow"] = t3lib_div::uniqueList(strtolower($f_ext["ftpspace"]["allow"]));
		$this->f_ext["ftpspace"]["deny"] = t3lib_div::uniqueList(strtolower($f_ext["ftpspace"]["deny"]));
		
		$this->mounts = $mounts;
		$this->webPath = $GLOBALS["HTTP_SERVER_VARS"]["DOCUMENT_ROOT"];
		$this->isInit=1;
	}
	function getTotalFileInfo($wholePath)	{
			// Returns an array with a whole lot of fileinformation
		$theuser = getmyuid();
		$info = t3lib_div::split_fileref($wholePath);
		$info[tstamp]=@filectime($wholePath);
		$info[size]=@filesize($wholePath);
		$info[type]=@filetype($wholePath);
		$info[owner]=@fileowner($wholePath);
		$info[perms]=@fileperms($wholePath);
		$info[writeable] = ($info[perms]&2 || ($theuser==$info[owner] && $info[perms]&128));
		$info[readable] = ($info[perms]&4 || ($theuser==$info[owner] && $info[perms]&256));	
//		$info[writeable_] = @is_writeable($wholePath);		// These seems to return true if permissions is set for the owner and the owner is not $theuser!!
//		$info[readable_] = is_readable($wholePath);	
		return $info;
	}

	
	
	

		// *********************
		// checking functions
		// *********************

	function is_allowed($iconkey,$type)	{
			// Checks if a $iconkey (fileextension) is allowed according to f_ext.
		if (isset($this->f_ext[$type]))	{
			$ik = strtolower($iconkey);
			if ($ik)	{
//					debug($this->f_ext);
					// If the extension is found amongst the allowed types, we return true immediately
				if ($this->f_ext[$type]["allow"]=="*" || t3lib_div::inList($this->f_ext[$type]["allow"],$ik))	return true;
					// If the extension is found amongst the denied types, we return false immediately
				if ($this->f_ext[$type]["deny"]=="*" || t3lib_div::inList($this->f_ext[$type]["deny"],$ik))	return false;
					// If no match we return true
				return true;
			} else {	// If no extension:
				if ($this->f_ext[$type]["allow"]=="*")	return true;
				if ($this->f_ext[$type]["deny"]=="*")	return false;
				return true;
			}
		}
		return false;
	}
	function checkIfFullAccess($theDest)	{
			// Returns true if you can operate of ANY file ("*") in the space $theDest is in ("webspace" / "ftpspace")
		$type = $this->is_webpath($theDest)?"webspace":"ftpspace";
		if (isset($this->f_ext[$type]))	{
			if ((string)$this->f_ext[$type]["deny"]=="" || $this->f_ext[$type]["allow"]=="*")	return true;
		}
	}
	function is_webpath($path)	{		
		// Checks if $this->webPath (should be DOCUMENT_ROOT) is in the first part of $path
		// Returns true also if $this->init is not set or if $path is empty...
		if ($this->isInit)	{
			$testPath = $this->slashPath($path);
			$testPathWeb = $this->slashPath($this->webPath);
			if ($testPathWeb && $testPath)	{
				return t3lib_div::isFirstPartOfStr($testPath,$testPathWeb);
			}
		}
		return true;	// Its more safe to return true (as the webpath is more restricted) if something went wrong...
	}
	function checkIfAllowed($ext, $theDest)	{
			// Checks if the $ext fileextension is allowed in the path $theDest (this is based on whether $theDest is below the $this->webPath)
		return $this->is_allowed($ext,($this->is_webpath($theDest)?"webspace":"ftpspace"));	
	}
	function checkFileNameLen($fileName)	{
		return strlen($fileName) <= $this->maxInputNameLen;
	}
	function is_directory($theDir)	{
			// Cleans $theDir for slashes in the end of the string and returns the new path, if it exists on the server.
		if ($this->isPathValid($theDir))	{
			$theDir=$this->cleanDirectoryName($theDir);
			if (@is_dir($theDir))	{
				return $theDir;
			}
		}
		return false;
	}
	function isPathValid($theFile)	{
			// Returns true if no "//", ".." or "\" is in the $theFile
		if (!strstr($theFile,"//") && !strstr($theFile,"..") && !strstr($theFile,"\\"))	return true;
	}
	function getUniqueName($theFile, $theDest, $dontCheckForUnique=0)	{
			// Returns the destination path/filename of a unique filename/foldername in that path.
			// if $theFile exists in $theDest (directory) the file have numbers appended up to $this->maxNumber. Hereafter a unique string will be appended.
			// $theDest MUST be a valid directory
		$theDest = $this->is_directory($theDest);	// $theDest is cleaned up
		$origFileInfo = t3lib_div::split_fileref($theFile);		// Fetches info about path, name, extention of $theFile
		if ($theDest)	{
			if ($this->getUniqueNamePrefix)	{		// Adds prefix
				$origFileInfo[file]=$this->getUniqueNamePrefix.$origFileInfo[file];
				$origFileInfo[filebody]=$this->getUniqueNamePrefix.$origFileInfo[filebody];
			}

				// Check if the file exists and if not - return the filename...
			$fileInfo = $origFileInfo;
			$theDestFile = $theDest."/".$fileInfo[file];		// The destinations file
			if (!@file_exists($theDestFile) || $dontCheckForUnique)		{	// If the file does NOT exist we return this filename
				return $theDestFile;
			}

				// Well the filename in it's pure form existed. Now we try to append numbers / unique-strings and see if we can find an available filename...
			$theTempFileBody = ereg_replace("_[0-9][0-9]$","",$origFileInfo[filebody]);		// This removes _xx if appended to the file
			$theOrigExt = $origFileInfo[realFileext] ? ".".$origFileInfo[realFileext] : "";

			for ($a=1; $a<=($this->maxNumber+1); $a++)	{
				if ($a<=$this->maxNumber)	{	// First we try to append numbers
					$insert = "_".sprintf("%02d", $a);
				} else {		// .. then we try unique-strings...
					$insert = "_".substr(md5(uniqId("")),0,$this->uniquePrecision);
				}
				$theTestFile = $theTempFileBody.$insert.$theOrigExt;
				$theDestFile = $theDest."/".$theTestFile;		// The destinations file
				if (!@file_exists($theDestFile))		{	// If the file does NOT exist we return this filename
					return $theDestFile;
				}
			}
		}
	}
	function checkPathAgainstMounts($thePath)	{
		// Checks if $thePath is a path under one of the paths in $this->mounts
		// $thePath MUST HAVE a trailing "/" in order to match correctly with the mounts
		// See comment in the header
		// Returns the key to the first mount found
		if ($thePath && $this->isPathValid($thePath) && is_array($this->mounts))	{
			reset ($this->mounts);
			while(list($k,$val)=each($this->mounts))	{
				if (t3lib_div::isFirstPartOfStr($thePath,$val["path"]))	{
					return $k;
				}
			}
		}
	}
	function blindPath($thePath)	{
		// takes a path $thePath and removes the path of the path outside the filemount
		$k=$this->checkPathAgainstMounts($thePath);
		if ($k)	{
			$name="";
			$name.="[".$this->mounts[$k]["name"]."]: ";
			$name.=substr($thePath,strlen($this->mounts[$k]["path"]));
			return $name;
		}
	}
	function findTempFolder()	{
		// Finds the first $this->tempFN ("_temp_" usually) -folder in the row of mounts.
		// Returns the path or nothing if error.
		if ($this->tempFN && is_array($this->mounts))	{
			reset ($this->mounts);
			while(list($k,$val)=each($this->mounts))	{
				$tDir = $val["path"].$this->tempFN;
				if (@is_dir($tDir))	{
					return $tDir;
				}
			}
		}
	}






		// *********************
		// cleaning functions
		// *********************
		
	function cleanDirectoryName($theDir)	{
			// Removes all dots, slashes and spaces after a path...
		return ereg_replace("[\/\. ]*$","",$this->rmDoubleSlash($theDir));
	}
	function rmDoubleSlash($string)	{
			// removes double-slashes in paths...
		return str_replace("//","/",$string);
	}
	function slashPath($path)	{
		// This function returns a string which has a slash "/" appended if it doesn't already have that slash
		if (substr($path,-1)!="/")	{
			return $path."/";
		} 
		return $path;
	}	
	function cleanFileName($fileName)	{
		// Returns a string where any character not matching [a-zA-Z0-9_-] is substituted by "_"
		$theNewName = ereg_replace("[^\.[:alnum:]_-]","_",trim($fileName));
		return $theNewName;
	}
	function formatSize($sizeInBytes)	{
		// Formats a number to Mb or Kb or just bytes
		if ($sizeInBytes>900)	{
			if ($sizeInBytes>900000)	{	// MB
				$val = $sizeInBytes/(1024*1024);
				return number_format($val, (($val<20)?1:0), ".", "")." M";
			} else {	// KB
				$val = $sizeInBytes/(1024);
				return number_format($val, (($val<20)?1:0), ".", "")." K";
			}
		} else {	// Bytes
			return $sizeInBytes."&nbsp;&nbsp;";
		}
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_basicfilefunc.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["t3lib/class.t3lib_basicfilefunc.php"]);
}

?>