<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Generating gif/png-files from TypoScript
 *
 * Used by the menu-objects and imgResource in TypoScript. 
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class tslib_gifBuilder extends t3lib_stdGraphic {
		// This makes giffiles with a lot of stuff on it. The options is described in another document
	var $setup = Array ();		// This holds the operational setup for gifbuilder
	var $data = Array();		// this is the array from which data->field: [key] is fetched
	var $objBB = Array();
	var $myClassName = "gifbuilder";
		// internal
	var $im = "";		// the main image
	var $w = 0;			// the image-width
	var $h = 0;			// the image-height
	var $map;	// map-data
	


	function start($conf,$data)	{
	
		if (is_array($conf))	{
			$this->setup = $conf;
			$this->data = $data;
//			ksort($this->setup);
			$sKeyArray=t3lib_TStemplate::sortedKeyList($this->setup);

				// stdWrap on backColor added 220600
			if ($conf["backColor."] || $conf["backColor"])	{
				$cObj =t3lib_div::makeInstance("tslib_cObj");
				$cObj->start($this->data);
				$this->setup["backColor"] = trim($cObj->stdWrap($this->setup["backColor"], $this->setup["backColor."]));
			}

			if (!$this->setup["backColor"])	{$this->setup["backColor"]="white";}
			
	// Transparent GIFs
	// not working with reduceColors
	// there's an option for IM: -transparent colors
			if ($conf["transparentColor."] || $conf["transparentColor"])	{
				$cObj =t3lib_div::makeInstance("tslib_cObj");
				$cObj->start($this->data);
				$this->setup["transparentColor_array"] = explode("|", trim($cObj->stdWrap($this->setup["transparentColor"], $this->setup["transparentColor."])));
			}

			if (!$this->setup["XY"])	{$this->setup["XY"]="120,50";}
	// check TEXT-obj and IMAGE for files. If any errors the objects are cleared. 
	// The Bounding Box for the objects is stored in an array

//			reset($this->setup);
//			while(list($theKey,$theValue)=each($this->setup))	{
			reset($sKeyArray);
			while(list(,$theKey)=each($sKeyArray))	{
				$theValue=$this->setup[$theKey];
			
				if (intval($theKey) && $conf=$this->setup[$theKey."."])	{
						// Swipes through TEXT and IMAGE-objects
					switch($theValue)	{
						case "TEXT":
							if ($this->setup[$theKey."."]=$this->checkTextObj($conf))	{
								if ($this->setup[$theKey."."]["maxWidth"])	{
									$this->setup[$theKey."."]["fontSize"] = $this->fontResize($this->setup[$theKey."."]); //RTF - this has to be done before calcBBox
								}
								$txtInfo=$this->calcBBox($this->setup[$theKey."."]);
								$this->setup[$theKey."."]["BBOX"]=$txtInfo;
								$this->objBB[$theKey]=$txtInfo;
								$this->setup[$theKey."."]["imgMap"]=0;
							}
						break;
						case "IMAGE":
							$fileInfo = $this->getResource($conf["file"],$conf["file."]);
							if ($fileInfo)	{
								$this->setup[$theKey."."]["file"]=$fileInfo[3];
								$this->setup[$theKey."."]["BBOX"]=$fileInfo;
								$this->objBB[$theKey]=$fileInfo;
								if ($conf["mask"])	{
									$maskInfo = $this->getResource($conf["mask"],$conf["mask."]);
									if ($maskInfo)	{
										$this->setup[$theKey."."]["mask"]=$maskInfo[3];
									} else {
										$this->setup[$theKey."."]["mask"] = "";
									}
								}
							} else {
								unset($this->setup[$theKey."."]);
							}
						break;
					}
						// Checks if disabled is set... (this is also done in menu.php / imgmenu!!)
					if ($conf["if."])	{
						$cObj =t3lib_div::makeInstance("tslib_cObj");
						$cObj->start($this->data);

						if (!$cObj->checkIf($conf["if."]))	{
							unset($this->setup[$theKey]);
							unset($this->setup[$theKey."."]);
						}
					}
				}
			}

	// calculate offsets on elements
			$this->setup["XY"] = $this->calcOffset($this->setup["XY"]);
			$this->setup["offset"] = $this->calcOffset($this->setup["offset"]);
			$this->setup["workArea"] = $this->calcOffset($this->setup["workArea"]);

//			reset($this->setup);
//			while(list($theKey,$theValue)=each($this->setup))	{
			reset($sKeyArray);
			while(list(,$theKey)=each($sKeyArray))	{
				$theValue=$this->setup[$theKey];

				if (intval($theKey) && $conf=$this->setup[$theKey."."])	{
					switch($theValue)	{
						case "TEXT":
						case "IMAGE":
							if ($this->setup[$theKey."."][offset])	{
								$this->setup[$theKey."."][offset] = $this->calcOffset($this->setup[$theKey."."][offset]);
							}
						break;
						case "BOX":
							if ($this->setup[$theKey."."][dimensions])	{
								$this->setup[$theKey."."][dimensions] = $this->calcOffset($this->setup[$theKey."."][dimensions]);
							}
						break;
						case "WORKAREA":
							if ($this->setup[$theKey."."][set])	{
								$this->setup[$theKey."."][set] = $this->calcOffset($this->setup[$theKey."."][set]);
							}
						break;
						case "CROP":
							if ($this->setup[$theKey."."][crop])	{
								$this->setup[$theKey."."][crop] = $this->calcOffset($this->setup[$theKey."."][crop]);
							}
						break;
						case "SCALE":
							if ($this->setup[$theKey."."][width])	{
								$this->setup[$theKey."."][width] = $this->calcOffset($this->setup[$theKey."."][width]);
							}
							if ($this->setup[$theKey."."][height])	{
								$this->setup[$theKey."."][height] = $this->calcOffset($this->setup[$theKey."."][height]);
							}
						break;
					}
				}
			}
				// Get trivial data
			$XY = t3lib_div::intExplode(",",$this->setup["XY"]);
			$maxWidth = intval($this->setup["maxWidth"]);
			$maxHeight = intval($this->setup["maxHeight"]);
			
			$XY[0] = t3lib_div::intInRange($XY[0],1, $maxWidth?$maxWidth:2000);
			$XY[1] = t3lib_div::intInRange($XY[1],1, $maxHeight?$maxHeight:2000);
			$this->XY = $XY;
			$this->w = $XY[0];
			$this->h = $XY[1];
			$this->OFFSET = t3lib_div::intExplode(",",$this->setup["offset"]);

			$this->setWorkArea($this->setup["workArea"]);	// this sets the workArea
			$this->defaultWorkArea = $this->workArea;	// this sets the default to the current;
		}
	}
	function make ()	{
			// Get trivial data
		$XY = $this->XY;
			// Gif-start

		$this->im = imagecreate($XY[0],$XY[1]);
		$this->w = $XY[0];
		$this->h = $XY[1];

			// backColor is set
		$cols=$this->convertColor($this->setup["backColor"]);		
		ImageColorAllocate($this->im, $cols[0],$cols[1],$cols[2]);

		if (is_array($this->setup))	{
//			reset($this->setup);
//			ksort($this->setup);
//			while(list($theKey,$theValue)=each($this->setup))	{
			$sKeyArray=t3lib_TStemplate::sortedKeyList($this->setup);
			reset($sKeyArray);
			while(list(,$theKey)=each($sKeyArray))	{
				$theValue=$this->setup[$theKey];

				if (intval($theKey) && $conf=$this->setup[$theKey."."])	{
					switch($theValue)	{
		// elements
						case "TEXT":
							if (!$conf[hide])	{
								if (is_array($conf["shadow."]))	{
									$this->makeShadow($this->im,$conf["shadow."],$this->workArea,$conf);
								}
								if (is_array($conf["emboss."]))	{
									$this->makeEmboss($this->im,$conf["emboss."],$this->workArea,$conf);
								}
								if (is_array($conf["outline."]))	{
									$this->makeOutline($this->im,$conf["outline."],$this->workArea,$conf);
								}
								$conf["imgMap"]=1;
								$this->makeText($this->im,$conf,$this->workArea);
							}
						break;
						case "IMAGE":
							if ($conf[mask])	{
								$this->maskImageOntoImage($this->im,$conf,$this->workArea);
							} else {
								$this->copyImageOntoImage($this->im,$conf,$this->workArea);
							}
						break;
						case "BOX":
							$this->makeBox($this->im,$conf,$this->workArea);
						break;
		// settings
						case "WORKAREA":
							if ($conf[set])	{
								$this->setWorkArea($conf[set]);	// this sets the workArea
							}
							if (isset($conf[clear]))	{
								$this->workArea = $this->defaultWorkArea;	// this sets the current to the default;
							}
						break;
		// effects
						case "OUTLINE":
							if ($this->setup[$conf["textObjNum"]]=="TEXT" && $txtConf=$this->checkTextObj($this->setup[$conf["textObjNum"]."."]))	{
								$this->makeOutline($this->im,$conf,$this->workArea,$txtConf);
							}
						break;
						case "SHADOW":
							if ($this->setup[$conf["textObjNum"]]=="TEXT" && $txtConf=$this->checkTextObj($this->setup[$conf["textObjNum"]."."]))	{
								$this->makeShadow($this->im,$conf,$this->workArea,$txtConf);
							}
						break;
						case "EMBOSS":
							if ($this->setup[$conf["textObjNum"]]=="TEXT" && $txtConf=$this->checkTextObj($this->setup[$conf["textObjNum"]."."]))	{
								$this->makeEmboss($this->im,$conf,$this->workArea,$txtConf);
							}
						break;
						case "EFFECT":
							$this->makeEffect($this->im,$conf);
						break;
						case "ADJUST":
							$this->adjust($this->im,$conf);
						break;
						case "SCALE":
							$this->scale($this->im,$conf);
						break;
						case "CROP":
							$this->crop($this->im,$conf);
						break;
					}
				}
			}			
		}	
			// Auto transparent background is set
		if ($this->setup["transparentBackground"])	{
			imagecolortransparent($this->im, imagecolorat($this->im, 0, 0));
		}
			// TransparentColors are set
		if (is_array($this->setup["transparentColor_array"]))	{
			reset($this->setup["transparentColor_array"]);
			while(list(,$transparentColor)=each($this->setup["transparentColor_array"]))	{
				$cols=$this->convertColor($transparentColor);
				if ($this->setup["transparentColor."]["closest"])	{
					$colIndex = ImageColorClosest ($this->im, $cols[0],$cols[1],$cols[2]);
				} else {
					$colIndex = ImageColorExact ($this->im, $cols[0],$cols[1],$cols[2]);
				}
				if ($colIndex > -1) {	
					ImageColorTransparent($this->im, $colIndex);
				} else {
					ImageColorTransparent($this->im, ImageColorAllocate($this->im, $cols[0],$cols[1],$cols[2]));
				}
				break;		// Originally we thought of letting many colors be defined as transparent, but GDlib seems to accept only one definition. Therefore We break here. Maybe in the future this "break" will be cancelled if a method of truly defining many transparent colors could be found.
			}
		}
	}
	function checkTextObj ($conf)	{
			// "cleans" TEXT-object; Checks fontfile and other vital setup
			// finds the title if its a "variable"
			// performs caseshift if any
		$conf["fontFile"]=$this->checkFile($conf["fontFile"]);
		if (!$conf["fontFile"]){$conf["fontFile"]="t3lib/fonts/arial.ttf";}
		if (!$conf[iterations]){$conf[iterations] = 1;}
		if (!$conf[fontSize]){$conf[fontSize]=12;}
		if ($conf[spacing] || $conf[wordSpacing])	{		// If any kind of spacing applys, we cannot use angles!!
			$conf[angle]=0;
		}
		if (!isset($conf[antiAlias])){$conf[antiAlias]=1;}
		$cObj =t3lib_div::makeInstance("tslib_cObj");
		$cObj->start($this->data);

		$conf["text"]=$cObj->stdWrap($conf["text"],$conf["text."]);
			// Strip HTML
		if (!$conf["doNotStripHTML"])	{
			$conf["text"] = strip_tags($conf["text"]);
		}
			// Max length = 100
		$tlen = intval($conf["textMaxLength"]) ? intval($conf["textMaxLength"]) : 100;
		$conf["text"] = substr($conf["text"],0,$tlen);
		if ((string)$conf["text"]!="")	{
			return $conf;
		}
	}
	function setWorkArea($workArea)	{
		$this->workArea = t3lib_div::intExplode(",",$workArea);
		$this->workArea = $this->applyOffset($this->workArea,$this->OFFSET);
		if (!$this->workArea[2])	{$this->workArea[2]=$this->w;}
		if (!$this->workArea[3])	{$this->workArea[3]=$this->h;}
	}
	function calcOffset($string)	{
		$numbers=explode(",",$string);
		while(list($key,$val)=each($numbers))	{
			$val = trim($val);
			if ((string)$val==(string)intval($val)) {
				$value[$key]=intval($val);
			} else {
				$parts= t3lib_div::splitCalc($val,"+-*/%");
				$value[$key]=0;
				reset($parts);
				while(list(,$part)=each($parts))	{
					$theVal = $part[1];
					$sign =  $part[0];
					if ((string)intval($theVal)==(string)$theVal)	{
						$theVal = intval($theVal);
					} elseif ("[".substr($theVal,1,-1)."]"==$theVal)	{
						$objParts=explode(".",substr($theVal,1,-1));
						$theVal=0;
						if (isset($this->objBB[$objParts[0]]))	{
							if ($objParts[1]=="w")	{$theVal=intval($this->objBB[$objParts[0]][0]);}
							if ($objParts[1]=="h")	{$theVal=intval($this->objBB[$objParts[0]][1]);}
						}
					} else {
						$theVal =0;
					}
					if ($sign=="-")	{$value[$key]-=$theVal;}
					if ($sign=="+")	{$value[$key]+=$theVal;}
					if ($sign=="/")	{if (intval($theVal)) $value[$key]/=intval($theVal);}
					if ($sign=="*")	{$value[$key]*=$theVal;}
					if ($sign=="%") {if (intval($theVal)) $value[$key]%=intval($theVal);}
				}
				$value[$key]=intval($value[$key]);
			}
		}
		$string = implode($value,",");
		return $string;
	}
/*	function getResource($file,$fileArray)	{
		return $this->checkFile($file);
	}*/
// ADDITION BEGIN: From the class "gifbuilder", 060502
	function getResource($file,$fileArray)	{
		$fileArray[ext]= $this->gifExtension;
		$cObj =t3lib_div::makeInstance("tslib_cObj");
		$cObj->start($this->data);
		return $cObj->getImgResource($file,$fileArray);
	}
	function checkFile($file)	{
		return $GLOBALS["TSFE"]->tmpl->getFileName($file);
	}
// ADDITION END:	
	function gifBuild()	{
		if ($this->setup)	{
			$gifFileName = $this->fileName("GB_");
			if (!@file_exists($gifFileName))	{		// File exists
				$this->make();
				$this->output($gifFileName);
				$this->destroy();
			}
			return $gifFileName;
		}
	}
	function fileName($pre)	{
		return $this->tempPath.$pre.t3lib_div::shortMD5(serialize($this->setup)).".".$this->extension();	// shortMD5 260900  
	}
	function extension() {
		switch(strtolower($this->setup[format]))	{
			case "jpg":
			case "jpeg":
				return "jpg";
			break;
			default:
				return $this->gifExtension;
			break;
		}
	}
}

/*
class gifbuilder extends tslib_gifBuilder	{
}
*/



?>