<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 2001-2002 Christian Jul Jensen (christian@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This class is a search indexer for Typo3
 *
 * @author	Christian Jul Jensen <christian@typo3.com>
 * @coauthor	Kasper Sk�rh�j <kasper@typo3.com>
 */


 
class tslib_searchIndex {
	var $excludeSections = "script,style";
	var $wordcount = 0;
	var $supportedExtensions="pdf,doc,txt,html,htm";
	var $pdf_mode = -20;	// zero: whole file is indexed in one. positive value: Indicates number of pages at a time, eg. "5" would means 1-5,6-10,.... Negative integer would indicate (abs value) number of groups. Eg "3" groups of 10 pages would be 1-4,5-8,9-10

	var $app = array(
		"pdftotext" => "/usr/local/bin/pdftotext",
		"pdfinfo" => "/usr/local/bin/pdfinfo",
		"catdoc" => "/usr/local/bin/catdoc"
	);
	
	var $defaultGrList="0,-1";
	var $defaultContentArray=array(
		"title"=>"",
		"description"=>"",
		"keywords"=>"",
		"body"=>"",
	);

	var $Itypes = array(
		"html" => 1,
		"htm" => 1,
		"pdf" => 2,
		"doc" => 3,
		"txt" => 4
	);
	
	var $reasons=array(
		-1 => "mtime matched the document, so no changes detected and no content updated",
		-2 => "The minimum age was not exceeded",
		1 => "The configured max-age was exceeded for the document and thus it's indexed.",
		2 => "The minimum age was exceed and mtime was set and the mtime was different, so the page was indexed.",
		3 => "The minimum age was exceed, but mtime was not set, so the page was indexed.",
		4 => "Page has never been indexed (is not represented in the index_phash table)."
	);

	var $convChars=array(
		"������������", 
		"������������"
	);
	var $page = array();
	var $conf = array();
	var $hash = array();
	var $contentParts=array();
	var $mtime = 0;				// If set, then the mtime of the document must be different in order to be indexed.
	var $tstamp_maxAge=0;		// If set, this tells a number of seconds that is the maximum age of an indexed document. Regardless of mtime the document will be re-indexed if this limit is exceeded.
	var $tstamp_minAge=0;		// If set, this tells a minimum limit before a document can be indexed again. This is regardless of mtime.
	var $rootLevel=array();
	var $content_md5h="";
	
	var $freqRange = 65000;
	var $freqMax = 0.1;
	
	/**
	 * Initializes.
	 * The situation is, that indexing is started from TSFE and therefore these parameters are needed.
	 */	
	function init($content,$conf,$id,$type,$gr_list,$cHashParams,$mtime,$rootLevel)	{
		$this->page["id"] = intval($id);
		$this->page["type"] = intval($type);
		$this->page["cHashParams"] = $cHashParams;
		$this->page["gr_list"] = $gr_list;
		
		$this->origContent = $content;
		$this->mtime = $mtime;
		$this->rootLevel = $rootLevel;
		
		$this->conf=array();
		$this->conf["index_externals"] = $conf["index_externals"];
		$this->conf["index_descrLgd"] = $conf["index_descrLgd"];
		
		$this->setT3Hashes();
	}

	/**
	 * Start indexing of the Typo3 page
	 * Called from TSFE
	 */	
	function indexTypo3PageContent()	{
		$check = $this->checkMtimeTstamp($this->mtime,$this->tstamp_maxAge,$this->tstamp_minAge,$this->hash["phash"]);
		if ($check > 0)	{
			$GLOBALS["TT"]->setTSlogMessage("Indexing needed, reason: ".$this->reasons[$check],1);
			$GLOBALS["TT"]->push("Split content","");
					// Divide into title,keywords,description and body:
				$this->contentParts = $this->splitHTMLContent($this->origContent);
			$GLOBALS["TT"]->pull();

				// Calculating a hash over what is to be the actual page content. Maybe this hash should not include title,description and keywords? The bodytext is the primary concern. (on the other hand a changed page-title would make no difference then, so dont!)
			$this->content_md5h = $this->md5inthash(implode($this->contentParts,""));	
				// This function checks if there is already a page (with gr_list = 0,-1) indexed and if that page has the very same contentHash. 
				// If the contentHash is the same, then we can rest assured that this page is already indexed and regardless of mtime and origContent we don't need to do anything more.
				// This will also prevent pages from being indexed if a fe_users has logged in and it turns out that the page content is not changed anyway. fe_users logged in should always search with hash_gr_list = "0,-1" OR "[their_group_list]". This situation will be prevented only if the page has been indexed with no user login on before hand. Else the page will be indexed by users until that event. However that does not present a serious problem.
			if ($this->checkContentHash())	{
				$Pstart=t3lib_div::milliseconds();
						// Splitting words
				$GLOBALS["TT"]->push("Extract words from content","");
					$splitInWords = $this->procesWordsInArrays($this->contentParts);
				$GLOBALS["TT"]->pull();

						// Analyse the indexed words.
				$GLOBALS["TT"]->push("Analyse the extracted words","");
					$indexArr = $this->indexAnalyze($splitInWords);
				$GLOBALS["TT"]->pull();

						// Submitting page (phash) record
				$GLOBALS["TT"]->push("Submitting page","");
					$this->submitPage();
				$GLOBALS["TT"]->pull();

						// Check words and submit to word list if not there
				$GLOBALS["TT"]->push("Check word list and submit words","");
					$this->checkWordList($indexArr);
					$this->submitWords($indexArr,$this->hash["phash"]);
				$GLOBALS["TT"]->pull();

						// Set parsetime
				$this->updateParsetime($this->hash["phash"],t3lib_div::milliseconds()-$Pstart);
				
						// Checking external files if configured for.
				$GLOBALS["TT"]->push("Checking external files","");
				if ($this->conf["index_externals"])	{
					$this->extractLinks($this->origContent);
				}
				$GLOBALS["TT"]->pull();
			} else {
				$this->updateTstamp($this->hash["phash"],$this->mtime);	// Update the timestatmp
				$this->updateRootline();
				$GLOBALS["TT"]->setTSlogMessage("Indexing not needed, the contentHash, ".$this->content_md5h.", has not changed. Timestamp updated.");
			}
		} else {
			$GLOBALS["TT"]->setTSlogMessage("Indexing not needed, reason: ".$this->reasons[$check]);
		}
	}

	/**
	 * Splits HTML content and returns an associative array, with title, a list of metatags, and a list of words in the body.
	 */	
	function splitHTMLContent($content) {

		# divide head from body ( u-ouh :) )
		
		$contentArr=$this->defaultContentArray;
		$contentArr["body"] = stristr($content,"<body");
		$headPart = substr($content,0,-strlen($contentArr["body"]));
		
		# get title
		$this->embracingTags($headPart,"TITLE",$contentArr["title"],$dummy2,$dummy);
		$titleParts = explode(":",$contentArr["title"],2);
		$contentArr["title"] = trim(isset($titleParts[1]) ? $titleParts[1] : $titleParts[0]);

		# get keywords and description metatags
		for($i=0;$this->embracingTags($headPart,"meta",$dummy,$headPart,$meta[$i]);$i++) { /*nothing*/ }
		for($i=0;isset($meta[$i]);$i++) {
			$meta[$i] = t3lib_div::get_tag_attributes($meta[$i]);
			if(stristr($meta[$i]["name"],"keywords")) $contentArr["keywords"].=",".$meta[$i]["content"];
			if(stristr($meta[$i]["name"],"description")) $contentArr["description"].=",".$meta[$i]["content"];
		}

		$this->typoSearchTags($contentArr["body"]);
		
		# get rid of unwanted sections (ie. scripting and style stuff) in body
		$tagList = explode(",",$this->excludeSections);
		reset($tagList);
		while(list(,$tag)=each($tagList)) {
			while($this->embracingTags($contentArr["body"],$tag,$dummy,$contentArr["body"],$dummy2));
		}

		# remove tags, but first make sure we don't concatenate words by doing it
		$contentArr["body"] = str_replace("<"," <",$contentArr["body"]);
		$contentArr["body"] = trim(strip_tags($contentArr["body"]));

		$contentArr["keywords"]=trim($contentArr["keywords"]);
		$contentArr["description"]=trim($contentArr["description"]);
		# ta-dah!
		return $contentArr;
	}
	
	/**
	 * Splits non-HTML content
	 */	
	function splitRegularContent($content) {
		$contentArr=$this->defaultContentArray;
		$contentArr["body"]=$content;

		return $contentArr;
	}

	/**
	 * Processing words in the array from split*Content -functions
	 */	
	function procesWordsInArrays($contentArr)	{
		# split all parts to words
		reset($contentArr);
		while(list($key,)=each($contentArr)) {
			$contentArr[$key] = $this->strtolower_all($contentArr[$key]);
			$this->split2words($contentArr[$key]);
		}
		
		# for title, keywords, and description we don't want duplicates
		$contentArr["title"] = array_unique($contentArr["title"]);
		$contentArr["keywords"] = array_unique($contentArr["keywords"]);
		$contentArr["description"] = array_unique($contentArr["description"]);
		return $contentArr;
	}
	
	/**
	 * Returns bodyDescription
	 */	
	function bodyDescription($contentArr)	{
		# Setting description
		if (intval($this->conf["index_descrLgd"]))	{
			$maxL = intval($this->conf["index_descrLgd"]);
			
			$bodyDescription = trim($contentArr["body"]);
			$bodyDescription = implode(" ",split("[[:space:],]+",substr($bodyDescription,0,$maxL*2)));	// Takes the double lenght first, because whitespace may be removed and thus shorten the string more yet. 
			$bodyDescription=substr($bodyDescription,0,$maxL);
		}
		return $bodyDescription;
	}
	
	/**
	 * extract links
	 */	
	function extractLinks($content) {
		$extract = t3lib_div::makeInstance("t3lib_htmlmail");
		$extract->extractHtmlInit($content,"");
		$extract->extractHyperLinks();
//		debug($extract->theParts["html"]["hrefs"]);
		if (is_array($extract->theParts["html"]["hrefs"]))	{
			reset($extract->theParts["html"]["hrefs"]);
			while(list(,$linkInfo)=each($extract->theParts["html"]["hrefs"]))	{
				if (strstr($linkInfo["ref"],"?") && strstr($linkInfo["ref"],"jumpurl="))	{
					$qParts = parse_url($linkInfo["ref"]);
					$theJumpurlFile = $this->getJumpurl($qParts["query"]);
//					debug($theJumpurlFile);
					if ($theJumpurlFile && @is_file($theJumpurlFile))	{
	//					debug($theJumpurlFile);
						$this->indexRegularDocument($theJumpurlFile);
					}	
				} elseif (@is_file($linkInfo["ref"]))	{
					$this->indexRegularDocument($linkInfo["ref"]);
				}
			}
		}
	}
	function getJumpurl($query)	{
		parse_str($query);
		
		return $jumpurl;
	}
	
	/**
	 * Splitting PDF info
	 */	
	function splitPdfInfo($pdfInfoArray)	{
		$res = array();
		if (is_array($pdfInfoArray))	{
			reset($pdfInfoArray);
			while(list(,$line)=each($pdfInfoArray))	{
				$parts = explode(":",$line,2);
				if (count($parts)>1 && trim($parts[0]))	{
					$res[strtolower(trim($parts[0]))] = trim($parts[1]);
				}
			}
		}
		return $res;
	}
	
	/**
	 * Indexing a regular document given as $file (url or relative, location file)
	 */	
	function indexRegularDocument($file)	{
			// init
		$fI=pathinfo($file);
		$ext = strtolower($fI["extension"]);
		$absFile = PATH_site.$file;
			// 
		if (@is_file($absFile) && t3lib_div::inList($this->supportedExtensions,$ext))	{
			$mtime = filemtime($absFile);
			$cParts = $this->fileContentParts($ext,$absFile);
//			debug($cParts);
			reset($cParts);
			while(list(,$cPKey)=each($cParts))	{
				$GLOBALS["TT"]->push("Index: ".str_replace(".","_",basename($file)).($cPKey?"#".$cPKey:""),"");
				$Pstart = t3lib_div::milliseconds();
				$subinfo=array("key"=>$cPKey);
				$phash_arr = $this->setExtHashes($file,$subinfo);
//				debug($phash_arr);
				
				$check = $this->checkMtimeTstamp($mtime,$this->tstamp_minAge,$this->tstamp_maxAge,$phash_arr["phash"]);
				if ($check > 0)	{
					$GLOBALS["TT"]->setTSlogMessage("Indexing needed, reason: ".$this->reasons[$check],1);
							// Divide into title,keywords,description and body:
					$GLOBALS["TT"]->push("Split content","");
						$contentParts = $this->readFileContent($ext,$absFile,$cPKey);
//						debug($contentParts);
					$GLOBALS["TT"]->pull();
					if (is_array($contentParts))	{
							// Calculating a hash over what is to be the actual content. (see indexTypo3PageContent())
						$content_md5h = $this->md5inthash(implode($contentParts,""));	
	
						if ($this->checkExternalDocContentHash($phash_arr["phash_grouping"], $content_md5h))	{
									// Splitting words
							$GLOBALS["TT"]->push("Extract words from content","");
								$splitInWords = $this->procesWordsInArrays($contentParts);
							$GLOBALS["TT"]->pull();
		
									// Analyse the indexed words.
							$GLOBALS["TT"]->push("Analyse the extracted words","");
								$indexArr = $this->indexAnalyze($splitInWords);
							$GLOBALS["TT"]->pull();
								
									// Submitting page (phash) record
							$GLOBALS["TT"]->push("Submitting page","");
								$size=filesize($absFile);
								$this->submitFilePage($phash_arr,$file,$subinfo,$ext,$mtime,$size,$content_md5h,$contentParts);
							$GLOBALS["TT"]->pull();
		
									// Check words and submit to word list if not there
							$GLOBALS["TT"]->push("Check word list and submit words","");
								$this->checkWordList($indexArr);
								$this->submitWords($indexArr,$phash_arr["phash"]);
							$GLOBALS["TT"]->pull();

								// Set parsetime
							$this->updateParsetime($phash_arr["phash"],t3lib_div::milliseconds()-$Pstart);
						} else {
							$this->updateTstamp($phash_arr["phash"],$mtime);	// Update the timestamp
							$GLOBALS["TT"]->setTSlogMessage("Indexing not needed, the contentHash, ".$content_md5h.", has not changed. Timestamp updated.");
						}
					} else {
						$GLOBALS["TT"]->setTSlogMessage("Could not index file! Unsupported extension.");
					}
				} else {
					$GLOBALS["TT"]->setTSlogMessage("Indexing not needed, reason: ".$this->reasons[$check]);
				}
					// Checking and setting sections:
				$this->submitFile_grlist($phash_arr["phash"]);	// Setting a gr_list record if there is none already (set for default fe_group)
				$this->submitFile_section($phash_arr["phash"]);		// Setting a section-record for the file. This is done also if the file is not indexed. Notice that section records are deleted when the page is indexed.
				$GLOBALS["TT"]->pull();
			}
		}
	}
	function readFileContent($ext,$absFile,$cPKey)	{
		switch ($ext)	{
			case "pdf":
					// Getting pdf-info:
				$cmd = $this->app["pdfinfo"]." ".$absFile;
				exec($cmd,$res);
				$pdfInfo=$this->splitPdfInfo($res);
			
				if (intval($pdfInfo["pages"]))	{
					list($low,$high) = explode("-",$cPKey);

						// Get pdf content:
					$tempFileName = tempnam("","Typo3_indexer");		// Create temporary name
					@unlink ($tempFileName);	// Delete if exists, just to be safe.
					$cmd = $this->app["pdftotext"]." -f ".$low." -l ".$high." -q ".$absFile." ".$tempFileName;
//					debug($cmd,1);
					exec($cmd,$res);
					$content = t3lib_div::getUrl($tempFileName);
					unlink($tempFileName);
					$contentArr = $this->splitRegularContent($content);
				}
			break;
			case "doc":
				$cmd = $this->app["catdoc"]." ".$absFile;
				exec($cmd,$res);
				$content = implode(chr(10),$res);
				$contentArr = $this->splitRegularContent($content);
			break;
			case "txt":
				$content = t3lib_div::getUrl($absFile);
				$contentArr = $this->splitRegularContent($content);
			break;
			case "html":
			case "htm":
				$fileContent = t3lib_div::getUrl($absFile);
				$contentArr = $this->splitHTMLContent($fileContent);
			break;
			default:
				return false;
			break;	
		}
		return $contentArr;
	}
	function fileContentParts($ext,$absFile)	{
		$cParts=array(0);
		switch ($ext)	{
			case "pdf":
					// Getting pdf-info:
				$cmd = $this->app["pdfinfo"]." ".$absFile;
				exec($cmd,$res);
				$pdfInfo=$this->splitPdfInfo($res);
			//	debug($pdfInfo);
			
				if (intval($pdfInfo["pages"]))	{
					$cParts=array();
						// Calculate mode
						// Calculate mode
					if ($this->pdf_mode>0)	{
						$iter=ceil($pdfInfo["pages"]/$this->pdf_mode);
					} else {
						$iter=t3lib_div::intInRange(abs($this->pdf_mode),1,$pdfInfo["pages"]);
					}
					for ($a=0;$a<$iter;$a++)	{
						$low=floor($a*($pdfInfo["pages"]/$iter))+1;
						$high=floor(($a+1)*($pdfInfo["pages"]/$iter));
						$cParts[]=$low."-".$high;
					}
				}
			break;
		}
		return $cParts;
	}
	
	/**
	 * Splits the incoming string into words
	 * The $string parameter is a reference and will be made into an array!
	 */	
	function split2words(&$string) {
		$words = split("[[:space:],]+",$string);
		$reg="[".quotemeta("().,_?!:-")."]*";
		$reg="[^[:alnum:]".$this->convChars[0].$this->convChars[1]."]*";
		
//		debug($words);
		reset($words);
		$matches=array();
		while(list(,$w)=each($words))	{
			$w=trim($w);
			$w=ereg_replace("^".$reg,"",$w);
			$w=ereg_replace($reg."$","",$w);
			if ($this->wordOK($w))	{$matches[]=$w;}
		}
//		debug($matches);
		$string =$matches;


		/*
		preg_match_all("/\b(\w[\w']*\w+|\w+)\b/", $string ,$matches);
		$string = $matches[0];
		*/
	}
	
	/** 
	 * Checks if a word is supposed to be indexed.
	 * This assessment includes that the word must be between 1 and 50 chars.
	 * The more exotic feature is that only 30 percent of the word must be non-alphanum characters. This is to exclude binary nonsense. This is done with a little trick it's counted how many chars are converted with a rawurlencode command. THis is not really an exact method, but I guess it's fast.
	 */
	function wordOK($w)	{
		if ($w && strlen($w)>1 && strlen($w)<50)	{
			if (rawurlencode($w)!=$w)	{
				$fChars = count(explode("%",rawurlencode($w)))-1;
				$rel = round($fChars/strlen($w)*100);
				return $rel<30 ? 1 : 0;		// Max 30% strange chars!
			} else {
				return 1;
			}
		}
	}
	
	/**
	 * Finds first occurence of embracing tags and returns the embraced content and the original string with
	 * the tag removed in the two passed variables. Returns false if no match found. ie. useful for finding 
	 * <title> of document or removing <script>-sections
	 */
	function embracingTags($string,$tagName,&$tagContent,&$stringAfter,&$paramList) {
		$endTag = "</".$tagName.">";
		$startTag = "<".$tagName;
		$isTagInText = stristr($string,$startTag);		// stristr used because we want a case-insensitive search for the tag.
		if(!$isTagInText) return false;	// if the tag was not found, return false

		list($paramList,$isTagInText) = explode(">",substr($isTagInText,strlen($startTag)),2);
		$afterTagInText = stristr($isTagInText,$endTag);
		if ($afterTagInText)	{
			$tagContent = substr($isTagInText,0,-strlen($afterTagInText));
			$stringAfter = substr($afterTagInText,strlen($endTag));
		} else {	// If there was no ending tag, the tagContent is blank and anything after the tag it self is returned.
			$tagContent="";
			$stringAfter = $isTagInText;
		}
//		debug(array($tagContent,$stringAfter));
		return true;
	}

	/**
	 * Analyzes content to use for indexing,
	 * the parameter must be an array with the keys title,keywords,description and body, which all contain an array of words.
	 */	
	function indexAnalyze($content) {
		$indexArr = Array();
		$counter = 0;
		
		$this->analyzeHeaderinfo($indexArr,$content,"title",7);
		$this->analyzeHeaderinfo($indexArr,$content,"keywords",6);
		$this->analyzeHeaderinfo($indexArr,$content,"description",5);
		$this->analyzeBody($indexArr,$content);

		return ($indexArr);
	}

	/**
	 * Calculates relevant information for headercontent
	 */
	function analyzeHeaderinfo(&$retArr,$content,$key,$offset) {
		reset($content[$key]);
		while(list(,$val)=each($content[$key]))  {
			$retArr[$val]["cmp"] = $retArr[$val]["cmp"]|pow(2,$offset);
			$retArr[$val]["count"] = $retArr[$val]["count"]+1;
			$retArr[$val]["hash"] = hexdec(substr(md5($val),0,8));
			$retArr[$val]["metaphone"] = $this->metaphone($val);
			$this->wordcount++;
		}	
	}

	/**
	 * Calculates relevant information for bodycontent
	 */
	function analyzeBody(&$retArr,$content) {
		reset($content["body"]);
		while(list($key,$val)=each($content["body"]))  {
			if(!isset($retArr[$val])) {
				$retArr[$val]["first"]=$key;
				$retArr[$val]["hash"] = hexdec(substr(md5($val),0,8));
				$retArr[$val]["metaphone"] = $this->metaphone($val);
			}
			$retArr[$val]["count"] = $retArr[$val]["count"]+1;
			$this->wordcount++;
		}	
	}
	
	/**
	 * Removes content that shouldn't be indexed according to TYPO3SEARCH-tags.
	 */
	function typoSearchTags(&$body) {
		$expBody = explode("<!--TYPO3SEARCH_",$body);
		if(!count($expBody)==1) {
			$body = "";
			reset($expBody);
			while(list(,$val)=each($expBody)) {
				$part = explode("-->",$val,2);
				if(trim($part[0])=="begin") {
					$body .= $part[1];
					$prev = "";
				} elseif(trim($part[0])=="end") {
					$body .= $prev;
				} else {
					$prev = $val;
				}
			}
			return true;
		} else {
			return false;
		}
	}

	/** 
	 * Check the Mtime / Tstamp of the currently indexed page
	 * Return positive integer if the page needs to being indexed!
	 */
	function checkMtimeTstamp($mtime,$minAge,$maxAge,$phash)	{
		$query="SELECT item_mtime, tstamp FROM index_phash WHERE phash='".$phash."'";
		$res = mysql (TYPO3_db, $query);
		$out=0;
		if ($row = mysql_fetch_assoc($res))	{
			if ($minAge && ($row["tstamp"]+$minAge)<time())	{		// If max age is exceed, index the page 
				$out=1;
			} else {
				if (!$maxAge || ($row["tstamp"]+$maxAge)<time())	{	// if minAge is not set or if minAge is exceeded, consider at mtime
					if ($mtime)	{		// It mtime is set, then it's tested. If not, the page must clearly be indexed.
						if ($row["item_mtime"] != $mtime)	{	// And if mtime is different from the index_phash mtime, it's about time to re-index.
							$out=2;
						} else {
							$out=-1;
							$this->updateTstamp($phash);	// Update the timestatmp
							$GLOBALS["TT"]->setTSlogMessage("Mtime matched, timestamp updated.",1);
						}
					} else {$out=3;	}
				} else {$out=-2;}
			}
		} else {$out=4;}
		return $out;
	}

	/** 
	 * Check content hash
	 * Returns true if the page needs to be indexed (that is, there was no result)
	 */
	function checkContentHash()	{
		$query = "SELECT * FROM index_phash AS A,index_grlist AS B WHERE A.phash=B.phash AND A.phash_grouping='".$this->hash["phash_grouping"]."' AND B.hash_gr_list=".$this->md5inthash($this->defaultGrList)." AND A.contentHash=".$this->content_md5h;
		$res = mysql (TYPO3_db, $query);
		if ($row = mysql_fetch_assoc($res))	{
			return 0;
		}
		return 1;
	}

	/** 
	 * Check content hash for external documents
	 * Returns true if the document needs to be indexed (that is, there was no result)
	 */
	function checkExternalDocContentHash($hashGr,$content_md5h)	{
		$query = "SELECT * FROM index_phash AS A WHERE A.phash_grouping='".$hashGr."' AND A.contentHash=".$content_md5h;
//		debug($query);
		$res = mysql (TYPO3_db, $query);
		if ($row = mysql_fetch_assoc($res))	{
			return 0;
		}
		return 1;
	}

	/** 
	 * Make insert query based on array
	 */
	function insertQuery($table,$fields)	{
		$q = "INSERT INTO ".$table." (".implode(",",array_keys($fields)).") VALUES ('".implode("','",$fields)."')";
		return $q;
	}

	/** 
	 * Update tstamp
	 */
	function updateTstamp($phash,$mtime=0)	{
		$mtimePart = $mtime ? ",item_mtime=".intval($mtime) : "";
		$query = "UPDATE index_phash SET tstamp=".time().$mtimePart." WHERE phash=".$phash;
		$res = mysql (TYPO3_db, $query);
		echo mysql_error();
	}

	/** 
	 * Update parsetime
	 */
	function updateParsetime($phash,$parsetime)	{
		$query = "UPDATE index_phash SET parsetime=".intval($parsetime)." WHERE phash=".$phash;
		$res = mysql (TYPO3_db, $query);
		echo mysql_error();
	}

	/** 
	 * Update section rootline for the page
	 */
	function updateRootline()	{
		$rl = $this->rootLevel;
		$query = "UPDATE index_section SET rl0=".intval($rl[0]["uid"]).",rl1=".intval($rl[1]["uid"]).",rl2=".intval($rl[2]["uid"])." WHERE page_id=".intval($this->page["id"]);
//		debug($query);
		$res = mysql (TYPO3_db, $query);
		echo mysql_error();
	}

	/** 
	 * Updates db with information about the page
	 */
	function submitPage()	{
			// Removing old registrations for all tables. Because the pages are Typo3 pages there can be nothing else that 1-1 relations here.
		$tableArr = explode(",","index_phash,index_section,index_grlist,index_fulltext");
		while(list(,$table)=each($tableArr))	{
			$res = mysql (TYPO3_db, "DELETE FROM ".$table." WHERE phash='".$this->hash["phash"]."'");
		}
			// Removing all index_section records with hash_t3 set to this hash
		$res = mysql (TYPO3_db, "DELETE FROM index_section WHERE phash_t3='".$this->hash["phash"]."'");
			
			// setting new
		$fields = array();
		$fields["phash"] = $this->hash["phash"];
		$fields["phash_grouping"] = $this->hash["phash_grouping"];
		$fields["cHashParams"] = addslashes(serialize($this->page["cHashParams"]));
		$fields["contentHash"] = $this->content_md5h;
		$fields["data_page_id"] = $this->page["id"];
		$fields["data_page_type"] = $this->page["type"];
		$fields["item_type"]=0;	// Typo3 page
		$fields["item_title"] = addslashes($this->contentParts["title"]);
		$fields["item_description"] = addslashes($this->bodyDescription($this->contentParts));
		$fields["item_mtime"] = $this->mtime;
		$fields["item_size"] = strlen($this->origContent);
		$fields["tstamp"] = time();
		$fields["crdate"] = time();

		$query = $this->insertQuery("index_phash",$fields);
		$res = mysql (TYPO3_db,$query);
		if (mysql_error())	echo mysql_error().'<!--submitPage_index_phash-->';

		// ************************
		// PROCESSING index_section
		// ************************
		$this->submit_section($this->hash["phash"],$this->hash["phash"]);

		// ************************
		// PROCESSING index_grlist
		// ************************
		$this->submit_grlist($this->hash["phash"]);

		// ************************
		// PROCESSING index_fulltext
		// ************************
		$fields = array();
		$fields["phash"] = $this->hash["phash"];
		$fields["fulltextdata"] = addslashes(implode($this->contentParts," "));
		$query = $this->insertQuery("index_fulltext",$fields);
		$res = mysql (TYPO3_db,$query);
		if (mysql_error())	echo mysql_error().'<!--submitPage_index_fulltext-->';
	}
	
	/** 
	 * Stores gr_list
	 */
	function submit_grlist($hash)	{
			// Setting the gr_list record
		$fields = array();
		$fields["phash"] = $hash;
		$fields["hash_gr_list"] = $this->md5inthash($this->page["gr_list"]);
		$fields["gr_list"] = $this->page["gr_list"];
		$query = $this->insertQuery("index_grlist",$fields);
		$res = mysql (TYPO3_db,$query);
//		debug($query);
		if (mysql_error())	echo mysql_error().'<!--submit_grlist_index_grlist-->';
	}

	/** 
	 * Stores section
	 */
	function submit_section($hash,$hash_t3)	{
		// ************************
		// PROCESSING index_section
		// ************************
		$rl = $this->rootLevel;
		$fields = array();
		$fields["phash"] = $hash;
		$fields["phash_t3"] = $hash_t3;
		$fields["rl0"]=intval($rl[0]["uid"]);
		$fields["rl1"]=intval($rl[1]["uid"]);
		$fields["rl2"]=intval($rl[2]["uid"]);
		$fields["page_id"]=intval($this->page["id"]);
		$query = $this->insertQuery("index_section",$fields);
		$res = mysql (TYPO3_db,$query);
		if (mysql_error())	echo mysql_error().'<!--submit_section_index_section-->';
	}

	/** 
	 * Updates db with information about the file
	 */
	function submitFilePage($hash,$file,$subinfo,$ext,$mtime,$size,$content_md5h,$contentParts)	{
			// Removing old registrations for tables.
		$tableArr = explode(",","index_phash,index_fulltext,index_grlist");
		while(list(,$table)=each($tableArr))	{
			$res = mysql (TYPO3_db, "DELETE FROM ".$table." WHERE phash='".$hash["phash"]."';");
		}
			// setting new
		$fields = array();
		$fields["phash"] = $hash["phash"];
		$fields["phash_grouping"] = $hash["phash_grouping"];
		$fields["cHashParams"] = addslashes(serialize($subinfo));
		$fields["contentHash"] = $content_md5h;
		$fields["data_filename"] = addslashes($file);
		$fields["item_type"]= intval($this->Itypes[$ext]) ? intval($this->Itypes[$ext]) : -1;
		$fields["item_title"] = addslashes(basename($file));
		$fields["item_description"] = addslashes($this->bodyDescription($contentParts));
		$fields["item_mtime"] = $mtime;
		$fields["item_size"] = $size;
		$fields["tstamp"] = time();
		$fields["crdate"] = time();

		$query = $this->insertQuery("index_phash",$fields);
		$res = mysql (TYPO3_db,$query);
		if (mysql_error())	echo mysql_error().'<!--submitFilePage_index_phash-->';

		// ************************
		// PROCESSING index_fulltext
		// ************************
		$fields = array();
		$fields["phash"] = $hash["phash"];
		$fields["fulltextdata"] = addslashes(implode($contentParts," "));
		$query = $this->insertQuery("index_fulltext",$fields);
		$res = mysql (TYPO3_db,$query);
		if (mysql_error())	echo mysql_error().'<!--submitFilePage_index_fulltext-->';
	}

	/** 
	 * Stores file gr_list for a file IF it does not exist
	 */
	function submitFile_grlist($hash)	{
		// ************************
		// PROCESSING index_grlist
		// ************************
			// Testing if there is a gr_list record for a non-logged in user and if so, there is no need to place another one.
		$query = "SELECT phash FROM index_grlist WHERE phash=".$hash." AND (hash_gr_list=".$this->md5inthash($this->defaultGrList)." OR hash_gr_list=".$this->md5inthash($this->page["gr_list"]).")";
//		debug($query);
		$res = mysql (TYPO3_db,$query);
		if (!mysql_num_rows($res))	{
			$this->submit_grlist($hash);
		}
	}

	/** 
	 * Stores file section for a file IF it does not exist
	 */
	function submitFile_section($hash)	{
		// ************************
		// PROCESSING index_grlist
		// ************************
			// Testing if there is a gr_list record for a non-logged in user and if so, there is no need to place another one.
		$query = "SELECT phash FROM index_section WHERE phash=".$hash." AND page_id=".intval($this->page["id"]);
		$res = mysql (TYPO3_db,$query);
		if (!mysql_num_rows($res))	{
			$this->submit_section($hash,$this->hash["phash"]);
		}
	}

	/** 
	 * Adds new words to db
	 */
	function checkWordList($wl) {
		reset($wl);
		$phashArr=array();
		while(list($key,)=each($wl)) {
			$phashArr[] = $wl[$key]["hash"];
		}
		if (count($phashArr))	{
			$cwl = implode(",",$phashArr);
			$res = mysql(TYPO3_db,"SELECT baseword FROM index_words WHERE wid in (".$cwl.");");
			echo mysql_error();
			if(mysql_num_rows($res)!=count($wl)) {
				$GLOBALS["TT"]->setTSlogMessage("Inserting words: ".(count($wl)-mysql_num_rows($res)),1);
				while($row = mysql_fetch_assoc($res)) {
					unset($wl[$row["baseword"]]);
				}
				reset($wl);
				while(list($key,$val)=each($wl)) {
					$res = mysql(TYPO3_db,"INSERT INTO index_words (wid, baseword, metaphone) VALUES ('".$val["hash"]."','".addslashes($key)."','".$val["metaphone"]."');");
					if (mysql_error())	echo mysql_error().'<!--checkWordList-->';
				}
			}
		}
	}
	
	/** 
	 * Submits information about words on the page to the db
	 */
	function submitWords($wl,$phash) {
		$res = mysql (TYPO3_db, "DELETE FROM index_rel WHERE phash='".$phash."';");
		echo mysql_error();
		reset($wl);
		while(list(,$val)=each($wl)) {
			$val["freq"] = $this->freqMap(($val["count"]/$this->wordcount));
			$res = mysql (TYPO3_db,"INSERT INTO index_rel (phash, wid, count, first, freq, flags) VALUES ('".$phash."','".$val["hash"]."','".$val["count"]."','".$val["first"]."','".$val["freq"]."','".$val["cmp"]."')");
			if (mysql_error())	echo mysql_error().'<!--submitWords-->';
		}
	}
	
	/** 
	 * metaphone
	 */
	function metaphone($word) {
		$tmp = metaphone($word);
		if($tmp=="") $ret=0; else $ret=hexdec(substr(md5($tmp),0,8));
		return $ret;
	}

	/** 
	 * Converts string-to-lower including special characters.
	 */
	function strtolower_all($str)	{
		return strtolower(strtr($str, $this->convChars[0], $this->convChars[1]));
	}

	/** 
	 * Get search hash, T3 pages
	 */
	function setT3Hashes()	{
			//  Set main array:
		$hArray = array(
			"id"=>$this->page["id"],
			"type"=>$this->page["type"],
			"cHash"=>$this->page["cHashParams"]
		);
			// Set grouping hash:
		$this->hash["phash_grouping"] = $this->md5inthash(serialize($hArray));
			// Add gr_list and set plain phash
		$hArray["gr_list"]=$this->page["gr_list"];
		$this->hash["phash"] = $this->md5inthash(serialize($hArray));
	}
	
	/** 
	 * Get search hash, external files
	 */
	function setExtHashes($file,$subinfo=array())	{
			//  Set main array:
		$hash=array();
		$hArray = array(
			"file" => $file,
		);
		
			// Set grouping hash:
		$hash["phash_grouping"] = $this->md5inthash(serialize($hArray));
			// Add subinfo
		$hArray["subinfo"]=$subinfo;
		$hash["phash"] = $this->md5inthash(serialize($hArray));
		return $hash;
	}
	
	/** 
	 * md5 integer hash
	 */
	function md5inthash($str)	{
		return hexdec(substr(md5($str),0,8));
	}
	/** 
	 * maps frequency from a real number in [0;1] to an integer in [0;$this->freqRange] with anything above $this->freqMax as 1
	 * and back.
	 */
	function freqMap($freq) {
		$mapFactor = $this->freqMax*100*$this->freqRange;
		if($freq<1) {
			$newFreq = $freq*$mapFactor;
			$newFreq = $newFreq>$this->freqRange?$this->freqRange:$newFreq;
		} else {
			$newFreq = $freq/$mapFactor;
		}
		return $newFreq;
		
	}
}

if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_searchindex.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_searchindex.php"]);
}

?>