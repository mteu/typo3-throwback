<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Content rendering based on TypoScript
 *
 * class tslib_cObj				:		contentObject (the main-thing in TS!)
 * class tslib_controlTable		:		Makes a table CTABLE (TS)
 * class tslib_tableOffset		:		Makes a table-offset (TS)
 * class tslib_frameset			: 		Generates framesets (TS)
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


include_once(PATH_t3lib."class.t3lib_parsehtml.php");

/** 
 * Rendering of content objects
 *
 * This class is normally instantiated and referred to as "cObj".
 * It does the rendering of socalled "cObjects" or "content objects" from TypoScript.
 * There are lots of functions you can use from your include-scripts.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
class tslib_cObj {
	var $align = Array ("center", "right", "left");

	/** 
	 * Holds ImageMagick parameters and extensions used for compression
	 *
	 * @see IMGTEXT()
	 *
	 * 0= Default
	 * 1= Dont change! (removes all parameters for the image_object!!)
	 * 1x = GIFs
	 * 2x = JPGs
	 */
	var $image_compression = Array(
		10 => Array("params"=>"", "ext"=>"gif"),
		11 => Array("params"=>"-colors 128", "ext"=>"gif"),
		12 => Array("params"=>"-colors 64", "ext"=>"gif"),
		13 => Array("params"=>"-colors 32", "ext"=>"gif"),
		14 => Array("params"=>"-colors 16", "ext"=>"gif"),
		15 => Array("params"=>"-colors 8", "ext"=>"gif"),

		30 => Array("params"=>"-colors 256", "ext"=>"png"),
		31 => Array("params"=>"-colors 128", "ext"=>"png"),
		32 => Array("params"=>"-colors 64", "ext"=>"png"),
		33 => Array("params"=>"-colors 32", "ext"=>"png"),
		34 => Array("params"=>"-colors 16", "ext"=>"png"),
		35 => Array("params"=>"-colors 8", "ext"=>"png"),
		39 => Array("params"=>"", "ext"=>"png"),

		20 => Array("params"=>"-quality 100", "ext"=>"jpg"),
		21 => Array("params"=>"-quality 90", "ext"=>"jpg"),
		22 => Array("params"=>"-quality 80", "ext"=>"jpg"),
		23 => Array("params"=>"-quality 70", "ext"=>"jpg"),
		24 => Array("params"=>"-quality 60", "ext"=>"jpg"),
		25 => Array("params"=>"-quality 50", "ext"=>"jpg"),
		26 => Array("params"=>"-quality 40", "ext"=>"jpg"),
		27 => Array("params"=>"-quality 30", "ext"=>"jpg"),
		28 => Array("params"=>"-quality 20", "ext"=>"jpg")
	);

	/** 
	 * ImageMagick parameters for image effects
	 *
	 * @see IMGTEXT()
	 */
	var $image_effects = Array(
		1 => "-rotate 90",
		2 => "-rotate 270",
		3 => "-rotate 180",
		10 => "-colorspace GRAY",
		11 => "-sharpen 70",
		20 => "-normalize",
		23 => "-contrast",
		25 => "-gamma 1.3",
		26 => "-gamma 0.8"
	);
	
	/** 
	 * Loaded with the current data-record.
	 *
	 * If the instance of this class is used to render records from the database those records are found in this array.
	 * The function stdWrap has TypoScript properties that fetch field-data from this array.
	 * @see init()
	 */
	var $data = Array();			
	var $oldData = Array();			// Used for backup...
	var $alternativeData ="";		// If this is set with an array before stdWrap, it's used instead of $this->data in the data-property in stdWrap
	var $parameters = Array();		// Used by the parseFunc function and is loaded with tag-parameters when parsing tags.
	var $currentValKey = "currentValue_kidjls9dksoje";
	var $currentRecord = "";		// This is set to the [table]:[uid] of the record delivered in the $data-array, if the cObjects CONTENT or RECORD is in operation. Note that $GLOBALS["TSFE"]->currentRecord is set to an equal value but always indicating the latest record rendered.
	var $currentRecordTotal=0;		// Set in cObj->RECORDS and cObj->CONTENT to the current number of records selected in a query.
	var $currentRecordNumber=0;		// Incremented in cObj->RECORDS and cObj->CONTENT before each record rendering.
	var $parentRecordNumber=0;		// Incremented in parent cObj->RECORDS and cObj->CONTENT before each record rendering.
	var $parentRecord=array();		// If the tslib_cObj was started from CONTENT, RECORD or SEARCHRESULT cObject's this array has two keys, "data" and "currentRecord" which indicates the record and data for the parent cObj.
	var $regObj;		// This may be set as a reference to the calling object of eg. cObjGetSingle. Anyway, just use it as you like. It's used in productsLib.inc for example.

	// internal
	var $INT_include=0;		// Is set to 1 if the instance of this cObj is executed from a PHP_SCRIPT_INT -include script (see pagegen, bottom of document)
	var $checkPid_cache = Array();		// This is used by checkPid, that checks if pages are accessible. The $checkPid_cache["page_uid"] is set true or false upon this check featuring a caching function for the next request.
	var $checkPid_badDoktypeList = "255";
	var $lastTypoLinkUrl=""; 	// This will be set by typoLink() to the url of the most recent link created.
	var $lastTypoLinkTarget=""; 	// DO. link target.
	var $substMarkerCache=array();	// Caching substituteMarkerArrayCached function
	
	/** 
	 * Class constructer. 
	 * 
	 * @param 	array 	$data	the record data that is rendered. 
	 * @param	stromg	$table	the table that the data record is from.
	 */
	function start($data,$table="")	{
		$this->data = $data;
		$this->currentRecord = $table ? $table.":".$this->data["uid"] : "";
		$this->parameters = Array();
	}
	function setParent($data,$currentRecord)	{
		$this->parentRecord=array("data"=>$data, "currentRecord"=>$currentRecord);
	}
	
	
	// *******************'
	// CONTENT_OBJ:
	// *******************'
	function getCurrentVal()	{
		return $this->data[$this->currentValKey];
	}
	function setCurrentVal($value)	{
		$this->data[$this->currentValKey] = $value;
	}
	function cObjGet($setup,$addKey="")	{
		if (is_array($setup))	{
			$sKeyArray=t3lib_TStemplate::sortedKeyList($setup);
			$content ="";
			reset($sKeyArray);
			while(list(,$theKey)=each($sKeyArray))	{
				$theValue=$setup[$theKey];
				if (intval($theKey) && !strstr($theKey,"."))	{
					$conf=$setup[$theKey."."];
					$ttKey=md5(microtime());
					$content.=$this->cObjGetSingle($theValue,$conf,$addKey.$theKey);	// Get the contentObject
				}
			}
			return $content;
		}
	}	
	function cObjGetSingle($name,$conf,$TSkey="__")	{
		$content="";
			// Checking that the function is not called eternally. This is done by interrupting at a depth of 100
		$GLOBALS["TSFE"]->cObjectDepthCounter--;
		if ($GLOBALS["TSFE"]->cObjectDepthCounter>0)	{
			$name = trim($name);
			if ($GLOBALS["TT"]->LR) $GLOBALS["TT"]->push($TSkey, $name);

				// Checking if the COBJ is a reference to another object. (eg. name of "blabla.blabla = < styles.something")
			if (substr($name,0,1)=="<")	{
				$key = trim(substr($name,1));
				$cF = t3lib_div::makeInstance("t3lib_TSparser");
					// $name and $conf is loaded with the referenced values.
				$old_conf=$conf;
				list($name, $conf) = $cF->getVal($key,$GLOBALS["TSFE"]->tmpl->setup);
				if (is_array($old_conf) && count($old_conf))	{
					$conf = $this->joinTSarrays($conf,$old_conf);
//					debug($conf);
				}
					// Getting the cObject
				$GLOBALS["TT"]->incStackPointer();
					$content.=$this->cObjGetSingle($name,$conf,$key);
				$GLOBALS["TT"]->decStackPointer();
			} else {
				switch($name)	{
					case "COBJ_ARRAY":
					case "COA":
						$content.=$this->COBJ_ARRAY($conf);
					break;
					case "COA_INT":
						$content.=$this->COBJ_ARRAY($conf,"INT");
					break;
					case "HTML":
						$content.=$this->HTML($conf);
					break;
					case "TEXT":
						$content.=$this->TEXT($conf);
					break;
					case "CLEARGIF":
						$content.=$this->CLEARGIF($conf);
					break;
					case "FILE":
						$content.=$this->FILE($conf);
					break;
					case "IMAGE":
						$content.=$this->IMAGE($conf);
					break;
					case "IMG_RESOURCE":
						$content.=$this->IMG_RESOURCE($conf);
					break;
					case "IMGTEXT":
						$content.=$this->IMGTEXT($conf);
					break;
					case "CONTENT":
						$content.=$this->CONTENT($conf);
					break;
					case "RECORDS":
						$content.=$this->RECORDS($conf);
					break;
					case "HMENU":
						$content.=$this->HMENU($conf);
					break;
					case "CTABLE":
						$content.=$this->CTABLE($conf);
					break;
					case "OTABLE":
						$content.=$this->OTABLE($conf);
					break;
					case "COLUMNS":
						$content.=$this->COLUMNS($conf);
					break;
					case "HRULER":
						$content.=$this->HRULER($conf);
					break;
					case "CASE":
						$content.=$this->CASEFUNC($conf);
					break;
					case "LOAD_REGISTER":
					case "RESTORE_REGISTER":
						$this->LOAD_REGISTER($conf,$name);
					break;
					case "FORM":
						$content.=$this->FORM($conf);
					break;
					case "SEARCHRESULT":
						$content.=$this->SEARCHRESULT($conf);
					break;
					case "PHP_SCRIPT":
						$content.=$this->PHP_SCRIPT($conf);
					break;
					case "PHP_SCRIPT_EXT":
						$content.=$this->PHP_SCRIPT($conf,"EXT");
					break;
					case "PHP_SCRIPT_INT":
						$content.=$this->PHP_SCRIPT($conf,"INT");
					break;
					case "USER":
						$content.=$this->USER($conf);
					break;
					case "USER_INT":
						$content.=$this->USER($conf,"INT");
					break;
					case "TEMPLATE":
						$content.=$this->TEMPLATE($conf);
					break;
					case "EDITPANEL":
						if ($GLOBALS["TSFE"]->beUserLogin)	{$content.=$this->editPanel($content, $conf);}
					break;
					case "MULTIMEDIA":
						$content.=$this->MULTIMEDIA($conf);
					break;
				}
			}
			if ($GLOBALS["TT"]->LR) $GLOBALS["TT"]->pull($content);
		}
			// Increasing on exit...
		$GLOBALS["TSFE"]->cObjectDepthCounter++;
		return $content;
	}







// *******************'
// Main content functions:
// *******************'

	function HTML($conf)	{
		return $this->stdWrap($conf["value"],$conf["value."]);
	}
	function TEXT($conf)	{
		return $this->stdWrap($conf["value"],$conf);
	}
	function CLEARGIF($conf)	{
		$w = $this->stdWrap($conf["width"],$conf["width."]);
		$h = $this->stdWrap($conf["height"],$conf["height."]);
		$w = $w ? $w : 1;
		$h = $h ? $h : 1;
		$wrap = $conf["wrap"] ? $conf["wrap"] : "|<BR>";
		$theValue = $this->wrap('<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$w.' height='.$h.' border=0>', $wrap);
		
		return $this->stdWrap($theValue,$conf["stdWrap."]);
	}
	function COBJ_ARRAY($conf,$ext="")	{
		$content="";
		switch($ext)	{
			case "INT":
				$substKey = $ext."_SCRIPT.".$GLOBALS["TSFE"]->uniqueHash();
				$content.="<!--".$substKey."-->";
				$GLOBALS["TSFE"]->config[$ext."incScript"][$substKey] = array(
					"file"=>$incFile, 
					"conf"=>$conf,
					"cObj"=>serialize($this),
					"type"=>"COA"
				);
			break;
			default:
				if ($this->checkIf($conf["if."]))	{
					$content=$this->cObjGet($conf);
					if ($conf["wrap"]) {
						$content=$this->wrap($content, $conf["wrap"]);
					}
					if ($conf["stdWrap."]) {
						$content=$this->stdWrap($content, $conf["stdWrap."]);
					}
				}
			break;
		}
		return $content;
	}
	function USER($conf,$ext="")	{
		$content="";
		switch($ext)	{
			case "INT":
				$substKey = $ext."_SCRIPT.".$GLOBALS["TSFE"]->uniqueHash();
				$content.="<!--".$substKey."-->";
				$GLOBALS["TSFE"]->config[$ext."incScript"][$substKey] = array(
					"file"=>$incFile, 
					"conf"=>$conf,
					"cObj"=>serialize($this),
					"type"=>"FUNC"
				);
			break;
			default:
				$content.=$this->callUserFunction($conf["userFunc"],$conf,"");
			break;
		}
		return $content;
	}
	function FILE($conf)	{
		$theValue = $this->fileResource($this->stdWrap($conf["file"],$conf["file."]));
		if ($conf["linkWrap"])	{
			$theValue = $this->linkWrap($theValue,$conf["linkWrap"]);
		}
		return $this->wrap($theValue,$conf["wrap"]);
	}
	function IMAGE($conf)	{
		$content="";
		if ($this->checkIf($conf["if."]))	{
			$theValue = $this->cImage($conf["file"],$conf);
			if ($conf["stdWrap."])	{
				$theValue = $this->stdWrap($theValue,$conf["stdWrap."]);
			}
			return $theValue;
		}
	}
	function IMG_RESOURCE($conf)	{
		$imgArray = $this->getImgResource($conf["file"],$conf["file."]);
		return $this->stdWrap($imgArray[3],$conf["stdWrap."]);
	}
	function IMGTEXT($conf) {
		$content="";
		if (is_array($conf["text."]))	{
			$content.= $this->stdWrap($this->cObjGet($conf["text."],"text."),$conf["text."]);	// this gets the surrounding content
		}
		$imgList=trim($this->stdWrap($conf["imgList"],$conf["imgList."]));	// gets images
		if ($imgList)	{
			$imgs = explode(",",$imgList);
			$imgStart = intval($this->stdWrap($conf["imgStart"],$conf["imgStart."]));
	
			$imgCount= count($imgs)-$imgStart;
	
			$imgMax = intval($this->stdWrap($conf["imgMax"],$conf["imgMax."]));
			if ($imgMax)	{
				$imgCount = t3lib_div::intInRange($imgCount,0,$conf["imgMax"]);	// reduces the number of images.
			}

			$imgPath = $this->stdWrap($conf["imgPath"],$conf["imgPath."]);

				// initialisation
			$caption="";
			if (is_array($conf["caption."]))	{
				$caption= $this->stdWrap($this->cObjGet($conf["caption."], "caption."),$conf["caption."]);
			}
			$captionArray=array();
			if ($conf["captionSplit"])	{
				$capSplit = $this->stdWrap($conf["captionSplit."]["token"],$conf["captionSplit."]["token."]);
				if (!$capSplit) {$capSplit=chr(10);}
				$caption2= $this->cObjGetSingle($conf["captionSplit."]["cObject"],$conf["captionSplit."]["cObject."],"captionSplit.cObject");
				$captionArray=explode($capSplit,$caption2);
				while(list($ca_key,$ca_val)=each($captionArray))	{
					$captionArray[$ca_key] = $this->stdWrap(trim($captionArray[$ca_key]), $conf["captionSplit."]["stdWrap."]);
				}
			}			
			
			$tablecode="";
			$position=$this->stdWrap($conf["textPos"],$conf["textPos."]);

			$tmppos = $position&7;
			$contentPosition = $position&24; 
			$align = $this->align[$tmppos];
			$cap = ($caption)?1:0;
			$txtMarg = intval($this->stdWrap($conf["textMargin"],$conf["textMargin."]));
			if (!$conf["textMargin_outOfText"] && $contentPosition<16)	{
				$txtMarg=0;
			}
			
			$cols = intval($this->stdWrap($conf["cols"],$conf["cols."]));
			$rows = intval($this->stdWrap($conf["rows"],$conf["rows."]));
			$colspacing = intval($this->stdWrap($conf["colSpace"],$conf["colSpace."]));
			$rowspacing = intval($this->stdWrap($conf["rowSpace"],$conf["rowSpace."]));

			$border = intval($this->stdWrap($conf["border"],$conf["border."])) ? 1:0;
			$borderColor = $this->stdWrap($conf["borderCol"],$conf["borderCol."]);
			$borderThickness = intval($this->stdWrap($conf["borderThick"],$conf["borderThick."]));
			
			$borderColor=$borderColor?$borderColor:"black";
			$borderThickness=$borderThickness?$borderThickness:1;
			
			$caption_align = $this->stdWrap($conf["captionAlign"],$conf["captionAlign."]);
			if (!$caption_align) {
				$caption_align = $align;
			}
				// generate cols
			$colCount = ($cols > 1) ? $cols : 1;
			if ($colCount > $imgCount)	{$colCount = $imgCount;}
			$rowCount = ($colCount > 1) ? ceil($imgCount / $colCount) : $imgCount;
				// generate rows
			if ($rows>1)  {
				$rowCount = $rows;
				if ($rowCount > $imgCount)	{$rowCount = $imgCount;}
				$colCount = ($rowCount>1) ? ceil($imgCount / $rowCount) : $imgCount;
			}
			
				// max Width
			$colRelations = trim($this->stdWrap($conf["colRelations"],$conf["colRelations."]));
			$maxW = intval($this->stdWrap($conf["maxW"],$conf["maxW."]));
			
			$maxWInText = intval($this->stdWrap($conf["maxWInText"],$conf["maxWInText."]));
			if (!$maxWInText)	{	// If maxWInText is not set, it's calculated to the 70 % of the max...
				$maxWInText = round($maxW/100*50);
			}
			
			if ($maxWInText && $contentPosition>=16)	{	// inText
				$maxW = $maxWInText;
			}

			if ($maxW && $colCount > 0) {	// If there is a max width and if colCount is greater than  column
/*				debug($border*$borderThickness*2);
				debug($maxW);
				debug($colspacing);
				debug(($maxW-$colspacing*($colCount-1)-$colCount*$border*$borderThickness*2));
				*/
				$maxW = ceil(($maxW-$colspacing*($colCount-1)-$colCount*$border*$borderThickness*2)/$colCount);
			}
				// create the relation between rows
			$colMaxW = Array();
			if ($colRelations)	{
				$rel_parts = explode(":",$colRelations);
				$rel_total = 0;
				for ($a=0;$a<$colCount;$a++)	{
					$rel_parts[$a] = intval($rel_parts[$a]);
					$rel_total+= $rel_parts[$a];
				}
				if ($rel_total)	{
					for ($a=0;$a<$colCount;$a++)	{
						$colMaxW[$a] = round(($maxW*$colCount)/$rel_total*$rel_parts[$a]);
					}
					if (min($colMaxW)<=0 || max($rel_parts)/min($rel_parts)>10)	{		// The difference in size between the largest and smalles must be within a factor of ten.
						$colMaxW = Array();
					}
				}
			}
			$image_compression = intval($this->stdWrap($conf["image_compression"],$conf["image_compression."]));
			$image_effects = intval($this->stdWrap($conf["image_effects"],$conf["image_effects."]));
			$image_frames = intval($this->stdWrap($conf["image_frames."]["key"],$conf["image_frames."]["key."]));
			
				// fetches pictures
			$splitArr=array();
			$splitArr["imgObjNum"]=$conf["imgObjNum"];
			$splitArr = $GLOBALS["TSFE"]->tmpl->splitConfArray($splitArr,$imgCount);

			$alttext = $this->stdWrap($conf["altText"],$conf["altText."]);
			if ($alttext) {
				$altP = ' alt="'.strip_tags($alttext).'"';
			}
				// EqualHeight
			$equalHeight = intval($this->stdWrap($conf["equalH"],$conf["equalH."]));
			if ($equalHeight)	{	// Initiate gifbuilder object in order to get dimensions AND calculate the imageWidth's
				$gifCreator = t3lib_div::makeInstance("tslib_gifbuilder");
				$gifCreator->init();
				$relations = Array();
				$relations_cols = Array();
				$totalMaxW = $maxW*$colCount;
				for($a=0;$a<$imgCount;$a++)	{
					$imgKey = $a+$imgStart;
					$imgInfo = $gifCreator->getImageDimensions($imgPath.$imgs[$imgKey]);
					$relations[$a] = $imgInfo[1] / $equalHeight;	// relationship between the original height and the wished height
					if ($relations[$a])	{	// if relations is zero, then the addition of this value is omitted as the image is not expected to display because of some error.
						$relations_cols[floor($a/$colCount)] += $imgInfo[0]/$relations[$a];	// counts the total width of the row with the new height taken into consideration.
					}
				}
			}

			$imageRowsFinalWidths = Array();	// contains the width of every image row
			$imageRowsMaxHeights = Array();
			$imgsTag=array();
			$origImages=array();
			for($a=0;$a<$imgCount;$a++)	{
				$GLOBALS["TSFE"]->register["IMAGE_NUM"] = $a;
				
				$imgKey = $a+$imgStart;
				$totalImagePath = $imgPath.$imgs[$imgKey];
				$this->data[$this->currentValKey] = $totalImagePath;
				$imgObjNum = intval($splitArr[$a]["imgObjNum"]);
				$imgConf = $conf[$imgObjNum."."];

				if ($equalHeight)	{
					$scale = 1;
					if ($totalMaxW)	{
						$rowTotalMaxW = $relations_cols[floor($a/$colCount)];
						if ($rowTotalMaxW > $totalMaxW)	{
							$scale = $rowTotalMaxW / $totalMaxW;
						}
					}
						// transfer info to the imageObject. Please note, that 
					$imgConf["file."]["height"] = round($equalHeight/$scale);

					unset($imgConf["file."]["width"]);
					unset($imgConf["file."]["maxW"]);
					unset($imgConf["file."]["maxH"]);
					unset($imgConf["file."]["minW"]);
					unset($imgConf["file."]["minH"]);
					unset($imgConf["file."]["width."]);
					unset($imgConf["file."]["maxW."]);
					unset($imgConf["file."]["maxH."]);
					unset($imgConf["file."]["minW."]);
					unset($imgConf["file."]["minH."]);
					$maxW = 0;	// setting this to zero, so that it doesn't disturb
				}
				
				if ($maxW) {
					if (count($colMaxW))	{
						$imgConf["file."]["maxW"] = $colMaxW[($a%$colCount)];
					} else {
						$imgConf["file."]["maxW"] = $maxW;
					}
				}
				
				if ($imgConf || $imgConf["file"]) {
					$imgConf["params"].=$altP;
					if ($this->image_effects[$image_effects])	{
						$imgConf["file."]["params"].= " ".$this->image_effects[$image_effects];
					}
					if ($image_frames)	{
						if (is_array($conf["image_frames."][$image_frames."."]))	{
							$imgConf["file."]["m."] = $conf["image_frames."][$image_frames."."];
						}
					}
					if ($image_compression && $imgConf["file"]!="GIFBUILDER")	{
						if ($image_compression==1)	{
							$tempImport = $imgConf["file."]["import"];
							$tempImport_dot = $imgConf["file."]["import."];
							unset($imgConf["file."]);
							$imgConf["file."]["import"] = $tempImport;
							$imgConf["file."]["import."] = $tempImport_dot;
						} elseif (isset($this->image_compression[$image_compression])) {
							$imgConf["file."]["params"].= " ".$this->image_compression[$image_compression]["params"];
							$imgConf["file."]["ext"] = $this->image_compression[$image_compression]["ext"];
							unset($imgConf["file."]["ext."]);
						}
					}
					$imgsTag[$imgKey] = $this->IMAGE($imgConf);
				} else {
					$imgsTag[$imgKey] = $this->IMAGE(Array('params'=>$altP, 'file'=>$totalImagePath)); 	// currentValKey !!!
				}
					// Store the original filepath
				$origImages[$imgKey]=$GLOBALS["TSFE"]->lastImageInfo;

				$imageRowsFinalWidths[floor($a/$colCount)] += $GLOBALS["TSFE"]->lastImageInfo[0];
				if ($GLOBALS["TSFE"]->lastImageInfo[1]>$imageRowsMaxHeights[floor($a/$colCount)])	{
					$imageRowsMaxHeights[floor($a/$colCount)] = $GLOBALS["TSFE"]->lastImageInfo[1];
				}
			}			
				// calculating the tableWidth:
				// TableWidth problems: It creates problems if the pictures are NOT as wide as the tableWidth.
			$tableWidth = max($imageRowsFinalWidths)+ $colspacing*($colCount-1) + $colCount*$border*$borderThickness*2;
			
				// make table for pictures
			$index=$imgStart;
			
			$noRows = $this->stdWrap($conf["noRows"],$conf["noRows."]);
			$noCols = $this->stdWrap($conf["noCols"],$conf["noCols."]);
			if ($noRows) {$noCols=0;}	// noRows overrides noCols. They cannot exist at the same time.
			if ($equalHeight) {
				$noCols=1;
				$noRows=0;
			}

			$rowCount_temp=1;
			$colCount_temp=$colCount;
			if ($noRows)	{
				$rowCount_temp = $rowCount;
				$rowCount=1;
			}
			if ($noCols)	{
				$colCount=1;
			}
				// col- and rowspans calculated
			$colspan = (($colspacing) ? $colCount*2-1 : $colCount);
			$rowspan = (($rowspacing) ? $rowCount*2-1 : $rowCount) + $cap;
			

				// Edit icons:
			$editIconsHTML = $conf["editIcons"]&&$GLOBALS["TSFE"]->beUserLogin ? $this->editIcons("",$conf["editIcons"],$conf["editIcons."]) : "";
			
				// strech out table:
			$tablecode="";
			$flag=0;
			$tablecode.='<tr>';
			if ($txtMarg && $align=="right")	{	// If right aligned, the textborder is added on the right side
				$tablecode.='<td rowspan="'.($rowspan+1).'" valign=top><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$txtMarg.' height=1>'.($editIconsHTML?"<BR>".$editIconsHTML:"").'</td>';
				$editIconsHTML="";
				$flag=1;
			}
			$tablecode.='<td colspan="'.$colspan.'"><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$tableWidth.' height=1></td>';
			if ($txtMarg && $align=="left")	{	// If left aligned, the textborder is added on the left side
				$tablecode.='<td rowspan="'.($rowspan+1).'" valign=top><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$txtMarg.' height=1>'.($editIconsHTML?"<BR>".$editIconsHTML:"").'</td>';
				$editIconsHTML="";
				$flag=1;
			}
			if ($flag) $tableWidth+=$txtMarg+1;
//			$tableWidth=0;
			$tablecode.='</tr>';

				
				// draw table
			for ($c=0;$c<$rowCount;$c++) {	// Looping through rows. If "noRows" is set, this is "1 time", but $rowCount_temp will hold the actual number of rows!
				if ($c && $rowspacing)	{		// If this is NOT the first time in the loop AND if space is required, a row-spacer is added. In case of "noRows" rowspacing is done further down.
					$tablecode.='<tr><td colspan="'.$colspan.'"><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$rowspacing.' border=0></td></tr>';
				}
				$tablecode.='<tr>';	// starting row
				for ($b=0; $b<$colCount_temp; $b++)	{	// Looping through the columns
					if ($b && $colspacing)	{		// If this is NOT the first iteration AND if column space is required. In case of "noCols", the space is done without a separate cell.
						if (!$noCols)	{
							$tablecode.='<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$colspacing.' height=1 border=0></td>';
						} else {
							$colSpacer='<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.($border?$colspacing-6:$colspacing).' height='.($imageRowsMaxHeights[$c]+($border?$borderThickness*2:0)).' border=0 align="'.($border?'left':'top').'">';
							$colSpacer='<td valign=top>'.$colSpacer.'</td>';	// added 160301, needed for the new "noCols"-table...
							$tablecode.=$colSpacer;
						}
					}
					if (!$noCols || ($noCols && !$b))	{
						$tablecode.='<td valign="top">';	// starting the cell. If "noCols" this cell will hold all images in the row, otherwise only a single image.
						if ($noCols)	{$tablecode.='<table width="'.$imageRowsFinalWidths[$c].'" border=0 cellpadding=0 cellspacing=0><tr>';}		// In case of "noCols" we must set the table-tag that surrounds the images in the row.
					}
					for ($a=0;$a<$rowCount_temp;$a++)	{	// Looping through the rows IF "noRows" is set. "noRows"  means that the rows of images is not rendered by physical table rows but images are all in one column and spaced apart with clear-gifs. This loop is only one time if "noRows" is not set.
						$imgIndex = $index+$a*$colCount_temp;
						if ($imgsTag[$imgIndex])	{
							if ($rowspacing && $noRows && $a) {		// Puts distance between the images IF "noRows" is set and this is the first iteration of the loop
								$tablecode.= '<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$rowspacing.'><BR>';
							}

							$imageHTML = $imgsTag[$imgIndex]."<BR>";
							$Talign = (!trim($captionArray[$imgIndex]) && !$noRows && !$conf["netprintApplicationLink"]) ? ' align="left"' : '';  // this is necessary if the tablerows are supposed to space properly together! "noRows" is excluded because else the images "layer" together. 
							if ($border)	{$imageHTML='<table border=0 cellpadding='.$borderThickness.' cellspacing=0 bgcolor="'.$borderColor.'"'.$Talign.'><tr><td>'.$imageHTML.'</td></tr></table>';}		// break-tag added 160301  , ($noRows?'':' align="left"')  removed 160301, break tag removed 160301 (later...)
							$imageHTML.=$editIconsHTML;		$editIconsHTML="";
							if ($conf["netprintApplicationLink"])	{$imageHTML = $this->netprintApplication_offsiteLinkWrap($imageHTML,$origImages[$imgIndex],$conf["netprintApplicationLink."]);}
							$imageHTML.=$captionArray[$imgIndex];	// Adds caption.
							if ($noCols)	{$imageHTML='<td valign=top>'.$imageHTML.'</td>';}		// If noCols, put in table cell.
							$tablecode.=$imageHTML;
						}
					}
					$index++;
					if (!$noCols || ($noCols && $b+1==$colCount_temp))	{
						if ($noCols)	{$tablecode.='</tr></table>';}	// In case of "noCols" we must finish the table that surrounds the images in the row.
						$tablecode.='</td>';	// Ending the cell. In case of "noCols" the cell holds all pictures!
					}
				}
				$tablecode.='</tr>';	// ending row
			}
			if ($c)	{
				// Table-tag is inserted
				$i=$contentPosition;
				$table_align = (($i==16) ? 'align="'.$align.'"' : '');
				$tablecode = '<table'.($tableWidth?' width="'.$tableWidth.'"':'').' border=0 cellspacing=0 cellpadding=0 '.$table_align.'>'.$tablecode;
				if ($editIconsHTML)	{	// IF this value is not long since reset.
					$tablecode.='<tr><td colspan="'.$colspan.'">'.$editIconsHTML.'</TD></tr>';
					$editIconsHTML="";
				}
				if ($cap)	{
					$tablecode.='<tr><td colspan="'.$colspan.'" align="'.$caption_align.'">'.$caption.'</TD></tr>';
				}
				$tablecode.='</table>';
				if ($conf["tableStdWrap."])	{$tablecode=$this->stdWrap($tablecode,$conf["tableStdWrap."]);}
			}

			$spaceBelowAbove = intval($this->stdWrap($conf["spaceBelowAbove"],$conf["spaceBelowAbove."]));
			switch ($contentPosition)	{
				case "0":	// above
					$output= '<DIV align="'.$align.'">'.$tablecode.'</div>'.$this->wrapSpace($content, $spaceBelowAbove."|0");
				break;
				case "8":	// below
					$output= $this->wrapSpace($content, "0|".$spaceBelowAbove).'<DIV align="'.$align.'">'.$tablecode.'</div>';
				break;
				case "16":	// in text
					$output= $tablecode.$content;
				break;
				case "24":	// in text, no wrap
					$theResult = "";
					$theResult.= '<table border=0 cellspacing=0 cellpadding=0><tr>';
					if ($align=="right")	{
						$theResult.= '<td valign=top>'.$content.'</td><td valign=top>'.$tablecode.'</td>';
					} else {
						$theResult.= '<td valign=top>'.$tablecode.'</td><td valign=top>'.$content.'</td>';
					}
					$theResult.= '</tr></table>';
					$output= $theResult;
				break;
			}
		} else {
			$output= $content;
		}
		return $output;
	}
	function CONTENT($conf)	{
		$theValue="";

		$originalRec=$GLOBALS["TSFE"]->currentRecord;	
		if ($originalRec)	{		// If the currentRecord is set, we register, that this record has invoked this function. It's should not be allowed to do this again then!!
			$GLOBALS["TSFE"]->recordRegister[md5($originalRec)]++;
		}

		if ($conf["table"]=="pages" || substr($conf["table"],0,3)=="tt_")	{

			$renderObjName = $conf["renderObj"] ? $conf["renderObj"] : "<".$conf["table"];
			$renderObjKey = $conf["renderObj"] ? "renderObj" : "";
			$renderObjConf = $conf["renderObj."];

			$query = $this->getQuery($conf["table"],$conf["select."]);
			$res = @mysql(TYPO3_db,$query);
			if ($error = mysql_error())	{
				$GLOBALS["TT"]->setTSlogMessage($error.":   ".$query,3);
			} else {
				$this->currentRecordTotal = mysql_num_rows($res);
				$GLOBALS["TT"]->setTSlogMessage($query);
				$GLOBALS["TT"]->setTSlogMessage("NUMROWS: ".mysql_num_rows($res));
				$cObj =t3lib_div::makeInstance("tslib_cObj");
				$cObj->setParent($this->data,$this->currentRecord);
				$this->currentRecordNumber=0;
				while ($row = mysql_fetch_assoc($res))	{
					if (!$GLOBALS["TSFE"]->recordRegister[md5($val["table"].":".$val["id"])])	{
						$this->currentRecordNumber++;
						$cObj->parentRecordNumber=$this->currentRecordNumber;
						$GLOBALS["TSFE"]->currentRecord=$conf["table"].":".$row["uid"];
						$this->lastChanged($row["tstamp"]);
						$cObj->start($row,$conf["table"]);
						if ($GLOBALS["TSFE"]->config["config"]["insertDmailerBoundaries"])	{$theValue.="<!--DMAILER_SECTION_BOUNDARY_".intval($row["module_sys_dmail_category"])."-->";}
						$theValue.=$cObj->cObjGetSingle($renderObjName, $renderObjConf, $renderObjKey);
					} else {debug($val["table"].":".$val["id"]);}
				}
				if ($GLOBALS["TSFE"]->config["config"]["insertDmailerBoundaries"])	{$theValue.="<!--DMAILER_SECTION_BOUNDARY_END-->";}
			}
		}
		
		$theValue = $this->wrap($theValue,$conf["wrap"]);
		if ($conf["stdWrap."]) $theValue = $this->stdWrap($theValue,$conf["stdWrap."]);
		$GLOBALS["TSFE"]->currentRecord=$originalRec;
		return $theValue;
	}
	function RECORDS($conf)	{
		$theValue="";

		$originalRec=$GLOBALS["TSFE"]->currentRecord;	
		if ($originalRec)	{		// If the currentRecord is set, we register, that this record has invoked this function. It's should not be allowed to do this again then!!
			$GLOBALS["TSFE"]->recordRegister[md5($originalRec)]++;
		}

		$conf["source"] = $this->stdWrap($conf["source"],$conf["source."]);
		if ($conf["tables"] && $conf["source"]) {
			$loadDB = t3lib_div::makeInstance("FE_loadDBGroup");
			$loadDB->start($conf["source"], $conf["tables"]);
			reset($loadDB->tableArray);
			while(list($table,)=each($loadDB->tableArray))	{
				if (is_array($GLOBALS["TCA"][$table]))	{
					$loadDB->additionalWhere[$table]=$this->enableFields($table);
				}
			}
			$loadDB->getFromDB();

			reset($loadDB->itemArray);
			$data = $loadDB->results;

			$cObj =t3lib_div::makeInstance("tslib_cObj");
			$cObj->setParent($this->data,$this->currentRecord);
			$this->currentRecordNumber=0;
			$this->currentRecordTotal = count($loadDB->itemArray);
			reset($loadDB->itemArray);
			while(list(,$val)=each($loadDB->itemArray))	{
				$row = $data[$val["table"]][$val["id"]];
				if (!$conf["dontCheckPid"])	{
					$row = $this->checkPid($row["pid"]) ? $row : "";
				}
				if ($row && !$GLOBALS["TSFE"]->recordRegister[md5($val["table"].":".$val["id"])])	{
					$renderObjName = $conf["conf."][$val["table"]] ? $conf["conf."][$val["table"]] : "<".$val["table"];
					$renderObjKey = $conf["conf."][$val["table"]] ? "conf.".$val["table"] : "";
					$renderObjConf = $conf["conf."][$val["table"]."."];
					$this->currentRecordNumber++;
					$GLOBALS["TSFE"]->currentRecord=$val["table"].":".$val["id"];
					$this->lastChanged($row["tstamp"]);
					$cObj->start($row,$val["table"]);
					if ($GLOBALS["TSFE"]->config["config"]["insertDmailerBoundaries"])	{$theValue.="<!--DMAILER_SECTION_BOUNDARY_".intval($row["module_sys_dmail_category"])."-->";}
					$theValue.=$cObj->cObjGetSingle($renderObjName, $renderObjConf, $renderObjKey);
					if ($GLOBALS["TSFE"]->config["config"]["insertDmailerBoundaries"])	{$theValue.="<!--DMAILER_SECTION_BOUNDARY_END-->";}
				}
			}
		}
		$GLOBALS["TSFE"]->currentRecord=$originalRec;
		return $this->wrap($theValue,$conf["wrap"]);
	}
	function HMENU($conf)	{
		$content="";
		if ($this->checkIf($conf["if."]))	{
			$cls=strtolower($conf[1]);
			if (t3lib_div::inList($GLOBALS["TSFE"]->tmpl->menuclasses,$cls))	{
				if ($conf["special."]["value."])	{
					$conf["special."]["value"]  = $this->stdWrap($conf["special."]["value"],$conf["special."]["value."]);
				}
				$GLOBALS["TSFE"]->register["count_HMENU"]++;
				$GLOBALS["TSFE"]->register["count_HMENU_MENUOBJ"]=0;

				$menu = t3lib_div::makeInstance("tslib_".$cls);
				$menu->parent_cObj = $this;
				$menu->start($GLOBALS["TSFE"]->tmpl,$GLOBALS["TSFE"]->sys_page,"",$conf,1);
				$menu->makeMenu();
				$content.=$menu->writeMenu();
			}
			if ($conf["wrap"]) 		$content=$this->wrap($content, $conf["wrap"]);
			if ($conf["stdWrap."])	$content = $this->stdWrap($content, $conf["stdWrap."]);
		}
		return $content;
	}
	function CTABLE ($conf)	{
		$controlTable = t3lib_div::makeInstance("tslib_controlTable");
			if ($conf["tableParams"])	{
			$controlTable->tableParams = $conf["tableParams"];
		}
			// loads the pagecontent
		$controlTable->contentW = $conf["cWidth"];
			// loads the menues if any
		if (is_array($conf["c."]))	{
			$controlTable->content = $this->cObjGet($conf["c."],"c.");
			$controlTable->contentTDparams = isset($conf["c."]["TDParams"]) ? $conf["c."]["TDParams"] : "valign=top";
		}
		if (is_array($conf["lm."]))	{
			$controlTable->lm = $this->cObjGet($conf["lm."],"lm.");
			$controlTable->lmTDparams = isset($conf["lm."]["TDParams"]) ? $conf["lm."]["TDParams"] : "valign=top";
		}
		if (is_array($conf["tm."]))	{
			$controlTable->tm = $this->cObjGet($conf["tm."],"tm.");
			$controlTable->tmTDparams = isset($conf["tm."]["TDParams"]) ? $conf["tm."]["TDParams"] : "valign=top";
		}
		if (is_array($conf["rm."]))	{
			$controlTable->rm = $this->cObjGet($conf["rm."],"rm.");
			$controlTable->rmTDparams = isset($conf["rm."]["TDParams"]) ? $conf["rm."]["TDParams"] : "valign=top";
		}
		if (is_array($conf["bm."]))	{
			$controlTable->bm = $this->cObjGet($conf["bm."],"bm.");
			$controlTable->bmTDparams = isset($conf["bm."]["TDParams"]) ? $conf["bm."]["TDParams"] : "valign=top";
		}
		return $controlTable->start($conf["offset"],$conf["cMargins"]);
	}
	function OTABLE ($conf)	{
		$controlTable = t3lib_div::makeInstance("tslib_tableOffset");
		if ($conf["tableParams"])	{
			$controlTable->tableParams = $conf["tableParams"];
		}
		return $controlTable->start($this->cObjGet($conf),$conf["offset"]);
	}
	function COLUMNS ($conf)	{
		$content="";
		if (is_array($conf) && $this->checkIf($conf["if."]))	{
			$tdRowCount=0;
			$tableParams = $conf["tableParams"] ? " ".$conf["tableParams"] : ' border=0 cellspacing=0 cellpadding=0';
			$TDparams = $conf["TDparams"] ? " ".$conf["TDparams"]:" valign=top";
			$rows = t3lib_div::intInRange($conf["rows"],2,20);
			$totalWidth = intval($conf["totalWidth"]);
			$columnWidth=0;

			$totalGapWidth=0;
			$gapData = Array(
				"gapWidth" => $this->stdWrap($conf["gapWidth"],$conf["gapWidth."]),
				"gapBgCol" => $this->stdWrap($conf["gapBgCol"],$conf["gapBgCol."]),
				"gapLineThickness" => $this->stdWrap($conf["gapLineThickness"],$conf["gapLineThickness."]),
				"gapLineCol" => $this->stdWrap($conf["gapLineCol"],$conf["gapLineCol."])
			);
			$gapData = $GLOBALS["TSFE"]->tmpl->splitConfArray($gapData,$rows-1);
			reset($gapData);
			while(list(,$val)=each($gapData))	{
				$totalGapWidth+=intval($val["gapWidth"]);
			}

			if ($totalWidth)	{
				$columnWidth = ceil(($totalWidth-$totalGapWidth)/$rows);
				$TDparams.=' width="'.$columnWidth.'"';
				$tableParams.=' width="'.$totalWidth.'"';
			} else {
				$TDparams.=' width="'.floor(100/$rows).'%"';
				$tableParams.=' width="100%"';
			}

			for ($a=1;$a<=$rows;$a++)	{
				$tdRowCount++;
				$content.='<TD'.$TDparams.'>';
				$content.=$this->cObjGetSingle($conf[$a],$conf[$a."."], $a);
				$content.='</TD>';
				if ($a < $rows)	{
					$gapConf = $gapData[($a-1)];
					$gapWidth = intval($gapConf["gapWidth"]);
					if ($gapWidth)	{
						$tdPar = $gapConf["gapBgCol"] ? ' bgColor="'.$gapConf["gapBgCol"].'"' : '';
						$gapLine = intval($gapConf["gapLineThickness"]);
						if ($gapLine)	{
							$gapSurround = t3lib_div::intInRange(($gapWidth-$gapLine)/2, 1, 1000);
								// right gap
							$content.='<TD'.$tdPar.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$gapSurround.' height=1></TD>';
							$tdRowCount++;
								// line:
							$GtdPar = $gapConf["gapLineCol"] ? ' bgColor="'.$gapConf["gapLineCol"].'"' : ' bgColor="black"';
							$content.='<TD'.$GtdPar.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$gapLine.' height=1></TD>';
							$tdRowCount++;
								// left gap
							$content.='<TD'.$tdPar.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$gapSurround.' height=1></TD>';
							$tdRowCount++;
						} else {
							$content.='<TD'.$tdPar.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$gapWidth.' height=1></TD>';
							$tdRowCount++;
						}
					}
				}
			}
			$content="<tr>".$content."</tr>";
			$content="<TABLE".$tableParams.">".$content."</TABLE>";
			$content.=$this->cObjGetSingle($conf["after"],$conf["after."], "after");
			if ($conf["stdWrap."])	{
				$content = $this->stdWrap($content,$conf["stdWrap."]);
			}
		}
		return $content;
	}
	function HRULER ($conf)	{
		$lineThickness = t3lib_div::intInRange($this->stdWrap($conf["lineThickness"],$conf["lineThickness."]),1,50);
		$lineColor = $conf["lineColor"] ? $conf["lineColor"] : "black";
		$spaceBefore = intval($conf["spaceLeft"]);
		$spaceAfter = intval($conf["spaceRight"]);
		$content="";
		
		$content.='<table border=0 cellspacing=0 cellpadding=0 width=99%><tr>';
		if ($spaceBefore)	{$content.='<td width=1><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$spaceBefore.' height=1></td>'; }
		$content.='<td bgColor="'.$lineColor.'"><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$lineThickness.'></td>';
		if ($spaceAfter)	{$content.='<td width=1><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$spaceAfter.' height=1></td>'; }
		$content.='</tr></table>';

		$content = $this->stdWrap($content, $conf["stdWrap."]);
		return $content;
	}
	function CASEFUNC ($conf){
		$content="";
		if ($this->checkIf($conf["if."]))	{
			if ($conf["setCurrent"] || $conf["setCurrent."]){$this->data[$this->currentValKey] = $this->stdWrap($conf["setCurrent"], $conf["setCurrent."]);}
	 		$key = $this->stdWrap($conf["key"],$conf["key."]);
	 		$key = $conf[$key] ? $key : "default";
	 		$name = $conf[$key];
	 		$theValue = $this->cObjGetSingle($name,$conf[$key."."], $key);
	 		if ($conf["stdWrap."])	{
	 			$theValue = $this->stdWrap($theValue,$conf["stdWrap."]);
	 		}			
	 		return $theValue;
		}
	}
	function LOAD_REGISTER($conf,$name)	{
		if ($name=="RESTORE_REGISTER")	{
			$GLOBALS["TSFE"]->register = array_pop($GLOBALS["TSFE"]->registerStack);
		} else {
			array_push($GLOBALS["TSFE"]->registerStack,$GLOBALS["TSFE"]->register);
			if (is_array($conf))	{
				reset($conf);
				while(list($theKey,$theValue)=each($conf))	{
					if (!strstr($theKey,".") || !isset($conf[substr($theKey,0,-1)]))	{		// Only if 1) the property is set but not the value itself, 2) the value and/or any property
						if (strstr($theKey,"."))	{
							$theKey = substr($theKey,0,-1);
						}
						$GLOBALS["TSFE"]->register[$theKey] = $this->stdWrap($conf[$theKey],$conf[$theKey."."]);
					}
				}
			}
		}
		return "";
	}
	function FORM($conf,$formData="")    {
		/*
			optional $formData:
			
			In the optional formData array each entry represents a line in the ordinary setup. In those entries each entry (0,1,2...) represents a space normally divided by the "|" line.
 
				$formData [] = array("Name:", "name=input, 25 ", "Default value...."); 
				$formData [] = array("Email:", "email=input, 25 ", "Default value for email....");

			- corresponds to the $conf["data"] value being :
				Name:|name=input, 25 |Default value....||Email:|email=input, 25 |Default value for email....
			
			If $formData is an array the value of $conf["data"] is ignored.
		*/
		$content="";
		if (is_array($formData))	{
			$dataArr = $formData;
		} else {
			$data=$this->stdWrap($conf["data"],$conf["data."]);
				// Clearing dataArr
			$dataArr=array();
				// Getting the original config
			if (trim($data))	{
				$data = ereg_replace(chr(10),"||",$data);
				$dataArr = explode("||",$data);
			} 
				// Adding the new dataArray config form:
			if (is_array($conf["dataArray."])) {	// dataArray is supplied
				reset($conf["dataArray."]);
				while(list($dAKey,$dAA)=each($conf["dataArray."]))	{
					if (is_array($dAA) && !strcmp(intval($dAKey).".",$dAKey))	{
						$temp=array();
						list($temp[0])= explode("|",$dAA["label."] ? $this->stdWrap($dAA["label"],$dAA["label."]) : $dAA["label"]);
						list($temp[1])= explode("|",$dAA["type"]);
						if ($dAA["required"])	{$temp[1]="*".$temp[1];}
						list($temp[2])= explode("|",$dAA["value."] ? $this->stdWrap($dAA["value"],$dAA["value."]) : $dAA["value"]);
							// If value Array is set, then implode those values.
						if (is_array($dAA["valueArray."]))	{
							reset($dAA["valueArray."]);
							$temp_accum = array();
							while(list($dAKey_vA,$dAA_vA)=each($dAA["valueArray."]))	{
								if (is_array($dAA_vA) && !strcmp(intval($dAKey_vA).".",$dAKey_vA))	{
									$temp_vA=array();
									list($temp_vA[0])= explode("=",$dAA_vA["label."] ? $this->stdWrap($dAA_vA["label"],$dAA_vA["label."]) : $dAA_vA["label"]);
									if ($dAA_vA["selected"])	{$temp_vA[0]="*".$temp_vA[0];}
									list($temp_vA[1])= explode(",",$dAA_vA["value"]);
								}
								$temp_accum[] = implode("=",$temp_vA);
							}
							$temp[2] = implode(",",$temp_accum);
						}
							// adding the form entry to the dataArray 
						$dataArr[] = implode("|",$temp);
					}
				}
			}
		}
		$attachmentCounter="";
		$hiddenfields="";
		$fieldlist=Array();
		$propertyOverride = Array();
		$fieldname_hashArray = Array();
		$cc=0;
		reset($dataArr);
		while(list(,$val)=each($dataArr)) {
			$cc++;
			$confData=Array();
			if (is_array($formData)) {
				$parts = $val;
				$val=1;    // true...
			} else {        
				$val=trim($val);
				$parts = explode("|",$val);
			}
			if ($val && strcspn($val,"#/")) {
					// label:
				$confData["label"] = trim($parts[0]);
					// field:
				$fParts = explode(",",$parts[1]);
				$fParts[0]=trim($fParts[0]);
				if (substr($fParts[0],0,1)=="*")	{
					$confData["required"]=1;
					$fParts[0] = substr($fParts[0],1);
				}
				$typeParts = explode("=",$fParts[0]);
				$confData["type"] = trim(strtolower(end($typeParts)));
				if (count($typeParts)==1)	{
					$confData["fieldname"] = substr(ereg_replace("[^a-zA-Z0-9_]","",str_replace(" ","_",trim($parts[0]))),0,30);
					if (strtolower(ereg_replace("[^[:alnum:]]","",$confData["fieldname"]))=="email")	{$confData["fieldname"]="email";}
						// Duplicate fieldnames resolved
					if (isset($fieldname_hashArray[md5($confData["fieldname"])]))	{
						$confData["fieldname"].="_".$cc;
					}
					$fieldname_hashArray[md5($confData["fieldname"])]=$confData["fieldname"];
						// Attachment names...
					if ($confData["type"]=="file")	{
						$confData["fieldname"]="attachment".$attachmentCounter;
						$attachmentCounter=intval($attachmentCounter)+1;
					}
				} else {
					$confData["fieldname"] = str_replace(" ","_",trim($typeParts[0]));
				}
				$fieldCode="";
				
					// Additional parameters
				if (trim($confData["type"]))	{
					$addParams=trim($conf["params"]);
					if (is_array($conf["params."]) && isset($conf["params."][$confData["type"]]))	{
						$addParams=trim($conf["params."][$confData["type"]]);
					}
					if (strcmp("",$addParams))	$addParams=" ".$addParams;
				} else $addParams="";
				
				switch($confData["type"])	{
					case"textarea":
						$cols=trim($fParts[1]) ? intval($fParts[1]) : 20;
						$compWidth = doubleval($conf["compensateFieldWidth"] ? $conf["compensateFieldWidth"] : $GLOBALS["TSFE"]->compensateFieldWidth);
						$compWidth = $compWidth ? $compWidth : 1;
						$cols = t3lib_div::intInRange($cols*$compWidth, 1, 120);
						
						$rows=trim($fParts[2]) ? t3lib_div::intInRange($fParts[2],1,30) : 5;
						$wrap=trim($fParts[3]) ? ' wrap="'.trim($fParts[3]).'"' : ' wrap="VIRTUAL"';
						$default = $this->getFieldDefaultValue($conf["noValueInsert"], $confData["fieldname"], trim($parts[2]));
						$fieldCode=sprintf('<textarea name="%s" cols="%s" rows="%s"%s'.$addParams.'>%s</textarea>',
							$confData["fieldname"], $cols, $rows, $wrap, t3lib_div::formatForTextarea($default));
					break;
					case"input":
					case"password":
						$size=trim($fParts[1]) ? intval($fParts[1]) : 20;
						$compWidth = doubleval($conf["compensateFieldWidth"] ? $conf["compensateFieldWidth"] : $GLOBALS["TSFE"]->compensateFieldWidth);
						$compWidth = $compWidth ? $compWidth : 1;
						$size = t3lib_div::intInRange($size*$compWidth, 1, 120);
						$default = $this->getFieldDefaultValue($conf["noValueInsert"], $confData["fieldname"], trim($parts[2]));
						if ($confData["type"]=="password")	{
							$default="";
						}

						$max=trim($fParts[2]) ? ' maxlength="'.t3lib_div::intInRange($fParts[2],1,1000).'"' : "";
						$theType = $confData["type"]=="input" ? "text" : "password";
						
						$fieldCode=sprintf('<input type="'.$theType.'" name="%s" size="%s"%s value="%s"'.$addParams.'>',
							$confData["fieldname"], $size, $max, htmlspecialchars($default));
					break;
					case"file":
						$size=trim($fParts[1]) ? t3lib_div::intInRange($fParts[1],1,60) : 20;
						$fieldCode=sprintf('<input type="file" name="%s" size="%s"'.$addParams.'>',
							$confData["fieldname"], $size);
					break;
					case"check":
							// alternative default value:
						$default = $this->getFieldDefaultValue($conf["noValueInsert"], $confData["fieldname"], trim($parts[2]));
						$checked = $default ? " checked" : "";
						$fieldCode=sprintf('<input type="Checkbox" value="%s" name="%s"%s'.$addParams.'>',
							1, $confData["fieldname"], $checked);
					break;
					case"select":
						$option="";
						$valueParts = explode(",",$parts[2]);
							// size
						if (strtolower(trim($fParts[1]))=="auto")	{$fParts[1]=count($valueParts);}		// Auto size set here. Max 20
						$size=trim($fParts[1]) ? t3lib_div::intInRange($fParts[1],1,20) : 1;
							// multiple
						$multiple = strtolower(trim($fParts[2]))=="m" ? " multiple" : "";
						
						$items=array();		// Where the items will be
						$defaults=array(); //RTF
						for($a=0;$a<count($valueParts);$a++)	{
							$valueParts[$a]=trim($valueParts[$a]);
							if (substr($valueParts[$a],0,1)=="*")	{	// Finding default value
								$sel="selected";
								$valueParts[$a] = substr($valueParts[$a],1);
							} else $sel="";
								// Get value/label
							$subParts=explode("=",$valueParts[$a]);
							$subParts[1] = (isset($subParts[1])?trim($subParts[1]):trim($subParts[0]));		// Sets the value
							$items[] = $subParts;	// Adds the value/label pair to the items-array
							if ($sel) {$defaults[]=$subParts[1];}	// Sets the default value if value/label pair is marked as default.
						}
							// alternative default value:
						$default = $this->getFieldDefaultValue($conf["noValueInsert"], $confData["fieldname"], $defaults);
						if (!is_array($default)) {
							$defaults=array();
							$defaults[] = $default;
						} else $defaults=$default;
							// Create the select-box:
						for($a=0;$a<count($items);$a++)	{
							$option.='<option value="'.$items[$a][1].'"'.(in_array($items[$a][1],$defaults)?" selected":"").'>'.trim($items[$a][0]).'</option>'; //RTF
						}
						
						if ($multiple)	$confData["fieldname"].="[]";	// The fieldname must be prepended "[]" if multiple select. And the reason why it's prepended is, because the required-field list later must also have [] prepended. 
						$fieldCode=sprintf('<select name="%s" size="%s"%s'.$addParams.'>%s</select>',
							$confData["fieldname"], $size, $multiple, $option); //RTF
					break;
					case"radio":
						$option="";
						$valueParts = explode(",",$parts[2]);
						$items=array();		// Where the items will be
						$default="";
						for($a=0;$a<count($valueParts);$a++)	{
							$valueParts[$a]=trim($valueParts[$a]);
							if (substr($valueParts[$a],0,1)=="*")	{
								$sel="checked";
								$valueParts[$a] = substr($valueParts[$a],1);
							} else $sel="";
								// Get value/label
							$subParts=explode("=",$valueParts[$a]);
							$subParts[1] = (isset($subParts[1])?trim($subParts[1]):trim($subParts[0]));		// Sets the value
							$items[] = $subParts;	// Adds the value/label pair to the items-array
							if ($sel) {$default=$subParts[1];}	// Sets the default value if value/label pair is marked as default.
						}
							// alternative default value:
						$default = $this->getFieldDefaultValue($conf["noValueInsert"], $confData["fieldname"], $default);
							// Create the select-box:
						for($a=0;$a<count($items);$a++)	{
							$option.= '<input type="Radio" name="'.$confData["fieldname"].'" value="'.$items[$a][1].'"'.(!strcmp($items[$a][1],$default)?" checked":"").''.$addParams.'>';
							$option.= $this->stdWrap(trim($items[$a][0]), $conf["radioWrap."]);
							$option.= "<BR>";
						}
						$fieldCode=$option;
					break;
					case "hidden":
						$value=trim($parts[2]);
						$hiddenfields.=sprintf('<input type="hidden" name="%s" value="%s">',
							$confData["fieldname"], $value);
					break;
					case "property":
						if (t3lib_div::inList("type,locationData,goodMess,badMess",$confData["fieldname"]))	{
							$value=trim($parts[2]);
							$propertyOverride[$confData["fieldname"]] = $value;
							$conf[$confData["fieldname"]] = $value;
						}
					break;
					case "submit":
						$value=trim($parts[2]);
						if ($conf["image."])	{
							$this->data[$this->currentValKey]=$value;
							$image=$this->IMAGE($conf["image."]);
						} else $image="";
						if($image)	{
							$fieldCode = str_replace('<img','<input type="Image"'.$addParams.' name="'.$confData["fieldname"].'"' ,$image);
						} else {
							$fieldCode=sprintf('<input type="Submit" name="%s" value="%s"'.$addParams.'>',
								$confData["fieldname"], $value);
						}
					break;
					default:
						$confData["type"]="comment";
						$fieldCode=trim($parts[2])."&nbsp;";
					break;
				}
				if ($fieldCode)	{
					$fieldCode = $this->stdWrap($fieldCode, $conf["fieldWrap."]);
					$labelCode = $this->stdWrap($confData["label"], $conf["labelWrap."]);
					$commentCode = $this->stdWrap($confData["label"], $conf["commentWrap."]); // RTF
					$result = $conf["layout"];
					if ($conf["REQ"] && $confData["required"])	{
						if (is_array($conf["REQ."]["fieldWrap."]))
							$fieldCode = $this->stdWrap($fieldCode, $conf["REQ."]["fieldWrap."]);
						if (is_array($conf["REQ."]["labelWrap."]))
							$labelCode = $this->stdWrap($confData["label"], $conf["REQ."]["labelWrap."]);
						if ($conf["REQ."]["layout"])	{
							$result = $conf["REQ."]["layout"];
						}
					}
					if ($confData["type"]=="comment" && $conf["COMMENT."]["layout"])	{
						$result = $conf["COMMENT."]["layout"];
					}
					if ($confData["type"]=="check" && $conf["CHECK."]["layout"])	{
						$result = $conf["CHECK."]["layout"];
					}
					if ($confData["type"]=="radio" && $conf["RADIO."]["layout"])	{
						$result = $conf["RADIO."]["layout"];
					}
					$result = str_replace("###FIELD###",$fieldCode,$result);
					$result = str_replace("###LABEL###",$labelCode,$result);
					$result = str_replace("###COMMENT###",$commentCode,$result); //RTF
					$content.=$result;
						// Required:
					if ($confData["required"] && $confData["type"]!="check")	{
						$fieldlist[]=rawurlencode($confData["fieldname"]);
						$fieldlist[]=rawurlencode($confData["label"]);
					}
				}
			}
		}
		if ($conf["stdWrap."]) $content=$this->stdWrap($content, $conf["stdWrap."]);


			// redirect (external: where to go afterwards. internal: where to submit to)
		$theRedirect = $this->stdWrap($conf["redirect"], $conf["redirect."]);			// redirect should be set to the page to redirect to after an external script has been used. If internal scripts is used, and if no "type" is set that dictates otherwise, redirect is used as the url to jump to as long as it's an integer (page)
		$page=$GLOBALS["TSFE"]->page;
		if (!$theRedirect)	{		// Internal: Just submit to current page
			$LD=$GLOBALS["TSFE"]->tmpl->linkData($page, $conf["target"], $conf["no_cache"],"index.php");
		} elseif (t3lib_div::testInt($theRedirect))	{		// Internal: Submit to page with id $theRedirect
			$page = $GLOBALS["TSFE"]->sys_page->getPage_noCheck($theRedirect);
			$LD=$GLOBALS["TSFE"]->tmpl->linkData($page, $conf["target"], $conf["no_cache"],"index.php");
		} else {	// External url, redirect-hidden field is rendered!
			$LD=$GLOBALS["TSFE"]->tmpl->linkData($page, $conf["target"], $conf["no_cache"],"");
			$LD["totalURL"]=$theRedirect;
			$hiddenfields.='<input type="hidden" name="redirect" value="'.$LD["totalURL"].'">';		// 18-09-00 added
		}

			// Formtype (where to submit to!):
		$formtype = $propertyOverride["type"] ? $propertyOverride["type"] : $this->stdWrap($conf["type"], $conf["type."]);
		if (t3lib_div::testInt($formtype))	{	// Submit to a specific page
			$page = $GLOBALS["TSFE"]->sys_page->getPage_noCheck($formtype);
			$LD_A=$GLOBALS["TSFE"]->tmpl->linkData($page,$conf["target"],$conf["no_cache"],"");
			$action=$LD_A["totalURL"];
		} elseif ($formtype){		// Submit to external script
			$LD_A=$LD;
			$action = $formtype;
		} elseif (t3lib_div::testInt($theRedirect)) {
			$LD_A=$LD;
			$action=$LD_A["totalURL"];
		} else {		// Submit to "nothing" - which is current page
			$LD_A=$GLOBALS["TSFE"]->tmpl->linkData($GLOBALS["TSFE"]->page,$conf["target"],$conf["no_cache"],"");
			$action=$LD_A["totalURL"];
		}

			// copyemail:
		$theEmail = $this->stdWrap($conf["recipient"], $conf["recipient."]);
		if ($theEmail)	{
			$hiddenfields.='<input type="hidden" name="recipient" value="'.$theEmail.'">';
		}
		
			// location data:
		if ($conf["locationData"])	{
			if ($conf["locationData"]=="HTTP_POST_VARS" && isset($GLOBALS["HTTP_POST_VARS"]["locationData"]))	{
				$locationData = $GLOBALS["HTTP_POST_VARS"]["locationData"];
			} else {
				$locationData = $GLOBALS["TSFE"]->id.":".$this->currentRecord;	// locationData is [hte page id]:[tablename]:[uid of record]. Indicates on which page the record (from tablename with uid) is shown. Used to check access.
			}
			$hiddenfields.='<input type="hidden" name="locationData" value="'.$locationData.'">';
		}

			// hidden fields:
		if (is_array($conf["hiddenFields."]))	{
			reset($conf["hiddenFields."]);
			while(list($hF_key,$hF_conf)=each($conf["hiddenFields."]))	{
				if (substr($hF_key,-1)!=".")	{
					$hF_value = $this->cObjGetSingle($hF_conf,$conf["hiddenFields."][$hF_key."."],"hiddenfields");
					$hiddenfields.='<input type="hidden" name="'.$hF_key.'" value="'.htmlspecialchars($hF_value).'">';
				}
			}
		}
		
			// Formname;
		$formname = $GLOBALS["TSFE"]->uniqueHash();
		if ($conf["REQ"])	{
			$validateForm=' onSubmit="return validateForm(\''.$formname.'\',\''.implode($fieldlist,",").'\',\''.rawurlencode($conf["goodMess"]).'\',\''.rawurlencode($conf["badMess"]).'\')"';
		$GLOBALS["TSFE"]->additionalHeaderData["JSFormValidate"] = '<SCRIPT LANGUAGE="JavaScript" SRC="'.$GLOBALS["TSFE"]->absRefPrefix.'t3lib/jsfunc.validateform.js"></SCRIPT>';
		} else $validateForm="";
		
		$content = '<form action="'.$action.'" name="'.$formname.'" enctype="multipart/form-data" method="'.($conf["method"]?$conf["method"]:"POST").'" target="'.($theRedirect?$LD["target"]:$LD_A["target"]).'"'.$validateForm.'>'.
					$hiddenfields.$content.
					'</form>';
		return $content;
	}
	function SEARCHRESULT($conf)	{
		if (t3lib_div::GPvar("sword") && t3lib_div::GPvar("scols"))	{
			$search = t3lib_div::makeInstance("tslib_search");
			$search->register_and_explode_search_string(stripSlashes(t3lib_div::GPvar("sword")));
			$search->register_tables_and_columns(t3lib_div::GPvar("scols"),$conf["allowedCols"]);
				// depth		
			$depth=100;
				// the startId is found
			$theStartId=0;
			if (t3lib_div::testInt(t3lib_div::GPvar("stype")))	{
				$temp_theStartId=t3lib_div::GPvar("stype");
				$rootLine = $GLOBALS["TSFE"]->sys_page->getRootLine($temp_theStartId);
					// The page MUST have a rootline with the Level0-page of the current site inside!!
				while(list(,$val)=each($rootLine))	{
					if($val["uid"]==$GLOBALS["TSFE"]->tmpl->rootLine[0][uid])	{
						$theStartId=$temp_theStartId;
					}
				}
			} else if (t3lib_div::GPvar("stype"))	{
				if (substr(t3lib_div::GPvar("stype"),0,1)=="L")	{
					$pointer = intval(substr(t3lib_div::GPvar("stype"),1));
					$theRootLine = $GLOBALS["TSFE"]->tmpl->rootLine;
						// location Data:
					$locDat_arr = explode(":",$GLOBALS["HTTP_POST_VARS"]["locationData"]);
					$pId = intval($locDat_arr[0]);
					if ($pId)	{
						$altRootLine = $GLOBALS["TSFE"]->sys_page->getRootLine($pId);
						ksort($altRootLine);
						if (count($altRootLine))	{
								// check if the rootline has the real Level0 in it!!
							reset($altRootLine);
							$hitRoot=0;
							$theNewRoot=array();
							while(list(,$val)=each($altRootLine))	{
								if($hitRoot || $val["uid"]==$GLOBALS["TSFE"]->tmpl->rootLine[0][uid])	{
									$hitRoot=1;
									$theNewRoot[]=$val;
								}
							}
							if ($hitRoot)	{
								$theRootLine = $theNewRoot;		// Override the real rootline if any thing 
							}
						}
					}
					$key = $this->getKey($pointer,$theRootLine);
					$theStartId = $theRootLine[$key][uid];
				}
			}
			if (!$theStartId)	{
					// If not set, we use current page
				$theStartId=$GLOBALS["TSFE"]->id;
			}
				// generate page-tree
			$search->pageIdList.=$this->getTreeList($theStartId,$depth);
//			debug($search->pageIdList);
			
			$endClause = "pages.uid IN (".$search->pageIdList.$theStartId.") AND pages.doktype in (1,2,5) AND pages.no_search=0";
//				debug();
			$endClause.=$this->enableFields($search->fTable).$this->enableFields("pages");
				// build query
			$search->build_search_query ($endClause);
//			debug($search->query);

				// count...
			if (t3lib_div::testInt(t3lib_div::GPvar("scount")))	{
				$search->res_count=t3lib_div::GPvar("scount");
			} else {
				$search->count_query();
			}
				// range
			$spointer = intval(t3lib_div::GPvar("spointer"));
			if (isset($conf["range"]))	{
				$theRange = intval($conf["range"]);
			} else {
				$theRange=20;
			}
			if (!$conf["noOrderBy"])	{
				$search->query.=" ORDER BY pages.lastUpdated, pages.tstamp";
			}
			$search->query.=" LIMIT ".$spointer.",".$theRange;
			$GLOBALS["TT"]->setTSlogMessage("Search query:   ".$search->query);
			
				// search...
			$search->execute_query();
			if (mysql_num_rows($search->result))	{
				$GLOBALS["TSFE"]->register["SWORD_PARAMS"] = $search->get_searchwords();
			
				$total=$search->res_count;
				$rangeLow = t3lib_div::intInRange($spointer+1,1,$total);
				$rangeHigh = t3lib_div::intInRange($spointer+$theRange,1,$total);
					// prev/next url:
				$LD=$GLOBALS["TSFE"]->tmpl->linkData($GLOBALS["TSFE"]->page,$conf["target"],1,"");
				$targetPart = $LD["target"] ? ' target="'.$LD["target"].'"' : '';
				$urlParams = $this->URLqMark($LD["totalURL"],
						"&sword=".rawurlencode(t3lib_div::GPvar("sword")).
						"&scols=".rawurlencode(t3lib_div::GPvar("scols")).
						"&stype=".rawurlencode(t3lib_div::GPvar("stype")).
						"&scount=".$total);
					// substitution:
				$result= $this->cObjGetSingle($conf["layout"],$conf["layout."], "layout");
				$result = str_replace("###RANGELOW###",$rangeLow,$result);
				$result = str_replace("###RANGEHIGH###",$rangeHigh,$result);
				$result = str_replace("###TOTAL###",$total,$result);
				
				if ($rangeHigh<$total)	{
					$next = $this->cObjGetSingle($conf["next"], $conf["next."], "next");
					$next = '<A HREF="'.$urlParams.'&spointer='.($spointer+$theRange).'"'.$targetPart.$GLOBALS["TSFE"]->ATagParams.'>'.$next.'</a>';
				} else $next="";
				$result = str_replace("###NEXT###",$next,$result);

				if ($rangeLow>1)	{
					$prev = $this->cObjGetSingle($conf["prev"], $conf["prev."], "prev");
					$prev = '<A HREF="'.$urlParams.'&spointer='.($spointer-$theRange).'"'.$targetPart.$GLOBALS["TSFE"]->ATagParams.'>'.$prev.'</a>';
				} else $prev="";
				$result = str_replace("###PREV###",$prev,$result);

					// searching result
				$theValue = $this->cObjGetSingle($conf["resultObj"], $conf["resultObj."],"resultObj");
				$cObj =t3lib_div::makeInstance("tslib_cObj");
				$cObj->setParent($this->data,$this->currentRecord);
				$renderCode="";
				while ($row = mysql_fetch_assoc($search->result))	{
					$cObj->start($row);
					$renderCode.=$cObj->cObjGetSingle($conf["renderObj"], $conf["renderObj."],"renderObj");
				}
				$theValue.=$this->wrap($renderCode,$conf["renderWrap"]);
				$theValue = str_replace("###RESULT###",$theValue,$result);
			} else {
				$theValue = $this->cObjGetSingle($conf["noResultObj"], $conf["noResultObj."],"noResultObj");
			}

			$GLOBALS["TT"]->setTSlogMessage("Search in fields:   ".$search->listOfSearchFields);

				// wrapping
			$content=$theValue;
			if ($conf["wrap"]) {
				$content=$this->wrap($content, $conf["wrap"]);
			}
			if ($conf["stdWrap."]) {
				$content=$this->stdWrap($content, $conf["stdWrap."]);
			}
				// returning
			$GLOBALS["TSFE"]->set_no_cache();
			return $content;
		}
	}
	function PHP_SCRIPT($conf,$ext="")	{
		$incFile = $GLOBALS["TSFE"]->tmpl->getFileName($conf["file"]);
		$content="";
		if ($incFile && (!$GLOBALS["TYPO3_CONF_VARS"]["FE"]["noPHPscriptInclude"] || substr($incFile,0,14)=="media/scripts/"))	{
			switch($ext)	{
				case "INT":
				case "EXT":
					$substKey = $ext."_SCRIPT.".$GLOBALS["TSFE"]->uniqueHash();
					$content.="<!--".$substKey."-->";
					$GLOBALS["TSFE"]->config[$ext."incScript"][$substKey] = array(
						"file"=>$incFile,
						"conf"=>$conf,
						"type"=>"SCRIPT"
					);
					if ($ext=="INT")	{
						$GLOBALS["TSFE"]->config[$ext."incScript"][$substKey]["cObj"] = serialize($this);
					} else {
						$GLOBALS["TSFE"]->config[$ext."incScript"][$substKey]["data"] = $this->data;
					}
				break;
				default:
						// Added 31-12-00: Make backup...
					$this->oldData = $this->data;
						// Include file..
					include($incFile);
						// Added 31-12-00: restore...
					if ($RESTORE_OLD_DATA)	{
						$this->data = $this->oldData;
					}
				break;
			}
		}
		return $content;
	}
	function TEMPLATE($conf)	{
		$subparts = Array();
		$marks = Array();
		$wraps = Array();
		$content="";
		
		list($PRE,$POST) = explode("|",$conf["markerWrap"] ? $conf["markerWrap"] : "### | ###");
		$POST = trim($POST);
		$PRE  = trim($PRE);
		
			// Getting the content
		$content = $this->cObjGetSingle($conf["template"],$conf["template."],"template");
		if ($conf["workOnSubpart"])	{
			$content = $this->getSubpart($content, $PRE.$conf["workOnSubpart"].$POST);
		}
		if ($content)	{
				// Getting subparts. 
			if (is_array($conf["subparts."]))	{
				reset($conf["subparts."]);
				while(list($theKey,$theValue)=each($conf["subparts."]))	{
					if (!strstr($theKey,"."))	{
						$subpart = $this->getSubpart($content, $PRE.$theKey.$POST);
						if ($subpart)	{
							$GLOBALS["TSFE"]->register["SUBPART_".$theKey] = $subpart;
							$subparts[$theKey]["name"] = $theValue;
							$subparts[$theKey]["conf"] = $conf["subparts."][$theKey."."];
						}
					}
				}
			}
				// Getting marks
			if (is_array($conf["marks."]))	{
				reset($conf["marks."]);
				while(list($theKey,$theValue)=each($conf["marks."]))	{
					if (!strstr($theKey,"."))	{
						$marks[$theKey]["name"] = $theValue;
						$marks[$theKey]["conf"] = $conf["marks."][$theKey."."];
					}
				}
			}
				// Getting subpart wraps
			if (is_array($conf["wraps."]))	{
				reset($conf["wraps."]);
				while(list($theKey,$theValue)=each($conf["wraps."]))	{
					if (!strstr($theKey,"."))	{
						$wraps[$theKey]["name"] = $theValue;
						$wraps[$theKey]["conf"] = $conf["wraps."][$theKey."."];
					}
				}
			}
				// Getting subparts
			$subpartArray =array();
			reset($subparts);
			while(list($theKey,$theValue)=each($subparts))	{
					// Set current with the content of the subpart...
				$this->data[$this->currentValKey] = $GLOBALS["TSFE"]->register["SUBPART_".$theKey];
					// Get subpart cObject and substitute it!
				$subpartArray[$PRE.$theKey.$POST] = $this->cObjGetSingle($theValue["name"],$theValue["conf"],"subparts.".$theKey);
			}	
			$this->data[$this->currentValKey] = "";	// Reset current to empty
			
				// Getting marks
			$markerArray =array();
			reset($marks);
			while(list($theKey,$theValue)=each($marks))	{
				$markerArray[$PRE.$theKey.$POST] = $this->cObjGetSingle($theValue["name"],$theValue["conf"],"marks.".$theKey);
			}
				// Getting wraps
			$subpartWraps =array();
			reset($wraps);
			while(list($theKey,$theValue)=each($wraps))	{
				$subpartWraps[$PRE.$theKey.$POST] = explode("|",$this->cObjGetSingle($theValue["name"],$theValue["conf"],"wraps.".$theKey));
			}

				// Substitution
			$content = $this->substituteMarkerArrayCached($content,$markerArray,$subpartArray,$subpartWraps);
		}
		return $content;
	}
	function MULTIMEDIA($conf)	{
		$content="";
		$filename=$this->stdWrap($conf["file"],$conf["file."]);
		$incFile = $GLOBALS["TSFE"]->tmpl->getFileName($filename);
		if ($incFile)	{
			$fileinfo = t3lib_div::split_fileref($incFile);
			if (t3lib_div::inList("txt,html,htm",$fileinfo["fileext"]))	{
				$content = $GLOBALS["TSFE"]->tmpl->fileContent($incFile);
			} else {
					// default params...
				$parArray=array();
					// src is added
				$parArray["src"]='src="'.$GLOBALS["TSFE"]->absRefPrefix.$incFile.'"';
				if (t3lib_div::inList("au,wav,mp3",$fileinfo["fileext"]))	{
//					$parArray["width"] = 'width="200"';
//					$parArray["height"] = 'height="16"';
				}
				if (t3lib_div::inList("avi,mov,mpg,asf,wmv",$fileinfo["fileext"]))	{
					$parArray["width"] = 'width="200"';
					$parArray["height"] = 'height="200"';
//					$parArray["autostart"] = 'autostart="0"';		// Changed 27-11-2000
				}
				if (t3lib_div::inList("swf,swa,dcr",$fileinfo["fileext"]))	{
					$parArray["quality"] = 'quality="high"';
				}
				if (t3lib_div::inList("class",$fileinfo["fileext"]))	{
					$parArray["width"] = 'width="200"';
					$parArray["height"] = 'height="200"';
				}
	
					// fetching params
				$lines = explode(chr(10), $this->stdWrap($conf["params"],$conf["params."]));
				while(list(,$l)=each($lines))	{
					$parts = explode("=", $l);
					$parameter = strtolower(trim($parts[0]));
					$value = trim($parts[1]);
					if ((string)$value!="")	{
						$parArray[$parameter] = $parameter.'="'.$value.'"';
					} else {
						unset($parArray[$parameter]);
					}
				}
				if ($fileinfo["fileext"]=="class")	{
					unset($parArray["src"]);
					$parArray["code"] = 'code="'.$fileinfo["file"].'"';
					$parArray["codebase"] = 'codebase="'.$fileinfo["path"].'"';
					$content='<applet '.implode($parArray," ").'></applet>';
				} else {
					$content='<embed '.implode($parArray," ").'></embed>';
				}
			}
		}
		return $content;
	}	

// *******************'
// Sub-functions:
// *******************'
	function netprintApplication_offsiteLinkWrap($str,$imgConf,$conf)	{
		if ($conf["url"] && @is_file($imgConf["origFile"]))	{
			$thisUrl = $conf["thisUrl"] ? $conf["thisUrl"] : "http://".t3lib_div::getThisUrl();
			$origFile=$thisUrl.$imgConf["origFile"];
				// Original file dimensions:
			$gifCreator = t3lib_div::makeInstance("tslib_gifbuilder");
			$gifCreator->init();
			$origDim = $gifCreator->getImageDimensions($imgConf["origFile"]);
			if (!$conf["linkOnlyPixelsAbove"] || $origDim[0]*$origDim[1]>$conf["linkOnlyPixelsAbove"])	{
	//			debug($origDim);
					// Set parameters
				$thumbFile=$thisUrl.$imgConf["3"]."|".$imgConf[0]."x".$imgConf[1]."|".$origDim[0]."x".$origDim[1]."|".filesize($imgConf["origFile"])."|".filemtime($imgConf["origFile"]);
					// Set url:
				$url = $conf["url"]
					."&NP[offsite][1]=".rawurlencode($origFile)
					."&NP[offsite_thumb][1]=".rawurlencode($thumbFile);
				$linkCObject = $this->cObjGetSingle($conf["cObject"],$conf["cObject."]);
				if ($linkCObject)	{
					$ATagParams = trim($conf["ATagParams"]) ? " ".trim($conf["ATagParams"]) : "";
					$linkCObject='<a href="'.$url.'"'.$ATagParams.'>'.$linkCObject.'</a>';
					$linkCObject=$this->stdWrap($linkCObject,$conf["outerStdWrap."]);
					if ($conf["before"])	{
						$str=$linkCObject.$str;
					} else {
						$str=$str.$linkCObject;
					}
				}
			}
		}
		return $str;
	}
	function getFieldDefaultValue($noValueInsert, $fieldName, $defaultVal) {
			// If noValueInsert OR if the no_cache flag for this page is NOT set, the original default value is returned. Page CANNOT be cached because that would include the inserted value for the current user.
		if (!$GLOBALS["TSFE"]->no_cache || (!isset($GLOBALS["HTTP_POST_VARS"][$fieldName]) && !isset($GLOBALS["HTTP_GET_VARS"][$fieldName])) || $noValueInsert)	{
			return $defaultVal;
		} else {
			return t3lib_div::GPvar($fieldName);
		}
	}
	function processParams($params)	{
		$paramArr=array();
		$lines=explode(chr(10),$params);
		while(list(,$val)=each($lines))	{
			$val = trim($val);
			if ($val)	{
				$pair = explode("=",$val,2);
				if (!t3lib_div::inList("#,/",substr(trim($pair[0]),0,1)))	{
					$paramArr[trim($pair[0])] = trim($pair[1]);
				}
			}
		}
		return $paramArr;
	}
	function lastChanged($tstamp)	{
		$tstamp = intval($tstamp);
		if ($tstamp>intval($GLOBALS["TSFE"]->register["SYS_LASTCHANGED"]))	{
			$GLOBALS["TSFE"]->register["SYS_LASTCHANGED"] = $tstamp;
		}
	}
	function getSubpart($content, $marker)	{
		if ($marker && strstr($content,$marker))	{
			$start = strpos($content, $marker)+strlen($marker);
			$stop = @strpos($content, $marker, $start+1);
			$sub = substr($content, $start, $stop-$start);
	
			$reg=Array();		
			ereg("^[^<]*-->",$sub,$reg);
			$start+=strlen($reg[0]);
			
			$reg=Array();		
			ereg("<!--[^>]*$",$sub,$reg);
			$stop-=strlen($reg[0]);
			
			return substr($content, $start, $stop-$start);
		}
	}
	function substituteSubpart($content,$marker,$subpartContent,$recursive=1)	{
			// This function substitutes a subpart in $content with the content of $subpartContent.
			// If $recursive is set, the function calls itself with the content set to the remaining part of the content after the second marker. This means that proceding subparts are ALSO substituted!
			// If $subpartContent happens to be an array, it's [0] and [1] elements are wrapped around the content of the subpart (fetched by getSubpart())
		$start = strpos($content, $marker);
		$stop = @strpos($content, $marker, $start+1)+strlen($marker);
		if ($start && $stop>$start)	{
				// code before
			$before = substr($content, 0, $start);
			$reg=Array();		
			ereg("<!--[^>]*$",$before,$reg);
			$start-=strlen($reg[0]);
			$before = substr($content, 0, $start);
				// code after
			$after = substr($content, $stop);
			$reg=Array();		
			ereg("^[^<]*-->",$after,$reg);
			$stop+=strlen($reg[0]);
			$after = substr($content, $stop);
				// replace?
			if (is_array($subpartContent))	{
				$substContent=$subpartContent[0].$this->getSubpart($content,$marker).$subpartContent[1];
			} else {
				$substContent=$subpartContent;
			}
	
			if ($recursive && strpos($after, $marker))	{
				return $before.$substContent.$this->substituteSubpart($after,$marker,$subpartContent);
			} else {
				return $before.$substContent.$after;
			}
		} else {
			return $content;
		}
	}
	function substituteMarker($content,$marker,$markContent)	{
		return str_replace($marker,$markContent,$content);
	}

	/**
	 * Multi substitution function with caching. 
	 *
	 * This function should be a one-stop substitution function for working with HTML-template. It does not substitute by str_replace but by splitting. This secures that the value inserted does not themselves contain markers or subparts.
	 * This function takes three kinds of substitutions in one: 
	 * $markContentArray is a regular marker-array where the "keys" are substituted in $content with their values
	 * $subpartContentArray works exactly like markContentArray only is whole subparts substituted and not only a single marker. 
	 * $wrappedSubpartContentArray is an array of arrays with 0/1 keys where the subparts pointed to by the main key is wrapped with the 0/1 value alternating.
	 */
	function substituteMarkerArrayCached($content,$markContentArray=array(),$subpartContentArray=array(),$wrappedSubpartContentArray=array())	{
		$GLOBALS["TT"]->push("/substituteMarkerArray/");

			// If not arrays then set them
		if (!is_array($markContentArray))	$markContentArray=array();	// Plain markers
		if (!is_array($subpartContentArray))	$subpartContentArray=array();	// Subparts being directly substituted
		if (!is_array($wrappedSubpartContentArray))	$wrappedSubpartContentArray=array();	// Subparts being wrapped
			// Finding keys and check hash:
		$sPkeys = array_keys($subpartContentArray);
		$wPkeys = array_keys($wrappedSubpartContentArray);
		$aKeys = array_merge(array_keys($markContentArray),$sPkeys,$wPkeys);
		if (!count($aKeys))	{return $content;}
		asort($aKeys);
		$storeKey = md5("substituteMarkerArrayCached_storeKey:".serialize(array($content,$aKeys)));
		if ($this->substMarkerCache[$storeKey])	{
			$storeArr = $this->substMarkerCache[$storeKey];
			$GLOBALS["TT"]->setTSlogMessage("Cached",0);
		} else {
			$storeArrDat = $GLOBALS["TSFE"]->sys_page->getHash($storeKey,0);
			if (!isset($storeArrDat))	{
					// Initialize storeArr
				$storeArr=array();
		
					// Finding subparts and substituting them with the subpart as a marker
				reset($sPkeys);
				while(list(,$sPK)=each($sPkeys))	{
					$content =$this->substituteSubpart($content,$sPK,$sPK);
				}
				
					// Finding subparts and wrapping them with markers
				reset($wPkeys);
				while(list(,$wPK)=each($wPkeys))	{
					$content =$this->substituteSubpart($content,$wPK,array($wPK,$wPK));
				}
				
					// traverse keys and quote them for reg ex.
				reset($aKeys);
				while(list($tK,$tV)=each($aKeys))	{
					$aKeys[$tK]=quotemeta($tV);
				}
				$regex = implode("|",$aKeys);
					// Doing regex's
				$storeArr["c"] = split($regex,$content);
				preg_match_all("/".$regex."/",$content,$keyList);
				$storeArr["k"]=$keyList[0];
					// Setting cache:
				$this->substMarkerCache[$storeKey] = $storeArr;
	
					// Storing the cached data:
				$GLOBALS["TSFE"]->sys_page->storeHash($storeKey, serialize($storeArr), "substMarkArrayCached");
				
				$GLOBALS["TT"]->setTSlogMessage("Parsing",0);
			} else {
					// Unserializing
				$storeArr = unserialize($storeArrDat);
					// Setting cache:
				$this->substMarkerCache[$storeKey] = $storeArr;
				$GLOBALS["TT"]->setTSlogMessage("Cached from DB",0);
			}
		}

			// Substitution/Merging: 
			// Merging content types together, resetting
		$valueArr = array_merge($markContentArray,$subpartContentArray,$wrappedSubpartContentArray);
		$wSCA_reg=array();
		reset($storeArr["k"]);
		$content = "";
			// traversin the keyList array and merging the static and dynamic content
		while(list($n,$keyN)=each($storeArr["k"]))	{
			$content.=$storeArr["c"][$n];
			if (!is_array($valueArr[$keyN]))	{
				$content.=$valueArr[$keyN];
			} else {
				$content.=$valueArr[$keyN][(intval($wSCA_reg[$keyN])%2)];
				$wSCA_reg[$keyN]++;
			}
		}
		$content.=$storeArr["c"][count($storeArr["k"])];
		
		$GLOBALS["TT"]->pull();
		return $content;
	}
	function substituteMarkerArray($content,$markContentArray)	{
		if (is_array($markContentArray))	{
			reset($markContentArray);
			while(list($marker,$markContent)=each($markContentArray))	{
				$content=str_replace($marker,$markContent,$content);
			}
		}
		return $content;
	}
	function substituteMarkerInObject (&$tree, $markContentArray) {
		if (is_array ($tree))	{
			reset($tree);
			while(list($key,$value)=each($tree))	{
				$this->substituteMarkerInObject ($tree[$key], $markContentArray);
			}
		} else {
			$tree = $this->substituteMarkerArray($tree,$markContentArray);
		}
		return $tree;
	}
	function fillInMarkerArray($markContentArray, $row, $fieldList="", $nl2br=1, $prefix="FIELD_")	{
		if ($fieldList)	{
			$fArr=t3lib_div::trimExplode(",",$fieldList,1);
			reset($fArr);
			while(list(,$field)=each($fArr))	{
				$markContentArray["###".$prefix.$field."###"] = $nl2br?nl2br($row[$field]):$row[$field];
			}
		} else {
			if (is_array($row))	{
				reset($row);
				while(list($field,)=each($row))	{
					if (!t3lib_div::testInt($field))	{		$markContentArray["###".$prefix.$field."###"] = $nl2br?nl2br($row[$field]):$row[$field];	}
				}
			}
		}
		return $markContentArray;
	}
	function cImage($file,$conf) {
		$info = $this->getImgResource($file,$conf["file."]);
		$GLOBALS["TSFE"]->lastImageInfo=$info;
		if (is_array($info))	{
			$info[3] = t3lib_div::png_to_gif_by_imagemagick($info[3]);
			$GLOBALS["TSFE"]->imagesOnPage[]=$info[3];		// This array is used to collect the image-refs on the page...
			$alttext = strip_tags($this->stdWrap($conf["alttext"],$conf["alttext."]));
			$theValue = '<img src="'.$GLOBALS["TSFE"]->absRefPrefix.$info[3].'" width="'.$info[0].'" height="'.$info[1].'"  border="0"'.($conf["params"]?" ".$conf["params"]:"").($alttext?' alt="'.$alttext.'"':'').'>';
			if ($conf["linkWrap"])	{
				$theValue = $this->linkWrap($theValue,$conf["linkWrap"]);
			} elseif ($conf["imageLinkWrap"]) {
				$theValue = $this->imageLinkWrap($theValue,$info["origFile"],$conf["imageLinkWrap."]);
			}
			return $this->wrap($theValue,$conf["wrap"]);
		}
	}
	function imageLinkWrap ($string,$imageFile,$conf) {
		$a1="";
		$a2="";
		$content=$string;
		if ($this->stdWrap($conf["enable"],$conf["enable."]))	{
			$content=$this->typolink($string, $conf["typolink."]);
				// imageFileLink:
			if ($content==$string && @is_file($imageFile)) {
				$params = '';
				if ($conf["width"]) {$params.='&width='.rawurlencode($conf["width"]);}
				if ($conf["height"]) {$params.='&height='.rawurlencode($conf["height"]);}
				if ($conf["effects"]) {$params.='&effects='.rawurlencode($conf["effects"]);}
				if ($conf["sample"]) {$params.='&sample=1';}
				if ($conf["alternativeTempPath"]) {$params.='&alternativeTempPath='.rawurlencode($conf["alternativeTempPath"]);}
	
				if ($conf["bodyTag"]) {$params.='&bodyTag='.rawurlencode($conf["bodyTag"]);}
				if ($conf["title"]) {$params.='&title='.rawurlencode($conf["title"]);}
				if ($conf["wrap"]) {$params.='&wrap='.rawurlencode($conf["wrap"]);}
				
				$md5_value = md5($imageFile."|".$conf["width"]."|".$conf["height"]."|".$conf["effects"]."|");
				
				$params.= "&md5=".$md5_value;
				$url = $GLOBALS["TSFE"]->absRefPrefix.'showpic.php?file='.rawurlencode($imageFile).$params;
				if ($conf["JSwindow."]["altUrl"] || $conf["JSwindow."]["altUrl."])	{
					$altUrl = $this->stdWrap($conf["JSwindow."]["altUrl"], $conf["JSwindow."]["altUrl."]);
					if ($altUrl)	{
						$url=$altUrl;
					}
				}
				
				if ($conf["JSwindow"])	{
					$gifCreator = t3lib_div::makeInstance("tslib_gifbuilder");
					$gifCreator->init();
					$gifCreator->mayScaleUp = 0;
					$dims = $gifCreator->getImageScale($gifCreator->getImageDimensions($imageFile),$conf["width"],$conf["height"],"");
					$offset = t3lib_div::intExplode(",",$conf["JSwindow."]["expand"].",");
					
					$a1='<a href="#" onClick="openPic(\''.$url.'\',\''.($conf["JSwindow."]["newWindow"]?md5($url):'thePicture').'\',\'width='.($dims[0]+$offset[0]).',height='.($dims[1]+$offset[1]).',status=0,menubar=0\'); return false;"'.$GLOBALS["TSFE"]->ATagParams.'>';
					$a2='</a>';
					$GLOBALS["TSFE"]->setJS("openPic");
				} else {
					$target = ' target="thePicture"';
					if (isset($conf["target"])) {
						$target= ($conf["target"]) ? ' target="'.$conf["target"].'"' : '';
					}
					$a1='<a href="'.$url.'"'.$target.$GLOBALS["TSFE"]->ATagParams.'>';
					$a2='</a>';
				}
				$content=$a1.$string.$a2;
			}
		}
		
		return $content;
	}
	function listNum($content,$listNum,$char) {
		$char = $char ? $char : ",";
		if (t3lib_div::testInt($char))	{
			$char = chr($char);
		}
		$temp = explode($char,$content);
		$last = "".(count($temp)-1);
		$index=$this->calc(eregi_replace("last",$last,$listNum));
		return $temp[$index];
	}
	function numRows($conf)	{
		$query = $this->getQuery($conf["table"],$conf["select."]);
		$query = str_replace("SELECT *","SELECT count(*)",$query);
		$res = @mysql(TYPO3_db,$query);
		if ($error = mysql_error())	{
			$GLOBALS["TT"]->setTSlogMessage($error.":   ".$query,3);
		} else {
			$row=mysql_fetch_row($res);
			return intval($row[0]);
		}
	}
	function stdWrap($content,$conf)	{
			// It $this->alternativeData is an array it's used instead of the $this->data array in ->getData
		if (is_array($conf))	{
			if ($conf["setContentToCurrent"]){$this->data[$this->currentValKey]=$content;}
			if ($conf["setCurrent"] || $conf["setCurrent."]){$this->data[$this->currentValKey] = $this->stdWrap($conf["setCurrent"], $conf["setCurrent."]);}
			if (isset($conf["lang."]) && isset($conf["lang."][$GLOBALS["TSFE"]->config["config"]["language"]]))	{$content = $conf["lang."][$GLOBALS["TSFE"]->config["config"]["language"]];}
			if ($conf["data"]){$content=$this->getData($conf["data"], is_array($this->alternativeData)?$this->alternativeData:$this->data);}
				$this->alternativeData="";		// This must be unset directly after 
			if ($conf["field"]) {$content=$this->getFieldVal($conf["field"]);}
			if ($conf["current"]) {$content=$this->data[$this->currentValKey];}
			if ($conf["cObject"]) {$content=$this->cObjGetSingle($conf["cObject"],$conf["cObject."],"/stdWrap/.cObject");}
			if ($conf["numRows."]) {$content=$this->numRows($conf["numRows."]);}
			if ($conf["filelist"] || $conf["filelist."])	{$content=$this->filelist($this->stdWrap($conf["filelist"], $conf["filelist."]));}
			if ($conf["preUserFunc"])	{$content = $this->callUserFunction($conf["preUserFunc"], $conf["preUserFunc."], $content);}
			
			if ($conf["override"] || $conf["override."]){ 
				$override = $this->stdWrap($conf["override"], $conf["override."]);
				if (trim($override)) {$content=$override;}
			}
			if (isset($conf["preIfEmptyListNum"]) || isset($conf["preIfEmptyListNum."]["stdWrap."])) {
				$preIfEmptyListNumber = isset($conf["preIfEmptyListNum."]["stdWrap."])  ?  $this->stdWrap($conf["preIfEmptyListNum"], $conf["preIfEmptyListNum."]["stdWrap."])  :  $conf["preIfEmptyListNum"];
				$content=$this->listNum($content,$preIfEmptyListNumber,$conf["preIfEmptyListNum."]["splitChar"]);
			}
			if (!trim($content) && ($conf["ifEmpty"] || $conf["ifEmpty."])){ $content = $this->stdWrap($conf["ifEmpty"], $conf["ifEmpty."]);}
			

				// values...
			if (isset($conf["listNum"]) || isset($conf["listNum."]["stdWrap."])) {
				$listNumber = isset($conf["listNum."]["stdWrap."])  ?  $this->stdWrap($conf["listNum"], $conf["listNum."]["stdWrap."])  :  $conf["listNum"];
				$content=$this->listNum($content,$listNumber,$conf["listNum."]["splitChar"]);
			}
			
			if ($conf["trim"]){$content=trim($content);}
			if (   ($conf["required"] && (string)$content=="") || ($conf["if."] && !$this->checkIf($conf["if."])) || ($conf["fieldRequired"] && !trim($this->data[$conf["fieldRequired"]]))    ){
				$content = "";
			} else {
				if ($conf["parseFunc."]) {$content=$this->parseFunc($content,$conf["parseFunc."]);}
				if ($conf["HTMLparser"] && is_array($conf["HTMLparser."])) {$content=$this->HTMLparser_TSbridge($content,$conf["HTMLparser."]);}
				if ($conf["split."]){$content=$this->splitObj($content,$conf["split."]);}
				if ($conf["prioriCalc"]){$content=t3lib_div::calcParenthesis($content); if ($conf["prioriCalc"]=="intval") $content=intval($content);}
				if ((string)$conf["char"]!=""){$content=chr(intval($conf["char"]));}
				if ($conf["intval"]){$content=intval($content);}
				if ($conf["date"]){$content=date($conf["date"], $content);}
				if ($conf["strftime"]){$content=strftime($conf["strftime"], $content);}
				if ($conf["age"]){$content=$this->calcAge(time()-$content,$conf["age"]);}
				
				if ($conf["case"]){$content=$this->HTMLcaseshift($content, $conf["case"]);}
				if ($conf["bytes"]){$content=$this->bytes($content);}
				if ($conf["substring"]){$content=$this->substring($content,$conf["substring"]);}
				if ($conf["crop"]){$content=$this->crop($content, $conf["crop"]);}
				if ($conf["stripHtml"]){$content=strip_tags($content);}
				if ($conf["htmlSpecialChars"]){$content=htmlSpecialChars($content);}
	
				if ($conf["doubleBrTag"]) {
					$content=ereg_replace("\r?\n[\t ]*\r?\n",$conf["doubleBrTag"],$content);
				}				
				if ($conf["br"]) {$content=nl2br($content);}
				if ($conf["brTag"]) {$content= ereg_replace(chr(10),$conf["brTag"],$content);}
				if ($conf["encapsLines."]) {$content=$this->encaps_lineSplit($content,$conf["encapsLines."]);}
				if ($conf["keywords"]) {$content= $this->keywords($content);}
				if ($conf["innerWrap"] || $conf["innerWrap."]){$content=$this->wrap($content, $this->stdWrap($conf["innerWrap"], $conf["innerWrap."]));}
				if ($conf["innerWrap2"] || $conf["innerWrap2."]){$content=$this->wrap($content, $this->stdWrap($conf["innerWrap2"], $conf["innerWrap2."]));}
				if ($conf["fontTag"]){$content=$this->wrap($content, $conf["fontTag"]);}
				if ($conf["addParams."]) {$content=$this->addParams($content,$conf["addParams."]);}
				if ($conf["textStyle."]) {$content=$this->textStyle($content,$conf["textStyle."]);}
				if ($conf["tableStyle."]) {$content=$this->tableStyle($content,$conf["tableStyle."]);}
				if ($conf["filelink."]) {$content=$this->filelink($content,$conf["filelink."]);}
				if ($conf["preCObject"]) {$content=$this->cObjGetSingle($conf["preCObject"],$conf["preCObject."],"/stdWrap/.preCObject").$content;}
				if ($conf["postCObject"]) {$content.=$this->cObjGetSingle($conf["postCObject"],$conf["postCObject."],"/stdWrap/.postCObject");}

				if ($conf["wrapAlign"] || $conf["wrapAlign."]){
					$wrapAlign = trim($this->stdWrap($conf["wrapAlign"], $conf["wrapAlign."]));
					if ($wrapAlign)	{$content=$this->wrap($content, '<DIV align="'.$wrapAlign.'">|</div>');}
				}
				if ($conf["typolink."]){$content=$this->typolink($content, $conf["typolink."]);}

					// Spacing			
				if ($conf["space"]){$content=$this->wrapSpace($content, $conf["space"]);}
				$spaceBefore = "";
				if ($conf["spaceBefore"] || $conf["spaceBefore."])	{$spaceBefore = trim($this->stdWrap($conf["spaceBefore"], $conf["spaceBefore."]));}
				$spaceAfter = "";
				if ($conf["spaceAfter"] || $conf["spaceAfter."])	{$spaceAfter = trim($this->stdWrap($conf["spaceAfter"], $conf["spaceAfter."]));}
				if ($spaceBefore || $spaceAfter)	{$content=$this->wrapSpace($content, $spaceBefore."|".$spaceAfter);}

					// Wraps
				if ($conf["wrap"]){$content=$this->wrap($content, $conf["wrap"], ($conf["wrap."]["splitChar"]?$conf["wrap."]["splitChar"]:"|"));}
				if ($conf["noTrimWrap"]){$content=$this->noTrimWrap($content, $conf["noTrimWrap"]);}
				if ($conf["wrap2"]){$content=$this->wrap($content, $conf["wrap2"], ($conf["wrap."]["splitChar"]?$conf["wrap."]["splitChar"]:"|"));}
				if ($conf["dataWrap"]){$content=$this->dataWrap($content, $conf["dataWrap"]);}
				if ($conf["prepend"]){$content.=$this->cObjGetSingle($conf["prepend"],$conf["prepend."],"/stdWrap/.prepend");}
				if ($conf["append"]){$content=$this->cObjGetSingle($conf["append"],$conf["append."],"/stdWrap/.append").$content;}
				if ($conf["wrap3"]){$content=$this->wrap($content, $conf["wrap3"], ($conf["wrap."]["splitChar"]?$conf["wrap."]["splitChar"]:"|"));}
				if ($conf["outerWrap"] || $conf["outerWrap."]){$content=$this->wrap($content, $this->stdWrap($conf["outerWrap"], $conf["outerWrap."]));}
				if ($conf["insertData"])	{$content = $this->insertData($content);}
				if ($conf["offsetWrap"]){	
					$controlTable = t3lib_div::makeInstance("tslib_tableOffset");
					if ($conf["offsetWrap."]["tableParams"] || $conf["offsetWrap."]["tableParams."])	{$controlTable->tableParams = $this->stdWrap($conf["offsetWrap."]["tableParams"], $conf["offsetWrap."]["tableParams."]);}
					if ($conf["offsetWrap."]["tdParams"] || $conf["offsetWrap."]["tdParams."])	{$controlTable->tdParams = " ".$this->stdWrap($conf["offsetWrap."]["tdParams"], $conf["offsetWrap."]["tdParams."]);}
					$content=$controlTable->start($content,$conf["offsetWrap"]);
					if ($conf["offsetWrap."]["stdWrap."])	{	$content=$this->stdWrap($content,$conf["offsetWrap."]["stdWrap."]);	}
				}
				if ($conf["postUserFunc"])	{$content = $this->callUserFunction($conf["postUserFunc"], $conf["postUserFunc."], $content);}

				if ($conf["editIcons"] && $GLOBALS["TSFE"]->beUserLogin){$content=$this->editIcons($content,$conf["editIcons"],$conf["editIcons."]);}
				if ($conf["editPanel"] && $GLOBALS["TSFE"]->beUserLogin){$content=$this->editPanel($content, $conf["editPanel."]);}
			}
			
			//Debug:
			if ($conf["debug"])	{$content = "<PRE>".HTMLSpecialChars($content)."</PRE>";}
			if ($conf["debugFunc"])	{debug($conf["debugFunc"]==2?array($content):$content);}
			if ($conf["debugData"])	{
				echo '<b>$cObj->data:</b>';
				debug($this->data);
				if (is_array($this->alternativeData))	{
					echo '<b>$cObj->alternativeData:</b>';
					debug($this->alternativeData);
				}
			}
		}
		return $content;
	}
	function callUserFunction($funcName,$conf,$content)	{
		$pre = $GLOBALS["TSFE"]->TYPO3_CONF_VARS["FE"]["userFuncClassPrefix"];
		if ($pre && strcmp(substr(trim($funcName),0,strlen($pre)),$pre))	{
			$GLOBALS["TT"]->setTSlogMessage("Function '".$funcName."' was not prepended with '".$pre."'",3);
			return $content;
		}
			// Split parts
		$parts = explode("->",$funcName);
		if (count($parts)==2)	{	// Class
			$cls = t3lib_div::makeInstanceClassName($parts[0]);
			if (class_exists ($cls))	{
				$classObj = new $cls;
				if (method_exists($classObj, $parts[1]))	{
					$classObj->cObj = &$this;
				 	$content = call_user_method($parts[1], $classObj, $content, $conf);
				} else {
					$GLOBALS["TT"]->setTSlogMessage("Method '".$parts[1]."' did not exist in class '".$cls."'",3);
				}
			} else {
				$GLOBALS["TT"]->setTSlogMessage("Class '".$cls."' did not exist",3);
			}
		} else {	// Function
			if (function_exists($funcName))	{
			 	$content = call_user_func($funcName, $content, $conf);
			} else {
				$GLOBALS["TT"]->setTSlogMessage("Function '".$funcName."' did not exist",3);
			}
		}
		return $content;
	}
	function addParams($content,$conf) {
		if (!is_array($conf))	{return $content;}
		$key = 1;
		$parts = explode("<",$content);
		if (intval($conf["_offset"]))	$key = intval($conf["_offset"])<0 ? count($parts)+intval($conf["_offset"]) : intval($conf["_offset"]);
		$subparts=explode(">",$parts[$key]);
		if (trim($subparts[0]))	{
				// Get attributes and name
			$attribs = t3lib_div::get_tag_attributes("<".$subparts[0].">");
			if (!is_array($attribs))	{$attribs=array();}
			list($tagName) = explode(" ",$subparts[0],2);
				// adds/overrides attributes
			reset($conf);
			while(list($pkey,$val)=each($conf))	{
				if (substr($pkey,-1)!="." && substr($pkey,0,1)!="_")	{
					$tmpVal=$this->stdWrap($conf[$pkey],$conf[$pkey."."]);
					if (strcmp($tmpVal,""))	{$attribs[$pkey]=$tmpVal;}
				}
			}
				// Re-assembles the tag and content
			$subparts[0]=trim($tagName." ".t3lib_div::implodeParams($attribs));
			$parts[$key] = implode(">",$subparts);
			$content = implode("<",$parts);
		}
		return $content;
	}
	function checkIf($conf)	{
		if (!is_array($conf))	{return true;}
		if (isset($conf["directReturn"]))	{return $conf["directReturn"] ? 1 : 0;}
		$flag = true;
			if (isset($conf["isTrue"]) || isset($conf["isTrue."]))	{
				$isTrue = trim($this->stdWrap($conf["isTrue"],$conf["isTrue."]));
				if (!$isTrue)	{
					$flag=0;
				}
			}
			if (isset($conf["isFalse"]) || isset($conf["isFalse."]))	{
				$isFalse = trim($this->stdWrap($conf["isFalse"],$conf["isFalse."]));
				if ($isFalse)	{
					$flag=0;
				}
			}
			if (isset($conf["isPositive"]) || isset($conf["isPositive."]))	{
				$number = $this->calc($this->stdWrap($conf["isPositive"],$conf["isPositive."]));
				if ($number<1)	{
					$flag=0;
				}
			}
			if ($flag)	{
				$value = trim($this->stdWrap($conf["value"],$conf["value."]));

				if (isset($conf["isGreaterThan"]) || isset($conf["isGreaterThan."]))	{
					$number = trim($this->stdWrap($conf["isGreaterThan"],$conf["isGreaterThan."]));
					if ($number<=$value)	{
						$flag=0;
					}
				}
				if (isset($conf["isLessThan"]) || isset($conf["isLessThan."]))	{
					$number = trim($this->stdWrap($conf["isLessThan"],$conf["isLessThan."]));
					if ($number>=$value)	{
						$flag=0;
					}
				}
				if (isset($conf["equals"]) || isset($conf["equals."]))	{
					$number = trim($this->stdWrap($conf["equals"],$conf["equals."]));
					if ($number!=$value)	{
						$flag=0;
					}
				}
				if (isset($conf["isInList"]) || isset($conf["isInList."]))	{
					$number = trim($this->stdWrap($conf["isInList"],$conf["isInList."]));
					if (!t3lib_div::inList($value,$number))	{
						$flag=0;
					}
				}
			}
		if ($conf["negate"])	{$flag = $flag ? 0 : 1;}
		return $flag;
	}
	function wrapSpace($content, $wrap)	{
			// This wraps stuff around content
		$result = $content;
		if (trim($wrap))	{
			$wrapArray = explode("|",$wrap);
			$wrapBefore = intval($wrapArray[0]);
			$wrapAfter = intval($wrapArray[1]);
			if ($wrapBefore)	{
				$result = '<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$wrapBefore.' border=0><BR>'.$result;
			}
			if ($wrapAfter)	{
				$result.='<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$wrapAfter.' border=0><BR>';
			}
		}
		return $result;
	}
	function getFieldVal($field)	{
		if (!strstr($field,"//"))	{
			return $this->data[trim($field)];
		} else {
			$sections = t3lib_div::trimExplode("//",$field,1);
			while (list(,$k)=each($sections)) {
				if (strcmp($this->data[$k],""))	return $this->data[$k];
			}
		}
	}
	function getData($string,$fieldArray)	{
		if (!is_array($fieldArray))	{
			$fieldArray=$GLOBALS["TSFE"]->page;
		}
		$retVal = "";
		$sections = explode("//",$string);

		while (!$retVal AND list($secKey, $secVal)=each($sections)) {
			$parts = explode(":",$secVal,2);
			$key = trim($parts[1]);
			if ((string)$key!="")	{
				switch(strtolower(trim($parts[0])))	{
					case "gpvar":
						$retVal= t3lib_div::GPvar($key);
					break;
					case "tsfe":
						$retVal= $GLOBALS["TSFE"]->$key;
					break;
					case "getenv":
						$retVal= getenv($key);
					break;
					case "field":
						$retVal= $fieldArray[$key];
					break;
					case "parameters":
						$retVal= $this->parameters[$key];
					break;
					case "register":
						$retVal= $GLOBALS["TSFE"]->register[$key];
					break;
					case "global":
						$retVal= $this->getGlobal($key);
					break;
					case "leveltitle":
						$nkey = $this->getKey($key,$GLOBALS["TSFE"]->tmpl->rootLine);
						$retVal= $this->rootLineValue($nkey,"title",stristr($key,"slide"));
					break;
					case "levelmedia":
						$nkey = $this->getKey($key,$GLOBALS["TSFE"]->tmpl->rootLine);
						$retVal= $this->rootLineValue($nkey,"media",stristr($key,"slide"));
					break;
					case "leveluid":
						$nkey = $this->getKey($key,$GLOBALS["TSFE"]->tmpl->rootLine);
						$retVal= $this->rootLineValue($nkey,"uid",stristr($key,"slide"));
					break;
					case "fullrootline":
						$keyP=t3lib_div::trimExplode(",",$key);
						$fullKey = intval($keyP[0])-count($GLOBALS["TSFE"]->tmpl->rootLine)+count($GLOBALS["TSFE"]->rootLine);
						if ($fullKey>=0)	{
							$retVal= $this->rootLineValue($fullKey,$keyP[1],stristr($keyP[2],"slide"),$GLOBALS["TSFE"]->rootLine);
						}
					break;
					case "date":
						if (!$key) {$key = "d/m Y";}
						$retVal= Date($key, time());
					break;
					case "page":
						$retVal= $GLOBALS["TSFE"]->page[$key];
					break;
					case "current":
						$retVal= $this->data[$this->currentValKey];
					break;
					case "level":
						$retVal= count($GLOBALS["TSFE"]->tmpl->rootLine)-1;
					break;
					case "db":
						$selectParts = t3lib_div::trimExplode(":",$key);
						$db_rec = $GLOBALS["TSFE"]->sys_page->getRawRecord($selectParts[0],$selectParts[1]);
						if (is_array($db_rec) && $selectParts[2])	{$retVal = $db_rec[$selectParts[2]];}
					break;
				}
			}
		}
		return $retVal;
	}
	function rootLineValue($key,$field,$slideBack=0,$altRootLine="")	{
		$rootLine = is_array($altRootLine) ? $altRootLine : $GLOBALS["TSFE"]->tmpl->rootLine;
		if (!$slideBack)	{
			return $rootLine[$key][$field];
		} else {
			for ($a=$key;$a>=0;$a--)	{
				$val = $rootLine[$a][$field];
				if ($val)	{return $val;}
			}
		}
	}
	function getGlobal($var) {
		$vars = explode("|",$var);
		$c = count($vars);
		$theVar = $GLOBALS[trim($vars[0])];
		for ($a=1;$a<$c;$a++) {
			if (!isset($theVar))	{break;}
			$theVar = $theVar[trim($vars[$a])];
		}
		if (!is_array($theVar))	{
			return $theVar;
		} else {
			return "";
		}
	}		
	function clean_directory($theDir)	{
			// Cleans $theDir for slashes in the end of the string and returns the new path, if it exists on the server.
		if (!strstr($theDir,"//") && !strstr($theDir,"..") && !strstr($theDir,"\\"))	{		// proceeds if no "//", ".." or "\" is in the $theFile
			$theDir = ereg_replace("[\/\. ]*$","",$theDir);		// Removes all dots, slashes and spaces after a path...
			if (substr($theDir,0,1)!="/" && @is_dir($theDir))	{
				return $theDir;
			}
		}
	}
	function filelist($data)	{
		$data = trim($data);
		if ($data)	{
			$data_arr = explode("|",$data);
				// read directory:
			if ($GLOBALS["TSFE"]->lockFilePath)	{		// MUST exist!
				$path = $this->clean_directory($data_arr[0]);	// Cleaning name...
				$path = substr($path,0,strlen($GLOBALS["TSFE"]->lockFilePath))==$GLOBALS["TSFE"]->lockFilePath ? $path : "";
			}
			if($path)	{
				$items = Array("files"=>array(), "sorting"=>array());
				$ext_list = strtolower(t3lib_div::uniqueList($data_arr[1]));
				$sorting = trim($data_arr[2]);
					// read dir:
				$d = @dir($path);
				$tempArray=Array();
				if (is_object($d))	{
					$count=0;
					while($entry=$d->read()) {
						if ($entry!="." && $entry!="..")	{
							$wholePath = $path."/".$entry;		// Because of odd PHP-error where  <BR>-tag is sometimes placed after a filename!!
							if (@file_exists($wholePath) && filetype($wholePath)=="file")	{
								$info = t3lib_div::split_fileref($wholePath);
								if (!$ext_list || t3lib_div::inList($ext_list,$info["fileext"]))	{
									$items["files"][] = $info["file"];
									switch($sorting)	{
										case "name":
											$items["sorting"][] = strtolower($info["file"]);
										break;
										case "size":
											$items["sorting"][] = filesize($wholePath);
										break;
										case "ext":
											$items["sorting"][] = $info["fileext"];
										break;
										case "date":
											$items["sorting"][] = filectime($wholePath);
										break;
										default:
											$items["sorting"][] = $count;
										break;
									}
									$count++;
								}
							}
						}
					}
					$d->close();
				}
					// Sort if required
				if (count($items["sorting"]))	{
					if (strtolower(trim($data_arr[3]))!="r")	{
						asort($items["sorting"]);
					} else {
						arsort($items["sorting"]);
					}
				}
				if (count($items["files"]))	{
						// make list
					reset($items["sorting"]);
					$fullPath = trim($data_arr[4]);
					$list_arr=Array();
					while(list($key,)=each($items["sorting"]))	{
						$list_arr[]=  $fullPath ? $path."/".$items["files"][$key] : $items["files"][$key];
					}
					return implode($list_arr,",");
				}
			}
		}
	}
	function getKey ($key,$arr)	{
		$key = intval($key);
		if (is_array($arr))	{
			if ($key < 0)	{
				$key = count($arr)+$key;	// entrylevel = -1 means that entryLevel ends up pointing at the outermost-level, -2 means the level before the outermost...
			}
			if ($key < 0)	{
				$key=0;
			}		
		}
		return $key;
	}
	function noTrimWrap($content,$wrap)	{
		if ($wrap)	{
			$wrapArr = explode("|", $wrap);
			return $wrapArr[1].$content.$wrapArr[2];
		} else return $content;
	}
	function wrap($content,$wrap,$char="|")	{
		if ($wrap)	{
			$wrapArr = explode($char, $wrap);
			return trim($wrapArr[0]).$content.trim($wrapArr[1]);
		} else return $content;
	}
	function linebreaks($string,$chars,$maxLines=0)	{
		$lines = explode(chr(10),$string);
		$lineArr=Array();
		$c=0;
		while(list(,$paragraph)=each($lines))	{
			$words = explode(" ",$paragraph);
			while(list(,$word)=each($words))	{
				if (strlen($lineArr[$c].$word)>$chars)	{
					$c++;
				}
				if (!$maxLines || $c<$maxLines)	{
					$lineArr[$c].= $word." ";
				}
			}
			$c++;
		}
		return $lineArr;
	}
	function typoLink($linktxt, $conf)	{
		$finalTagParts=array();
		$finalTagParts["aTagParams"] = $GLOBALS["TSFE"]->ATagParams.($conf["ATagParams"]?" ".$conf["ATagParams"]:"");
		
		$link_param = trim($this->stdWrap($conf["parameter"],$conf["parameter."]));
		$sectionMark = trim($this->stdWrap($conf["section"],$conf["section."]));
		$sectionMark = $sectionMark ? "#".$sectionMark : "";
		$initP = '?id='.$GLOBALS["TSFE"]->id.'&type='.$GLOBALS["TSFE"]->type;
		$this->lastTypoLinkUrl="";
		$this->lastTypoLinkTarget = "";
		if ($link_param)	{
			$link_paramA = t3lib_div::trimExplode(" ",$link_param,1);
			$link_param = trim($link_paramA[0]);
			$forceTarget = trim($link_paramA[1]);
			if ($forceTarget=="-")	$forceTarget="";	// The '-' character means 'no target'. Necessary in order to specify a class as third parameter without setting the target!
			$linkClass = trim($link_paramA[2]);
			
				// Internal target:
			$target = isset($conf["target"]) ? $conf["target"] : $GLOBALS["TSFE"]->intTarget;
			if ($conf["target."])	{$target=$this->stdWrap($target, $conf["target."]);}
			if(strstr($link_param,"@"))	{		// mailadr
				$link_param = eregi_replace("^mailto:","",$link_param);
				if ($linktxt=="") $linktxt = $link_param;
				if (!$GLOBALS["TSFE"]->config["config"]["jumpurl_enable"] || $GLOBALS["TSFE"]->config["config"]["jumpurl_mailto_disable"])	{
					$this->lastTypoLinkUrl = 'mailto:'.$link_param;
				} else {
					$this->lastTypoLinkUrl = $GLOBALS["TSFE"]->absRefPrefix.$GLOBALS["TSFE"]->config["mainScript"].$initP.'&jumpurl='.rawurlencode('mailto:'.$link_param).$GLOBALS["TSFE"]->getMethodUrlIdToken;
				}
				$finalTagParts["url"]=$this->lastTypoLinkUrl;
				$finalTagParts["TYPE"]="mailto";
			} else {
				$fileChar=intval(strpos($link_param, "/"));
				$urlChar=intval(strpos($link_param, "."));
				if($urlChar && (strstr($link_param,"//") || !$fileChar || $urlChar<$fileChar))	{	// url (external): If doubleSlash or if a "." comes before a "/".
					$target = isset($conf["extTarget"]) ? $conf["extTarget"] : $GLOBALS["TSFE"]->extTarget;
					if ($conf["extTarget."])	{$target = $this->stdWrap($target, $conf["extTarget."]);}
					if ($forceTarget)	{$target=$forceTarget;}
					if ($linktxt=="") $linktxt = $link_param;
					if (!ereg("^[a-z]*://",trim(strtolower($link_param))))	{$scheme="http://";} else {$scheme="";}
					if ($GLOBALS["TSFE"]->config["config"]["jumpurl_enable"])	{
						$this->lastTypoLinkUrl = $GLOBALS["TSFE"]->absRefPrefix.$GLOBALS["TSFE"]->config["mainScript"].$initP.'&jumpurl='.rawurlencode($scheme.$link_param).$GLOBALS["TSFE"]->getMethodUrlIdToken;
					} else {
						$this->lastTypoLinkUrl = $scheme.$link_param;
					}
					$this->lastTypoLinkTarget = $target;
					$finalTagParts["url"]=$this->lastTypoLinkUrl;
					$finalTagParts["targetParams"]=' target="'.$target.'"';
					$finalTagParts["TYPE"]="url";
				} elseif($fileChar)	{	// file (internal)
					$splitLinkParam = explode("?",$link_param);
					if (@file_exists($splitLinkParam[0]))	{
						if ($linktxt=="") $linktxt = $link_param;
						if ($GLOBALS["TSFE"]->config["config"]["jumpurl_enable"])	{
							$this->lastTypoLinkUrl = $GLOBALS["TSFE"]->absRefPrefix.$GLOBALS["TSFE"]->config["mainScript"].$initP.'&jumpurl='.rawurlencode($link_param).$GLOBALS["TSFE"]->getMethodUrlIdToken;
						} else {
							$this->lastTypoLinkUrl = $GLOBALS["TSFE"]->absRefPrefix.$link_param;
						}
						if ($forceTarget)	{$target=$forceTarget;}
						$this->lastTypoLinkTarget = $target;

						$finalTagParts["url"]=$this->lastTypoLinkUrl;
						$finalTagParts["targetParams"]=' target="'.$target.'"';
						$finalTagParts["TYPE"]="file";
					} else {
						$GLOBALS["TT"]->setTSlogMessage("typolink(): File '".$splitLinkParam[0]."' did not exist, so '".$linktxt."' was not linked.",1);
						return $linktxt;
					}
	 			} else {	// integer or alias (alias is without slashes or periods or commas, that is "nospace,alphanum_x,lower,unique" according to tables.php!!)
					if ($conf["no_cache."])	$conf["no_cache"]=$this->stdWrap($conf["no_cache"], $conf["no_cache."]);
					$link_params_parts=explode("#",$link_param);
					$link_param = trim($link_params_parts[0]);		// Link-data del
					if (!strcmp($link_param,""))	{$link_param=$GLOBALS["TSFE"]->id;}	// If no id or alias is given
					if ($link_params_parts[1] && !$sectionMark)	{
						$sectionMark="#".trim($link_params_parts[1]);
					}
						// Splitting the parameter by "," and if the array counts more than 1 element it's a id/type/? pair
					unset($theTypeP);
					$pairParts = t3lib_div::trimExplode(",",$link_param);
					if (count($pairParts)>1)	{
						$link_param = $pairParts[0];
						$theTypeP = $pairParts[1];		// Overruling "type"
			//			debug($pairParts);
					}
						// Checking if the id-parameter is an alias.
					if (!t3lib_div::testInt($link_param))	{
						$link_param = $GLOBALS["TSFE"]->sys_page->getPageIdFromAlias($link_param);
					}
					$page = $GLOBALS["TSFE"]->sys_page->getPage($link_param);
					if ($page)	{
							// This checks if the linked id is in the rootline of this site.
						$tCR_domain="";
						if ($GLOBALS["TSFE"]->config["config"]["typolinkCheckRootline"])	{
							$tCR_rootline=$GLOBALS["TSFE"]->sys_page->getRootLine ($page["uid"]);	// Gets rootline of linked-to page
							$tCR_flag=0;
							reset($tCR_rootline);
							while(list(,$tCR_data)=each($tCR_rootline))	{
									if ($tCR_data["uid"]==$GLOBALS["TSFE"]->tmpl->rootLine[0]["uid"])	{
										$tCR_flag = 1;	// OK, it was in rootline!
										break;
									}
							}
							if (!$tCR_flag)	{
								reset($tCR_rootline);
								while(list(,$tCR_data)=each($tCR_rootline))	{
									$query = "SELECT * FROM sys_domain WHERE pid=".$tCR_data["uid"]." AND redirectTo=''".$this->enableFields("sys_domain")." ORDER BY sorting";
									$res = mysql (TYPO3_db, $query);
									echo mysql_error();
									if ($row=mysql_fetch_assoc($res))	{
										$tCR_domain=ereg_replace("\/$","",$row["domainName"]);
										break;
									}
								}
							}
						}
						$addQueryParams = trim($this->stdWrap($conf["additionalParams"],$conf["additionalParams."]));
						if (substr($addQueryParams,0,1)!="&")		{
							$addQueryParams="";
						} elseif ($conf["useCacheHash"]) {	// cache hashing:
							$params = explode("&",substr($addQueryParams,1));	// Splitting parameters up
							$pA=array();
							while(list(,$theP)=each($params))	{
								$pKV = explode("=",$theP);	// SPlitting single param by "=" sign
								$pA[$pKV[0]]=(string)rawurldecode($pKV[1]);
							}
							$pA["encryptionKey"]=$GLOBALS["TSFE"]->TYPO3_CONF_VARS["SYS"]["encryptionKey"];
							ksort($pA);
							$addQueryParams.="&cHash=".t3lib_div::shortMD5(serialize($pA));
						}	

						if ($linktxt=="") $linktxt = $page["title"];
						if ($tCR_domain)	{		// If other domain, overwrite 
							$target = isset($conf["extTarget"]) ? $conf["extTarget"] : $GLOBALS["TSFE"]->extTarget;
							if ($conf["extTarget."])	{$target = $this->stdWrap($target, $conf["extTarget."]);}
							if ($forceTarget)	{$target=$forceTarget;}
							$LD["target"] = $target;
							$this->lastTypoLinkUrl = $this->URLqMark("http://".$tCR_domain."/?id=".$page["uid"],$addQueryParams).$sectionMark;
						} else {	// Internal link:
							if ($forceTarget)	{$target=$forceTarget;}
							$LD=$GLOBALS["TSFE"]->tmpl->linkData($page,$target,$conf["no_cache"],"","","",$theTypeP);
							$this->lastTypoLinkUrl = $this->URLqMark($LD["totalURL"],$addQueryParams).$sectionMark;
						}

						$this->lastTypoLinkTarget = $LD["target"];
						$targetPart = $LD["target"] ? ' target="'.$LD["target"].'"' : '';

							// If sectionMark is set AND the current page is the page the link is to, check if there are any additional parameters and is not, drop the url.
						if ($sectionMark && $page["uid"]==$GLOBALS["TSFE"]->id)	{
							list(,$URLparams) = explode("?",$this->lastTypoLinkUrl);
							list($URLparams) = explode("#",$URLparams);
							parse_str ($URLparams.$LD["orig_type"], $URLparamsArray); 
							if (intval($URLparamsArray["type"])==$GLOBALS["TSFE"]->type)	{	// type nums must match as well as page ids
								unset($URLparamsArray["id"]);
								unset($URLparamsArray["type"]);
								if (!count($URLparamsArray))	{	// If there are no parameters left.... set the new url.
									$this->lastTypoLinkUrl = $sectionMark;
								}
							}
						}
							// Rendering the tag.
						$finalTagParts["url"]=$this->lastTypoLinkUrl;
						$finalTagParts["targetParams"]=$targetPart;
						$finalTagParts["TYPE"]="page";
					} else {
						$GLOBALS["TT"]->setTSlogMessage("typolink(): Page id '".$link_param."' was not found, so '".$linktxt."' was not linked.",1);
						return $linktxt;
					}
				}		
			}
			
			$res = '<A HREF="'.$finalTagParts["url"].'"'.$finalTagParts["targetParams"].($linkClass?' class="'.$linkClass.'"':'').$finalTagParts["aTagParams"].'>';
				// Call user function:
			if ($conf["userFunc"])	{
				$finalTagParts["TAG"]=$res;
				$res = $this->callUserFunction($conf["userFunc"],$conf["userFunc."],$finalTagParts);
			}
			if ($conf["ATagBeforeWrap"])	{
				return $res.$this->wrap($linktxt, $conf["wrap"]).'</a>';
			} else {
				return $this->wrap($res.$linktxt.'</a>', $conf["wrap"]);
			}
		} else {
			return $linktxt;
		}
	}
	function typoLink_URL($conf)	{
		$this->typolink("|",$conf);
		return $this->lastTypoLinkUrl;
	}

	/*
	 * Returns a linked string made from typoLink parameters. 
	 *
	 * This function takes $label as a string, wraps it in a link-tag based on the $params string, which should contain data like that you would normally pass to the popular <LINK>-tag in the TSFE.
	 * Optionally you can supply $urlParameters which is an array with key/value pairs that are rawurlencoded and appended to the resulting url.
	 */
	function getTypoLink($label,$params,$urlParameters=array(),$target="")	{
		$conf=array();
		$conf["parameter"] = $params;
		if ($target)	{
			$conf["target"]=$target;
			$conf["extTarget"]=$target;
		}
		if (count($urlParameters))	{
			reset($urlParameters);
			while(list($k,$v)=each($urlParameters))	{
				$conf["additionalParams"].="&".$k."=".rawurlencode($v);
			}
		}
		$out = $this->typolink($label,$conf);
		return $out;
	}
	function typolinkWrap($conf)	{
		$k=md5(microtime());
		return explode($k,$this->typolink($k,$conf));
	}
	function getTypoLink_URL($params,$urlParameters=array(),$target="")	{
		$this->getTypoLink("",$params,$urlParameters,$target);
		return $this->lastTypoLinkUrl;
	}
	function currentPageUrl($urlParameters=array(),$id=0)	{
		return $this->getTypoLink_URL($id?$id:$GLOBALS["TSFE"]->id,$urlParameters,$GLOBALS["TSFE"]->sPre);
	}
	function linkWrap($content,$wrap)	{
		$wrapArr = explode("|", $wrap);
		if (ereg("\{([0-9]*)\}",$wrapArr[0],$reg))	{
			if ($uid = $GLOBALS["TSFE"]->tmpl->rootLine[$reg[1]][uid])	{
				$wrapArr[0] = str_replace($reg[0],$uid,$wrapArr[0]);
			}
		}
		return trim($wrapArr[0]).$content.trim($wrapArr[1]);
	}
	function dataWrap($content,$wrap)	{
		return $this->wrap($content,$this->insertData($wrap));
	}
	function insertData($str)	{
		$inside=0;
		$newVal="";
		$pointer=0;
		$totalLen = strlen($str);
		do	{
			if (!$inside)	{
				$len = strcspn(substr($str,$pointer),"{");
				$newVal.=substr($str,$pointer,$len);
				$inside = 1;
			} else {
				$len = strcspn(substr($str,$pointer),"}")+1;
				$newVal.=$this->getData(substr($str,$pointer+1,$len-2),$this->data);
				$inside = 0;
			}
			$pointer+=$len;
		} while($pointer<$totalLen);
		return $newVal;
	}
	function substring($content,$options)	{
		$options = t3lib_div::intExplode(",",$options.",");
		if ($options[1])	{
			return substr($content,$options[0],$options[1]);
		} else {
			return substr($content,$options[0]);
		}
	}
	function crop($content,$options)	{
		$options = explode("|",$options);
		$chars=intval($options[0]);
		$afterstring=trim($options[1]);
		if ($chars)	{
			if (strlen($content)>abs($chars))	{
				if ($chars<0)	{
					$content= substr($content,$chars).$afterstring;
				} else {
					$content= substr($content,0,$chars).$afterstring;
				}
			}
		}
		return $content;
	}
	function keywords($content)	{
		$listArr = split(",|;|".chr(10),$content);
		reset($listArr);
		while(list($k,$v)=each($listArr))	{
			$listArr[$k]=trim($v);
		}
		return implode($listArr,",");
	}
	function caseshift($theValue, $case)	{
		$case = strtolower($case);
		switch($case)	{
			case "upper":
				$theValue = strtoupper($theValue);
				$theValue = strtr($theValue, "���������������", "���������������");
			break;
			case "lower":
				$theValue = strtolower($theValue);
				$theValue = strtr($theValue, "������������", "������������");
			break;
		}
		return $theValue;
	}
	function HTMLcaseshift($theValue, $case)	{
		$inside=0;
		$newVal="";
		$pointer=0;
		$totalLen = strlen($theValue);
		do	{
			if (!$inside)	{
				$len = strcspn(substr($theValue,$pointer),"<");
				$newVal.=$this->caseshift(substr($theValue,$pointer,$len),$case);
				$inside = 1;
			} else {
				$len = strcspn(substr($theValue,$pointer),">")+1;
				$newVal.=substr($theValue,$pointer,$len);
				$inside = 0;
			}
			$pointer+=$len;
		} while($pointer<$totalLen);
		return $newVal;
	}
	function bytes($sizeInBytes)	{
				// Formats a number to Mb or Kb or just bytes
		if ($sizeInBytes>900)	{
			if ($sizeInBytes>900000)	{	// MB
				$val = $sizeInBytes/(1024*1024);
				return number_format($val, (($val<20)?1:0), ".", "")." M";
			} else {	// KB
				$val = $sizeInBytes/(1024);
				return number_format($val, (($val<20)?1:0), ".", "")." K";
			}
		} else {	// Bytes
			return $sizeInBytes."&nbsp;&nbsp;";
		}
	}
	function calcAge ($seconds,$labels)	{
			// returns the "age" of the tstamp $seconds, 
			// $labels are the labels of the individual units. Defaults to : " min| hrs| days| yrs"
		if (t3lib_div::testInt($labels)) {
			$labels = " min| hrs| days| yrs";
		} else {
			$labels=str_replace('"',"",$labels);
		}
		
		$labelArr = explode("|",$labels);
		if ($seconds<3600)	{
			$seconds = round ($seconds/60).$labelArr[0];
		} elseif ($seconds<24*3600)	{
			$seconds = round ($seconds/3600).$labelArr[1];
		} elseif ($seconds<365*24*3600)	{
			$seconds = round ($seconds/(24*3600)).$labelArr[2];
		} else {
			$seconds = round ($seconds/(365*24*3600)).$labelArr[3];
		}
		return $seconds;
	}
	function HTMLparser_TSbridge($theValue, $conf)	{
		$htmlParser = t3lib_div::makeInstance("t3lib_parsehtml");
		$htmlParserCfg =  $htmlParser->HTMLparserConfig($conf);
		return $htmlParser->HTMLcleaner($theValue,$htmlParserCfg[0],$htmlParserCfg[1],$htmlParserCfg[2]);
	}
	function parseFunc ($theValue, $conf) {
		if (strcmp($conf["externalBlocks"],""))	{
			$tags = strtolower(implode(",",t3lib_div::trimExplode(",",$conf["externalBlocks"])));
			$htmlParser = t3lib_div::makeInstance("t3lib_parsehtml");
			$parts = $htmlParser->splitIntoBlock($tags,$theValue);
			
			reset($parts);
			while(list($k,$v)=each($parts))	{
				if ($k%2)	{	// font:
					$tagName=strtolower($htmlParser->getFirstTagName($v));
					$cfg=$conf["externalBlocks."][$tagName."."];
					if ($cfg["stripNLprev"] || $cfg["stripNL"])	{
						$parts[$k-1]=ereg_replace(chr(13)."?".chr(10)."[ ]*$", "", $parts[$k-1]);
					}
					if ($cfg["stripNLnext"] || $cfg["stripNL"])	{
						$parts[$k+1]=ereg_replace("^[ ]*".chr(13)."?".chr(10), "", $parts[$k+1]);
					}
				}
			}

			reset($parts);
			while(list($k,$v)=each($parts))	{
				if ($k%2)	{
					$tag=$htmlParser->getFirstTag($v);
					$tagName=strtolower($htmlParser->getFirstTagName($v));
					$cfg=$conf["externalBlocks."][$tagName."."];
					if ($cfg["callRecursive"])	{
						$parts[$k]=$this->parseFunc($htmlParser->removeFirstAndLastTag($v), $conf);
						if (!$cfg["callRecursive."]["dontWrapSelf"])	{
							if (is_array($cfg["callRecursive."]["tagStdWrap."]))	{
								$tag = $this->stdWrap($tag,$cfg["callRecursive."]["tagStdWrap."]);
							}
							$parts[$k]=$tag.$parts[$k].'</'.$tagName.'>';
						}
					} elseif($cfg["HTMLtableCells"]) {
						$rowParts = $htmlParser->splitIntoBlock("tr",$parts[$k]);
						reset($rowParts);
						while(list($kk,$vv)=each($rowParts))	{
							if ($kk%2)	{
								$colParts = $htmlParser->splitIntoBlock("td",$vv);
								reset($colParts);
								$cc=0;
								while(list($kkk,$vvv)=each($colParts))	{
									if ($kkk%2)	{
										$cc++;
										$tag=$htmlParser->getFirstTag($vvv);
										$tagName=strtolower($htmlParser->getFirstTagName($vvv));
										$colParts[$kkk] = $htmlParser->removeFirstAndLastTag($vvv);

										if ($cfg["HTMLtableCells."][$cc."."]["callRecursive"] || (!isset($cfg["HTMLtableCells."][$cc."."]["callRecursive"]) && $cfg["HTMLtableCells."]["default."]["callRecursive"]))	{
											if ($cfg["HTMLtableCells."]["addChr10BetweenParagraphs"])	$colParts[$kkk]=str_replace("</P><P>","</P>".chr(10)."<P>",$colParts[$kkk]);
											$colParts[$kkk] = $this->parseFunc($colParts[$kkk], $conf);
										}

										$tagStdWrap = is_array($cfg["HTMLtableCells."][$cc."."]["tagStdWrap."])?$cfg["HTMLtableCells."][$cc."."]["tagStdWrap."]:$cfg["HTMLtableCells."]["default."]["tagStdWrap."];
										if (is_array($tagStdWrap))	{
											$tag = $this->stdWrap($tag,$tagStdWrap);
										}

										$stdWrap = is_array($cfg["HTMLtableCells."][$cc."."]["stdWrap."])?$cfg["HTMLtableCells."][$cc."."]["stdWrap."]:$cfg["HTMLtableCells."]["default."]["stdWrap."];
										if (is_array($stdWrap))	{
											$colParts[$kkk] = $this->stdWrap($colParts[$kkk],$stdWrap);
										}
										
										$colParts[$kkk]=$tag.$colParts[$kkk].'</'.$tagName.'>';
									}
								}
								$rowParts[$kk] = implode("",$colParts);
							}
						}
						$parts[$k] = implode("",$rowParts);
					}
					
					if (is_array($cfg["stdWrap."]))	{
						$parts[$k] = $this->stdWrap($parts[$k],$cfg["stdWrap."]);
					}
				} else {
					$parts[$k]=$this->_parseFunc($parts[$k], $conf);
				}
			}

			return implode("",$parts);
		} else return $this->_parseFunc ($theValue, $conf);
	}
	function _parseFunc ($theValue, $conf) {
		if (!$this->checkIf($conf["if."]))	{
			return $theValue;
		}
		$inside=0;	// Indicates that the data is from within a tag.
		$pointer=0;	// Pointer to the total string position
		$currentTag="";	// Loaded with the current typo-tag if any.
		$stripNL=0;
		$contentAccum=array();
		$contentAccumP=0;

		$allowTags=strtolower(str_replace(" ","",$conf["allowTags"]));
		$denyTags=strtolower(str_replace(" ","",$conf["denyTags"]));

		$totalLen = strlen($theValue);
		do	{
			if (!$inside)	{
				if (!is_array($currentTag))	{			// These operations should only be performed on code outside the typotags...
						// data: this checks that we enter tags ONLY if the first char in the tag is alphanumeric OR "/"
					$len_p=0;
					$c=100;
					do 	{
						$len = strcspn(substr($theValue,$pointer+$len_p),"<");
						$len_p+=$len+1;
						$endChar = ord(strtolower(substr($theValue,$pointer+$len_p,1)));
						$c--;
					} while ($c>0 && $endChar && ($endChar<97 || $endChar>122) && $endChar!=47);
					$len = $len_p-1;					
				} else {		
						// If we're inside a currentTag, just take it to the end of that tag!
					$tempContent = strtolower(substr($theValue,$pointer));
					$len = strpos ($tempContent, "</".$currentTag[0]);
 					if (is_string ($len) && !$len) {
						$len = strlen($tempContent);
					}
				}

				$data = substr($theValue,$pointer,$len);	// $data is the content until the next <tag-start or end is detected. In case of a currentTag set, this would mean all data between the start- and end-tags
				if ($data!="")	{
					if ($stripNL)	{		// If the previous tag was set to strip NewLines in the beginning of the next data-chunk.
						$data = ereg_replace("^[ ]*".chr(13)."?".chr(10), "", $data);
					}

					if (!is_array($currentTag))	{			// These operations should only be performed on code outside the tags...
							// Constants
						if ($conf["constants"] && is_array($GLOBALS["TSFE"]->tmpl->setup["constants."]))	{
							reset($GLOBALS["TSFE"]->tmpl->setup["constants."]);
							while(list($key,$val)=each($GLOBALS["TSFE"]->tmpl->setup["constants."]))	{
								if (is_string($val))	{
									$data = str_replace("###".$key."###", $val, $data);
								}
							}
						}
							// Short
						if (is_array($conf["short."]))	{
							$shortWords = $conf["short."];
							krsort($shortWords);
							reset($shortWords);
							while(list($key,$val)=each($shortWords))	{
								if (is_string($val))	{
									$data = str_replace($key, $val, $data);
								}
							}
						}
						
							// stdWrap
						if (is_array($conf["plainTextStdWrap."]))	{$data = $this->stdWrap($data,$conf["plainTextStdWrap."]);}
							// userFunc
						if ($conf["userFunc"])	{$data = $this->callUserFunction($conf["userFunc"], $conf["userFunc."], $data);}

							// Makelinks: (Before search-words as we need the links to be generated when searchwords go on...!)
						if ($conf["makelinks"])	{
							$data = $this->http_makelinks($data,$conf["makelinks."]["http."]);
							$data = $this->mailto_makelinks($data,$conf["makelinks."]["mailto."]);
						}
						
							// Search Words:
						if ($GLOBALS["TSFE"]->no_cache && $conf["sword"] && is_array($GLOBALS["TSFE"]->sWordList) && $GLOBALS["TSFE"]->sWordRegEx)	{
							$newstring = "";
							do {
								$pieces = split($GLOBALS["TSFE"]->sWordRegEx,$data,2);
								$newstring.=$pieces[0];
								$match_len = strlen($data)-(strlen($pieces[0])+strlen($pieces[1]));
								if (strstr($pieces[0],"<") || strstr($pieces[0],">"))	{
									$inTag = strrpos($pieces[0],"<") > strrpos($pieces[0],">");		// Returns true, if a "<" is closer to the string-end than ">". This is the case if we're INSIDE a tag (that could have been made by makelinks...) and we must secure, that the inside of a tag is not marked up.
								}
									// The searchword:
								$match = substr($data,strlen($pieces[0]),$match_len);

								if (trim($match) && strlen($match)>1 && !$inTag)	{
									$match = $this->wrap($match, $conf["sword"]);
								}
									// Concatenate the Search Word again.
								$newstring.= $match;
								$data=$pieces[1];
							} while ($pieces[1]);
							$data = $newstring;
						}
					}
					$contentAccum[$contentAccumP].=$data;
				}
				$inside = 1;
			} else {
					// tags
				$len = strcspn(substr($theValue,$pointer),">")+1;
				$data = substr($theValue,$pointer,$len);

				$tag = explode(" ",trim(substr($data,1,-1)),2);
				$tag[0]=strtolower($tag[0]);
				if (substr($tag[0],0,1)=="/")	{
					$tag[0]=substr($tag[0],1);
					$tag["out"]=1;
				}
				if($conf["tags."][$tag[0]])	{
					$treated=0;
					$stripNL = 0;
						// in-tag
					if (!$currentTag && !$tag["out"])	{
						$currentTag = $tag;		// $currentTag er lig med det tag (array!), man er igang med!
						$contentAccumP++;
						$treated=1;
					}
						// out-tag
					if ($currentTag[0]==$tag[0] && $tag["out"])	{
						$theName = $conf["tags."][$tag[0]];
						$theConf = $conf["tags."][$tag[0]."."];
						$stripNL = ($theConf["stripNL"] ? 1 : 0);	// This flag indicates, that NL- (13-10-chars) should be stripped first and last.
						$breakOut = ($theConf["breakoutTypoTagContent"] ? 1 : 0);	// This flag indicates, that this TypoTag section should NOT be included in the nonTypoTag content.

						$this->parameters=Array();
						if ($currentTag[1])	{
							$params=t3lib_div::get_tag_attributes($currentTag[1]);
							if (is_array($params))	{
								reset($params);
								while(list($option,$val)=each($params))	{
									$this->parameters[strtolower($option)]=$val;
								}
							}
						}
						$this->parameters["allParams"]=trim($currentTag[1]);
						if ($stripNL)	{	// Removes NL in the beginning and end of the tag-content AND at the end of the currentTagBuffer. $stripNL depends on the configuration of the current tag
							$contentAccum[$contentAccumP-1] = ereg_replace(chr(13)."?".chr(10)."[ ]*$", "", $contentAccum[$contentAccumP-1]);
							$contentAccum[$contentAccumP] = ereg_replace("^[ ]*".chr(13)."?".chr(10), "", $contentAccum[$contentAccumP]);
							$contentAccum[$contentAccumP] = ereg_replace(chr(13)."?".chr(10)."[ ]*$", "", $contentAccum[$contentAccumP]);
						}
						$this->data[$this->currentValKey] = $contentAccum[$contentAccumP];
						$newInput=$this->cObjGetSingle($theName,$theConf,"/parseFunc/.tags.".$tag[0]);	// fetch the content object

						$contentAccum[$contentAccumP]=$newInput;
						$contentAccumP++;

							// If the TypoTag section
						if (!$breakOut)	{
							$contentAccum[$contentAccumP-2].=$contentAccum[$contentAccumP-1].$contentAccum[$contentAccumP];
							unset($contentAccum[$contentAccumP]);
							unset($contentAccum[$contentAccumP-1]);
							$contentAccumP-=2;
						}
						
						unset($currentTag);
						$treated=1;
					}
						// other tags...
					if (!$treated)	{
						$contentAccum[$contentAccumP].=$data;
					}
				} else {
						// If a tag was not a typo tag, then it is just added to the content
					$stripNL = 0;
					if (t3lib_div::inList($allowTags,$tag[0]) || ($denyTags!="*" && !t3lib_div::inList($denyTags,$tag[0])))	{
						$contentAccum[$contentAccumP].=$data;
					} else {
						$contentAccum[$contentAccumP].=HTMLSpecialChars($data);
					}
				}
				$inside = 0;
			}
			$pointer+=$len;
		} while($pointer<$totalLen);

			// Parsing nonTypoTag content (all even keys):
//debug($contentAccum);
//debug($conf);
//debug(array($theValue));

		reset($contentAccum);
		for ($a=0;$a<count($contentAccum);$a++)	{
			if ($a%2 != 1)	{
					// stdWrap
				if (is_array($conf["nonTypoTagStdWrap."]))	{$contentAccum[$a] = $this->stdWrap($contentAccum[$a],$conf["nonTypoTagStdWrap."]);}
					// userFunc
				if ($conf["nonTypoTagUserFunc"])	{$contentAccum[$a] = $this->callUserFunction($conf["nonTypoTagUserFunc"], $conf["nonTypoTagUserFunc."], $contentAccum[$a]);}
			}
		}
		return implode("",$contentAccum);
	}
	function encaps_lineSplit($theValue, $conf)	{
		$lParts = explode(chr(10),$theValue);

		$encapTags = t3lib_div::trimExplode(",",strtolower($conf["encapsTagList"]),1);
		$nonWrappedTag = $conf["nonWrappedTag"];
		$defaultAlign=trim($this->stdWrap($conf["defaultAlign"],$conf["defaultAlign."]));
		
		if (!strcmp("",$theValue))	return "";
		
		while(list($k,$l)=each($lParts))	{
			$sameBeginEnd=0;
			$l=trim($l);
			$attrib=array();
			$nWrapped=0;
			$byPass=0;
			if (substr($l,0,1)=="<" && substr($l,-1)==">")	{
				$fwParts = explode(">",substr($l,1),2);
				$backParts = t3lib_div::revExplode("<", substr($fwParts[1],0,-1), 2);
				$attrib = t3lib_div::get_tag_attributes("<".$fwParts[0].">");
				list($tagName) = explode(" ",$fwParts[0]);
				$str_content = $backParts[0];
				$sameBeginEnd = (substr(strtolower($backParts[1]),1,strlen($tagName))==strtolower($tagName));
			}

			if ($sameBeginEnd && in_array(strtolower($tagName),$encapTags))	{
				$uTagName = strtoupper($tagName);
				$uTagName = strtoupper($conf["remapTag."][$uTagName]?$conf["remapTag."][$uTagName]:$uTagName);
			} else {
				$uTagName = strtoupper($nonWrappedTag);
				$str_content = $lParts[$k];
				$nWrapped=1;
			}

				// Wrapping all inner-content:
			if (is_array($conf["innerStdWrap_all."]))	{$str_content = $this->stdWrap($str_content,$conf["innerStdWrap_all."]);}

			if ($uTagName)	{
					// Setting common attributes
				if (is_array($conf["addAttributes."][$uTagName."."]))	{
					reset($conf["addAttributes."][$uTagName."."]);
					while(list($kk,$vv)=each($conf["addAttributes."][$uTagName."."]))	{
						$attrib[$kk]=$vv;
					}
				}
					// Wrapping all inner-content:
				if (is_array($conf["encapsLinesStdWrap."][$uTagName."."]))	{$str_content = $this->stdWrap($str_content,$conf["encapsLinesStdWrap."][$uTagName."."]);}
					// Default align
				if (!$attrib["align"] && $defaultAlign)	$attrib["align"]=$defaultAlign;

				$params = t3lib_div::implodeParams($attrib);
				if ($conf["removeWrapping"])	{
					$str_content=$str_content;
				} else {
					$str_content='<'.$uTagName.(trim($params)?" ".trim($params):"").'>'.$str_content.'</'.$uTagName.'>';
				}
			}

			if ($nWrapped && $conf["wrapNonWrappedLines"])	{$str_content = $this->wrap($str_content,$conf["wrapNonWrappedLines"]);}

			$lParts[$k] = $str_content;
		}
//debug($lParts);
//debug(t3lib_div::debug_ordvalue($theValue));
		return implode(chr(10),$lParts);
	}
	function textStyle($theValue, $conf) {	
		$conf["face."][1] = "Times New Roman";
		$conf["face."][2] = "Verdana,Arial,Helvetica,Sans serif";
		$conf["face."][3] = "Arial,Helvetica,Sans serif";

		$conf["size."][1] = 1;
		$conf["size."][2] = 2;
		$conf["size."][3] = 3;
		$conf["size."][4] = 4;
		$conf["size."][5] = 5;
		$conf["size."][10] = "+1";
		$conf["size."][11] = "-1";
	
		$conf["color."][240] = "black";
		$conf["color."][241] = "white";
		$conf["color."][242] = "#333333";
		$conf["color."][243] = "gray";
		$conf["color."][244] = "silver";
		$conf["color."][245] = "red";
		$conf["color."][246] = "navy";
		$conf["color."][247] = "yellow";
		$conf["color."][248] = "green";
		$conf["color."][249] = "olive";
		$conf["color."][250] = "maroon";
	
		$face = $this->data[$conf["face."]["field"]];		
		$size = $this->data[$conf["size."]["field"]];		
		$color = $this->data[$conf["color."]["field"]];		
		$align = $this->data[$conf["align."]["field"]];
		$properties = $this->data[$conf["properties."]["field"]];
		if (!$properties)	{
			$properties=$this->stdWrap($conf["properties."]["default"],$conf["properties."]["default."]);
		}
		
			// properties
		if (($properties&8))	{$theValue=$this->HTMLcaseshift($theValue, "upper");}
		if (($properties&1))	{$theValue="<B>".$theValue."</B>";}
		if (($properties&2))	{$theValue="<I>".$theValue."</I>";}
		if (($properties&4))	{$theValue="<U>".$theValue."</U>";}
		
			// Fonttag
		$theFace = $conf["face."][$face] ? $conf["face."][$face] : $this->stdWrap($conf["face."]["default"],$conf["face."]["default."]);
		$theSize = $conf["size."][$size] ? $conf["size."][$size] : $this->stdWrap($conf["size."]["default"],$conf["size."]["default."]);
		$theColor = $conf["color."][$color] ? $conf["color."][$color] : $this->stdWrap($conf["color."]["default"],$conf["color."]["default."]);
		
		if ($conf["altWrap"])	{
			$theValue=$this->wrap($theValue, $conf["altWrap"]);
		} elseif ($theFace || $theSize || $theColor)	{
			$fontWrap = '<font'.($theFace?' face="'.$theFace.'"':'').($theSize?' size="'.$theSize.'"':'').($theColor?' color="'.$theColor.'"':'').'>|</font>';
			$theValue=$this->wrap($theValue, $fontWrap);
		}
			// align
		if ($align)	{$theValue=$this->wrap($theValue, '<DIV align="'.$align.'">|</div>');}
			// return
		return $theValue;
	}
	function tableStyle($theValue, $conf) {	
		$conf["color."][240] = "black";
		$conf["color."][241] = "white";
		$conf["color."][242] = "#333333";
		$conf["color."][243] = "gray";
		$conf["color."][244] = "silver";

		$align = $this->stdWrap($conf["align"],$conf["align."]);
		$border = intval($this->stdWrap($conf["border"],$conf["border."]));
		$cellspacing = intval($this->stdWrap($conf["cellspacing"],$conf["cellspacing."]));
		$cellpadding = intval($this->stdWrap($conf["cellpadding"],$conf["cellpadding."]));

		$color = $this->data[$conf["color."]["field"]];		
		$theColor = $conf["color."][$color] ? $conf["color."][$color] : $conf["color."]["default"];
			// Assembling the table tag
		$tableTagArray = Array("<table");
		$tableTagArray[]='border="'.$border.'"';
		$tableTagArray[]='cellspacing="'.$cellspacing.'"';
		$tableTagArray[]='cellpadding="'.$cellpadding.'"';
		if ($align)	{$tableTagArray[]='align="'.$align.'"';}
		if ($theColor)	{$tableTagArray[]='bgColor="'.$theColor.'"';}

		if ($conf["params"])	{
			$tableTagArray[] = $conf["params"];
		}

		$tableWrap = implode($tableTagArray," ")."> | </table>";
		$theValue=$this->wrap($theValue, $tableWrap);
			// return
		return $theValue;
	}
	function filelink($theValue, $conf)	{
		$output = "";
		$aTagParams = $GLOBALS["TSFE"]->ATagParams.($conf["ATagParams"]?" ".$conf["ATagParams"]:"");
		$initP = '?id='.$GLOBALS["TSFE"]->id.'&type='.$GLOBALS["TSFE"]->type;
		$conf["path"] = $this->stdWrap($conf["path"],$conf["path."]);
		$theFile = trim($conf["path"]).$theValue;
		if (@is_file($theFile))	{
			$locDataAdd = $conf["jumpurl."]["secure"] ? $this->locDataJU($theFile,$conf["jumpurl."]["secure."]) : "";
			$url = ($conf["jumpurl"]) ? $GLOBALS["TSFE"]->config["mainScript"].$initP."&jumpurl=".rawurlencode($theFile).$locDataAdd.$GLOBALS["TSFE"]->getMethodUrlIdToken : $theFile;		// && $GLOBALS["TSFE"]->config["config"]["jumpurl_enable"]
			$theLinkWrap = '<A href="'.$GLOBALS["TSFE"]->absRefPrefix.$url.'"'.($conf["target"]?' target="'.$conf["target"].'"':'').$aTagParams.'>|</a>';
		
			$theSize = filesize($theFile);
			$fI = t3lib_div::split_fileref($theFile);
			if ($conf["icon"])	{
				$iconP = "t3lib/gfx/fileicons/";
				$icon = @is_file($iconP.$fI["fileext"].".gif") ? $iconP.$fI["fileext"].".gif" : $iconP."default.gif";
					// Checking for images: If image, then return link to thumbnail.
				$IEList = $this->stdWrap($conf["icon_image_ext_list"],$conf["icon_image_ext_list."]); 
				$image_ext_list = str_replace(" ","",strtolower($IEList));
				if ($fI["fileext"] && t3lib_div::inList($image_ext_list, $fI["fileext"]))	{
					if ($conf["iconCObject"])	{
						$icon = $this->cObjGetSingle($conf["iconCObject"],$conf["iconCObject."],"iconCObject");
					} else {
						if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["thumbnails"])	{
							$icon = 't3lib/thumbs.php?&dummy='.$GLOBALS["EXEC_TIME"].'&file='.rawurlencode("../".$theFile);
						} else {
							$icon = 't3lib/gfx/notfound_thumb.gif';
						}
						$icon = '<img src="'.$GLOBALS["TSFE"]->absRefPrefix.$icon.'" border=0>';
					}
				} else {
					$icon = '<img src="'.$GLOBALS["TSFE"]->absRefPrefix.$icon.'" width=18 height=16 border=0>';
				}
				if ($conf["icon_link"]) {$icon = $this->wrap($icon, $theLinkWrap);}
				$icon = $this->stdWrap($icon,$conf["icon."]);
			}
			if ($conf["size"])	{
				$size = $this->stdWrap($theSize,$conf["size."]);
			}

				// Wrapping file label
			if ($conf["removePrependedNumbers"]) $theValue=ereg_replace("_[0-9][0-9](\.[[:alnum:]]*)$",'\1',$theValue);
			$theValue = $this->stdWrap($theValue,$conf["labelStdWrap."]);

				// Wrapping file
			if ($conf["ATagBeforeWrap"])	{
				$theValue = $this->wrap($this->wrap($theValue, $conf["wrap"]), $theLinkWrap);
			} else {
				$theValue = $this->wrap($this->wrap($theValue, $theLinkWrap), $conf["wrap"]);
			}
			$file = $this->stdWrap($theValue,$conf["file."]);
				// output			
			return $this->stdWrap($icon.$file.$size, $conf["stdWrap."]);
		}
	}
	function locDataJU($jumpUrl,$conf)	{
		$fI = pathinfo($jumpUrl);
		$mimetype="";
		if ($fI["extension"])	{
			$mimeTypes = t3lib_div::trimExplode(",",$conf["mimeTypes"],1);
			reset($mimeTypes);
			while(list(,$v)=each($mimeTypes))	{
				$parts = explode("=",$v,2);
				if (strtolower($fI["extension"]) == strtolower(trim($parts[0])))	{
					$mimetype = "&mimeType=".rawurlencode(trim($parts[1]));
				}
			}
		}
		$locationData = $GLOBALS["TSFE"]->id.":".$this->currentRecord;
		$rec="&locationData=".$locationData;
		$hArr = array(	
			$jumpUrl,
			$locationData,
			$GLOBALS["TSFE"]->TYPO3_CONF_VARS["SYS"]["encryptionKey"]
		);
		$juHash="&juHash=".t3lib_div::shortMD5(serialize($hArr));
		return "&juSecure=1".$mimetype.$rec.$juHash;
	}
	function http_makelinks($data,$conf)	{
		// http-split
		$aTagParams = $GLOBALS["TSFE"]->ATagParams.($conf["ATagParams"]?" ".$conf["ATagParams"]:"");
		$textpieces = explode("http://", $data);
		$pieces = count($textpieces);
		$textstr = $textpieces[0];
		$initP = '?id='.$GLOBALS["TSFE"]->id.'&type='.$GLOBALS["TSFE"]->type;
		for($i=1; $i<$pieces; $i++)	{
			$len=strcspn($textpieces[$i],chr(32).chr(9).chr(13).chr(10));
			if (trim(substr($textstr,-1))=="" && $len)	{

				$lastChar=substr($textpieces[$i],$len-1,1);
				if (!ereg("[A-Za-z0-9\/#_-]",$lastChar)) {$len--;}		// Included "\/" 3/12

				$parts[0]=substr($textpieces[$i],0,$len);
				$parts[1]=substr($textpieces[$i],$len);

				$keep=$conf["keep"];
				$linkParts=parse_url("http://".$parts[0]);
				$linktxt="";
				if (strstr($keep,"scheme"))	{
					$linktxt="http://";
				}
				$linktxt.= $linkParts["host"];
				if (strstr($keep,"path"))	{
					$linktxt.= $linkParts["path"];
					if (strstr($keep,"query") && $linkParts["query"])	{		// added $linkParts["query"] 3/12
						$linktxt.= "?".$linkParts["query"];
					} elseif ($linkParts["path"]=="/")	{  // If query is NOT added and the path is "/" then remove the slash ("/")   (added 3/12)
						$linktxt=substr($linktxt,0,-1);
					}
				}
  				$target = isset($conf["extTarget"]) ? $conf["extTarget"] : $GLOBALS["TSFE"]->extTarget;
				if ($GLOBALS["TSFE"]->config["config"]["jumpurl_enable"])	{
					$res = '<A HREF="'.$GLOBALS["TSFE"]->absRefPrefix.$GLOBALS["TSFE"]->config["mainScript"].$initP.'&jumpurl='.rawurlencode('http://'.$parts[0]).$GLOBALS["TSFE"]->getMethodUrlIdToken.'" target="'.$target.'"'.$aTagParams.'>';
				} else {
					$res = '<A HREF="http://'.$parts[0].'" target="'.$target.'"'.$aTagParams.'>';
				}
				if ($conf["ATagBeforeWrap"])	{
					$res= $res.$this->wrap($linktxt, $conf["wrap"]).'</a>';
				} else {
					$res= $this->wrap($res.$linktxt.'</a>', $conf["wrap"]);
				}
				$textstr.=$res.$parts[1];
			} else {
				$textstr.='http://'.$textpieces[$i];
			}				
		}
		return $textstr;
	}	
	function mailto_makelinks($data,$conf)	{
		// http-split
		$aTagParams = $GLOBALS["TSFE"]->ATagParams.($conf["ATagParams"]?" ".$conf["ATagParams"]:"");
		$textpieces = explode("mailto:", $data);
		$pieces = count($textpieces);
		$textstr = $textpieces[0];
		$initP = '?id='.$GLOBALS["TSFE"]->id.'&type='.$GLOBALS["TSFE"]->type;
		for($i=1; $i<$pieces; $i++)	{
			$len=strcspn($textpieces[$i],chr(32).chr(9).chr(13).chr(10));
			if (trim(substr($textstr,-1))=="" && $len)	{
				$lastChar=substr($textpieces[$i],$len-1,1);
				if (!ereg("[A-Za-z0-9]",$lastChar)) {$len--;}

				$parts[0]=substr($textpieces[$i],0,$len);
				$parts[1]=substr($textpieces[$i],$len);
				$linktxt=ereg_replace("\?.*","",$parts[0]);
				if (!$GLOBALS["TSFE"]->config["config"]["jumpurl_enable"] || $GLOBALS["TSFE"]->config["config"]["jumpurl_mailto_disable"])	{
					$res = '<A HREF="mailto:'.$parts[0].'"'.$aTagParams.'>';
				} else {
					$res = '<A HREF="'.$GLOBALS["TSFE"]->absRefPrefix.$GLOBALS["TSFE"]->config["mainScript"].$initP.'&jumpurl='.rawurlencode('mailto:'.$parts[0]).$GLOBALS["TSFE"]->getMethodUrlIdToken.'"'.$aTagParams.'>';
				}
				if ($conf["ATagBeforeWrap"])	{
					$res= $res.$this->wrap($linktxt, $conf["wrap"]).'</a>';
				} else {
					$res= $this->wrap($res.$linktxt.'</a>', $conf["wrap"]);
				}
				$textstr.=$res.$parts[1];
			} else {
				$textstr.='mailto:'.$textpieces[$i];
			}				
		}
		return $textstr;
	}	
	function fileResource($fName)	{
		// If gif/jpg: returns image_tag with picture in
		// If html,txt: returns content
		$incFile = $GLOBALS["TSFE"]->tmpl->getFileName($fName);
		if ($incFile)	{
			$fileinfo = t3lib_div::split_fileref($incFile);
			if (t3lib_div::inList("jpg,gif,jpeg,png",$fileinfo["fileext"]))	{
				$imgFile = $incFile;
				$imgInfo = @getImageSize($imgFile);
				return '<img src="'.$GLOBALS["TSFE"]->absRefPrefix.$imgFile.'" width="'.$imgInfo[0].'" height="'.$imgInfo[1].'" border=0>';
			} elseif (filesize($incFile)<1024*1024) {
				return $GLOBALS["TSFE"]->tmpl->fileContent($incFile);
			}
		}
	}
	function getImgResource($file,$fileArray)	{
		// returns info-array
		// info[origFile] = original file.
		if (is_array($fileArray))	{
			switch($file)	{
				case "GIFBUILDER":
					$gifCreator = t3lib_div::makeInstance("tslib_gifbuilder");
					$gifCreator->init();
					$theImage="";
					if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"])	{
						$gifCreator->start($fileArray,$this->data);
						$theImage = $gifCreator->gifBuild();
					}
					return $gifCreator->getImageDimensions($theImage);
				break;
				default:
					if ($fileArray["import."])	{
						$ifile = $this->stdWrap("",$fileArray["import."]);
						if ($ifile)	{$file = $fileArray["import"].$ifile;}
					}
					$theImage = $GLOBALS["TSFE"]->tmpl->getFileName($file);
					if ($theImage)	{
						$fileArray["width"]= $this->stdWrap($fileArray["width"],$fileArray["width."]);
						$fileArray["height"]= $this->stdWrap($fileArray["height"],$fileArray["height."]);
						$fileArray["ext"]= $this->stdWrap($fileArray["ext"],$fileArray["ext."]);
						$fileArray["maxW"]= intval($this->stdWrap($fileArray["maxW"],$fileArray["maxW."]));
						$fileArray["maxH"]= intval($this->stdWrap($fileArray["maxH"],$fileArray["maxH."]));
						$fileArray["minW"]= intval($fileArray["minW"]);
						$fileArray["minH"]= intval($fileArray["minH"]);
						$maskArray=	$fileArray["m."];
						$maskImages=array();
						if (is_array($fileArray["m."]))	{	// Must render mask images and include in hash-calculating - else we cannot be sure the filename is unique for the setup!
							$maskImages["m_mask"] = $this->getImgResource($maskArray["mask"],$maskArray["mask."]);
							$maskImages["m_bgImg"] = $this->getImgResource($maskArray["bgImg"],$maskArray["bgImg."]);
							$maskImages["m_bottomImg"] = $this->getImgResource($maskArray["bottomImg"],$maskArray["bottomImg."]);
							$maskImages["m_bottomImg_mask"] = $this->getImgResource($maskArray["bottomImg_mask"],$maskArray["bottomImg_mask."]);
						}
						$hash = t3lib_div::shortMD5($theImage.serialize($fileArray).serialize($maskImages));
						if (!isset($GLOBALS["TSFE"]->tmpl->fileCache[$hash]))	{
							$gifCreator = t3lib_div::makeInstance("tslib_gifbuilder");
							$gifCreator->init();
							if ($fileArray["sample"])	{
								$gifCreator->scalecmd = "-sample";
								$GLOBALS["TT"]->setTSlogMessage("Sample option: Images are scaled with -sample.");
							}
							if ($fileArray["alternativeTempPath"] && t3lib_div::inList($GLOBALS["TYPO3_CONF_VARS"]["FE"]["allowedTempPaths"],$fileArray["alternativeTempPath"]))	{
								$gifCreator->tempPath = $fileArray["alternativeTempPath"];	
								$GLOBALS["TT"]->setTSlogMessage("Set alternativeTempPath: ".$fileArray["alternativeTempPath"]);
							}
							
							if (!trim($fileArray["ext"])){$fileArray["ext"]="web";}
							$options = Array();
							if ($fileArray["maxW"]) {$options["maxW"]=$fileArray["maxW"];}
							if ($fileArray["maxH"]) {$options["maxH"]=$fileArray["maxH"];}
							if ($fileArray["minW"]) {$options["minW"]=$fileArray["minW"];}
							if ($fileArray["minH"]) {$options["minH"]=$fileArray["minH"];}

								// checks to see if m (the mask array) is defined
							if (is_array($maskArray) && $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im"])	{
									// Filename:
								$fI = t3lib_div::split_fileref($theImage);
								$dest = $gifCreator->tempPath.$hash.".".($fI["fileext"]==$gifCreator->gifExtension ? $gifCreator->gifExtension : "jpg");
								if (!@file_exists($dest))	{		// Generate!
									$m_mask= $maskImages["m_mask"];
									$m_bgImg = $maskImages["m_bgImg"];
									if ($m_mask && $m_bgImg)	{
										$negate = $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_negate_mask"] ? " -negate" : "";
										$temp_ext="png";
										if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_mask_temp_ext_gif"])	{		// If ImageMagick version 5+
											$temp_ext=$gifCreator->gifExtension;
										}
										$tempFileInfo = $gifCreator->imageMagickConvert($theImage,$temp_ext,$fileArray["width"],$fileArray["height"],$fileArray["params"],$fileArray["frame"],$options);
										if (is_array($tempFileInfo))	{
											$m_bottomImg = $maskImages["m_bottomImg"];
											if ($m_bottomImg)	{
												$m_bottomImg_mask = $maskImages["m_bottomImg_mask"];
											}
												//	Scaling:	****
											$tempScale=array();
											$command = "-geometry ".$tempFileInfo[0]."x".$tempFileInfo[1]."!";
											$tmpStr = $gifCreator->randomName();
											
												//	m_mask
											$tempScale["m_mask"]=$tmpStr."_mask.".$temp_ext;
											$gifCreator->imageMagickExec($m_mask[3],$tempScale["m_mask"],$command.$negate);
												//	m_bgImg
											$tempScale["m_bgImg"]=$tmpStr."_bgImg.miff";
											$gifCreator->imageMagickExec($m_bgImg[3],$tempScale["m_bgImg"],$command);
												//	m_bottomImg / m_bottomImg_mask
											if ($m_bottomImg && $m_bottomImg_mask)	{
												$tempScale["m_bottomImg"]=$tmpStr."_bottomImg.".$temp_ext;
												$gifCreator->imageMagickExec($m_bottomImg[3],$tempScale["m_bottomImg"],$command);
												$tempScale["m_bottomImg_mask"]=$tmpStr."_bottomImg_mask.".$temp_ext;
												$gifCreator->imageMagickExec($m_bottomImg_mask[3],$tempScale["m_bottomImg_mask"],$command.$negate);
	
													// BEGIN combining:
													// The image onto the background
												$gifCreator->combineExec($tempScale["m_bgImg"],$tempScale["m_bottomImg"],$tempScale["m_bottomImg_mask"],$tempScale["m_bgImg"]);
											}
												// The image onto the background
											$gifCreator->combineExec($tempScale["m_bgImg"],$tempFileInfo[3],$tempScale["m_mask"],$dest);
												// Unlink the temp-images...
											reset($tempScale);
											while(list(,$file)=each($tempScale))	{
												if (@is_file($file))	{
													unlink($file);
												}
											}
												//	t3lib_div::print_array($GLOBALS["TSFE"]->tmpl->fileCache[$hash]);
										}
									}
								}
									// Finish off
								$GLOBALS["TSFE"]->tmpl->fileCache[$hash]= $gifCreator->getImageDimensions($dest);
								$GLOBALS["TSFE"]->tmpl->fileCache[$hash][origFile] = $theImage;
							} else {		// Normal situation:
								$GLOBALS["TSFE"]->tmpl->fileCache[$hash]= $gifCreator->imageMagickConvert($theImage,$fileArray["ext"],$fileArray["width"],$fileArray["height"],$fileArray["params"],$fileArray["frame"],$options);
								$GLOBALS["TSFE"]->tmpl->fileCache[$hash][origFile] = $theImage;
							}
						}
						return $GLOBALS["TSFE"]->tmpl->fileCache[$hash];
					}
					
				break;
			}
		}
		$theImage = $GLOBALS["TSFE"]->tmpl->getFileName($file);
		if ($theImage)	{
			$gifCreator = t3lib_div::makeInstance("tslib_gifbuilder");
			$gifCreator->init();
			$info= $gifCreator->imageMagickConvert($theImage,"WEB","","","","","");
			$info["origFile"] = $theImage;
			return $info;
		}
	}
	function getQuery($table,$conf)	{
		$conf["pidInList"] = trim($this->stdWrap($conf["pidInList"],$conf["pidInList."]));
		if (!strcmp($conf["pidInList"],""))	{
			$conf["pidInList"] = "this";
		}
		
		$where = $this->getWhere($table,$conf);
		if ($conf["max"] || $conf["begin"]) {
			if (strstr(strtolower($conf["begin"].$conf["max"]),"total"))	{
				$res = @mysql(TYPO3_db,"SELECT count(*) FROM ".$table." ".$where);
				if ($error = mysql_error())	{
					$GLOBALS["TT"]->setTSlogMessage($error);
				} else {
					$row = mysql_fetch_row($res);
					$total = $row[0];
					$conf["max"]=eregi_replace("total","".$total,$conf["max"]);
					$conf["min"]=eregi_replace("total","".$total,$conf["min"]);
				}
			}
			if (!$error)	{
				$conf["begin"] = ceil($this->calc($conf["begin"]));
				$conf["max"] = ceil($this->calc($conf["max"]));
				if ($conf["begin"] && !$conf["max"])	{
					$conf["max"] = 100000;
				}
				if ($conf["begin"] && $conf["max"])	{
					$where.=" LIMIT ".$conf["begin"].",".$conf["max"];
				}
				if (!$conf["begin"] && $conf["max"])	{
					$where.=" LIMIT ".$conf["max"];
				}
			}
		}

		if (!$error)	{
			$joinPart="";
			if ($conf["join"])	{
				$joinPart = "JOIN " .trim($conf["join"]);
			} elseif ($conf["leftjoin"])	{
				$joinPart = "LEFT OUTER JOIN " .trim($conf["leftjoin"]);
			} elseif ($conf["rightjoin"])	{
				$joinPart = "RIGHT OUTER JOIN " .trim($conf["rightjoin"]);
			}
			$query = "SELECT * FROM ".$table." ".$joinPart." ".$where;
		}
		return $query;
	}
	function checkPidArray($listArr)	{
		$outArr = Array();
		if (is_array($listArr) && count($listArr))	{
			$query = "select uid from pages where uid in (".implode($listArr,",").")".$this->enableFields("pages")." AND doktype NOT IN (".$this->checkPid_badDoktypeList.")";
			$res = @mysql(TYPO3_db,$query);
			if ($error = mysql_error())	{
				$GLOBALS["TT"]->setTSlogMessage($error.": ".$query,3);
			} else {
				while($row = mysql_fetch_assoc($res))	{
					$outArr[]=$row["uid"];
				}
			}			
		}
		return $outArr;
	}
	function checkPid($uid)	{
		$uid = intval($uid);
		if (!isset($this->checkPid_cache[$uid]))	{	
			$query = "select uid from pages where uid=".$uid.$this->enableFields("pages")." AND doktype NOT IN (".$this->checkPid_badDoktypeList.")";
			$res = @mysql(TYPO3_db,$query);
			if (mysql_num_rows($res))	{
				$this->checkPid_cache[$uid]=1;
			} else {
				$this->checkPid_cache[$uid]=0;
			}
		}
		return $this->checkPid_cache[$uid];
	}
	function getWhere($table,$conf)	{
		$query = "";
		$pid_uid_flag=0;
		if (trim($conf["uidInList"]))	{
			$listArr = t3lib_div::intExplode(",",str_replace("this",$GLOBALS["TSFE"]->page[uid],$conf["uidInList"]));  // str_replace instead of ereg_replace 020800
			if (count($listArr)==1)	{
				$query.=" AND uid=".$listArr[0];
			} else {
				$query.=" AND uid IN (".implode($listArr,",").")";
			}
			$pid_uid_flag++;
		}
		if (trim($conf["pidInList"]))	{
			$listArr = t3lib_div::intExplode(",",str_replace("this",$GLOBALS["TSFE"]->page[uid],$conf["pidInList"]));	// str_replace instead of ereg_replace 020800
				// removes all pages which are not visible for the user!			
			$listArr = $this->checkPidArray($listArr);
			if (count($listArr))	{
			    // Old: $query.=" AND pid IN (".implode($listArr,",").")";
			    $query.=" AND ".$table.".pid IN (".implode($listArr,",").")";
				$pid_uid_flag++;
			} else {
				$pid_uid_flag=0;		// If not uid and not pid then uid is set to 0 - which results in nothing!!
			}
		}
		if (!$pid_uid_flag)	{		// If not uid and not pid then uid is set to 0 - which results in nothing!!
			$query.=" AND uid=0";
		}
		if ($where = trim($conf["where"]))	{
			$query.=" AND ".$where;
		}
		if ($conf["languageField"])	{
			$query.=" AND ".$conf["languageField"]."=".intval($GLOBALS["TSFE"]->sys_language_uid);
		}
		
		$andWhere = trim($this->stdWrap($conf["andWhere"],$conf["andWhere."]));
		if ($andWhere)	{
			$query.=" AND ".$andWhere;
		}

		// enablefields
		if ($table=="pages")	{
			$query.=" ".$GLOBALS["TSFE"]->sys_page->where_hid_del;
		} else {
			$query.=$this->enableFields($table);
		}
		if ($query)	{
			$query = "WHERE ".substr($query,4);
		}
		
		// order By
		if (trim($conf["orderBy"]))	{
			$query.=" ORDER BY ".trim($conf["orderBy"]);
		}
		// group By
		if (trim($conf["groupBy"]))	{
			$query.=" GROUP BY ".trim($conf["groupBy"]);
		}
		return $query;
	}
	function enableFields($table,$show_hidden=0)	{
		return $GLOBALS["TSFE"]->sys_page->enableFields($table,$show_hidden?$show_hidden:($table=="pages" ? $GLOBALS["TSFE"]->showHiddenPage : $GLOBALS["TSFE"]->showHiddenRecords));
	}
	function getTreeList($id,$depth,$begin=0,$dontCheckEnableFields=0,$addSelectFields="",$moreWhereClauses="")	{
		/* Generates a list of Page-uid's from $id. List does not include $id itself
		 The only pages WHICH PREVENTS DECENDING in a branch are 
		   - deleted pages, 
		   - pages in a recycler (added 061101) or of the Backend User Section type (added 080102)
		   - pages that has the extendToSubpages set, WHERE start/endtime, hidden and fe_users would hide the records.
		 Appart from that, pages with enable-fields excluding them, will also be removed. HOWEVER $dontCheckEnableFields set will allow enableFields-excluded pages to be included anyway - including extendToSubpages sections!

		 Returns the list with a comma in the end (if any pages selected!)
		 $begin is an optional integer that determines at which level in the tree to start collecting uid's. Zero means "start right away", 1 = 'next level and out'
		*/
		$depth=intval($depth);
		$begin=intval($begin);
		$id=intval($id);
		$theList="";
		$allFields = "uid,hidden,starttime,endtime,fe_group,extendToSubpages,doktype,php_tree_stop".$addSelectFields;
		if ($id && $depth>0)	{
			$query = "SELECT ".$allFields." FROM pages WHERE pid = $id AND NOT deleted AND doktype!=255 AND doktype!=6".$moreWhereClauses." ORDER BY sorting";	// "ORDER BY sorting" added 280201
			$res = mysql(TYPO3_db, $query);
			echo mysql_error();
			while ($row = mysql_fetch_assoc($res))	{
				if ($dontCheckEnableFields || $GLOBALS["TSFE"]->checkPagerecordForIncludeSection($row))	{
					if ($begin<=0)	{
						if ($dontCheckEnableFields || $GLOBALS["TSFE"]->checkEnableFields($row))	{
							$theList.=$row["uid"].",";
						}
					}
					if ($depth>1 && !$row["php_tree_stop"])	{
						$theList.=tslib_cObj::getTreeList($row["uid"], $depth-1, $begin-1, $dontCheckEnableFields, $addSelectFields, $moreWhereClauses);
					}
				}
			}
		}
//		debug($theList);
		return $theList;
	}
	function calc($val)	{
		$parts= t3lib_div::splitCalc($val,"+-*/");
		$value=0;
		reset($parts);
		while(list(,$part)=each($parts))	{
			$theVal = $part[1];
			$sign =  $part[0];
			if ((string)intval($theVal)==(string)$theVal)	{
				$theVal = intval($theVal);
			} else {
				$theVal =0;
			}
			if ($sign=="-")	{$value-=$theVal;}
			if ($sign=="+")	{$value+=$theVal;}
			if ($sign=="/")	{if (intval($theVal)) $value/=intval($theVal);}
			if ($sign=="*")	{$value*=$theVal;}
		}
		return $value;
	}
	function calcIntExplode($delim, $string)	{
		// This explodes a comma-list into an array where the values are parsed through intval();
		$temp = explode($delim,$string);
		while(list($key,$val)=each($temp))	{
			$temp[$key]=intval(tslib_cObj::calc($val));
		}
		return $temp;
	}
	function splitObj($value, $conf)	{
		$conf["token"]=$this->stdWrap($conf["token"],$conf["token."]);
		
		if ($conf["token"])	{
			$conf["max"]=intval($this->stdWrap($conf["max"],$conf["max."]));
			$conf["min"]=intval($this->stdWrap($conf["min"],$conf["min."]));
			
			$valArr=explode($conf["token"],$value);
				// calculate splitCount
			$splitCount = count($valArr);
			if ($conf["max"] && $splitCount>$conf["max"]) {
				$splitCount=$conf["max"];
			}
			if ($conf["min"] && $splitCount<$conf["min"]) {
				$splitCount=$conf["min"];
			}

			if ($conf["wrap"] || $conf["cObjNum"]) {
				$splitArr=array();
				$splitArr["wrap"]=$conf["wrap"];
				$splitArr["cObjNum"]=$conf["cObjNum"];
				$splitArr = $GLOBALS["TSFE"]->tmpl->splitConfArray($splitArr,$splitCount);
			}

			$content="";
			for($a=0;$a<$splitCount;$a++)	{
				$GLOBALS["TSFE"]->register["SPLIT_COUNT"]=$a;
				$value = "".$valArr[$a];
				$this->data[$this->currentValKey] = $value;
				if ($splitArr[$a][cObjNum]) {
					$objName=intval($splitArr[$a][cObjNum]);
					$value = $this->stdWrap($this->cObjGet($conf[$objName."."],$objName."."),$conf[$objName."."]);
				}
				if ($splitArr[$a][wrap]) {
					$value=$this->wrap($value,$splitArr[$a][wrap]);
				}
				$content.=$value;
			}
		}
		return $content;
	}
	function clearTSProperties ($TSArr,$propList)	{
		$list = explode(",",$propList);
		while(list(,$prop)=each($list))	{
			$prop = trim($prop);
			unset($TSArr[$prop]);
			unset($TSArr[$prop."."]);
		}
		return $TSArr;
	}
	function mergeTSRef($confArr,$prop)	{
		if (substr($confArr[$prop],0,1)=="<")	{
			$key = trim(substr($confArr[$prop],1));
			$cF = t3lib_div::makeInstance("t3lib_TSparser");
				// $name and $conf is loaded with the referenced values.
			$old_conf=$confArr[$prop."."];
			list($name, $conf) = $cF->getVal($key,$GLOBALS["TSFE"]->tmpl->setup);
			if (is_array($old_conf) && count($old_conf))	{
				$conf = $this->joinTSarrays($conf,$old_conf);
			}
			$confArr[$prop."."]=$conf;
		}
		return $confArr;
	}
	function joinTSarrays($conf,$old_conf)	{
		if (is_array($old_conf))	{
			reset($old_conf);
			while(list($key,$val)=each($old_conf))	{
				if (is_array($val))	{
					$conf[$key] = $this->joinTSarrays($conf[$key],$val);
				} else {
					$conf[$key] = $val;
				}
			}
		}
		return $conf;
	}
	function gifBuilderTextBox ($gifbuilderConf, $conf, $text)	{
			// This function creates a number of TEXT-objects in a Gifbuilder configuration in order to create a text-field like thing. Used with the script tslib/media/scripts/postit.inc
		$chars = intval($conf["chars"]) ? intval($conf["chars"]) : 20;
		$lineDist = intval($conf["lineDist"]) ? intval($conf["lineDist"]) : 20;
		$Valign = strtolower(trim($conf["Valign"]));
		$tmplObjNumber = intval($conf["tmplObjNumber"]);
		$maxLines = intval($conf["maxLines"]);
		
		if ($tmplObjNumber && $gifbuilderConf[$tmplObjNumber]=="TEXT")	{
			$textArr = $this->linebreaks($text,$chars,$maxLines);
			$angle = intval($gifbuilderConf[$tmplObjNumber."."]["angle"]);
			reset($textArr);
			while(list($c,$textChunk)=each($textArr))	{
				$index = $tmplObjNumber+1+($c*2);
					// Workarea
				$gifbuilderConf = $this->clearTSProperties($gifbuilderConf,$index);
				$rad_angle = 2*pi()/360*$angle;
				$x_d = sin($rad_angle)*$lineDist;
				$y_d = cos($rad_angle)*$lineDist;

				$diff_x_d=0;
				$diff_y_d=0;
				if ($Valign=="center")	{
					$diff_x_d = $x_d*count($textArr);
					$diff_x_d = $diff_x_d/2;
					$diff_y_d = $y_d*count($textArr);
					$diff_y_d = $diff_y_d/2;
				}


				$x_d = round($x_d*$c - $diff_x_d);
				$y_d = round($y_d*$c - $diff_y_d);

				$gifbuilderConf[$index] = "WORKAREA";
				$gifbuilderConf[$index."."]["set"] = $x_d.",".$y_d;
					// Text
				$index++;
				$gifbuilderConf = $this->clearTSProperties($gifbuilderConf,$index);
				$gifbuilderConf[$index] = "TEXT";
				$gifbuilderConf[$index."."] = $this->clearTSProperties($gifbuilderConf[$tmplObjNumber."."],"text");
				$gifbuilderConf[$index."."]["text"] = $textChunk;
			}
			$gifbuilderConf = $this->clearTSProperties($gifbuilderConf,$tmplObjNumber);
		}
		return $gifbuilderConf;
	}
	function URLqMark($url,$params)	{
		// checks if $url has a "?" in it and if not, a "?" is inserted between $url and $params, which are anyway concatenated and returned
		if ($params && !strstr($url,"?"))	{
			return $url."?".$params;
		} else {
			return $url.$params;
		}
	}
	function checkEmail($email)	{
		return ereg("^[A-Za-z0-9\._-]*[@][A-Za-z0-9\._-]*[\.].[A-Za-z0-9]*$",$email);
	}
	function getUpdateJS($dataArray, $formName, $arrPrefix, $fieldList, $stripSlashes=1)	{
		$JSPart="";
		$updateValues=t3lib_div::trimExplode(",",$fieldList);
		while(list(,$fKey)=each($updateValues))	{
			$value = $dataArray[$fKey];
			if (is_array($value))	{
				reset($value);
				while(list(,$Nvalue)=each($value))	{
					$Nvalue = stripslashes($Nvalue);
					if ($stripSlashes)	{$Nvalue = stripslashes($Nvalue);}
					$JSPart.="
	updateForm('".$formName."','".$arrPrefix."[".$fKey."][]',unescape('".rawurlencode($Nvalue)."'))";
				}
			
			} else {
				if ($stripSlashes)	{$value = stripslashes($value);}
				$JSPart.="
	updateForm('".$formName."','".$arrPrefix."[".$fKey."]',unescape('".rawurlencode($value)."'))";
			}
		}
		$JSPart='<script>'.$JSPart.'
</script>
';	
		$GLOBALS["TSFE"]->additionalHeaderData["JSincludeFormupdate"]='<SCRIPT LANGUAGE="JavaScript" SRC="'.$GLOBALS["TSFE"]->absRefPrefix.'t3lib/jsfunc.updateform.js"></SCRIPT>';
		return $JSPart;
	}
	function DBgetUpdate($table, $uid, $dataArr, $fieldList, $addSlashes=0)	{
		unset($dataArr["uid"]);	// uid can never be set
		$uid=intval($uid);
		if ($uid)	{
			$fieldList=implode(t3lib_div::trimExplode(",",$fieldList,1),",");
			$query="";
			$queryA=array();
			reset($dataArr);
			while(list($f,$v)=each($dataArr))	{
				if (t3lib_div::inList($fieldList,$f))	{
					$queryA[]=$f."='".($addSlashes?addslashes($v):$v)."'";
				}
			}
			if ($GLOBALS["TCA"][$table]["ctrl"]["tstamp"])	{
				$queryA[]=$GLOBALS["TCA"][$table]["ctrl"]["tstamp"]."=".time();
			}
			if (count($queryA))	{
				$query="UPDATE ".$table." SET ".implode($queryA,",")." WHERE uid=".$uid;
				return $query;
			}
		}
	}
	function DBgetDelete($table, $uid)	{
		$uid=intval($uid);
		if ($uid)	{
			if ($GLOBALS["TCA"][$table]["ctrl"]["delete"])	{
				$field=$GLOBALS["TCA"][$table]["ctrl"]["delete"];
				$query="UPDATE ".$table." SET ".$field."=1 WHERE uid=".$uid;
			} else {
				$query="DELETE FROM ".$table." WHERE uid=".$uid;
			}
			return $query;
		}
	}
	function DBgetInsert($table, $pid, $dataArr, $fieldList, $addSlashes=0)	{
		$fp=array();
		$vp=array();
		$extraList="pid";
		if ($GLOBALS["TCA"][$table]["ctrl"]["tstamp"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["tstamp"]; $dataArr[$field]=time(); $extraList.=",".$field;}
		if ($GLOBALS["TCA"][$table]["ctrl"]["crdate"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["crdate"]; $dataArr[$field]=time(); $extraList.=",".$field;}
		if ($GLOBALS["TCA"][$table]["ctrl"]["cruser_id"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["cruser_id"]; $dataArr[$field]=0; $extraList.=",".$field;}
		if ($GLOBALS["TCA"][$table]["ctrl"]["fe_cruser_id"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["fe_cruser_id"]; $dataArr[$field]=intval($GLOBALS["TSFE"]->fe_user->user["uid"]); $extraList.=",".$field;}
		if ($GLOBALS["TCA"][$table]["ctrl"]["fe_crgroup_id"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["fe_crgroup_id"]; list($dataArr[$field])=explode(",",$GLOBALS["TSFE"]->fe_user->user["usergroup"]); $dataArr[$field]=intval($dataArr[$field]); $extraList.=",".$field;}
		
		unset($dataArr["uid"]);	// uid can never be set
		if ($pid>=0)	{$dataArr["pid"]=$pid;}		// Set pid z 0 and the dataarr-pid will be used!
		$fieldList=implode(t3lib_div::trimExplode(",",$fieldList.",".$extraList,1),",");
		reset($dataArr);
		while(list($f,$v)=each($dataArr))	{
			if (t3lib_div::inList($fieldList,$f))	{
				$fp[]=$f;
				$vp[]=$addSlashes?addslashes($v):$v;
			}
		}
		return $this->DBcompileInsert($table,$fp,$vp);
	}
	function DBcompileInsert($table,$fp,$vp)	{
		$query = "INSERT INTO ".$table." (".implode($fp,",").") VALUES ('".implode($vp,"','")."')";
		return $query;
	}
	function DBmayFEUserEdit($table,$row, $feUserRow, $allowedGroups="",$feEditSelf=0)	{
		$groupList = $allowedGroups ? implode(array_intersect(t3lib_div::trimExplode(",",$feUserRow["usergroup"],1),t3lib_div::trimExplode(",",$allowedGroups,1)),",") : $feUserRow["usergroup"];
		$ok=0;
			// points to the field that allowes further editing from frontend if not set. If set the record is locked.
		if (!$GLOBALS["TCA"][$table]["ctrl"]["fe_admin_lock"] || !$row[$GLOBALS["TCA"][$table]["ctrl"]["fe_admin_lock"]])	{
				// points to the field (integer) that holds the fe_users-id of the creator fe_user
			if ($GLOBALS["TCA"][$table]["ctrl"]["fe_cruser_id"])	{
				$rowFEUser = intval($row[$GLOBALS["TCA"][$table]["ctrl"]["fe_cruser_id"]]);
				if ($rowFEUser && $rowFEUser==$feUserRow["uid"])	{
					$ok=1;
				}
			}
				// If $feEditSelf is set, fe_users may always edit them selves...
			if ($feEditSelf && $table=="fe_users" && !strcmp($feUserRow["uid"],$row["uid"]))	{
				$ok=1;
			}
				// points to the field (integer) that holds the fe_group-id of the creator fe_user's first group
			if ($GLOBALS["TCA"][$table]["ctrl"]["fe_crgroup_id"])	{
				$rowFEUser = intval($row[$GLOBALS["TCA"][$table]["ctrl"]["fe_crgroup_id"]]);
				if ($rowFEUser)	{
					if (t3lib_div::inList($groupList, $rowFEUser))	{
						$ok=1;
					}
				}
			}
		}
		return $ok;
	}
	function DBmayFEUserEditSelect($table,$feUserRow,$allowedGroups="",$feEditSelf=0)	{
			// Returns where-definition that selects user-editable records.
		$groupList = $allowedGroups ? implode(array_intersect(t3lib_div::trimExplode(",",$feUserRow["usergroup"],1),t3lib_div::trimExplode(",",$allowedGroups,1)),",") : $feUserRow["usergroup"];
		$OR_arr=array();
			// points to the field (integer) that holds the fe_users-id of the creator fe_user
		if ($GLOBALS["TCA"][$table]["ctrl"]["fe_cruser_id"])	{
			$OR_arr[]=$GLOBALS["TCA"][$table]["ctrl"]["fe_cruser_id"]."=".$feUserRow["uid"];
		}
			// points to the field (integer) that holds the fe_group-id of the creator fe_user's first group
		if ($GLOBALS["TCA"][$table]["ctrl"]["fe_crgroup_id"])	{
			$values = t3lib_div::intExplode(",",$groupList);
			while(list(,$theGroupUid)=each($values))	{
				if ($theGroupUid)	{$OR_arr[]=$GLOBALS["TCA"][$table]["ctrl"]["fe_crgroup_id"]."=".$theGroupUid;}
			}
		}
			// If $feEditSelf is set, fe_users may always edit them selves...
		if ($feEditSelf && $table=="fe_users")	{
			$OR_arr[]="uid=".intval($feUserRow["uid"]);
		}
		
		$whereDef=" AND 1=0";
		if (count($OR_arr))	{
			$whereDef=" AND (".implode($OR_arr," OR ").")";
			if ($GLOBALS["TCA"][$table]["ctrl"]["fe_admin_lock"])	{
				$whereDef.=" AND NOT ".$GLOBALS["TCA"][$table]["ctrl"]["fe_admin_lock"];
			}
		}
		return $whereDef;
	}
	function whereSelectFromList($field,$value)	{
		$command=addslashes($value);
		$where="(".$field." LIKE '%,".$command.",%' OR ".$field." LIKE '".$command.",%' OR ".$field." LIKE '%,".$command."' OR ".$field."='".$command."')";
		return $where;
	}	
	/**
	 * Generates a search where clause.
	 */
	function searchWhere($sw,$searchFieldList)	{
		$where="";
		if ($sw)	{
			$searchFields=explode(",",$searchFieldList);
			$kw=split("[ ,]",$sw);

			while(list(,$val)=each($kw))	{
				$val=trim($val);
				$where_p=array();
				if (strlen($val)>=2)	{
					reset($searchFields);
					while(list(,$field)=each($searchFields))	{
						$where_p[]=$field." LIKE '%".addslashes($val)."%'";
					}
				}
				if (count($where_p))	{
					$where.=" AND (".implode($where_p," OR ").")";
				}
			}
		}
		return $where;
	}
	function sendNotifyEmail($msg, $recipients, $cc, $email_from, $email_fromName="", $replyTo="")	{
			// Sends order emails:
		$headers=array();
		if ($email_from)	{$headers[]="From: ".$email_fromName." <".$email_from.">";}
		if ($replyTo)		{$headers[]="Reply-To: ".$replyTo;}

		$recipients=implode(t3lib_div::trimExplode(",",$recipients,1),",");
		
		$emailContent = trim($msg);
		if ($emailContent)	{
			$parts = split(chr(10),$emailContent,2);		// First line is subject
			$subject=trim($parts[0]);
			$plain_message=trim($parts[1]);
			
			if ($recipients)	mail ($recipients, $subject, $plain_message, implode($headers,chr(10)));
			if ($cc)	mail ($cc, $subject, $plain_message, implode($headers,chr(10)));
			return true;
		}		
	}
	function editPanel($content, $conf, $currentRecord="", $dataArr=array())	{
		global $TCA,$BE_USER;

			// If no backend user, return immediately
		if (!$GLOBALS["TSFE"]->beUserLogin)		{return $content;}
		
			// If a backend user is logged in, then go on...
		if ($conf["newRecordFromTable"])	{
			$currentRecord = $conf["newRecordFromTable"].":NEW";
			$conf["allow"]="new";
		}
		
		if (!$currentRecord)	$currentRecord=$this->currentRecord;
		if (!count($dataArr))	$dataArr=$this->data;
		list($table,$uid) = explode(":",$currentRecord);
		$mayEdit=0;
		
		if (!$conf["onlyCurrentPid"] || $dataArr["pid"]==$GLOBALS["TSFE"]->id)	{
				// Permissions:
			$types = t3lib_div::trimExplode(",",strtolower($conf["allow"]),1);
			$allow = array_flip($types);
			
			$perms = $GLOBALS["BE_USER"]->calcPerms($GLOBALS["TSFE"]->page);
			if ($table=="pages")	{
				if (count($GLOBALS["TSFE"]->config["rootLine"])==1)	{unset($allow["move"]); unset($allow["hide"]); unset($allow["delete"]);}	// rootpage!
				if (!($perms&2))	{unset($allow["edit"]);unset($allow["move"]);unset($allow["hide"]);}
				if (!($perms&4))	unset($allow["delete"]);
				if (!($perms&8))	unset($allow["new"]);
				if (count($allow))	$mayEdit=1;		// Can only display editbox if there are options in the menu
				$newUid = $uid;
			} else {
				$mayEdit = count($allow)&&($perms&16);
				if ($conf["newRecordFromTable"])	{
					$newUid=$GLOBALS["TSFE"]->id;
				} else {
					$newUid = -1*$uid;
				}
			}
		}		
				
//		debug($table);
//		debug($GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"]);
		if ($GLOBALS["TSFE"]->displayEditIcons && $table && $mayEdit)	{
			$GLOBALS["TSFE"]->set_no_cache();		// Special content is about to be shown, so the cache must be disabled.
			$formName = 'TSFE_EDIT_FORM_'.substr($GLOBALS["TSFE"]->uniqueHash(),0,4);
			$formTag = '<form name="'.$formName.'" action="'.getenv("REQUEST_URI").'" method="post" enctype="multipart/form-data" onSubmit="return TBE_EDITOR_checkSubmit(1);">';			// Old: index.php?'.getenv("QUERY_STRING")
			$sortField = $TCA[$table]["ctrl"]["sortby"];
			$labelField = $TCA[$table]["ctrl"]["label"];
			$hideField = $TCA[$table]["ctrl"]["enablecolumns"]["disabled"];
			$blackLine = $conf["line"]?'<img src=clear.gif width=1 height='.intval($conf["line"]).'><BR><table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor=black><tr><td><img src=clear.gif width=1 height=1></td></tr></table><BR>':'';

			$theCmd="";
			if (is_array($GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"]) && $GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"]["record"]==$currentRecord && !$GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"]["update_close"])	{
				$theCmd =$GLOBALS["HTTP_POST_VARS"]["TSFE_EDIT"]["cmd"];
			}
			
			switch($theCmd)	{
				case "edit":
				case "new":
					$tceforms = t3lib_div::makeInstance("t3lib_TCEforms_FE");
					$tceforms->prependFormFieldNames = "TSFE_EDIT[data]";
					$tceforms->prependFormFieldNames_file = "TSFE_EDIT_file";
					$tceforms->doSaveFieldName = "TSFE_EDIT[doSave]";
					$tceforms->formName = $formName;
					$tceforms->backPath = 'typo3/';
					$tceforms->RTEbgColor= "#ABBBB4";
					$tceforms->setFancyDesign();
					$tceforms->defStyle = "font-family:Verdana;font-size:10px;";
					$tceforms->edit_showFieldHelp = $GLOBALS["BE_USER"]->uc["edit_showFieldHelp"];
					$tceforms->helpTextFontTag='<font face="verdana,sans-serif" color="#333333" size=1>';
			
					$trData = t3lib_div::makeInstance("t3lib_transferData");
					$trData->fetchRecord($table,	($theCmd=="new"?$newUid:$dataArr["uid"]), ($theCmd=="new"?"new":"") );
					reset($trData->regTableItems_data);
					$processedDataArr = current($trData->regTableItems_data);
					$processedDataArr["uid"]=$theCmd=="new"?"NEW":$dataArr["uid"];
					$processedDataArr["pid"]=$theCmd=="new"?$newUid:$dataArr["pid"];

					$panel="";
					$buttons = '<input type="image" border=0 name="TSFE_EDIT[update]" src="'.$tceforms->backPath.'gfx/savedok.gif" hspace=2 width="21" height="16" title="'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["saveDoc"]).'">';
					$buttons.= '<input type="image" border=0 name="TSFE_EDIT[update_close]" src="'.$tceforms->backPath.'gfx/saveandclosedok.gif" hspace=2 width="21" height="16" title="'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["saveCloseDoc"]).'">';
					$buttons.= '<input type="image" border=0 name="TSFE_EDIT[cancel]" onClick="document.location=\''.getenv("REQUEST_URI").'\';return false;" src="'.$tceforms->backPath.'gfx/closedok.gif" hspace=2 width="21" height="16" title="'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["closeDoc"]).'">';
					$panel.=$tceforms->intoTemplate(array("ITEM"=>$buttons));		// Buttons top
					$panel.=$tceforms->getMainFields($table,$processedDataArr);
/*					$buttons='
					<input type="submit" name="TSFE_EDIT[update]" value="Update">
					<input type="submit" name="TSFE_EDIT[cancel]" value="Cancel">
					';
*/
					$hiddenF="";
					if ($theCmd=="new")	{
						$hiddenF.='<input type="hidden" name="TSFE_EDIT[data]['.$table.'][NEW][pid]" value="'.$newUid.'">';
						if ($table=="pages")	$hiddenF.='<input type="hidden" name="TSFE_EDIT[data]['.$table.'][NEW][hidden]" value="0">';		// If a new page is created in front-end, then show it by default!
					} else {
						$hiddenF.='<input type="hidden" name="TSFE_EDIT[record]" value="'.$currentRecord.'">';
						$hiddenF.='<input type="hidden" name="TSFE_EDIT[cmd]" value="edit">';
					}
					$hiddenF.='<input type="hidden" name="TSFE_EDIT[doSave]" value="0">';
					$panel.=$tceforms->intoTemplate(array("ITEM"=>$buttons.$hiddenF));	// Buttons AND hidden fields bottom.

					$panel=$formTag.$tceforms->wrapTotal($panel,$dataArr,$table)."</form>".($theCmd!="new"?$blackLine:"");
					$finalOut = $tceforms->printNeededJSFunctions_top().($conf["edit."]["displayRecord"]?$content:"").$panel.($theCmd=="new"?$blackLine:"").$tceforms->printNeededJSFunctions();
				break;
				default:
					$panel = "";
					if (isset($allow["toolbar"]))		$panel.=$GLOBALS["BE_USER"]->ext_makeToolBar().'<img src=clear.gif width=2 height=1>';
					if (isset($allow["edit"]))		$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/edit2.gif" width="11" height="12" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_editRecord").'" align="top">',$formName,"edit",$currentRecord);
					if (isset($allow["move"]) && $sortField)	{
						$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/button_up.gif" width="11" height="10" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_moveUp").'" align="top">',$formName,"up");
						$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/button_down.gif" width="11" height="10" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_moveDown").'" align="top">',$formName,"down");
					}
					if (isset($allow["hide"]) && $hideField)	{
						if ($dataArr[$hideField])	{
							$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/button_unhide.gif" width="11" height="10" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_unhide").'" align="top">',$formName,"unhide");
						} else {
							$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/button_hide.gif" width="11" height="10" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_hide").'" align="top">',$formName,"hide");
						}
					}
					if (isset($allow["new"]))	{
						if ($table=="pages")	{
							$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/new_page.gif" width="13" height="12" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_newSubpage").'" align="top">',$formName,"new",$currentRecord);
						} else {
							$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/new_record.gif" width="16" height="12" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_newRecordAfter").'" align="top">',$formName,"new",$currentRecord);
						}
					}
					if (isset($allow["delete"]))		$panel.=$this->editPanelLinkWrap('<img src="t3lib/gfx/delete_record.gif" width="12" height="12" vspace="1" hspace="2" border="0" title="'.$BE_USER->extGetLL("p_delete").'" align="top">',$formName,"delete");


//				Final				
					$panel='<tr><td bgColor="#ABBBB4">'.$panel.'</td>'.($conf["label"]?'<td nowrap bgColor="#F6F2E6"><font face=verdana size=1 color=black>&nbsp;'.sprintf($conf["label"],htmlspecialchars(t3lib_div::fixed_lgd($dataArr[$labelField],50))).'&nbsp;</font></td>':'').'</tr>';
					$panel=$formTag.'<input type="hidden" name="TSFE_EDIT[cmd]" value=""><input type="hidden" name="TSFE_EDIT[record]" value="'.$currentRecord.'">'.$panel.'</form>';
					$panel='<table border="0" cellpadding="0" cellspacing="0" width="100%">'.$panel.'</table>';
					$panel='<table border=0 cellpadding=1 cellspacing=0 bgcolor=black><tr><td>'.$panel.'</td></tr></table>';
						// add black line:
					$panel.=$blackLine;
					$finalOut = $content.$panel;
				break;
			}

			if ($conf["previewBorder"]) $finalOut = $this->editPanelPreviewBorder($table,$dataArr,$finalOut,$conf["previewBorder"]);
			return $finalOut;
		} else {
			return $content;
		}
	}
	function editIcons($content,$params, $conf=array(), $currentRecord="", $dataArr=array())	{
		global $BE_USER;

			// If no backend user, return immediately
		if (!$GLOBALS["TSFE"]->beUserLogin)		{return $content;}
		
			// Check incoming params:
		$rParts = explode(":",$currentRecord?$currentRecord:$this->currentRecord);
		list($table,$fieldList)=t3lib_div::trimExplode(":",$params,1);
		if (!$fieldList)	{
			$fieldList=$table;
			$table=$rParts[0];
		} else {
			if ($table!=$rParts[0])	return $content;	// If the table is set as the first parameter, and does not match the table of the current record, then just return.
		}

		// Check if allowed to edit content:
		$mayEdit=0;
		$dataArr=count($dataArr)?$dataArr:$this->data;	// If pages-record, should contain correct perms-field, if not, should contain correct pid value.
		
		if ($table=="pages")	{
			$mayEdit = $BE_USER->isAdmin()||$BE_USER->doesUserHaveAccess($dataArr,2)?1:0;
		} else {
			$mayEdit = $BE_USER->isAdmin()||$BE_USER->doesUserHaveAccess(t3lib_BEfunc::getRecord("pages",$dataArr["pid"]),16)?1:0;
		}

		if ($GLOBALS["TSFE"]->displayFieldEditIcons && $table && $mayEdit && $fieldList)	{
			$GLOBALS["TSFE"]->set_no_cache();		// Special content is about to be shown, so the cache must be disabled.
			$iconImg = '<img src="t3lib/gfx/edit2.gif" width="11" height="12" border="0" align=top title="'.htmlspecialchars($conf["iconTitle"]).'">';
			$nV=t3lib_div::GPvar("ADMCMD_view")?1:0;
			$icon = $this->editPanelLinkWrap_doWrap($iconImg,'typo3/alt_doc.php?edit['.$rParts[0].']['.$rParts[1].']=edit&columnsOnly='.rawurlencode($fieldList)."&noView=".$nV,implode(":",$rParts));
			if ($conf["beforeLastTag"])	{
				$cBuf = trim($content);
				$securCount=10;
				while($securCount && substr($cBuf,-1)==">")	{
					$cBuf = trim(ereg_replace("<[^<]*>$","",$cBuf));
					$securCount--;
				}
//				debug($cBuf);
				$content=strlen($cBuf)&&$securCount? substr($content,0,strlen($cBuf)).$icon.substr($content,strlen($cBuf)) : $content=$icon.$content;
			} else $content.=$icon;
		}
		return $content;
	}
	function editPanelLinkWrap($string,$formName,$cmd,$currentRecord="")	{
		$eFONPage = $GLOBALS["BE_USER"]->uc["TSFE_adminConfig"]["edit_editFormsOnPage"];
		$nV=t3lib_div::GPvar("ADMCMD_view")?1:0;
		if ($cmd=="edit" && !$eFONPage)	{
			$rParts = explode(":",$currentRecord);
			$out=$this->editPanelLinkWrap_doWrap($string,'typo3/alt_doc.php?edit['.$rParts[0].']['.$rParts[1].']=edit&noView='.$nV,$currentRecord);
		} elseif ($cmd=="new" && !$eFONPage)	{
			$rParts = explode(":",$currentRecord);
			if ($rParts[0]=="pages")	{
				$out=$this->editPanelLinkWrap_doWrap($string,'typo3/db_new.php?id='.$rParts[1].'&pagesOnly=1',$currentRecord);
			} else {
				$nPid = t3lib_div::testInt($rParts[1]) ? -$rParts[1] : $GLOBALS["TSFE"]->id;
				$out=$this->editPanelLinkWrap_doWrap($string,'typo3/alt_doc.php?edit['.$rParts[0].']['.$nPid.']=new&noView='.$nV,$currentRecord);
			}
		} else {
			$out='<a href="#" onClick="document.'.$formName.'[\'TSFE_EDIT[cmd]\'].value=\''.$cmd.'\'; document.'.$formName.'.submit(); return false;">'.$string.'</a>';
		}
		return $out;	
	}
	function editPanelLinkWrap_doWrap($string,$url,$currentRecord)	{
		if ($GLOBALS["BE_USER"]->uc["TSFE_adminConfig"]["edit_editNoPopup"] || $GLOBALS["BE_USER"]->extAdminConfig["module."]["edit."]["forceNoPopup"])	{
			$retUrl = getenv("REQUEST_URI");
			$rParts = explode(":",$currentRecord);
			if ($rParts[0]=="tt_content" && $this->parentRecordNumber>2)	{	// This parentRecordNumber is used to make sure that only elements 3- of ordinary content elements makes a "anchor" jump down the page.
				$retUrl.="#".$rParts[1];
			}
			return '<a href="'.$url.'&returnUrl='.rawurlencode($retUrl).'">'.$string.'</a>';
		} else {
			return '<a href="#" onClick="vHWin=window.open(\''.$url.'&returnUrl=close.html\',\'FEquickEditWindow\',\''.($GLOBALS["BE_USER"]->uc["edit_wideDocument"]?"width=670,height=500":"width=520,height=400").',status=0,menubar=0,scrollbars=1,resizable=1\');vHWin.focus();return false;">'.$string.'</a>';
		}
	}
	function editPanelPreviewBorder($table,$row,$content,$thick)	{
		$thick = t3lib_div::intInRange($thick,1,100);
		if ($this->isDisabled($table,$row))	{
			$content='<table border='.$thick.' cellpadding=0 cellspacing=0 bordercolor="#cccccc" width=100%><tr><td>'.$content.'</td></tr></table>';
		}
		return $content;
	}
	function isDisabled($table,$row)	{
		global $TCA;
		if (
			($TCA[$table][ctrl][enablecolumns][disabled] && $row[$TCA[$table][ctrl][enablecolumns][disabled]]) ||
			($TCA[$table][ctrl][enablecolumns][fe_group] && $GLOBALS["TSFE"]->simUserGroup && $row[$TCA[$table][ctrl][enablecolumns][fe_group]]==$GLOBALS["TSFE"]->simUserGroup) ||
			($TCA[$table][ctrl][enablecolumns][starttime] && $row[$TCA[$table][ctrl][enablecolumns][starttime]]>time() ) ||
			($TCA[$table][ctrl][enablecolumns][endtime] && $row[$TCA[$table][ctrl][enablecolumns][endtime]] && $row[$TCA[$table][ctrl][enablecolumns][endtime]]<time())
		)	return true;
	}
}







/** 
 * Rendering of framesets
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
class tslib_frameset {
	function make($setup)	{
		$content = '';
		if (is_array($setup))	{
			$sKeyArray=t3lib_TStemplate::sortedKeyList($setup);
			reset($sKeyArray);
			while(list(,$theKey)=each($sKeyArray))	{
				$theValue=$setup[$theKey];
				if (intval($theKey) && $conf=$setup[$theKey."."])	{
					switch($theValue)	{
						case "FRAME":
							$typeNum = intval($GLOBALS["TSFE"]->tmpl->setup[$conf["obj"]."."][typeNum]);
							if (!$conf["src"] && !$typeNum) 	{
								$typeNum = -1;
							}
							$content.='<FRAME'.$this->frameParams($conf,$typeNum).'>'.chr(10);
						break;
						case "FRAMESET":
							$frameset = t3lib_div::makeInstance("tslib_frameset");
							$content.=$frameset->make($conf).chr(10);
						break;
					}
				}
			}
			return '<FRAMESET'.$this->framesetParams($setup).'>'.chr(10).$content.'</FRAMESET>';
		}
	}
	function frameParams($setup, $typeNum)	{
		$paramStr = "";
		$name = $setup["obj"];
			// 		
		if ($GLOBALS["TSFE"]->config["config"]["simulateStaticDocuments"])	{
			$theCompURL="";
			$theCompURL.=$GLOBALS["TSFE"]->makeSimulFileName($GLOBALS["TSFE"]->page["title"],
				($GLOBALS["TSFE"]->page["alias"] ? $GLOBALS["TSFE"]->page["alias"] : $GLOBALS["TSFE"]->page["uid"]),
				intval($typeNum));
			if ($GLOBALS["TSFE"]->config["config"]["simulateStaticDocuments"]=="PATH_INFO")	{
				$theCompURL = str_replace(".","/",$theCompURL);
				$theCompURL = "index.php/".$theCompURL."/?";
			} else {
				$theCompURL.=".html?";
			}
		} else {
			$theCompURL = $GLOBALS["TSFE"]->config["mainScript"].'?id='.$GLOBALS["TSFE"]->page["uid"].'&type='.intval($typeNum);
		}
		// Add absRefPrefix if exists.
		$finalURL = $GLOBALS["TSFE"]->absRefPrefix.$theCompURL.($setup["options"]?'&'.$setup["options"]:'').$GLOBALS["TSFE"]->linkVars.$GLOBALS["TSFE"]->getMethodUrlIdToken.($GLOBALS["TSFE"]->no_cache?"&no_cache=1":"");
		$finalURL = $GLOBALS["TSFE"]->tmpl->removeQueryString($finalURL);
		if ($setup["src"]) {$paramStr.=' src="'.$setup["src"].'"';} else {$paramStr.=' src="'.$finalURL.'"';}
		if ($setup["name"]) {		$paramStr.=' name="'.$setup["name"].'"';	} else {$paramStr.=' name="'.$name.'"';}
		if ($setup["params"]) {	$paramStr.=' '.$setup["params"];	}
		return $paramStr;
	}
	function framesetParams($setup)	{
		$paramStr = "";
		if ($setup["cols"]) {		$paramStr.=' cols="'.$setup["cols"].'"';	}
		if ($setup["rows"]) {		$paramStr.=' rows="'.$setup["rows"].'"';	}
		if ($setup["params"]) {	$paramStr.=' '.$setup["params"];	}
		return $paramStr;
	}
}




/** 
 * Rendering of tables for offset
 *
 * @see	function OTABLE from tslib_cObj
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
class tslib_tableOffset	{
	var $tableParams = 'border=0 cellspacing=0 cellpadding=0';
	var $default_tableParams = 'border=0 cellspacing=0 cellpadding=0';
	var $tdParams = ' width=99% valign=top';

	function start($content,$offset)	{
		$valPairs = t3lib_div::intExplode(",",$offset.",,,,,");
	//	debug($valPairs);
		if ($valPairs[0] || $valPairs[1] || $valPairs[2] || $valPairs[3] || $valPairs[4] || $valPairs[5])	{
				// If width is defined AND there has been no change to the default table params, then extend them to a tablewidth of 1
			if ($valPairs[4] && $this->default_tableParams==$this->tableParams)	{$this->tableParams.=" width=1";}
				// Init:
			$this->begin = chr(10)."<TABLE ".$this->tableParams.">";
			$this->end = "</table>";
			$rows=array();
			$widthImg = "";
			$heightImg = "";
				// If width is required, set so bottom column will display for sure			
			if ($valPairs[4])	{
				if (!$valPairs[3])	$valPairs[3]=1; 
				$widthImg='<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$valPairs[4].' height=1>';
			}
				// If height is required, set so right column will display for sure
			if ($valPairs[5])	{
				if (!$valPairs[2])	$valPairs[2]=1;
				$valPairs[2]=1; $heightImg='<img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$valPairs[5].'>';
			}
			
				// First row:
			if ($valPairs[1])	{	// top
				$rows[1].= '<tr>';
				$rows[1].= '<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.($valPairs[0]?$valPairs[0]:1).' height='.$valPairs[1].'></td>';
				if ($valPairs[0])	$rows[1].= '<td></td>';
				if ($valPairs[2])	$rows[1].= '<td></td>';
				$rows[1].= '</tr>';
			}
				// Middle row:
			$rows[2].= '<tr>';
			if ($valPairs[0])	{$rows[2].= $valPairs[1] ? '<td></td>' : '<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$valPairs[0].' height=1></td>';}
			$rows[2].= '<td'.$this->tdParams.'>'.$content.'</td>';
			if ($valPairs[2])	{$rows[2].= $valPairs[3] ? '<td>'.$heightImg.'</td>' : '<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.$valPairs[2].' height='.($valPairs[5]?$valPairs[5]:1).'></td>';}
			$rows[2].= '</tr>';
				// Bottom row:
			if ($valPairs[3])	{	// bottom
				$rows[3].= '<tr>';
				if ($valPairs[0])	$rows[3].= '<td></td>';
				if ($valPairs[2])	$rows[3].= '<td>'.$widthImg.'</td>';
				$rows[3].= '<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width='.($valPairs[2]?$valPairs[2]:($valPairs[4]?$valPairs[4]:1)).' height='.$valPairs[3].'></td>';
				$rows[3].= '</tr>';
			}
//			debug($rows);
			return $this->begin.implode("",$rows).$this->end;
		} else return $content;
	}
}




/** 
 * Rendering of tables for content positioning
 *
 * @see function CTABLE from tslib_cObj
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
class tslib_controlTable	{
	var $offX = 0;		// offset, x
	var $offY = 0;		// offset, y

	var $tm = "";		// top menu
	var $lm = "";		// left menu
	var $rm = "";		// right menu
	var $bm = "";		// bottom menu
	var $content = "";	// content
	
	var $tmTDparams = 'valign=top';		// top menu TDparams
	var $lmTDparams = 'valign=top';		// left menu TDparams
	var $rmTDparams = 'valign=top';		// right menu TDparams
	var $bmTDparams = 'valign=top';		// bottom menu TDparams
	var $contentTDparams = 'valign=top';	// content TDparams

	var $cMl = 1;		// content margin, left
	var $cMr = 1;		// content margin, right
	var $cMt = 0;		// content margin, top
	var $cMb = 1;		// content margin, bottom

	var $contentW = 0;	// s�tter en lille gif-spacer nedest i content-framen
	
	var $tableParams = 'border=0 cellspacing=0 cellpadding=0';
	
	function start($offset,$cMargins)	{
		$offArr = t3lib_div::intExplode(",",$offset);
		$cMargArr = t3lib_div::intExplode(",",$cMargins);
		
	
	
		$cols = 0;
		$rows = 0;
		
		if ($this->lm) $cols++;
		if ($this->rm) $cols++;
		if ($cMargArr[0]) $cols++;
		if ($cMargArr[2]) $cols++;
		if ($cMargArr[1]||$cMargArr[3]||$this->tm||$this->bm||$this->content||$this->contentW) $cols++;
		
		if ($cMargArr[1]) $rows++;
		if ($cMargArr[3]) $rows++;
		if ($this->tm) $rows++;
		if ($this->bm) $rows++;
		if ($this->content) $rows++;
		if ($this->contentW) $rows++;
		if (!$rows && $cols) $rows=1;		// hvis der slet ingen r�kker er sat i midten men der trods alt er nogle kolonner

		if ($rows&&$cols)	{
			$res = chr(10)."<TABLE ".$this->tableParams.">";
				// top offset:
			if ($offArr[1])	{
				$xoff = $offArr[0] ? 1 : 0;
				if ($cols+$xoff > 1)	{$colspan =' colspan="'.($cols+$xoff).'"';}
				$res.= '<tr><td'.$colspan.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$offArr[1].'></td></tr>';
			}
				// The rows:
			if ($rows>1)	{$rowspan =' rowspan="'.($rows).'"';}
			$res.= '<tr>';
			if ($offArr[0])	{	$res.='<td'.$rowspan.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" height=1 width='.$offArr[0].'></td>';	}
			if ($this->lm)	{	$res.='<td'.$rowspan.' '.$this->lmTDparams.'>'.$this->lm.'</td>';		}
			if ($cMargArr[0])	{	$res.='<td'.$rowspan.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" height=1 width='.$cMargArr[0].'></td>';		}
				// content...
				
			$middle=Array();
			if ($this->tm)	{	$middle[]='<td '.$this->tmTDparams.'>'.$this->tm.'</td>';}
			if ($cMargArr[1])	{	$middle[]='<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$cMargArr[1].'></td>';}
			if ($this->content)	{	$middle[]='<td '.$this->contentTDparams.'>'.$this->content.'</td>';}
			if ($cMargArr[3])	{	$middle[]='<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" width=1 height='.$cMargArr[3].'></td>';}
			if ($this->bm)	{	$middle[]='<td '.$this->bmTDparams.'>'.$this->bm.'</td>';}
			if ($this->contentW)	{	$middle[]='<td><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" height=1 width='.$this->contentW.'></td>';}
			if (isset($middle[0]))	{$res.=$middle[0];}

				// venstre for content
			if ($cMargArr[2])	{	$res.='<td'.$rowspan.'><img src="'.$GLOBALS["TSFE"]->absRefPrefix.'clear.gif" height=1 width='.$cMargArr[2].'></td>';		}
			if ($this->rm)	{	$res.='<td'.$rowspan.' '.$this->rmTDparams.'>'.$this->rm.'</td>';		}
			$res.= '</tr>';

				// flere end de 2 r�kker
			$mCount = count($middle);
			for($a=1;$a<$mCount;$a++)	{
				$res.="<tr>".$middle[$a]."</tr>";
			}
			$res.="</TABLE>";
			return $res;
		}
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_content.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_content.php"]);
}

?>