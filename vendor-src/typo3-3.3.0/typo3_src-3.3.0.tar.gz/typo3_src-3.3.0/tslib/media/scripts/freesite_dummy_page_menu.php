<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * Dummy menu of templates/dummy pages on the FreeSite Application.
 *
 * This displays a menu with links to each dummy page set following the uid of the base template to use. Used for preview of the base templates.
 * Required: The Freesite Application
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



if (!is_object($this)) {
	die ("No cObj object present. This script must be included as a PHP_SCRIPT cObject in TypoScript!");
}



			// Template
		$pid = intval($conf["pid_templateArchive"]);
		$content="";
		
		$specialComment="";
		if ($pid)	{
				// Select templates in root
				// Does NOT take TSFE->showHiddenRecords into account!
			$query="SELECT * FROM sys_template WHERE pid=".$pid." AND NOT deleted AND NOT hidden AND NOT starttime AND NOT endtime ORDER BY sorting";
			$res = mysql(TYPO3_db,$query);
			echo mysql_error();
			while($row=mysql_fetch_assoc($res))	{
				if (!$firstUID) $firstUID=$row[uid];
				$key=$row["uid"];
				$val=$row["title"];
				$content.='<a target="testTemplate" href="'.$GLOBALS["TSFE"]->absRefPrefix.'index.php?id='.$GLOBALS["TSFE"]->id.'&based_on_uid='.$key.'">'.$val.'</a><BR>';
				$specialComment.='[globalVar= based_on_uid='.$key.']'.chr(10);
			}
				// Select subcategories of template folder.
			$query="SELECT * FROM pages WHERE pid=".$pid." AND NOT deleted AND NOT hidden AND NOT starttime AND NOT endtime AND NOT fe_group ORDER BY sorting";
			$page_res = mysql(TYPO3_db,$query);
			echo mysql_error();
			while($page_row=mysql_fetch_assoc($page_res))	{
					// Subcategory templates
				$query="SELECT * FROM sys_template WHERE pid=".$page_row["uid"]." AND NOT deleted AND NOT hidden AND NOT starttime AND NOT endtime ORDER BY sorting";
				$res = mysql(TYPO3_db,$query);
				echo mysql_error();
				while($row=mysql_fetch_assoc($res))	{
					if (!$firstUID) $firstUID=$row[uid];
					$key=$row["uid"];
					$val=$page_row["title"]." / ".$row["title"];
					$content.='<a target="testTemplate" href="'.$GLOBALS["TSFE"]->absRefPrefix.'index.php?id='.$GLOBALS["TSFE"]->id.'&based_on_uid='.$key.'">'.$val.'</a><BR>';
					$specialComment.='[globalVar= based_on_uid='.$key.']'.chr(10);
				}
			}
		}		

	$content.='
<!--

NOTE:
When updating the template archive, these TypoScript conditions should replace the current conditions found in the DUMMY PAGE test template:


'.$specialComment.'

-->
';	

?>