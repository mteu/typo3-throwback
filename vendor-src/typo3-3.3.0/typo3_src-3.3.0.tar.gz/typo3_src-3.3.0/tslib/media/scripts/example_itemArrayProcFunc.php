<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * This is an example of how to manipulate menu item arrays.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


		// This function basically adds the parent page to the sublevel but only if the sublevel is empty!

function user_itemArrayProcFuncTest($menuArr,$conf)	{
//	debug($menuArr);
	if ($conf["demoItemStates"])	{		// Used in the example of item states
		reset($menuArr);
		$c=0;
		$teststates=explode(",","NO,ACT,IFSUB,CUR,USR,SPC,USERDEF1,USERDEF2");
		while(list($k,$v)=each($menuArr))	{
			$menuArr[$k]["ITEM_STATE"]=$teststates[$c];
			$menuArr[$k]["title"].= ($teststates[$c] ? " [".$teststates[$c]."]" : "");
			$c++;
		}
	} else {	// used in the fake menu item example!
		if (!count($menuArr))	{		// There must be no menu items if we add the parent page to the submenu:
			$parentPageId = $conf["parentObj"]->id;	// id of the parent page
			$parentPageRow = $GLOBALS["TSFE"]->sys_page->getPage($parentPageId);	// ... and get the record...
			if (is_array($parentPageRow))	{	// ... and if that page existed (a row was returned) then add it! 
				$menuArr[]=$parentPageRow;	
			}
		}
	}
	return $menuArr;
}

function user_IProcFuncTest($I,$conf)	{
	$itemRow = $conf["parentObj"]->menuArr[$I["key"]];

		// Setting the document status content to the value of the page title on mouse over	
	$I["linkHREF"]["onMouseover"].='extraRollover(\''.rawurlencode($itemRow["title"]).'\');';
	$conf["parentObj"]->I = $I;
	$conf["parentObj"]->setATagParts();
	$I = $conf["parentObj"]->I;
	$I["parts"]["ATag_begin"]=$I["A1"];

	if ($conf["debug"])	{
			// Outputting for debug example:
		echo "ITEM: <h2>".$itemRow["uid"].": ".$itemRow["title"]."</h2>";
		debug($itemRow);
		debug($I);
		echo "<HR>";
	}
		// Returns:
	return $I;
}


?>