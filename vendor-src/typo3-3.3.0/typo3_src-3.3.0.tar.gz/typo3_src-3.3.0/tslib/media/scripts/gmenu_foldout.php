<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * GMENU_FOLDOUT extension classs
 *
 * Additional TypoScript parameters:
 * (See TSref document)
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class tslib_gmenu_foldout extends tslib_gmenu {
	var $GMENU_fixKey="foldout";
	
	var $WMarrowNO;
	var $WMarrowACT;
	var $WMimagesFlag;
	var $WMimageHTML;
	var $WMsubmenu;
	var $WMtableWrap;

	function extProc_init()	{
		$this->WMarrowNO="";
		$this->WMarrowACT="";
		$this->WMimagesFlag=0;
		$this->WMimageHTML ="";
		if (($this->mconf["arrowNO"]||$this->mconf["arrowNO."]) && ($this->mconf["arrowACT"]||$this->mconf["arrowACT."]))	{
			$this->WMarrowNO = $GLOBALS["TSFE"]->cObj->getImgResource($this->mconf["arrowNO"],$this->mconf["arrowNO."]);
			$this->WMarrowACT = $GLOBALS["TSFE"]->cObj->getImgResource($this->mconf["arrowACT"],$this->mconf["arrowACT."]);
			if (is_array($this->WMarrowACT) && is_array($this->WMarrowNO))	{
				$this->WMimagesFlag=1;
			}
		}
	}
	function extProc_beforeLinking($key)	{
		$this->I["addATagParams"]="";
		$this->WMsubmenu = $this->subMenu($this->I["uid"]);
		if (trim($this->WMsubmenu))	{
			$this->I["addATagParams"]=' onClick="GF_menu('.$key.');'.($this->mconf["dontLinkIfSubmenu"] ? " return false;" : "").'"';
		}
	}
	function extProc_afterLinking($key)	{
		$this->WMtableWrap = $this->mconf["dontWrapInTable"] ? '' : '<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0><TR><TD>|</TD></TR></TABLE>';

		if ($this->WMimagesFlag)	{
			$this->WMimageHTML='<img src="'.$GLOBALS["TSFE"]->absRefPrefix.$this->WMarrowNO[3].'" width="'.$this->WMarrowNO[0].'" height="'.$this->WMarrowNO[1].'" border="0" name="imgA'.$key.'"'.($this->mconf["arrowImgParams"]?' '.$this->mconf["arrowImgParams"]:'').'>';		
		} else {$this->WMimageHTML="";}

		if (strstr($this->I["theItem"], "###ARROW_IMAGE###"))	{
			$this->I["theItem"] = str_replace("###ARROW_IMAGE###", $this->WMimageHTML, $this->I["theItem"]);
		} else {
			$this->I["theItem"] = $this->WMimageHTML.$this->I["theItem"];
		}

		$this->WMresult.= '
<DIV class=clTop id=divTop'.($key+1).'>'.$this->tmpl->wrap($this->I["theItem"], $this->WMtableWrap).'
<DIV class=clSub id=divSub'.($key+1).'>
		'.$this->WMsubmenu.'
</DIV>
</DIV>';		// Originally a <BR> between the div-tags, but it seemed to break stuff.
	}
	function extProc_finish()	{
		$bHeight = t3lib_div::intInRange(($this->mconf["bottomHeight"]?$this->mconf["bottomHeight"]:100) ,0,3000);
		$bottomContent = $this->mconf["bottomContent"] ? $GLOBALS["TSFE"]->cObj->cObjGetSingle($this->mconf["bottomContent"],$this->mconf["bottomContent."], "/GMENU_FOLDOUT/.bottomContent") : "";
		$adjustTopHeights = intval($this->mconf["adjustItemsH"]);
		$adjustSubHeights = intval($this->mconf["adjustSubItemsH"]);
		$mWidth = t3lib_div::intInRange(($this->mconf["menuWidth"]?$this->mconf["menuWidth"]:170) ,0,3000);
		$mHeight = t3lib_div::intInRange(($this->mconf["menuHeight"]?$this->mconf["menuHeight"]:400) ,0,3000);
		$insertmColor= $this->mconf["menuBackColor"] ? 'BACKGROUND-COLOR: '.$this->mconf["menuBackColor"].'; layer-background-color: '.$this->mconf["menuBackColor"] : '';
		$insertBottomColor= $this->mconf["bottomBackColor"] ? 'BACKGROUND-COLOR: '.$this->mconf["bottomBackColor"].'; layer-background-color: '.$this->mconf["bottomBackColor"] : '';
		$menuOffset = t3lib_div::intExplode(",",$this->mconf["menuOffset"].",");
		$subOffset = t3lib_div::intExplode(",",$this->mconf["subMenuOffset"].",");

		$GLOBALS["TSFE"]->additionalHeaderData[].= "

<SCRIPT language=JavaScript1.2 type=text/javascript>
//This resize fix should be in the head, as early as possible for best results.
if(document.layers){ //NS4 resize fix.
    GFV_scrX= innerWidth; GFV_scrY= innerHeight;
    onresize= function(){if(GFV_scrX!= innerWidth || GFV_scrY!= innerHeight){history.go(0)} };
}
</SCRIPT>



<STYLE type=text/css>
#divCont {
	Z-INDEX: 1; LEFT: ".$menuOffset[0]."px; VISIBILITY: hidden; WIDTH: ".$mWidth."px; POSITION: absolute; TOP: ".$menuOffset[1]."px; HEIGHT: ".$mHeight."px
}
.clTop {
	Z-INDEX: 1; WIDTH: ".$mWidth."px; POSITION: absolute; ".$insertmColor."
}
.clSub {
	Z-INDEX: 1; LEFT: ".$subOffset[0]."px; WIDTH: ".$mWidth."px; POSITION: absolute; TOP: ".$subOffset[1]."px
}
.bottomLayer {
	Z-INDEX: 1; WIDTH: ".$mWidth."px; CLIP: rect(0px ".$mWidth."px ".$bHeight."px 0px); POSITION: absolute; HEIGHT: ".$bHeight."px; ".$insertBottomColor."
}

</STYLE>


<SCRIPT language=JavaScript type=text/javascript>
<!--
/***********************************************************************************
Foldoutmenu 1
Copyright (C) 1999 Thomas Brattli
This script is made by and copyrighted to Thomas Brattli at www.bratta.com
Visit for more great scripts. This may be used freely as long as this msg is intact!
I will also appriciate any links you could give me.
************************************************************************************
Modified for animation - Michael van Ouwerkerk (mvouwerkerk@hotmail.com) Feb 2001
***********************************************************************************/

/*** variables you can configure ***/

GFV_foldNumber=".$this->WMmenuItems."          //How many toplinks do you have?
GFV_foldTimer=".t3lib_div::intInRange(($this->mconf["foldTimer"]?$this->mconf["foldTimer"]:40) ,1,3000).";          //The timeout in the animation, these are milliseconds.
GFV_foldSpeed=".t3lib_div::intInRange($this->mconf["foldSpeed"],1,100).";           //How many steps in an animation?
GFV_stayFolded=".($this->mconf["stayFolded"] ? 'true' : 'false').";      //Stay open when you click a new toplink?
GFV_foldImg=".$this->WMimagesFlag.";             //Do you want images (if not set to 0 and remove the images from the body)?
GFV_currentFold=null, 
GFV_foldStep1=null, 
GFV_foldStep2=null, 
GFV_step=0, 
GFV_active=false //Don't change this one.


//This is the default image.
//Remember to change the actual images in the page as well, but remember to keep the name of the image.
var GFV_unImg=new Image();
GFV_unImg.src='".$GLOBALS["TSFE"]->absRefPrefix.$this->WMarrowNO[3]."';

var GFV_exImg=new Image();          //Making an image variable...
GFV_exImg.src='".$GLOBALS["TSFE"]->absRefPrefix.$this->WMarrowACT[3]."';   //...this is the source of the image that it changes to when the menu expands.

/*** There should be no need to change anything beyond this. ***/


//browsercheck...
function GF_checkBrowser(){
    this.opera= (navigator.userAgent.indexOf('Opera')>-1);
	this.ie4= (document.all && !document.getElementById);
	this.ie5= (document.all && document.getElementById && !this.opera);
	this.ns4= (document.layers && !document.getElementById);
	this.ns6= (!document.all && document.getElementById && !this.opera);
    this.mac= (navigator.userAgent.indexOf('Mac')>-1);
	this.bw= (this.ie5 || this.ie4 || this.ns4 || this.ns6 || this.opera)
	return this
}
bw= new GF_checkBrowser()

//object constructor...
function GF_makeMenu(obj,nest,adjustH){
	nest= (!nest)?'':'document.'+nest+'.';
	this.el= bw.ie4?document.all[obj]:bw.ns4?eval(nest+'document.'+obj):document.getElementById(obj);	
   	this.css= bw.ns4?this.el:this.el.style;
	this.ref= bw.ns4?this.el.document:document;		
	this.x= (bw.ns4||bw.opera)?this.css.left:this.el.offsetLeft;
	this.y= (bw.ns4||bw.opera)?this.css.top:this.el.offsetTop;
	this.height= (bw.ie4||bw.ie5||bw.ns6)?this.el.offsetHeight:bw.ns4?this.ref.height:bw.opera?this.css.pixelHeight:0;
    this.vis= GF_visible;
	this.hideIt= GF_hideIt;
    this.showIt= GF_showIt;
    this.moveIt= GF_moveIt;
    this.moveBy= GF_moveBy;
		// Added by Kasper Sk�rh�j:
	if (adjustH)	this.height = this.height+adjustH;
	return this
}
//object methods...
function GF_showIt(){this.css.visibility='visible'}
function GF_hideIt(){this.css.visibility='hidden'}
function GF_visible(){if(this.css.visibility=='visible' || this.css.visibility=='VISIBLE' || this.css.visibility=='show') return true;}
function GF_moveIt(x,y){this.x=x; this.y=y; this.css.left=this.x; this.css.top=this.y}
function GF_moveBy(x,y){this.moveIt(this.x+x,this.y+y)}

/************************************************************************************
These functions GF_menu, GF_doMove, and GF_placeAll open and close the menu.
************************************************************************************/
function GF_menu(num){

    //If GFV_stayFolded is false, one fold is open, and it's not the one you clicked, we enter this if structure.
	if(bw.bw && !GFV_active && !GFV_stayFolded && GFV_currentFold!=null && GFV_currentFold!=num){
        GFV_active= true
	
        //Adjusting the speed of the animation.
        GFV_foldStep1= oSub[num].height/GFV_foldSpeed
        GFV_foldStep2= oSub[GFV_currentFold].height/-GFV_foldSpeed

        //Setting the images correctly, showing the new sub.
        if(GFV_foldImg) oTop[num].ref['imgA'+num].src=GFV_exImg.src
        if(GFV_foldImg) oTop[GFV_currentFold].ref['imgA'+GFV_currentFold].src=GFV_unImg.src
        oSub[num].showIt()
		
        //Keeping track of what fold is opened, then do the move.
        var temp= GFV_currentFold
        GFV_currentFold= num
        GF_doMove(num+1,temp+1)
    }

    //In the simple cases, we enter this else if structure.
    else if(bw.bw && !GFV_active){
        GFV_active= true
	
        //If the sub is not visible, show it, change it's image, and expand it.
		if(!oSub[num].vis()){
			oSub[num].showIt()
			if(GFV_foldImg)oTop[num].ref['imgA'+num].src=GFV_exImg.src
            GFV_foldStep1=oSub[num].height/GFV_foldSpeed
            GFV_currentFold=num
            GF_doMove(num+1,null)
		}

        //If the sub is visible, change it's image and collapse it.
        else{
			if(GFV_foldImg)oTop[num].ref['imgA'+num].src=GFV_unImg.src
            GFV_foldStep2=oSub[num].height/-GFV_foldSpeed
            GFV_currentFold=null
            GF_doMove(null,num+1)
		}
	}
}
function GF_doMove(expand,collapse){
    GFV_step++
    if(expand!=null) for(var i=expand;i<oTop.length;i++){ oTop[i].moveBy(0,GFV_foldStep1) }
    if(collapse!=null) for(var i=collapse;i<oTop.length;i++){ oTop[i].moveBy(0,GFV_foldStep2) }

    //If the animation is not done yet, activate GF_doMove again.
    if(GFV_step<GFV_foldSpeed) setTimeout('GF_doMove('+expand+','+collapse+')',GFV_foldTimer)

    //Else clean up and bail out.
    else{
        GFV_step=0
        if(collapse!=null) oSub[collapse-1].hideIt()
        GF_placeAll()
    }
}

//This function places everything at the exact right place and signals that the animation is done.
function GF_placeAll(){
    for(var i=1;i<oTop.length;i++){ 
        if(oSub[i-1].vis()) oTop[i].moveIt(0,oTop[i-1].y+oTop[i-1].height+oSub[i-1].height) 
        else oTop[i].moveIt(0,oTop[i-1].y+oTop[i-1].height)
    }
    GFV_active= false
}
/*********************************************************************
The init function... there should be no need to change anything here.
*********************************************************************/
function GF_initFoldout(){

    //Making the object arrays...
	oTop= new Array()
	oSub= new Array()

    //Making the objects and hiding the subs...
    for(var i=1;i<=GFV_foldNumber+1;i++){
        oTop[i-1]= new GF_makeMenu('divTop'+i,'divCont',".$adjustTopHeights.");
        oSub[i-1]= new GF_makeMenu('divSub'+i,'divCont.document.divTop'+i, ".$adjustSubHeights.")
        oSub[i-1].hideIt()
    }

    //Positioning the top objects...
    oTop[0].moveIt(0,0)
	for(var i=1;i<oTop.length;i++){ oTop[i].moveIt(0,oTop[i-1].y+oTop[i-1].height) }

    //Making the containing menu object and showing it...
  	oCont= new GF_makeMenu('divCont')
  	oCont.showIt()
}

//If the browser is ok, the script is started onload...
if(bw.bw) ".$this->onLoadEventName."=GF_initFoldout;


if(bw.opera){ //Opera 5 resize fix.
    GFV_scrX= innerWidth; GFV_scrY= innerHeight;
//    document.onmousemove= function(){if(GFV_scrX<innerWidth-10 ||GFV_scrY<innerHeight-10 || GFV_scrX>innerWidth+10 ||GFV_scrY>innerHeight+10){location.reload();}};
    document.onmousemove= function(){if(GFV_scrX<innerWidth-10 ||GFV_scrY<innerHeight-10 || GFV_scrX>innerWidth+10 ||GFV_scrY>innerHeight+10){GFV_scrX= innerWidth; GFV_scrY= innerHeight;	GF_initFoldout();}};
}

//-->
</SCRIPT>

";

//			$GLOBALS["TSFE"]->divSection=implode($divLayers,chr(10));
		$GLOBALS["TSFE"]->divSection.= '
<DIV id=divCont><!-- These are the contents of the foldoutmenu. -->
		'.$this->tmpl->wrap($this->WMresult,$this->mconf["wrap"]).'
<DIV class=bottomLayer id=divTop'.($this->WMmenuItems+1).'>
	<DIV class=clSub id=divSub'.($this->WMmenuItems+1).'><!-- This is a cover layer, it should always be the last one, and does NOT count in your number of toplinks! --><!-- So if this one is divTop7, the GFV_foldNumber variable should be set to 6 --><!-- This layer covers up the last sub, so if the last sub gets too big, increase this layers size in the stylesheet. --><!-- There are tables with width="100%" around the toplinks, to force NS4 to use the real width specified for the toplinks in the stylesheet. -->
	</DIV>'.$this->tmpl->wrap($bottomContent, $this->WMtableWrap).'
</DIV>
</DIV><!-- Here ends the foldoutmenu. -->
		';
		return "";
	}
}

$GLOBALS["TSFE"]->tmpl->menuclasses.=",gmenu_foldout";


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["media/scripts/gmenu_foldout.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["media/scripts/gmenu_foldout.php"]);
}

?>