<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * GMENU_LAYERS extension classs
 *
 * Additional TypoScript parameters:
 * (See TSref document)
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class tslib_gmenu_layers extends tslib_gmenu {
	var $GMENU_fixKey="layers";
	var $divLayers=Array();
	
	var $WMx=0;
	var $WMy=0;
	var $WMxyArray=array();
	var $WMextraScript="";
	var $WMextraScript_RO="";
	var $WMlastKey="";
	var $WMrestoreScript="";
	var $WMactiveHasSubMenu="";
	var $WMactiveKey="";
	var $WMtheSubMenu;
	var $WMisSub;
	var $WMhideCode;
	var $WMonlyOnLoad=0;
	var $WMbordersWithin=array();

	function extProc_init()	{
		$this->WMfreezePrefix = $this->mconf["freezeMouseover"] ? "GL_" : "";
		$this->WMonlyOnLoad = ($this->mconf["displayActiveOnLoad"] && !$this->mconf["displayActiveOnLoad."]["onlyOnLoad"]);
		$this->WMbordersWithin = t3lib_div::intExplode(",",$this->mconf["bordersWithin"].",0,0,0,0,0");
	}
	function extProc_RO($key)	{
		if ($this->mconf["freezeMouseover"])	{$this->WMextraScript_RO = $this->I["theName"];}
	}
	function extProc_beforeLinking($key)	{
		if ($this->I["uid"])	{
			$this->WMtheSubMenu = $this->subMenu($this->I["uid"]);
			$this->WMisSub = trim($this->WMtheSubMenu) ? 1 : 0;
	
			if ($this->mconf["lockPosition_addSelf"])		{
				$this->WMy+=$this->I["val"]["output_h"]+intval($this->mconf["lockPosition_adjust"]);
				$this->WMx+=$this->I["val"]["output_w"]+intval($this->mconf["lockPosition_adjust"]);
			}
			
			if ($this->isActive($this->I["uid"]) && $this->mconf["displayActiveOnLoad"])	{	// orig: && $this->WMisSub, changed 210901
				$this->WMactiveHasSubMenu = $this->WMisSub;
				$this->WMactiveKey = "Menu".$key;
	
	

				$this->WMrestoreVars=trim('
var GLV_restoreImage = "'.$this->WMextraScript_RO.'";
var GLV_restoreMenu = "'.$this->WMactiveKey.'";
				');
				$this->WMrestoreScript='	GL_doTop(GLV_restoreMenu);'.($this->WMextraScript_RO?'
	over(GLV_restoreImage);
	GL_currentImage = GLV_restoreImage;':'');

				$this->WMextraScript='<script language="JavaScript" type="text/javascript">
<!--
	GL_restoreMenu();
//-->
</script>';
			}
	
			if ($this->WMisSub)	{
				$this->I["linkHREF"]["onMouseover"]='GL_doTop(\'Menu'.$key.'\');'.$this->I["linkHREF"]["onMouseover"];
				$event="GL_stopMove();";
				$this->I["linkHREF"]["onMouseout"].=$event;
			} else {
				$this->I["linkHREF"]["onMouseover"]='GL_hideAll();'.$this->I["linkHREF"]["onMouseover"];
				$event="GL_resetAll();";
				$this->I["linkHREF"]["onMouseout"].=$event;
			}
			
			$this->WMxyArray[] = "GLV_menuXY['Menu".$key."']= new Array(".$this->WMx.",".$this->WMy.");";
		}
	}
	function extProc_afterLinking($key)	{
		if ($this->I["uid"])	{
			if (!$this->I["spacer"] && $this->WMisSub)	{
				$exStyle=$this->mconf["layerStyle"] ? $this->mconf["layerStyle"] : 'position:absolute;visibility:hidden';
				if (trim($exStyle))	{
					$exStyle=" ".$exStyle;
				}
				$divStart = '<DIV id="Menu'.$key.'" style="z-index:'.($key+2).';'.$exStyle.'">';
				$divStop = '</div>';
				
				$this->divLayers[]= $divStart.$this->WMtheSubMenu.$divStop;
				$this->WMhideCode.='	GL_getObjCss("Menu'.$key.'").visibility = "hidden";
	';
				$this->WMlastKey = "Menu".$key;
			}
	
			if (!$this->mconf["lockPosition_addSelf"])		{
				$this->WMy+=$this->I["val"]["output_h"]+intval($this->mconf["lockPosition_adjust"]);
				$this->WMx+=$this->I["val"]["output_w"]+intval($this->mconf["lockPosition_adjust"]);
			}
		}
		$this->WMresult.=$this->I["theItem"];
	}
	function extProc_finish ()	{
		$dirL = $this->mconf["directionLeft"] ? '-GL_getObj(id).width' : '';
		$dirU = $this->mconf["directionUp"] ? '-GL_getObj(id).height' : '';
		if ($this->mconf["lockPosition"]=="x")	{
			$DoTop.='
		GLV_menuOn.left = GLV_menuXY[id][0]-('.intval($this->mconf["xPosOffset"]).')'.$dirL.';';
			if (intval($this->mconf["topOffset"]))	{
				$DoTop.='
		GLV_menuOn.top = '.intval($this->mconf["topOffset"]).$dirU.';';
			}
		} elseif (intval($this->mconf["xPosOffset"])) {
			$GLV_menuOn.='
		GLV_menuOn.left = GLV_x-('.intval($this->mconf["xPosOffset"]).')'.$dirL.';';
			$DoTop.='
		GLV_menuOn.left = GLV_x-('.intval($this->mconf["xPosOffset"]).')'.$dirL.';';
			if (intval($this->mconf["topOffset"]))	{
				$DoTop.='
		GLV_menuOn.top = '.intval($this->mconf["topOffset"]).$dirU.';';
			}
		}
		if ($this->mconf["lockPosition"]=="y")	{
			$DoTop.='
		GLV_menuOn.top = GLV_menuXY[id][1]-('.intval($this->mconf["yPosOffset"]).')'.$dirU.';';
			if (intval($this->mconf["leftOffset"]))	{
				$DoTop.='
		GLV_menuOn.left = '.intval($this->mconf["leftOffset"]).$dirL.';';
			}
		} elseif (intval($this->mconf["yPosOffset"]))	{
			$GLV_menuOn.='
		GLV_menuOn.top = GLV_y-('.intval($this->mconf["yPosOffset"]).')'.$dirU.';';
			$DoTop.='
		GLV_menuOn.top = GLV_y-('.intval($this->mconf["yPosOffset"]).')'.$dirU.';';
			if (intval($this->mconf["leftOffset"]))	{
				$DoTop.='
		GLV_menuOn.left = '.intval($this->mconf["leftOffset"]).$dirL.';';
			}
		}
		// BordersWithIn:
		$DoTop.=$this->extCalcBorderWithin('left',$this->WMbordersWithin[0]);
		$DoTop.=$this->extCalcBorderWithin('top',$this->WMbordersWithin[1]);
		$DoTop.=$this->extCalcBorderWithin('right',$this->WMbordersWithin[2]);
		$DoTop.=$this->extCalcBorderWithin('bottom',$this->WMbordersWithin[3]);
		$DoTop.=$this->extCalcBorderWithin('left',$this->WMbordersWithin[4]);
		$DoTop.=$this->extCalcBorderWithin('top',$this->WMbordersWithin[5]);
		
		
		if ($this->mconf["freezeMouseover"])	{
		$GLOBALS["TSFE"]->JSCode.= '			

// Alternative rollover/out functions for use with GMENU_LAYER
function GL_over(name)	{
	if (version == "n3" && document[name]) {
		if (GL_currentImage!=null) document[GL_currentImage].src = eval(GL_currentImage+"_n.src");
		document[name].src = eval(name+"_h.src");
		GL_currentImage= name;
	}
}
function GL_out(name)	{
}
';	
		}

		$GLOBALS["TSFE"]->JSCode.= '			
var GLV_menuOn;
var GLV_curLayerWidth=0;
var GLV_curLayerHeight=0;
var GLV_curLayerX=0;
var GLV_curLayerY=0;
var GLV_x=0;
var GLV_y=0;
var GLV_menuOn = null;
var GLV_gap='.t3lib_div::intInRange($this->mconf["hideMenuWhenNotOver"],0,600).';
var GLV_currentLayer = null;
var GLV_hasBeenOver=0;
var GLV_doReset=false;
var GL_currentImage = null;
var GLV_menuXY = new Array();
'.implode(chr(10),$this->WMxyArray).'
'.$this->WMrestoreVars.'

	//browsercheck...
function GL_checkBrowser(){
	this.dom= (document.getElementById);
	this.op=  (navigator.userAgent.indexOf("Opera")>-1);
	this.ie4= (document.all && !this.dom && !this.op);
	this.ie5= (document.all && this.dom && !this.op);
	this.ns4= (document.layers && !this.dom);
	this.ns5= (!document.all && this.dom && !this.op);
	this.ns6= (this.ns5);
	this.bw=  (this.ie4 || this.ie5 || this.ns4 || this.ns6 || this.op);
	return this;
}
bw= new GL_checkBrowser();
	//NS4 resize fix.
if(document.layers){
    scrX= innerWidth; scrY= innerHeight;
    onresize= function()	{if(scrX!= innerWidth || scrY!= innerHeight)	{history.go(0);}};
}
	//Returns css
function GL_getObjCss(obj){								
	return bw.dom? document.getElementById(obj).style:bw.ie4?document.all[obj].style:bw.ns4?document.layers[obj]:0;
};
function GL_isObjCss(obj){								
	flag = bw.dom? document.getElementById(obj):bw.ie4?document.all[obj]:bw.ns4?document.layers[obj]:0;
	if (flag)	return true;
};
function GL_getObj(obj){
//	nest= (!nest)?"":"document."+nest+".";
	nest="";
	this.el= bw.ie4?document.all[obj]:bw.ns4?eval(nest+"document."+obj):document.getElementById(obj);	
   	this.css= bw.ns4?this.el:this.el.style;
	this.ref= bw.ns4?this.el.document:document;		
	this.x= (bw.ns4||bw.op)?this.css.left:this.el.offsetLeft;
	this.y= (bw.ns4||bw.op)?this.css.top:this.el.offsetTop;
	this.height= (bw.ie4||bw.ie5||bw.ns6)?this.el.offsetHeight:bw.ns4?this.ref.height:bw.op?this.css.pixelHeight:0;
	this.width= (bw.ie4||bw.ie5||bw.ns6)?this.el.offsetWidth:bw.ns4?this.ref.width:bw.op?this.css.pixelWidth:0;
	return this;
}
	//Capturing mousemove
function GL_getMouse(e) {
	GLV_x= (bw.ns4||bw.ns5)?e.pageX:(bw.ie4||bw.op)?event.x:(event.x-2)+document.body.scrollLeft;
	GLV_y= (bw.ns4||bw.ns5)?e.pageY:(bw.ie4||bw.op)?event.y:(event.y-2)+document.body.scrollTop;

	if (GLV_menuOn!=null){	'.$GLV_menuOn.'
	}
//	status = (GLV_x+GLV_gap-GLV_curLayerX) + " | " + (GLV_y+GLV_gap-GLV_curLayerY);
	if (GLV_gap && GLV_currentLayer!=null)	{
		if (	GLV_x+GLV_gap-GLV_curLayerX <0 || GLV_y+GLV_gap-GLV_curLayerY <0 || GLV_curLayerX+GLV_curLayerWidth+GLV_gap-GLV_x <0 || GLV_curLayerY+GLV_curLayerHeight+GLV_gap-GLV_y <0)	{
			if (GLV_hasBeenOver)	{GL_resetAll();}
		} else {
			GLV_hasBeenOver=1;
		}
	}
}
function GL_hideAll() {
	GLV_doReset = false;
	GLV_currentLayer = null;
	if (GL_isObjCss("'.$this->WMlastKey.'") && GL_getObjCss("'.$this->WMlastKey.'"))	{
'.$this->WMhideCode.'
	}
	'.(($this->mconf["freezeMouseover"] && $this->mconf["freezeMouseover."]["alwaysKeep"]) ? '' : 'if (GL_currentImage!=null) document[GL_currentImage].src = eval(GL_currentImage+"_n.src");
	').'GLV_hasBeenOver=0;
}
function GL_doResetAll() {
	if (GLV_doReset) {
		GLV_doReset = false;
		GL_hideAll();
		'.($this->WMonlyOnLoad ? 'GL_restoreMenu();' : '').'
	}
}
function GL_resetAll() {
	if (!GLV_doReset) {
		GLV_doReset = true;
		setTimeout(\'GL_doResetAll()\','.intval($this->mconf["hideMenuTimer"]?$this->mconf["hideMenuTimer"]:"0").');
	}
}
function GL_stopMove() { 
	GLV_menuOn = null;	
}
function GL_doTop(id) { 
	GL_hideAll();
	if (GL_isObjCss(id))	{
		GLV_menuOn = GL_getObjCss(id);
		GLV_menuOn.visibility = "visible";
'.$DoTop.'

		var layerObj = GL_getObj(id);
		GLV_curLayerHeight = layerObj.height;
		GLV_curLayerWidth = layerObj.width;
		GLV_curLayerX = layerObj.x;
		GLV_curLayerY  = layerObj.y;
		GLV_currentLayer = id;
		GLV_hasBeenOver=0;
	}
}
function GL_initLayers() {
	if(bw.ns4) document.captureEvents(Event.MOUSEMOVE);
	document.onmouseup = GL_mouseUp
	document.onmousemove= GL_getMouse;
//	GL_hideAll();
}
function GL_mouseUp(e) {
	GLV_doReset = false;
	'.($this->mconf["dontHideOnMouseUp"]?"// ":"").'GL_hideAll();
}
function GL_restoreMenu() {
'.$this->WMrestoreScript.'
}

//If the browser is ok, the script is started onload...
if(bw.bw) '.$this->onLoadEventName.'=GL_initLayers;
';			

		$GLOBALS["TSFE"]->divSection.=implode($this->divLayers,chr(10));
		return $this->tmpl->wrap($this->WMresult,$this->mconf["wrap"]).$this->WMextraScript;
	}
	function extCalcBorderWithin($kind,$integer)	{
		if ($integer)	{
			switch($kind)	{
				case "right":
				case "bottom":
					$add="";
					if ($kind=="right")		{$add='GL_getObj(id).width'; $key = "left";}
					if ($kind=="bottom")	{$add='GL_getObj(id).height'; $key = "top";}
					$str = '
		if (parseInt(GLV_menuOn.'.$key.')+'.$add.'>'.$integer.') GLV_menuOn.'.$key.'='.$integer.'-'.$add.';';
				break;
				default:
					$str = '
		if (parseInt(GLV_menuOn.'.$kind.')<'.$integer.') GLV_menuOn.'.$kind.'='.$integer.';';
				break;
			}
		}
		return $str;
	}
}

$GLOBALS["TSFE"]->tmpl->menuclasses.=",gmenu_layers";

if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["media/scripts/gmenu_layers.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["media/scripts/gmenu_layers.php"]);
}

?>