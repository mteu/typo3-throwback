<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * USER cObject EXAMPLE FILE
 *
 * This is an example of how to use your own functions and classes directly from Typo3.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */





// TEST FILE: call function from TypoScript

function user_reverseString($content,$conf)	{
	$content = strrev($content);
	if ($conf["uppercase"])	{
		$content=strtoupper($content);
	}
	return $content;
}
function user_printTime($content,$conf)	{
	return '<font color=red>Dynamic time: '.date("H:i:s").'</font><BR>';
}



// TEST FILE: call method in class from TypoScript
class user_various	{
	var $cObj;		// Reference to the calling cObj set from TypoScript
	
	
		// Testing stdWrap
	function reverseString($content,$conf)	{
		$content = strrev($content);
		if ($conf["uppercase"])	{
			$content=$this->cObj->caseshift($content,"upper");
		}
		if ($conf["typolink"])	{
			$content=$this->cObj->getTypoLink($content,$conf["typolink"]);
		}
		return $content;
	}
	
		// Testing USER cObject:
	function listContentRecordsOnPage($content,$conf)	{
		$query = "SELECT header FROM tt_content WHERE pid=".$GLOBALS["TSFE"]->id.$this->cObj->enableFields("tt_content")." ORDER BY sorting";
		if ($conf["reverseOrder"])	$query.=" DESC";
		$output="This is the query: <strong>".$query."</strong><BR><BR>";
		return $output.$this->selectThem($query);
	}
	function selectThem($query)	{
		$res = mysql(TYPO3_db,$query);
		$output=array();
		while($row=mysql_fetch_assoc($res))	{
			$output[]=$row["header"];
		}
		return implode($output,"<BR>");
	}
}

?>