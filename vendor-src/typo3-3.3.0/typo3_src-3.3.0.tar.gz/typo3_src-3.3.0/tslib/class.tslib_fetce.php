<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Form-data processing
 *
 * included from index_ts.php
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class tslib_feTCE	{

	var $extScripts=array();
	var $extScriptsConf=array();
	var $newData=array();
	var $extraList = "pid";

	function start($data,$FEData)	{
		reset($data);
		while(list($table,$id_arr)=each($data))	{
			t3lib_div::loadTCA($table);
			if (is_array($id_arr))	{
				$sep=$FEData[$table."."]["separator"]?$FEData[$table."."]["separator"]:chr(10);
				reset($id_arr);
				while(list($id,$field_arr)=each($id_arr))	{
					$this->newData[$table][$id]=Array();
					if (strstr($id,"NEW"))	{		// NEW
							// Defaults:
						if ($FEData[$table."."]["default."])	{
							$this->newData[$table][$id] = $FEData[$table."."]["default."];
						}
						if ($FEData[$table."."]["autoInsertPID"]) {
							$this->newData[$table][$id]["pid"] = intval($GLOBALS["TSFE"]->page[uid]);
						}
							// Insert external data:
						if (is_array($field_arr))	{
							reset($field_arr);
							while(list($field,$value)=each($field_arr))	{
								if ($FEData[$table."."]["allowNew."][$field])	{
									if (is_array($value)) {
										$this->newData[$table][$id][$field] = implode($sep,$value);
									} else {
										$this->newData[$table][$id][$field] = $value;
									}
								}
							}
						}
							// Double post check
						$dPC_field = $FEData[$table."."]["doublePostCheck"];
						if (is_array($this->newData[$table][$id]) && $dPC_field) {
							$doublePostCheckKey = $this->calcDoublePostKey($this->newData[$table][$id]);
							if ($this->checkDoublePostExist($table,$dPC_field,$doublePostCheckKey))	{
								unset($this->newData[$table][$id]);	// Unsetting the whole thing, because it's not going to be saved.
								$GLOBALS["TT"]->setTSlogMessage("'FEData': Submitted record to table $table was doublePosted (key: $doublePostCheckKey). Nothing saved.",2);
							} else {
								$this->newData[$table][$id][$dPC_field] = $doublePostCheckKey;	// Setting key value
								$this->extraList.=",".$dPC_field;
							}
						}
					} else {		// EDIT
							// Insert external data:
						if (is_array($field_arr))	{
							reset($field_arr);
							while(list($field,$value)=each($field_arr))	{
								if ($FEData[$table."."]["allowEdit."][$field])	{
									if (is_array($value)) {
										$this->newData[$table][$id][$field] = implode($sep,$value);
									} else {
										$this->newData[$table][$id][$field] = $value;
									}
								}
							}
						}
							// Internal Override
						if (is_array($FEData[$table."."]["overrideEdit."]))	{
							reset($FEData[$table."."]["overrideEdit."]);
							while(list($field,$value)=each($FEData[$table."."]["overrideEdit."]))	{
								$this->newData[$table][$id][$field] = $value;
							}
						}
					}
					if ($FEData[$table."."]["userIdColumn"]) {
						$this->newData[$table][$id][$FEData[$table."."]["userIdColumn"]] = intval($GLOBALS["TSFE"]->fe_user->user[uid]);
					}
				}
				$incFile = $GLOBALS["TSFE"]->tmpl->getFileName($FEData[$table."."]["processScript"]);
				if ($incFile)	{
					$this->extScripts[$table]=$incFile;
					$this->extScriptsConf[$table]=$FEData[$table."."]["processScript."];
				}
			}
		}
	}
	function checkDoublePostExist($table,$doublePostField,$key)	{
		$query = "SELECT count(*) FROM ".$table." WHERE ".$doublePostField."=".$key;
		$res = mysql(TYPO3_db,$query);
		echo mysql_error();
		$row = mysql_fetch_row($res);
		return $row[0];
	}
	function calcDoublePostKey($array)	{
		ksort($array);	// Sorting by key
		$doublePostCheckKey = hexdec(substr(md5(serialize($array)),0,8));	// Making key
		return $doublePostCheckKey;
	}
	function includeScripts()	{
		reset($this->extScripts);
		while(list($incFile_table,$incFile)=each($this->extScripts))	{
			if (@is_file($incFile) && (!$GLOBALS["TYPO3_CONF_VARS"]["FE"]["noPHPscriptInclude"] || substr($incFile,0,14)=="media/scripts/"))	{
				include($incFile);	// Always start the incFiles with a check of the object fe_tce.  is_object($this);
				$GLOBALS["TT"]->setTSlogMessage("Included ".$incFile,0);
			} else $GLOBALS["TT"]->setTSlogMessage("'".$incFile."' was not found!",2);
		}
	}
	function getNEWinsert($table, $dataArr)	{
		$fp=array();
		$vp=array();
		$extraList=$this->extraList;
		if ($GLOBALS["TCA"][$table]["ctrl"]["tstamp"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["tstamp"]; $dataArr[$field]=time(); $extraList.=",".$field;}
		if ($GLOBALS["TCA"][$table]["ctrl"]["crdate"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["crdate"]; $dataArr[$field]=time(); $extraList.=",".$field;}
		if ($GLOBALS["TCA"][$table]["ctrl"]["cruser_id"])	{$field=$GLOBALS["TCA"][$table]["ctrl"]["cruser_id"]; $dataArr[$field]=0; $extraList.=",".$field;}
		
		unset($dataArr["uid"]);	// uid can never be set
		reset($dataArr);
		while(list($f,$v)=each($dataArr))	{
			if (t3lib_div::inList($extraList,$f) || isset($GLOBALS["TCA"][$table]["columns"][$f]))	{
				$fp[]=$f;
				$vp[]=$v;
			}
		}
		return $this->getInsert($table,$fp,$vp);
	}
	function getInsert($table,$fp,$vp)	{
		$query = "INSERT INTO ".$table." (".implode($fp,",").") VALUES ('".implode($vp,"','")."')";
		return $query;
	}
	function clear_cacheCmd($cacheCmd)	{
		$cacheCmd = intval($cacheCmd);
		if ($cacheCmd)	{
			$res = mysql(TYPO3_db,"DELETE FROM cache_pages WHERE page_id=".$cacheCmd);
			if ($cacheCmd==intval($GLOBALS["TSFE"]->id))	{	// Setting no_cache true if the cleared-cache page is the current page!
				$GLOBALS["TSFE"]->set_no_cache();
			}
		}
	}
	function getConf($table)	{
		return $this->extScriptsConf[$table];
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_fetce.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_fetce.php"]);
}

?>