<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 *
 * Shows a picture...
 *
 * Input vars:
 *
 * file, width, height, effects, frame
 * bodyTag, title, wrap, md5
 *
 * @author		Kasper Sk�rh�j	<kasper@typo3.com>
 */

// *******************************
// Set error reporting 
// *******************************
error_reporting (E_ALL ^ E_NOTICE); 




// ***********************
// Paths are setup
// ***********************
define("TYPO3_OS", stristr(PHP_OS,"win")&&!stristr(PHP_OS,"darwin")?"WIN":"");
define("TYPO3_MODE","FE");
define("PATH_thisScript",
	TYPO3_OS=="WIN" ?
	str_replace('//','/',str_replace('\\','/', $HTTP_SERVER_VARS["PATH_TRANSLATED"]?$HTTP_SERVER_VARS["PATH_TRANSLATED"]:getenv("PATH_TRANSLATED"))) :
	(php_sapi_name()=="cgi"?(getenv("PATH_TRANSLATED")?getenv("PATH_TRANSLATED"):getenv("SCRIPT_FILENAME")):$HTTP_SERVER_VARS["PATH_TRANSLATED"])
);
define("PATH_t3lib", "t3lib/");
define("PATH_tslib", "tslib/");
define("PATH_typo3conf", "typo3conf/");	

include_once(PATH_t3lib."class.t3lib_div.php");
include_once(PATH_t3lib."class.t3lib_stdgraphic.php");

// ******************
// Including config
// ******************
include(PATH_t3lib."config_default.php");
if (!defined ("TYPO3_db")) 	die ("The configuration file was not included.");






// ***************************
// Script Classes
// ***************************
class SC_tslib_showpic {
	var $content;
	
	function init()	{
		global $id,$doc,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$HTTP_POST_FILES,$MOD_MENU,$MCONF,$MOD_SETTINGS,$CLIENT,$TYPO3_CONF_VARS,$SET;
		global $file, $width, $height, $sample, $alternativeTempPath, $effects, $frame, $bodyTag, $title, $wrap, $md5;
		
		t3lib_div::setGPvars("file, width, height, sample, alternativeTempPath, effects, frame, bodyTag, title, wrap, md5");
		
		
		// ***********************
		// Check parameters
		// ***********************
			// If no file-param is given, we must exit
		if (!$file)	{
			die("Parameter Error: No file given.");
		}
		
			// Chech md5-checksum: If this md5-value does not match the one submitted, then we fail... (this is a kind of security that somebody don't just hit the script with a lot of different parameters
		$md5_value = md5($file."|".$width."|".$height."|".$effects."|");
		if ($md5_value!=$md5) {
			die("Parameter Error: Wrong parameters sent.");
		}
		
		// ***********************
		// Check the file. If must be in a directory beneath the dir of this script...
		// $file remains unchanged, because of the code in stdgraphic, but we do check if the file exists within the current path 
		// ***********************
		
		$test_file=dirname(PATH_thisScript)."/".$file;
		if (strstr($test_file,"\\") || strstr($test_file,"..") && strstr($test_file,"//"))	{
			die("Parameter Error: No valid filepath");
		}
		if (!@is_file($test_file))	{
			die("The given file was not found");
		}

	}
	function main()	{
		global $id,$doc,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$HTTP_POST_FILES,$MOD_MENU,$MCONF,$MOD_SETTINGS,$CLIENT,$TYPO3_CONF_VARS,$SET;
		global $file, $width, $height, $sample, $alternativeTempPath, $effects, $frame, $bodyTag, $title, $wrap;

		// ***********************
		// Functions and classes
		// ***********************
		$img = t3lib_div::makeInstance("t3lib_stdGraphic");
		$img->mayScaleUp = 0;
		$img->init();
		if ($sample)	{$img->scalecmd = "-sample";}
		if ($alternativeTempPath && t3lib_div::inList($GLOBALS["TYPO3_CONF_VARS"]["FE"]["allowedTempPaths"],$alternativeTempPath))	{
			$img->tempPath = $alternativeTempPath;
		}
		if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["enable_typo3temp_db_tracking"])	{
				// Need to connect to database, because this may be used.
			mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password);
		}
		
		// ***********************
		// Initialization
		// ***********************
		
		if (strstr($width.$height, "m")) {$max="m";} else {$max="";}
		
		$height = t3lib_div::intInRange($height,0,1000);
		$width = t3lib_div::intInRange($width,0,1000);
		if ($frame)	{$frame = intval($frame);}
		$imgInfo = $img->imageMagickConvert($file,"web",$width.$max,$height,$img->IMparams($effects),$frame,"");
		
		$this->content="";
		$this->content.='
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>'.($title ? stripslashes($title) : "Image").'</title>
</head>
		'.($bodyTag ? stripslashes($bodyTag) : "<BODY>");
		
		if (is_array($imgInfo))	{
			$wrapParts = explode("|",stripslashes($wrap));
			$this->content.=trim($wrapParts[0]).$img->imgTag($imgInfo).trim($wrapParts[1]);
		}
		$this->content.='
		</body>
		</html>';
	}
	function printContent()	{
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/showpic.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/showpic.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_tslib_showpic");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>