The "tslib".

The "tslib" contains PHP4-classes that generates the
standard TypoScript based frontend for Typo3. 
The library depends on t3lib.