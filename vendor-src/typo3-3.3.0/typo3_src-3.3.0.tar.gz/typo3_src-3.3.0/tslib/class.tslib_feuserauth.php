<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Front End session user. Login and session data
 *
 * included from index_ts.php
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class tslib_feUserAuth extends t3lib_userAuth {
	var $session_table = "fe_sessions"; 		// Table to use for session data.
	var $name = "fe_typo_user";                 // Session/Cookie name
	var $get_name = "ftu";		                 // Session/GET-var name

	var $user_table = "fe_users"; 					// Table in database with userdata
	var $username_column = "username"; 			// Column for login-name
	var $userident_column = "password"; 		// Column for password
	var $userid_column = "uid"; 					// Column for user-id
	var $lastLogin_column = "lastlogin";

	var $enablecolumns = Array (
		"deleted" => "deleted",
		"disabled" => "disable",
		"starttime" => "starttime",
		"endtime" => "endtime"
	);
	var $formfield_uname = "user"; 			// formfield with login-name
	var $formfield_uident = "pass"; 		// formfield with password
	var $formfield_chalvalue = "challenge";		// formfield with a unique value which is used to encrypt the password and username
	var $formfield_status = "logintype"; 	// formfield with status: *"login", "logout"
	var $security_level = "";				// sets the level of security. *"normal" = clear-text. "challenged" = hashed password/username from form in $formfield_uident. "superchallenged" = hashed password hashed again with username.

	var $auth_include = "";						// this is the name of the include-file containing the login form. If not set, login CAN be anonymous. If set login IS needed.
	
	var $auth_timeout_field = 6000;				// if > 0 : session-timeout in seconds. if false/<0 : no timeout. if string: The string is fieldname from the usertable where the timeout can be found.
	var $lifetime = 0;                  		// 0 = Session-cookies. If session-cookies, the browser will stop session when the browser is closed. Else it keeps the session for $lifetime seconds.
	var $sendNoCacheHeaders = 0;
	var $getFallBack = 1;					// If this is set, authentication is also accepted by the HTTP_GET_VARS. Notice that the identification is NOT 128bit MD5 hash but reduced. This is done in order to minimize the size for mobile-devices, such as WAP-phones
	var $hash_length = 10;
	var $getMethodEnabled = 1;				// Login may be supplied by url.

	var $usergroup_column = "usergroup";
	var $usergroup_table = "fe_groups";
	var $groupData = Array(
		"title" =>Array(),
		"uid" =>Array(),
		"pid" =>Array()
	);
	var $TSdataArray=array();		// Used to accumulate the TSconfig data of the user
	var $userTS = array();
	var $userTSUpdated=0;	
	var $showHiddenRecords=0;

	function fetchGroupData()	{
		$this->TSdataArray=array();
		$this->userTS = array();
		$this->userTSUpdated=0;	

			// Setting default configuration:
		$this->TSdataArray[]=$GLOBALS["TYPO3_CONF_VARS"]["FE"]["defaultUserTSconfig"];
		
		if (is_array($this->user) && $this->user["usergroup"])	{
			$groups = t3lib_div::intExplode(",",$this->user["usergroup"]);
			$list = implode($groups,",");
			$lockToDomain_SQL = " AND (lockToDomain='' OR lockToDomain='".getenv("HTTP_HOST")."')";
			if (!$this->showHiddenRecords)	$hiddenP = "AND NOT hidden ";
			$query="SELECT * FROM ".$this->usergroup_table." WHERE NOT deleted ".$hiddenP."AND uid IN (".$list.")".$lockToDomain_SQL;
			$res = mysql(TYPO3_db,$query);
			while ($row=mysql_fetch_assoc($res))	{
				$this->groupData["title"][$row["uid"]]=$row["title"];
				$this->groupData["uid"][$row["uid"]]=$row["uid"];
				$this->groupData["pid"][$row["uid"]]=$row["pid"];
				$this->groupData["TSconfig"][$row["uid"]]=$row["TSconfig"];
			}
			if (mysql_num_rows($res))	{
				// TSconfig:
				reset($groups);
				while(list(,$TSuid)=each($groups))	{
					$this->TSdataArray[]=$this->groupData["TSconfig"][$TSuid];
				}
				$this->TSdataArray[]=$this->user["TSconfig"];
				
				// Sort information
				ksort($this->groupData["title"]);
				ksort($this->groupData["uid"]);
				ksort($this->groupData["pid"]);
				return count($this->groupData["uid"]);
			} else {
				return 0;
			}
		}
	}


	function getUserTSconf()	{
		if (!$this->userTSUpdated) {
				// Parsing the user TS (or getting from cache)
			$userTS = implode($this->TSdataArray,chr(10)."[GLOBAL]".chr(10));
			$parseObj = t3lib_div::makeInstance("t3lib_TSparser");
			$parseObj->parse($userTS);
			$this->userTS = $parseObj->setup;

			$this->userTSUpdated=1;
		}
		return $this->userTS;
	}
	
	
	
		// Session and user data:
		/*
			There are two types of data that can be stored: UserData and Session-Data. Userdata is for the login-user, and session-data for anyone viewing the pages.
			"Keys" are keys in the internal dataarray of the data. When you get or set a key in one of the data-spaces (user or session) you decide the type of the variable (not object though)
			"Reserved" keys are: 
				- "recs": Array: Used to "register" records, eg in a shopping basket. Structure: ["recs"][tablename][record_uid]=number
				- sys: Reserved for TypoScript standard code.
		*/
	var $sesData = Array();
	var $sesData_change = 0;
	var $userData_change = 0;

	function fetchSessionData()	{
		// Gets SesData if any
		if ($this->id)	{
			$query="SELECT * FROM fe_session_data WHERE hash = '".$this->id."'";
			$dbres=mysql(TYPO3_db,$query);
			echo mysql_error();
			if ($sesDataRow = mysql_fetch_assoc($dbres))	{
				$this->sesData = unserialize($sesDataRow["content"]);
			}
		}
			// delete old data:
		if ((rand()%100) <= 1) {		// a possibility of 1 % for garbage collection.
			$query="DELETE FROM fe_session_data WHERE tstamp < '".(time()-3600*24)."'";		// all data older than 24 hours are deleted.
			$dbres=mysql(TYPO3_db,$query);
			echo mysql_error();
		}
	}
	function storeSessionData()	{
		// Saves UC and SesData if changed.
		if ($this->userData_change)	{
			$this->writeUC("");
		}
		if ($this->sesData_change)	{
			if ($this->id)	{
				$query="DELETE FROM fe_session_data WHERE hash = '".$this->id."'";
				$dbres=mysql(TYPO3_db,$query);
				echo mysql_error();
				$query="INSERT INTO fe_session_data (hash, content, tstamp) VALUES ('".$this->id."', '".addslashes(serialize($this->sesData))."', '".time()."')";
				$dbres=mysql(TYPO3_db,$query);
				echo mysql_error();
			}
		}
	}
	function getKey($type,$key) {
		if ($key)	{
			switch($type)	{
				case "user":
					return $this->uc[$key];
				break;
				case "ses":
					return $this->sesData[$key];
				break;
			}
		}
	}
	function setKey($type,$key,$data)	{
		if ($key)	{
			switch($type)	{
				case "user":
					if ($this->user[uid])	{
						$this->uc[$key]=$data;
						$this->userData_change=1;
					}
				break;
				case "ses":
					$this->sesData[$key]=$data;
					$this->sesData_change=1;
				break;
			}
		}
	}
	function record_registration($recs)	{
		if ($recs["clear_all"])	{
			$this->setKey("ses","recs","");
		}
		$change=0;
		$recs_array=$this->getKey("ses","recs");
		reset($recs);
		while(list($table,$data)=each($recs))	{
			if (is_array($data))	{
				reset($data);
				while(list($rec_id,$value)=each($data))	{
					if ($value != $recs_array[$table][$rec_id])	{
						$recs_array[$table][$rec_id] = stripslashes($value);
						$change=1;
					}
				}
			}
		}
		if ($change)	{
			$this->setKey("ses","recs",$recs_array);
		}
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_feuserauth.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_feuserauth.php"]);
}

?>
