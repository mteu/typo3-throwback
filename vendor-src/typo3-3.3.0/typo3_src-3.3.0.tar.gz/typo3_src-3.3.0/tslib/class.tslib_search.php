<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Searching
 *
 * Used to generate search queries for TypoScript
 *
 * @see		tslib_cObj
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 * @author	Rene Fritz	<r.fritz@colorcube.de>
 */


class tslib_search {
	var $tables = Array (
/*		"pages" => Array (
			"searchfields" => Array ("keywords","titel"),
			"resultfields" => Array ("s_id AS SIDE_ID", "titel"),
			"primary_key" => "uid"
		),
		"fm_afsnit" => Array (
			"searchfields" => Array ("fm_txt_tx","fm_ovsk_ln"),
			"resultfields" => Array ("fm_ovsk_ln"),
			"fkey" => "pid"
		)
		*/
	);

	var $standalone = "";	// true / false - if the searchresult MAY NOT be a part-string (doesn't work yet. Does not find words with parentheses or periods before/after....beginning/end of a line is also a problem!)
	var $mixedcase = "yes";		// true / false - matches both upper and lower case (doesn't work if you disable. Matches all cases currently)

	var $order_by = "";		// ORDER BY part of the query. (field-reference, eg. "pages.uid"
	var $group_by = "PRIMARY_KEY";		// Alternatively "PRIMARY_KEY"; sorting by primary key

	var $default_operator = "AND";	// Standard SQL-operator between words
	var $operator_translate_table_caseinsensitive = "1";
	var $operator_translate_table = Array (		// case-sensitiv. Defineres the words, which will be operators between words
		Array ("+" , "AND"),
		Array ("-" , "AND NOT"),
			// english
		Array ("AND" , "AND"),
		Array ("OR" , "OR"),
		Array ("NOT" , "AND NOT"),
			// danish
		Array ("OG" , "AND"),
		Array ("ELLER" , "OR"),
		Array ("UDEN" , "AND NOT")
	);

	// Internal
	var $sword_array;		// Contains the search-words and operators
	var $query_begin = "";		// Beginning of query
	var $query_end = "";			// Ending of query

	var $query;			// Contains the final query after processing.

	var $other_where_clauses;	// Addition to the whereclause. This could be used to limit search to a certain page or alike in the system.
	var $fTable;		// This is set with the foreign table that "pages" are connected to.

	var $res_offset = 0;	// How many rows to offset from the beginning
	var $res_shows = 20;	// How many results to show (0 = no limit)
	var $res_count;			// Intern: How many results, there was last time (with the exact same searchstring.
	
	var $pageIdList="";		// List of pageIds.
	
	var $listOfSearchFields ="";

	function explodeCols ($in)	{
		$theArray = explode(":",$in);
		$out = Array();
		while(list(,$val)=each($theArray))	{
			$val=trim($val);
			$parts = explode(".",$val);
			if ($parts[0] && $parts[1])	{
				$subparts = explode("-",$parts[1]);
				while(list(,$piece)=each($subparts))	{
					$piece=trim($piece);
					if ($piece)		$out[]=$parts[0].".".$piece;
				}
			}
		}
		return $out;
	}
	function register_tables_and_columns($requestedCols,$allowedCols)	{
			// this creates the $this->tables-array. 
			// $requestedCols is a list (-) of columns that we want to search. This could be input from the search-form (see TypoScript documentation)
			// $allowedCols is the list of columns, that MAY be searched. All allowed cols are set as result-fields. All requested cols MUST be in the allowed-fields list.
			// The "pages"-table is ALWAYS included as the search is page-based. Apart from this there may be one and only one table, joined with the pages-table. This table is the first table mentioned in the requested-list. If any more tables are set here, they are ignored.
		$rCols=$this->explodeCols($requestedCols);
		$aCols=$this->explodeCols($allowedCols);
		
		
//		debug($rCols);
//		debug($aCols);

		reset($rCols);
		while(list($k,$v)=each($rCols))	{
			$rCols[$k]=trim($v);
			if (in_array($rCols[$k], $aCols))	{
				$parts = explode(".",$rCols[$k]);
				$this->tables[$parts[0]]["searchfields"][] = $parts[1];
//				$this->tables[$parts[0]]["resultfields"]["uid"]="uid";	// Cannot set this, because then the link to the searched page will not be correct! Must set otherwise
			}
		}
		$this->tables["pages"]["primary_key"] = "uid";
		$this->tables["pages"]["resultfields"][]="uid";
		unset($this->tables["pages"]["fkey"]);

		reset($aCols);
		while(list($k,$v)=each($aCols))	{
			$aCols[$k]=trim($v);
			$parts = explode(".",$aCols[$k]);
			$this->tables[$parts[0]]["resultfields"][] = $parts[1]." AS ".str_replace(".","_",$aCols[$k]);
			$this->tables[$parts[0]]["fkey"]="pid";
		}
//debug($this->tables);
		reset($this->tables);
		$this->fTable="";
		while(list($t,$v)=each($this->tables))	{
			if ($t!="pages")	{
				if (!$this->fTable)	{
					$this->fTable=$t;
				} else {
					unset($this->tables[$t]);
				}
			}
		}
//		debug($this->tables);
	}
	function split ($tag, $specchars="+-")	{
		// Returns an array with the components from a attribute-list. The result is normally analyzed by get_tag_attributes.
		// Removes tag if present
		$tag_tmp = $tag;
		$specs = "[".quotemeta($specchars)."]";

		while ($tag_tmp)	{
			if (ereg("^\"",$tag_tmp))	{
				// Der er g�se�jne omkring v�rdien. Der ledes efter n�ste "
				$tag_tmp = ereg_replace("^\"","",$tag_tmp);		// Fjerner f�rst g�se�je.
				ereg("^[^\"]*",$tag_tmp,$reg);  // Tager alt indtil n�ste g�se�je
				$value[] = $reg[0];  // reg[0] er lig med v�rdien!! Skal ikke trimmes
				$tag_tmp = ereg_replace("^".quotemeta($reg[0]),"",$tag_tmp);
				$tag_tmp = trim(ereg_replace("^\"","",$tag_tmp));		// Fjerner det sidste g�se�je.
			} elseif (ereg("^$specs",$tag_tmp,$reg)) {
				$value[] = $reg[0];
				$tag_tmp = trim(ereg_replace("^$specs","",$tag_tmp));		// Fjerner = tegn.
			} else {
				// Der er ikke g�se�jne om v�rdien. Der ledes efter n�ste " " eller ">"
				ereg("^[^ ".quotemeta($specchars)."]*",$tag_tmp,$reg);
				$value[] = trim($reg[0]);
				$tag_tmp = trim(ereg_replace("^".quotemeta($reg[0]),"",$tag_tmp));
			}
		}
		return $value;
	}
	function register_and_explode_search_string ($sword)	{
		// takes a search-string (WITHOUT SLASHES or else it'll be a little sppooky , NOW REMEMBER to unslash!!)
		// sets up $this->sword_array op with operators. 
		// This function uses $this->operator_translate_table as well as $this->default_operator
		$sword = trim($sword);
		if ($sword)	{
			$components = $this->split($sword);
			$s_sword = "";	 // the searchword is stored here during the loop
			if (is_array($components))	{
				$i=0;
				$lastoper = "";
				reset($components);
				while (list($key,$val) = each ($components))	{
					$operator=$this->get_operator($val);
					if ($operator)	{
						$lastoper = $operator;
					} elseif (strlen($val)>1) {		// A searchword MUST be at least two characters long!
						$this->sword_array[$i][sword] = $val;
						$this->sword_array[$i][oper] = ($lastoper) ? $lastoper : $this->default_operator;
						$lastoper = "";
						$i++;
					}
				}
			}
		}
//		t3lib_div::print_array($this->sword_array);
	}
	function build_search_query ($endClause) {
			// This creates the search-query. 
			// $endClause is some extra conditions that the search must match. See tt_content.
			// In TypoScript this is used for searching only records not hidden, start/endtimed and fe_grouped! (enable-fields, see tt_content)
		if (is_array($this->tables))	{
			$tables = $this->tables;
			$primary_table = "";
			$query = "SELECT";
				// Primary key table is found.
			reset($tables);
			while (list($key,$val) = each($tables))	{
				if ($tables[$key]["primary_key"])	{$primary_table = $key;}
			}
			if ($primary_table) {
				reset($tables);
				while (list($key,$val) = each($tables))	{
					$resultfields = $tables[$key][resultfields];
					if (is_array($resultfields))	{
						reset($resultfields);
						while (list($key2,$val2) = each($resultfields))	{
							$query.= " $key.$val2,";
						}
					}
				}
	
				$query = t3lib_div::rm_endcomma($query);
				$query.= " FROM";
	
				reset($tables);
				while (list($key,$val) = each($tables))	{
					$query.= " $key,";
				}
	
				$query = t3lib_div::rm_endcomma($query);
				$query.= " WHERE";
				
				reset($tables);
				$primary_table_and_key = "$primary_table.".$tables[$primary_table][primary_key];
				$primKeys=Array();
				while (list($key,$val) = each($tables))	{
					$fkey = $tables[$key][fkey];
					if ($fkey)	{
						 $primKeys[]="$key.$fkey=$primary_table_and_key";
					}
				}
				if (count($primKeys))	{
					$query.="(".implode($primKeys," OR ").")";
				}
				if (!ereg("WHERE$",trim($query)))	{
					$query.=" AND";
				}

				$tempClause = trim($endClause);
				if ($tempClause)	{
					$query.= " (".$tempClause.") AND";
				}		

				$query.= " (";
				$this->query_begin = $query;
	
				if ($this->group_by)	{
					if ($this->group_by == "PRIMARY_KEY")	{
						$this->query_end = ") GROUP BY $primary_table_and_key";
					} else {
						$this->query_end = ") GROUP BY ".$this->group_by;
					}
				} else {
					$this->query_end = ")";
				}
			}
		}

		$query_part = $this->build_search_query_for_searchwords();
		if (!$query_part)	{
			$query_part="(0!=0)";
		}
		$this->query = $this->query_begin.$query_part.$this->query_end;
		return true;
	}
	function build_search_query_for_searchwords ()	{
			// Creates the part of the SQL-sentence, that searches for the search-words ($this->sword_array)
		$tables = $this->tables;
		$sword_array = $this->sword_array;
		$query_part = "";
		$sp="";
		if ($this->standalone)	{$sp=" ";}		// Der inds�ttes et space foran og efter ordet, hvis det SKAL st� alene. Dette er dog ikke korrekt implementeret, fordi det ikke finder ord i starten, slutningen og i parenteser osv. Egentlig skal der v�re check p� noget om der er alfanumeriske v�rdier f�r eller efter!!
		if (is_array($sword_array))	{
			reset($sword_array);
			while (list($key,$val) = each($sword_array))	{
				$s_sword = $sword_array[$key][sword];
					// Get subQueryPart
				$sub_query_part="";
				reset ($tables);
				$this->listOfSearchFields="";
				while (list($key3,$val3) = each($tables))	{
					$searchfields = $tables[$key3][searchfields];
					if (is_array($searchfields))	{
						reset ($searchfields);
						while (list($key2,$val2) = each($searchfields))	{
							$this->listOfSearchFields.=$key3.".".$val2.",";
							$sub_query_part.= " $key3.$val2 LIKE '%$sp".AddSlashes($s_sword)."$sp%' OR";
						}
					}
				}
				$sub_query_part = trim(ereg_replace("OR$","",$sub_query_part));

				if ($sub_query_part)	{
					if ($query_part != "")	{
						$query_part.= " ".$sword_array[$key][oper]." (".$sub_query_part.")";
					} else {
						$query_part.= "(".$sub_query_part.")";
					}
				}
//				$lastoper = $sword_array[$key][oper];
			}
			$query_part = trim($query_part);
//			$query_part = ereg_replace("$lastoper$","",$query_part);
			if (!$query_part || trim($query_part)=="()")	{
//				$query_part = " (0!=0)";
				$query_part = "";
			}
			return $query_part;
		}
	}
	function get_operator ($operator)	{
			// This returns a search-operator. Used internally
		$operator = trim($operator);
		$op_array = $this->operator_translate_table;
		reset ($op_array);
		if ($this->operator_translate_table_caseinsensitive)	{
			$operator = strtoupper($operator);
		}
		while (list($key,$val) = each($op_array))	{
			$item = $op_array[$key][0];
			if ($this->operator_translate_table_caseinsensitive)	{
				$item = strtoupper($item);
			}
			if ($operator==$item)	{
				return $op_array[$key][1];
			}
		}
	}	
	function count_query () {
			// Counts the results.
		$query = $this->query;
		if ($query)	{
//		debug($query);
			$res = mysql(TYPO3_db, $query);
			echo mysql_error();
		    $this->res_count = mysql_num_rows($res);
			return true;
		}
	}
	function execute_query () {
			// Executes the search
		$query = $this->query;
		if ($query)	{
			if ($this->order_by)
			$query.= " ORDER BY ".$this->order_by;
			//echo $query;
	        $this->result = mysql(TYPO3_db, $query);
			echo mysql_error();
			return true;
		}
	}
	function get_searchwords()	{
		$SWORD_PARAMS="";
		if (is_array($this->sword_array))	{
			reset($this->sword_array);
			while (list($key,$val)=each($this->sword_array))	{
				$SWORD_PARAMS.="&sword_list[]=".rawurlencode($val[sword]);
			}
		}
		return $SWORD_PARAMS;
	}



	function get_searchwordsArray()	{
		if (is_array($this->sword_array))	{
			reset($this->sword_array);
			while (list($key,$val)=each($this->sword_array))	{
				$swords[]=$val[sword];
			}
		}
		return $swords;
	}
}	   




if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_search.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_search.php"]);
}

?>