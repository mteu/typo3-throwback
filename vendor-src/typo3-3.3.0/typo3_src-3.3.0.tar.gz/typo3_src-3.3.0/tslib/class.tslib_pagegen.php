<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Libraries for pagegen.php
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class TSpagegen {

	/** 
	 * Setting some vars in TSFE, primarily based on TypoScript config settings.
	 */
	function pagegenInit()	{
			// Global vars...
		$GLOBALS["TSFE"]->debug = "".$GLOBALS["TSFE"]->config["config"]["debug"];

			// Internal and External target defaults
		$GLOBALS["TSFE"]->intTarget = "".$GLOBALS["TSFE"]->config["config"]["intTarget"];
		$GLOBALS["TSFE"]->extTarget = "".$GLOBALS["TSFE"]->config["config"]["extTarget"]; 
		$GLOBALS["TSFE"]->absRefPrefix = trim("".$GLOBALS["TSFE"]->config["config"]["absRefPrefix"]);
		if ((!strcmp($GLOBALS["TSFE"]->config["config"]["simulateStaticDocuments"],"PATH_INFO") || $GLOBALS["TSFE"]->absRefPrefix_force) 
				&& !$GLOBALS["TSFE"]->absRefPrefix)	{
			$GLOBALS["TSFE"]->absRefPrefix=dirname(t3lib_div::getIndpEnv("SCRIPT_NAME")); $GLOBALS["TSFE"]->absRefPrefix.=($GLOBALS["TSFE"]->absRefPrefix=="/"?"":"/");
		}		// Force absRefPrefix to this value is PATH_INFO is used.
		
		$GLOBALS["TSFE"]->compensateFieldWidth = "".$GLOBALS["TSFE"]->config["config"]["compensateFieldWidth"];  
		$GLOBALS["TSFE"]->lockFilePath = "".$GLOBALS["TSFE"]->config["config"]["lockFilePath"];  
		$GLOBALS["TSFE"]->lockFilePath = $GLOBALS["TSFE"]->lockFilePath ? $GLOBALS["TSFE"]->lockFilePath : "fileadmin/";
		$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_noScaleUp"] = isset($GLOBALS["TSFE"]->config["config"]["noScaleUp"]) ? "".$GLOBALS["TSFE"]->config["config"]["noScaleUp"] : $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_noScaleUp"];
		$GLOBALS["TSFE"]->TYPO3_CONF_VARS["GFX"]["im_noScaleUp"] = $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["im_noScaleUp"];
		
		$GLOBALS["TSFE"]->ATagParams = trim($GLOBALS["TSFE"]->config["config"]["ATagParams"]) ? " ".trim($GLOBALS["TSFE"]->config["config"]["ATagParams"]) : "";
		if ($GLOBALS["TSFE"]->config["config"]["setJS_mouseOver"])	$GLOBALS["TSFE"]->setJS("mouseOver");
		if ($GLOBALS["TSFE"]->config["config"]["setJS_openPic"])	$GLOBALS["TSFE"]->setJS("openPic");
		
		$GLOBALS["TSFE"]->sWordRegEx="";
		$GLOBALS["TSFE"]->sWordList = t3lib_div::GPvar("sword_list");
		if (is_array($GLOBALS["TSFE"]->sWordList))	{
			$standAlone = trim("".$GLOBALS["TSFE"]->config["config"]["sword_standAlone"]);
			$noMixedCase = trim("".$GLOBALS["TSFE"]->config["config"]["sword_noMixedCase"]);
		
			$space = ($standAlone) ? "[[:space:]]" : "";
			reset($GLOBALS["TSFE"]->sWordList);
			while (list($key,$val) = each($GLOBALS["TSFE"]->sWordList))	{
				if (trim($val)) {
					if (!$noMixedCase) {
						$GLOBALS["TSFE"]->sWordRegEx.= $space.sql_regcase(quotemeta($val)).$space."|";
					} else {
						$GLOBALS["TSFE"]->sWordRegEx.= $space.quotemeta($val).$space."|";
					}
				}
			}
			$GLOBALS["TSFE"]->sWordRegEx = ereg_replace("\|$","",$GLOBALS["TSFE"]->sWordRegEx);
		}
		
			// linkVars
		$GLOBALS["TSFE"]->linkVars = "".$GLOBALS["TSFE"]->config["config"]["linkVars"];
		if ($GLOBALS["TSFE"]->linkVars)	{
			$linkVarArr = explode(",",$GLOBALS["TSFE"]->linkVars);
			reset($linkVarArr);
			$GLOBALS["TSFE"]->linkVars="";
			while(list(,$val)=each($linkVarArr))	{
				$val=trim($val);
				if ($val && isset($GLOBALS["HTTP_GET_VARS"][$val]))	{
					if (!is_array($GLOBALS["HTTP_GET_VARS"][$val]))	{
						$GLOBALS["TSFE"]->linkVars.="&".$val."=".rawurlencode($GLOBALS["HTTP_GET_VARS"][$val]);
					} else {
						$GLOBALS["TSFE"]->linkVars.=t3lib_div::implodeArrayForUrl($val,$GLOBALS["HTTP_GET_VARS"][$val]);
					}
				}
			}
//						debug($GLOBALS["TSFE"]->linkVars);
		} else {
			$GLOBALS["TSFE"]->linkVars="";
		}
	}

	/** 
	 * Returns an array with files to include. These files are the ones set up in TypoScript config.
	 */
	function getIncFiles()	{
		$incFilesArray = array();
			// Get files from config.includeLibrary
		$includeLibrary = trim("".$GLOBALS["TSFE"]->config["config"]["includeLibrary"]);
		if ($includeLibrary)	{
			$incFile=$GLOBALS["TSFE"]->tmpl->getFileName($includeLibrary);
			if ($incFile)	{
				$incFilesArray[] = $incFile;
			}
		}
		
		if (is_array($GLOBALS["TSFE"]->pSetup["includeLibs."]))	{$incLibs=$GLOBALS["TSFE"]->pSetup["includeLibs."];} else {$incLibs=array();}
		if (is_array($GLOBALS["TSFE"]->tmpl->setup["includeLibs."]))	{$incLibs+=$GLOBALS["TSFE"]->tmpl->setup["includeLibs."];}	// toplevel "includeLibs" is added to the PAGE.includeLibs. In that way, PAGE-libs get first priority, because if the key already exist, it's not altered. (Due to investigation by me)
		if (count($incLibs))	{
			reset($incLibs);
			while(list(,$theLib)=each($incLibs))	{
				if (!is_array($theLib) && $incFile=$GLOBALS["TSFE"]->tmpl->getFileName($theLib))	{
					$incFilesArray[] = $incFile;
				}
			}
		}
			// Include HTML mail library?
		if ($GLOBALS["TSFE"]->config["config"]["incT3Lib_htmlmail"])	{
			$incFilesArray[] = "t3lib/class.t3lib_htmlmail.php";
		}
		return $incFilesArray;
	}


	/** 
	 * Rendering the page content
	 */
	function renderContent()	{
		// PAGE CONTENT
		$GLOBALS["TT"]->incStackPointer();
		$GLOBALS["TT"]->push($GLOBALS["TSFE"]->sPre, "PAGE");
			$pageContent = $GLOBALS["TSFE"]->cObj->cObjGet($GLOBALS["TSFE"]->pSetup);

			if ($GLOBALS["TSFE"]->pSetup["wrap"])	{$pageContent = $GLOBALS["TSFE"]->cObj->wrap($pageContent, $GLOBALS["TSFE"]->pSetup["wrap"]);}
			if ($GLOBALS["TSFE"]->pSetup["stdWrap."])	{$pageContent = $GLOBALS["TSFE"]->cObj->stdWrap($pageContent, $GLOBALS["TSFE"]->pSetup["stdWrap."]);}
		
		// PAGE HEADER (after content - maybe JS is inserted!
		
			// if "disableAllHeaderCode" is set, all the header-code is discarded!
		if ($GLOBALS["TSFE"]->config["config"]["disableAllHeaderCode"])	{
			$GLOBALS["TSFE"]->content=$pageContent;
		} else {			
			TSpagegen::renderContentWithHeader($pageContent);
		}
		$GLOBALS["TT"]->pull($GLOBALS["TT"]->LR?$GLOBALS["TSFE"]->content:"");
		$GLOBALS["TT"]->decStackPointer();
	}

	/** 
	 * Rendering normal HTML-page with header
	 */
	function renderContentWithHeader($pageContent)	{
		$customContent = $GLOBALS["TSFE"]->config["config"]["headerComment"];
		if (trim($customContent))	{
			$customContent = chr(10).$customContent;
		} else $customContent="";
		
		$GLOBALS["TSFE"]->content="";
		$GLOBALS["TSFE"]->content.='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<!-- '.$customContent.'
  This is a Typo3/TypoScript generated document.
  Typo3 is a free open source Content Management Framework
  developed by Kasper Skaarhoej and licensed under GNU/GPL.
  Info and downloads at http://www.typo3.com
-->
';
		
		
		if ($GLOBALS["TSFE"]->pSetup["shortcutIcon"]) {
			$ss=$path.$GLOBALS["TSFE"]->tmpl->getFileName($GLOBALS["TSFE"]->pSetup["shortcutIcon"]);
			$GLOBALS["TSFE"]->content.='
<link rel="SHORTCUT ICON" href="'.$ss.'" />';
		}
		if ($GLOBALS["TSFE"]->pSetup["stylesheet"]) {
			$ss=$GLOBALS["TSFE"]->tmpl->getFileName($GLOBALS["TSFE"]->pSetup["stylesheet"]);
			if ($ss) {
				$GLOBALS["TSFE"]->content.='
<link rel="stylesheet" href="'.$ss.'">';
			}
		}

		// Stylesheets
		$style="";
		
		if ($GLOBALS["TSFE"]->pSetup["insertClassesFromRTE"])	{
			$pageTSConfig = $GLOBALS["TSFE"]->getPagesTSconfig();
			$RTEclasses = $pageTSConfig["RTE."]["classes."];
			if (is_array($RTEclasses))	{
				reset($RTEclasses);
				while(list($RTEclassName,$RTEvalueArray)=each($RTEclasses))	{
					if ($RTEvalueArray["value"])	{
						$style.='
.'.substr($RTEclassName,0,-1).' {'.$RTEvalueArray["value"].'}';
					}
				}
			}

			if ($GLOBALS["TSFE"]->pSetup["insertClassesFromRTE."]["add_mainStyleOverrideDefs"] && is_array($pageTSConfig["RTE."]["default."]["mainStyleOverride_add."]))	{
				$mSOa_tList = t3lib_div::trimExplode(",",strtoupper($GLOBALS["TSFE"]->pSetup["insertClassesFromRTE."]["add_mainStyleOverrideDefs"]),1);
				reset($pageTSConfig["RTE."]["default."]["mainStyleOverride_add."]);
				while(list($mSOa_key,$mSOa_value)=each($pageTSConfig["RTE."]["default."]["mainStyleOverride_add."]))	{
					if (!is_array($mSOa_value) && (in_array("*",$mSOa_tList)||in_array($mSOa_key,$mSOa_tList)))	{
						$style.='
'.$mSOa_key.' {'.$mSOa_value.'}';
					}
				}
			}
		}
		
		if ($GLOBALS["TSFE"]->pSetup["noLinkUnderline"])	{
			$style.='
A:link {text-decoration: none}
A:visited {text-decoration: none}
A:active {text-decoration: none}';
		}
		if (trim($GLOBALS["TSFE"]->pSetup["hover"]))	{
			$style.='
A:hover {color: '.trim($GLOBALS["TSFE"]->pSetup["hover"]).';}';
		}
		if (trim($GLOBALS["TSFE"]->pSetup["hoverStyle"]))	{
			$style.='
A:hover {'.trim($GLOBALS["TSFE"]->pSetup["hoverStyle"]).'}';
		}
		if ($GLOBALS["TSFE"]->pSetup["smallFormFields"])	{
			$style.='
SELECT {  font-family: Verdana, Arial, Helvetica; font-size: 10px }
TEXTAREA  {  font-family: Verdana, Arial, Helvetica; font-size: 10px} 
INPUT   {  font-family: Verdana, Arial, Helvetica; font-size: 10px }';
		}
		
		if ($style)	{
		$GLOBALS["TSFE"]->content.='
<STYLE TYPE="text/css">
<!--'.$style.'
-->
</STYLE>';
		}
	
		// Headerdata
		if (is_array($GLOBALS["TSFE"]->pSetup["headerData."]))	{
			$GLOBALS["TSFE"]->content.= "\n".$GLOBALS["TSFE"]->cObj->cObjGet($GLOBALS["TSFE"]->pSetup["headerData."],"headerData.");
		}
		
			// <title></title> :
		$titleTagContent = $GLOBALS["TSFE"]->tmpl->printTitle($GLOBALS["TSFE"]->page["title"],$GLOBALS["TSFE"]->config["config"]["noPageTitle"]);
		if ($GLOBALS["TSFE"]->config["config"]["titleTagFunction"])	{
			$titleTagContent = $GLOBALS["TSFE"]->cObj->callUserFunction($GLOBALS["TSFE"]->config["config"]["titleTagFunction"], array(), $titleTagContent);
		}
		
		$GLOBALS["TSFE"]->content.='
<title>'.$titleTagContent.'</title>';
		$GLOBALS["TSFE"]->content.='
<meta http-equiv="Content-Type" content="text/html; charset='.($GLOBALS["TSFE"]->config["config"]["metaCharset"] ? $GLOBALS["TSFE"]->config["config"]["metaCharset"] : "iso-8859-1").'">';
		$GLOBALS["TSFE"]->content.='
<meta name="generator" content="Typo 3.3 CMS">';
		
		$conf=$GLOBALS["TSFE"]->pSetup["meta."];
		if (is_array($conf))	{
			reset($conf);
			while(list($theKey,$theValue)=each($conf))	{
				if (!strstr($theKey,".") || !isset($conf[substr($theKey,0,-1)]))	{		// Only if 1) the property is set but not the value itself, 2) the value and/or any property
					if (strstr($theKey,"."))	{
						$theKey = substr($theKey,0,-1);
					}
					$val = $GLOBALS["TSFE"]->cObj->stdWrap($conf[$theKey],$conf[$theKey."."]);
					$key = $theKey;
					if (trim($val))	{
						$a="name";
						if (strtolower($key)=="refresh")	{$a="http-equiv";}
						$GLOBALS["TSFE"]->content.= '
<meta '.$a.'="'.$key.'" content="'.trim($val).'">';
					}
				}
			}
		}
	
	
		unset($GLOBALS["TSFE"]->additionalHeaderData["JSCode"]);
		unset($GLOBALS["TSFE"]->additionalHeaderData["JSImgCode"]);
	
		if (is_array($GLOBALS["TSFE"]->config["INTincScript"]))	{
				// Storing the JSCode and JSImgCode vars...
			$GLOBALS["TSFE"]->additionalHeaderData["JSCode"] = $GLOBALS["TSFE"]->JSCode;	
			$GLOBALS["TSFE"]->additionalHeaderData["JSImgCode"] = $GLOBALS["TSFE"]->JSImgCode;
			$GLOBALS["TSFE"]->config["INTincScript_ext"]["divKey"]= $GLOBALS["TSFE"]->uniqueHash();
			$GLOBALS["TSFE"]->config["INTincScript_ext"]["additionalHeaderData"]	= $GLOBALS["TSFE"]->additionalHeaderData;	// Storing the header-data array
			$GLOBALS["TSFE"]->config["INTincScript_ext"]["additionalJavaScript"]	= $GLOBALS["TSFE"]->additionalJavaScript;	// Storing the JS-data array

			$GLOBALS["TSFE"]->additionalHeaderData=array("<!--HD_".$GLOBALS["TSFE"]->config["INTincScript_ext"]["divKey"]."-->");	// Clearing the array
			$GLOBALS["TSFE"]->divSection.="<!--TDS_".$GLOBALS["TSFE"]->config["INTincScript_ext"]["divKey"]."-->";
		} else {
			$GLOBALS["TSFE"]->INTincScript_loadJSCode();
		}
		$GLOBALS["TSFE"]->content.='
<script language="javascript">
<!--
	browserName = navigator.appName;
	browserVer = parseInt(navigator.appVersion);
	var msie4 = (browserName == "Microsoft Internet Explorer" && browserVer >= 4);
	if ((browserName == "Netscape" && browserVer >= 3) || msie4 || browserName=="Konqueror") {version = "n3";} else {version = "n2";}
	function blurLink(theObject)	{
		if (msie4)	{theObject.blur();}
	}
// -->
</script>
'.implode($GLOBALS["TSFE"]->additionalHeaderData,chr(10)).'
</head>';
		if ($GLOBALS["TSFE"]->pSetup["frameSet."])	{
			$fs = t3lib_div::makeInstance("tslib_frameset");
			$GLOBALS["TSFE"]->content.=$fs->make($GLOBALS["TSFE"]->pSetup["frameSet."]);
			$GLOBALS["TSFE"]->content.= "\n<noframes>\n";
		}
		
		// Bodytag:
		$bodyTag = $GLOBALS["TSFE"]->pSetup["bodyTag"] ? $GLOBALS["TSFE"]->pSetup["bodyTag"] : '<body bgcolor="#FFFFFF">';
		if ($bgImg=$GLOBALS["TSFE"]->cObj->getImgResource($GLOBALS["TSFE"]->pSetup["bgImg"],$GLOBALS["TSFE"]->pSetup["bgImg."]))	{
			$bodyTag = ereg_replace(">$","",trim($bodyTag)).' background="'.$GLOBALS["TSFE"]->absRefPrefix.$bgImg[3].'">';
		}
		if (isset($GLOBALS["TSFE"]->pSetup["bodyTagMargins"]))	{
			$margins = $GLOBALS["TSFE"]->pSetup["bodyTagMargins"];
			$bodyTag = ereg_replace(">$","",trim($bodyTag)).' leftmargin="'.$margins.'" topmargin="'.$margins.'" marginwidth="'.$margins.'" marginheight="'.$margins.'">';
		}
		if (trim($GLOBALS["TSFE"]->pSetup["bodyTagAdd"]))	{
			$bodyTag = ereg_replace(">$","",trim($bodyTag)).' '.trim($GLOBALS["TSFE"]->pSetup["bodyTagAdd"]).'>';
		}

		// Div-sections			
		$GLOBALS["TSFE"]->content.= "\n".$bodyTag;
		if ($GLOBALS["TSFE"]->divSection)	{
			$GLOBALS["TSFE"]->content.=	"\n".$GLOBALS["TSFE"]->divSection;
		}
		
		// Page content
		$GLOBALS["TSFE"]->content.="\n".$pageContent;
		
		// Ending page
		$GLOBALS["TSFE"]->content.= "\n</body>";
		if ($GLOBALS["TSFE"]->pSetup["frameSet."])	{
			$GLOBALS["TSFE"]->content.= "\n</noframes>";
		}
		$GLOBALS["TSFE"]->content.="\n</html>";
	}
}

if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_pagegen.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_pagegen.php"]);
}



// ********************************************************
// Includes the search-class if $sword and $scols are set.
// ********************************************************
if (t3lib_div::GPvar("sword") && t3lib_div::GPvar("scols"))	{
	include_once(PATH_tslib."class.tslib_search.php");
}

// ************
// LoadDBGroup
// ************
include_once(PATH_t3lib."class.t3lib_loaddbgroup.php");
class FE_loadDBGroup extends t3lib_loadDBGroup	{
	var $fromTC = 0;		// Means the not only uid and label-field is returned, but everything
}

// **********************************
// includes stuff for graphical work
// **********************************
include_once(PATH_t3lib."class.t3lib_stdgraphic.php");
include_once(PATH_tslib."class.tslib_gifbuilder.php");

// *************************
// includes menu-management
// *************************
include_once(PATH_tslib."class.tslib_menu.php");
/* 060502: Removed these class names
class gmenu extends tslib_gmenu {
}
class tmenu extends tslib_tmenu {
}
class imgmenu extends tslib_imgmenu {
}
class jsmenu extends tslib_jsmenu {
}
*/


// *************************
// Global content object...
// *************************
include_once(PATH_tslib."class.tslib_content.php");

?>