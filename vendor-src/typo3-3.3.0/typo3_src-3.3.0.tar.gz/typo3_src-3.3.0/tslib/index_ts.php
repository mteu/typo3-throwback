<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This is the MAIN DOCUMENT of the TypoScript driven standard front-end
 *
 * On UNIX: You should create a symlink to this file from the directory from which you want your Typo3 website to run (which is ../)
 * ln -s tslib/index_ts.php index.php
 *
 * On Windows this file should copied to "index.php" in your website root (which is ../)
 *
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
 
// *******************************
// Set error reporting 
// *******************************
error_reporting (E_ALL ^ E_NOTICE); 


// ******************
// Constants defined
// ******************
$TYPO3_MISC["microtime_start"] = microtime();
define("TYPO3_OS", stristr(PHP_OS,"win")&&!stristr(PHP_OS,"darwin")?"WIN":"");
define("TYPO3_MODE","FE");
define("PATH_thisScript",
	TYPO3_OS=="WIN" ?
	str_replace('//','/',str_replace('\\','/', $HTTP_SERVER_VARS["PATH_TRANSLATED"]?$HTTP_SERVER_VARS["PATH_TRANSLATED"]:getenv("PATH_TRANSLATED"))) :
	(php_sapi_name()=="cgi"?(getenv("PATH_TRANSLATED")?getenv("PATH_TRANSLATED"):getenv("SCRIPT_FILENAME")):$HTTP_SERVER_VARS["PATH_TRANSLATED"])
);
define("PATH_site", dirname(PATH_thisScript)."/");
define("PATH_t3lib", "t3lib/");
define("PATH_tslib", "tslib/");
define("PATH_typo3conf", "typo3conf/");	
if (!@is_dir(PATH_typo3conf))	die("Cannot find configuration. This file is probably executed from the wrong location.");

// *********************
// Timetracking started
// *********************
include_once(PATH_tslib."class.tslib_timetrack.php");
$TT = new tslib_timeTrack;
$TT->start();
$TT->push("","Script start");


// *********************
// DIV Library included
// *********************
$TT->push("Include class t3lib_div","");
	include_once(PATH_t3lib."class.t3lib_div.php");
$TT->pull();



// **********************
// Include configuration
// **********************
$TT->push("Include config files","");
include(PATH_t3lib."config_default.php");
if (!defined ("TYPO3_db")) 	die ("The configuration file was not included.");	// the name of the Typo3 database is stored in this constant. Here the inclusion of the config-file is verified by checking if this var is set.
$CLIENT=t3lib_div::clientInfo();				// Set to the browser: net / msie if 4+ browsers
$TT->pull();


// *********************
// Libraries included
// *********************
$TT->push("Include Frontend libraries","");
	include_once(PATH_tslib."class.tslib_fe.php");
	include_once(PATH_t3lib."class.t3lib_page.php");
	include_once(PATH_t3lib."class.t3lib_userauth.php");
	include_once(PATH_tslib."class.tslib_feuserauth.php");
	include_once(PATH_t3lib."class.t3lib_tstemplate.php");
$TT->pull();


// *******************************
// Checking environment
// *******************************
if ((double)phpversion()<4 || (intval(substr(phpversion(),4))<3 && intval(substr(phpversion(),2))<1))	die ("Typo3 runs with PHP4.0.3+ only");

if (isset($HTTP_POST_VARS["GLOBALS"]) || isset($HTTP_GET_VARS["GLOBALS"]))	die("You cannot set the GLOBALS-array from outside the script.");
if (!get_magic_quotes_gpc())	{
	$TT->push("Add slashes to GET/POST arrays","");
	t3lib_div::addSlashesOnArray($HTTP_GET_VARS);
	t3lib_div::addSlashesOnArray($HTTP_POST_VARS);
	$TT->pull();
}

// ***********************************
// Create $TSFE object (TSFE = TypoScript Front End)
// Connecting to database
// ***********************************
$temp_TSFEclassName=t3lib_div::makeInstanceClassName("tslib_fe");
$TSFE = new $temp_TSFEclassName(
		$TYPO3_CONF_VARS, 
		t3lib_div::GPvar("id"), 
		t3lib_div::GPvar("type"), 
		t3lib_div::GPvar("no_cache"), 
		t3lib_div::GPvar("cHash"), 
		t3lib_div::GPvar("jumpurl")
	);
$TSFE->connectToMySQL();


// *******************
// output compression
// *******************
if ($TYPO3_CONF_VARS["FE"]["compressionLevel"])	{
	ob_start();
	include_once(PATH_t3lib."class.gzip_encode.php");
}

// *********
// FE_USER
// *********
$TT->push("Front End user initialized","");
	$TSFE->initFEuser();
$TT->pull();

// *********
// BE_USER
// *********
$BE_USER="";
if ($HTTP_COOKIE_VARS["be_typo_user"]) {		// If the backend cookie is set, we proceed and checks if a backend user is logged in.
	$TYPO3_MISC["microtime_BE_USER_start"] = microtime();
	$TT->push("Back End user initialized","");
		include_once (PATH_t3lib."class.t3lib_befunc.php");
		include_once (PATH_t3lib."class.t3lib_userauthgroup.php");
		include_once (PATH_t3lib."class.t3lib_beuserauth.php");
		include_once (PATH_t3lib."class.t3lib_tsfebeuserauth.php");
	
			// the value this->formfield_status is set to empty in order to disable login-attempts to the backend account through this script
		$BE_USER = t3lib_div::makeInstance("t3lib_tsfeBeUserAuth");	// New backend user object
		$BE_USER->OS = TYPO3_OS;
		$BE_USER->start();			// Object is initialized
		$BE_USER->unpack_uc("");
		if ($BE_USER->user["uid"])	{
			$BE_USER->fetchGroupData();
			$TSFE->beUserLogin=1; 
		}
		if ($BE_USER->checkLockToIP())	{
			$BE_USER->extInitFeAdmin();
			if ($BE_USER->extAdmEnabled)	{
				$BE_USER->extSaveFeAdminConfig();
					// Setting some values based on the admin panel
				$TSFE->forceTemplateParsing = $BE_USER->extGetFeAdminValue("tsdebug", "forceTemplateParsing");
				$TSFE->displayEditIcons = $BE_USER->extGetFeAdminValue("edit", "displayIcons");
				$TSFE->displayFieldEditIcons = $BE_USER->extGetFeAdminValue("edit", "displayFieldIcons");
	
				if (t3lib_div::GPvar("ADMCMD_editIcons"))	{
					$TSFE->displayFieldEditIcons=1;
					$BE_USER->uc["TSFE_adminConfig"]["edit_editNoPopup"]=1;
				}
				if (t3lib_div::GPvar("ADMCMD_simUser"))	{
					$BE_USER->uc["TSFE_adminConfig"]["preview_simulateUserGroup"]=intval(t3lib_div::GPvar("ADMCMD_simUser"));
					$BE_USER->ext_forcePreview=1;
				}
				if (t3lib_div::GPvar("ADMCMD_simTime"))	{
					$BE_USER->uc["TSFE_adminConfig"]["preview_simulateDate"]=intval(t3lib_div::GPvar("ADMCMD_simTime"));
					$BE_USER->ext_forcePreview=1;
				}
	
				if ($BE_USER->extAdmModuleEnabled("edit"))	{
					if ($BE_USER->extIsEditAction())	{
						$TSFE->includeTCA();
						include_once (PATH_t3lib."class.t3lib_tcemain.php");
						$BE_USER->extEditAction();
					}
					if ($BE_USER->extIsFormShown())	{
						$BE_USER->extLangSplit();
						$TSFE->includeTCA();
						include_once (PATH_t3lib."class.t3lib_tceforms.php");
						include_once (PATH_t3lib."class.t3lib_iconworks.php");
						include_once(PATH_t3lib."class.t3lib_loaddbgroup.php");
						include_once(PATH_t3lib."class.t3lib_transferdata.php");
							// Language loads:
						include("typo3/lang/lang.php");
						$LANG = t3lib_div::makeInstance("language");
						$LANG->init($BE_USER->uc["lang"],"typo3/");
							// Descriptions loads:
						if ($BE_USER->uc["edit_showFieldHelp"])	{
							$TCA_DESCR=t3lib_BEfunc::loadTablesDescriptions($LANG->lang!="default"?$LANG->lang:"");
						}
					}
				}
	
				if ($TSFE->forceTemplateParsing || $TSFE->displayEditIcons || $TSFE->displayFieldEditIcons)	{$TSFE->set_no_cache();}
			}
	
	//		$WEBMOUNTS = (string)($BE_USER->groupData[webmounts])!="" ? explode(",",$BE_USER->groupData[webmounts]) : Array();
	//		$FILEMOUNTS = $BE_USER->groupData[filemounts];
		} else {	// Unset the user initialization.
			$BE_USER="";
			$TSFE->beUserLogin=0; 
		}
	$TT->pull();
	$TYPO3_MISC["microtime_BE_USER_end"] = microtime();	
}


// *****************************************
// Proces the ID, type and other parameters
// After this point we have an array, $page in TSFE, which is the page-record of the current page, $id
// *****************************************
$TT->push("Process ID","");
	$TSFE->checkAlternativeIdMethods();
	$TSFE->clear_preview();
	$TSFE->determineId();

		// Now, if there is a backend user logged in and he has NO access to this page, then re-evaluate the id shown!
	if (is_object($BE_USER) && !$BE_USER->extPageReadAccess($TSFE->page))	{
			// Remove user
		$BE_USER="";
		$TSFE->beUserLogin=0; 
			// Re-evaluate the page-id.
		$TSFE->checkAlternativeIdMethods();
		$TSFE->clear_preview();
		$TSFE->determineId();
	}
$TT->pull();


// ********************************
// Starts the template
// *******************************
$TT->push("Start Template","");
	$TSFE->initTemplate();
$TT->pull();


// ********************************
// Get from cache
// *******************************
$TT->push("Get Page from cache","");
	$TSFE->getFromCache();
$TT->pull();


// ******************************************************
// Get config if not already gotten
// After this, we should have a valid config-array ready
// ******************************************************
$TSFE->getConfigArray();


// *******************************************
// Get compressed $TCA-Array();
// After this, we should now have a valid $TCA, though minimized
// *******************************************
$TSFE->getCompressedTCarray();


// *******************************************
// Setting the internal var, sys_language_uid 
// *******************************************
$TSFE->settingLanguage();


// ********************************
// Check Submission of data. 
// This is done at this point, because we need the config values
// *******************************
switch($TSFE->checkDataSubmission())	{
	case "email":
		include_once(PATH_t3lib."class.t3lib_htmlmail.php");
		include_once(PATH_t3lib."class.t3lib_formmail.php");
		$TSFE->sendFormmail();
	break;
	case "fe_tce":
		include_once(PATH_tslib."class.tslib_fetce.php");
		$TSFE->includeTCA();
		$TT->push("fe_tce","");
		$TSFE->fe_tce();
		$TT->pull();
	break;
}


// ********************************
// Check JumpUrl
// *******************************
$TSFE->checkJumpUrl();


// ********************************
// Generate page
// *******************************
$TSFE->setUrlIdToken();

$TT->push("Page generation","");
if ($TSFE->isGeneratePage())	{
		$TSFE->generatePage_preProcessing();
		$temp_theScript=$TSFE->generatePage_whichScript();

		if ($temp_theScript)	{
			include($temp_theScript);
		} else {
			include_once(PATH_tslib."class.tslib_pagegen.php");
			include(PATH_tslib."pagegen.php");
		}
		if ($TSFE->isSearchIndexPage())	{
			if ($TSFE->config["config"]["index_externals"])	{include_once(PATH_t3lib."class.t3lib_htmlmail.php");}
			include_once(PATH_tslib."class.tslib_searchindex.php");
		}
		$TSFE->generatePage_postProcessing();
} elseif ($TSFE->isINTincScript())	{
	include_once(PATH_tslib."class.tslib_pagegen.php");
	include(PATH_tslib."pagegen.php");	
}
$TT->pull();


// ********************************
// $GLOBALS["TSFE"]->config["INTincScript"] 
// *******************************
if ($TSFE->isINTincScript())		{
	$TT->push("Non-cached objects","");
		$INTiS_config = $GLOBALS["TSFE"]->config["INTincScript"];
			
			// Special feature: Include libraries
		$TT->push("Include libraries");
//		debug($INTiS_config);
		reset($INTiS_config);
		while(list(,$INTiS_cPart)=each($INTiS_config))	{
			if ($INTiS_cPart["conf"]["includeLibs"])	{
				$INTiS_resourceList = t3lib_div::trimExplode(",",$INTiS_cPart["conf"]["includeLibs"],1);
				$GLOBALS["TT"]->setTSlogMessage("Files for inclusion: '".implode(", ",$INTiS_resourceList)."'");
				reset($INTiS_resourceList);
				while(list(,$INTiS_theLib)=each($INTiS_resourceList))	{
					$INTiS_incFile=$GLOBALS["TSFE"]->tmpl->getFileName($INTiS_theLib);
					if ($INTiS_incFile)	{
						include_once($INTiS_incFile);
					} else {
						$GLOBALS["TT"]->setTSlogMessage("Include file '".$INTiS_theLib."' did not exist!",2);
					}
				}
			}
		}
		$TT->pull();
		$TSFE->INTincScript();
	$TT->pull();
}  

// ***************
// Output content
// ***************
if ($TSFE->isOutputting())	{
	$TT->push("Print Content","");
	$TSFE->processOutput();

	// ***************************************
	// Outputs content / Includes EXT scripts
	// ***************************************
	if ($TSFE->isEXTincScript())	{
		$TT->push("External PHP-script","");
				// Important global variables here are $EXTiS_*, they must not be overridden in include-scripts!!!
			$EXTiS_config = $GLOBALS["TSFE"]->config["EXTincScript"];
			$EXTiS_splitC = explode("<!--EXT_SCRIPT.",$GLOBALS["TSFE"]->content);			// Splits content with the key.

				// Special feature: Include libraries
			reset($EXTiS_config);
			while(list(,$EXTiS_cPart)=each($EXTiS_config))	{
				if ($EXTiS_cPart["conf"]["includeLibs"])	{
					$EXTiS_resourceList = t3lib_div::trimExplode(",",$EXTiS_cPart["conf"]["includeLibs"],1);
					$GLOBALS["TT"]->setTSlogMessage("Files for inclusion: '".implode(", ",$EXTiS_resourceList)."'");
					reset($EXTiS_resourceList);
					while(list(,$EXTiS_theLib)=each($EXTiS_resourceList))	{
						$EXTiS_incFile=$GLOBALS["TSFE"]->tmpl->getFileName($EXTiS_theLib);
						if ($EXTiS_incFile)	{
							include_once($EXTiS_incFile);
						} else {
							$GLOBALS["TT"]->setTSlogMessage("Include file '".$EXTiS_theLib."' did not exist!",2);
						}
					}
				}
			}

			reset($EXTiS_splitC);
			while(list($EXTiS_c,$EXTiS_cPart)=each($EXTiS_splitC))	{
				if (substr($EXTiS_cPart,32,3)=="-->")	{	// If the split had a comment-end after 32 characters it's probably a split-string
					$EXTiS_key = "EXT_SCRIPT.".substr($EXTiS_cPart,0,32);
					if (is_array($EXTiS_config[$EXTiS_key]))	{
						$REC = $EXTiS_config[$EXTiS_key]["data"];
						$CONF = $EXTiS_config[$EXTiS_key]["conf"];
						$content="";
						include($EXTiS_config[$EXTiS_key]["file"]);
						echo $content;	// The script MAY return content in $content or the script may just output the result directly!
					}
					echo substr($EXTiS_cPart,35);
				} else {
					echo ($c?"<!--EXT_SCRIPT.":"").$EXTiS_cPart;
				}
			}
			
		$TT->pull();
	} else {
		echo $GLOBALS["TSFE"]->content;
	}
	$TT->pull();
}


// ********************************
// Store session data for fe_users
// ********************************
$TSFE->storeSessionData();


// ***********
// Statistics
// ***********
$TYPO3_MISC["microtime_end"] = microtime();
$TSFE->setParseTime();
if ($TSFE->isOutputting() && ($TSFE->TYPO3_CONF_VARS["FE"]["debug"] || $TSFE->config["config"]["debug"]))	{
	echo "\n<!-- Parsetime: ".$TSFE->scriptParseTime." ms-->";
}
$TSFE->statistics();


// ***************
// Check JumpUrl
// ***************
$TSFE->jumpurl();


// *************
// Preview info
// *************
$TSFE->previewInfo();


// ******************
// Publishing static
// ******************
if (is_object($BE_USER))	{
	if ($BE_USER->extAdmModuleEnabled("publish") && $BE_USER->extPublishList)	{
		include_once(PATH_tslib."publish.php");
	}
}


// ********************
// Finish timetracking
// ********************
$TT->pull();


// ******************
// beLoginLinkIPList
// ******************
echo $GLOBALS["TSFE"]->beLoginLinkIPList();


// *************
// Admin panel
// *************
if (is_object($BE_USER) 
	&& $GLOBALS["TSFE"]->beUserLogin 
	&& $GLOBALS["TSFE"]->config["config"]["admPanel"] 
	&& $BE_USER->extAdmEnabled 
//	&& $BE_USER->extPageReadAccess($GLOBALS["TSFE"]->page)	// This is already done, if there is a BE_USER object at this point!
	&& !$BE_USER->extAdminConfig["hide"])	{
		echo $BE_USER->extPrintFeAdminDialog();
}


// *************
// Compressions
// *************
if ($TYPO3_CONF_VARS["FE"]["compressionLevel"])	{
	new gzip_encode($TYPO3_CONF_VARS["FE"]["compressionLevel"], false, $GLOBALS["TYPO3_CONF_VARS"]["FE"]["compressionDebugInfo"]);
}

?>