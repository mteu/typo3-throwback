<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Class for the built TypoScript based Front End
 *
 * This class has a lot of functions and internal variable which are use from index_ts.php.
 * The class is instantiated as $GLOBALS["TSFE"] in index_ts.php.
 *
 * The use of this class should be inspired by the order of function calls as found in index_ts.php. 
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class tslib_fe	{

		// CURRENT PAGE:
	var $id="";							// The page id (int)
	var $type="";						// RO The type (int)
	var $idParts=array();				// Loaded with the id, exploded by ","
	var $cHash="";						// The submitted cHash
	var $no_cache=""; 					// Page will not be cached. Write only true. Never clear value (some other code might have reasons to set it true)
	var $rootLine="";					// The rootLine (all the way to tree root, not only the current site!) (array)
	var $page="";						// The pagerecord (array)
	var $sys_page="";					// The object with pagefunctions (object)
	var $jumpurl="";		
	var $pageNotFound=0;				// Is set to 1 if a pageNotFound handler could have been called.

		// USER
	var $fe_user="";					// The user (object)
	var $loginUser="";					// Global falg indicating that a front-end user is logged in. This is set only if a user really IS logged in. The group-list may show other groups (like added by IP filter or so) even though there is no user. 
	var $gr_list="";					// (RO=readonly) The group list, sorted numerically. Group "0,-1" is the default group, but other groups may be added by other means than a user being logged in though...
	var $beUserLogin="";				// Flag that indicates if a Backend user is logged in!

		// PREVIEW
	var $fePreview="";					// Flag indication that preview is active. This is based on the login of a backend user and whether the backend user has read access to the current page.
	var $showHiddenPage="";				// Flag indicating that hidden pages should be shown, selected and so on. This goes for almost all selection of pages!
	var $showHiddenRecords="";			// Flag indicating that hidden records should be shown. This includes sys_template, pages_language_overlay and even fe_groups in addition to all other regular content. So in effect, this includes everything except pages.
	var $simUserGroup="0";				// Value that contains the simulated usergroup if any

		// CONFIGURATION
	var $TYPO3_CONF_VARS=array();		// The configuration array as set up in t3lib/config_default.php. Should be an EXACT copy of the global array.
	var $config="";						// "CONFIG" object from TypoScript. Array generated based on the TypoScript configuration of the current page. Saved with the cached pages.

		// TEMPLATE / CACHE
	var $tmpl="";						// The TypoScript template object. Used to parse the TypoScript template
	var $cacheTimeOutDefault="";		// Is set to the time-to-live time of cached pages. If false, default is 60*60*24, which is 24 hours.
	var $cacheContentFlag="";			// Set internally if cached content is fetched from the database
	var $all="";						// $all used by template fetching system. This array is an identification of the template. If $this->all is empty it's because the template-data is not cached, which it must be.
	var $sPre="";						// toplevel - objArrayName, eg "page"
	var $pSetup="";						// TypoScript configuration of the page-object pointed to by sPre. $this->tmpl->setup[$this->sPre."."]
	var $newHash="";					// This hash is unique to the template, the $this->id and $this->type vars and the gr_list (list of groups). Used to get and later store the cached data
	var $getMethodUrlIdToken="";		// If config.ftu (Frontend Track User) is set in TypoScript for the current page, the string value of this var is substituted in the rendered source-code with the string, "&ftu=[token...]" which enables GET-method usertracking as opposed to cookie based
	var $noCacheBeforePageGen="";		// This flag is set before inclusion of pagegen.php IF no_cache is set. If this flag is set after the inclusion of pagegen.php, no_cache is forced to be set. This is done in order to make sure that php-code from pagegen does not falsely clear the no_cache flag.
	var $tempContent="";				// This flag indicates if temporary content went into the cache during page-generation.
	var $forceTemplateParsing="";				// Boolean, passed to TypoScript template class and tells it to render the template forcibly
	var $cHash_array=array();			// The array which cHash_calc is based on, see ->makeCacheHash().
	var $hash_base="";					// Loaded with the serialized array that is used for generating a hashstring for the cache
	var $pagesTSconfig="";				// May be set to the pagesTSconfig
		// PAGE-GENERATION / cOBJ
	/*
		Eg. insert JS-functions in this array ($additionalHeaderData) to include them once. Use associative keys.
		Keys in use:
			JSFormValidate	:		<SCRIPT LANGUAGE="JavaScript" SRC="'.$GLOBALS["TSFE"]->absRefPrefix.'t3lib/jsfunc.validateform.js"></SCRIPT>
			JSincludeFormupdate :	<SCRIPT LANGUAGE='JavaScript' SRC='t3lib/jsfunc.updateform.js'></SCRIPT>
			JSMenuCode, JSMenuCode_menu :			JavaScript for the JavaScript menu
			JSCode : reserved
			JSImgCode : reserved
	*/
	var $additionalHeaderData=array();	// used to accumulate additional HTML-code for the header-section, <head>...</head>. Insert either associative keys (like additionalHeaderData["myStyleSheet"], see reserved keys above) or num-keys (like additionalHeaderData[] = "...")
	var $additionalJavaScript=array();	// used to accumulate additional JavaScript-code. Works like additionalHeaderData. Reserved keys at "openPic" and "mouseOver"
	var $JSCode="";						// Depreciated, use additionalJavaScript instead.
	var $JSImgCode="";					// Used to accumulate JavaScript loaded images (by menus)
	var $divSection="";					// Used to accumulate DHTML-layers.

		// RENDERING configuration, settings from TypoScript is loaded into these vars. See pagegen.php
	var $debug="";						// Debug flag, may output special debug html-code.
	var $intTarget="";					// Default internal target
	var $extTarget="";					// Default external target
	var $absRefPrefix="";				// Absolute Reference prefix
	var $absRefPrefix_force=0;			// Absolute Reference prefix force flag. This is set, if the type and id is retrieve from PATH_INFO and thus we NEED to prefix urls with at least "/"
	var $compensateFieldWidth="";		// Factor for form-field widths compensation
	var $lockFilePath="";				// Lock file path
	var $ATagParams="";					// <A>-tag parameters
	var $sWordRegEx="";					// Search word regex, calculated if there has been search-words send. This is used to mark up the found search words on a page when jumped to from a link in a search-result.
	var $sWordList="";					// Is set to the incoming array sword_list in case of a page-view jumped to from a search-result.
	var $linkVars="";					// A string prepared for insertion in all links on the page as url-parameters. Based on configuration in TypoScript where you defined which GET_VARS you would like to pass on.
	var $displayEditIcons="";			// If set, edit icons are rendered aside content records. Must be set only if the ->beUserLogin flag is set and set_no_cache() must be called as well.
	var $displayFieldEditIcons="";		// If set, edit icons are rendered aside individual fields of content. Must be set only if the ->beUserLogin flag is set and set_no_cache() must be called as well.
	var $sys_language_uid=0;			// Site language, 0 (zero) is default, int+ is uid pointing to a sys_language record.

		// RENDERING data 
	var $register=Array();				
	var $registerStack=Array();			// Stack used for storing array and retrieving register arrays (see LOAD_REGISTER and CLEAR_REGISTER)
	var $cObjectDepthCounter = 50;		// Checking that the function is not called eternally. This is done by interrupting at a depth of 50
	var $recordRegister = Array();		// used by cObj->RECORDS and cObj->CONTENT to ensure the a records is NOT rendered twice through it!
	var $currentRecord = "";			// This is set to the [table]:[uid] of the latest record rendered. Note that class tslib_cObj has an equal value, but that is pointing to the record delivered in the $data-array of the tslib_cObj instance, if the cObjects CONTENT or RECORD created that instance
	var $accessKey =array();			// Used by class tslib_menu to keep track of access-keys.
	var $imagesOnPage=array();			// Numerical array where image filenames are added if they are referenced in the rendered document. This includes only Typo3 generated/inserted images.
	var $lastImageInfo=array();			// Is set in tslib_cObj->cImage() function to the info-array of the most recent rendered image. The information is used in tslib_cObj->IMGTEXT
	var $uniqueCounter=0;				// Used to generate page-unique keys. Point is that uniqid() functions is very slow, so a unikey key is made based on this, see function uniqueHash()
	var $uniqueString="";

		// Page content render object
	var $cObj ="";						// is instantiated object of tslib_cObj
	
		// CONTENT accumulation
	var $content="";					// All page content is accumulated in this variable. See pagegen.php
	
		// GENERAL
	var $clientInfo="";				// Set to the browser: net / msie if 4+ browsers
	var $scriptParseTime=0;
	var $TCAloaded = 0;			// Set ONLY if the full TCA is loaded
	
	/** 
	 * Class constructor
	 */
	function tslib_fe($TYPO3_CONF_VARS, $id, $type, $no_cache="", $cHash="", $jumpurl="")	{
			// Setting some variables:
		$this->id = $id;
		$this->type = $type;
		$this->no_cache = $no_cache ? 1 : 0;
		$this->cHash = $cHash;
		$this->jumpurl = $jumpurl;
		$this->TYPO3_CONF_VARS = $TYPO3_CONF_VARS;
		$this->clientInfo = t3lib_div::clientInfo();
		$this->uniqueString=md5(microtime());
		$this->makeCacheHash();
	}

	/** 
	 * Connect to MySQL
	 */
	function connectToMySQL()	{
		if (@mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
			if (!TYPO3_db)	{
				$this->printError("No database selected","Database Error");
				echo '<script>
					document.location = "typo3/install/index.php?mode=123&step=1&password=joh316";
					</script>';
				exit;
			} elseif (!mysql_select_db(TYPO3_db))	{
				$this->printError("Cannot connect to the current database, '".TYPO3_db."'","Database Error");
				exit;
			}
		} else {
			$this->printError("The current username, password or host was not accepted when the connection to the database was attempted to be established!","Database Error");
			exit;
		}
	}

	/** 
	 * Pass the content through tidy - a little program that cleans up HTML-code
	 */
	function tidyHTML($content)		{
		if ($this->TYPO3_CONF_VARS["FE"]["tidy"] && $this->TYPO3_CONF_VARS["FE"]["tidy_path"])	{
			$oldContent = $content;
			$fname = tempnam("","Typo3_Tidydoc_");		// Create temporary name
			@unlink ($fname);	// Delete if exists, just to be safe.
			$fp = fopen ($fname,"w");	// Open for writing
			fputs ($fp, $content);	// Put $content
			@fclose ($fp);	// Close
		
			exec ($this->TYPO3_CONF_VARS["FE"]["tidy_path"]." ".$fname, $output);			// run the $content through "tidy", which formats the HTML to nice code.
			@unlink ($fname);	// Delete the tempfile again
			$content = implode($output,chr(10));	
			if (!trim($content))	{
				$content = $oldContent;	// Restore old content due empty return value.
				$GLOBALS["TT"]->setTSlogMessage("'tidy' returned an empty value!",2);
			}
			$GLOBALS["TT"]->setTSlogMessage("'tidy' content lenght: ".strlen($content),0);
		}
		return $content;
	}

	/** 
	 * Gets the page and rootline arrays based on the id, $this->id
	 *
	 * If the id does not correspond to a proper page, the "previous" valid page in the rootline is found
	 * If the page is a shortcut (doktype=4), the ->id is loaded with that id
	 * 
	 * Whether or not the ->id is changed to the shortcut id or the previous id in rootline (eg if a page is hidden), the ->page-array and ->rootline is found and must also be valid.
	 */
	function getPageAndRootline() {
		$this->page = $this->sys_page->getPage($this->id);
		if (!count($this->page))	{
			// If no page, we try to find the page before in the rootLine.
			$this->pageNotFound=1;			// Page is "not found" in case the id itself was not an accessible page. code 1
			$this->rootLine = $this->sys_page->getRootLine($this->id);		
			if (count($this->rootLine))	{
				$c=count($this->rootLine)-1;
				while($c>0)	{
					$c--;
					$this->id=$this->rootLine[$c]["uid"];
					$this->page = $this->sys_page->getPage($this->id);
					if (count($this->page)){break;}
				}
			}
			// If still no page...
			if (!count($this->page))	{
				$this->printError("The requested page does not exist!");
				exit;
			}
		}
		// Is the ID a link to another page??
		if ($this->page["doktype"]==4)	{
			$this->page = $this->getPageShortcut($this->page["shortcut"]);
			$this->id = $this->page["uid"];
		}
		// Gets the rootLine
		$this->rootLine = $this->sys_page->getRootLine($this->id);
	
		// If not rootline we're off...
		if (!count($this->rootLine))	{
			$this->printError("The requested page didn't have a proper connection to the tree-root!");
			exit;
		}
		
		// Checking for include section regarding the hidden/starttime/endtime/fe_user (that is access control of a whole subbranch!)
		if ($this->checkRootlineForIncludeSection())	{
			if (!count($this->rootLine))	{
				$this->printError("The requested page was not accessible!");
				exit;
			} else {
				$el = reset($this->rootLine);
				$this->id = $el["uid"];
				$this->page = $this->sys_page->getPage($this->id);
				$this->rootLine = $this->sys_page->getRootLine($this->id);
			}
		}
	}
	
	/** 
	 * Get page shortcut
	 */
	function getPageShortcut($SC,$itera=20,$pageLog=array())	{
		$idArray = t3lib_div::intExplode(",",$SC);
		$page = $this->sys_page->getPage($idArray[0]);
		if ($page["doktype"]==4)	{
			if (!in_array($page["uid"],$pageLog) && $itera>0)	{
				$pageLog[] = $page["uid"];
				$page = $this->getPageShortcut($page["shortcut"],$itera-1,$pageLog);
			} else {
				$pageLog[] = $page["uid"];
				$this->printError("Page shortcuts were looping in uids ".implode(",",$pageLog)."...!");
				exit;
			}
		}
		return $page;
	}

	/** 
	 * Checks the current rootline for defined sections.
	 */
	function checkRootlineForIncludeSection()	{
		$c=count($this->rootLine);
		$removeTheRestFlag=0;	
		for ($a=0;$a<$c;$a++)	{
			if (!$this->checkPagerecordForIncludeSection($this->rootLine[$a]))	{
				$removeTheRestFlag=1;
			}
			if ($this->rootLine[$a]["doktype"]==6)	{
				if ($this->beUserLogin)	{	// If there is a backend user logged in, check if he has read access to the page:
					$query = "SELECT uid FROM pages WHERE uid=".$this->id." AND ".$GLOBALS["BE_USER"]->getPagePermsClause(1);
					$res=mysql(TYPO3_db,$query);
					list($isPage)=mysql_fetch_row($res);
					if (!$isPage)	$removeTheRestFlag=1;	// If there was no page selected, the user apparently did not have read access to the current PAGE (not position in rootline) and we set the remove-flag...
				} else {	// Dont go here, if there is no backend user logged in.
					$removeTheRestFlag=1;
				}
//debug("Backend User Section:".$removeTheRestFlag);
			}
			if ($removeTheRestFlag)	{
				$this->pageNotFound=2;			// Page is "not found" in case a subsection was found and not accessible, code 2
				unset($this->rootLine[$a]);
			}
		}
		return $removeTheRestFlag;
	}

	/** 
	 * Checks page record for enableFields
	 * Returns true if enableFields does not disable the page record.
	 */
	function checkEnableFields($row)	{
		if ((!$row["hidden"] || $this->showHiddenPage)
			&& $row["starttime"]<=$GLOBALS["SIM_EXEC_TIME"] 
			&& ($row["endtime"]==0 || $row["endtime"]>$GLOBALS["SIM_EXEC_TIME"])
			&& t3lib_div::inList($this->gr_list,$row["fe_group"])
		) {
			return 1;
		}
	}
	
	/** 
	 * Checks page record for include section
	 * Returns true if either extendToSubpages is not checked or if the enableFields does not disable the page record.
	 */
	function checkPagerecordForIncludeSection($row)	{
		return (!$row["extendToSubpages"] || $this->checkEnableFields($row)) ? 1 : 0;
	}
	
	/** 
	 * Clears the preview-flags, sets sim_exec_time to current time.
	 * 
	 * hidden pages must be hidden as default, $GLOBALS["SIM_EXEC_TIME"] is set to $GLOBALS["EXEC_TIME"] in t3lib/config_default.inc. Alter it by adding or subtracting seconds.
	 */
	function clear_preview()	{
		$this->showHiddenPage = 0;
		$this->showHiddenRecords = 0;
		$GLOBALS["SIM_EXEC_TIME"] = $GLOBALS["EXEC_TIME"];	
		$this->fePreview = 0;
	}

	/** 
	 * Sets the cache-flag to 1. Could be called from user-included php-files in order to ensure that a page is not cached.
	 */
	function set_no_cache()	{
		$this->no_cache = 1;
	}

	/** 
	 * Sets the cache-timeout in seconds
	 */
	function set_cache_timeout_default($seconds)	{
		$this->cacheTimeOutDefault = intval($seconds);
	}

	/**
	 * Get uniqueCounter
	 */
	function uniqueHash($str="")	{
		return md5($this->uniqueString."_".$str.$this->uniqueCounter++);
	}
	
	/** 
	 * Get The Page ID
	 *
	 * This gets the id of the page, 
	 * checks if the page is in the domain 
	 * and if the page is accessible
	 */
	function fetch_the_id()	{
		$GLOBALS["TT"]->push("fetch_the_id initialize/","");
			// Initialize the page-select functions. 
		$this->sys_page = t3lib_div::makeInstance("t3lib_pageSelect");
		$this->sys_page->init($this->showHiddenPage);
			// Sets ->loginUser and ->gr_list based on front-end user status.
		$this->fe_user->showHiddenRecords = $this->showHiddenRecords;		// This affects the hidden-flag selecting the fe_groups for the user!
		if (is_array($this->fe_user->user) && $this->fe_user->fetchGroupData())	{
			$this->loginUser=1;	// global flag!
			$this->gr_list = "0,-2";	// group -2 is not an existing group, but denotes a "default" group when a user IS logged in. This is used to let elements be shown for all logged in users!
			$gr_array = $this->fe_user->groupData["uid"];
		} else {
			$this->loginUser=0;
			$this->gr_list = "0,-1";	// group -1 is not an existing group, but denotes a "default" group when not logged in. This is used to let elements be hidden, when a user is logged in!
			$gr_array=array();
		}
			// ADD group-numbers if the IPmask matches.
		if (is_array($GLOBALS["TYPO3_CONF_VARS"]["FE"]["IPmaskMountGroups"]))	{
			reset($GLOBALS["TYPO3_CONF_VARS"]["FE"]["IPmaskMountGroups"]);
			while(list(,$IPel)=each($GLOBALS["TYPO3_CONF_VARS"]["FE"]["IPmaskMountGroups"]))	{
				if (getenv("REMOTE_ADDR") && $IPel[0] && t3lib_div::cmpIP(getenv("REMOTE_ADDR"),$IPel[0]))	{$gr_array[]=intval($IPel[1]);}
			}
		}

			// Clean up.
		$gr_array = array_unique($gr_array);	// Make unique...
		sort($gr_array);	// sort
		if (count($gr_array))	{
			$this->gr_list.=",".implode(",",$gr_array);
		}
//debug($this->gr_list);


			// Sets sys_page where-clause
		$this->sys_page->where_hid_del.=" AND doktype<200 AND fe_group IN (".$this->gr_list.")";
			
		// Fetches the $this->id
		if (!$this->id)	{
			list($theAlias) = explode("&",getenv("QUERY_STRING"));
			$theAlias = trim($theAlias);
			$this->id = $theAlias ? $theAlias : 0;
		}
		
		// Splitting $this->id by a period (.). First part is 'id' and second part - if exists - will overrule the &type param if given 
		$pParts = explode(".",$this->id);
		$this->id = $pParts[0];	// Set it.
		if (isset($pParts[1]))	{$this->type=$pParts[1];}
		
		// Splitting $this->id by a comma (,). First part is 'id' and other parts are just stored for use in scripts. 
		$this->idParts = explode(",",$this->id);
		$this->id = $this->idParts[0];	// Set it.
		
		// If $this->id is a string, it's an alias
		if ($this->id && !t3lib_div::testInt($this->id))	{
			$aid = $this->sys_page->getPageIdFromAlias($this->id);
			if ($aid)	{$this->id=$aid;}
		}
		
		// The id and type is set to the integer-value - just to be sure...
		$this->id = intval($this->id);
		$this->type = intval($this->type);
		$GLOBALS["TT"]->pull();

		// We find the first page belonging to the current domain
		$GLOBALS["TT"]->push("fetch_the_id domain/","");
		$domainStartPage = $this->findDomainRecord($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["recursiveDomainSearch"]);	// the page_id of the current domain 
		if (!$this->id)	{
			if ($domainStartPage)	{
				$this->id = $domainStartPage;	// If the id was not previously set, set it to the id of the domain.
			} else {
				$theFirstPage = $this->sys_page->getFirstWebPage($this->id);	// Find the first "visible" page in that domain
				if ($theFirstPage)	{
					$this->id = $theFirstPage[uid];
				} else {
					$this->printError("No pages are found on the rootlevel!");
					exit;
				}
			}
		}
		$GLOBALS["TT"]->pull();

		$GLOBALS["TT"]->push("fetch_the_id rootLine/","");
		$requestedId = $this->id;		// We store the originally requested id
		$this->getPageAndRootline();	// Gets ->page and ->rootline information based on ->id. ->id may change during this operation.

		// Checks if the $domain-startpage is in the rootLine. This is necessary so that references to page-id's from other domains are not possible.
		if ($domainStartPage && is_array($this->rootLine)) {
			reset ($this->rootLine);
			$idFound = 0;
			while(list($key,$val)=each($this->rootLine)) {
				if ($val["uid"]==$domainStartPage)	{
					$idFound=1;
					break;
				}
			}
			if (!$idFound)	{
				$this->pageNotFound=3;			// Page is "not found" in case the id was outside the domain, code 3
				$this->id = $domainStartPage;
				$this->getPageAndRootline();		//re-get the page and rootline if the id was not found.
			}
		}
		$GLOBALS["TT"]->pull();

		if ($this->pageNotFound && $this->TYPO3_CONF_VARS["FE"]["pageNotFound_handling"])	{
			$this->pageNotFoundHandler($this->TYPO3_CONF_VARS["FE"]["pageNotFound_handling"]);
		}
		// set no_cache if set
		if ($this->page["no_cache"])	{
			$this->set_no_cache();
		}
		$this->register["SYS_LASTCHANGED"] = intval($this->page["tstamp"]);
	}

	/**
	 * Page not found handler
	 */
	function findDomainRecord($recursive=0)	{
		if ($recursive)	{
			$host = explode(".",getenv("HTTP_HOST"));
			while(count($host))	{
				$pageUid = $this->sys_page->getDomainStartPage(implode(".",$host),t3lib_div::getIndpEnv("SCRIPT_NAME"));	
				if ($pageUid)	return $pageUid; else array_shift($host);
			}
			return $pageUid;
		} else {
			return $this->sys_page->getDomainStartPage(getenv("HTTP_HOST"),t3lib_div::getIndpEnv("SCRIPT_NAME"));	
		}
	}

	/**
	 * Page not found handler
	 */
	function pageNotFoundHandler($code)	{
		header("Status: 404 Not Found");
		if (gettype($code)=="boolean" || !strcmp($code,1))	{
			$this->printError("The page did not exist or was inaccessible.");
			exit;
		} else if (t3lib_div::testInt($code))	{
			$this->printError("Error ".$code);
			exit;
		} else {
			header("Location: ".$code);
		}
	}

	/** 
	 * Provides was to bypass the "?id=[xxx]&type=[xx]" format.
	 *
	 * Two options:
	 * 1) Apache mod_rewrite: Here a .htaccess file maps all .html-files to index.php and then we extract the id and type from the name of that HTML-file.
	 * 2) Use PATH_INFO (also Apache) to extract id and type from that var. Does not require any special modules compiled with apache.
	 *
	 * @see TSref.pdf
	 */
	function checkAlternativeIdMethods()	{
		IF (TYPO3_OS=="WIN")	return;

			// Support for RewriteRule to generate   (simulateStaticDocuments)
			// With the mod_rewrite compiled into apache, put these lines into a .htaccess in this directory:
			//
			// 			RewriteEngine On
			// 			RewriteRule   ^[^/]*\.html$  index.php
			
			// The url must end with ".html" and the format must comply with either of these:
			// 1:      "[title].[id].[type].html"			- title is just for easy recognition in the logfile!; no practical use of the title for Typo3.
			// 2:      "[id].[type].html"					- above, but title is omitted; no practical use of the title for Typo3.
			// 3:      "[id].html"							- only id, type is set to the default, zero!
			// NOTE: In all case "id" may be the uid-numer OR the page alias (if any)
	
		if ($GLOBALS["HTTP_SERVER_VARS"]["REDIRECT_URL"])	{		// If there has been a redirect this can happend either due to a CGI-script or because of reWrite rule.
			$uParts = parse_url($GLOBALS["HTTP_SERVER_VARS"]["REQUEST_URI"]);
			$requestFilename = trim(ereg_replace(".*\/","",$uParts["path"]));		// This is the filename of the script/simulated html-file.
			if ($requestFilename && substr($requestFilename,-4)!=".php")	{
				$parts = explode(".",ereg_replace(".*\/","",$requestFilename));
				$pCount = count($parts);
				if ($parts[$pCount-1]="html")	{
					if ($pCount>2)	{
						$this->type = intval($parts[$pCount-2]);
						$this->id= $parts[$pCount-3];
					} else {
						$this->type = 0;
						$this->id= $parts[0];
					}
				}
			}
		}
			// If PATH_INFO
		if (getenv("PATH_INFO"))	{		// If pathinfo contains stuff...
			if (getenv("PATH_INFO")!=t3lib_div::getIndpEnv("SCRIPT_NAME") && count(explode("/",getenv("PATH_INFO")))>1)	{	// There must be at least one "/" in the path - else the PATH_INFO value does not make sense., ALSO getenv("PATH_INFO")!=t3lib_div::getIndpEnv("SCRIPT_NAME") is necessary because some servers are seen to set pathinfo equal to script_name
				$parts=t3lib_div::trimExplode("/",getenv("PATH_INFO"),1);
				$parts[]="html";
				$pCount = count($parts);
				if ($pCount>2)	{
					$this->type = intval($parts[$pCount-2]);
					$this->id= $parts[$pCount-3];
				} else {
					$this->type = 0;
					$this->id= $parts[0];
				}
				$this->absRefPrefix_force=1;
			}
		}
			
	}

	/** 
	 * Determines the id and evaluates any preview settings
	 * 
	 * Basically this function is about determining whether a backend user is logged in, if he has read access to the page and if he's previewing the page. That all determines which id to show and how to initialize the id.
	 *
	 * public
	 */
	function determineId()	{
		$GLOBALS["TT"]->push("beUserLogin","");
		if ($this->beUserLogin)	{		// If a backend user is logged in.
			$this->fePreview = $GLOBALS["BE_USER"]->extGetFeAdminValue("preview");
			if (!$this->fePreview)	{				// If FE_PREVIEW has not been set by any previous action, it's investigated if the raw page-id points to a hidden page and if so, the flag is set.
				// ... moved to after this section...
			} else {	// If front-end preview is enabled...
				$fe_user_OLD_USERGROUP = $this->fe_user->user["usergroup"];

				$this->showHiddenPage = $GLOBALS["BE_USER"]->extGetFeAdminValue("preview","showHiddenPages");
				$this->showHiddenRecords = $GLOBALS["BE_USER"]->extGetFeAdminValue("preview","showHiddenRecords");
					// simulate date
				$simTime = $GLOBALS["BE_USER"]->extGetFeAdminValue("preview","simulateDate");
				if ($simTime)	$GLOBALS["SIM_EXEC_TIME"]=$simTime;
					// simulate user
				$simUserGroup = $GLOBALS["BE_USER"]->extGetFeAdminValue("preview","simulateUserGroup");
				$this->simUserGroup = $simUserGroup;
				if ($simUserGroup)	$this->fe_user->user["usergroup"]=$simUserGroup; 
				if (!$simUserGroup && !$simTime && !$this->showHiddenPage && !$this->showHiddenRecords)	{
					$this->fePreview=0;
				}
			}
			//... inserted begin
			if (t3lib_div::testInt($this->id))	{
				$query="SELECT hidden FROM pages WHERE uid = '".$this->id."' AND hidden AND NOT deleted";
				$GLOBALS["TT"]->setTSselectQuery($query,"determineId");
				$res = mysql(TYPO3_db, $query);
				if (mysql_num_rows($res))	{
					$this->fePreview=1;	// The preview flag is set only if the current page turns out to actually be hidden!
					$this->showHiddenPage = 1;
				}
			}
			//... inserted end
			if ($this->fePreview)	{	// If the front-end is showing a preview, caching MUST be disabled.
				$this->set_no_cache();
			}
		}
		$GLOBALS["TT"]->pull();

		$this->fetch_the_id();
		if ($this->beUserLogin && $this->fePreview)	{	// Check if backend user has read access to this page. If not, recalculate the id.
			if (!$GLOBALS["BE_USER"]->doesUserHaveAccess($this->page,1))	{
					// resetting
				$this->clear_preview();
				$this->fe_user->user["usergroup"] = $fe_user_OLD_USERGROUP;
					// fetching the id again, now with the preview settings reset.
				$this->fetch_the_id();
			} 
		}	
		$this->id=intval($this->id);	// Make sure it's an integer
		$this->type=intval($this->type);	// Make sure it's an integer
	}

	/** 
	 * Initializes the front-end login user.
	 */
	function initFEuser()	{
		$this->fe_user = t3lib_div::makeInstance("tslib_feUserAuth");
			
		$this->fe_user->checkPid = $this->TYPO3_CONF_VARS["FE"]["checkFeUserPid"];
//		$this->fe_user->checkPid_value = $GLOBALS["HTTP_POST_VARS"]["pid"];
		$this->fe_user->checkPid_value = t3lib_div::GPvar("pid");

			// Check if a session is transferred:
		if (t3lib_div::GPvar("FE_SESSION_KEY"))	{
			$fe_sParts = explode("-",t3lib_div::GPvar("FE_SESSION_KEY"));
			if (!strcmp(md5($fe_sParts[0]."/".$this->TYPO3_CONF_VARS["SYS"]["encryptionKey"]), $fe_sParts[1]))	{	// If the session key hash check is OK:
				$GLOBALS["HTTP_COOKIE_VARS"][$this->fe_user->name]=$fe_sParts[0];
				$this->fe_user->forceSetCookie=1;
			}
		}
		
		if ($this->TYPO3_CONF_VARS["FE"]["dontSetCookie"])	{
			$this->fe_user->dontSetCookie=1;
		}
	
//		debug($GLOBALS["HTTP_POST_VARS"]);
		$this->fe_user->start();
		$this->fe_user->unpack_uc("");
		$this->fe_user->fetchSessionData();	// Gets session data
		$recs = t3lib_div::GPvar("recs");
		if (is_array($recs))	{	// If any record registration is submitted, register the record.
			$this->fe_user->record_registration($recs);
		}
	}

	/** 
	 * Initialize the TypoScript template
	 */
	function initTemplate()	{
		$this->tmpl = t3lib_div::makeInstance("t3lib_TStemplate");
		$this->tmpl->init();
		$this->tmpl->tt_track= $this->beUserLogin ? 1 : 0;
	}

	/** 
	 * Calculates the cache-hash
	 */
	function getHash()	{
		// This hash is unique to the template, the ->id and ->type vars and the ->gr_list (list of groups). Used to get and later store the cached data
		$this->hash_base = serialize(
			array(
				"all"=>$this->all,
				"id"=>intval($this->id),
				"type"=>intval($this->type),
				"gr_list"=>$this->gr_list,
				"cHash"=>$this->cHash_array
			)
		);
		return md5($this->hash_base);
	}

	/** 
	 * Calculates a hash string based on additional parameters in the url. This is used to cache pages with more parameters than just id and type
	 */
	function makeCacheHash()	{
		if ($this->cHash && is_array($GLOBALS["HTTP_GET_VARS"]))	{
			$pA=array();
			$pList=array();
			reset($GLOBALS["HTTP_GET_VARS"]);
			while(list($theK,$theV)=each($GLOBALS["HTTP_GET_VARS"]))	{
				if (!t3lib_div::inList("id,type,no_cache,cHash,ftu",$theK))	{
					$pA[$theK]=(string)stripslashes($theV);
					$pList[]=$theK;
				}
			}
			$pA["encryptionKey"]=$this->TYPO3_CONF_VARS["SYS"]["encryptionKey"];
			ksort($pA);
			$this->cHash_array = $pA;
			$cHash_calc = t3lib_div::shortMD5(serialize($this->cHash_array));
			if ($cHash_calc!=$this->cHash)	{
				$this->set_no_cache();
				$GLOBALS["TT"]->setTSlogMessage("The incoming cHash '".$this->cHash."' and calculated cHash '".$cHash_calc."' did not match, so caching was disabled. The fieldlist used was '".implode($pList,",")."'",2);
			}
		}	
	}
	
	/** 
	 * see if page is in cache and get it if so
	 */
	function getFromCache()	{
		$this->tmpl->getCurrentPageData();
		$cc=Array();
		if (is_array($this->tmpl->currentPageData))	{
				// BE CAREFULL to change the content of the cc-array. This array is serialized and an md5-hash based on this is used for caching the page. 
				// If this hash is not the same in here in this section and after page-generation the page will not be properly cached!
		
			$cc["all"] = $this->tmpl->currentPageData["all"];
			$cc["rowSum"] = $this->tmpl->currentPageData["rowSum"];
			$cc["rootLine"] = $this->tmpl->currentPageData["rootLine"];		// This rootline is used with templates only (matching()-function)
			$this->all = $this->tmpl->matching($cc);	// This array is an identification of the template. If $this->all is empty it's because the template-data is not cached, which it must be.
			ksort($this->all);
		}
		// t3lib_div::print_array($this->all);
		
		$this->content="";	// clearing the content-variable, which will hold the pagecontent
		unset($this->config);	// Unsetting the lowlevel config
		$this->cacheContentFlag=0;
		if ($this->all && !$this->no_cache)	{
			$this->newHash = $this->getHash();
			$query = "SELECT S.* FROM cache_pages S,pages P WHERE S.hash='".$this->newHash."' AND S.page_id=P.uid AND S.expires > ".$GLOBALS["EXEC_TIME"]." AND NOT P.deleted AND NOT P.hidden AND P.starttime<=".$GLOBALS["EXEC_TIME"]." AND (P.endtime=0 OR P.endtime>".$GLOBALS["EXEC_TIME"].")";
			$GLOBALS["TT"]->setTSselectQuery($query,"getFromCache");

		$GLOBALS["TT"]->push("Cache Query","");
			$res = mysql (TYPO3_db, $query);	// getting cached page.
		$GLOBALS["TT"]->pull();
		$GLOBALS["TT"]->push("Cache Row","");
			if ($row = mysql_fetch_assoc($res))	{
				$this->config = unserialize($row["cache_data"]);		// Fetches the lowlevel config stored with the cached data
				$this->content = $row[HTML];	// Getting the content
				$this->cacheContentFlag=1;	// Setting flag, so we know, that some cached content is gotten.
				
				if ($this->TYPO3_CONF_VARS["FE"]["debug"] || $this->config["config"]["debug"])	{
					$this->content.="\n<!-- Cached page generated ".Date("d/m Y H:i", $row[tstamp]).". Expires ".Date("d/m Y H:i", $row[expires])." -->";
				}
			}
		$GLOBALS["TT"]->pull();
		}	
	}

	/** 
	 * checks if config-array exists already but if not, gets it
	 */
	function getConfigArray()	{
		if (!is_array($this->config) || is_array($this->config["INTincScript"]) || $this->forceTemplateParsing)	{	// If config is not set by the cache (which would be a major mistake somewhere) OR if INTincScripts-include-scripts has been registered, then we must parse the template in order to get it 
				$GLOBALS["TT"]->push("Parse template","");
			$this->tmpl->forceTemplateParsing = $this->forceTemplateParsing;
			$this->tmpl->start($this->rootLine);
				$GLOBALS["TT"]->pull();
				
			if ($this->tmpl->loaded)	{
				$GLOBALS["TT"]->push("Setting the config-array","");
			//	t3lib_div::print_array($this->tmpl->setup);
				$this->sPre = $this->tmpl->setup["types."][$this->type];	// toplevel - objArrayName
				$this->pSetup = $this->tmpl->setup[$this->sPre."."];

				if (!is_array($this->pSetup))	{
					$this->printError("The page is not configured! [type= ".$this->type."][".$this->sPre."]");
					exit;
				} else {
					$this->config["config"]=Array();
					
						// Filling the config-array.
					if (is_array($this->tmpl->setup["config."]))	{
						$this->config["config"] = $this->tmpl->setup["config."];
					}
					if (is_array($this->pSetup["config."]))	{
						reset($this->pSetup["config."]);
						while(list($theK,$theV)=each($this->pSetup["config."]))	{
							$this->config["config"][$theK] = $theV;
						}
					}
						// if .simulateStaticDocuments was not present, the default value will rule.
					if (!isset($this->config["config"]["simulateStaticDocuments"]))	{
						$this->config["config"]["simulateStaticDocuments"]=$this->TYPO3_CONF_VARS["FE"]["simulateStaticDocuments"];
					}
		
							// Processing for the config_array:
					$this->config["rootLine"] = $this->tmpl->rootLine;
					$this->config["mainScript"] = trim($this->config["config"]["mainScript"]) ? trim($this->config["config"]["mainScript"]) : "index.php";
					
						// STAT:
					$theLogFile = $this->TYPO3_CONF_VARS["FE"]["logfile_dir"].$this->config["config"]["stat_apache_logfile"];
					if ($this->config["config"]["stat_apache"] && 
						$this->config["config"]["stat_apache_logfile"] &&
						!strstr($this->config["config"]["stat_apache_logfile"],"/") && 
						@is_dir($this->TYPO3_CONF_VARS["FE"]["logfile_dir"]) && @is_file($theLogFile)	&& @is_writeable($theLogFile))	{
							$this->config["stat_vars"]["logFile"] = $theLogFile;
							$shortTitle = substr(ereg_replace("[^\.[:alnum:]_-]","_",$this->page[title]),0,30);
							$pageName = $this->config["config"]["stat_apache_pagenames"] ? $this->config["config"]["stat_apache_pagenames"] : "[path][title]--[uid].html";
							$pageName = str_replace("[title]", $shortTitle ,$pageName);
							$pageName = str_replace("[uid]",$this->page[uid],$pageName);
							$pageName = str_replace("[alias]",$this->page[alias],$pageName);
							$pageName = str_replace("[type]",$this->page[type],$pageName);
							$temp = $this->config["rootLine"];	
							array_pop($temp);		
							$pageName = str_replace("[path]", ereg_replace("[^\.[:alnum:]\/_-]","_",$this->sys_page->getPathFromRootline($temp))."/" ,$pageName);		
							$this->config["stat_vars"]["pageName"] = $pageName;
					}
					$this->config["FEData"] = $this->tmpl->setup["FEData"];
					$this->config["FEData."] = $this->tmpl->setup["FEData."];
				}
				$GLOBALS["TT"]->pull();
			} else {
				$this->printError("No template found!");
				exit;
			}
		}
			// No cache
		if ($this->config["config"]["no_cache"])	{$this->set_no_cache();}		// Set $this->no_cache true if the config.no_cache value is set!

			// Check PATH_INFO url
		if ($this->absRefPrefix_force && strcmp($this->config["config"]["simulateStaticDocuments"],"PATH_INFO"))	{
			$redirectUrl = "http://".t3lib_div::getThisUrl()."index.php?id=".$this->id."&type=".$this->type;
			if ($this->config["config"]["simulateStaticDocuments_dontRedirectPathInfoError"])	{
				$this->printError("PATH_INFO was not configured for this website, and the URL tries to find the page by PATH_INFO!<BR><BR><a href=\"".$redirectUrl."\">Click here to get to the right page.</a>","Error: PATH_INFO not configured");
			} else {
				header("Location: ".$redirectUrl);
			}
			exit;
//			$this->set_no_cache();	// Set no_cache if PATH_INFO is NOT used as simulateStaticDoc. and if absRefPrefix_force shows that such an URL has been passed along.
		}
	}

	/** 
	 * Setting the language key that'll be used by the current page.
	 * In this function it should be checked, 1) that this language exists, 2) that a page_overlay_record exists, .. and if not the default language, 0 (zero), should be set.
	 */
	function settingLanguage()	{
		$this->sys_language_uid = intval($this->config["config"]["sys_language_uid"]);
		$olRec = $this->sys_page->getPageOverlay($this->id,$this->sys_language_uid);
		if (!count($olRec))	{
			$this->sys_language_uid=0;
		} else {
			$this->page = $this->sys_page->getPageOverlay($this->page,$this->sys_language_uid);
		}
		$this->sys_page->sys_language_uid = $this->sys_language_uid;
		
			// Updating content of the two rootLines IF the language key is set!
		if ($this->sys_language_uid && is_array($this->tmpl->rootLine))	{
			reset($this->tmpl->rootLine);
			while(list($rLk)=each($this->tmpl->rootLine))	{
				$this->tmpl->rootLine[$rLk] = $this->sys_page->getPageOverlay($this->tmpl->rootLine[$rLk]);
			}
		}
		if ($this->sys_language_uid && is_array($this->rootLine))	{
			reset($this->rootLine);
			while(list($rLk)=each($this->rootLine))	{
				$this->rootLine[$rLk] = $this->sys_page->getPageOverlay($this->rootLine[$rLk]);
			}
		}
	}
	
	/** 
	 * get the compressed $TCA array for use in the front-end
	 *
	 * A compressed $TCA array holds only the ctrl-part for each table plus a little more. But the column-definitions are omitted in order to save some memory and be more efficient...
	 */
	function getCompressedTCarray()	{
		global $TCA;
		
		$GLOBALS["TT"]->push("Get Compressed TC array");
		if (!$this->TCAloaded)	{
			$tempHash = md5("tables.php:".
				filemtime(TYPO3_extTableDef_script ? PATH_typo3conf.TYPO3_extTableDef_script : PATH_t3lib."install/tables.php").
				(TYPO3_extTableDef_script?filemtime(PATH_typo3conf.TYPO3_extTableDef_script):"")
			);
			$TCA = unserialize($this->sys_page->getHash($tempHash, 0));
			if (!$TCA)	{
				$this->includeTCA(0);
				reset($TCA);
				$newTc=Array();
				while(list($key,$val)=each($TCA))		{
			/*		$newTc[$key]["ctrl"]["enablecolumns"] = $val["ctrl"]["enablecolumns"];
					$newTc[$key]["ctrl"]["delete"] = $val["ctrl"]["delete"];*/
					$newTc[$key]["ctrl"] = $val["ctrl"];
					$newTc[$key]["feInterface"]=$val["feInterface"];
				}
				$TCA=$newTc;
				$this->sys_page->storeHash($tempHash, serialize($newTc), "SHORT TC");
			}
		}
		$GLOBALS["TT"]->pull();
	}

	/**
	 * Includes TCA
	 */
	function includeTCA($TCAloaded=1)	{
		global $TCA, $PAGES_TYPES, $LANG_GENERAL_LABELS;
		
		if (!$this->TCAloaded)	{
			$TCA = Array();
			include (TYPO3_tables_script ? PATH_typo3conf.TYPO3_tables_script : PATH_t3lib."install/tables.php");
			if (TYPO3_extTableDef_script)	{
				include (PATH_typo3conf.TYPO3_extTableDef_script);
			}
			$this->TCAloaded = $TCAloaded;
		}
	}

	/** 
	 * Checks if any email-submissions or submission via the fe_tce
	 *
	 * @return 	string	"email" if a formmail has been send, "fe_tce" if front-end data submission (like forums, guestbooks) is send. "" if none.
	 */
	function checkDataSubmission()	{
		if ($GLOBALS["HTTP_POST_VARS"]["formtype_db"] || $GLOBALS["HTTP_POST_VARS"]["formtype_mail"])	{

			$refInfo=parse_url(getenv("HTTP_REFERER"));
			list($httpHost) = explode(":",getenv("HTTP_HOST"));
			if ($httpHost==$refInfo["host"] || $this->TYPO3_CONF_VARS["SYS"]["doNotCheckReferer"])	{
				if ($this->locDataCheck($GLOBALS["HTTP_POST_VARS"]["locationData"]))	{
					$ret = "";
					if ($GLOBALS["HTTP_POST_VARS"]["formtype_mail"])	{
						$ret = "email";
					} elseif ($GLOBALS["HTTP_POST_VARS"]["formtype_db"] && is_array($GLOBALS["HTTP_POST_VARS"]["data"]))	{
						$ret = "fe_tce";
					}
					$GLOBALS["TT"]->setTSlogMessage("'Check Data Submission': Return value: ".$ret,0);
					return $ret;
				}
			} else $GLOBALS["TT"]->setTSlogMessage("'Check Data Submission': HTTP_HOST and REFERER HOST did not match when processing submitted formdata!",3);
		}
	}

	/** 
	 * Sends the email.
	 */
	function locDataCheck($locationData)	{
		$locData = explode(":",$locationData);
		if (!$locData[1] ||  $this->sys_page->checkRecord($locData[1],$locData[2],1))	{
			if (count($this->sys_page->getPage($locData[0])))	{	// $locData[1] -check means that a record is checked only if the locationData has a value for a record else than the page.
				return 1;
			} else $GLOBALS["TT"]->setTSlogMessage("LocationData Error: The page pointed to by location data (".$locationData.") was not accessible.",2);
		} else $GLOBALS["TT"]->setTSlogMessage("LocationData Error: Location data (".$locationData.") record pointed to was not accessible.",2);
	}
	
	/** 
	 * Sends the email.
	 */
	function sendFormmail()	{
		$formmail = t3lib_div::makeInstance("t3lib_formmail");

		$EMAIL_VARS = $GLOBALS["HTTP_POST_VARS"];
		unset($EMAIL_VARS["locationData"]);
		unset($EMAIL_VARS["formtype_mail"]);

		$formmail->start($EMAIL_VARS);
		$formmail->sendtheMail();
		$GLOBALS["TT"]->setTSlogMessage("'Formmail' invoked, sending mail to ".$EMAIL_VARS["recipient"],0);
	}

	/** 
	 * Processes user data
	 */
	function fe_tce()	{
		$fe_tce = t3lib_div::makeInstance("tslib_feTCE");
		$fe_tce->start($GLOBALS["HTTP_POST_VARS"]["data"],$this->config["FEData."]);
		$fe_tce->includeScripts();
	}

	/** 
	 * Checks if jumpurl is set.
	 *
	 * This function also takes care of jumpurl utilized by the direct mail module which may set a integer value for jumpurl which refers to a link in a certain mail-record, mid
	 */
	function checkJumpUrl()	{
		$mid = t3lib_div::GPvar("mid");		// mail id, if direct mail link
		$rid = t3lib_div::GPvar("rid");		// recipient id, if direct mail link
		if ((strcmp($this->jumpurl,"") && ((getenv("HTTP_REFERER") || $this->TYPO3_CONF_VARS["SYS"]["doNotCheckReferer"]) || $mid)) || ($this->jumpurl = $this->sys_page->getExtURL($this->page,$this->config["config"]["disablePageExternalUrl"])))	{
			if ($mid)	{	// Yes, it's OK if the link comes from a direct mail
				$temp_recip=explode("_",$rid);
				$url_id=0;
				if (t3lib_div::testInt($this->jumpurl))	{
					$temp_query="SELECT mailContent FROM sys_dmail WHERE uid=".intval($mid);
					$temp_res = mysql(TYPO3_db,$temp_query);
					if ($row=mysql_fetch_assoc($temp_res))	{
						$temp_unpackedMail = unserialize($row["mailContent"]);
						$url_id=$this->jumpurl;
						if ($this->jumpurl>=0)	{
							$responseType=1;	// Link (number)
							$this->jumpurl = $temp_unpackedMail["html"]["hrefs"][$url_id]["absRef"];
						} else {
							$responseType=2;	// Link (number, plaintext)
							$this->jumpurl = $temp_unpackedMail["plain"]["link_ids"][abs($url_id)];
						}
						switch($temp_recip[0])	{
							case "t":
								$theTable = "tt_address";
							break;
							case "f":
								$theTable = "fe_users";
							break;
							default:
								$theTable="";
							break;
						}
						if ($theTable)	{
							$recipRow = $this->sys_page->getRawRecord($theTable,$temp_recip[1]);
							if (is_array($recipRow))	{
//								debug($recipRow);
								$authCode = t3lib_div::stdAuthCode($recipRow["uid"]);
								$rowFieldsArray = explode(",", "uid,name,title,email,phone,www,address,company,city,zip,country,fax,firstname");
								reset($rowFieldsArray);
								while(list(,$substField)=each($rowFieldsArray))	{
									$this->jumpurl = str_replace("###USER_".$substField."###", $recipRow[$substField], $this->jumpurl);
								}
								$this->jumpurl = str_replace("###SYS_TABLE_NAME###", $tableNameChar, $this->jumpurl);	// Put in the tablename of the userinformation
								$this->jumpurl = str_replace("###SYS_MAIL_ID###", $mid, $this->jumpurl);	// Put in the uid of the mail-record
								$this->jumpurl = str_replace("###SYS_AUTHCODE###", $authCode, $this->jumpurl);
								
						//		debug($this->jumpurl);
							}
						}
					}
					if (!$this->jumpurl)	die("Error: No further link. Please report error to the mail sender.");
				} else {
					$responseType=-1;	// received (url, dmailerping)
				}
				if ($responseType!=0)	{
					$temp_query="INSERT INTO sys_dmail_maillog (mid,rtbl,rid,tstamp,url,response_type,url_id) VALUES ('".intval($mid)."','".addslashes($temp_recip[0])."','".intval($temp_recip[1])."','".time()."','".addslashes($this->jumpurl)."',".intval($responseType).",".intval($url_id).")";
					$temp_res = mysql(TYPO3_db,$temp_query);
				}
			}
		} else {
			unset($this->jumpurl);
		}
	}

	/** 
	 * Sends a header "Location" to jumpurl, if jumpurl is set.
	 */
	function jumpUrl()	{
		if ($this->jumpurl)	{
			if (t3lib_div::GPvar("juSecure"))	{
				$hArr = array(	
					$this->jumpurl,
					t3lib_div::GPvar("locationData"),
					$this->TYPO3_CONF_VARS["SYS"]["encryptionKey"]
				);
				$calcJuHash=t3lib_div::shortMD5(serialize($hArr));
				$locationData = t3lib_div::GPvar("locationData");
				$juHash = t3lib_div::GPvar("juHash");
				if ($juHash == $calcJuHash)	{
					if ($this->locDataCheck($locationData))	{
						if (@is_file($this->jumpurl))	{
							$mimeType = t3lib_div::GPvar("mimeType");
							$mimeType = $mimeType ? $mimeType : "application/octet-stream";
							Header("Content-Type: ".$mimeType);
							Header("Content-Disposition: attachment; filename=".basename($this->jumpurl));
							readfile($this->jumpurl);
							exit;
						} else die("jumpurl Secure: '".$this->jumpurl."' was not a valid file!");
					} else die("jumpurl Secure: locationData,".$locationData." , was not accessible.");
				} else die("jumpurl Secure: Calculated juHash, ".$calcJuHash.", did not match the submitted juHash.");
			} else {
				$TSConf = $this->getPagesTSconfig();
				if ($TSConf["TSFE."]["jumpUrl_transferSession"])	{
					$uParts = parse_url($this->jumpurl);
					$params = "&FE_SESSION_KEY=".rawurlencode($this->fe_user->id."-".md5($this->fe_user->id."/".$this->TYPO3_CONF_VARS["SYS"]["encryptionKey"]));
					$this->jumpurl.=($uParts["query"]?"":"?").$params;	// Add the session parameter ...
				}
				Header("Location: ".$this->jumpurl);
				exit;
			}
		}
	}
	
	/** 
	 * Sets the URL_ID_TOKEN
	 */
	function setUrlIdToken()	{
		if ($this->config["config"]["ftu"])	{
			$this->getMethodUrlIdToken = $this->TYPO3_CONF_VARS["FE"]["get_url_id_token"];
		} else {
			$this->getMethodUrlIdToken = "";
		}
	}

	/** 
	 * returns true if the page should be generated
	 *
	 * That is if jumpurl is not set and the cacheContentFlag is not set.
	 */
	function isGeneratePage()	{
		return (!$this->cacheContentFlag && !$this->jumpurl);
	}

	/** 
	 * Temp cache content
	 *
	 * The temporary cache will expire after a few seconds (typ. 30) or will be cleared by the rendered page, which will also clear and rewrite the cache.
	 */
	function tempPageCacheContent()	{
		$this->tempContent=0;
		if (!$this->no_cache)	{
			$seconds=30;
			$stdMsg = '<HTML><HEAD><TITLE>'.$this->tmpl->printTitle($this->page["title"]).'</TITLE><META http-equiv=Refresh Content="3; Url='.$GLOBALS["HTTP_SERVER_VARS"]["REQUEST_URI"].'"></HEAD><BODY bgcolor="white"><FONT SIZE="1" FACE="VERDANA,ARIAL,HELVETICA" COLOR="#cccccc"><div align="center"><b>Page is being generated.</b><BR> If this message does not disappear within '.$seconds.' seconds, please reload.</div></FONT></BODY></HTML>';
			$temp_content = $this->config["config"]["message_page_is_being_generated"] ? $this->config["config"]["message_page_is_being_generated"] : $stdMsg;
			
			$this->setPageCacheContent($temp_content,"",$GLOBALS["EXEC_TIME"]+$seconds);
			$this->tempContent=1;		// This flag shows that temporary content is put in the cache
		}
	}
	
	/** 
	 * Set cache content
	 */
	function realPageCacheContent()	{
		$cache_timeout = $this->page[cache_timeout] ? $this->page[cache_timeout] : ($this->cacheTimeOutDefault ? $this->cacheTimeOutDefault : 60*60*24);		// seconds until a cached page is too old
		$timeOutTime = $GLOBALS["EXEC_TIME"]+$cache_timeout;
		if ($this->config["config"]["cache_clearAtMidnight"])	{
			$midnightTime = mktime (0,0,0,date("m",$timeOutTime),date("d",$timeOutTime),date("Y",$timeOutTime));
			if ($midnightTime > time())	{		// If the midnight time of the expire-day is greater than the current time, we may set the timeOutTime to the new midnighttime.
				$timeOutTime=$midnightTime;
			}
		}
		$this->config["hash_base"] = $this->hash_base;
//		debug(unserialize($this->hash_base));
		$this->setPageCacheContent($this->content,$this->config,$timeOutTime);
	}

	/** 
	 * Clears cache content
	 */
	function clearPageCacheContent()	{
		$res = mysql (TYPO3_db, "DELETE FROM cache_pages WHERE hash='".$this->newHash."'");
	}

	/** 
	 * Clears cache content
	 */
	function clearPageCacheContent_pidList($pidList)	{
		$res = mysql (TYPO3_db, "DELETE FROM cache_pages WHERE page_id IN (".$pidList.")");
	}

	/** 
	 * Sets cache content
	 */
	function setPageCacheContent($c,$d,$t)	{
		$this->clearPageCacheContent();
		$res = mysql (TYPO3_db, "INSERT INTO cache_pages (hash, page_id, HTML, cache_data, expires, tstamp) VALUES ('".$this->newHash."','".$this->id."','".addSlashes($c)."','".addSlashes(serialize($d))."','".$t."',".time().")");
		echo mysql_error();
	}

	/** 
	 * Sets sys last changed
	 */
	function setSysLastChanged()	{
			// setting the LASTUPDATE value in the pagerecord: This value will thus be set to the highest tstamp of records rendered on the page. This includes all records with no regard to hidden records, userprotection and so on.
		if ($this->page["SYS_LASTCHANGED"] < intval($this->register["SYS_LASTCHANGED"]))	{
			$query = "UPDATE pages SET SYS_LASTCHANGED=".intval($this->register["SYS_LASTCHANGED"])." WHERE uid='".$this->id."'";
			$res = mysql (TYPO3_db, $query);
		}
	}

	/** 
	 * Does some processing BEFORE the pagegen script is included.
	 */
	function generatePage_preProcessing()	{
		ksort($this->all);
			// Same code as above. BUT $this->all has been set in the meantime, so we can't just skip this line and let it be set above! Keep this line!
		$this->newHash = $this->getHash();
	
			// Here we put some temporary stuff in the cache in order to let the first hit generate the page. The temporary cache will expire after a few seconds (typ. 30) or will be cleared by the rendered page, which will also clear and rewrite the cache.
		$this->tempPageCacheContent();
	
			// Setting locale
		if ($this->config["config"]["locale_all"])	{setlocale("LC_ALL",$this->config["config"]["locale_all"]);}

			// Setting cache_timeout_default. May be overridden by PHP include scritps.
		$this->cacheTimeOutDefault = intval($this->config["config"]["cache_period"]);
	
			// page is generated
		$this->no_cacheBeforePageGen = $this->no_cache;
	}

	/** 
	 * Determines to include custom or pagegen.php script
	 *
	 * returns script-filename if a TypoScript (config) script is defined and should be include instead of pagegen.php
	 */
	function generatePage_whichScript()	{
		if (!$this->TYPO3_CONF_VARS["FE"]["noPHPscriptInclude"] && $this->config["config"]["pageGenScript"])	{
			return $this->tmpl->getFileName($this->config["config"]["pageGenScript"]);
		}
	}

	/** 
	 * Does some processing AFTER the pagegen script is included.
	 */
	function generatePage_postProcessing()	{
			// This is to ensure, that the page is NOT cached if the no_cache parameter was set before the page was generated. This is a safety precaution, as it could have been unset by some script.
		if ($this->no_cacheBeforePageGen) $this->set_no_cache();	
	
			// Garbage collect images (beta):	
			// Problem: Deleting these files has the drawback that the gifbuilder objects trys to generate them before their own filename is known - and therefore they are important!!
/*		$GARBAGE_COLLECT_TEMPFILES=0;
		if ($GARBAGE_COLLECT_TEMPFILES && is_array($GLOBALS["TEMP_IMAGES_ON_PAGE"]) && is_array($GLOBALS["TSFE"]->imagesOnPage))	{
			$GC_files = array_diff($GLOBALS["TEMP_IMAGES_ON_PAGE"], $GLOBALS["TSFE"]->imagesOnPage);		// THis array holds all files that are generated but not referred to in the HTML-code. They are going to be deleted now.
			while(list(,$GC_delFile)=each($GC_files))	{
				if (substr($GC_delFile,0,10)=="typo3temp/")	{
					if (@is_file($GC_delFile))	{
						unlink($GC_delFile);
					}
				}
			}
		}*/
	
			// Tidy up the code, if flag...
		if ($this->TYPO3_CONF_VARS["FE"]["tidy_option"] == "all")		{
			$GLOBALS["TT"]->push("Tidy, all","");
				$this->content = $this->tidyHTML($this->content);
			$GLOBALS["TT"]->pull();
		}
			
			// Storing page	
		if (!$this->no_cache)	{
					// Tidy up the code, if flag...
			if ($this->TYPO3_CONF_VARS["FE"]["tidy_option"] == "cached")		{
				$GLOBALS["TT"]->push("Tidy, cached","");
					$this->content = $this->tidyHTML($this->content);
				$GLOBALS["TT"]->pull();
			}
			$this->realPageCacheContent();
		} elseif ($this->tempContent)	{		// If there happens to be temporary content in the cache and the cache was not cleared due to new content put in it... ($this->no_cache=0)
			$this->clearPageCacheContent();
		}
	
		if ($this->isSearchIndexPage())	{
			$GLOBALS["TT"]->push("Index page","");
				$indexer = t3lib_div::makeInstance("tslib_searchIndex");
				$indexer->init($this->content,$this->config["config"],$this->id,$this->type,$this->gr_list,$this->cHash_array,$this->register["SYS_LASTCHANGED"],$this->config["rootLine"]);
				$indexer->indexTypo3PageContent();
			$GLOBALS["TT"]->pull();
		}
		$this->setSysLastChanged();
	}
	
	/** 
	 * Returns true if page should be indexed.
	 */
	function isSearchIndexPage()	{
		return $this->config["config"]["index_enable"] && !$this->no_cache;
	}

	/** 
	 * newCObj
	 */
	function newCObj()	{
		$this->cObj =t3lib_div::makeInstance("tslib_cObj");
		$this->cObj->start($this->page,"pages");
	}

	/** 
	 * Sets JavaScript code in the additionalJavaScript array
	 *
	 * $key is the key in the array, for num-key let the value be empty
	 * $content is the content if you want any
	 * Note reserved keys "openPic" and "mouseOver"
	 */
	function setJS($key,$content="")	{
		if ($key)	{
			switch($key)	{
				case "mouseOver":
					$this->additionalJavaScript[$key]=
'	function over(name,imgObj)	{
		if (version == "n3" && document[name]) {document[name].src = eval(name+"_h.src");}
		else if (imgObj)	{imgObj.src = eval(name+"_h.src");}
	}
	function out(name,imgObj)	{
		if (version == "n3" && document[name]) {document[name].src = eval(name+"_n.src");}
		else if (imgObj)	{imgObj.src = eval(name+"_n.src");}
	}';
				break;
				case "openPic":
					$this->additionalJavaScript[$key]=
'	function openPic(url,winName,winParams)	{
		var theWindow = window.open(url,winName,winParams);	
		if (theWindow)	{theWindow.focus();}
	}';
				break;
				default:
					$this->additionalJavaScript[$key]=$content;
				break;
			}
		}
	}

	/** 
	 * Determines if there are any INTincScripts to include
	 */
	function isINTincScript()	{
		return	(is_array($this->config["INTincScript"]) && !$this->jumpurl);
	}

	/** 
	 * Processes the INTinclude-scripts
	 */
	function INTincScript()	{
		$GLOBALS["TT"]->push("Split content");
		$INTiS_splitC = explode("<!--INT_SCRIPT.",$this->content);			// Splits content with the key.
		$this->content="";
		$GLOBALS["TT"]->setTSlogMessage("Parts: ".count($INTiS_splitC));
		$GLOBALS["TT"]->pull();

			// Depreciated stuff:
		$this->additionalHeaderData = $this->config["INTincScript_ext"]["additionalHeaderData"];
		$this->additionalJavaScript = $this->config["INTincScript_ext"]["additionalJavaScript"];
		$this->JSCode = $this->additionalHeaderData["JSCode"];
		$this->JSImgCode = $this->additionalHeaderData["JSImgCode"];
		$this->divSection="";

		$INTiS_config = $GLOBALS["TSFE"]->config["INTincScript"];
		reset($INTiS_splitC);
		while(list($INTiS_c,$INTiS_cPart)=each($INTiS_splitC))	{
			if (substr($INTiS_cPart,32,3)=="-->")	{	// If the split had a comment-end after 32 characters it's probably a split-string
				$GLOBALS["TT"]->push("Include ".$INTiS_config[$INTiS_key]["file"],"");
				$INTiS_key = "INT_SCRIPT.".substr($INTiS_cPart,0,32);
				$incContent="";
				if (is_array($INTiS_config[$INTiS_key]))	{
					$INTiS_cObj = unserialize($INTiS_config[$INTiS_key]["cObj"]);
					$INTiS_cObj->INT_include=1;
					switch($INTiS_config[$INTiS_key]["type"])	{
						case "SCRIPT":
							$incContent=$INTiS_cObj->PHP_SCRIPT($INTiS_config[$INTiS_key]["conf"]);
						break;
						case "COA":
							$incContent=$INTiS_cObj->COBJ_ARRAY($INTiS_config[$INTiS_key]["conf"]);
						break;
						case "FUNC":
							$incContent=$INTiS_cObj->USER($INTiS_config[$INTiS_key]["conf"]);
						break;
					}
				}
				$this->content.=$incContent;
				$this->content.= substr($INTiS_cPart,35);
				$GLOBALS["TT"]->pull($incContent);
			} else {
				$this->content.= ($c?"<!--INT_SCRIPT.":"").$INTiS_cPart;
			}
		}
		$GLOBALS["TT"]->push("Substitute header section");
		$this->INTincScript_loadJSCode();
		$this->content = str_replace("<!--HD_".$this->config["INTincScript_ext"]["divKey"]."-->", implode($this->additionalHeaderData,chr(10)), $this->content);
		$this->content = str_replace("<!--TDS_".$this->config["INTincScript_ext"]["divKey"]."-->", $this->divSection, $this->content);
		$this->setAbsRefPrefix();
		$GLOBALS["TT"]->pull();
	}

	/** 
	 * Loads the JavaScript code for INTincScript
	 */
	function INTincScript_loadJSCode()	{
		if ($this->JSImgCode)	{	// If any images added, then add them to the javascript section
			$this->additionalHeaderData["JSImgCode"]='
<script>
<!--
if (version == "n3") {
'.trim($this->JSImgCode).'
}
// -->
</script>';
		}
		if ($this->JSCode || count($this->additionalJavaScript))	{	// Add javascript
			$this->additionalHeaderData["JSCode"]='
<script>
<!--
'.implode($this->additionalJavaScript,chr(10)).'
'.trim($this->JSCode).'
// -->
</script>';
		}
	}
		
	/** 
	 * Stores session data for the front end user
	 */
	function storeSessionData()	{
		$this->fe_user->storeSessionData();
	}

	/** 
	 * Saves statistics
	 */
	function statistics()	{
		if ($this->config["config"]["stat"] &&
				(!strcmp("",$this->config["config"]["stat_typeNumList"]) || t3lib_div::inList(str_replace(" ","",$this->config["config"]["stat_typeNumList"]), $this->type)) &&
				(!$this->config["config"]["stat_excludeBEuserHits"] || !$this->beUserLogin) &&
				(!$this->config["config"]["stat_excludeIPList"] || !t3lib_div::inList(str_replace(" ","",$this->config["config"]["stat_excludeIPList"]), getenv("REMOTE_ADDR")))) {
			$GLOBALS["TT"]->push("Stat");
				if ($this->config["config"]["stat_mysql"])	{
						// Jumpurl:
					$sword = t3lib_div::GPvar("sword");
					if ($sword)	{
						$jumpurl_msg="sword:".$sword;
					} elseif ($this->jumpurl) {
						$jumpurl_msg="jumpurl:".$this->jumpurl;
					} else {
						$jumpurl_msg="";
					}
						// Flags: bits: 0 = BE_user, 1=Cached page?
					$flags=0;
					if ($this->beUserLogin) {$flags|=1;}
					if ($this->cacheContentFlag) {$flags|=2;}
						// Ref url:
//					$refUrl = ereg_replace("\?.*","",getenv("HTTP_REFERER"));
					$refUrl = getenv("HTTP_REFERER");
					$thisUrl = "http://".t3lib_div::getThisUrl();
					if (t3lib_div::isFirstPartOfStr($refUrl,$thisUrl))	{
						$refUrl="[LOCAL]";
					}
				
					$query = "INSERT INTO sys_stat SET ";
					$query.="page_id='".$this->id."',";		// id
					$query.="page_type='".$this->type."',";		// type
					$query.="jumpurl='".addslashes($jumpurl_msg)."',";		// jumpurl message
					$query.="feuser_id='".$this->fe_user->user["uid"]."',";		// fe_user id, integer
					$query.="cookie='".addslashes($this->fe_user->id)."',";		// cookie as set or retrieve. If people has cookies disabled this will vary all the time...
					$query.="sureCookie='".hexdec(substr($this->fe_user->cookieId,0,8))."',";	// This is the cookie value IF the cookie WAS actually set. However the first hit where the cookie is set will thus NOT be logged here. So this lets you select for a session of at least two clicks...
					$query.="rl0='".$this->config["rootLine"][0]["uid"]."',";	// RootLevel 0 uid
					$query.="rl1='".$this->config["rootLine"][1]["uid"]."',";	// RootLevel 1 uid
					$query.="client_browser='".$GLOBALS["CLIENT"]["BROWSER"]."',";	// Client browser (net, msie, opera)
					$query.="client_version='".$GLOBALS["CLIENT"]["VERSION"]."',";	// Client version (double value)
					$query.="client_os='".$GLOBALS["CLIENT"]["SYSTEM"]."',";	// Client Operating system (win, mac, unix)
					$query.="parsetime='".intval($this->scriptParseTime)."',";		// Parsetime for the page.
					$query.="flags='".$flags."',";		// Flags: Is be user logged in? Is page cached?
					$query.="IP='".getenv("REMOTE_ADDR")."',";		// Remote IP address
					$query.="host='".getenv("REMOTE_HOST")."',";		// Remote Host Address
					$query.="referer='".addslashes($refUrl)."',";		// Referer URL
					$query.="browser='".addslashes(getenv("HTTP_USER_AGENT"))."',";		// User Agent Info.
					$query.= "tstamp=".$GLOBALS["EXEC_TIME"];	// Time stamp
					$GLOBALS["TT"]->push("Store SQL");
						mysql (TYPO3_db, $query);
					$GLOBALS["TT"]->pull();
					echo mysql_error();
				}

					// Apache:
				if ($this->config["config"]["stat_apache"] && $this->config["stat_vars"]["pageName"])	{
					if (@is_file($this->config["stat_vars"]["logFile"]) && TYPO3_OS!="WIN")	{
						$LogLine = ((getenv("REMOTE_HOST") && !$this->config["config"]["stat_apache_noHost"]) ? getenv("REMOTE_HOST") : getenv("REMOTE_ADDR")).' - - '.Date("[d/M/Y:H:i:s +0000]",$GLOBALS["EXEC_TIME"]).' "GET '.$this->config["stat_vars"]["pageName"].' HTTP/1.1" 200 '.strlen($this->content);
						if (!$this->config["config"]["stat_apache_notExtended"])	{
							$LogLine.= ' "'.getenv("HTTP_REFERER").'" "'.getenv("HTTP_USER_AGENT").'"';
						}
						$execCmd = 'echo "'.addslashes($LogLine).'" >> '.$this->config["stat_vars"]["logFile"];
						$GLOBALS["TT"]->push("Write to log file");
							exec($execCmd);
						$GLOBALS["TT"]->pull();
						$GLOBALS["TT"]->setTSlogMessage("Writing to logfile: OK",0);
						//debug($execCmd);
					} else {
						$GLOBALS["TT"]->setTSlogMessage("Writing to logfile: Error - logFile did not exist or OS is Windows!",3);
					}
				}
			$GLOBALS["TT"]->pull();
		}
	}

	/** 
	 * Determines if content should be outputted. 
	 *
	 * Outputting content is done only if jumpurl is set.
	 */
	function isOutputting()	{
		return (!$this->jumpurl);
	}

	/** 
	 * processes the output before it's actually output. Sends headers also.
	 */
	function processOutput()	{
			// Substitutes username mark with the username
		if ($this->fe_user->user[uid])	{		
			$token = trim($this->config["config"]["USERNAME_substToken"]);
			$this->content = str_replace($token ? $token : "<!--###USERNAME###-->",$this->fe_user->user[username],$this->content);
		}
			// Substitutes get_URL_ID in case of GET-fallback
		if ($this->getMethodUrlIdToken)	{
			$this->content = str_replace($this->getMethodUrlIdToken, $this->fe_user->get_URL_ID, $this->content);
		}
	
			// Set headers, if any
		if ($this->config["config"]["additionalHeaders"])	{
			$headerArray = explode("|", $this->config["config"]["additionalHeaders"]);
			while(list(,$headLine)=each($headerArray))	{
				$headLine = trim($headLine);
				header($headLine);
			}
		}

				// Tidy up the code, if flag...
		if ($this->TYPO3_CONF_VARS["FE"]["tidy_option"] == "output")		{
			$GLOBALS["TT"]->push("Tidy, output","");
				$this->content = $this->tidyHTML($this->content);
			$GLOBALS["TT"]->pull();
		}
		

/*		if ($this->beUserLogin && t3lib_div::GPvar("ADMCMD_view"))	{		// This is a try to change target=_top to target=_self if pages are shown in the Web>View module...
			$this->content = str_replace('target="_top"','target="_self"',$this->content);
			$this->content = str_replace('target=_top','target="_self"',$this->content);
		}*/
	}

	/** 
	 * Substitute the path's to files in the media/ folder like icons used in static_template of TypoScript
	 */
	function setAbsRefPrefix()	{
		if ($this->absRefPrefix)	{
			$this->content = str_replace('"media/', '"'.$this->absRefPrefix.'media/', $this->content);
			$this->content = str_replace('"fileadmin/', '"'.$this->absRefPrefix.'fileadmin/', $this->content);
		}
	}

	/** 
	 * Substitute the path's to files in the media/ folder like icons used in static_template of TypoScript
	 */
	function getSimulFileName()	{
		$url="";
		$url.=$this->makeSimulFileName($this->page["title"], $this->page["alias"]?$this->page["alias"]:$this->id, $this->type).".html";
		return $url;
	}	
	
	/** 
	 * make simulation filename
	 */
	function makeSimulFileName($inTitle,$page,$type)	{
		$titleChars = intval($this->config["config"]["simulateStaticDocuments_addTitle"]);
		$out="";
		if ($titleChars)	{
			$out= ereg_replace("[^[:alnum:]_-]","_",trim(substr($inTitle,0,$titleChars)));
			if ($out)	$out.=".";
		}
			// Setting page and type number:
		$url = $out.$page;
		$url.= ($type || $out || !$this->config["config"]["simulateStaticDocuments_noTypeIfNoTitle"]) ? ".".$type : "";
		return $url;
	}
	
	/** 
	 * Returns the pages TSconfig array based on the currect ->rootLine
	 */
	function getPagesTSconfig()	{
		if (!is_array($this->pagesTSconfig))	{
//			debug($this->rootLine);
			reset($this->rootLine);
			$TSdataArray = array();
			$TSdataArray[]=$GLOBALS["TYPO3_CONF_VARS"]["BE"]["defaultPageTSconfig"];	// Setting default configuration:
			while(list($k,$v)=each($this->rootLine))	{
				$TSdataArray[]=$v["TSconfig"];
			}
				// Parsing the user TS (or getting from cache)
			$userTS = implode($TSdataArray,chr(10)."[GLOBAL]".chr(10));
			$hash = md5("pageTS:".$userTS);
			$cachedContent = $this->sys_page->getHash($hash,0);
			if (isset($cachedContent))	{
				$this->pagesTSconfig = unserialize($cachedContent);
			} else {
				$parseObj = t3lib_div::makeInstance("t3lib_TSparser");
				$parseObj->parse($userTS);
				$this->pagesTSconfig = $parseObj->setup;
				$this->sys_page->storeHash($hash,serialize($this->pagesTSconfig),"PAGES_TSconfig");
			}
		}
		return $this->pagesTSconfig;
	}
	
	/** 
	 * Determines if any EXTincScripts should be included
	 */
	function isEXTincScript()	{
		return is_array($this->config["EXTincScript"]);
	}
	
	/** 
	 * Returns a link to the login screen with redirect to the front-end
	 */
	function beLoginLinkIPList()	{
		if ($this->config["config"]["beLoginLinkIPList"])	{
			if (t3lib_div::cmpIP(getenv("REMOTE_ADDR"), $this->config["config"]["beLoginLinkIPList"]))	{
				$label = !$this->beUserLogin ? $this->config["config"]["beLoginLinkIPList_login"] : $this->config["config"]["beLoginLinkIPList_logout"];
				if ($label)	{
					if (!$this->beUserLogin)	{
						$link = '<a href="typo3/index.php?redirect_url='.rawurlencode(getenv("REQUEST_URI")).'">'.$label.'</a>';
					} else {
						$link = '<a href="typo3/index.php?L=OUT&redirect_url='.rawurlencode(getenv("REQUEST_URI")).'">'.$label.'</a>';
					}
					return $link;
				}
			}
		}
	}

	/** 
	 * Outputs preview info.
	 */
	function previewInfo()	{
		if ($this->fePreview)	{
				$stdMsg = '<BR><div align="center"><table border=3 bordercolor=black cellpadding=2 bgColor="red"><tr><td>&nbsp;&nbsp;<font face="Verdana" size="1"><b>PREVIEW!</b></font>&nbsp;&nbsp;</td></tr></table></div>';
				$temp_content = $this->config["config"]["message_preview"] ? $this->config["config"]["message_preview"] : $stdMsg;
				echo $temp_content;
		}
	}
	function printError($label,$header="Error!")	{
		tslib_timeTrack::debug_typo3PrintError($header,$label,0);	
	}
	function setParseTime()	{		// Compensates for the time consumed with Back end user initialization.
		$this->scriptParseTime = $GLOBALS["TT"]->convertMicrotime($GLOBALS["TYPO3_MISC"]["microtime_end"])
								- $GLOBALS["TT"]->convertMicrotime($GLOBALS["TYPO3_MISC"]["microtime_start"]) 
								- ($GLOBALS["TT"]->convertMicrotime($GLOBALS["TYPO3_MISC"]["microtime_BE_USER_end"])-$GLOBALS["TT"]->convertMicrotime($GLOBALS["TYPO3_MISC"]["microtime_BE_USER_start"]));
	}
	function debugSelf()	{
		$theVars = get_class_vars("tslib_fe");
		$newArr=array();
		reset($theVars);
		while(list($key,$val)=each($theVars))	{
			if (!t3lib_div::inList("pSetup", $key))	{
				$newArr[$key] = $this->$key;
			}
		}
		debug($newArr);
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_fe.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["tslib/class.tslib_fe.php"]);
}

?>