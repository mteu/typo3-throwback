<?
define("TYPO3_MOD_PATH","../typo3conf/freesite/");		// Relative path to the module from the typo3/ folder
$BACK_PATH="../../typo3/";					// Relative path to the typo3/ folder

$MLANG["default"]["labels"]["tablabel"] = "Automated creation of sites based on standard templates.";
$MLANG["default"]["tabs"]["tab"] = "Freesite";
$MLANG["default"]["tabs_images"]["tab"] = "freesite.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Automatisk oprettelse af sites baseret p� standard skabeloner.";
$MLANG["dk"]["tabs"]["tab"] = "Freesite";

$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="freesite";		// Name: [module]_[subModule]  or just [module] if no submodule!! Remember, no "_" in module names!!!
?>