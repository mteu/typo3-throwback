<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Clipboard upload
 *
 * This shows 5 upload-fields to the first temp-dir found in the users path
 * Used on the clipboard to upload files.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 





// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








include("init.php");
include ("template.php");



// ***************************
// Registering Incoming data
// ***************************
t3lib_div::setGPvars("pad");



// ***************************
// Initialize
// ***************************
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
$count = $pad=="normal" ? 1 : 5;		// Number of upload fields

$fileProcessor = t3lib_div::makeInstance("t3lib_basicFileFunctions");
$fileProcessor->init($FILEMOUNTS, $TYPO3_CONF_VARS["BE"]["fileExtensions"]);
$path = $fileProcessor->findTempFolder();	// The closest TEMP-path is found

if (!$path)	{
	t3lib_BEfunc::typo3PrintError ($LANG->php3Lang["file_clipupload.php"]["warning_head"],$LANG->php3Lang["file_clipupload.php"]["warning"],"");
	exit;
}



// ***************************
// Starting document output
// ***************************
?>
<!DOCTYPE html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<SCRIPT language="javascript1.2">
	top.writeStyleSheet(document);
</SCRIPT>
<TITLE>Content</TITLE>
</HEAD>
<BODY background="gfx/docback_mini2.gif" link="#000000" marginwidth="0" marginheight="0">
<FORM action="tce_file.php" method="POST" name="editform" enctype="multipart/form-data"><IMG src="gfx/doctop_mini2.gif" width="240" height="16" border="0">

<TABLE border="0" cellpadding="0" cellspacing="0" width="100"><TR><TD><IMG src="clear.gif" width="18" height="1"></TD><TD nowrap align="center" bgcolor="<?php echo $TBE_TEMPLATE->bgColor2;?>"><B><?php echo $TBE_TEMPLATE->fontWrap(strtoupper($LANG->php3Lang["file_upload.php"]["pagetitle"])); ?></B><BR><IMG src="clear.gif" width="207" height="1"></TD></TR></TABLE><TABLE border="0" cellspacing="0" cellpadding="0" width="240">
		<TR>
			<TD><IMG src="clear.gif" width="18" height="1" border="0">
			</TD>
			<TD colspan="2"><IMG src="clear.gif" width="210" height="1" border="0">
			</TD>
		</TR>
		<TR>
			<TD>
			</TD>
			<TD>
<?php
for ($a=1;$a<=$count;$a++)	{
	echo '
		<input type="File" name="upload_'.$a.'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(20).'>
		<input type="Hidden" name="file[upload]['.$a.'][target]" value="'.$path.'">
		<input type="Hidden" name="file[upload]['.$a.'][data]" value="'.$a.'">
		<BR><img src="clear.gif" width=1 height=3><BR>
	';
}
?>
<input type="Hidden" name="redirect" value="status_file.php?clipboard=1">
<input type="Submit" name="submit" value="<?php echo $LANG->php3Lang["file_upload.php"]["submit"]; ?>">
			</TD>
		</TR>
	</TABLE><IMG src="gfx/docmiddle_mini2.gif" width="240" height="20">
</FORM>
</BODY>
</HTML>
