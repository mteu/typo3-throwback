<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Loading content from records into the JavaScript interface for editing
 *
 * This script is called to load records in the Typo3 standard interface.
 * 
 * GET_VARS:
 * $edit :		Array that defines the records to load (see transfer-data/main.php for syntax)
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */






// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








include("init.php");
include ($BACK_PATH."template.php");


// ***************************
// Registering Incoming data
// ***************************
t3lib_div::setGPvars("edit,edit_content,samedoc,defVals");


// ***************************
// Functions 
// ***************************
include_once(PATH_t3lib."class.t3lib_loaddbgroup.php");
include_once(PATH_t3lib."class.t3lib_transferdata.php");

// ***************************
// Processing instructions
// ***************************
if (is_array($edit)):
	$trData = t3lib_div::makeInstance("t3lib_transferData");
	$trData->formname = "loadform";
	$trData->loading = 1;
	$trData->tt_content_limit = t3lib_div::intInRange($BE_USER->uc["edit_maxRecords"],0,1000);
	$trData->start($edit);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Load data for editing</title>
</head>
<body bgcolor="#F7F3EF">
<?php
echo $trData->getHTMLcode();
?>

<script language="javascript">

// Loading data
var recCount = <?php echo $trData->recCount;?>;
var pid = '<?php echo $trData->lastPID;?>';
var table = '<?php echo $trData->lastTable;?>';
var id = '<?php echo $trData->lastID;?>';

if (recCount > 1)	{
	docNum = parent.editWin.addDoc();
} else {
	<?php	echo ($samedoc)?  "docNum = parent.editWin.currentDoc;" : "docNum = parent.editWin.addDoc();";?>
}

<?php
echo $trData->getJScode();
?>

	parent.busy.set(0);
	parent.editWin.currentDoc = docNum;
	parent.editWin.initFaner();
	parent.menuFaner.click('doc');
</script>
<?php
endif;	// If is_array($edit)

?>
<?php
if ($TYPO3_CONF_VARS["BE"]["compressionLevel"])	{
	new gzip_encode($TYPO3_CONF_VARS["BE"]["compressionLevel"]);
}
?>