<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Page tree in alternative backend.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
$BACK_PATH="";
include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_browsetree.php");









// ***************************
// Script Classes
// ***************************
class localPageTree extends t3lib_browseTree {
	function wrapTitle($title,$v)	{
		$title= (!strcmp(trim($title),"")) ? "<em>[".$GLOBALS["LANG"]->php3Lang["labels"]["no_title"]."]</em>" : htmlspecialchars($title);
		return '<a href="#" onClick="return jumpTo('.$v["uid"].',this);">'.$title.'</a>';
	}
	function wrapIcon($icon,$row)	{
		if ($lockInfo=t3lib_BEfunc::isRecordLocked("pages",$row["uid"]))	{
			$lockIcon='<a href="#" onClick="alert(unescape(\''.rawurlencode($lockInfo["msg"]).'\'));return false;"><img src="gfx/recordlock_warning3.gif" width="17" height="12" vspace=2 border="0" align=top'.t3lib_BEfunc::titleAttrib($lockInfo["msg"]).'></a>';
		} else $lockIcon="";
		$thePageIcon = substr($icon,0,-1).' '.$this->titleAttrib.'="'.$this->titleAttribForPages($row).'" border=0>';

		if (!$this->ext_IconMode)	{
			$thePageIcon = $GLOBALS["TBE_TEMPLATE"]->wrapClickMenuOnIcon($thePageIcon,"pages",$row["uid"],1,0);
		} elseif (!strcmp($this->ext_IconMode,"titlelink"))	{
			$thePageIcon='<a href="#" onClick="return jumpTo('.$row["uid"].',this);">'.$thePageIcon.'</a>';
		}
		
		return $thePageIcon.$lockIcon;
	}
}
class SC_alt_db_navframe {
	var $content;
	var $pagetree;
	var $doc;	
	
		// Constructor:
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS;

		$this->pagetree = t3lib_div::makeInstance("localPageTree");
		$this->pagetree->ext_IconMode = $BE_USER->getTSConfigVal("options.pageTree.disableIconLinkToContextmenu");
		$this->pagetree->thisScript = "alt_db_navframe.php";
		$this->pagetree->titleAttrib = t3lib_BEfunc::titleAttrib();
		$this->pagetree->addField("alias");
		$this->pagetree->addField("shortcut");
		$this->pagetree->addField("url");
		
		$currentSubScript = t3lib_div::GPvar("currentSubScript");


		$this->doc = t3lib_div::makeInstance("template");
		$this->doc->backPath = $BACK_PATH;
		$this->doc->JScode='';
		$this->doc->JScode.='
<script>
	'.($currentSubScript?'top.currentSubScript=unescape("'.rawurlencode($currentSubScript).'");':'').'
	
	function jumpTo(id,linkObj)	{
//alert(top.TS.PATH_typo3);
//alert(top.currentSubScript);
//alert("?AB=1&id="+id);
		var theUrl = top.TS.PATH_typo3+top.currentSubScript+"?AB=1&id="+id;

		if (top.condensedMode)	{
			top.content.document.location=theUrl;
		} else {
			parent.db_list_frame.document.location=theUrl;
		}
		'.(!$GLOBALS["CLIENT"]["FORMSTYLE"] ? '' : 'if (linkObj) {linkObj.blur();}').'
		return false;
	}
	function refresh_nav()	{
		window.setTimeout("_refresh_nav();",0);
	}
	function _refresh_nav()	{
		document.location="'.$this->pagetree->thisScript.'?unique='.time().'";
	}
	
	'.(t3lib_div::GPvar("cMR")?"jumpTo(top.theMenu.recentuid,'');":"").';
</script>	
		';

		$CMparts=$this->doc->getContextMenuCode();
		$this->doc->bodyTagAdditions = $CMparts[1];
		$this->doc->JScode.=$CMparts[0];
		$this->doc->postCode.= $CMparts[2];
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$CLIENT;

		$this->content="";
		$this->content.=$this->doc->startPage("DB list");
		
		$tree = $this->pagetree->getBrowsableTree();
		if ($CLIENT["BROWSER"]=="konqu")	{
				// Where <nobr> does not work, this will secure non-breaks in lines:
			$tree = '<table border=0 cellspacing=0 cellpadding=0><tr><td nowrap>'.$tree.'</td></tr></table>';
		}
		$this->content.=fw($tree);
		$this->content.=fw('<BR><a href="'.getenv("REQUEST_URI").'"><img src="gfx/refresh_n.gif" width="14" hspace=2 height="14" border="0" align=top title="'.$LANG->mainLang["labels"]["refresh"].'">&nbsp;'.htmlspecialchars($LANG->mainLang["labels"]["refresh"])."</a><BR><BR>");
	}
	function printContent()	{
		$this->content.= $this->doc->endPage();
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_db_navframe.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_db_navframe.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_db_navframe");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();

?>