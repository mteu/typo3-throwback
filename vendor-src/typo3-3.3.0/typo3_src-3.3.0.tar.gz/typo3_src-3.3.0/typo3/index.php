<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Login-screen of Typo3.
 *
 * GET vars:
 * u=	default username
 * p=	default password
 * L=	'OUT' = logout
 * A=	'1' (true) = Alternative backend
 * redirect_url=	URL to redirect to instead of starting the TBE
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

define("TYPO3_PROCEED_IF_NO_USER", 1);
include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_loadmodules.php");


// ***************************
// Script Classes
// ***************************
class SC_index {
	var $content;
	
	var $loadModules;
	var $redirect_url;
	var $GPinterface;
	var $A;
	var $u;
	var $p;
	var $L;
	var $L_vars;
	var $interfaceSelector;
	var $forceA;

	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_MODULES,$TBE_TEMPLATE;
		
		// ******************************
		// Registering Global Vars
		// ******************************
		$this->redirect_url = t3lib_div::GPvar("redirect_url");
		$this->GPinterface = t3lib_div::GPvar("interface");
		$this->A = t3lib_div::GPvar("A");		// If "A" is true, the alternative backend is started
		
		$this->forceA = 0;
		if ($CLIENT["BROWSER"]=="opera" || $CLIENT["BROWSER"]=="konqu" || ($CLIENT["BROWSER"]=="net" && $CLIENT["VERSION"]<6.1))	$this->forceA=1;		// Alternative Backend is forcibly started if netscape <6.1 or Opera.		//  || stristr(getenv("HTTP_USER_AGENT"),"Netscape6")
		
		if ($this->forceA)	$this->A=1;
		if ($this->A)	{$this->redirect_url="alt_main.php";}
		
		
		$this->u = t3lib_div::GPvar("u");		// preset username
		$this->p = t3lib_div::GPvar("p");		// preset password
		$this->L = t3lib_div::GPvar("L");		// If "L" is "OUT", then any logged in used is logged out. If redirect_url is given, we redirect to it
		
		
		// *********
		// Logout?
		// *********
		if ($this->L=="OUT" && is_object($BE_USER))	{
			$BE_USER->logoff();
			if ($this->redirect_url)	header("Location: ".$this->redirect_url);
			exit;
		}
		
		// ******************************
		// The modules are loaded - just so that any errors will show now and not later when the JavaScript loads
		// ******************************
		$this->loadModules = t3lib_div::makeInstance("t3lib_loadModules");
		$this->loadModules->load($TBE_MODULES);

		$this->L_vars = explode("|",$TYPO3_CONF_VARS["BE"]["loginLabels"]);
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_MODULES,$TBE_TEMPLATE;
		
		$this->content="";
		$this->content.=$this->makeLoginLogoutForm();
		$this->content.=$this->makeStartHTML();
	}
	function makeLoginLogoutForm()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_MODULES,$TBE_TEMPLATE;

		$TBE_TEMPLATE->bgColor="#CCCCCC";
		
		// Code for the challenged form.
		$challenge = md5(uniqid(""));
		
		$content='
		<div align="center">
		<form action="index.php" method="POST" name="loginform" autocomplete="off">
		<table border=1 cellspacing=2 cellpadding=10>
		<tr>
			<td bgcolor="'.$TBE_TEMPLATE->bgColor2.'">
				<table border=0 cellspacing=0 cellpadding=2>
					<tr>
						<td><img src="clear.gif" width=1 height=1 hspace=35></td>
						<td><img src="clear.gif" width=1 height=1 hspace=5></td>
						<td><img src="clear.gif" width=1 height=1 hspace=25></td>
					</tr>
		';
		
		$this->interfaceSelector = "";
		$interfaceHidden="";
		$interfaceSelector_jump = "";
		if ($TYPO3_CONF_VARS["BE"]["interfaces"])	{
			$parts = t3lib_div::trimExplode(",",$TYPO3_CONF_VARS["BE"]["interfaces"]);
			if (count($parts)>1)	{
				$tempLabels=explode(",",$this->L_vars[5]);
				$labels=array();
				$labels["classic"]=$tempLabels[0];
				$labels["alternative"]=$tempLabels[1];
				$labels["frontend"]=$tempLabels[2];
				
				$jumpScript=array();
				$jumpScript["classic"]="main.php";
				$jumpScript["alternative"]="alt_main.php";
				$jumpScript["frontend"]="../";
				
				reset($parts);
				while(list(,$valueStr)=each($parts))	{
					if (!$this->forceA || $valueStr!="classic")	{
						$this->interfaceSelector.='<option value="'.$valueStr.'">'.htmlspecialchars($labels[$valueStr]).'</option>';
						$interfaceSelector_jump.='<option value="'.$jumpScript[$valueStr].'">'.htmlspecialchars($labels[$valueStr]).'</option>';
					}
				}
				$this->interfaceSelector='<select name="interface">'.$this->interfaceSelector.'</select>';
				$interfaceSelector_jump='<select name="interface" onChange="document.location=this.options[this.selectedIndex].value;">'.$interfaceSelector_jump.'</select>';
			} else {
				$interfaceHidden='<input type="hidden" name="interface" value="'.trim($TYPO3_CONF_VARS["BE"]["interfaces"]).'">';
				$this->GPinterface=trim($TYPO3_CONF_VARS["BE"]["interfaces"]);
			}
		}
		
		
		if (!$BE_USER->user["uid"])	{
			// document.loginform.p_field.focus();  ... was in the username field once...
			$content.='
					<tr>
						<td nowrap><font face="VERDANA,ARIAL,SANS-SERIF" size="2"><b>'.$this->L_vars[0].':</b></font></td>
						<td></td>
						<td nowrap><input type="Text" name="username" value="'.$this->u.'"'.$TBE_TEMPLATE->formWidth(10).' onBlur="if(parent.typoWin && parent.typoWin.TS){this.value=parent.typoWin.TS.username;}"></td>
					</tr>
					<tr>
						<td nowrap><font face="VERDANA,ARIAL,SANS-SERIF" size="2"><b>'.$this->L_vars[1].':</b></font></td>
						<td></td>
						<td nowrap><input type="password" name="p_field" value="'.$this->p.'"'.$TBE_TEMPLATE->formWidth(10).'></td>
					</tr>';
			if ($this->interfaceSelector && !t3lib_div::GPvar("loginRefresh"))	{
			$content.='<tr>
							<td nowrap><font face="VERDANA,ARIAL,SANS-SERIF" size="2"><b>'.$this->L_vars[2].':</b></font></td>
							<td></td>
							<td nowrap>'.$this->interfaceSelector.'</td>
						</tr>';
			}
			$content.='<tr>
						<td nowrap></td>
						<td></td>
						<td nowrap><input type="Submit" name="commandLI" value="'.$this->L_vars[3].'" onClick="document.loginform.login_status.value=\'login\';doChallengeResponse();"></td>
					</tr>
			';
		} else {
			if ($interfaceSelector_jump)	{
			$content.='<tr>
							<td nowrap><font face="VERDANA,ARIAL,SANS-SERIF" size="2"><b>'.$this->L_vars[2].':</b></font></td>
							<td></td>
							<td nowrap>'.$interfaceSelector_jump.'</td>
						</tr>';
			$content.='<tr>
							<td colspan=3>&nbsp;</td>
						</tr>';
			}
			$content.='
					<tr>
						<td nowrap><B><font face="VERDANA,ARIAL,SANS-SERIF" size="2">&nbsp;&nbsp;'.$BE_USER->user["username"].'&nbsp;&nbsp;</font></b></td>
						<td></td>
						<td nowrap><input type="Hidden" name="p_field" value=""><input type="Submit" name="commandLO" value="'.$this->L_vars[4].'" onClick="document.loginform.p_field.value=\'\'; document.loginform.login_status.value=\'logout\';"></td>
					</tr>
			';
		}
		$content.='
				</table>
			</td>
		</tr>
		</table>
		<input type="Hidden" name="userident" value="">
		<input type="Hidden" name="challenge" value="'.$challenge.'">
		<input type="Hidden" name="redirect_url" value="'.htmlspecialchars($this->redirect_url).'">
		<input type="Hidden" name="loginRefresh" value="'.t3lib_div::GPvar("loginRefresh").'">
		<input type="Hidden" name="login_status" value="">
		'.$interfaceHidden.'
		</form>
		</div>
		';
		
		return $content;
	}
	function makeStartHTML()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_MODULES,$TBE_TEMPLATE;

		$content="";;

		if (!$BE_USER->user["uid"])	{
			$content.='
			<script language="JavaScript">
			  if (parent.typoWin && parent.typoWin.TS)	{
				  document.loginform.username.value = parent.typoWin.TS.username;
			  }
			  if (document.loginform.username.value == \'\') {
			    document.loginform.username.focus();
			  } else {
			    document.loginform.p_field.focus();
			  }
			</script>
			';
		}
		
		// If a users is logged in:
		// AND if either the login is just done (commandLI) or a loginRefresh is done or the interface-selector is NOT enabled (If it is on the other hand, it should not just load an interface, because people has to choose then...)
		if ($BE_USER->user["uid"] && (t3lib_div::GPvar("commandLI") || t3lib_div::GPvar("loginRefresh") || !$this->interfaceSelector))	{
			switch ($this->GPinterface)	{
				case "classic":
					if (!$this->forceA)	$this->redirect_url="";
				break;
				case "alternative":
					$this->redirect_url = "alt_main.php";
				break;
				case "frontend":
					$this->redirect_url = "../";
				break;
			}
		
		
		
			if ($this->redirect_url && !t3lib_div::GPvar("loginRefresh"))	{
				header("Location: ".$this->redirect_url);
				exit;
			} else {
				if ($BE_USER->uc["winH"] && $BE_USER->uc["winW"])	{
					$winH=t3lib_div::intInRange($BE_USER->uc["winH"],500,1200);
					$winW=t3lib_div::intInRange($BE_USER->uc["winW"],500,1200);	// Standard value is 655
					$winWidth='height='.$winH.',width='.$winW.',';
				} else {
					$winWidth='';
				}
				
				$JSwindowParams = $BE_USER->uc["JSwindowParams"] ?  $BE_USER->uc["JSwindowParams"] : $winWidth.'status=1,menubar=0,resizable='.($CLIENT["BROWSER"]=="msie" || ($CLIENT["BROWSER"]=="net" && $CLIENT["VERSION"]>=6)? 1 : 0);
				
				$content.='
				<script language="JavaScript">
					var openD = '.($BE_USER->uc["openDirectly"]?1:0).';
					var openA = '.($BE_USER->uc["alternativeBackend"]&&t3lib_div::GPvar("interface")!="classic"?1:0).';
				
					function start()	{
						var time = new Date();
						var theCount=time.getSeconds();
						if (openD)	{theCount = "";	}
						theCount+="'.md5(getenv("HTTP_HOST")).'";
						window.open("main.php","typowin_"+theCount,"'.$JSwindowParams.'");
					}
				
					if (parent.typoWin && parent.typoWin.busy) {
						parent.typoWin.busy.loginRefreshed();
						parent.close();
					} else if (top.opener && top.opener.busy) {
						top.opener.busy.loginRefreshed();
						top.close();
					} else if (top.opener && top.opener.TBE_EDITOR_loginRefreshed) {
						top.opener.TBE_EDITOR_loginRefreshed();
						top.close();
					} else {
						if (openA) {
							document.location = "alt_main.php";
						} else if (openD)	{
							document.location = "../";
							start();
						} else {
							if (confirm("'.$LANG->php3Lang["mess"]["start_typo3"].'"))	{
								document.location = "../";
								start();
							}
						}
					}
				</script>
				';
				$content.="<BR>".$TBE_TEMPLATE->fontwrap($LANG->php3Lang["mess"]["close_login"].'<BR><BR><A href="#" onClick="start();">Start Typo3</a>');
			}
		}
		return $content;
	}
	function printContent()	{
		global $TBE_MODULES,$TBE_TEMPLATE;

		$TBE_TEMPLATE->topSpace=0;

		echo $TBE_TEMPLATE->startPage("Typo3 Login");
		echo '
		<SCRIPT LANGUAGE="JavaScript" SRC="md5.js"></SCRIPT>
		<script language="javascript">
		  function doChallengeResponse() {
		  	password = document.loginform.p_field.value;
			if (password)	{
				password = MD5(password);	// this makes it superchallenged!!
			    str = document.loginform.username.value+":"+password+":"+document.loginform.challenge.value;
			    document.loginform.userident.value = MD5(str);
			    document.loginform.p_field.value = "";
			    document.loginform.submit();
			}
		  }
		</script>';
		
		t3lib_BEfunc::typo3PrintError ($this->L_vars[6],$this->content,"",0);
		echo $TBE_TEMPLATE->endPage();
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_index");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>
