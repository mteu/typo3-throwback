<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TBE init
 *
 * This script is called by every backend script. The script autheticates the backend user.
 * In addition this script also initializes the database and other stuff by including the script localconf.php
 * 
 * IMPORTANT:
 * This script exits if no user is logged in. 
 * If you want the script to return, you must define the constant TYPO3_PROCEED_IF_NO_USER=1 before you include this script.
 *
 * 
 * This script does the following:
 * - extracts and defines path's
 * - includes certain libraries
 * - authenticates the user
 * - sets the configuration values (localconf.php)
 * - includes tables.php that sets more values and possibly overrides others
 * - load the groupdata for the user and set filemounts / webmounts
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
/***************************************************************
Global Variables in Typo3 after this script:
	$BE_USER	:			(object) The user object
	$WEBMOUNTS	:			Array of uid's to be mounted in the page-tree
	$FILEMOUNTS	: 			Array of filepaths on the server to be mountet in the directory tree
	$FILEICONS	:			Assoc. array; keys are the type (eg. "tif") and values are the filename (without path)
	$PARSETIME_START
	$CLIENT

Constants:
	PATH_typo3	:	Absolute path to the typo3 folder
	PATH_typo3_mod	:	Relative path (from the PATH_typo3) to a properly configured module
	PATH_site	:	Absolute path to the site (the folder right before the typo3/ folder)
	PATH_temp	:	Path to temporary folder used for gifs and stuff in the interface
	PATH_t3lib	:	Path to the t3lib
	PATH_typo3conf	:	Path to the typo3conf/ folder
	
See "Inside Typo" for more details on the TBE (Typo3 BackEnd)
*/


// *******************************
// Set error reporting 
// *******************************
error_reporting (E_ALL ^ E_NOTICE); 


// *******************************
// Define constants
// *******************************
define("TYPO3_OS", stristr(PHP_OS,"win")&&!stristr(PHP_OS,"darwin")?"WIN":"");
define("TYPO3_MODE","BE");
define("PATH_thisScript",
	TYPO3_OS=="WIN" ?
	str_replace('//','/',str_replace('\\','/', $HTTP_SERVER_VARS["PATH_TRANSLATED"]?$HTTP_SERVER_VARS["PATH_TRANSLATED"]:getenv("PATH_TRANSLATED"))) :
	(php_sapi_name()=="cgi"?(getenv("PATH_TRANSLATED")?getenv("PATH_TRANSLATED"):getenv("SCRIPT_FILENAME")):$HTTP_SERVER_VARS["PATH_TRANSLATED"])
);
define("TYPO3_mainDir", "typo3/");		// This is the directory of the backend administration for the sites of this Typo3 installation. 


// *******************************
// Checking path
// *******************************
$temp_path = dirname(PATH_thisScript)."/";
$temp_modPath="";
	// If TYPO3_MOD_PATH is defined we must calculate the modPath as we're included by a module
if (substr($temp_path,-strlen(TYPO3_mainDir))!=TYPO3_mainDir)	{
	if (defined("TYPO3_MOD_PATH"))	{
		if (substr($temp_path,-strlen(TYPO3_MOD_PATH))==TYPO3_MOD_PATH)	{
			$temp_path=substr($temp_path,0,-strlen(TYPO3_MOD_PATH));
			$temp_modPath=TYPO3_MOD_PATH;	
		} elseif (substr(TYPO3_MOD_PATH,0,13)=="../typo3conf/" && (substr(TYPO3_MOD_PATH,3)==substr($temp_path,-strlen(substr(TYPO3_MOD_PATH,3))))) {
			$temp_path = substr($temp_path,0,-strlen(substr(TYPO3_MOD_PATH,3))).TYPO3_mainDir;
			$temp_modPath=TYPO3_MOD_PATH;
		}
		if (!@is_dir($temp_path))	{
			$temp_path="";
		}
	}
}
if (!$temp_path || substr($temp_path,-strlen(TYPO3_mainDir))!=TYPO3_mainDir)	{	// This must be the case in order to proceed
	echo ("Error in init.php: sitepath not specified correctly. <BR><BR>This happens if the last ".strlen(TYPO3_mainDir)." characters of this path, ".$temp_path.", (\$temp_path) is NOT '".TYPO3_mainDir."' for some reason. <BR> Or did you set constant TYPO3_MOD_PATH in your module?");
	echo "<BR><strong>If you expect any help from anybody on this issue, you should save this page as an html document and send it along with your request for help!</strong>";
	echo "<HR><pre>";
	print_r(array("TYPO3_OS"=>TYPO3_OS,"PATH_thisScript"=>PATH_thisScript,"php_sapi_name()"=>php_sapi_name(),"getenv('PATH_TRANSLATED')"=>getenv("PATH_TRANSLATED"),"HTTP_SERVER_VARS['PATH_TRANSLATED']"=>$HTTP_SERVER_VARS["PATH_TRANSLATED"],"SCRIPT_FILENAME"=>getenv("SCRIPT_FILENAME")));
	echo "</pre><HR>";
	phpinfo();
	exit;
} else {
	define("PATH_typo3", $temp_path);
	define("PATH_typo3_mod", $temp_modPath);
	define("PATH_site", substr(PATH_typo3,0,-strlen(TYPO3_mainDir)));
	define("PATH_temp", PATH_typo3."temp/"); 
	define("PATH_t3lib", PATH_typo3."t3lib/");		// Typo-lib path
	define("PATH_typo3conf", PATH_site."typo3conf/");	// Typo-configuraton path
}


// *********************
// t3lib_div included
// *********************
include_once(PATH_t3lib."class.t3lib_div.php");		// The standard-library is included


// **********************
// Include configuration
// **********************
include(PATH_t3lib."config_default.php");		
if (!defined ("TYPO3_db")) 	die ("The configuration file was not included.");
$CLIENT=t3lib_div::clientInfo();				// Set to the browser: net / msie if 4+ browsers
$PARSETIME_START = t3lib_div::milliseconds();		// Is set to the systemtime in milliseconds. This could be used to output script parsetime in the end of the script


// *********************
// Libraries included
// *********************
include_once(PATH_t3lib."class.t3lib_userauth.php");
include_once(PATH_t3lib."class.t3lib_userauthgroup.php");
include_once(PATH_t3lib."class.t3lib_beuserauth.php");
include_once(PATH_t3lib."class.t3lib_iconworks.php");
include_once(PATH_t3lib."class.t3lib_befunc.php");


// **********************
// Check IP
// **********************
if (trim($TYPO3_CONF_VARS["BE"]["IPmaskList"]))	{
	if (!t3lib_div::cmpIP(getenv("REMOTE_ADDR"), $TYPO3_CONF_VARS["BE"]["IPmaskList"]))	{
		header("Status: 404 Not Found");	// Send Not Found header - if the webserver can make use of it...
		header("Location: http://");	// Just point us away from here...
		exit;	// ... and exit good!
	}
}


// *******************************
// Checking environment
// *******************************
if ((double)phpversion()<4 || (intval(substr(phpversion(),4))<3 && intval(substr(phpversion(),2))<1))	die ("Typo3 runs with PHP4.0.3+ only");
if (isset($HTTP_POST_VARS["GLOBALS"]) || isset($HTTP_GET_VARS["GLOBALS"]))	die("You cannot set the GLOBALS-array from outside the script.");
if (!get_magic_quotes_gpc())	{
	t3lib_div::addSlashesOnArray($HTTP_GET_VARS);
	t3lib_div::addSlashesOnArray($HTTP_POST_VARS);
}


// ********************************************
// Check if the install script should be run:
// ********************************************
if (defined("TYPO3_enterInstallScript") && TYPO3_enterInstallScript)	{
	include_once(PATH_t3lib."class.t3lib_install.php");
	include_once(PATH_t3lib."class.t3lib_stdgraphic.php");
	$install_check = t3lib_div::makeInstance("t3lib_install");
	$install_check->allowUpdateLocalConf=1;
	$install_check->init();
	exit;
}


// *************************
// Connect to the database
// *************************
if (@mysql_pconnect(TYPO3_db_host, TYPO3_db_username, TYPO3_db_password))	{
	if (!TYPO3_db)	{
		t3lib_BEfunc::typo3PrintError ("No database selected","Database Error");
		exit;
	} elseif (!mysql_select_db(TYPO3_db))	{
		t3lib_BEfunc::typo3PrintError ("Cannot connect to the current database, '".TYPO3_db."'","Database Error");
		exit;
	}
} else {
	t3lib_BEfunc::typo3PrintError ("The current username, password or host was not accepted when the connection to the database was attempted to be established!","Database Error");
	exit;
}


// *******************************
// Checks for proper browser
// *******************************
if (!$CLIENT["BROWSER"])	{
	t3lib_BEfunc::typo3PrintError ("Browser error","You must use 4+ browsers with Typo3!",0);
	exit;
}


// *******************************
// File icons
// This defines icons for the various file-formats
// *******************************
$FILEICONS = Array (
	"txt" => "txt.gif",
	"pdf" => "pdf.gif",
	"doc" => "doc.gif",
	"ai" => "ai.gif",
	"bmp" => "bmp.gif",
	"tif" => "tif.gif",
	"htm" => "html1.gif",
	"html" => "html1.gif",
	"pcd" => "pcd.gif",
	"gif" => "gif.gif",
	"jpg" => "jpg.gif",
	"jpeg" => "jpg.gif",
	"mpg" => "mpeg.gif",
	"mpeg" => "mpeg.gif",
	"exe" => "exe.gif",
	"com" => "exe.gif",
	"zip" => "zip.gif",
	"tgz" => "zip.gif",
	"gz" => "zip.gif",
	"php3" => "php3.gif",
	"php" => "php3.gif",
	"ttf" => "ttf.gif",
	"pcx" => "pcx.gif",
	"png" => "png.gif",
	"tga" => "tga.gif",
	"class" => "java.gif",
	"swf" => "flash.gif",
	"swa" => "flash.gif",
	"dcr" => "flash.gif",
	"wav" => "wav.gif",
	"mp3" => "wav.gif",
	"avi" => "avi.gif",
	"au" => "au.gif",
	"mov" => "mov.gif",
	"default" => "default.gif"
);


// *******************************
// Customization: 
// *******************************
/*
 tables.php holds all customized values that makes Typo work with different projects
 - database, tables / fields 
 - modules
 - overriding values like: image-formats, filemounts
*/
include (TYPO3_tables_script ? PATH_typo3conf.TYPO3_tables_script : PATH_t3lib."install/tables.php");
if (TYPO3_extTableDef_script)	{
	include (PATH_typo3conf.TYPO3_extTableDef_script);
}


// *******************************
// BackEnd User authentication
// *******************************
/* 
	if constant TYPO3_PROCEED_IF_NO_USER is defined true (in the mainscript), this script will return even though a user did not log in!
*/
$BE_USER = t3lib_div::makeInstance("t3lib_beUserAuth");	// New backend user object
$BE_USER->warningEmail = $GLOBALS["TYPO3_CONF_VARS"]["BE"]["warning_email_addr"];
$BE_USER->OS = TYPO3_OS;
$BE_USER->start();			// Object is initialized
$BE_USER->backendCheckLogin();	// Checking if there's a user logged in and if so, call the 
$BE_USER->trackBeUser($GLOBALS["TYPO3_CONF_VARS"]["BE"]["trackBeUser"]);	// Tracking backend user script hits

	// Setting the web- and filemount global vars:
$WEBMOUNTS = $BE_USER->returnWebmounts();
$FILEMOUNTS = $BE_USER->returnFilemounts();

// ***********************************************
// Setting typical global incoming variables.
// This is needed if register_globals is disabled in php.ini
// ***********************************************
#$id=t3lib_div::GPvar("id");					// Typ. in the submodules, web/file-module (removed 21/5-2002)
$AB=t3lib_div::GPvar("AB");					// Flag for 'Alternative Backend'


// ****************
// compression
// ****************
if ($TYPO3_CONF_VARS["BE"]["compressionLevel"])	{
	ob_start();
	include_once(PATH_t3lib."class.gzip_encode.php");
}

?>