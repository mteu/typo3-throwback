<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This is the buttons in the upper right corner of the Typo3 standard interface
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */







// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








include("init.php");
include("template.php");


// ******************************
// Starting document output
// ******************************
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE>Typo 3 Buttons frame</TITLE>
</head>
<BODY bgcolor="<?php echo $TBE_TEMPLATE->bgColor2;?>" LINK="#000000" marginwidth="1" marginheight="2" topmargin="2" leftmargin="2">
<table border=0 cellspacing=0 cellpadding=1 align="right">
<tr>
	<td nowrap><script language="javascript">
		document.write('<a href="#" onClick="parent.busy.click();">');
		document.write(parent.glImage.getTag('sys_busy','h','sys_busy','System status',''));
		document.write('</a>');

		document.write('<img src="clear.gif" width=5 height=1 border="0">');
		document.write(parent.buttons['thumbmode'].draw(''));
		document.write('<img src="clear.gif" width=5 height=1 border="0">');
		document.write(parent.buttons['selectmode'].draw(''));
		document.write('<img src="clear.gif" width=5 height=1 border="0">');
		document.write(parent.buttons['clipboard'].draw(''));
		document.write('<img src="clear.gif" width=5 height=1 border="0">');
		document.write(parent.buttons['logout'].draw(''));
		document.write('<img src="clear.gif" width=2 height=1 border="0">');
</script></td>
</tr>
</table>
<script language="javascript">
	parent.buttons['selectmode'].enable(!(parent.clipBrd.pad == 'normal' || !parent.clipBrd.clipboard));
	parent.buttons['selectmode'].init();
	parent.buttons['thumbmode'].init();
	parent.buttons['clipboard'].init();
	parent.buttons['logout'].init();
	parent.bottonsFrameLoaded=1;
</script>
</body>
</html>