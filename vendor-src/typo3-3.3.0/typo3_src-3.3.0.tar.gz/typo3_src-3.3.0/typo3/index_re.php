<?php

// Meant to solve the trailing slash problem with Apache:
// Make a mod_rewrite rule like this:
//		RewriteRule   ^typo3$  typo3/index_re.php
// ... and this document will redirect to the right script.

header("Location: ".getenv("REQUEST_URI")."/index.php");
?>