<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Logout script for the backend
 *
 * This script saves the interface positions and calls the closeTypo3Windows in the frameset
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
include("init.php");

// ***************************
// Script Classes
// ***************************
class SC_logout {
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$ATBE = t3lib_div::GPvar("ATBE");

		// ******************************
		// Storing user settings
		// ******************************
		if (is_array($HTTP_GET_VARS) && !$ATBE)	{
			$interfaceSetup=unserialize($BE_USER->uc[interfaceSetup]);
			if (!is_array($interfaceSetup)){$interfaceSetup=Array();}
			$interfaceSetup["currentMenuFane"]=$HTTP_GET_VARS["currentMenuFane"];
			$interfaceSetup["mod"]=$HTTP_GET_VARS["mod"];
			$interfaceSetup["submod"]=$HTTP_GET_VARS["submod"];
			if (isset($HTTP_GET_VARS["dirTree"]))		{$interfaceSetup["dirTree"]=$HTTP_GET_VARS["dirTree"];}
			if (isset($HTTP_GET_VARS["pageTree"]))	{$interfaceSetup["pageTree"]=$HTTP_GET_VARS["pageTree"];}	
			$BE_USER->uc["interfaceSetup"]=serialize($interfaceSetup);
			$BE_USER->writeUC($BE_USER->uc);
		}
		
		if ($HTTP_GET_VARS["sendLogoutSignal"])	{
			$BE_USER->writelog(255,2,0,1,"User %s logged out from Typo3 Interface",Array($BE_USER->user["username"]));	// Logout written to log
			$BE_USER->logoff();
			if ($ATBE)	{
				header("Location: ".t3lib_div::GPvar("redirect"));
			}
		}
	}
	function main()	{
		global $HTTP_GET_VARS;
		$this->content.='
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
		<HTML>
		<HEAD>
		<TITLE>Typo 3.2 Logout script</TITLE>
		</HEAD>
		<BODY bgcolor="#F7F3EF" LINK="#000000" marginwidth="3" marginheight="1">
		'.($HTTP_GET_VARS["sendLogoutSignal"]?'<script language="javascript">top.closeTypo3Windows()</script>':'').'
		</body>
		</HTML>';
	}
	function printContent()	{
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/logout.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/logout.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_logout");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>
