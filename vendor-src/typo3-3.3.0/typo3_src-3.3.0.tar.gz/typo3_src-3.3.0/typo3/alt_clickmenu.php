<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Alternative TBE: Click menu
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_clipboard.php");
include("lang/LL_misc.php");


// ***************************
// Script Classes
// ***************************
class alt_clickmenu_CMtemplate extends template {
	var $ext_background_image="gfx/alt_topmenu_back_full.gif";
	function docBodyTagBegin()	{
		return '<BODY bgColor="'.$this->bgColor2.'" LINK="#000000" ALINK="#000000" VLINK="#000000" marginwidth="3" marginheight="1" background="'.$this->ext_background_image.'">';
	}
}
class clickMenu {
	var $backPath="";
	var $elCount=0;
	var $listFrame=0;
	var $isDBmenu=0;
	var $alwaysContentFrame=0;
	var $iParts=array();
	var $disabledItems=array();
	var $editPageIconSet=0;
	var $dontDisplayTopFrameCM=0;
	var $leftIcons=0;
	
	function init($item)	{
		$this->iParts = $iParts = explode(":",$item);
		if ($iParts[2])	$this->listFrame=1;
		if ($GLOBALS["BE_USER"]->uc["condensedMode"]) $this->alwaysContentFrame=1;
		if (strcmp($iParts[1],""))	$this->isDBmenu=1;

		$TSkey =($this->isDBmenu?"page":"folder").($this->listFrame?"List":"Tree");
		$this->disabledItems = t3lib_div::trimExplode(",",$GLOBALS["BE_USER"]->getTSConfigVal("options.contextMenu.".$TSkey.".disableItems"),1);
		$this->leftIcons = $GLOBALS["BE_USER"]->getTSConfigVal("options.contextMenu.options.leftIcons");
//debug(implode(",",$this->disabledItems));
		if ($this->isDBmenu)	{
			return $this->printDBClickMenu($iParts[0],$iParts[1]);
		} else {
			return $this->printFileClickMenu($iParts[0]);
		}
	}

	function doDisplayTopFrameCM()	{
		return !$GLOBALS["SOBE"]->doc->isCMlayers() || !$this->dontDisplayTopFrameCM;
	}


	// ***************************************
	// DATABASE
	// ***************************************

	function printDBClickMenu($table,$uid)	{
		global $TCA, $BE_USER;
		$rec = t3lib_BEfunc::getRecord($table,$uid);
		$menuItems=array();
		$root=0;
		if ($table=="pages" && !strcmp($uid,"0"))	{	// Rootlevel
			$root=1;
		}
		if (is_array($rec) || $root)	{
			$lCP = $BE_USER->calcPerms(t3lib_BEfunc::getRecord("pages",($table=="pages"?$rec["uid"]:$rec["pid"])));
			$editOK=0;
				// View
			if (!in_array("view",$this->disabledItems))	{
				if ($table=="pages")	$menuItems[]=$this->DB_view($uid);
				if ($table==$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"])	$menuItems[]=$this->DB_view($rec["pid"],"#".$uid);
			}
				// Edit: 
			if(!$root && ($BE_USER->isPSet($lCP,$table,"edit")||$BE_USER->isPSet($lCP,$table,"editcontent")))	{
				if (!in_array("edit",$this->disabledItems))		$menuItems[]=$this->DB_edit($table,$uid);
				$editOK=1;
			}

				// New: 
			if (!in_array("new",$this->disabledItems) && $BE_USER->isPSet($lCP,$table,"new"))	$menuItems[]=$this->DB_new($table,$uid);
			
				// Info:
			if(!in_array("info",$this->disabledItems) && !$root)	$menuItems[]=$this->DB_info($table,$uid);

			$menuItems[]="spacer";
			
				// Copy:
			if(!in_array("copy",$this->disabledItems) && !$root)	$menuItems[]=$this->DB_copycut($table,$uid,"copy");
				// Cut:
			if(!in_array("cut",$this->disabledItems) && !$root)	$menuItems[]=$this->DB_copycut($table,$uid,"cut");

				// Paste:
			$elFromAllTables = count($this->clipObj->elFromTable(""));
			if (!in_array("paste",$this->disabledItems) && $elFromAllTables)	{
				$selItem = $this->clipObj->getSelectedRecord();
				$elInfo=array(
					$selItem["_RECORD_TITLE"],
					($root?$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]:t3lib_BEfunc::getRecordTitle($table,$rec)),
					$this->clipObj->currentMode()
				);
				if ($table=="pages" && ($lCP & 8))	{
					if ($elFromAllTables)	$menuItems[]=$this->DB_paste("",$uid,"into",$elInfo);
				}

				$elFromTable = count($this->clipObj->elFromTable($table));
				if (!$root && $elFromTable  && $TCA[$table]["ctrl"]["sortby"])	$menuItems[]=$this->DB_paste($table,-$uid,"after",$elInfo);
			}

			if ($editOK)	{
				$menuItems[]="spacer";
				if (!in_array("move_wizard",$this->disabledItems) && ($table=="pages" || $table=="tt_content"))	$menuItems[]=$this->DB_moveWizard($table,$uid,$rec);
				if (!in_array("history",$this->disabledItems))	$menuItems[]=$this->DB_history($table,$uid);
				if (!in_array("perms",$this->disabledItems) && $table=="pages" && $BE_USER->check("modules","web_perm"))	$menuItems[]=$this->DB_perms($table,$uid,$rec);
				if (!in_array("db_list",$this->disabledItems) && $BE_USER->check("modules","web_list"))	$menuItems[]=$this->DB_db_list($table,$uid,$rec);
//				$menuItems[]="spacer";
				if (!in_array("new_wizard",$this->disabledItems) && ($table=="pages" || $table=="tt_content"))	$menuItems[]=$this->DB_newWizard($table,$uid,$rec);
				if (!in_array("hide",$this->disabledItems) && $TCA[$table]["ctrl"]["enablecolumns"] && $TCA[$table]["ctrl"]["enablecolumns"]["disabled"])	$menuItems[]=$this->DB_hideUnhide($table,$rec,$TCA[$table]["ctrl"]["enablecolumns"]["disabled"]);
				if (!in_array("edit_access",$this->disabledItems) && is_array($TCA[$table]["ctrl"]["enablecolumns"]))	$menuItems[]=$this->DB_editAccess($table,$uid);
				if (!in_array("edit_pageheader",$this->disabledItems) && $table=="pages" && $this->editPageIconSet)	$menuItems[]=$this->DB_editPageHeader($uid);
			}
		
				// Delete:
			$elInfo=array(t3lib_BEfunc::getRecordTitle($table,$rec));
			if(!in_array("delete",$this->disabledItems) && !$root && $BE_USER->isPSet($lCP,$table,"delete"))	{
				$menuItems[]="spacer";
				$menuItems[]=$this->DB_delete($table,$uid,$elInfo);
			}
		}
		$menuItems = $this->externalProcessingOfDBMenuItems($menuItems);
		return $this->printItems($menuItems,
			$this->wrapColorTable(
				$root?
				'<img src="'.$this->backPath.'gfx/i/_icon_website.gif" width="18" height="16" hspace=5 border="0" align=absmiddle><strong>'.htmlspecialchars($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]).'</strong>':
				t3lib_iconWorks::getIconImage($table,$rec,$this->backPath," hspace=5 align=absmiddle".t3lib_BEfunc::titleAttrib(t3lib_BEfunc::getRecordIconAltText($rec,$table))).'<strong>'.t3lib_BEfunc::getRecordTitle($table,$rec,1).'</strong>'
			)
		);
	}
	function externalProcessingOfDBMenuItems($menuItems)	{
		return $menuItems;
	}
	function DB_copycut($table,$uid,$type)	{
		if ($this->clipObj->current=="normal")	{
			$isSel = $this->clipObj->isSelected($table,$uid);
		}	
		return $this->linkItem(
			$this->label($type),$this->excludeIcon('<img src="'.$this->backPath.'gfx/clip_'.$type.($isSel==$type?"_h":"").'.gif" width="12" height="12" border=0 align=top>'),
			"top.loadTopMenu('".$this->clipObj->selUrlDB($table,$uid,($type=="copy"?1:0),($isSel==$type))."');return false;"
		);
	}

	// $table and $uid should follow the special syntax for paste, see clipboard-class :: pasteUrl();
	function DB_paste($table,$uid,$type,$elInfo)	{	
		$editOnClick="";
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".db_list_frame":"");
		$conf=$loc." && confirm(unescape('".rawurlencode(sprintf($GLOBALS["LANG"]->mainLang["mess"][($elInfo[2]=="copy"?"copy":"move")."_".$type],$elInfo[0],$elInfo[1]))."'))";
		$editOnClick="if(".$conf."){".$loc.".document.location=top.TS.PATH_typo3+'".$this->clipObj->pasteUrl($table,$uid,0)."&redirect='+top.rawurlencode(".$this->frameLocation($loc.".document")."); hideCM();}";
		return $this->linkItem(
			$this->label("paste".$type),$this->excludeIcon('<img src="'.$this->backPath.'gfx/clip_paste'.$type.'.gif" width="12" height="12" border=0 align=top>'),
			$editOnClick."return false;"
		);
	}
	function DB_info($table,$uid)	{
		return $this->linkItem(
			$this->label("info"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/zoom2.gif" width="12" height="12" border=0 align=top>'),
			"top.launchView('".$table."', '".$uid."'); return hideCM();"			
		);
	}
	function DB_history($table,$uid)	{
		$url = 'show_rechis.php?element='.rawurlencode($table.":".$uid);
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_history"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/history2.gif" width="13" height="12" border=0 align=top>'),
			$this->urlRefForCM($url,"returnUrl"),
			1
		);
	}
	function DB_perms($table,$uid,$rec)	{
		$url = 'mod/web/perm/index.php?id='.$uid.($rec["perms_userid"]==$GLOBALS["BE_USER"]->user["uid"]||$GLOBALS["BE_USER"]->isAdmin()?'&return_id='.$uid.'&edit=1':'');
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_perms"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/perm.gif" width="7" height="12" border=0 align=top>'),
			$this->urlRefForCM($url),
			1
		);
	}
	function DB_db_list($table,$uid,$rec)	{
		$url = "http://".t3lib_div::getThisUrl().'db_list.php?table='.($table=="pages"?"":$table).'&id='.($table=="pages"?$uid:$rec["pid"]);
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_db_list"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/list.gif" width="11" height="11" border=0 align=top>'),
			"top.nextLoadModuleUrl='".$url."';top.goToModule('web_list',1);",
			1
		);
	}
	function DB_moveWizard($table,$uid,$rec)	{
		$url = 'move_el.php?table='.$table.'&uid='.$uid.($table=="tt_content"?"&sys_language_uid=".intval($rec["sys_language_uid"]):"");
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_moveWizard".($table=="pages"?"_page":"")),$this->excludeIcon('<img src="'.$this->backPath.'gfx/move_'.($table=="pages"?"page":"record").'.gif" width="11" height="12" border=0 align=top>'),
			$this->urlRefForCM($url,"returnUrl"),
			1
		);
	}
	function DB_newWizard($table,$uid,$rec)	{
		$url = ($table=="pages") ? 'db_new.php?id='.$uid.'&pagesOnly=1' : 'db_new_content_el.php?id='.$rec["pid"]."&sys_language_uid=".intval($rec["sys_language_uid"]);
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_newWizard"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/new_'.($table=="pages"?"page":"record").'.gif" width="'.($table=="pages"?"13":"16").'" height="12" border=0 align=top>'),
			$this->urlRefForCM($url,"returnUrl"),
			1
		);
	}
	function DB_editAccess($table,$uid)	{
		global $BE_USER;
		$addParam="&columnsOnly=".implode(",",$GLOBALS["TCA"][$table]["ctrl"]["enablecolumns"]);
		$url = "alt_doc.php?edit[".$table."][".$uid."]=edit".$addParam;
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_editAccess"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/editaccess.gif" width="12" height="12" border=0 align=top>'),
			$this->urlRefForCM($url,"returnUrl"),
			1	// no top frame CM!
		);
	}
	function DB_editPageHeader($uid)	{
		global $BE_USER;
		$table="pages";
		$url = "alt_doc.php?edit[".$table."][".$uid."]=edit";
		return $this->linkItem(
			$GLOBALS["LANG"]->getLL("CM_editPageHeader"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/edit2.gif" width="11" height="12" border=0 align=top>'),
			$this->urlRefForCM($url,"returnUrl"),
			1	// no top frame CM!
		);
	}
	function urlRefForCM($url,$retUrl="",$hideCM=1)	{
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".db_list_frame":"");
		$editOnClick="var docRef=(top.content.db_list_frame)?top.content.db_list_frame:".$loc."; docRef.document.location=top.TS.PATH_typo3+'".$url."'".
			($retUrl?"+'&".$retUrl."='+top.rawurlencode(".$this->frameLocation("docRef.document").")":"").";".
			($hideCM?"return hideCM();":"");
		return $editOnClick;
	}
	function DB_edit($table,$uid)	{
		global $BE_USER;

		$editOnClick="";
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".db_list_frame":"");
		$addParam="";
		$theIcon = 'gfx/edit2.gif" width="11" height="12"';
		if (
//				!$this->listFrame && 
				$this->iParts[0]=="pages" && 
				$this->iParts[1] && 
				$GLOBALS["BE_USER"]->check("modules","web_layout")
			)	{
			$theIcon = 'gfx/edit_page.gif" width="12" height="12"';
			$this->editPageIconSet=1;
			if ($BE_USER->uc["classicPageEditMode"])	{
				$addParam="&editRegularContentFromId=".$this->iParts[1];
			} else {
				$editOnClick="top.theMenu.recentuid=".intval($this->iParts[1]).";top.goToModule('web_layout',1);";
			}
		}
		if (!$editOnClick)	{
			$editOnClick="if(".$loc."){".$loc.".document.location=top.TS.PATH_typo3+'alt_doc.php?returnUrl='+top.rawurlencode(".$this->frameLocation($loc.".document").")+'&edit[".$table."][".$uid."]=edit".$addParam."';}";
		}
		return $this->linkItem(
			$this->label("edit"),$this->excludeIcon('<img src="'.$this->backPath.$theIcon.' border=0 align=top>'),
			$editOnClick."return hideCM();"
		);
	}
	function DB_new($table,$uid)	{
		$editOnClick="";
		$loc="top.content".(!$this->alwaysContentFrame?".db_list_frame":"");
		$editOnClick="if(".$loc."){".$loc.".document.location=top.TS.PATH_typo3+'".
			($this->listFrame?
				$this->backPath."alt_doc.php?returnUrl='+top.rawurlencode(".$this->frameLocation($loc.".document").")+'&edit[".$table."][-".$uid."]=new'":
				$this->backPath."db_new.php?id=".intval($uid)."&AB=1'").
			";}";
		return $this->linkItem(
			$this->label("new"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/new_'.($table=="pages"&&$this->listFrame?"page":"el").'.gif" width="'.($table=="pages"?"13":"11").'" height="12" border=0 align=top>'),
			$editOnClick."return hideCM();"
		);
	}
	function DB_hideUnhide($table,$rec,$hideField)	{
		$uid=$rec["uid"];
		$editOnClick="";
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".db_list_frame":"");
		$editOnClick="if(".$loc."){".$loc.".document.location=top.TS.PATH_typo3+'tce_db.php?redirect='+top.rawurlencode(".$this->frameLocation($loc.".document").")+'&data[".$table."][".$uid."][".$hideField."]=".($rec[$hideField]?0:1)."&prErr=1&vC=".$GLOBALS["BE_USER"]->veriCode()."';hideCM();}";
		return $this->linkItem(
			$this->label(($rec[$hideField]?"un":"")."hide"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/button_'.($rec[$hideField]?"un":"").'hide.gif" width="11" height="10" vspace=1 border=0 align=top>'),
			$editOnClick."return false;",
			1
		);
	}
	function DB_delete($table,$uid,$elInfo)	{
		$editOnClick="";
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".db_list_frame":"");
		$editOnClick="if(".$loc." && confirm(unescape('".rawurlencode(sprintf($GLOBALS["LANG"]->mainLang["mess"]["delete"],$elInfo[0]))."'))){".$loc.".document.location=top.TS.PATH_typo3+'tce_db.php?redirect='+top.rawurlencode(".$this->frameLocation($loc.".document").")+'&cmd[".$table."][".$uid."][delete]=1&prErr=1&vC=".$GLOBALS["BE_USER"]->veriCode()."';hideCM();}";
		return $this->linkItem(
			$this->label("delete"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/garbage.gif" width="11" height="12" border=0 align=top>'),
			$editOnClick."return false;"
		);
	}
	function DB_view($id,$anchor="")	{
		return $this->linkItem(
			$this->label("view"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/zoom.gif" width="12" height="12" border=0 align=top>'),
			t3lib_BEfunc::viewOnClick($id,$this->backPath,t3lib_BEfunc::BEgetRootLine($id),$anchor)."return hideCM();"
		);
	}


	// ***************************************
	// FILE
	// ***************************************
	function printFileClickMenu($path)	{
		global $TCA, $BE_USER;
		$menuItems=array();
		if (@file_exists($path))	{
			$fI=pathinfo($path);
			$icon = is_dir($path) ? "folder.gif" : t3lib_BEfunc::getFileIcon(strtolower($fI["extension"]));
			$size=" (".t3lib_div::formatSize(filesize($path))."bytes)";
			$icon = '<img src="gfx/fileicons/'.$icon.'" width=18 height=16 border=0 hspace=5'.t3lib_BEfunc::titleAttrib($fI["basename"].$size).' align=absmiddle>';

				// edit
			if (!in_array("edit",$this->disabledItems) && is_file($path) && t3lib_div::inList($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["textfile_ext"],$fI["extension"])) $menuItems[]=$this->FILE_launch($path,"file_edit.php","edit","edit_file.gif");
				// rename
			if (!in_array("rename",$this->disabledItems))	$menuItems[]=$this->FILE_launch($path,"file_rename.php","rename","rename.gif");
				// upload
			if (!in_array("upload",$this->disabledItems) && is_dir($path)) $menuItems[]=$this->FILE_launch($path,"file_upload.php","upload","upload.gif");
				// new
			if (!in_array("new",$this->disabledItems) && is_dir($path)) $menuItems[]=$this->FILE_launch($path,"file_newfolder.php","new","new_file.gif");
				// info
			if (!in_array("info",$this->disabledItems))	$menuItems[]=$this->DB_info($path,"");

			$menuItems[]="spacer";
			
				// copy:
			if (!in_array("copy",$this->disabledItems))	$menuItems[]=$this->FILE_copycut($path,"copy");
				// cut:
			if (!in_array("cut",$this->disabledItems))	$menuItems[]=$this->FILE_copycut($path,"cut");

				// PAste:
			$elFromAllTables = count($this->clipObj->elFromTable("_FILE"));
			if (!in_array("paste",$this->disabledItems) && $elFromAllTables && is_dir($path))	{
				$elArr = $this->clipObj->elFromTable("_FILE");
				reset($elArr);
				$selItem = current($elArr);
				$elInfo=array(
					basename($selItem),
					basename($path),
					$this->clipObj->currentMode()
				);
				$menuItems[]=$this->FILE_paste($path,$selItem,$elInfo);
			}

			$menuItems[]="spacer";

				// delete:
			if (!in_array("delete",$this->disabledItems))	$menuItems[]=$this->FILE_delete($path);
		}
		$menuItems = $this->externalProcessingOfFileMenuItems($menuItems);
		return $this->printItems($menuItems,
			$this->wrapColorTable(
				$icon.'<strong>'.basename($path).'</strong>'
			)
		);
	}
	function externalProcessingOfFileMenuItems($menuItems)	{
		return $menuItems;
	}
	function frameLocation($str)	{
		return $str.".location";
//		return $str.".T3_THIS_LOCATION?".$str.".T3_THIS_LOCATION:".$str.".location";
	}
	function FILE_launch($path,$script,$type,$image)	{
		$loc="top.content".(!$this->alwaysContentFrame?".file_list_frame":"");
		$editOnClick="if(".$loc."){".$loc.".document.location=top.TS.PATH_typo3+'".$script."?target=".rawurlencode($path)."';}";
		return $this->linkItem(
			$this->label($type),$this->excludeIcon('<img src="'.$this->backPath.'gfx/'.$image.'" width="12" height="12" border="0" align=top>'),
			$editOnClick."return hideCM();"
		);
	}
	function FILE_copycut($path,$type)	{
		$table="_FILE";
		$uid = t3lib_div::shortmd5($path);
		if ($this->clipObj->current=="normal")	{
			$isSel = $this->clipObj->isSelected($table,$uid);
		}	
		return $this->linkItem(
			$this->label($type),$this->excludeIcon('<img src="'.$this->backPath.'gfx/clip_'.$type.($isSel==$type?"_h":"").'.gif" width="12" height="12" border=0 align=top>'),
			"top.loadTopMenu('".$this->clipObj->selUrlFile($path,($type=="copy"?1:0),($isSel==$type))."');return false;"
		);
	}
	function FILE_delete($path)	{
		$editOnClick="";
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".file_list_frame":"");
		$editOnClick="if(".$loc." && confirm(unescape('".rawurlencode(sprintf($GLOBALS["LANG"]->mainLang["mess"]["delete"],basename($path)))."'))){".$loc.".document.location=top.TS.PATH_typo3+'tce_file.php?redirect='+top.rawurlencode(".$this->frameLocation($loc.".document").")+'&file[delete][0][data]=".rawurlencode($path)."&vC=".$GLOBALS["BE_USER"]->veriCode()."';hideCM();}";
		return $this->linkItem(
			$this->label("delete"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/garbage.gif" width="11" height="12" border=0 align=top>'),
			$editOnClick."return false;"
		);
	}
	// $table and $uid should follow the special syntax for paste, see clipboard-class :: pasteUrl();
	function FILE_paste($path,$target,$elInfo)	{	
		$editOnClick="";
		$loc="top.content".($this->listFrame && !$this->alwaysContentFrame ?".file_list_frame":"");
		$conf=$loc." && confirm(unescape('".rawurlencode(sprintf($GLOBALS["LANG"]->mainLang["mess"][($elInfo[2]=="copy"?"copy":"move")."_into"],$elInfo[0],$elInfo[1]))."'))";
		$editOnClick="if(".$conf."){".$loc.".document.location=top.TS.PATH_typo3+'".$this->clipObj->pasteUrl("_FILE",$path,0)."&redirect='+top.rawurlencode(".$this->frameLocation($loc.".document")."); hideCM();}";
		return $this->linkItem(
			$this->label("pasteinto"),$this->excludeIcon('<img src="'.$this->backPath.'gfx/clip_pasteinto.gif" width="12" height="12" border=0 align=top>'),
			$editOnClick."return false;"
		);
	}


	
	// ***************************************
	// COMMON
	// ***************************************

	function wrapColorTable($str)	{
		return '<table border=0 cellpadding=0 cellspacing=0 style="border: solid 1px black;" bgcolor="'.$GLOBALS["TBE_TEMPLATE"]->bgColor2.'"><tr><td>'.$str.'</td><td><img src=clear.gif width=10 height=1></td></tr></table>';
	}
	function printItems($menuItems,$item)	{
		$out = ($this->doDisplayTopFrameCM()?
			'<img src=clear.gif width=1 height=10><BR>
		<table border=0 cellpadding=0 cellspacing=0><tr><td nowrap valign=top>'.implode('</td><td valign=top><img src="gfx/acm_spacer2.gif" width="8" height="12"></td><td nowrap valign=top>',$this->menuItemsForTopFrame($menuItems)).'</td><td><img src=clear.gif width=10 height=1></td>
		<td nowrap valign=top><a href="#" onClick="hideCM();return false;"><img src="gfx/close_12h.gif" width="11" height="12" vspace=2 hspace=5 border="0"'.t3lib_BEfunc::titleAttrib($GLOBALS["LANG"]->mainLang["labels"]["close"]).'></a></td>
		<td>'.$item.'</td></tr></table>
		<BR><BR>
		' : '').
		$this->printLayerJScode($menuItems);
		return $out;
	}
	function menuItemsForTopFrame($menuItems)	{
		reset($menuItems);
		$out=array();
		while(list(,$i)=each($menuItems))	{
			if (is_array($i) && !$i["4"])	$out[]=$i[0];
		}
		return $out;
	}
	function menuItemsForClickMenu($menuItems)	{
		reset($menuItems);
		$out=array();
		while(list($cc,$i)=each($menuItems))	{
			if (is_string($i) && $i=="spacer")	{
				$out[]='<tr style="background:'.$GLOBALS["TBE_TEMPLATE"]->bgColor2.'"><td colspan=4><img src=clear.gif width=1 height=1</td></tr>';
			}	else {
				$onClick=$i[3];
				$onClick=eregi_replace("return[[:space:]]+hideCM\(\)[[:space:]]*;","",$onClick);
				$onClick=eregi_replace("return[[:space:]]+false[[:space:]]*;","",$onClick);
				$onClick=eregi_replace("hideCM\(\);","",$onClick);
				$onClick.='hideEmpty();';
				
				$out[]='<tr onClick="'.$onClick.'" style="cursor:hand;" onMouseOver="this.bgColor=\''.$GLOBALS["TBE_TEMPLATE"]->bgColor5.'\';" onMouseOut="this.bgColor=\'\';">'.
					(!$this->leftIcons?'
					<td nowrap>&nbsp;'.$i[1].'</td>
					<td><img src=clear.gif width=20 height=14></td>
					<td align=center>'.$i[2].'</td>
					<td>&nbsp;</td>'
						:
					'<td><img src=clear.gif width=2 height=14></td>
					<td align=center>'.$i[2].'</td>
					<td nowrap>&nbsp;'.$i[1].'</td>
					<td>&nbsp;</td>').
				'</tr>';
			}
		}
		return $out;
	}
	function isCMlayers()	{
		return $GLOBALS["SOBE"]->doc->isCMlayers() && !t3lib_div::GPvar("CB");
	}
	function printLayerJScode($menuItems)	{
		$script="";
		if ($this->isCMlayers())	{	// Clipboard must not be submitted - then it's probably a copy/cut situation.
			$frameName = ".".($this->listFrame ? ($this->isDBmenu?"db":"file")."_list_frame" : "nav_frame");
			if ($this->alwaysContentFrame)	$frameName="";
			
			$script='<script>
if (top.content && top.content'.$frameName.' && top.content'.$frameName.'.setLayerObj)	{
	top.content'.$frameName.'.setLayerObj(unescape("'.str_replace("%20"," ",rawurlencode($this->wrapColorTableCM('<table border=0 cellpadding=0 cellspacing=0 bgColor="'.$GLOBALS["TBE_TEMPLATE"]->bgColor4.'">'.implode('',$this->menuItemsForClickMenu($menuItems))).'</table>')).'"));
}
</script>';
		}		
		return $script;
	}
	function wrapColorTableCM($str)	{
		//style="border:solid 1px '.$GLOBALS["SOBE"]->bgColor2.'"
		$str = '<table border=0 cellpadding=1 cellspacing=0 bgColor="'.$GLOBALS["TBE_TEMPLATE"]->bgColor4.'" style="border: solid 1px black;"><tr><td>'.$str.'</td></tr></table>';
		return $str;
	}
	function linkItem($str,$icon,$onClick,$onlyCM=0)	{
		$this->elCount++;
		return array('<img src="clear.gif" width="7" height="10" align=top hspace=1 name="roimg_'.$this->elCount.'"><A HREF="#" onClick="'.$onClick.'" onMouseover="mo('.$this->elCount.');" onMouseout="mout('.$this->elCount.');">'.$str.$icon.'</a>',$str,$icon,$onClick,$onlyCM);
	}
	function excludeIcon($iconCode)	{
//		return $iconCode;
		return ($GLOBALS["BE_USER"]->uc["noMenuMode"] && strcmp($GLOBALS["BE_USER"]->uc["noMenuMode"],"icons")) ? "" : " ".$iconCode;
	}
	function label($label)	{
		return htmlspecialchars($GLOBALS["LANG"]->mainLang["cm"][$label]);
	}
}
class SC_alt_clickmenu {
	var $content="";
	var $doc;	
	var $dontDisplayTopFrameCM=0;
		// Constructor:
	function init()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		$secs = t3lib_div::intInRange($BE_USER->getTSConfigVal("options.contextMenu.options.clickMenuTimeOut"),1,100,5);	// default is 3

		$this->doc = t3lib_div::makeInstance("alt_clickmenu_CMtemplate");
		$this->dontDisplayTopFrameCM= $this->doc->isCMlayers() && !$GLOBALS["BE_USER"]->getTSConfigVal("options.contextMenu.options.alwaysShowClickMenuInTopFrame");
		if ($this->dontDisplayTopFrameCM)	$this->doc->ext_background_image = "gfx/alt_topmenu_back_dummy.gif";
		$this->doc->backPath = $BACK_PATH;
		$this->doc->topSpace=0;
		$this->doc->JScode.='
<script language="javascript">
	var date = new Date();
	var mo_timeout = Math.floor(date.getTime()/1000);

	roImg =new Image(); 
	roImg.src = "gfx/content_client.gif";

	routImg =new Image(); 
	routImg.src = "clear.gif";

	function mo(c)	{
		var name="roimg_"+c;
		document[name].src = roImg.src;
		updateTime();
	}
	function mout(c)	{
		var name="roimg_"+c;
		document[name].src = routImg.src;
		updateTime();
	}
	function updateTime()	{
		date = new Date();
		mo_timeout = Math.floor(date.getTime()/1000);
	}	
	
	function timeout_func()	{
		date = new Date();
		if (Math.floor(date.getTime()/1000)-mo_timeout > '.$secs.')	{
			hideCM();
		}
		window.setTimeout("timeout_func();",1*1000);
	}
	function hideCM()	{
		document.location="alt_topmenu_dummy.php";
		return false;
	}
	
	timeout_func();
</SCRIPT>
		';
	}
	function main()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS;

		$clipObj = t3lib_div::makeInstance("t3lib_clipboard");
		$clipObj->initializeClipboard();
		$clipObj->lockToNormal();	// This locks the clipboard to the Normal for this request.
		//if (t3lib_div::GPvar("cmd")=="setCB") $CB["el"] = $clipObj->cleanUpCBC(array_merge($HTTP_POST_VARS["CBH"],$HTTP_POST_VARS["CBC"]),t3lib_div::GPvar("cmd_table"));
		$CB = $HTTP_GET_VARS["CB"];
		$clipObj->setCmd($CB);
		$clipObj->cleanCurrent();
		$clipObj->endClipboard();	// Saves

		$clickMenu = t3lib_div::makeInstance("clickMenu");
		$clickMenu->clipObj = $clipObj;
		$clickMenu->dontDisplayTopFrameCM = $this->dontDisplayTopFrameCM;

		$this->content.=$this->doc->startPage("Alternative Click-menu");
		$this->content.= $clickMenu->init(t3lib_div::GPvar("item"));
	}
	function printContent()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		$this->content.= $this->doc->endPage();
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_clickmenu.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_clickmenu.php"]);
}











// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_clickmenu");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();

?>