<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Typo3 Backend Design
 *
 * This document serves the purpose of writing the trivial elements of the Typo3 standard interface.
 * This class holds the color-definitions, font-definitions and so on.
 *
 * This file is typically included right after the init.php file, if language and layout is needed.
 * In the end of the file, the global $LANG object (language) is initialized
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class template {
	var $bgColor = "#F7F3EF";		// Light background color
	var $bgColor2 = "#9BA1A8";		// Steel-blue
	var $bgColor3 = "#F6F2E6";		// dok.color
	var $bgColor4 = "#D9D5C9";		// light tablerow background, brownish
	var $bgColor5 = "#ABBBB4";		// light tablerow background, greenish
	var $bgColor6 = "#E7DBA8";		// light tablerow background, yellowish, for section headers. Light.
	var $hoverColor = "#254D7B";

/*

	var $bgColor = "#FBF8EB";		// Light background color
	var $bgColor2 = "#7A9EC9";		// Steel-blue
	var $bgColor3 = "#F6F2E6";		// dok.color
	var $bgColor4 = "#DDE4BE";		// light tablerow background, brownish
	var $bgColor5 = "#E6C880";		// light tablerow background, greenish
	var $bgColor6 = "#CED9C3";		// light tablerow background, for section headers. Light.

	*/
	
	var $form_rowsToStylewidth = 9.58;	// Factor from NN4 form field widths to style-aware browsers (like NN6+ and MSIE, with the $CLIENT[FORMSTYLE] value set)
	var $form_NSWidthComp = 1;		// Compensation for NN4 form field widths to other browsers using the cols/size attributes
	var $form_largeComp = 1.33;		// Compensation for large documents, doc-tab (editing)
	
	var $menufont_b = '<FONT FACE="VERDANA,ARIAL" SIZE="1">';		// Default-font
	var $menufont_e = '</FONT>';
	var $menufont_b_D = '<FONT FACE="VERDANA,ARIAL" SIZE="1" COLOR="#666666">';		// Default-font, dimmed
	var $menufont_e_D = '</FONT>';
	var $menufont_b_R = '<FONT FACE="VERDANA,ARIAL" SIZE="1" COLOR="RED">';		// Default-font, dimmed
	var $menufont_e_R = '</FONT>';

	var $subhead_b = '<FONT FACE="VERDANA,ARIAL" SIZE="2">';		// Subheader font
	var $subhead_e = '</FONT>';

	var $head_b = '<FONT FACE="VERDANA,ARIAL" SIZE="3"><B><div align="center">';		// Header font
	var $head_e = '</div></b></FONT>';
	
	var $defStyle = 'font-family: Verdana,Arial,Helvetica,Sans-serif; font-size: 10px;';

//	var $charset = 'iso-2022-jp';
//	var $charset = 'big5';
	var $charset = 'iso-8859-1';
	
	var $bodyTagMargins = array("x"=>0,"y"=>0);
	
	var $backPath = "";	
	var $form="";		// This can be set to the HTML-code for a formtag. Usefull when you need a form to begin exactly after the body-tag
	var $JScode="";		// JavaScript could be accommulated in this var. It will be output in the header.
	var $postCode="";	// JavaScript could be accommulated in this var. It will be output in the end.
	
	var $parseTimeFlag = 0;		// Set this to false when releasing Typo3. Only for dev.
	var $noDocBackground=1;		// Default with "docBackground" was '0'
	var $topSpace=5;	
	var $lMarg = 2;		// Default with "docBackground" was '9'
	var $ABtrack=0;		// If set (for debugging!) if the global var $AB is set, then the background color will change.
	var $endJS=1;
	var $bodyTagAdditions="";
	
	var $tableLayout = Array (		// This helps us to layout tables made with the table()-function
		"defRow" => Array (
			"defCol" => Array('<TD valign="top">','</td>')
		)
	);
	var $table_TR = '<TR>';
	var $table_TABLE = '<TABLE border=0 cellspacing=0 cellpadding=0>';
	
	function parseTime()	{
//debug($GLOBALS["loadTCA_tables"]);
//debug(strlen(serialize($GLOBALS["TCA"])));
		if ($this->parseTimeFlag && $GLOBALS["BE_USER"]->isAdmin()) {return "<BR>".$this->fontwrap("(ParseTime: ".(t3lib_div::milliseconds()-$GLOBALS["PARSETIME_START"])." ms, REQUEST_URI-length: ".strlen(getenv("REQUEST_URI")).")");}
	}
	function initCharset()	{
		$this->charset = $GLOBALS["LANG"]->charSet ? $GLOBALS["LANG"]->charSet : $this->charset;
		return '<meta http-equiv="Content-Type" content="text/html; charset='.$this->charset.'">';
	}
	function formWidth($size=48,$textarea=0,$styleOverride="") {
			// Input or text-field attribute (size or cols)
		$wAttrib = $textarea?"cols":"size";
		if (!$GLOBALS["CLIENT"]["FORMSTYLE"])	{	// If not setting the width by style-attribute
			$size = ceil($size*$this->form_NSWidthComp);
			$retVal = ' '.$wAttrib.'="'.$size.'"';
		} else {	// Setting width by style-attribute. "cols" MUST be avoided with NN6+
			$pixels = ceil($size*$this->form_rowsToStylewidth);
			$retVal = $styleOverride ? ' style="'.$styleOverride.'"' : ' style="width:'.$pixels.'px;"';
		}
//		debug($retVal);
		return $retVal;
	}
	function formWidthText($size=48,$styleOverride="") {
		return $this->formWidth($size,1,$styleOverride);
	}
	function helpStyle()	{
		return $GLOBALS["CLIENT"]["FORMSTYLE"] ? ' style="cursor:help;"':'';
	}
	function template()	{
		global $TBE_STYLES;
		if ($TBE_STYLES["mainColors"]["bgColor"])	$this->bgColor=$TBE_STYLES["mainColors"]["bgColor"];
		if ($TBE_STYLES["mainColors"]["bgColor1"])	$this->bgColor1=$TBE_STYLES["mainColors"]["bgColor1"];
		if ($TBE_STYLES["mainColors"]["bgColor2"])	$this->bgColor2=$TBE_STYLES["mainColors"]["bgColor2"];
		if ($TBE_STYLES["mainColors"]["bgColor3"])	$this->bgColor3=$TBE_STYLES["mainColors"]["bgColor3"];
		if ($TBE_STYLES["mainColors"]["bgColor4"])	$this->bgColor4=$TBE_STYLES["mainColors"]["bgColor4"];
		if ($TBE_STYLES["mainColors"]["bgColor5"])	$this->bgColor5=$TBE_STYLES["mainColors"]["bgColor5"];
		if ($TBE_STYLES["mainColors"]["bgColor6"])	$this->bgColor6=$TBE_STYLES["mainColors"]["bgColor6"];
		if ($TBE_STYLES["mainColors"]["hoverColor"])	$this->hoverColor=$TBE_STYLES["mainColors"]["hoverColor"];

	
		if ($this->ABtrack && t3lib_div::GPvar("AB"))	$this->bgColor="#999999";
		if ($GLOBALS["CLIENT"]["SYSTEM"]=="unix")	{
			$this->menufont_b = '<FONT FACE="SANS-SERIF" SIZE="2">';		// Default-font
			$this->menufont_b_D = '<FONT FACE="SANS-SERIF" SIZE="2" COLOR="#666666">';		// Default-font
			$this->menufont_b_R = '<FONT FACE="SANS-SERIF" SIZE="2" COLOR="RED">';		// Default-font
			$this->subhead_b = '<FONT FACE="SANS-SERIF" SIZE="3">';		// Subheader font
			$this->head_b = '<FONT FACE="SANS-SERIF" SIZE="4"><B><div align="center">';		// Header font
			$this->defStyle = 'font-family: Sans-serif; font-size: 11px;';
			if ($GLOBALS["CLIENT"]["BROWSER"]=="konqu" || $GLOBALS["CLIENT"]["BROWSER"]=="opera")	{
				$this->menufont_b = '<FONT CLASS="defstyle">';		// Default-font
				$this->menufont_b_D = '<FONT CLASS="defstyle" COLOR="#666666">';		// Default-font
				$this->menufont_b_R = '<FONT CLASS="defstyle" COLOR="RED">';		// Default-font
				$this->subhead_b = '<FONT FACE="SANS-SERIF" SIZE="5">';		// Subheader font
				$this->head_b = '<FONT FACE="SANS-SERIF" SIZE="6"><B><div align="center">';		// Header font
			}
		} elseif ($GLOBALS["CLIENT"]["BROWSER"]=="net" && $GLOBALS["CLIENT"]["VERSION"]<6) {
			$this->defStyle = 'font-family: Verdana,Arial,Helvetica,Sans-serif; font-size: 11px;';
			if ($GLOBALS["CLIENT"]["SYSTEM"]=="mac")	$this->form_NSWidthComp=1.5;
			// Nothing. Use old setup with NN 6
		} else {
			$this->menufont_b = '';
			$this->menufont_e = '';
			$this->menufont_b_D = '<FONT COLOR="#666666">';
			$this->menufont_b_R = '<FONT COLOR="RED">';
		}
		if ($GLOBALS["CLIENT"]["BROWSER"]=="opera")	{
			$this->form_NSWidthComp=1.9;
		}
	}
	function docStyle()	{
		$style='<STYLE TYPE="text/css">
	SELECT {'.$this->defStyle.'}
	TEXTAREA  {'.$this->defStyle.'} 
	INPUT {'.$this->defStyle.'}
	TD {'.$this->defStyle.'}
	BODY {'.$this->defStyle.'}
	.defstyle {'.$this->defStyle.'}
	PRE   {font-family: mono-spaced; font-size: 12px;}
	
	A:link {text-decoration: none}
	A:visited {text-decoration: none}
	A:active {text-decoration: none}
	A:hover {color: '.$this->hoverColor.'}
</STYLE>';
		return $style;
	}
	function docBodyTagBegin()	{
		return $this->docPlainBodyTag();
	}
	function docPlainBodyTag()	{
		return'<BODY'.$this->bodyTagAdditions.' bgcolor="'.$this->bgColor.'" marginwidth="'.$this->bodyTagMargins["x"].'" marginheight="'.$this->bodyTagMargins["y"].'" topMargin="'.$this->bodyTagMargins["y"].'" leftMargin="'.$this->bodyTagMargins["x"].'" link="black" alink="gray" vlink="black"'.$this->getBackgroundImage().'>'.$this->form.($this->topSpace?'<IMG src="clear.gif" width="1" height="'.$this->topSpace.'"><BR>':'');
	}
	function getBackgroundImage()	{
		return ($GLOBALS["TBE_STYLES"]["background"]?' background="'.$this->backPath.$GLOBALS["TBE_STYLES"]["background"].'"':'');
	}
	function tblHeader($str,$t=6,$b=3)	{
		$str='<table border=0 cellpadding=1 cellspacing=0 width="100%">'.
			($t?'<tr><td><img src=clear.gif height='.$t.' width=1></td></tr>':'').
			'<tr bgColor='.$this->bgColor6.'><td><strong>'.fw($str).'</strong></td></tr>'.
			($b?'<tr><td><img src=clear.gif height='.$b.' width=1></td></tr>':'').
			'</table>';
		return $str;
	}
	function t3Button($onClick,$label,$type=0)	{
		switch($type)	{
			case 1:
				$button = '<input type="submit" onClick="'.$onClick.'; return false;" value="'.htmlspecialchars($label).'" style="padding: 0 0 0 0; margin: 0 0 0 0; height:18px;">';
			break;
			default:
				$linkText='<a href="#" onClick="'.$onClick.'">'.$label.'</a>';
				$button = '<BR><table border=0 cellpadding=2 cellspacing=0 style="BORDER:dotted 1px '.$this->hoverColor.'; background-color:'.$this->bgColor4.'"><tr><td nowrap>&nbsp;&nbsp;<strong>'.$linkText.'</strong>&nbsp;&nbsp;</td></tr></table>';
			break;
		}
		return $button;
	}

	// ****************
	// Page
	// ****************
	function startPage($title)	{
		$this->initCharset();
			// Write page header.
		$str = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset='.$this->charset.'">
'.$this->docStyle().'
<TITLE>'.$title.'</TITLE>
'.$this->JScode.'
</head>
'.$this->docBodyTagBegin();	
		return $str;
	}
	function endPage()	{
			// Write page end.
		$updateSig=t3lib_BEfunc::getSetUpdateSignal();
		$str = $this->sectionEnd().$this->postCode.$this->endPageJS().$updateSig.$this->parseTime().'
</body>
</html>	';
		return $str;
	}
	function endPageJS()	{
			// JavaScript for the page-end. Among others loginRefreshed is called as standard. If a form was around the </form>-tags is output.
		return ($this->form?'</form>':'').($this->endJS?'<script language="javascript">if (top.busy && top.busy.loginRefreshed) {top.busy.loginRefreshed(); top.busy.checkMD5("'.md5(serialize($GLOBALS["BE_USER"]->groupData)).'")}</script>':'');
	}
		// Dummy functions:
	function header()	{
	}
	function spacer()	{
	}
	function divider()	{
	}
	function divider2()	{
	}
	function sectionBegin()	{
	}
	function sectionEnd()	{
	}	
	function section()	{
	}
	function sectionH($label)	{
		$str='<TR><TD></TD><TD valign="top">'.$this->tblHeader($label).'</TD></TR>';
		return $this->sectionBegin().$str;
	}
	function middle()	{
	}

	// ****************
	// FontWrap
	// ****************
	function fontwrap($string)	{
			// Wraps $string with the menufont_b/e
		return $this->menufont_b.$string.$this->menufont_e;
	}
	function fontwrap_D($string)	{
			// Wraps $string with the menufont_b/e
		return $this->menufont_b_D.$string.$this->menufont_e_D;
	}
	function fontwrap_R($string)	{
			// Wraps $string with the menufont_b/e, RED
		return $this->menufont_b_R.$string.$this->menufont_e_R;
	}
	function fontwrapH($string,$type)	{
			// Wraps $string with the menufont-tags depending on $type
		$type=strtolower($type);
		switch($type)	{
			case "h":
				return $this->head_b.$string.$this->head_e;
			break;
			case "sh":
				return $this->subhead_b.$string.$this->subhead_e;
			break;
			default:
				return $this->menufont_b.$string.$this->menufont_e;
			break;
		}
	}

	// ****************
	// Elements
	// ****************
	function table($arr)	{
		// Print out a table
		if (is_array($arr))	{
			reset($arr);
			$code="";
			$rc=0;
			while(list(,$val)=each($arr))	{
				$layout = is_array($this->tableLayout[$rc]) ? $this->tableLayout[$rc] : $this->tableLayout["defRow"];
				$code_td="";
				if (is_array($val))	{
					$cc=0;
					while(list(,$content)=each($val))	{
						$wrap= is_array($layout[$cc]) ? $layout[$cc] : $layout["defCol"];
						$code_td.=$wrap[0].$this->fontWrap($content).$wrap[1];
						$cc++;
					}
				}
				$code.=$this->table_TR.$code_td.'</tr>';
				$rc++;
			}
			$code=$this->table_TABLE.$code.'</table>';
		}
		return $code;
	}
	function getHeader($table,$row,$path,$noViewPageIcon=0,$tWrap=array("",""))	{
		// Makes the header (icon+title) for a page (used in minidocs on the web-tab)
		global $TCA;
		if (is_array($row))	{
			$iconfile=t3lib_iconWorks::getIcon($table,$row);
			$title= strip_tags($row[$TCA[$table][ctrl][label]]);
			if (!$noViewPageIcon)	$viewPage = $this->viewPageIcon($row["uid"],$this->backPath,'align=top vspace=2');
//			$path.=' id='.$row["uid"];
			if ($table=="pages")	$path.=" - ".t3lib_BEfunc::titleAttribForPages($row,"",0);
		} else {
			$iconfile="gfx/i/_icon_website.gif";
			$title=$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"];
		}
		return $this->wrapClickMenuOnIcon('<img src="'.$this->backPath.$iconfile.'" width=18 height=16 border=0 title="'.$path.'" align="top">',$table,$row["uid"]).$viewPage.'&nbsp;<b>'.$tWrap[0].t3lib_div::fixed_lgd($title,45).$tWrap[1].'</b>';
	}
	function thisBlur()	{
		return ($GLOBALS["CLIENT"]["FORMSTYLE"]?'this.blur();':'');
	}
	function wrapClickMenuOnIcon($str,$table,$uid="",$forceAB=0,$listFr=1)	{
		return ($GLOBALS["AB"]||$forceAB) ? '<A HREF="#" onClick="top.loadTopMenu(\''.$this->backPath.'alt_clickmenu.php?item='.rawurlencode($table.":".$uid.":".$listFr).'\');'.$this->thisBlur().'return false;">'.$str.'</A>' : $str;
	}
	function getFileheader($title,$path,$iconfile)	{
		$fileInfo = t3lib_div::split_fileref($title);
		$title=$fileInfo["path"]."<b>".$fileInfo["file"]."</b>";
		$title=t3lib_div::fixed_lgd_pre($title,45);
		return '<img src="'.$this->backPath.$iconfile.'" width=18 height=16 border=0 title="'.$path.'" align="top">&nbsp;'.$title;
	}
	function funcMenu($content,$menu)	{
		return '<table border=0 cellpadding=0 cellspacing=0 width=470>
		<tr><td valign=top nowrap>'.$content.'</td><td valign=top align=right nowrap>'.$menu.'</td></tr>
		</table>';
	}
	// MAKE url for storing
	function makeShortcutUrl($gvList,$setList)	{
		global $HTTP_GET_VARS;
		$storeArray = array_merge(
			t3lib_div::compileSelectedGetVarsFromArray($gvList,$HTTP_GET_VARS),
			array("SET"=>t3lib_div::compileSelectedGetVarsFromArray($setList,$GLOBALS["SOBE"]->MOD_SETTINGS))
		);
		$storeUrl = t3lib_div::implodeArrayForUrl("",$storeArray);
		return $storeUrl;
	}
	function makeShortcutIcon($gvList,$setList,$modName,$motherModName="")	{
		$backPath=$this->backPath;
		$storeUrl=$this->makeShortcutUrl($gvList,$setList);
		$pathInfo = parse_url(getenv("REQUEST_URI"));
		
		if (!strcmp($motherModName,"1"))	{
			$mMN="&motherModName='+top.currentModuleLoaded+'";
		} elseif ($motherModName)	{
			$mMN='&motherModName='.rawurlencode($motherModName);
		} else $mMN="";
		
		$sIcon = '<a href="#" onClick="if (top.shortcutFrame && confirm(unescape(\''.rawurlencode($GLOBALS["LANG"]->php3Lang["labels"]["makeShortcut"]).'\'))){top.shortcutFrame.document.location=\''.$backPath.'alt_shortcut.php?modName='.rawurlencode($modName).
			'&URL='.rawurlencode($pathInfo["path"]."?".$storeUrl).$mMN.'\';}return false;">'.
			'<img src="'.$backPath.'gfx/shortcut.gif" width="14" height="14" border="0"'.t3lib_BEfunc::titleAttrib($GLOBALS["LANG"]->php3Lang["labels"]["makeShortcut"]).'></a>';
		return $sIcon;
	}
	function menuTable($arr1,$arr2=array(), $arr3=array())	{
		$rows = max(array(count($arr1),count($arr2),count($arr3)));
		
		$menu='
		<table border=0 cellpadding=0 cellspacing=0>';
		for($a=0;$a<$rows;$a++)	{
			$menu.='<tr>';
			$cls=array();
			$valign="middle";
			$cls[]='<td valign='.$valign.'>'.$arr1[$a][0].'&nbsp;</td><td>'.$arr1[$a][1].'</td>';
			if (count($arr2))	{
				$cls[]='<td valign='.$valign.'>'.$arr2[$a][0].'&nbsp;</td><td>'.$arr2[$a][1].'</td>';
				if (count($arr3))	{
					$cls[]='<td valign='.$valign.'>'.$arr3[$a][0].'&nbsp;</td><td>'.$arr3[$a][1].'</td>';
				}
			}
			$menu.=implode($cls,'<td>&nbsp;&nbsp;</td>');
			$menu.='</tr>';
		}
		$menu.='
		</table>
		';
		return $menu;
	}
	function clearCacheMenu($id,$addSaveOptions=0)	{
		global $BE_USER;
		$opt=$addOptions;
		if ($addSaveOptions)	{
			$opt[]='<option value="">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["menu"]).'</option>';
			$opt[]='<option value="TBE_EDITOR_checkAndDoSubmit(1);">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["saveDoc"]).'</option>';
			$opt[]='<option value="document.editform.closeDoc.value=-2; TBE_EDITOR_checkAndDoSubmit(1);">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["saveCloseDoc"]).'</option>';
			if ($BE_USER->uc["allSaveFunctions"])	$opt[]='<option value="document.editform.closeDoc.value=-3; TBE_EDITOR_checkAndDoSubmit(1);">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["saveCloseAllDocs"]).'</option>';
			$opt[]='<option value="document.editform.closeDoc.value=2; document.editform.submit();">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["closeDoc"]).'</option>';
			$opt[]='<option value="document.editform.closeDoc.value=3; document.editform.submit();">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["closeAllDocs"]).'</option>';
			$opt[]='<option value=""></option>';
		}
		$opt[]='<option value="">[ '.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["clearCache_clearCache"]).' ]</option>';
		if ($id) $opt[]='<option value="'.$id.'">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["clearCache_thisPage"]).'</option>';
		if ($BE_USER->isAdmin() || $BE_USER->getTSConfigVal("options.clearCache.pages")) $opt[]='<option value="pages">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["clearCache_pages"]).'</option>';
		if ($BE_USER->isAdmin() || $BE_USER->getTSConfigVal("options.clearCache.all")) $opt[]='<option value="all">'.htmlspecialchars($GLOBALS["LANG"]->mainLang["rm"]["clearCache_all"]).'</option>';
		$af_content = '<select name="cacheCmd" onChange="
			if (!this.options[this.selectedIndex].value) {
				this.selectedIndex=0;
			} else if (this.options[this.selectedIndex].value.indexOf(\';\')!=-1) {
				eval(this.options[this.selectedIndex].value);
			}else{
				document.location=\''.$this->backPath.'tce_db.php?vC='.$BE_USER->veriCode().'&redirect='.rawurlencode(getenv("REQUEST_URI")).'&cacheCmd=\'+this.options[this.selectedIndex].value;
			}">'.implode("",$opt).'</select>';
		if (count($opt)>2)	{
			return $af_content;
		}
	}

	// ****************
	// Date formatting
	// ****************
	function formatTime($tstamp,$type)	{
		// Returns a formatted string of $tstamp
		switch($type)	{
				// HH:MM
			case 1: return date("H:i",$tstamp); break;		
				// DD-MM-YY
			case 10: return date("d-m-y",$tstamp); break;		
		}
	}
	function viewPageIcon($id,$backPath,$addParams='hspace=3')	{
		global $BE_USER;
		if ($BE_USER->check("modules","web_list"))	$str.= '<a href="'.$backPath.'db_list.php?AB=1&id='.$id.'&returnUrl='.rawurlencode(getenv("REQUEST_URI")).'"><img src="'.$backPath.'gfx/list.gif" width="11" height="11" vspace=2 border="0" title="'.$GLOBALS["LANG"]->php3Lang["labels"]["showList"].'"'.($addParams?" ".trim($addParams):"").'></a>';
		$str.= '<a href="#" onClick="'.t3lib_BEfunc::viewOnClick($id,$backPath,t3lib_BEfunc::BEgetRootLine($id)).'"><img src="'.$backPath.'gfx/zoom.gif" width="12" height="12" border="0" title="'.$GLOBALS["LANG"]->php3Lang["labels"]["showPage"].'"'.($addParams?" ".trim($addParams):"").' hspace=2></a>';	
		return $str;
	}
	function icons($type)	{
		switch($type)	{
			case "3":
				$icon = 'gfx/icon_fatalerror.gif';
			break;
			case "2":
				$icon = 'gfx/icon_warning.gif';
			break;
			case "1":
				$icon = 'gfx/icon_note.gif';
			break;
			case "-1":
				$icon = 'gfx/icon_ok.gif';
			break;
			default:
			break;
		}
		if ($icon)	{
			return '<img src="'.$this->backPath.$icon.'" width=18 height=16 align=absmiddle>';
		} 
	}
	
	function issueCommand($params,$rUrl="")	{
		$rUrl = $rUrl ? $rUrl : getenv("REQUEST_URI");
		return $this->backPath.'tce_db.php?'.$params.'&redirect='.($rUrl==-1?"'+T3_THIS_LOCATION+'":rawurlencode($rUrl))."&vC=".rawurlencode($GLOBALS["BE_USER"]->veriCode())."&prErr=1&uPT=1";
	}
	function redirectUrls($thisLocation="")	{
		$thisLocation = $thisLocation?$thisLocation:t3lib_div::linkThisScript(
		array(
			"CB"=>"",
			"SET"=>"",
			"cmd" => "",
			"popViewId"=>""
		));
		
		$out ="
	var T3_RETURN_URL = '".str_replace("%20","",rawurlencode(t3lib_div::GPvar("returnUrl")))."';
	var T3_THIS_LOCATION = '".str_replace("%20","",rawurlencode($thisLocation))."';
		";
		return $out;
	}
	function isCMlayers()	{
		return !$GLOBALS["BE_USER"]->uc["disableCMlayers"] && $GLOBALS["CLIENT"]["FORMSTYLE"] && $GLOBALS["CLIENT"]["SYSTEM"]!="mac";
	}
	function getContextMenuCode()	{
		if ($this->isCMlayers())	{
		$content='
		<script>
			var GLV_gap=10;
			var GLV_curLayerX=0;
			var GLV_curLayerY=0;
			var GLV_curLayerWidth=0;
			var GLV_curLayerHeight=0;
			var GLV_x=0;
			var GLV_y=0;
			var layerObj="";
			var layerObjCss="";
			
				//browsercheck...
			function GL_checkBrowser(){
				this.dom= (document.getElementById);
				this.op=  (navigator.userAgent.indexOf("Opera")>-1);
				this.konq=  (navigator.userAgent.indexOf("Konq")>-1);
				this.ie4= (document.all && !this.dom && !this.op && !this.konq);
				this.ie5= (document.all && this.dom && !this.op && !this.konq);
				this.ns4= (document.layers && !this.dom && !this.konq);
				this.ns5= (!document.all && this.dom && !this.op && !this.konq);
				this.ns6= (this.ns5);
				this.bw=  (this.ie4 || this.ie5 || this.ns4 || this.ns6 || this.op || this.konq);
				return this;
			}
			bw= new GL_checkBrowser();	
			
			function GL_getObj(obj){
				nest="";
				this.el= bw.ie4?document.all[obj]:bw.ns4?eval(nest+"document."+obj):document.getElementById(obj);	
			   	this.css= bw.ns4?this.el:this.el.style;
				this.ref= bw.ns4?this.el.document:document;		
				this.x= (bw.ns4||bw.op)?this.css.left:this.el.offsetLeft;
				this.y= (bw.ns4||bw.op)?this.css.top:this.el.offsetTop;
				this.height= (bw.ie4||bw.ie5||bw.ns6||this.konq)?this.el.offsetHeight:bw.ns4?this.ref.height:bw.op?this.css.pixelHeight:0;
				this.width= (bw.ie4||bw.ie5||bw.ns6||this.konq)?this.el.offsetWidth:bw.ns4?this.ref.width:bw.op?this.css.pixelWidth:0;
				return this;
			}
			function GL_getObjCss(obj){								
				return bw.dom? document.getElementById(obj).style:bw.ie4?document.all[obj].style:bw.ns4?document.layers[obj]:0;
			}
			function GL_getMouse(event) {
				if (layerObj)	{
					GLV_x= (bw.ns4||bw.ns5)?event.pageX:(bw.ie4||bw.op)?event.clientX:(event.clientX-2)+document.body.scrollLeft;
					GLV_y= (bw.ns4||bw.ns5)?event.pageY:(bw.ie4||bw.op)?event.clientY:(event.clientY-2)+document.body.scrollTop;
	
				//	status = (GLV_x+GLV_gap-GLV_curLayerX) + " | " + (GLV_y+GLV_gap-GLV_curLayerY);
					if (layerObjCss.visibility=="visible")	{
						if (GLV_x+GLV_gap-GLV_curLayerX <0 || GLV_y+GLV_gap-GLV_curLayerY <0 || GLV_curLayerX+GLV_curLayerWidth+GLV_gap-GLV_x <0 || GLV_curLayerY+GLV_curLayerHeight+GLV_gap-GLV_y <0)	{
							hideEmpty();
						}
					}
				}
			}
			
			function setLayerObj(html)	{
				if (layerObj)	{
					layerObj.el.innerHTML = html;
					layerObj.height= (bw.ie4||bw.ie5||bw.ns6||bw.konq)?this.el.offsetHeight:bw.ns4?this.ref.height:bw.op?this.css.pixelHeight:0;
					layerObj.width= (bw.ie4||bw.ie5||bw.ns6||bw.konq)?this.el.offsetWidth:bw.ns4?this.ref.width:bw.op?this.css.pixelWidth:0;
				
					layerObjCss.left = GLV_curLayerX = GLV_x;
					layerObjCss.top = GLV_curLayerY = GLV_y;
					layerObjCss.visibility = "visible";
					GLV_curLayerWidth = layerObj.width;
					GLV_curLayerHeight = layerObj.height;
				}
			}
			function hideEmpty()	{
				layerObjCss.visibility = "hidden";
				layerObj.el.innerHTML = "";
				return false;
			}
			function debugObj(obj,name)	{
				var acc;
				for (i in obj) {if (obj[i])	{acc+=i+":  "+obj[i]+"\n";}}			  
				alert("Object: "+name+"\n\n"+acc);
			}
			function initLayer(){
				if (document.all)   {
					window.onmousemove=GL_getMouse;
				}
				layerObj = GL_getObj("contextMenu");
				layerObjCss = GL_getObjCss("contextMenu");
			}
		</script>		
		';
		return array($content,' onmousemove="GL_getMouse(event);" onload="initLayer();"','<DIV ID="contextMenu" style="z-index:1; position:absolute;visibility:hidden"></DIV>');
		} else return array("","","");
	}
}





/***************************************************************

bigDoc:

Used to print bigDoc's (large documents)
The functions tells a lot about themselfes so study...


A typical use of an instance of this class:

$content.=$SOBE->doc->startPage("Title");
$content.=$SOBE->doc->header("Header");
$content.=$SOBE->doc->spacer(5);
$content.=$SOBE->doc->section("HeadLine:","The content");
$content.=$SOBE->doc->divider(3);

****************************************************************/
class bigDoc extends template {
	var $sectionFlag = 0;
	var $form="";

	function docBodyTagBegin()	{
		if ($this->noDocBackground)	return $this->docPlainBodyTag();
		return'<BODY'.$this->bodyTagAdditions.' bgcolor="'.$this->bgColor.'" background="'.$this->backPath.'gfx/docback.gif" marginwidth="'.$this->bodyTagMargins["x"].'" marginheight="'.$this->bodyTagMargins["y"].'" topMargin="'.$this->bodyTagMargins["y"].'" leftMargin="'.$this->bodyTagMargins["x"].'" link="black" alink="gray" vlink="black">'.$this->form.'<IMG src="'.$this->backPath.'gfx/doctop.gif" width="605" height="15"><BR>';
	}
	function sectionBegin()	{
		if (!$this->sectionFlag)	{
			$this->sectionFlag=1;
			$str='<TABLE border="0" cellspacing="0" cellpadding="0" width="3">';
			$str.='<TR><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="56" height="1"></TD><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="6" height="1"></TD><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="230" height="1"></TD></TR>';
			return $str;
		} else return '';
	}
	function sectionEnd()	{
		if ($this->sectionFlag)	{
			$this->sectionFlag=0;
			return '</TABLE>';
		} else return '';
	}
	function header($text)	{
		$str='<TABLE border="0" cellpadding="0" cellspacing="0" width="100"><TR><TD><IMG src="'.$this->backPath.'clear.gif" width="125" height="1"></TD><TD nowrap align="center" bgcolor="'.$this->bgColor2.'"><b>'.$this->fontWrap($text).'</b><BR><IMG src="'.$this->backPath.'clear.gif" width="470" height="1"></TD></TR></TABLE>';
		return $this->sectionEnd().$str;
	}
	function divider($dist)	{
		$str='<IMG src="'.$this->backPath.'gfx/stiblet.gif" width="605" height="1"'.($dist? ' vspace="'.$dist.'"':'').'><BR>';
		return $this->sectionEnd().$str;
	}
	function divider2($dist)	{
		return $this->section('','<img src="'.$this->backPath.'gfx/stiblet_mini.gif" width=460 height=1'.($dist? ' vspace="'.$dist.'"':'').'>');
	}
	function spacer($dist)	{
		if ($dist>0)	{
			return $this->section('','<IMG src="'.$this->backPath.'clear.gif" width="1" height="'.$dist.'">');
		}
	}
	function middle()	{
		$str=$this->noDocBackground?'<BR>':'<IMG src="'.$this->backPath.'gfx/docmiddle.gif" width="605" height="20"><BR>';
		return $this->sectionEnd().$str;
	}
	function section($label,$text)	{
		$str='<TR><TD align="right" valign="top">'.$this->fontWrap('<FONT color="#666666"><B>'.$label.'</B></FONT>').'</TD><TD></TD><TD valign="top">'.$this->fontWrap($text).'</TD></TR>';
		return $this->sectionBegin().$str;
	}
	function sectionH($label)	{
		$str='<TR><TD colspan=2></TD><TD valign="top">'.$this->tblHeader($label).'</TD></TR>';
		return $this->sectionBegin().$str;
	}
}




// *****************
//  noDoc
// *****************
class noDoc extends template {
	var $sectionFlag = 0;
	var $form="";
	var $halfWidth=370;
	var $leftMargin=3;

	function docBodyTagBegin()	{
		return $this->docPlainBodyTag();
	}
	function sectionBegin()	{
		if (!$this->sectionFlag)	{
			$this->sectionFlag=1;
			$str='<TABLE border="0" cellspacing="0" cellpadding="0" width="3">';
			$str.='<TR><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="'.$this->leftMargin.'" height="1"></TD><TD><IMG src="'.$this->backPath.'clear.gif" width="'.($this->halfWidth*2).'" height="1"></TD></TR>';
			return $str;
		} else return '';
	}
	function sectionEnd()	{
		if ($this->sectionFlag)	{
			$this->sectionFlag=0;
			return '</TABLE>';
		} else return '';
	}
	function header($text)	{
		$str='<TABLE border="0" cellpadding="0" cellspacing="0" width="100"><TR><TD><IMG src="'.$this->backPath.'clear.gif" hspace="'.$this->leftMargin.'" width="1" height="1"></TD><TD nowrap align="center" bgcolor="'.$this->bgColor2.'"><b>'.$this->fontWrap($text).'</b><BR><IMG src="'.$this->backPath.'clear.gif" width="'.($this->halfWidth*2).'" height="1"></TD></TR></TABLE>';
		return $this->sectionEnd().$str;
	}
	function divider($dist)	{
		$str='<IMG src="'.$this->backPath.'gfx/stiblet_nodoc.gif" width="747" height="1"'.($dist? ' vspace="'.$dist.'"':'').'><BR>';
		return $this->sectionEnd().$str;
	}
	function divider2($dist)	{
		return $this->section('','<img src="'.$this->backPath.'gfx/stiblet_mini.gif" width=460 height=1'.($dist? ' vspace="'.$dist.'"':'').'>');
	}
	function spacer($dist)	{
		if ($dist>0)	{
			return $this->section('','<IMG src="'.$this->backPath.'clear.gif" width="1" height="'.$dist.'">');
		}
	}
	function middle()	{
		$str='<BR>';
		return $this->sectionEnd().$str;
	}
	function section($label,$text,$nostrtoupper=0,$sH=0,$type=0)	{
		if ($sH&&$label)	$str.=$this->sectionH($this->icons($type).($nostrtoupper?$label:t3lib_div::danish_strtoupper($label)));
		$str.='<TR><TD></TD><TD valign="top">';
		if (!$sH&&$label)	{
			$str.= $this->fontWrap('<FONT color="#333333"><B>'.$this->icons($type).($nostrtoupper?$label:t3lib_div::danish_strtoupper($label)).'</B></FONT>').'<BR><IMG src="'.$this->backPath.'clear.gif" width="1" height="4"><BR>';
		}
		$str.=$this->fontWrap($text).'</TD></TR>';
		return $this->sectionBegin().$str;
	}
}





// *****************
//  smallDoc
// *****************
class smallDoc extends template {
	var $sectionFlag = 0;
	var $form="";

	function docBodyTagBegin()	{
		if ($this->noDocBackground)	return $this->docPlainBodyTag();
		return'<BODY'.$this->bodyTagAdditions.' bgcolor="'.$this->bgColor.'" background="'.$this->backPath.'gfx/docback_mini.gif" marginwidth="'.$this->bodyTagMargins["x"].'" marginheight="'.$this->bodyTagMargins["y"].'" topMargin="'.$this->bodyTagMargins["y"].'" leftMargin="'.$this->bodyTagMargins["x"].'" link="black" alink="gray" vlink="black">'.$this->form.'<IMG src="'.$this->backPath.'gfx/doctop_mini.gif" width="383" height="14"><BR>';
	}
	function sectionBegin()	{
		if (!$this->sectionFlag)	{
			$this->sectionFlag=1;
			$str='<TABLE border="0" cellspacing="0" cellpadding="0" width="3">';
			$str.='<TR><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="'.$this->lMarg.'" height="1"></TD><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="174" height="1"></TD></TR>';
			return $str;
		} else return '';
	}
	function sectionEnd()	{
		if ($this->sectionFlag)	{
			$this->sectionFlag=0;
			return '</TABLE>';
		} else return '';
	}
	function header($text)	{
		$str='<TABLE border="0" cellpadding="0" cellspacing="0" width="100"><TR><TD><IMG src="'.$this->backPath.'clear.gif" width="'.($this->lMarg*2).'" height="1"></TD><TD nowrap align="center" bgcolor="'.$this->bgColor2.'"><b>'.$this->fontWrap($text).'</b><BR><IMG src="'.$this->backPath.'clear.gif" width="350" height="1"></TD></TR></TABLE>';
		return $this->sectionEnd().$str;
	}
	function divider($dist)	{
		$str='<IMG src="'.$this->backPath.'gfx/stiblet_minidoc.gif" width="383" height="1"'.($dist? ' vspace="'.$dist.'"':'').'><BR>';
		return $this->sectionEnd().$str;
	}
	function divider2($dist)	{
		return $this->section('','<img src="'.$this->backPath.'gfx/stiblet_minidoc2.gif" width=348 height=1'.($dist? ' vspace="'.$dist.'"':'').'>');
	}
	function spacer($dist)	{
		if ($dist>0)	{
			return $this->section('','<IMG src="'.$this->backPath.'clear.gif" width="1" height="'.$dist.'">');
		}
	}
	function middle()	{
		$str=$this->noDocBackground?'<BR>':'<IMG src="'.$this->backPath.'gfx/docmiddle_mini.gif" width="383" height="20"><BR>';
		return $this->sectionEnd().$str;
	}
	function section($label,$text,$nostrtoupper=0,$sH=0,$type=0)	{
		if ($sH&&$label)	$str.=$this->sectionH($this->icons($type).($nostrtoupper?$label:t3lib_div::danish_strtoupper($label)));
		$str.='<TR><TD></TD><TD valign="top">';
		if (!$sH&&$label)	{
			$str.= $this->fontWrap('<FONT color="#333333"><B>'.$this->icons($type).($nostrtoupper?$label:t3lib_div::danish_strtoupper($label)).'</B></FONT>').'<BR><IMG src="'.$this->backPath.'clear.gif" width="1" height="4"><BR>';
		}
		$str.=$this->fontWrap($text).'</TD></TR>';
		return $this->sectionBegin().$str;
	}
}



// *****************
//  mediumDoc
// *****************
class mediumDoc extends template {
	var $sectionFlag = 0;
	var $form="";
	var $hW = 470;
	var $halfWidth=234;

	function docBodyTagBegin()	{
		if ($this->noDocBackground)	return $this->docPlainBodyTag();
		return '<BODY'.$this->bodyTagAdditions.' bgcolor="'.$this->bgColor.'" background="'.$this->backPath.'gfx/docback_medium.gif" marginwidth="'.$this->bodyTagMargins["x"].'" marginheight="'.$this->bodyTagMargins["y"].'" topMargin="'.$this->bodyTagMargins["y"].'" leftMargin="'.$this->bodyTagMargins["x"].'" link="black" alink="gray" vlink="black">'.$this->form.'<IMG src="'.$this->backPath.'gfx/doctop_medium.gif" width="503" height="14"><BR>';
	}
	function sectionBegin()	{
		if (!$this->sectionFlag)	{
			$this->sectionFlag=1;
			$str='<TABLE border="0" cellspacing="0" cellpadding="0" width="3">';
			$str.='<TR><TD><IMG src="'.$this->backPath.'clear.gif" width="1" hspace="'.$this->lMarg.'" height="1"></TD><TD><IMG src="'.$this->backPath.'clear.gif" width="'.($this->halfWidth*2).'" height="1"></TD></TR>';
			return $str;
		} else return '';
	}
	function sectionEnd()	{
		if ($this->sectionFlag)	{
			$this->sectionFlag=0;
			return '</TABLE>';
		} else return '';
	}
	function header($text)	{
		$str='<TABLE border="0" cellpadding="0" cellspacing="0" width="100"><TR><TD><IMG src="'.$this->backPath.'clear.gif" width="'.($this->lMarg*2).'" height="1"></TD><TD nowrap align="center" bgcolor="'.$this->bgColor2.'"><b>'.$this->fontWrap($text).'</b><BR><IMG src="'.$this->backPath.'clear.gif" width="'.$this->hW.'" height="1"></TD></TR></TABLE>';
		return $this->sectionEnd().$str;
	}
	function divider($dist)	{
		$str='<IMG src="'.$this->backPath.'gfx/stiblet_medium.gif" width="468" hspace=4 height="1"'.($dist? ' vspace="'.$dist.'"':'').'><BR>';
		return $this->sectionEnd().$str;
	}
	function divider2($dist)	{
		return $this->section('','<img src="'.$this->backPath.'gfx/stiblet_medium2.gif" width=468 height=1'.($dist? ' vspace="'.$dist.'"':'').'>');
	}
	function spacer($dist)	{
		if ($dist>0)	{
			return $this->section('','<IMG src="'.$this->backPath.'clear.gif" width="1" height="'.$dist.'">');
		}
	}
	function middle()	{
		$str=$this->noDocBackground?'<BR>':'<IMG src="'.$this->backPath.'gfx/docmiddle_medium.gif" width="503" height="20"><BR>';
		return $this->sectionEnd().$str;
	}
	function section($label,$text,$nostrtoupper=0,$sH=0,$type=0)	{
		if ($sH&&$label)	$str.=$this->sectionH($this->icons($type).($nostrtoupper?$label:t3lib_div::danish_strtoupper($label)));
		$str.='<TR><TD></TD><TD valign="top">';
		if (!$sH&&$label)	{
			$str.=$this->fontWrap('<FONT color="#333333"><B>'.$this->icons($type).($nostrtoupper?$label:t3lib_div::danish_strtoupper($label)).'</B></FONT>').'<BR><IMG src="'.$this->backPath.'clear.gif" width="1" height="4"><BR>';
		}
		$str.=$this->fontWrap($text).'</TD></TR>';
		return $this->sectionBegin().$str;
	}
}






/***************************************************************

iGraphics:

Used to generate the buttons, clickmenus, tabs and so on
Files are stored in $outputpath."temp/"
****************************************************************/
class iGraphics {
	var $outputpath = "";

	var $setup = Array (
		"dummy" => "gfx/clickmenu/menu_blank.gif",
		"fontfile" => "fonts/verdana.ttf",
		"fontsize" => 10,
		"RGB" => "0,0,0",			// font color
		"gray" => "204,204,204"		// Interface gray
	);
	
	function start($outputpath)	{
		if (@is_dir($outputpath))	{
			$this->outputpath = $outputpath;
		}
	}
	function recodeString($string)	{
		return $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["TTFLocaleConv"] ? recode_string($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["TTFLocaleConv"],$string) : $string;
	}
	function makeClick($val,$basefile)	{
			// Generate the graphics for a click-menu
		$name="cm_".t3lib_div::shortMD5($val).".gif";
		if ($this->outputpath && !@file_exists($this->outputpath.$name))	{
			if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"] && !$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib_png"])	{
				$im = imagecreatefromgif($this->setup[dummy]);
				$white = ImageColorAllocate($im, 255,255,255);
				$cols = explode(",",$this->setup[RGB]);
				$textColor = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
		
				if ($basefile && @is_file($basefile))	{	// This is the image from which we make this new image...
					$preimg = imagecreatefromgif($basefile);
					$olw=imagesx($preimg);
					imagecopyresized($im, $preimg, imagesx($im)-$olw-4, 0, 0, 0, $olw, 12, $olw, 12);
					ImageDestroy($preimg);
				}
	
				ImageTTFText($im, $this->setup[fontsize], 0, 0, 9, -$textColor, PATH_t3lib.$this->setup[fontfile], $this->recodeString($val));
				$this->outputGif($im, $this->outputpath.$name);
				ImageDestroy($im);
			} else {
				$name = "dummy_click.gif";				
			}
		}
		return $name;
	}
	function makePane($name,$text,$basefile)	{
			// Generate the graphics for a tab in panes
		$name="tab_".t3lib_div::shortMD5($name.$text).".gif";
		if ($this->outputpath && !@file_exists($this->outputpath.$name))	{
			if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"] && !$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib_png"])	{
				$w=0;
				$olw=0;
				$txtw=0;	// txtWidth
				$preimg="";
				if ($basefile && @is_file($basefile))	{	// This is the image from which we make this new image...
					$preimg = imagecreatefromgif($basefile);
					$olw=imagesx($preimg);
					$w+=$olw;
				}
				if ($text)	{
					$textInf=ImageTTFBBox(10, 0, PATH_t3lib.$this->setup[fontfile], $this->recodeString($text));
					$txtw=$textInf[2]-$textInf[0]+2;
					$w+=$txtw+4;
				}
				$im = imagecreate($w,12);
				$cols = explode(",",$this->setup[gray]);
				$white = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
				if ($preimg)	{
					imagecopyresized($im, $preimg, 0, 0, 0, 0, imagesx($preimg), 12, imagesx($preimg), 12);
					ImageDestroy($preimg);
				}
	
				$cols = explode(",",$this->setup[RGB]);
				$textColor = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
	
				ImageTTFText($im, $this->setup[fontsize], 0, $olw+2, 9, -$textColor, PATH_t3lib.$this->setup[fontfile], $this->recodeString($text));
				if ($this->outputpath)	{
					$this->outputGif($im, $this->outputpath.$name);
				} else {
					debug("No outputpath!!!");
				}
				ImageDestroy($im);
			} else {
				$name="dummy_pane.gif";
			}			
		}	
		$imgInfo=@getImageSize($this->outputpath.$name);
		$imgInfo["name"]=$name;
		return $imgInfo;
	}
	function makeButtons($name,$text,$basefile,$color)	{
			// Generate the graphics for a buttons
		$name="button_".t3lib_div::shortMD5($name.$text).".gif";
		if ($this->outputpath && !@file_exists($this->outputpath.$name))	{
			if ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib"] && !$GLOBALS["TYPO3_CONF_VARS"]["GFX"]["gdlib_png"])	{
				$h_off=1;
				$w_off=3;
				$h2_off=3;
				$w2_off=3;
			
				$w=0;
				$olw=0;
				$txtw=0;	// txtWidth
				$preimg="";
				if ($basefile && @is_file($basefile))	{	// This is the image from which we make this new image...
					$preimg = imagecreatefromgif($basefile);
					$olw=imagesx($preimg);
					$w+=$olw;
				}
				if ($text)	{
					$textInf=ImageTTFBBox(10, 0, PATH_t3lib.$this->setup[fontfile], $this->recodeString($text));
					$txtw=$textInf[2]-$textInf[0]+2;
					$w+=$txtw+4;
				}
				$im = imagecreate($w+$w_off+$w2_off,12+$h_off+$h2_off);
				$cols = explode(",",$color?$color:$this->setup[gray]);
				$white = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
				if ($preimg)	{
					imagecopyresized($im, $preimg, $w_off, $h_off, 0, 0, imagesx($preimg), imagesy($preimg), imagesx($preimg), imagesy($preimg));
					ImageDestroy($preimg);
				}
	
				$cols = explode(",",$this->setup[RGB]);
				$textColor = ImageColorAllocate($im, $cols[0],$cols[1],$cols[2]);
				ImageTTFText($im, $this->setup[fontsize], 0, $w_off+$olw+2, $h_off+9, -$textColor, PATH_t3lib.$this->setup[fontfile], $this->recodeString($text));
	
				$lineCol3 = ImageColorAllocate($im, 130,130,130);
				imageline($im, 0, imagesy($im)-2, imagesx($im), imagesy($im)-2, $lineCol3);
				imageline($im, imagesx($im)-2, 0, imagesx($im)-2, imagesy($im), $lineCol3);
				$lineCol2 = ImageColorAllocate($im, 255,255,255);
				imageline($im, 0, 0, imagesx($im), 0, $lineCol2);
				imageline($im, 0, 0, 0, imagesy($im), $lineCol2);
				$lineCol1 = ImageColorAllocate($im, 0,0,0);
				imageline($im, 0, imagesy($im)-1, imagesx($im), imagesy($im)-1, $lineCol1);
				imageline($im, imagesx($im)-1, 0, imagesx($im)-1, imagesy($im), $lineCol1);
				
				if ($this->outputpath)	{
					$this->outputGif($im, $this->outputpath.$name);
				} else {
					debug("No outputpath!!!");
				}
				ImageDestroy($im);
			} else {
				$name="dummy_button.gif";
			}
		}	
		$imgInfo=@getImageSize($this->outputpath.$name);
		$imgInfo["name"]=$name;
		return $imgInfo;
	}
	function outputGif($im, $name)	{
		ImageGif($im, $name);
		t3lib_div::gif_compress($name, "IM");
	}
}



if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/template.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/template.php"]);
}



// ******************************
// The main language is loaded
// ******************************
include(PATH_typo3."lang/lang.php");
$LANG = t3lib_div::makeInstance("language");
$LANG->init($BE_USER->uc["lang"]);



// ******************************
// The template is loaded
// ******************************
$TBE_TEMPLATE = t3lib_div::makeInstance("template");
$TBE_iGraphics = t3lib_div::makeInstance("iGraphics");			
$TBE_iGraphics->start(PATH_temp);

function fw($string,$red=0)	{
	if ($red)	{$string='<font color="#FF0000">'.$string.'</font>';}
	return $GLOBALS["TBE_TEMPLATE"]->fontwrap($string);
}
function dfw($string)	{
	return $GLOBALS["TBE_TEMPLATE"]->fontwrap_D($string);
}
function rfw($string)	{
	return $GLOBALS["TBE_TEMPLATE"]->fontwrap_R($string);
}
?>