<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Folder tree in alternative backend.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
$BACK_PATH="";
include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_browsetree.php");




// ***************************
// Script Classes
// ***************************
class localPageTree extends t3lib_browseTree {
	function wrapTitle($title,$v)	{
		return '<a href="#" onClick="return jumpTo(\''.rawurlencode($v["path"]).'\',this);">'.$title.'</a>';
	}
	function wrapIcon($icon,$row)	{
		$theFolderIcon = substr($icon,0,-1).' border=0>';
		if (!$this->ext_IconMode)	{
			$theFolderIcon = $GLOBALS["TBE_TEMPLATE"]->wrapClickMenuOnIcon($theFolderIcon,$row["path"],"",1,0);
		} elseif (!strcmp($this->ext_IconMode,"titlelink"))	{
			$theFolderIcon='<a href="#" onClick="return jumpTo(\''.rawurlencode($row["path"]).'\',this);">'.$theFolderIcon.'</a>';
		}
		return $theFolderIcon.$lockIcon;
	}
}
class SC_alt_file_navframe {
	var $content;
	var $foldertree;
	var $doc;	

		// Constructor:
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

			$this->foldertree = t3lib_div::makeInstance("localPageTree");
			$this->foldertree->ext_IconMode = $BE_USER->getTSConfigVal("options.folderTree.disableIconLinkToContextmenu");
			$this->foldertree->thisScript = "alt_file_navframe.php";
			
			$this->doc = t3lib_div::makeInstance("template");
			$this->doc->backPath = $BACK_PATH;
			$this->doc->JScode='';
			$currentSubScript = t3lib_div::GPvar("currentSubScript");
			$this->doc->JScode.='
<script>
	'.($currentSubScript?'top.currentSubScript=unescape("'.rawurlencode($currentSubScript).'");':'').'
	function jumpTo(id,linkObj)	{
		var theUrl = top.TS.PATH_typo3+top.currentSubScript+"?AB=1&id="+id;
		if (top.condensedMode)	{
			top.content.document.location=theUrl;
		} else {
			parent.file_list_frame.document.location=theUrl;
		}
		'.(!$CLIENT["FORMSTYLE"] ? '' : 'if (linkObj) {linkObj.blur();}').'
		return false;
	}
	
	'.(t3lib_div::GPvar("cMR")?"jumpTo(top.file_recent_id,'');":"").';
</script>	
		';

		$CMparts=$this->doc->getContextMenuCode();
		$this->doc->bodyTagAdditions = $CMparts[1];
		$this->doc->JScode.=$CMparts[0];
		$this->doc->postCode.= $CMparts[2];
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$tree=$this->foldertree->getBrowsableFolderTree();
		if ($CLIENT["BROWSER"]=="konqu")	{
				// Where <nobr> does not work, this will secure non-breaks in lines:
			$tree = '<table border=0 cellspacing=0 cellpadding=0><tr><td nowrap>'.$tree.'</td></tr></table>';
		}
		
		$this->content="";
		$this->content.=$this->doc->startPage("Filelist list");
		$this->content.=fw($tree);
		$this->content.=fw('<BR><a href="'.getenv("REQUEST_URI").'"><img src="gfx/refresh_n.gif" width="14" height="14" border="0" align=top title="'.$LANG->mainLang["labels"]["refresh"].'">&nbsp;'.htmlspecialchars($LANG->mainLang["labels"]["refresh"])."</a><BR><BR>");
	}
	function printContent()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content.= $this->doc->endPage();
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_file_navframe.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_file_navframe.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_file_navframe");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();

?>