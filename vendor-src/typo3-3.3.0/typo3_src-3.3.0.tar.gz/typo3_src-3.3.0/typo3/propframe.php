<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This is the "upper palette" that holds the document-selector and menu on the document-tab
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */






// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************







include("init.php");
include("template.php");




// ******************************
// The modules are loaded
// ******************************

include_once(PATH_t3lib."class.t3lib_loadmodules.php");
$loadModules = t3lib_div::makeInstance("t3lib_loadModules");
$loadModules->load($TBE_MODULES);





// ******************************
// Start document output
// ******************************

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<script language="javascript">
	var loading = true;
	parent.writeStyleSheet(document);		// May result in a "Out of memory"-error...


	var theBrowser = parent.theBrowser;
	function dom_getObj(obj){
		this.el= theBrowser.ie4?document.all[obj]:theBrowser.ns4?document[obj]:document.getElementById(obj);	
	   	this.css= theBrowser.ns4?this.el:this.el.style;
		this.ref= theBrowser.ns4?this.el.document:document;		
		this.x= (theBrowser.ns4||theBrowser.op)?this.css.left:this.el.offsetLeft;
		this.y= (theBrowser.ns4||theBrowser.op)?this.css.top:this.el.offsetTop;
		this.height= (theBrowser.ie4||theBrowser.ie5||theBrowser.ns6)?this.el.offsetHeight:theBrowser.ns4?this.ref.height:theBrowser.op?this.css.pixelHeight:0;
		this.width= (theBrowser.ie4||theBrowser.ie5||theBrowser.ns6)?this.el.offsetWidth:theBrowser.ns4?this.ref.width:theBrowser.op?this.css.pixelWidth:0;
		return this;
	}
</script>
	<title>The Property Menu</title>
</head>
<BODY background="gfx/editwin_pm_back.gif" LINK="#000000" marginwidth="0" marginheight="0">
<DIV ID='edit' STYLE="POSITION: absolute; Z-INDEX: 1; VISIBILITY: hidden; TOP: 3px; LEFT: 6px;">
	<script language="javascript">
		parent.writeLines(document, parent.writeFrameContent("editMenu"));
	</script>
</DIV>

<?php

$a=2;


// ******************************
// Make module layers
// ******************************


if (is_array($loadModules->modules))	{
	reset ($loadModules->modules);
	while(list($ref,$data)=each($loadModules->modules))	{
		$subref="";
		if (is_array($data) && $data[cpalScript])	{
			echo "
<DIV ID='modLayer".$ref."' STYLE=\"POSITION: absolute; Z-INDEX: ".$a."; VISIBILITY: hidden; TOP: 5px; LEFT: 5px;\">
";
			include ($data[cpalScript]);
			echo "
</DIV>
";
			$a++;
		}
			
			// Submodules are also looked at...
		if (is_array($data) && is_array($data[sub]) && count($data[sub]))	{
			reset($data[sub]);
			while(list($subref,$subdata)=each($data[sub]))	{
				if (is_array($subdata) && $subdata[cpalScript])	{
					echo "
<DIV ID='modLayer".$ref."SUB".$subref."' STYLE=\"POSITION: absolute; Z-INDEX: ".$a."; VISIBILITY: hidden; TOP: 5px; LEFT: 5px;\">
";
					include ($subdata[cpalScript]);
					echo "
</DIV>
";
					$a++;
				}
			}
		}
	}
}
?>
<script language="javascript">

	// *** Layercontrol
	function theLayers()	{
		this.theLayers = new Array();
	
		this.theLayers[1]='edit';
		this.theLayersCount=1;
<?php
// *********************
// Make module layers
// *********************

if (is_array($loadModules->modules))	{
	reset ($loadModules->modules);
	while(list($ref,$data)=each($loadModules->modules))	{
		if (is_array($data) && $data[cpalScript])	{
			echo "
		this.theLayersCount++;
		this.theLayers[this.theLayersCount]='modLayer".$ref."';";
		}
		if (is_array($data[sub]) && count($data[sub]))	{
			reset($data[sub]);
			while(list($subref,$subdata)=each($data[sub]))	{
				if (is_array($subdata) && $subdata[cpalScript])	{
					echo "
	this.theLayersCount++;
	this.theLayers[this.theLayersCount]='modLayer".$ref."SUB".$subref."';";
				}
			}
		}
	}
}


?>
		
		this.hide = hideAll;
		this.show = show;
	}
	function hideAll()	{
		for(var a=1; a<=this.theLayersCount; a++)	{
			layerCss = parent.dom_getObj(this.theLayers[a],document).css;
			layerCss.visibility = "hidden";
		}
	}
	function show(theLayer)	{
			layerCss = parent.dom_getObj(theLayer,document).css;
			layerCss.visibility = "visible";
	}
	layerControl = new theLayers;

	// *** Switch Document (editWin)
	function swDoc(element)	{
		theVal = element.options[element.selectedIndex].value;
		parent.switchDocument(theVal);
	}

	parent.buttons['pilleft'].init();
	parent.buttons['pilright'].init();
	parent.busy.set(0, 'propframe');
</script>
</body>
</html>
