<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Alternative TBE: Main menu
 *
 * This is an alternative Typo3 Backend interface using the same modules, but designed to work with less capable browsers than MSIE.
 * This is probably in pre-alpha test as this time... so dont expect anything useful.
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_loadmodules.php");
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
include_once("class.alt_menu_functions.inc");


// ***************************
// Script Classes
// ***************************
class SC_alt_menu_sel {
	var $content;
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_MODULES,$TBE_TEMPLATE;
		
		$loadModules = t3lib_div::makeInstance("t3lib_loadModules");
		$loadModules->load($TBE_MODULES);

		$this->content.='
<!DOCTYPE html public "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
'.$TBE_TEMPLATE->docStyle().'
<TITLE>menu</TITLE>
<META name="GENERATOR" content="Typo '.$TYPO_VERSION.' by www.typo3.com, (c) Kasper Sk�rh�j 1998-2002">
'.$TBE_TEMPLATE->initCharset().'
</HEAD>
<BODY vlink=black alink=black link=black bgColor="'.$TBE_TEMPLATE->bgColor2.'"><form action=""><img src="clear.gif" width=1 height=5><BR>
';

		$AB=1;
		$alt_menuObj = t3lib_div::makeInstance("alt_menu_functions");
		$this->content.=$alt_menuObj->topMenu($loadModules->modules,0,"",2);
		$this->content.='</form>
</BODY>
</HTML>';
	}
	function printContent()	{
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_menu_sel.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_menu_sel.php"]);
}











// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_menu_sel");
$SOBE->main();
$SOBE->printContent();
?>
