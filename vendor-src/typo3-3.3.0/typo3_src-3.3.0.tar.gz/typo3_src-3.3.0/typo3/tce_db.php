<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TCE (Typo Core Engine) for database handling
 *
 * This script if the gateway to tce_main.php that manipulates all information in the database!!
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
/***************************************************************

SYNTAX:
See document "Inside Typo"

****************************************************************/


include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_tcemain.php");



// ***************************
// Script Classes
// ***************************
class SC_tce_db {
	var $include_once=array();
	var $tce;
	var $CB;
	
	var $flags;
	var $data;
	var $cmd;
	var $mirror;
	var $cacheCmd;
	var $redirect;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// ***************************
		// Registering Incoming data
		// ***************************
		$this->flags = t3lib_div::GPvar("flags");
		$this->data = t3lib_div::GPvar("data");
		$this->cmd = t3lib_div::GPvar("cmd");
		$this->mirror = t3lib_div::GPvar("mirror");
		$this->cacheCmd = t3lib_div::GPvar("cacheCmd");
		$this->redirect = t3lib_div::GPvar("redirect");
//		t3lib_div::setGPvars("flags,data,cmd,mirror,cacheCmd,redirect");
		
		
		// ***************************
		// Creating backend object
		// ***************************
		$this->tce = t3lib_div::makeInstance("t3lib_TCEmain");
		
		
		// *********************************
		// configuring based on user prefs.
		// *********************************
		if ($BE_USER->uc["recursiveDelete"])	{
			$this->tce->deleteTree = 1;	// True if the delete Recursive flag is set.
		}
		if ($BE_USER->uc["copyLevels"])	{
			$this->tce->copyTree = t3lib_div::intInRange($BE_USER->uc["copyLevels"],0,100);	// Set to number of page-levels to copy.
		}
		if ($BE_USER->uc["neverHideAtCopy"])	{
			$this->tce->neverHideAtCopy = 1;
		}
		$TCAdefaultOverride = $BE_USER->getTSConfigProp("TCAdefaults");
		if (is_array($TCAdefaultOverride))	{
			$this->tce->setDefaultsFromUserTS($TCAdefaultOverride);
		}
		
		// ******************
		// reverse order.
		// ******************
		if ($this->flags["reverseOrder"])	{
			$this->tce->reverseOrder=1;
		}
		
		$this->tce->disableRTE = t3lib_div::GPvar("_disableRTE");

	
		$this->CB = t3lib_div::GPvar("CB");
		if (is_array($this->CB))	{
			$this->include_once[]=PATH_t3lib."class.t3lib_clipboard.php";
		}
	}
	function initClipboard()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// ******************
		// Clipboard pasting:
		// ******************
		if (is_array($this->CB))	{
			$clipObj = t3lib_div::makeInstance("t3lib_clipboard");
			$clipObj->initializeClipboard();
			if ($this->CB["paste"])	{
				$clipObj->setCurrentPad($this->CB["pad"]);
				$this->cmd = $clipObj->makePasteCmdArray($this->CB["paste"],$this->cmd);
			}
			if ($this->CB["delete"])	{
				$clipObj->setCurrentPad($this->CB["pad"]);
				$this->cmd = $clipObj->makeDeleteCmdArray($this->cmd);
			}
		}
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// *********************************
		// Initializing
		// *********************************
		//$this->tce->debug=1;
		//debug(t3lib_div::GPvar("vC"));
		
		
		if ($this->tce->debug) {
			echo '<a href="'.$this->redirect.'"><b>--redirect--</b></a><br>';
			echo $GLOBALS["PHP_SELF"];
		}
		$this->tce->start($this->data,$this->cmd);
		if (is_array($this->mirror))	{$this->tce->setMirror($this->mirror);}
		
		
		// ***************************
		// Checking referer / executing
		// ***************************
		$refInfo=parse_url(getenv("HTTP_REFERER"));
		list($httpHost) = explode(":",getenv("HTTP_HOST"));
		if ($httpHost!=$refInfo["host"] && t3lib_div::GPvar("vC")!=$BE_USER->veriCode() && !$TYPO3_CONF_VARS["SYS"]["doNotCheckReferer"])	{
			$this->tce->log("",0,0,0,1,"Referer host '%s' and server host '%s' did not match and veriCode was not valid either!",1,array($refInfo["host"],$httpHost));
		} else {

//debug(array($this->data,$this->cmd));
			$this->tce->process_uploads($GLOBALS["HTTP_POST_FILES"]);
			$this->tce->process_datamap();
			$this->tce->process_cmdmap();
			
			$this->tce->clear_cacheCmd($this->cacheCmd);
			
			if($this->tce->debug) {
				echo "<b>GET-vars:<br></b>";
				t3lib_div::print_array($HTTP_GET_VARS);
				
				echo "<BR><b>POST-vars:<br></b>";
				t3lib_div::print_array($HTTP_POST_VARS);
				
				echo "<BR><b>Cookies:</b><br>";
				t3lib_div::print_array($GLOBALS["HTTP_COOKIE_VARS"]);
				echo '<a href="'.$this->redirect.'"><b>TILBAGE</b></a><br>';
			}
			
			if (t3lib_div::GPvar("uPT") && (isset($this->data["pages"])||isset($this->cmd["pages"])))	{
				t3lib_BEfunc::getSetUpdateSignal("updatePageTree");
			}
		}
		
	}
	function finish()	{
		// ***************************
		// Redirecting
		// ***************************
		if (t3lib_div::GPvar("prErr"))	{
			$this->tce->printLogErrorMessages($this->redirect);
		}
		
		// ***************************
		// Redirecting
		// ***************************
		if (!$this->redirect)	{
			$this->redirect = "status.php";
		}
		if (!$this->tce->debug) {
			Header("Location: ".$this->redirect);
		
		echo '
		<script language="javascript">
			if (confirm(\'System Error:\n\n Some error happend in tce_db.php. Continue?\'))	{
				document.location = \''.$this->redirect.'\';
			}
		</script>
		';
		}
	}	
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/tce_db.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/tce_db.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_tce_db");
$SOBE->init();

// Include files?
reset($SOBE->include_once);	
while(list(,$INC_FILE)=each($SOBE->include_once))	{include_once($INC_FILE);}

$SOBE->initClipboard();
$SOBE->main();
$SOBE->finish();
?>
