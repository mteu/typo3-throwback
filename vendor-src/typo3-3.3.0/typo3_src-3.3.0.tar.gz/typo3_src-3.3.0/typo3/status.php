<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TCE status transfer, file handling
 *
 * This script reads the sys_log table since the last known entry and updates the interface if necessary
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 





// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************









$BACK_PATH="";
include("init.php");
include ($BACK_PATH."template.php");



// ***************************
// Registering Incoming data
// ***************************
t3lib_div::setGPvars("logid,closeDocuments,JScommand");


// ***************************
// Classes and functions
// ***************************
include_once(PATH_t3lib."class.t3lib_loaddbgroup.php");
include_once(PATH_t3lib."class.t3lib_transferdata.php");

// ***************************
// Beginning status
// ***************************
$updateData = t3lib_div::makeInstance("t3lib_transferData");
$updateData->formname = "loadform";
$updateData->loading = 0;	// updating
$debug=0;

$res=mysql(TYPO3_db,"select uid from sys_log order by uid desc limit 1");		// Get latest log_id
$row=mysql_fetch_assoc($res);
$new_logid = $row["uid"];

$logid = intval($logid);
if (!$logid) {	// If no logid is given as GET-var, set logid to the latest in the log-table
	$logid=$new_logid;
}

$JS='';
$errorJS='';
$updateWin=0;
$limit=61;		// Number of log-entries to read +1

if($debug) { echo 'old logid='.$logid.' ,new logid='.$new_logid; }

$res_log=mysql(TYPO3_db,"select * from sys_log where uid > $logid AND type=1 AND userid=".$BE_USER->user["uid"]." ORDER BY uid LIMIT ".$limit);
$c=0;
while ($row=mysql_fetch_assoc($res_log)) {
	$c++;
	if ($c==$limit)		{
		$errorJS.='IMPORTANT:
There are more than '.($limit-1).' entries to read from the system log. Please reload the Typo3 Backend Interface!';
		break;
	} else {
		if ($row["error"])	{
			$log_data=unserialize($row["log_data"]);
			$errorJS.=$row[error].': '.sprintf($row["details"], $log_data[0],$log_data[1],$log_data[2],$log_data[3],$log_data[4]).chr(10);
		} else {
			if ($debug)	{	t3lib_div::print_array($row);}
	
			if ($row[tablename])	{
				$res_table = mysql(TYPO3_db,"select * from $row[tablename] where uid=$row[recuid]");
				if (mysql_num_rows($res_table))	{
					$row_table = mysql_fetch_assoc($res_table);
				} else {
					$row_table = "";
				}
			}
		
			$titleLen=intval($GLOBALS["BE_USER"]->uc[titleLen]);
			$titel_text= t3lib_div::fixed_lgd(strip_tags($row_table[$TCA[$row["tablename"]]["ctrl"]["label"]]),$titleLen);	// get the 'titel text' from the 'titel-row-name'
			if($debug) { echo '<hr>Titel: '.$titel_text.' , action='.$row["action"].' ('; }
		
			switch ($row["action"]) {
			case 1: 	// new : table, uid, pid, title, path, values, image
				if($debug) { echo 'new)'; }
				if ($row[tablename]=="pages")	{
					$thePositionPID = $row[recpid];
					$JS.='top.theMenu.aI('.$row[recuid].','.$thePositionPID.',\''.rawurlencode($titel_text).'\',\''.t3lib_BEfunc::getRecordIconAltText($row_table).'\',\''.$row_table[alias].'\',\''.t3lib_iconWorks::getIcon("pages",$row_table).'\');'."\n";
				}
				if ($row["NEWid"])	{
					$JS.='top.data.registerNewData(\''.$row[tablename].'\',\''.t3lib_div::slashJS($row["NEWid"]).'\','.intval($row["recuid"]).','.intval($row_table["pid"]).');'."\n";
				}
				// Datadel opdateres
				if ($row_table)	{
					$updateData->renderRecord($row[tablename], $row_table["uid"], $row_table["pid"], $row_table);					// Datadel opdateres
				}
				break;	
			case 2:		// update : table, uid, pid, title, path, values, image
				if($debug) { echo 'update)'; }
				if ($row[tablename]=="pages")	{
					$JS.='top.theMenu.updateItem(\''.$row[tablename].'\','.$row[recuid].',null,\''.rawurlencode($titel_text).'\',\''.t3lib_BEfunc::getRecordIconAltText($row_table).'\',\''.$row_table[alias].'\',\''.t3lib_iconWorks::getIcon("pages",$row_table).'\');'."\n";			
				}
				if ($row_table)	{
					$updateData->renderRecord($row[tablename], $row_table["uid"], $row_table["pid"], $row_table);					// Datadel opdateres
				}
				break;
			case 3:		// delete : table, uid
				if($debug) { echo 'delete)'; }
				if ($row[tablename]=="pages")	{
					$JS.='top.theMenu.deleteItem(\''.$row[tablename].'\','.$row[recuid].');'."\n";
				}
				$JS.='top.editWin.deleteDocRecord(\''.$row[tablename].'\','.$row[recuid].');'."\n";
				// Her skal der ogs� slettes data fra data-delen
				break;	
			case 4:		// move : table, uid, pid, title, path, values, image
				if($debug) { echo 'move)'; }
				if ($row[tablename]=="pages")	{
					$thePositionPID = $row[recpid];
					$JS.='top.theMenu.updateItem(\''.$row[tablename].'\','.$row[recuid].','.$thePositionPID.',\''.rawurlencode($titel_text).'\',\''.t3lib_BEfunc::getRecordIconAltText($row_table).'\',\''.$row_table[alias].'\');'."\n";
				}
				$updateWin=1;
				break;	
			}
		}	
	}
}



// ***************************
// Outputting update code
// ***************************
if ($errorJS)	{
	$JS.="alert(unescape('".rawurlencode($errorJS)."'));";
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Status script</title>
</head>
<body bgcolor="#F7F3EF">

<?php
echo $updateData->getHTMLcode();
?>

<script language="javascript">
top.logid = <?php echo $new_logid;?>;
top.busy.set(0);
top.busy.loginRefreshed();

<?php	
echo $JS;
?>

<?php
echo $updateData->getJScode();

if ($JS || $updateData->JS_code || $updateWin)	{
	echo "
top.reloadCurrentWin();";
}

if ($JScommand)	{
	echo chr(10).$JScommand;
}

if ($closeDocuments)	{
	if (!strcmp($closeDocuments,"all"))	{
?>
top.editWin.closeAll();
<?php	} else {
?>
top.editWin.closeCur();
<?php	}
}
?>

</script>

<?php if($debug) {?>
<pre>
<?php
echo $JS;
?>
</pre>
<?php }?>



</body>
</html>
<?php
if ($TYPO3_CONF_VARS["BE"]["compressionLevel"])	{
	new gzip_encode($TYPO3_CONF_VARS["BE"]["compressionLevel"]);
}
?>