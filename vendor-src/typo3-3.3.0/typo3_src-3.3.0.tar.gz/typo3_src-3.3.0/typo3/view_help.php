<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This is the frameset to the clipboard window
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


include("init.php");
include("template.php");
include("lang/LL_view_help.php");



// ***************************
// Script Classes
// ***************************
class SC_view_help {
	var $content;
	var $limitAccess;
	var $table;
	var $field;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$TCA_DESCR=t3lib_BEfunc::loadTablesDescriptions($LANG->lang!="default"?$LANG->lang:"");
		list($this->table,$this->field)=explode(".",t3lib_div::GPvar("tfID"));
		t3lib_BEfunc::loadSingleTableDescription($this->table,$LANG->lang);
		
		$this->limitAccess=1;
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_TEMPLATE;
		
		$this->content.='
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Typo 3.3 Field Help</title>
'.$TBE_TEMPLATE->docStyle().'
</head>
<BODY bgcolor="'.$TBE_TEMPLATE->bgColor.'" LINK="#000000" VLINK="#000000" ALINK="#000000" marginwidth="10" marginheight="10" topmargin="10" leftmargin="10">';

		if ($this->field=="*")	{
			t3lib_div::loadTCA($this->table);
			if (is_array($TCA_DESCR[$this->table]["columns"]) && (!$this->limitAccess || $BE_USER->check("tables_select",$this->table)))	{
				reset($TCA_DESCR[$this->table]["columns"]);
				while(list($this->field)=each($TCA_DESCR[$this->table]["columns"]))	{
					$fieldValue = $TCA[$this->table]["columns"][$this->field];
					if (!$this->limitAccess || !$fieldValue["exclude"] || $BE_USER->check("non_exclude_fields",$this->table.":".$this->field))	{
						$this->content.=$this->printItem($this->table,$this->field,1);
						$this->content.="<BR><BR><BR>";
					}
				}
			}
		} else {
			$this->content.=$this->printItem($this->table,$this->field);
			$this->content.=fw('<BR><a href="#" onClick="vHWin=window.open(\'view_help.php?tfID='.rawurlencode($this->table.".*").'&ONLY='.$LANG->lang.'\',\'fullHelpWindow\',\'width=600,scrollbars=1,status=1,menubar=1,location=1,resizable=1,toolbar=1\');vHWin.focus();return false;">'.$LANG->getLL("fullDescription").'</a>');
		}

		$this->content.='<BR><form action=""><input type="submit" value="'.$LANG->getLL("close").'" onClick="self.close(); return false;"></form>';
		$this->content.='
</body>
</html>		
		';
	}
	function printContent()	{
		echo $this->content;
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************

	function make_seeAlso($value,$anchorTable="")	{
		global $TCA,$BE_USER;
		$items = split(",|".chr(10),$value);
		reset($items);
		$lines=array();
		while(list(,$val)=each($items))	{
			$val = trim($val);
			if ($val)	{
				$iP = explode(":",$val);
				$iPUrl = t3lib_div::trimExplode("|",$val);
				if (substr($iPUrl[1],0,7)=="http://")	{
					$lines[]='<a href="'.$iPUrl[1].'" target="_blank"><em>'.$iPUrl[0].'</em></a>';
				} else {
					t3lib_div::loadTCA($iP[0]);
					if (!$this->limitAccess || ($BE_USER->check("tables_select",$iP[0]) && (!$TCA[$iP[0]]["columns"][$iP[1]]["exclude"] || $BE_USER->check("non_exclude_fields",$iP[0].":".$iP[1]))))	{
						$lines[]='<a href="'.($anchorTable&&$iP[0]==$anchorTable ? '#'.implode(".",$iP) : 'view_help.php?tfID='.implode(".",$iP).'&back='.t3lib_div::GPvar("tfID")).'">'.$GLOBALS["LANG"]->sL($TCA[$iP[0]]["ctrl"]["title"]).($iP[1]?" / ".ereg_replace(":$","",$GLOBALS["LANG"]->sL($TCA[$iP[0]]["columns"][$iP[1]]["label"])):"").'</a>';
					}
				}
			}
		}
		return implode("<BR>",$lines);
	}
	function printImage($image,$descr)	{
		if (!strstr($image,"/"))	{
			$imgFile = "t3lib/install/descr_imgs/".$image;
			$imgInfo=@getimagesize($imgFile);
			if (is_array($imgInfo))	{
				$code = '<BR><img src="'.$imgFile.'" '.$imgInfo[3].'><BR>';
				$code.= '<em>'.$descr.'</em>';
				return $code;
			}
		}
	}
	function headerLine($str,$type=0)	{
		switch($type)	{
			case 1:
				$str='<table border=1 cellpadding=0 cellspacing=0 bordercolor="'.$GLOBALS["TBE_TEMPLATE"]->bgColor5.'" width="100%" bgcolor="'.$GLOBALS["TBE_TEMPLATE"]->bgColor5.'"><tr><td>'.$str.'</td></tr></table><BR>';
			break;
			case 0:
				$str='<strong>'.t3lib_div::danish_strtoupper($str).'</strong><BR><img src="gfx/blackclear.gif" width="100%" height="1" border="0"><BR><img src=clear.gif width=1 height=4><BR>';
			break;
		}
		
		return $str;
	}
	function printItem($table,$field,$anchors=0)	{
		global $TCA_DESCR, $LANG, $TCA, $BE_USER;
		t3lib_div::loadTCA($table);
		if ($table && (!$field || is_array($TCA_DESCR[$table]["columns"][$field])))	{
			$seeAlsoRes = $this->make_seeAlso($TCA_DESCR[$table]["columns"][$field]["seeAlso"],$anchors?$table:"");
			$out= '<a name="'.$table.'.'.$field.'"></a>'.
				fw(
					$this->headerLine('<strong>'.$LANG->sL($TCA[$table]["ctrl"]["title"]).": ".($field?ereg_replace(":$","",stripslashes(trim($LANG->sL($TCA[$table]["columns"][$field]["label"])))):"").'</strong>',1).
					$TCA_DESCR[$table]["columns"][$field]["description"].
					($TCA_DESCR[$table]["columns"][$field]["details"]?'<BR><BR><BR>'.$this->headerLine($LANG->getLL("details").':').$TCA_DESCR[$table]["columns"][$field]["details"]:"").
					($TCA_DESCR[$table]["columns"][$field]["syntax"]?'<BR><BR><BR>'.$this->headerLine($LANG->getLL("syntax").':').$TCA_DESCR[$table]["columns"][$field]["syntax"]:"").
					($TCA_DESCR[$table]["columns"][$field]["image"]?'<BR>'.$this->printImage($TCA_DESCR[$table]["columns"][$field]["image"],$TCA_DESCR[$table]["columns"][$field]["image_descr"]):"").
					($TCA_DESCR[$table]["columns"][$field]["seeAlso"]&&$seeAlsoRes?'<BR><BR><BR>'.$this->headerLine($LANG->getLL("seeAlso").':').$seeAlsoRes:"").
					(t3lib_div::GPvar("back") ? '<BR><BR><strong><a href="view_help.php?tfID='.t3lib_div::GPvar("back").'">'.$LANG->getLL("goBack").'</a></strong>' : '')
				).
			'<BR>';
	
				// EDIT ICON - should be commented out this line if not under development!
//			$out.=$BE_USER->isAdmin()?'<BR><a href="#" onClick="vHWin=window.open(\'dev/dev_descriptions.php?selectKey[]='.$table.":".$field.'&ONLY='.$LANG->lang.'\',\'dev_translations_window\',\'scrollbars=1,status=1,menubar=1,location=1,resizable=1,toolbar=1\');vHWin.focus();return false;"><img src="gfx/edit2.gif" width="11" height="12" border="0" title="Edit item"></a>':'';
	
		}
		return $out;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/view_help.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/view_help.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_view_help");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>