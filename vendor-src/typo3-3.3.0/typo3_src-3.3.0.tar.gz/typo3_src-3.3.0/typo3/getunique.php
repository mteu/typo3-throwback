<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Get unique value
 *
 * This script returns a unique value for the $table/$field based on $value. 
 * If $value is unique already, $value is returned, else $value is prepended with numbers until a unique value is found
 *
 * GET_VARS:
 * $table,$field,$value
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

include("init.php");



// ***************************
// Registering Incoming data
// ***************************
t3lib_div::setGPvars("value,field,formRef,uniqueInPid");



// ***************************
// Processing
// ***************************
$oldValue = $value;
t3lib_div::loadTCA($table);
if ($TCA[$table] && isset($TCA[$table][columns][$field]))	{
	$whereAdd="";
	if (intval($uniqueInPid))	{
		$row = t3lib_BEfunc::getRecord ($table,intval($id),"pid");
		$whereAdd.=" AND pid=".intval($row["pid"]);
	}
	$whereAdd.=t3lib_BEfunc::deleteClause($table);
	
		// Query:
	$res = mysql(TYPO3_db,"select uid from $table where $field = '".addslashes($value)."' and uid != '".addslashes($id)."'".$whereAdd);
	$counter=0;
	while (mysql_num_rows($res))	{
		$newValue = $value.$counter;
		$res = mysql(TYPO3_db,"select uid from $table where $field = '".addslashes($newValue)."' and uid != '".addslashes($id)."'".$whereAdd);
		$counter++;
		if ($counter>100)	{break;}
	}
	$value = ($newValue) ? $newValue : $value;
}



// ***************************
// Starting document output
// ***************************
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Get Unique database field</title>
</head>
<body>
<script language="javascript">



parent.busy.set(0);
parent.busy.loginRefreshed();
<?php


if ($oldValue != $value && $counter<100)	{
	echo "if (".$formRef." && ".$formRef."['data[".$table."][".$id."][".$field."]'])	{";
	echo $formRef."['data[".$table."][".$id."][".$field."]'].value = unescape('".rawurlencode($value)."');";
	echo "parent.form_has_changed('".$table."',".(strpos(" ".$id,"NEW")?"'".$id."'":$id).",'".$field."',".$formRef."['data[".$table."][".$id."][".$field."]'],parent.content.document);";
	echo "}";
}
?>
</script>