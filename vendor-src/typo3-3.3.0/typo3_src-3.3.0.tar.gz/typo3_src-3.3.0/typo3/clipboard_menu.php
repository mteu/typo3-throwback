<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Clipboard menu
 *
 * This is the pane and buttons on the clipboard
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */






// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








include("init.php");
include("template.php");



// **************************
// Starting document output
// **************************
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE>Typo 3.3 Clipboard Menu</TITLE>
<?php echo $TBE_TEMPLATE->docStyle(); ?>
</head>
<BODY bgcolor="<?php echo $TBE_TEMPLATE->bgColor2;?>" LINK="#000000" marginwidth="1" marginheight="1">
<form action="" method="POST" name="docForm">
<table border=0 cellpadding=0 cellspacing=0 width=200>
	<tr>
		<td><img src="clear.gif" width=1 height=3 border="0"></td>
		<td><img src="clear.gif" width=200 height=1 border="0"></td>
	</tr>
	<tr>
		<td></td>
		<td>
<script language="javascript">

//	var content = parent.typoWin.buttons['editClipboard'].draw('') + parent.typoWin.buttons['clrClipboard'].draw('') + parent.typoWin.buttons['thumbmode_clip'].draw('') + parent.typoWin.buttons['copymode_clip'].draw('');
//	document.writeln(parent.typoWin.faner_clip.draw(document, content));

	var theCode = '';
	theCode+='<table border=0 cellpadding=0 cellspacing=0 width=50><tr><td nowrap>';
	theCode+=parent.typoWin.buttons['thumbmode_clip'].draw('');
	theCode+=parent.typoWin.buttons['copymode_clip'].draw('');
	theCode+='</td><td><img src="clear.gif" width=20 height=1>';
	theCode+='</td><td valign="top"><font face="Verdana" size="1">';
	theCode+=parent.typoWin.rollMenu.menu['clipMenu'].write(0);
	theCode+='</font></td>';
	theCode+='<td><img src="clear.gif" width=5 height=1></td>';
	theCode+='<td nowrap>'+parent.typoWin.buttons['clear_clip'].draw('')+'</td>';
	theCode+='</tr></table>';
	document.writeln(parent.typoWin.faner_clip.draw(document, theCode));
</script>
	</td>
	</tr>
</table>
</form>

<script language="javascript">
	parent.typoWin.faner_clip.init();
	parent.typoWin.clipBrd.init();
	parent.typoWin.buttons['thumbmode_clip'].init();
	parent.typoWin.buttons['copymode_clip'].init();
</script>

</body>
</html>