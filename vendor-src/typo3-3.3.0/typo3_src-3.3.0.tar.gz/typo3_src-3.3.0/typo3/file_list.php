<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: Filelisting
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

unset($MCONF);
include ("mod/file/list/conf.php");
include ("init.php");
include ("template.php");
include (TYPO3_MOD_PATH."locallang.php");
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
include_once(PATH_t3lib."class.t3lib_extfilefunc.php");
include_once(PATH_t3lib."class.t3lib_recordlist.php");
include_once(PATH_t3lib."class.t3lib_clipboard.php");
include_once("class.file_list.inc");
$BE_USER->modAccess($MCONF,1);



// ***************************
// Script Classes
// ***************************
class SC_file_list {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();

	var $content;
	var $pointer;
	var $basicFF;
	var $imagemode;
	var $table;
	var $id;
	var $doc;	

	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $FILEMOUNTS;
		$this->MCONF = $GLOBALS["MCONF"];

		$this->id = t3lib_div::GPvar("id");
		$this->pointer = t3lib_div::GPvar("pointer");
		$this->table = t3lib_div::GPvar("table");
		$this->imagemode = t3lib_div::GPvar("imagemode");
		$this->basicFF = t3lib_div::makeInstance("t3lib_basicFileFunctions");
		$this->basicFF->init($FILEMOUNTS,$TYPO3_CONF_VARS["BE"]["fileExtensions"]);
		
		$this->menuConfig();
	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

			// MENU-ITEMS:
			// If array, then it's a selector box menu
			// If empty string it's just a variable, that'll be saved. 
			// Values NOT in this array will not be saved in the settings-array for the module.
		$this->MOD_MENU = array(
			"sort" => "",
			"reverse" => "",
			"displayThumbs" => "",
			"clipBoard" => ""
		);
			
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"]);
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $FILEMOUNTS;
		
		
		$this->doc = t3lib_div::makeInstance("template");
		$this->doc->backPath = $BACK_PATH;
		$this->doc->topSpace=0;
		
		$this->id = $this->basicFF->is_directory($this->id);
		$access = $this->id && $this->basicFF->checkPathAgainstMounts($this->id."/");
		
		$filelist = t3lib_div::makeInstance("fileList");
		$filelist->backPath = $BACK_PATH;
		$filelist->thumbs = ($AB?($this->MOD_SETTINGS["displayThumbs"]?1:$BE_USER->uc["thumbnailsByDefault"]):$this->imagemode);
		$filelist->AB = $AB;
		
			// CLipboard things...	
		$filelist->showClipboard = ($AB || $BE_USER->getTSConfigVal("options.enableABClipboardInCB"));
		$filelist->clipObj = t3lib_div::makeInstance("t3lib_clipboard");
		$filelist->clipObj->fileMode=1;
		$filelist->clipObj->initializeClipboard();
		if ($AB || $BE_USER->getTSConfigVal("options.enableABClipboardInCB"))	{
			$CB = $HTTP_GET_VARS["CB"];
			if (t3lib_div::GPvar("cmd")=="setCB") $CB["el"] = $filelist->clipObj->cleanUpCBC(array_merge($HTTP_POST_VARS["CBH"],$HTTP_POST_VARS["CBC"]),"_FILE");
			if (!$this->MOD_SETTINGS["clipBoard"])	$CB["setP"]="normal";
			$filelist->clipObj->setCmd($CB);
			$filelist->clipObj->cleanCurrent();
			$filelist->clipObj->endClipboard();	// Saves
		}
		
		if ($access)	{
			if (t3lib_div::GPvar("cmd")=="delete")	{
				$items = $filelist->clipObj->cleanUpCBC($HTTP_POST_VARS["CBC"],"_FILE",1);
				if (count($items))	{
					$FILE=array();
					reset($items);
					while(list(,$v)=each($items))	{
						$FILE["delete"][]=array("data"=>$v);
					}
		
					$fileProcessor = t3lib_div::makeInstance("t3lib_extFileFunctions");
					$fileProcessor->init($FILEMOUNTS, $TYPO3_CONF_VARS["BE"]["fileExtensions"]);
					$fileProcessor->init_actionPerms($BE_USER->user["fileoper_perms"]);
					$fileProcessor->dontCheckForUnique = t3lib_div::GPvar("overwriteExistingFiles") ? 1 : 0;
		
					$fileProcessor->start($FILE);
					$fileProcessor->processData();
					
					Header("Location: status_file.php");
					exit;
				}
			}
		
			$this->pointer = t3lib_div::intInRange($this->pointer,0,100000);
			$filelist->start($this->id,$this->pointer,$this->MOD_SETTINGS["sort"],$this->MOD_SETTINGS["reverse"],$this->MOD_SETTINGS["clipBoard"]);
			$filelist->writeTop($this->id);
			$filelist->generateList($this->id,$this->table);
			$filelist->writeBottom();
		
			
		$this->doc->JScode='<script>
			top.file_recent_id = unescape("'.rawurlencode($this->id).'");
			function jumpToUrl(URL)	{
				document.location = URL;
			}
		
			'.$filelist->CBfunctions().'
			
		</script>';
		if (!$AB)	{
			$this->doc->JScode.='
		<script language="javascript">
		script_ended = 0;
			function mouseTracker(e) {
				e = e || window.Event || window.event;
				top.pageX = e.pageX || e.clientX;
				top.pageY = e.pageY || e.clientY;
				top.mouseY = e.screenY;	top.mouseX = e.screenX;
				if (script_ended && top.checkCursorPosition)	{
					top.checkCursorPosition(thisClickmenu);
				}
			}
			thisClickmenu = top.fileListMenu;
			thisClickmenu.ready=false;
			var topFrame = top;
		
			top.funcMgr.lastClickedItem["fileListMenu"]  = "";
			var thePad = "file";
			top.clipBrd.clr(thePad);
		
		'.$filelist->JScode.'
		
		top.clipBrd.updateButtons("file");
		</SCRIPT>
		';
		$this->doc->postCode='
		
		<DIV ID="menuLayer1" STYLE="POSITION: absolute; Z-INDEX: 2; VISIBILITY: hidden; TOP: 30px; LEFT: 45px;">
			<script language="javascript">
				 document.write(thisClickmenu.writeMenu());
			</script>
		</DIV>
		<script language="javascript">
			if (window.captureEvents) {
				window.captureEvents(Event.MOUSEMOVE | Event.MOUSEUP);
				window.onmousemove = mouseTracker;
			} else {
				document.onmousemove = mouseTracker;
			}
			script_ended = 1;
			thisClickmenu.ready=true;
			top.fileMenu.recentuid = unescape("'.rawurlencode($this->id).'");
		</script>
		';
			} else {
				$CMparts=$this->doc->getContextMenuCode();
				$this->doc->bodyTagAdditions = $CMparts[1];
				$this->doc->JScode.=$CMparts[0];
				$this->doc->postCode.= $CMparts[2];
			}
		
		} // access
		
		
		$this->content="";
		$this->content.=$this->doc->startPage($LANG->getLL("files"));
		$this->content.= '<form action="'.$filelist->listURL().'" method="POST" name="dblistForm">';
		$this->content.= $filelist->HTMLcode;
		$this->content.= '<input type="hidden" name="cmd"></form>';
		
		if ($filelist->HTMLcode)	{	// Making search form:
			$this->content.='<form action="" method="POST">';
			if ($AB)	{
				$this->content.=t3lib_BEfunc::getFuncCheck($this->id,"SET[displayThumbs]",$this->MOD_SETTINGS["displayThumbs"],"file_list.php","&AB=".$AB).fw(" ".$LANG->getLL("displayThumbs")).'<BR>';
			}
			if ($filelist->showClipboard)	$this->content.=t3lib_BEfunc::getFuncCheck($this->id,"SET[clipBoard]",$this->MOD_SETTINGS["clipBoard"],"file_list.php","&AB=".$AB).fw(" ".$LANG->getLL("clipBoard"));
			$this->content.='</form>';
		
			if ($this->MOD_SETTINGS["clipBoard"] && $filelist->showClipboard)	$this->content.=$filelist->clipObj->printClipboard();
		}
		
		
		
		
		
		if ($BE_USER->mayMakeShortcut())	{
			$this->content.=$this->doc->makeShortcutIcon("pointer,id,target,table",implode(",",array_keys($this->MOD_MENU)),$this->MCONF["name"]);
		}
	}
	function printContent()	{
		global $SOBE;

		$this->content.= $this->doc->endPage();
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/file_list.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/file_list.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_file_list");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();



if ($TYPO3_CONF_VARS["BE"]["compressionLevel"])	{
	new gzip_encode($TYPO3_CONF_VARS["BE"]["compressionLevel"]);
}
?>