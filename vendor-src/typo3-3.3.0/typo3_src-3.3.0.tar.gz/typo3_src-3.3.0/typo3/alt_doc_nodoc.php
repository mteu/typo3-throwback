<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Alternative TBE: Main frameset
 *
 * This is an alternative Typo3 Backend interface using the same modules, but designed to work with less capable browsers than MSIE.
 * This is probably in pre-alpha test as this time... so dont expect anything useful.
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

include("init.php");
include("template.php");
include("lang/LL_alt_doc.php");
include("mod/user/task/class.mod_user_task.php");

$AB = 1;

// ***************************
// Script Classes
// ***************************
class SC_alt_doc_nodoc {
	var $content;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->doc = t3lib_div::makeInstance("mediumDoc");
		$this->doc->bodyTagMargins["x"]=5;
		$this->doc->bodyTagMargins["y"]=5;
		$this->doc->backPath = $BACK_PATH;
		
		$this->content="";
		$this->content.=$this->doc->startPage("Typo3 Edit Document");
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$msg=array();
		$msg[]=$LANG->getLL("noDocuments_msg");
		$a_wl = $BE_USER->check("modules","web_list");
		$a_wp = $BE_USER->check("modules","web_layout");
		if ($a_wl || $a_wp)	{
			$msg_2 = array();
			if ($a_wp)	{
				$msg_2[]='<strong><a href="#" onClick="if (top.goToModule){top.goToModule(\'web_layout\');}else{top[\'modPane_web\'].click(\'modPane_web_layout\');} return false;">'.$LANG->getLL("noDocuments_pagemodule").' <img src="mod/web/layout/layout.gif" width="14" height="12" border="0" align="top"></a></strong>';
				if ($a_wl)	$msg_2[]=$LANG->getLL("noDocuments_OR");
			}
			if ($a_wl)	{
				$msg_2[]='<strong><a href="#" onClick="if (top.goToModule){top.goToModule(\'web_list\');}else{top[\'modPane_web\'].click(\'modPane_web_list\');} return false;">'.$LANG->getLL("noDocuments_listmodule").' <img src="mod/web/list/list.gif" width="14" height="12" border="0" align="top"></a></strong>';
			}
			$msg[]="<BR><BR>".sprintf($LANG->getLL("noDocuments_msg2"),implode(" ",$msg_2));
		}
		
		if ($BE_USER->check("modules","user_task"))	{
			$modObj = t3lib_div::makeInstance("mod_user_task");
			$modObj->backPath = $BACK_PATH;
			$modObj->BE_USER = $BE_USER;
			$modObj->perms_clause = $BE_USER->getPagePermsClause(1);

			$msg[]="<BR><BR>".$LANG->getLL("noDocuments_msg3")."<BR><BR>".$modObj->_renderRecent();
		}
		
		$this->content.=$this->doc->section($LANG->getLL("noDocuments"),implode(" ",$msg),0,1);
	}
	function printContent()	{
		echo $this->content.$this->doc->endPage();
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_doc_nodoc.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_doc_nodoc.php"]);
}











// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_doc_nodoc");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>