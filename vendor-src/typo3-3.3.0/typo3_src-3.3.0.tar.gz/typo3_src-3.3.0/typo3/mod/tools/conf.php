<?php
$MLANG["default"]["labels"]["tablabel"] = "Administration and maintenance tools";
$MLANG["default"]["tabs"]["tab"] = "Tools";
$MLANG["default"]["tabs_images"]["tab"] = "tool.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Administrations- og vedligeholdelses-funktioner";
$MLANG["dk"]["tabs"]["tab"] = "V�rkt�jer";

$MLANG["de"]["labels"]["tablabel"] = "Administrations-Funktionen";
$MLANG["de"]["tabs"]["tab"] = "Tools";

$MLANG["no"]["labels"]["tablabel"] = "Administrasjons- og vedlikeholds-funksjoner";
$MLANG["no"]["tabs"]["tab"] = "Verkt�y";

$MLANG["it"]["labels"]["tablabel"] = "Tools per il mantenimento e amministrazione";
$MLANG["it"]["tabs"]["tab"] = "Tools";

$MLANG["fr"]["labels"]["tablabel"] = "Outils d'administration et de maintenance";
$MLANG["fr"]["tabs"]["tab"] = "Outils";

$MLANG["es"]["labels"]["tablabel"] = "Herramientas de administraci�n y mantenimiento";
$MLANG["es"]["tabs"]["tab"] = "Herramientas";

$MLANG["nl"]["labels"]["tablabel"] = "Beheer- en onderhoudswerkset";
$MLANG["nl"]["tabs"]["tab"] = "Werkset";

$MLANG["cz"]["labels"]["tablabel"] = "N�stroje pro spr�vu";
$MLANG["cz"]["tabs"]["tab"] = "N�stroje";

$MLANG["pl"]["labels"]["tablabel"] = "Narz�dzia administracyjne";
$MLANG["pl"]["tabs"]["tab"] = "Narzedzia";

$MLANG["si"]["labels"]["tablabel"] = "Orodja za administracijo";
$MLANG["si"]["tabs"]["tab"] = "Orodja";

$MLANG["fi"]["labels"]["tablabel"] = "Hallinnoinnin ja hoidon ty�kalut";
$MLANG["fi"]["tabs"]["tab"] = "Ty�kalut";

$MLANG["tr"]["labels"]["tablabel"] = "Y�netim ve bak�m ara�lar�";
$MLANG["tr"]["tabs"]["tab"] = "Ara�lar";


$MCONF["name"]="tools";
$MCONF["access"]="admin";
?>