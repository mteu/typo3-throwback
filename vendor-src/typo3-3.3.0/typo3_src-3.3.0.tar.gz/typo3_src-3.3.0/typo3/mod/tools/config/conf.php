<?php
define("TYPO3_MOD_PATH", "mod/tools/config/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "View configuration from localconf.php and tables.php";
$MLANG["default"]["tabs"]["tab"] = "Configuration";
$MLANG["default"]["tabs_images"]["tab"] = "config.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Allows you to browse the values of the \$TCA array (table configuration) and \$TYPO3_CONF_VARS. You cannot set any values, only browse them.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Se konfigurationen i localconf.php og tables.php";
$MLANG["dk"]["tabs"]["tab"] = "Konfiguration";
$MLANG["dk"]["labels"]["tabdescr"] = "Lader dig gennemse v�rdierne i \$TCA array'et (tabel konfiguration) samt \$TYPO3_CONF_VARS. Du kan ikke �ndre nogen v�rdier, kun se dem.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["labels"]["tablabel"] = "Zeige die Konfiguration von localconf.php und tables.php an";
$MLANG["de"]["labels"]["tabdescr"] = "Hier k�nnen Sie durch die Werte die Felder \$TCA (Tabellenkonfoguration) und \$TYPO3_CONF_VARS navigieren. Sie haben allerdings nur einen lesenden Zugriff auf die einzelnen Werte.<BR><em>Zugriff nur f�r Administratoren!</em>";
$MLANG["de"]["tabs"]["tab"] = "Konfiguration";

$MLANG["no"]["labels"]["tablabel"] = "Se konfigurasjonen i localconf.php og tables.php";
$MLANG["no"]["labels"]["tabdescr"] = "Lar deg se gjennom verdiene i \$TCA array'en (tabell konfigurasjon) samt \$TYPO3_CONF_VARS. Du kan ikke endre noen verdier, kun se dem.<BR><em>Adgang kun for 'admin' brukere!</em>";
$MLANG["no"]["tabs"]["tab"] = "Konfigurasjon";

$MLANG["it"]["labels"]["tablabel"] = "Mostra la configurazione di localconf.php e tables.php";
$MLANG["it"]["labels"]["tabdescr"] = "Consente di sfogliare i valori dell'array \$TCA (configurazione delle tabelle) e di \$TYPO3_CONF_VARS. Non potete impostare alcun valore, ma solo leggerli.<br><em>Accesso riservato ai soli utenti 'admin'!</em>";
$MLANG["it"]["tabs"]["tab"] = "Configurazione";

$MLANG["es"]["labels"]["tablabel"] = "Ver configuraci�n en localconf.php y tables.php";
$MLANG["es"]["tabs"]["tab"] = "Configuraci�n";
$MLANG["es"]["labels"]["tabdescr"] = "Permite el ver los valores del arreglo \$TCA (configuraci�n de las tablas) y \$TYPO3_CONF_VARS. No puede modificar ning�n valor, solamente ver.<BR><em>�Acceso solamente para usuarios 'administrador'!</em>";

$MLANG["fr"]["labels"]["tablabel"] = "Voir la configuration depuis localconf.php et tables.php";
$MLANG["fr"]["labels"]["tabdescr"] = "Vous pouvez depuis ici naviguer dans les propri�t�s du tableau \$TCA (Configuration des tables) et \$TYPO3_CONF_VARS. Vous ne pouvez pas modifer les valeurs, seulement les consulter.";
$MLANG["fr"]["tabs"]["tab"] = "Configuration";

$MLANG["nl"]["labels"]["tablabel"] = "Toon configuratie vanuit localconf.php en tables.php";
$MLANG["nl"]["tabs"]["tab"] = "Configuratie";
$MLANG["nl"]["labels"]["tabdescr"] = "Biedt je de mogelijkheid te bladeren door de waardes van de \$TCA array (tabel configuratie) en \$TYPO3_CONF_VARS. Je kan geen waardes instellen, alleen doorbladeren is mogelijk. <BR><em>Alleen toegang voor 'admin' gebruikers!</em>";

$MLANG["pl"]["labels"]["tablabel"] = "Zobacz konfiguracj� z localconf.php i tables.php";
$MLANG["pl"]["tabs"]["tab"] = "Konfiguracja";
$MLANG["pl"]["labels"]["tabdescr"] = "Umo�liwia przegl�danie warto�ci z tablicy \$TCA (tablicy konfiguracyjnej) oraz \$TYPO3_CONF_VARS. Nie mo�na zmienia� tych warto�ci a jedynie przegl�da�. <br><em>Dost�p tylko dla administrator�w!<em>";

$MLANG["si"]["labels"]["tablabel"] = "Nastavitve localconf.php in tables.php";
$MLANG["si"]["tabs"]["tab"] = "Nastavitve";
$MLANG["si"]["labels"]["tabdescr"] = "Omogo�a pregled vrste spremenljivk \$TCA (table configuration) in \$TYPO3_CONF_VARS. Vrednosti si lahko le ogledate, spremeniti jih tukaj ne morete.<BR><em>Uporaba je dovoljena le 'admin' uporabnikom!</em>";

$MLANG["cz"]["labels"]["tablabel"] = "Zobrazit konfiguraci z localconf.php a tables.php";
$MLANG["cz"]["labels"]["tabdescr"] = "Umo��uje proch�zet hodnoty \$TCA array (konfigurace tabulek) a \$TYPO3_CONF_VARS. Nem��ete ��dn� hodnoty nastavovat, jen je proch�zet.<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";
$MLANG["cz"]["tabs"]["tab"] = "Konfigurace";

$MLANG["fi"]["labels"]["tablabel"] = "Katsele localconf.php ja tables.php m��rityksi�";
$MLANG["fi"]["labels"]["tabdescr"] = "T��ll� voit selailla \$TCA arvoja (taulujen m��ritykset) ja \$TYPO3_CONF_VARS arvoja. Et voi asettaa mit��n arvoja ainoastaan selailla.<BR><em>Sallittu vain 'Admin' k�ytt�jille!</em>";
$MLANG["fi"]["tabs"]["tab"] = "Asetukset";

$MLANG["tr"]["labels"]["tablabel"] = "Localconf.php ve tables.php den konfig�rasyonun g�r�nt�lenmesi";
$MLANG["tr"]["tabs"]["tab"] = "Konfigurasyon";
$MLANG["tr"]["labels"]["tabdescr"] = "\$TCA d�zenindeki (tablo konfig�rasyonu) de�erlerde gezinmenize izin verir ve \$TYPO3_CONF_VARS. Bazi de�erleri kuramazs�n�z, sadece g�zatmak i�in.<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";



$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_config";
?>