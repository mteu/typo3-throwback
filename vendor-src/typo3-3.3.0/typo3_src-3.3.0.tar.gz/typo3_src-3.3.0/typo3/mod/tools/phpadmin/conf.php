<?php

// Setting specific configuration for the third part module:
$MCONF["phpMyAdminScript"] = "";	// or 'main.php','db_details.php'	// Enter the script to load, if any
$MCONF["phpMyAdminSubDir"]="";
if (!isset($MCONF["extModInclude"]))	{$MCONF["extModInclude"]=0;}

## UN-COMMENT THIS LINE to activate phpMyAdmin! Please make sure the path is correct!
$MCONF["phpMyAdminSubDir"] = "phpMyAdmin-2.2.6/";			// Enter the subdirectory of the scripts






// Almost regular configuration of the module. Only if $MCONF["extModInclude"] is set, then phpMyAdminSubDir is prepended to the TYPO3_MOD_PATH and "../" to BACK_PATH. If this is not correct, init.php will exit!
define("TYPO3_MOD_PATH", "mod/tools/phpadmin/".($MCONF["extModInclude"]?$MCONF["phpMyAdminSubDir"]:""));
$BACK_PATH="../../../".($MCONF["extModInclude"]?"../":"");

$MLANG["default"]["labels"]["tablabel"] = "Third-Party database administration, phpMyAdmin";
$MLANG["default"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["default"]["tabs_images"]["tab"] = "thirdparty_db.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Integrated 'Third-party module', the popular phpMyAdmin interface. This allows ground level access to the database tables. The access to phpMyAdmin is authenticated through Typo3. But this is the only interference whatsoever - phpMyAdmin allows you to modify whatever you wish so be careful!<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Tredjeparts database administrationsv�rkt�j, phpMyAdmin";
$MLANG["dk"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["dk"]["labels"]["tabdescr"] = "Integreret 'Tredje-parts modul' - det popul�re phpMyAdmin interface. Dette giver dig helt grundl�ggende adgang til databasens tabeller. Adgangen til phpMyAdmin er kontrolleret af Typo3. Men dette er ogs� den eneste styring overhovedet - phpMyAdmin giver dig tilladelse til at �ndre hvadend du pr�ver p�, s� v�r forsigtig!<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["de"]["labels"]["tablabel"] = "Datenbank Administration von Dritt-Hersteller, phpMyAdmin";
$MLANG["de"]["labels"]["tabdescr"] = "Integriertes 'Dritt-Hersteller-Modul' - dieekannte phpMyAdmin Oberfl�che. Diese erlaubt den grundlegenden Zugriff auf die Tabellen der Datenbank. Der Zugriff auf phpMyAdmin wird durch Typo3 authentifiziert. Dies ist schon die einzige Einschr�kung - phpMyAdmin bietet seinen kompletten Funktionsumfang, wodurch Sie bei Ihrer Arbeit mit diesem entsprechend vorsichtig seien sollten!<BR><em>Zugriff nur f�r Administratoren!</em>";

$MLANG["no"]["labels"]["tablabel"] = "Tredjeparts database administrasjonsverkt�y, phpMyAdmin";
$MLANG["no"]["labels"]["tabdescr"] = "Integrert tredjeparts modul - det popul�re phpMyAdmin grensesnittet. Dette gir deg helt grunnleggende adgang til databasens tabeller. Adgangen til phpMyAdmin er kontrollert av Typo3. Dette er ogs� den eneste styringen overhode - phpMyAdmin gir deg tillatelse til � endre hva som helst, s� v�r forsiktig!<BR><em>Adgang kun for 'admin' brukere!</em>";
$MLANG["no"]["tabs"]["tab"] = "phpMyAdmin";

$MLANG["it"]["labels"]["tablabel"] = "phpMyAdmin, tool per l'amministrazione di database";
$MLANG["it"]["labels"]["tabdescr"] = "phpMyAdmin � un tool (sviluppato da terzi) molto diffuso che consente l'accesso a basso livello a tutte le tabelle del database. L'autenticazione � gestita da Typo3. phpMyAdmin consente di modificare qualunque cosa, senza controllo di Typo3, quindi � necessario prestare particolare attenzione alle modifiche che si compiono.<br><em>Accesso riservato ai soli utenti 'admin'!</em>";
$MLANG["it"]["tabs"]["tab"] = "phpMyAdmin";

$MLANG["fr"]["labels"]["tablabel"] = "Administration tiers de la base de donn�es, phpMyAdmin";
$MLANG["fr"]["labels"]["tabdescr"] = "Le c�l�bre outil d'administration pour base de donn�es mySQL est maintenant int�gr� dans Typo3.";
$MLANG["fr"]["tabs"]["tab"] = "phpMyAdmin";

$MLANG["pl"]["labels"]["tablabel"] = "Zewn�trzny modu� do administracji baz�, phpMyAdmin";
$MLANG["pl"]["labels"]["tabdescr"] = "Zintegrowany 'Zewn�trzny' modu�, popularnego interfejsu phpMyAdmin. Zapewnia on dost�p do tablic na najni�szym poziomie. Autentykacja jest realizowana przez Typo3. Ten modu� pozwala na nieograniczon� ingerencj� w baz�. Zalecana du�a ostro�no��. <br><em>Dost�p tylko dla administrator�w!<em>";
$MLANG["pl"]["tabs"]["tab"] = "phpMyAdmin";

$MLANG["es"]["labels"]["tablabel"] = "Administraci�n de base de datos de un tercero, phpMyAdmin";
$MLANG["es"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["es"]["labels"]["tabdescr"] = "Con el m�dulo incluido de un tercero, el popular phpMyAdmin, permite acceso directo a las tablas de las base de datos. El acceso a phpMyAdmin es autentificado por medio de Typo3. Salvo ese detalle Typo3 no interfiere para nada - phpMyAdmin le permite el modificar lo que deseee, por tanto �tenga cuidado!<BR><em>�Acceso solamente para usuarios 'administrador'!</em>";

$MLANG["si"]["labels"]["tablabel"] = "phpMyAdmin, orodje za administracijo MySQL baze";
$MLANG["si"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["si"]["labels"]["tabdescr"] = "Na voljo vam je popularno orodje za administracijo MySQL stre�nika. Ker omogo�a popoln nadzor nad podatkovno bazo, zahteva uporaba nekaj previdnosti in znanja. Avtorizacija dostopa poteka preko Typo3.<BR><em>Uporaba je dovoljena samo 'admin' uporabnikom!</em>";

$MLANG["nl"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["nl"]["labels"]["tablabel"] = "Geintegreerde databasebeheermodule van derden, phpMyAdmin";
$MLANG["nl"]["labels"]["tabdescr"] = "Geintegreerde module van derden, het populaire phpMyAdmin. Dit geeft je toegang op basisniveau naar de databasetabellen. De toegang tot phpMyAdmin wordt geregeld door Typo3. Dit is ook de enige tussenstap. Whatever! Met phpMyAdmin kan je alles modificeren wat je wilt, dus pas op!<BR><em>Alleen toegang voor 'admin' gebruikers!</em>";

$MLANG["cz"]["labels"]["tablabel"] = "Administrance datab�ze od t�et� strany, phpMyAdmin";
$MLANG["cz"]["labels"]["tabdescr"] = "Integrovan� modul 't�et� strany', popul�rn� phpMyAdmin interafce. Umo��uje �pln� p��stup k datab�zov�m tabulk�m. P��stup k phpMyAdmin je autentifikov�n p�es Typo3. Ale toto je jedin� interference - phpMyAdmin umo�n� cokoli si usmysl�te, proto bu�te opatrn�!<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";
$MLANG["cz"]["tabs"]["tab"] = "phpMyAdmin";

$MLANG["fi"]["labels"]["tablabel"] = "Tietokanta hallinta, phpMyAdmin";
$MLANG["fi"]["labels"]["tabdescr"] = "Typo3n kanssa integroitu kolmannen osapuolen tietokanta hallinta. <BR><em>Sallittu vain 'Admin'  k�ytt�jille.</em> ";
$MLANG["fi"]["tabs"]["tab"] = "phpMyAdmin";

$MLANG["tr"]["labels"]["tablabel"] = "���nc�-Parti veritaban� y�netimi, phpMyAdmin";
$MLANG["tr"]["tabs"]["tab"] = "phpMyAdmin";
$MLANG["tr"]["labels"]["tabdescr"] = "B�t�nle�mi� '���nc�-parti mod�l�', pop�ler phpMyAdmin arabirimi. Bu izinler temel seviyede veritaban� tablolar�na eri�imi sa�lar. PhpMyAdmin e eri�im Typo3 i�inden do�ruland�r�l�yor. Fakat bu sadece herhangi bir k�s�tlamad�r - phpMyAdmin neyi isterseniz onu modifiye etmenize izin verir!<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";


$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_phpadmin";
?>