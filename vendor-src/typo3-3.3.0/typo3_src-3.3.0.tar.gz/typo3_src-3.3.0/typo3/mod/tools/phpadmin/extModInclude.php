<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


// This includes the Typo3 module configuration as required:
unset($MCONF);
$MCONF["extModInclude"]=1;
include ("../conf.php");

// It phpMyAdmin is congured for, proceed
if ($MCONF["phpMyAdminSubDir"])	{	// If phpMyAdmin is configured in the conf.php script, we continue to load it...
		// Now, the init.php script is included. This loads a lot of stuff and includes Typo3 specific libraries which we don't need directly for the application.
		// However this is the only way to get the Typo3 backend user authenticated so we know if this user is actually allowed to access this module!
	include ($BACK_PATH."init.php");
	include ($BACK_PATH."template.php");
	$BE_USER->modAccess($MCONF,1);
	
		// By now the Typo3 backend user is authenticated and if that failed and error is outputted and the script has exited.
		// So now we go on, altering certain configoptions of phpMyAdmin (for details here, see the phpMyAdmin config-file, config.inc.php)

			// Set some interface values:		
		$cfgLeftWidth           = 200;          // left frame width
		$cfgLeftBgColor         = $TBE_TEMPLATE->bgColor;    // background color for the left frame
		$cfgRightBgColor        = $TBE_TEMPLATE->bgColor;    // background color for the right frame
		$cfgThBgcolor           = $TBE_TEMPLATE->bgColor5;    // table header row colour
		$cfgBgcolorOne          = $TBE_TEMPLATE->bgColor4;    // table data row colour
		$cfgBgcolorTwo          = t3lib_div::modifyHTMLColor($TBE_TEMPLATE->bgColor4,+20,+20,+20);    // table data row colour, alternate
		$cfgBrowsePointerColor  = $TBE_TEMPLATE->bgColor6;    // color of the pointer in browse mode
		$cfgLeftPointerColor    = $TBE_TEMPLATE->bgColor6;    // color of the pointer in left frame
		$cfgDefaultDisplay      = 'horizontal'; // default display direction (horizontal|vertical)
		
		
			// Setting the database information, using 'server1'. The other servers are NOT configured or reset, so you may set then independantly if you like.
		$cfgServers[1]['host']          = TYPO3_db_host; // MySQL hostname
		$cfgServers[1]['user']          = TYPO3_db_username;      // MySQL user (only needed with basic auth)
		$cfgServers[1]['password']      = TYPO3_db_password;          // MySQL password (only needed with basic auth)
		$cfgServers[1]['only_db']       = TYPO3_db;          // If set to a db-name, only this db is accessible

		$cfgPmaAbsoluteUri = "http://".t3lib_div::getThisUrl();
} else {
	die ("phpMyAdmin was not configured in mod/tools/phpadmin/conf.php!");
}

?>