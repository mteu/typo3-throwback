<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: Indexing Engine Overview
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
$BE_USER->modAccess($MCONF,1);




// ***************************
// Script Classes
// ***************************
class SC_mod_tools_isearch_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $include_once=array();
	var $content;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		$this->menuConfig();

		$this->doc = t3lib_div::makeInstance("noDoc");
		$this->doc->form='<form action="" method="POST">';
		$this->doc->backPath = $BACK_PATH;
				// JavaScript
		$this->doc->JScode = '
		<script>
			script_ended = 0;
			function jumpToUrl(URL)	{
				document.location = URL;
			}
		</SCRIPT>
		';
		$this->doc->tableLayout = Array (
			"defRow" => Array (
				"0" => Array('<td valign="top" nowrap>','</td>'),
				"defCol" => Array('<TD><img src="'.$this->doc->backPath.'clear.gif" width=10 height=1></td><td valign="top" nowrap>','</td>')
			)
		);
	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// MENU-ITEMS:
			// If array, then it's a selector box menu
			// If empty string it's just a variable, that'll be saved. 
			// Values NOT in this array will not be saved in the settings-array for the module.
		$this->MOD_MENU = array(
			"function" => array(
				"stat" => "General statistics",
				"typo3pages" => "List: Typo3 Pages",
				"externalDocs" => "List: External documents",
				"testSearch" => "Test search"
			)
		);
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"], "ses");
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content="";
		$this->content.=$this->doc->startPage("Indexing Engine Statistics");
		
		$menu=t3lib_BEfunc::getFuncMenu(0,"SET[function]",$this->MOD_SETTINGS["function"],$this->MOD_MENU["function"]);
		
		$this->content.=$this->doc->header("Indexing Engine Statistics");
		$this->content.=$this->doc->spacer(5);
		$this->content.=$this->doc->section('',$menu);
				
		switch($this->MOD_SETTINGS["function"])	{
			case "stat":
				$this->content.=$this->doc->section('Records',$this->doc->table($this->getRecordsNumbers()),0,1);
				$this->content.=$this->doc->spacer(15);
		//		$this->content.=$this->doc->section('index_phash STATISTICS',$this->doc->table($this->getPhashStat()),1);
		//		$this->content.=$this->doc->spacer(15);
				$this->content.=$this->doc->section('index_phash TYPES',$this->doc->table($this->getPhashTypes()),1);
				$this->content.=$this->doc->spacer(15);
			break;
			case "externalDocs":
				$this->content.=$this->doc->section('External documents',$this->doc->table($this->getPhashExternalDocs()),0,1);
				$this->content.=$this->doc->spacer(15);
			break;
			case "typo3pages":
				$this->content.=$this->doc->section('Typo3 Pages',$this->doc->table($this->getPhashT3pages()),0,1);
				$this->content.=$this->doc->spacer(15);
			break;
			case "testSearch":
				$this->content.=$this->doc->section('Test search',$this->doc->table($this->testSearch()),0,1);
				$this->content.=$this->doc->spacer(15);
			break;
		}
	}
	function printContent()	{
		global $SOBE;

		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
	

	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
	function getRecordsNumbers()	{
		$tables=explode(",","index_phash,index_words,index_rel,index_grlist,index_section,index_fulltext");
		$recList=array();
		reset($tables);
		while(list(,$t)=each($tables))	{
			$query = "SELECT count(*) FROM ".$t;
			$res = mysql(TYPO3_db,$query);
			$row = mysql_fetch_row($res);
			$recList[]=array($this->tableHead($t), $row[0]);
		}
		return $recList;
	}
	function tableHead($str)	{
		return "<strong>".$str.":&nbsp;&nbsp;&nbsp;</strong>";
	}
	function getPhashStat()	{
		$recList=array();
		
			// Typo3 pages, unique
		$query = "SELECT count(*),phash FROM index_phash WHERE data_page_id!=0 GROUP BY phash_grouping";
		$res = mysql(TYPO3_db,$query);
		$items=array();
		while($row = mysql_fetch_row($res))	{
			$items[]=$row;
		}
		$recList[]=array($this->tableHead("Typo3 pages"), count($items));
	
			// Typo3 pages:
		$query = "SELECT count(*) FROM index_phash WHERE data_page_id!=0";
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_row($res);
		$recList[]=array($this->tableHead("Typo3 pages, raw"), $row[0]);
	
			// External files, unique
		$query = "SELECT count(*),phash FROM index_phash WHERE data_filename!='' GROUP BY phash_grouping";
		$res = mysql(TYPO3_db,$query);
		$items=array();
		while($row = mysql_fetch_row($res))	{
			$items[]=$row;
		}
		$recList[]=array($this->tableHead("External files"), count($items));
	
			// External files
		$query = "SELECT count(*) FROM index_phash WHERE data_filename!=''";
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_row($res);
		$recList[]=array($this->tableHead("External files, raw"), $row[0]);
	
		return $recList;
	}
	function getPhashT3pages()	{
		$recList[]=array(
			$this->tableHead("id/type"),
			$this->tableHead("Title"),
			$this->tableHead("Size"),
			$this->tableHead("Words"),
			$this->tableHead("mtime"),
			$this->tableHead("Indexed"),
			$this->tableHead("Updated"),
			$this->tableHead("Parsetime"),
			$this->tableHead("#sec/gr/full"),
			$this->tableHead("#sub"),
			$this->tableHead("cHash"),
			$this->tableHead("phash")
		);
		
			// Typo3 pages, unique
		$query = "SELECT count(*),index_phash.* FROM index_phash WHERE data_page_id!=0 GROUP BY phash_grouping ORDER BY data_page_id";
		$res = mysql(TYPO3_db,$query);
		while($row = mysql_fetch_assoc($res))	{
			
			$cHash = count(unserialize($row["cHashParams"])) ? $this->formatCHash(unserialize($row["cHashParams"])) : "";
			$grListRec = $this->getGrlistRecord($row["phash"]);
			$recList[]=array(
				$row["data_page_id"].($row["data_page_type"]?"/".$row["data_page_type"]:""),
				t3lib_div::fixed_lgd($row["item_title"],30),
				t3lib_div::formatSize($row["item_size"]),
				$this->getNumberOfWords($row["phash"]),
				t3lib_BEfunc::datetime($row["item_mtime"]),
				t3lib_BEfunc::datetime($row["crdate"]),
				($row["tstamp"]!=$row["crdate"] ? t3lib_BEfunc::datetime($row["tstamp"]) : ""),
				$row["parsetime"],
				$this->getNumberOfSections($row["phash"])."/".$grListRec["count(*)"]."/".$this->getNumberOfFulltext($row["phash"]),
				$row["count(*)"]."/".$this->formatFeGroup($grListRec["gr_list"]),
				$cHash,
				$row["phash"]
			);
			
			if ($row["count(*)"]>1)	{
				$query = "SELECT index_phash.* FROM index_phash WHERE phash_grouping=".$row["phash_grouping"]." AND phash!=".$row["phash"];
				$res2 = mysql(TYPO3_db,$query);
				while($row2 = mysql_fetch_assoc($res2))	{
					$grListRec = $this->getGrlistRecord($row2["phash"]);
					$recList[]=array(
						"",
						"",
						t3lib_div::formatSize($row2["item_size"]),
						$this->getNumberOfWords($row2["phash"]),
						t3lib_BEfunc::datetime($row2["item_mtime"]),
						t3lib_BEfunc::datetime($row2["crdate"]),
						($row2["tstamp"]!=$row2["crdate"] ? t3lib_BEfunc::datetime($row2["tstamp"]) : ""),
						$row2["parsetime"],
						$this->getNumberOfSections($row2["phash"])."/".$grListRec["count(*)"]."/".$this->getNumberOfFulltext($row2["phash"]),
						"-/".$this->formatFeGroup($grListRec["gr_list"]),
						"",
						$row2["phash"]
					);
				}
			}
	//		debug($row);
		}
		return $recList;
	}
	function getPhashExternalDocs()	{
		$recList[]=array(
			$this->tableHead("Filename"),
			$this->tableHead("Size"),
			$this->tableHead("Words"),
			$this->tableHead("mtime"),
			$this->tableHead("Indexed"),
			$this->tableHead("Updated"),
			$this->tableHead("Parsetime"),
			$this->tableHead("#sec/gr/full"),
			$this->tableHead("#sub"),
			$this->tableHead("cHash"),
			$this->tableHead("phash"),
			$this->tableHead("Path")
		);
		
			// Typo3 pages, unique
		$query = "SELECT count(*),index_phash.* FROM index_phash WHERE item_type>0 GROUP BY phash_grouping ORDER BY item_type";
		$res = mysql(TYPO3_db,$query);
		while($row = mysql_fetch_assoc($res))	{
			
			$cHash = count(unserialize($row["cHashParams"])) ? $this->formatCHash(unserialize($row["cHashParams"])) : "";
			$grListRec = $this->getGrlistRecord($row["phash"]);
			$recList[]=array(
				t3lib_div::fixed_lgd($row["item_title"],30),
				t3lib_div::formatSize($row["item_size"]),
				$this->getNumberOfWords($row["phash"]),
				t3lib_BEfunc::datetime($row["item_mtime"]),
				t3lib_BEfunc::datetime($row["crdate"]),
				($row["tstamp"]!=$row["crdate"] ? t3lib_BEfunc::datetime($row["tstamp"]) : ""),
				$row["parsetime"],
				$this->getNumberOfSections($row["phash"])."/".$grListRec["count(*)"]."/".$this->getNumberOfFulltext($row["phash"]),
				$row["count(*)"],
				$cHash,
				$row["phash"],
				t3lib_div::fixed_lgd($row["data_filename"],100)
			);
			
			if ($row["count(*)"]>1)	{
				$query = "SELECT index_phash.* FROM index_phash WHERE phash_grouping=".$row["phash_grouping"]." AND phash!=".$row["phash"];
				$res2 = mysql(TYPO3_db,$query);
				while($row2 = mysql_fetch_assoc($res2))	{
					$cHash = count(unserialize($row2["cHashParams"])) ? $this->formatCHash(unserialize($row2["cHashParams"])) : "";
					$grListRec = $this->getGrlistRecord($row2["phash"]);
					$recList[]=array(
						"",
						"",
						$this->getNumberOfWords($row2["phash"]),
						"",
						t3lib_BEfunc::datetime($row2["crdate"]),
						($row2["tstamp"]!=$row2["crdate"] ? t3lib_BEfunc::datetime($row2["tstamp"]) : ""),
						$row2["parsetime"],
						$this->getNumberOfSections($row2["phash"])."/".$grListRec["count(*)"]."/".$this->getNumberOfFulltext($row2["phash"]),
						"",
						$cHash,
						$row2["phash"],
						""
					);
				}
			}
	//		debug($row);
		}
		return $recList;
	}
	function formatFeGroup($fegroup)	{
		$str = $fegroup=="0,-1" ? "NL" : $fegroup;
		return $str;
	}
	function formatCHash($arr)	{
		reset($arr);
		$list=array();
		while(list($k,$v)=each($arr))	{
			$list[]=$k."=".$v;
		}
		return implode("<BR>",$list);
	}
	function getNumberOfSections($phash)	{
		$query = "SELECT count(*) FROM index_section WHERE phash=".$phash;
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_row($res);
		return $row[0];
	}
	function getNumberOfWords($phash)	{
		$query = "SELECT count(*) FROM index_rel WHERE phash=".$phash;
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_row($res);
		return $row[0];
	}
	function getGrlistRecord($phash)	{
		$query = "SELECT index_grlist.* FROM index_grlist WHERE phash=".$phash;
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_assoc($res);
		$row["count(*)"] = mysql_num_rows($res);
		return $row;
	}
	function getNumberOfFulltext($phash)	{
		$query = "SELECT count(*) FROM index_fulltext WHERE phash=".$phash;
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_row($res);
		return $row[0];
	}
	function getPhashTypes()	{
		$recList=array();
	
		// Types:
		$Itypes = array(
			"html" => 1,
			"htm" => 1,
			"pdf" => 2,
			"doc" => 3,
			"txt" => 4
		);
		
		$revTypes=array_flip($Itypes);
		$revTypes[0]="Typo3 page";
	
		$query = "SELECT count(*),item_type FROM index_phash GROUP BY item_type ORDER BY item_type";
		$res = mysql(TYPO3_db,$query);
		while($row = mysql_fetch_row($res))	{
			$iT=$row[1];
			$recList[]=array($this->tableHead($revTypes[$iT]." ($iT)"), $this->countUniqueTypes($iT)."/".$row[0]);
		}
	
		return $recList;
	}
	function countUniqueTypes($item_type)	{
			// Typo3 pages, unique
		$query = "SELECT count(*) FROM index_phash WHERE item_type=".intval($item_type)." GROUP BY phash_grouping";
		$res = mysql(TYPO3_db,$query);
		$items=array();
		while($row = mysql_fetch_row($res))	{
			$items[]=$row;
		}
		return count($items);
	}
	
	function testSearch()	{
	
	
		$sQ ="EXPLAIN SELECT STRAIGHT_JOIN count(*), SUM(IR.freq) AS order_val FROM 
	index_words AS IW, 
	index_rel AS IR, 
	index_phash AS IP,
	index_section AS ISEC
	#index_grlist AS IG
	WHERE 
	IW.wid=IR.wid AND 
	IR.phash = IP.phash AND 
	ISEC.phash = IP.phash AND 
	#IG.phash = IP.phash AND 
	
	#ISEC.rl1 = 1032 AND
	
	IW.baseword LIKE 'conte%'
	#IW.baseword = 'content'
	#IW.wid = -1711053639
	
	GROUP BY IP.phash
	ORDER BY order_val DESC
	";
		debug(array("query:",$sQ));
		$timeBefore=t3lib_div::milliseconds();
		$res = mysql(TYPO3_db,$sQ);
		debug(mysql_error());
		
	
		
		debug(array("Rows selected:",mysql_num_rows($res)));
		debug(array("in time",t3lib_div::milliseconds()-$timeBefore));
		
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/tools/isearch/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/tools/isearch/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_tools_isearch_index");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>