<?php
define("TYPO3_MOD_PATH", "mod/tools/isearch/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "View statistics for the Indexing Engine";
$MLANG["default"]["tabs"]["tab"] = "Indexing";
$MLANG["default"]["tabs_images"]["tab"] = "isearch.gif";
$MLANG["default"]["labels"]["tabdescr"] = "This lets you manage settings for the Indexing Engine which is provided by the frontend website. You can see statistics of indexed pages. Indexing must be enabled in the TypoScript template.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Se statistik for indekseringsenheden";
$MLANG["dk"]["tabs"]["tab"] = "Indeksering";
$MLANG["dk"]["labels"]["tabdescr"] = "Dette modul lader dig kontrollere indstillinger for indekseringsenheden som bruges p� websitet. Du kan se statestik over indekserede sider. Indeksering skal v�re sl�et til i TypoScript skabelonen.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["labels"]["tablabel"] = "Zeige Statistik f�r die Indexierungs-Engine an.";
$MLANG["de"]["labels"]["tabdescr"] = "Hier k�nnen Sie die Einstellungen der Indexierungs-Engine vornehmen, welche durch das Typo3 Frontend zur Verf�gung gestellt wird. Sie k�nnen Statistiken �ber indexierte Seiten ansehen. Die Indexierung muss allerdings im TypoScript Template aktiviert werden.<BR><em>Zugriff nur f�r Administratoren!</em>";
$MLANG["de"]["tabs"]["tab"] = "Indexierung";

$MLANG["no"]["labels"]["tablabel"] = "Se statistikk for indekseringsenheten";
$MLANG["no"]["labels"]["tabdescr"] = "Med denne modulen kan du kontrollere innstillingene for indekseringsenheten som brukes p� webomr�det. Du kan se statistikk over indekserte sider. Indeksering m� v�re aktivert i TypoScript malen.<BR><em>Adgang kun for 'admin' brukere!</em>";
$MLANG["no"]["tabs"]["tab"] = "Indeksering";

$MLANG["it"]["labels"]["tablabel"] = "Vedi le statistiche dell'Indexing Engine";
$MLANG["it"]["labels"]["tabdescr"] = "In questo modulo potete configurare il motore di indicizzazione del sito web e vedere le statistiche sulle pagine indicizzate. L'indicizzazione deve essere attivata nel template Typoscript.<br><em>Accesso riservato ai soli utenti 'admin'!</em>";
$MLANG["it"]["tabs"]["tab"] = "Indicizzazione";

$MLANG["fr"]["labels"]["tablabel"] = "Voir les statistiques du moteur d'indexation";
$MLANG["fr"]["labels"]["tabdescr"] = "Vous pouvez r�gler le moteur d'indexation depuis cette page. Vous pouvez aussi consulter ses statistiques.";
$MLANG["fr"]["tabs"]["tab"] = "Moteur d'indexation";

$MLANG["pl"]["labels"]["tablabel"] = "Ogl�danie statystyk dotycz�cych Indeksowania";
$MLANG["pl"]["labels"]["tabdescr"] = "Pozwala zmienia� ustawienia Indeksowania. Mo�esz zobaczy� statystyki zindeksowanych stron. Indeksowanie musi by� w�aczone w Szablonie.<br><em>Dost�p tylko dla administrator�w!<em>";
$MLANG["pl"]["tabs"]["tab"] = "Indeksowanie";

$MLANG["es"]["labels"]["tablabel"] = "Ver las estad�sticas del motor de indexaci�n";
$MLANG["es"]["labels"]["tabdescr"] = "Este m�dulo permite administrar la configuraci�n del motor de indexaci�n que esta incluido en el website de frontend.Ud. puede ver las estad�sticas de las p�ginas indexadas. La funci�n de indexado debe estar habilitada en el template TypoScript.<BR><em>�Acceso solamente para usuarios 'administrador'!</em>";
$MLANG["es"]["tabs"]["tab"] = "Indexando";

$MLANG["si"]["labels"]["tablabel"] = "Ogled statistike orodja za indeksiranje";
$MLANG["si"]["tabs"]["tab"] = "Indeksiranje";
$MLANG["si"]["labels"]["tabdescr"] = "Tukaj lahko urejate nastavitve orodja za indeksiranja, ki je del 'frontenda'. Indeksiranje mora biti vklopljeno v TypoScript templatu.<BR><em>Uporaba je dovoljena le 'admin' uporabnikom!</em>";

$MLANG["nl"]["labels"]["tablabel"] = "Bekijk statistieken van de Indexeermachine";
$MLANG["nl"]["labels"]["tabdescr"] = "Hier kan je de instellingen bepalen voor de Indexeer Machine die geboden wordt in de website zelf. Je kan statistieken bekijken van geindexeerde pagina's. Indexeren moet geactiveerd zijn in de TypoScript template.<BR><em>Alleen toegang voor 'admin' gebruikers!</em>";
$MLANG["nl"]["tabs"]["tab"] = "Indexeren";

$MLANG["cz"]["labels"]["tablabel"] = "Zobrazit statistiku Indexovac� Engine";
$MLANG["cz"]["labels"]["tabdescr"] = "Zde m��ete spravovat nastaven� Indexovac� Engine, kter� je poskytov�na frontendem. M��ete vid�t statistiky indexovan�ch stran. Indexace mus� b�t aktivov�na v TypoScriptov� �ablon�.<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";
$MLANG["cz"]["tabs"]["tab"] = "Indexace";

$MLANG["fi"]["labels"]["tablabel"] = "Katsele Indexing Engine tilastoja";
$MLANG["fi"]["labels"]["tabdescr"] = "T��ll� voit hallita Indexing Engine asetuksia. N�et indeksoitujen sivujen tilastot. Indeksointi asetetaan TypoScript mallilla.<BR><em>Sallittu vain 'Admin' k�ytt�jille</em>";
$MLANG["fi"]["tabs"]["tab"] = "Indeksointi";

$MLANG["tr"]["labels"]["tablabel"] = "�ndeksleme Motoru i�in istatistiklerin g�r�nt�lenmesi";
$MLANG["tr"]["tabs"]["tab"] = "�ndeksleme";
$MLANG["tr"]["labels"]["tabdescr"] = "�nplan websitesi taraf�ndan sa�lanan indeksleme motoru i�in ayarlar�n y�netimine izin verir. �ndekslenmi� sayfalar�n istatistiklerini g�rebilirsiniz. TypoScript �ablonunda indekleme aktif hale getirilmelidir.<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";


$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_isearch";
?>