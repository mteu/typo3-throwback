<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Backend User Administration Module
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
include_once(PATH_t3lib."class.t3lib_browsetree.php");
include_once(PATH_t3lib."class.t3lib_tstemplate.php");
include_once(PATH_t3lib."class.t3lib_loadmodules.php");
include_once(PATH_typo3."mod/web/ts/tsparser_ext.php");
include_once(PATH_typo3."class.alt_menu_functions.inc");
$BE_USER->modAccess($MCONF,1);



// ***************************
// Script Classes
// ***************************
class localPageTree extends t3lib_browseTree {
	var $expandFirst=0;
	var $expandAll=0;

	function localPageTree($BE_USER,$WEBMOUNTS="",$FILEMOUNTS="")	{
		$this->BE_USER = $BE_USER;
		$this->WEBMOUNTS = $WEBMOUNTS;
		$this->FILEMOUNTS = $FILEMOUNTS;
	}
	function wrapTitle($str)	{
		return $str;
	}
	function PM_ATagWrap($icon,$cmd,$bMark="")	{
		return "";//$icon;
	}
	function permsC()	{
		return "1";
	}
	function wrapIcon($str,$val)	{
		if ($val["path"])	{
			$title = $GLOBALS["SOBE"]->localPath($val["path"]);
		}
		if ($val["uid"])	{
			$title = "[".$val["uid"]."] ".t3lib_BEfunc::getRecordPath ($val["uid"],"1",15);
		}
		return substr($str,0,-1).' title="'.htmlspecialchars($title).'">';
	}
}
class printAllPageTree extends localPageTree {
	var $expandFirst=1;
	var $expandAll=1;
	function permsC()	{
		return $this->BE_USER->getPagePermsClause(1);
	}
	function PM_ATagWrap($icon,$cmd,$bMark="")	{
		return $icon;
	}
	function wrapIcon($str,$val)	{
		if ($val["path"])	{
			$title = $GLOBALS["SOBE"]->localPath($val["path"]);
		}
		if ($val["uid"])	{
			$title = "[".$val["uid"]."]";
		}
		return substr($str,0,-1).' title="'.htmlspecialchars($title).'">';
	}
}
class printAllPageTree_perms extends printAllPageTree {
	function printTree($treeArr="",$printPath=0)	{
		$titleLen=intval($this->BE_USER->uc["titleLen"]);	
		
		$be_user_Array = t3lib_BEfunc::getUserNames();
		$be_group_Array = t3lib_BEfunc::getGroupNames();
		$lines=array();
		$lines[]='<tr bgColor="'.$GLOBALS["SOBE"]->doc->bgColor5.'">
			<td nowrap><strong>Page title:</strong></td>
			'.($printPath?'<td nowrap><strong>Path:</strong></td>':'').'
			<td nowrap colspan=2><strong>User:</strong></td>
			<td nowrap colspan=2><strong>Group: &nbsp;</strong></td>
			<td nowrap><strong>Everybody: &nbsp;</strong></td>
			<td nowrap><strong>This user: &nbsp;</strong></td>
			<td nowrap><strong>Main group:</strong></td>
		</tr>';

		if (!is_array($treeArr))	$treeArr=$this->tree;
		reset($treeArr);
		while(list($k,$v)=each($treeArr))	{
			$col1 = ' bgColor="'.t3lib_div::modifyHtmlColor($GLOBALS["SOBE"]->doc->bgColor4,+10,+10,+10).'"';
			$row = $v["row"];
			$title = t3lib_div::fixed_lgd(htmlspecialchars($row["title"]),$this->BE_USER->uc["titleLen"]);
			$lines[]='<tr bgColor="'.$GLOBALS["SOBE"]->doc->bgColor4.'">
				<td nowrap>'.$v["HTML"].$title.' &nbsp;</td>
				'.($printPath?'<td nowrap>'.htmlspecialchars(t3lib_BEfunc::getRecordPath ($row["pid"],"1",15)).' &nbsp;</td>':'').'
				<td nowrap'.$col1.'>'.$be_user_Array[$row["perms_userid"]]["username"].' &nbsp;</td>
				<td nowrap'.$col1.'>'.$this->ext_printPerms($row["perms_user"]).' &nbsp;</td>
				<td nowrap>'.$be_group_Array[$row["perms_groupid"]]["title"].' &nbsp;</td>
				<td nowrap>'.$this->ext_printPerms($row["perms_group"]).' &nbsp;</td>
				<td nowrap align=center '.$col1.'>'.$this->ext_printPerms($row["perms_everybody"]).' &nbsp;</td>
				<td nowrap align=center>'.$this->ext_printPerms($this->BE_USER->calcPerms($row)).' &nbsp;</td>
				<td nowrap align=center>'.$this->ext_printPerms($this->ext_groupPerms($row,$be_group_Array[$this->BE_USER->firstMainGroup])).' &nbsp;</td>
			</tr>';
		}
		return '<table border=0 cellpadding=0 cellspacing=0>'.implode("",$lines).'</table>';
	}
	function ext_printPerms($int)	{
		// Print a set of permissions
		$str="";
		$str.= (($int&1)?'*':'<font color="red">x</font>');
		$str.= (($int&16)?'*':'<font color="red">x</font>');
		$str.= (($int&2)?'*':'<font color="red">x</font>');
		$str.= (($int&4)?'*':'<font color="red">x</font>');
		$str.= (($int&8)?'*':'<font color="red">x</font>');
		
		return '<B><font color="green">'.$str.'</font></b>';
	}
	function ext_groupPerms($row,$firstGroup)	{
		// returns the permissions for a group based of the perms_groupid of $row. If the $row[perms_groupid] equals the $firstGroup[uid] then the function returns perms_everybody OR'ed with perms_group, else just perms_everybody
		if (is_array($row))	{
			$out=intval($row["perms_everybody"]);
			if ($row["perms_groupid"] && $firstGroup["uid"]==$row["perms_groupid"])	{
				$out|= intval($row["perms_group"]);
			}
			return $out;
		}
	}
}
class local_beUserAuth extends t3lib_beUserAuth {
	var $ext_pageIdsFromMounts="";
	var $ext_non_readAccessPageArray=array();

	function returnWebmounts($pClause="")	{
		$webmounts = (string)($this->groupData["webmounts"])!="" ? explode(",",$this->groupData["webmounts"]) : Array();
		$pClause=$pClause?$pClause:$this->getPagePermsClause(1);
		
		reset($webmounts);
		while(list($k,$id)=each($webmounts))	{
			$rec=t3lib_BEfunc::getRecord("pages",$id,"*"," AND ".$pClause);
			if (!is_array($rec))	{
				$this->ext_non_readAccessPageArray[$id]=t3lib_BEfunc::getRecord("pages",$id);
				unset($webmounts[$k]);
			}
		}
		return $webmounts;
	}
	function ext_non_readAccessPages()	{
		$lines=array();
		reset($this->ext_non_readAccessPageArray);
		while(list(,$pA)=each($this->ext_non_readAccessPageArray))	{
			if ($pA)	$lines[]=t3lib_BEfunc::getRecordPath($pA["uid"],1,15);
		}
		if (count($lines))	{
			return '<table bgcolor=red border=0 cellpadding=0 cellspacing=0><tr><td align=center><font color=white><strong>The user has no read access to these DB-mounts!</strong></font></td></tr><tr><td>'.implode('</td></tr><tr><td>',$lines).'</td></tr></table>';
		}
	}

	function user_where_clause()	{
			// This returns the where-clause needed to select the user with respect flags like deleted, hidden, starttime, endtime
		return  "AND pid=0 ";
	}

	function ext_printOverview($uInfo,$compareFlags,$printTrees=0)	{
			// Prepare for filemount and db-mount
		if ($printTrees)	{
			$className=t3lib_div::makeInstanceClassName("printAllPageTree");
			$foldertree = $pagetree = new $className($this,$this->returnWebmounts(),$this->returnFilemounts());
			if (!$this->isAdmin())	{
				$className=t3lib_div::makeInstanceClassName("printAllPageTree_perms");
				$pagetree = new $className($this,$this->returnWebmounts(),$this->returnFilemounts());
				$pagetree->addField("perms_user");
				$pagetree->addField("perms_group");
				$pagetree->addField("perms_everybody");
				$pagetree->addField("perms_userid");
				$pagetree->addField("perms_groupid");
			}
		} else {
			$className=t3lib_div::makeInstanceClassName("localPageTree");
			$pagetree = $foldertree = new $className($this,$this->returnWebmounts("1=1"),$this->returnFilemounts());
		}
//		$pagetree->script="index.php";
		$pagetree->backPath = $foldertree->backPath = $GLOBALS["BACK_PATH"];
		
		
	
			// Names for modules:
		$modNames = array(
			"web" => "Web",
			"web_layout" => "Page",
			"web_modules" => "Modules",
			"web_info" => "Info",
			"web_perms" => "Access",
			"web_func" => "Func",
			"web_list" => "List",
			"web_ts" => "Template",
			"file" => "File",
			"file_list" => "List",
			"file_images" => "Images",
			"doc" => "Doc.",
			"help" => "Help",
			"help_about" => "About",
			"help_quick" => "User manual",
			"help_welcome" => "Welcome",
			"user" => "User",
			"user_setup" => "Setup",
			"user_task" => "Task center"
		);
		
		
//debug($uInfo);
		reset($uInfo);
		$out=array();
		while(list($k,$v)=each($uInfo))	{
			if ($compareFlags[$k])	{
				switch($k)	{
					case "filemounts":
						$out[$k] = $foldertree->getBrowsableFolderTree();
					break;
					case "webmounts":
						$pagetree->addSelfId=1;
						$out[$k] = $this->ext_non_readAccessPages();
						$out[$k].= $pagetree->getBrowsableTree();
						$this->ext_pageIdsFromMounts=implode(",",array_unique($pagetree->ids));
					break;
					case "tempPath":
						$out[$k] = $GLOBALS["SOBE"]->localPath($v);
					break;
					case "pagetypes_select":
						$pageTypes = explode(",",$v);
						reset($pageTypes);
						while(list($kk,$vv)=each($pageTypes))	{
							$pageTypes[$kk]=$GLOBALS["LANG"]->sL(t3lib_BEfunc::getLabelFromItemlist("pages","doktype",$vv));
						}
						$out[$k] = implode("<BR>",$pageTypes);
					break;
					case "tables_select":
					case "tables_modify":
						$tables = explode(",",$v);
						reset($tables);
						while(list($kk,$vv)=each($tables))	{
							if ($vv)	{
								$tables[$kk]='<nobr>'.t3lib_iconWorks::getIconImage($vv,array(),$GLOBALS["BACK_PATH"],'align=top').$GLOBALS["LANG"]->sL($GLOBALS["TCA"][$vv]["ctrl"]["title"]).'</nobr>';
							}
						}
						$out[$k] = implode("<BR>",$tables);
					break;
					case "non_exclude_fields":
						$nef = explode(",",$v);
						reset($nef);
						$table="";
						$pout=array();
						while(list($kk,$vv)=each($nef))	{
							if ($vv)	{
								list($thisTable,$field) = explode(":",$vv);
								if ($thisTable!=$table)	{
									$table=$thisTable;
									t3lib_div::loadTCA($table);
									$pout[]='<nobr>'.t3lib_iconWorks::getIconImage($table,array(),$GLOBALS["BACK_PATH"],'align=top').$GLOBALS["LANG"]->sL($GLOBALS["TCA"][$table]["ctrl"]["title"]).'</nobr>';
								}
								if ($GLOBALS["TCA"][$table]["columns"][$field])	{
									$pout[]='<nobr> - '.ereg_replace(":$","",$GLOBALS["LANG"]->sL($GLOBALS["TCA"][$table]["columns"][$field]["label"])).'</nobr>';
								}
							}
						}
						$out[$k] = implode("<BR>",$pout);
					break;
					case "groupList":
					case "firstMainGroup":
						$uGroups = explode(",",$v);
						reset($uGroups);
						$table="";
						$pout=array();
						while(list($kk,$vv)=each($uGroups))	{
							if ($vv)	{
								$uGRow = t3lib_BEfunc::getRecord("be_groups",$vv);
								$pout[]='<tr><td nowrap>'.t3lib_iconWorks::getIconImage("be_groups",$uGRow,$GLOBALS["BACK_PATH"],'align=top')."&nbsp;".htmlspecialchars($uGRow["title"]).'&nbsp;&nbsp;</td><td width=1% nowrap>'.$GLOBALS["SOBE"]->elementLinks("be_groups",$uGRow).'</td></tr>';
							}
						}
						$out[$k] = '<table border=0 cellpadding=0 cellspacing=0 width=100%>'.implode("",$pout).'</table>';
					break;
					case "modules":
						$mods = explode(",",$v);
						reset($mods);
						$mainMod="";
						$pout=array();
						while(list($kk,$vv)=each($mods))	{
							if ($vv)	{
								list($thisMod,$subMod) = explode("_",$vv);
								if ($thisMod!=$mainMod)	{
									$mainMod=$thisMod;
									$pout[]='<nobr>'.($modNames[$mainMod]?$modNames[$mainMod]:$mainMod).'</nobr>';
								}
								if ($subMod)	{
									$pout[]='<nobr> - '.($modNames[$mainMod."_".$subMod]?$modNames[$mainMod."_".$subMod]:$mainMod."_".$subMod).'</nobr>';
								}
							}
						}
						$out[$k] = implode("<BR>",$pout);
					break;
					case "userTS":

						$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
						$tmpl->tt_track = 0;	// Do not log time-performance information
						
						$tmpl->fixedLgd=0;
						$tmpl->linkObjects=0;
						$tmpl->bType="";
						$tmpl->ext_expandAllNotes=1;
						$tmpl->ext_noPMicons=1;
						
						$out[$k] = $tmpl->ext_getObjTree($v,"","");
					break;
				}
			}
		}
		return $out;
	}
	function ext_getReadableButNonmounted()	{
		if (!$this->ext_pageIdsFromMounts)	{
			$this->ext_pageIdsFromMounts=0;
		}

		$be_user_Array = t3lib_BEfunc::getUserNames();
		$be_group_Array = t3lib_BEfunc::getGroupNames();

		$query = "SELECT pid,uid,title,media,layout,hidden,starttime,endtime,fe_group,extendToSubpages,doktype,perms_user,perms_group,perms_everybody,perms_userid,perms_groupid FROM pages WHERE uid NOT IN (".$this->ext_pageIdsFromMounts.") AND ".$this->getPagePermsClause(1).t3lib_BEfunc::deleteClause("pages");
//		debug($query);
		$res = mysql(TYPO3_db,$query);
		$dat=array();
		while($row=mysql_fetch_assoc($res))	{
			$dat[] = array(
				"row"=>$row,
				"HTML"=>t3lib_iconWorks::getIconImage("pages",$row,$GLOBALS["BACK_PATH"],'align=top title="['.$row["uid"].']"')	// .htmlspecialchars($row["title"])
			);
		}
		$className=t3lib_div::makeInstanceClassName("printAllPageTree_perms");
		$pp = new $className($this);
		return $pp->printTree($dat,1);
	}
	function ext_printPerms($int)	{
		// Print a set of permissions
		$str="";
		$str.= (($int&1)?'*':'<font color="red">x</font>');
		$str.= (($int&16)?'*':'<font color="red">x</font>');
		$str.= (($int&2)?'*':'<font color="red">x</font>');
		$str.= (($int&4)?'*':'<font color="red">x</font>');
		$str.= (($int&8)?'*':'<font color="red">x</font>');
		
		return '<B><font color="green">'.$str.'</font></b>';
	}
	function ext_groupPerms($row,$firstGroup)	{
		// returns the permissions for a group based of the perms_groupid of $row. If the $row[perms_groupid] equals the $firstGroup[uid] then the function returns perms_everybody OR'ed with perms_group, else just perms_everybody
		if (is_array($row))	{
			$out=intval($row["perms_everybody"]);
			if ($row["perms_groupid"] && $firstGroup["uid"]==$row["perms_groupid"])	{
				$out|= intval($row["perms_group"]);
			}
			return $out;
		}
	}
	function ext_compileUserInfoForHash()	{
		$uInfo=array();
			// Filemounts:
		$uInfo["filemounts"]=$this->ext_uniqueAndSortList(implode(",",array_keys($this->groupData["filemounts"])));

			// DBmounts:
		$uInfo["webmounts"]=$this->ext_uniqueAndSortList($this->groupData["webmounts"]);
		
			// Sharing Upload Folder
		$fileProcessor = t3lib_div::makeInstance("t3lib_basicFileFunctions");
		$fileProcessor->init($this->groupData["filemounts"], $GLOBALS["TYPO3_CONF_VARS"]["BE"]["fileExtensions"]);
		$uInfo["tempPath"] = $fileProcessor->findTempFolder();	// The closest TEMP-path is found
		
			// First Main Group:
		$uInfo["firstMainGroup"]=$this->firstMainGroup;

			// Group List:
//		$uInfo["groupList"]=$this->ext_uniqueAndSortList($this->groupList);
		$uInfo["groupList"]=$this->groupList;	// This gives a list that shows in which order the groups are processed. This may result in a list of groups which is similar to that of another user regarding which group but not the order of groups. For now, I believe it's most usefull to let separate orders of groups appear as different group settings for a user.

			// Page Types:
		$uInfo["pagetypes_select"]=$this->ext_uniqueAndSortList($this->groupData["pagetypes_select"]);

			// Tables select:
		$uInfo["tables_select"]=$this->ext_uniqueAndSortList($this->groupData["tables_select"].",".$this->groupData["tables_modify"]);

			// Tables modify:
		$uInfo["tables_modify"]=$this->ext_uniqueAndSortList($this->groupData["tables_modify"]);

			// Non-exclude fields:
		$uInfo["non_exclude_fields"]=$this->ext_uniqueAndSortList($this->groupData["non_exclude_fields"]);

			// Modules:
		$uInfo["modules"]=$this->ext_uniqueAndSortList($this->groupData["modules"]);
		
			// User TS:
		$this->ext_ksortArrayRecursive($this->userTS);
		$uInfo["userTS"] = $this->userTS;

		return $uInfo;
	}
	function ext_uniqueAndSortList($list)	{
		$uList=t3lib_div::trimExplode(",",$list,1);
		sort($uList);
		$uList=array_unique($uList);
		$uList=implode(",",$uList);
		return $uList;
	}
	function ext_ksortArrayRecursive(&$arr)	{
		krsort($arr);
		reset($arr);
		while(list($k,$v)=each($arr))	{
			if (is_array($v))	$this->ext_ksortArrayRecursive($arr[$k]);
		}
	}
}
class SC_mod_tools_be_user_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $include_once=array();
	var $content;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		$this->menuConfig();
		$this->switchUser(t3lib_div::GPvar("SwitchUser"));


		// **************************
		// Initializing
		// **************************
		$this->doc = t3lib_div::makeInstance("noDoc");
		$this->doc->form='<form action="" method="POST">';
		$this->doc->backPath = $BACK_PATH;
				// JavaScript
		$this->doc->JScode = '
		<script>
			script_ended = 0;
			function jumpToUrl(URL)	{
				document.location = URL;
			}
		</SCRIPT>
		';
	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// MENU-ITEMS:
			// If array, then it's a selector box menu
			// If empty string it's just a variable, that'll be saved. 
			// Values NOT in this array will not be saved in the settings-array for the module.
		$this->MOD_MENU = array(
			"function" => array(
				"compare" => "Compare User Settings"
			)
		);
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"], "ses");
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content="";
		$this->content.=$this->doc->startPage("Backend User Administration");
		
		$menu=t3lib_BEfunc::getFuncMenu(0,"SET[function]",$this->MOD_SETTINGS["function"],$this->MOD_MENU["function"]);
		
		$this->content.=$this->doc->header("Backend User Administration");
		$this->content.=$this->doc->spacer(5);
		$this->content.=$this->doc->section('',$menu).$this->doc->divider(5);
		
		switch($this->MOD_SETTINGS["function"])	{
			case "compare":
				if (t3lib_div::GPvar("ads"))	{
					$compareFlags = t3lib_div::GPvar("compareFlags");
					$BE_USER->pushModuleData("tools_beuser/index.php/compare",$compareFlags);
				} else {
					$compareFlags = $BE_USER->getModuleData("tools_beuser/index.php/compare","ses");
				}
				$this->content.=$this->compareUsers($compareFlags);
			break;
		}
		
		
		if ($BE_USER->mayMakeShortcut())	{
			$this->content.=$this->doc->spacer(20).
						$this->doc->section('',$this->doc->makeShortcutIcon("be_user_uid,compareFlags","function",$this->MCONF["name"]));
		}
	}
	function printContent()	{
		global $SOBE;
		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
	function compareUsers($compareFlags)	{
		global $SOBE;
			// Menu:
		$options = array(
			"filemounts" => "Filemounts",
			"webmounts" => "Webmounts",
			"tempPath" => "Default upload path",
			"firstMainGroup" => "Main user group",
			"groupList" => "Member of groups",
			"pagetypes_select" => "Page types access",
			"tables_select" => "Select tables",
			"tables_modify" => "Modify tables",
			"non_exclude_fields" => "Non-exclude fields",
			"modules" => "Modules",
			"userTS" => "TSconfig"
		);
		
		$be_user_uid = t3lib_div::GPvar("be_user_uid");
		if ($be_user_uid)	{
				// This is used to test with other users. Development ONLY!
			$tempBE_USER = t3lib_div::makeInstance("local_beUserAuth");	// New backend user object
			$tempBE_USER->OS = TYPO3_OS;
			$tempBE_USER->setBeUserByUid($be_user_uid);
			$tempBE_USER->fetchGroupData();
			
			$uInfo = $tempBE_USER->ext_compileUserInfoForHash();
			$uInfo_dat = $tempBE_USER->ext_printOverview($uInfo,$options,1);
			
			$lines=array();
			reset($options);
			while(list($kk,$vv)=each($options))	{
				if ($kk=="modules")	{
					$loadModules = t3lib_div::makeInstance("t3lib_loadModules");
					$loadModules->load($GLOBALS["TBE_MODULES"],$tempBE_USER);
					$alt_menuObj = t3lib_div::makeInstance("alt_menu_functions");
					$uInfo_dat[$kk] = $alt_menuObj->topMenu($loadModules->modules,1,$GLOBALS["BACK_PATH"]);
				}
				$lines[]='<tr bgColor="'.$this->doc->bgColor4.'">
					<td nowrap valign=top>'.$vv.':&nbsp;&nbsp;</td>
					<td>'.$uInfo_dat[$kk].'&nbsp;</td>
				</tr>';
				
				if ($kk=="webmounts" && !$tempBE_USER->isAdmin())	{
					$lines[]='<tr bgColor="'.$this->doc->bgColor4.'">
						<td nowrap valign=top>Non-mounted readable pages:&nbsp;&nbsp;</td>
						<td>'.$tempBE_USER->ext_getReadableButNonmounted().'&nbsp;</td>
					</tr>';
				}
			}
	
			$outTable = '<table border=0 cellpadding=1 cellspacing=1><tr bgcolor="'.$this->doc->bgColor5.'"><td>'.t3lib_iconWorks::getIconImage("be_users",$tempBE_USER->user,$GLOBALS["BACK_PATH"],'align=absmiddle title="'.$tempBE_USER->user["uid"].'"').$tempBE_USER->user["username"]."</td>";
			$outTable.= '<td>'.$tempBE_USER->user["realName"].($tempBE_USER->user["email"] ? ', <a href="mailto:'.$tempBE_USER->user["email"].'">'.$tempBE_USER->user["email"].'</a>' : "")."</td>";
			$outTable.= "<td>".$this->elementLinks("be_users",$tempBE_USER->user)."</td></tr></table>";
			$outTable.= '<strong><a href="index.php">< Back to overview</a></strong><BR>';
	
			$outTable.= '<BR><table border=0 cellpadding=2 cellspacing=1>'.implode("",$lines).'</table>';
			$content.= $this->doc->section('User info',$outTable,0,1);
		} else {	
			reset($options);
			$menu=array();
			while(list($kk,$vv)=each($options))	{
				$menu[]='<input type="checkbox" value="1" name="compareFlags['.$kk.']"'.($compareFlags[$kk]?" checked":"").'>'.htmlspecialchars($vv);
			}
			$outCode = "Group by:<BR>".implode("<BR>",$menu);
			$outCode.='<BR><input type="submit" name="ads" value="Update">';
			$content = $this->doc->section('Group and Compare Users',$outCode,0,1);
		
		
				// Traverse all users
			$users = t3lib_BEfunc::getUserNames();
			$comparation=array();
	//		debug($users);
			reset($users);
			$counter=0;
	
	
			$offset=0;
			$numberAtTime=1000;
			$tooManyUsers="";
	
	//$pt=t3lib_div::milliseconds();
			while(list(,$r)=each($users))	{
				if ($counter>=$offset)	{
						// This is used to test with other users. Development ONLY!
					$tempBE_USER = t3lib_div::makeInstance("local_beUserAuth");	// New backend user object
					$tempBE_USER->OS = TYPO3_OS;
					$tempBE_USER->setBeUserByUid($r["uid"]);
					$tempBE_USER->fetchGroupData();
			
						// Making group data
					$md5pre="";		
					$menu=array();
					$uInfo = $tempBE_USER->ext_compileUserInfoForHash();
					reset($options);
					while(list($kk,$vv)=each($options))	{
						if ($compareFlags[$kk])	{
							$md5pre.=serialize($uInfo[$kk])."|";
						}
					}
						// setting md5:
					$md5=md5($md5pre);
					if (!isset($comparation[$md5]))	{
						$comparation[$md5]=$tempBE_USER->ext_printOverview($uInfo,$compareFlags);
						$comparation[$md5]["users"]=array();
					}
					$comparation[$md5]["users"][]=$tempBE_USER->user;	//array("uid"=>$r["uid"],"username"=>$r["username"],"realName"=>$tempBE_USER->user["realName"],"email"=>$tempBE_USER->user["email"],"admin"=>$tempBE_USER->user["admin"]);
					unset($tempBE_USER);
				}
				$counter++;
				if ($counter>=($numberAtTime+$offset)) {
					$tooManyUsers="There were more than ".$numberAtTime." users (total: ".count($users).") and this tool can display only ".$numberAtTime." at a time!";
					break;
				}
			}
	//debug(t3lib_div::milliseconds()-$pt);
			
				// Print the groups:
			$allGroups=array();
				// Header:
			$allCells = array();
			reset($options);
			$allCells["USERS"] = "<B>Usernames:</B>";
			while(list($kk,$vv)=each($options))	{
				if ($compareFlags[$kk])	{
					$allCells[$kk] = "<B>".$vv.":</B>";
				}
			}
			$allGroups[]=$allCells;
				
			reset($comparation);
			while(list(,$dat)=each($comparation))	{
				$allCells = array();
				
				$uListArr=array();
				reset($dat["users"]);
				while(list(,$uDat)=each($dat["users"]))	{
					$uListArr[] = '<tr><td width="130">'.t3lib_iconWorks::getIconImage("be_users",$uDat,$GLOBALS["BACK_PATH"],'align=top title="'.$uDat["uid"].'"').$this->linkuser($uDat["username"],$uDat).'&nbsp;&nbsp;</td><td nowrap>'.$this->elementLinks("be_users",$uDat).
						'<a href="'.getenv("REQUEST_URI").'?&SwitchUser='.$uDat["uid"].'" target=_top><img src="'.$GLOBALS["BACK_PATH"].'gfx/su.gif" width="18" height="11" border="0" align=top title="'.htmlspecialchars("Switch User to: ".$uDat["username"]).'"></a>'.
						'</td></tr>';
				}
				$allCells["USERS"] = '<table border=0 cellspacing=0 cellpadding=0 width=100%>'.implode("",$uListArr).'</table>';
				
				reset($options);
				while(list($kk,$vv)=each($options))	{
					if ($compareFlags[$kk])	{
						$allCells[$kk] = $dat[$kk];
					}
				}
				$allGroups[]=$allCells;
			}
			
			
				// Make table
			$outTable="";
			reset($allGroups);
			$TDparams=' nowrap bgColor="'.$this->doc->bgColor5.'" valign=top';
			while(list(,$allCells)=each($allGroups))	{
				$outTable.='<tr><td'.$TDparams.'>'.implode('</td><td'.$TDparams.'>',$allCells).'</td></tr>';
				$TDparams=' nowrap bgColor="'.$this->doc->bgColor4.'" valign=top';
			}
			$outTable='<table border=0 cellpadding=2 cellspacing=2>'.$outTable.'</table>';
			$outTable.=fw('<BR><BR>(All cached group lists updated.)');
			$outTable.=$tooManyUsers?'<BR><BR><strong>'.rfw($tooManyUsers).'</strong>':'';
			$content.= $this->doc->spacer(10);
			$content.= $this->doc->section('Result',$outTable,0,1);
		}		
		return $content;
	}
	function linkUser($str,$rec)	{
		return '<a href="index.php?be_user_uid='.$rec["uid"].'">'.$str.'</a>';
	}
	function elementLinks($table,$row)	{
		global $TCA;
			// Info:
		$cells[]='<A HREF="#" onClick="top.launchView(\''.$table.'\', \''.$row["uid"].'\',\''.$GLOBALS["BACK_PATH"].'\'); return false;"><img src="'.$GLOBALS["BACK_PATH"].'gfx/zoom2.gif" width=12 height=12 border=0 align="top" title="Show information"></a>';
	
			// Edit:
		$params="&edit[".$table."][".$row["uid"]."]=edit";
		$cells[]='<A HREF="#" onClick="'.t3lib_BEfunc::editOnClick($params,$GLOBALS["BACK_PATH"],"",1).'"><img src="'.$GLOBALS["BACK_PATH"].'gfx/edit2.gif" width=11 height=12 border=0 align="top" title="Edit"></a>';
	
			// Hide:
		$hiddenField = $TCA[$table]["ctrl"]["enablecolumns"]["disabled"];
		if ($row[$hiddenField])	{
			$params="&data[".$table."][".$row["uid"]."][".$hiddenField."]=0";
			$cells[]='<A HREF="'.$this->doc->issueCommand($params).'"><img src="'.$GLOBALS["BACK_PATH"].'gfx/button_unhide.gif" width=11 height=10 border=0 title="Disable" align="top"></a>';
		} else {
			$params="&data[".$table."][".$row["uid"]."][".$hiddenField."]=1";
			$cells[]='<A HREF="'.$this->doc->issueCommand($params).'"><img src="'.$GLOBALS["BACK_PATH"].'gfx/button_hide.gif" width=11 height=10 border=0 title="Disable" align="top"></a>';
		}
	
			// Delete
		$params="&cmd[".$table."][".$row["uid"]."][delete]=1";
		$cells[]='<A HREF="'.$this->doc->issueCommand($params).'" onClick="return confirm(unescape(\''.rawurlencode("Are you sure, you want to delete this element?").'\'));"><img src="'.$GLOBALS["BACK_PATH"].'gfx/garbage.gif" width=11 height=12 border=0 align="top" title="Delete(!)"></a>';
		
		return implode("",$cells);
	}
	function initUsers()	{
			// Initializing all users in order to generate the usergroup_cached_list
		$users = t3lib_BEfunc::getUserNames();
		//debug($users);
		reset($users);
		while(list(,$r)=each($users))	{
				// This is used to test with other users. Development ONLY!
			$tempBE_USER = t3lib_div::makeInstance("local_beUserAuth");	// New backend user object
			$tempBE_USER->OS = TYPO3_OS;
			$tempBE_USER->setBeUserByUid($r["uid"]);
			$tempBE_USER->fetchGroupData();
		}
	}
	function localPath($str)	{
		if (substr($str,0,strlen(PATH_site))==PATH_site)	{
			return substr($str,strlen(PATH_site));
		} else return $str;
	}
	function switchUser($switchUser)	{
		$uRec=t3lib_BEfunc::getRecord("be_users",$switchUser);
		if (is_array($uRec) && $GLOBALS["BE_USER"]->isAdmin())	{
			$query = "UPDATE be_sessions SET ses_userid=".$uRec["uid"]." 
				WHERE ses_id='".$GLOBALS["BE_USER"]->id."' 
				AND ses_name='be_typo_user' 
				AND ses_userid='".$GLOBALS["BE_USER"]->user["uid"]."'";
			$res = mysql(TYPO3_db,$query);
			
			header("Location: ".$GLOBALS["BACK_PATH"]."index.php".($GLOBALS["TYPO3_CONF_VARS"]["BE"]["interfaces"]?"":"?commandLI=1"));
			exit;
		}
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/tools/be_user/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/tools/be_user/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_tools_be_user_index");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>