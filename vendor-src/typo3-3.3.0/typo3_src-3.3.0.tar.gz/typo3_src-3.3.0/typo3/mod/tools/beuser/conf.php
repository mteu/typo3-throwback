<?php
define("TYPO3_MOD_PATH", "mod/tools/beuser/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Administration of Backend Users";
$MLANG["default"]["tabs"]["tab"] = "User Admin";
$MLANG["default"]["tabs_images"]["tab"] = "beuser.gif";
$MLANG["default"]["labels"]["tabdescr"] = "The User Admin module provides you with an overview of all backend users. You can group them by their properties so you're able to monitor their permissions, filemounts, TSconfig, member groups etc.. This module is an indispensable tool in order to make sure the users are correctly configured.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Administration af Opdateringsbrugere";
$MLANG["dk"]["tabs"]["tab"] = "Brugere";
$MLANG["dk"]["labels"]["tabdescr"] = "'Brugere' modulet giver dig et overblik over alle opdateringsbrugere. Du kan gruppere dem efter deres egenskaber s� du er i stand til at overv�ge deres rettigheder, fildrev, TSconfig, medlemsgrupper osv. Dette modul er et uundv�rligt v�rkt�j n�r man skal v�re sikker p�, at brugere er korrekt konfigureret.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["labels"]["tablabel"] = "Administration der Backend Benutzer";
$MLANG["de"]["labels"]["tabdescr"] = "Das Benutzer Administrations-Modul bietet Ihnen eine �bersicht �ber alle vorhanden Benutzer des Typo3 Backends. Sie k�nnen diese Benutzer ihren Eigenschaften entsprechend gruppieren, deren Zugriffrechte, Dateifreigaben, Konfiguration, Gruppenzugeh�rigkeiten ansehen, usw. Dieses Modul ist ein unentbehrliches Hilfsmittel zur �berpr�fung und Festlegung der korrekten Benutzerkonfiguration.<BR><em>Zugriff nur f�r Administratoren!</em>";
$MLANG["de"]["tabs"]["tab"] = "Benutzer Administrator";

$MLANG["no"]["labels"]["tablabel"] = "Administrasjon av Oppdateringsbrukere";
$MLANG["no"]["labels"]["tabdescr"] = "'Brukere' modulen gir deg en oversikt over alle oppdateringsbrukerne. Du kan gruppere dem etter deres egenskaper slik at du er i stand til � overv�ke deres rettigheter, fildrev, TSconfig, medlemsgrupper osv. Dette er et uunnv�rlig verkt�y n�r man skal v�re sikker p� at brukerne er riktig konfigurert.<BR><em>Adgang kun for 'admin' brukere!</em>";
$MLANG["no"]["tabs"]["tab"] = "Brukere";

$MLANG["it"]["tabs"]["tab"] = "Utente Amministratore";
$MLANG["it"]["labels"]["tablabel"] = "Amministrazione utenti Backend";
$MLANG["it"]["labels"]["tabdescr"] = "Questo modulo offre una visione d'insieme degli utenti del backend (gli amministratori): potete raggrupparli in base ai loro attributi, in modo da analizzare i permessi, filemount, TSconfig, gruppi di appartenenza, etc. Questo modulo � indispensabile per assicurarsi che tutti gli account di amministrazione siano correttamente configurati. <br><em>Accesso riservato ai soli utenti 'admin'!</em>";

$MLANG["fr"]["labels"]["tablabel"] = "Administration des utilisateurs Backend";
$MLANG["fr"]["labels"]["tabdescr"] = "Ce module vous offre une vue d'ensemble sur les comptes utilisateur Backend. Ce module est indispensable, pour �tre s�re de bien avoir configuer tous les comptes.";
$MLANG["fr"]["tabs"]["tab"] = "Administration des utilisateurs";

$MLANG["pl"]["labels"]["tablabel"] = "Administracja u�ytkownikami";
$MLANG["pl"]["labels"]["tabdescr"] = "Modu� administracji u�ytkownikami umo�liwia przegl�danie listy u�ytkownik�w. Mo�na tu por�wnywa� u�ytkownik�w spe�niaj�cych zadane kryteria. Jest to pomocne przy monitorowaniu ich uprawnie�, dost�pu do plik�w, grup oraz czuwaniu nad prawid�ow� konfiguracj� u�ytkownik�w.<br><em>Dost�p tylko dla administrator�w!<em>";
$MLANG["pl"]["tabs"]["tab"] = "Administracja u�ytkownikami";

$MLANG["es"]["labels"]["tablabel"] = "Administraci�n de los usuarios de Backend";
$MLANG["es"]["labels"]["tabdescr"] = "El m�dulo de Administraci�n de usuarios le da un listado de todos los usuraios de backend. Los puede agrupar por sus propiedades para as� monitorear sus permisos, puntos de montaje de archivos, TSconfig, miembros de grupo etc. Este m�dulo es una herramienta indispensable para garantizar la correcta configuraci�n de los usuarios.<BR><em>�Acceso solamente para usuarios 'administrador'!</em>";
$MLANG["es"]["tabs"]["tab"] = "Administraci�n de usuarios";

$MLANG["si"]["labels"]["tablabel"] = "Administracija uporabnikov 'backend'a";
$MLANG["si"]["tabs"]["tab"] = "User Admin";
$MLANG["si"]["labels"]["tabdescr"] = "Modul za administracijo uporabnikov vam ponuja nadzor nad uporabniki programa. Lahko jih sortirate po zna�ilnostih. Spreminjate jim lahko privilegije, dostop do datotek, TSconfig, �lanstvo v skupinah itd. Ta modul je nepogre�ljivo orodje za administracijo.<BR><em>Uporaba dovoljena le 'admin' uporabnikom!</em>";

$MLANG["nl"]["labels"]["tablabel"] = "Administratie van de BeheerSitegebruikers";
$MLANG["nl"]["labels"]["tabdescr"] = "De Gebruikers Adminmodule biedt je een overzicht van de BeheerSitegebruikers. Je kan ze aan de hand van hun eigenschappen groeperen, zodat je toezicht kunt houden op hun rechten, startpunten, TSconfig, groepen van leden enz.... Deze module is een onmisbaar instrument. Zo kan je controleren of de gebruikers juist zijn geconfigureerd.<BR><em>Alleen toegang voor 'admin' gebruikers!</em>";
$MLANG["nl"]["tabs"]["tab"] = "Gebruikers Admin";

$MLANG["cz"]["labels"]["tablabel"] = "Administrace u�ivatel� backendu";
$MLANG["cz"]["labels"]["tabdescr"] = "Modul administrace u�ivatel� poskytuje p�ehled o v�ech u�ivatel�ch backendu. M��ete je seskupovat podle vlastnost�, abyste mohli monitorovat jejich p��stupov� pr�va, mounty soubor�, TSconfig, skupiny u�ivatel� atd. Tento modul je nepostradateln�, abyste si byli jisti, �e jsou u�ivatel� spr�vn� nakonfigurov�ni.<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";
$MLANG["cz"]["tabs"]["tab"] = "U�ivatel�";

$MLANG["fi"]["labels"]["tablabel"] = "Backend k�ytt�jien hallinta";
$MLANG["fi"]["labels"]["tabdescr"] = "User admin modulilla hallitaan backend k�ytt�ji�. N�m� k�ytt�j�t voidaan my�s ryhmitell� jotta eri toimintojesa seuranta helpottuu. Modulin v�ltt�m�tt�myys korostuu varmistautuessa k�ytt�jien asetuksien ja oikeuksia asianmukaisuudesta.<BR><em>Sallittu vain 'Admin'  k�ytt�jille.</em>";
$MLANG["fi"]["tabs"]["tab"] = "User Admin";

$MLANG["tr"]["labels"]["tablabel"] = "Arkaplan Kullan�c�lar�n�n Y�netimi ";
$MLANG["tr"]["tabs"]["tab"] = "Kullan�c� Y�netimi";
$MLANG["tr"]["labels"]["tabdescr"] = "Kullan�c� Y�netim mod�l� t�m arkaplan kullan�c�lar�na genel bir g�r�n�m sa�lar. Kullan�c�lar� �zellikleriyle grup yapabilirisiniz ki izinlerini, dosya mountlar�n�, TSkonfig�rasyonlar�n�, �ye gruplar�n� v.s.. g�r�nt�leyebilirsiniz. Bu mod�l komuttaki gerekli arac� ne yap�p edip do�ru bir �ekilde konfig�re edilmesini sa�lar.<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";


$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_beuser";
?>