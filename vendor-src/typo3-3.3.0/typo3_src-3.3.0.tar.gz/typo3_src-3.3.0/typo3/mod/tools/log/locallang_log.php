<?php
$LOCAL_LANG_LOG = Array (
	"default" => Array (
		"type_1" => "DB",
		"action_1_1" => "Insert",
		"action_1_2" => "Update",
		"action_1_3" => "Delete",
		"action_1_4" => "Move",
		"action_1_4" => "Check",
		
		"msg_1_0_1" => "Referer host '%s' and server host '%s' did not match!",
		"msg_1_1_11" => "Attempt to insert record on page '%s' (%s) where this table, %s, is not allowed",
		"msg_1_1_12" => "Attempt to insert a record on page '%s' (%s) from table '%s' without permissions. Or non-existing page.",
		"msg_1_2_1" => "Attempt to modify table '%s' without permission",
		"msg_1_2_2" => "Attempt to modify record '%s' (%s) without permission. Or non-existing page.",
		"msg_1_2_10" => "Record '%s' (%s) was updated.",
		"msg_1_2_12" => "MySQL error: '%s' (%s)",
		"msg_1_4_1" => "Attempt to move record '%s' (%s) to after a non-existing record (uid=%s)",
		"msg_1_4_2" => "Moved record '%s' (%s) to page '%s' (%s)",
		"msg_1_4_3" => "Moved record '%s' (%s) from page '%s' (%s)",
		"msg_1_4_4" => "Moved record '%s' (%s) on page '%s' (%s)",
		"msg_1_4_10" => "Attempt to move page '%s' (%s) to inside of its own rootline (at page '%s' (%s))",
		"msg_1_4_11" => "Attempt to insert record on page '%s' (%s) where this table, %s, is not allowed",
		"msg_1_4_12" => "Attempt to insert a record on page '%s' (%s) from table '%s' without permissions. Or non-existing page.",
		"msg_1_4_13" => "Attempt to move record '%s' (%s) to after another record, although the table has no sorting row.",
		"msg_1_4_14" => "Attempt to move record '%s' (%s) without having permissions to do so",
		"msg_1_5_1" => "You cannot change the 'doktype' of page '%s' to the desired value.",
		"msg_1_5_2" => "'doktype' of page '%s' could not be changed because the page contains records from disallowed tables; %s",
		"msg_1_5_3" => "Too few items in the list of values. (%s)",
		"msg_1_5_10" => "Could not delete file '%s' (does not exist). (%s)",
		"msg_1_5_11" => "Copying file '%s' failed!: No destination file (%s) possible!. (%s)",
		"msg_1_5_12" => "Fileextension '%' not allowed. (%s)",
		"msg_1_5_13" => "Filesize (%s) of file '%s' exceeds limit (%s). (%s)",
		"msg_1_5_14" => "The destination (%s) or the source file (%s) does not exist. (%s)",
		"msg_1_5_15" => "Copying to file '%s' failed! (%s)",
		"msg_1_5_16" => "Copying file '%s' failed!: The destination path (%s) may be write protected. Please make it write enabled!. (%s)",
		
		"type_2" => "FILE",
		"action_2_1" => "Upload",
		"action_2_2" => "Copy",
		"action_2_3" => "Move",
		"action_2_4" => "Delete",
		"action_2_5" => "Rename",
		"action_2_6" => "New",
		"action_2_7" => "Unzip",
		"action_2_8" => "New file",
		"action_2_9" => "Edit",
		
		"msg_2_9_1" => "File saved to '%s', bytes: %s, MD5: %s ",


		"type_254" => "SETTING",
		"action_254_1" => "Change",

		"type_255" => "LOGIN",
		"action_255_1" => "LOGIN",
		"action_255_2" => "LOGOUT",
		"action_255_3" => "ATTEMPT"
	),
	"dk" => Array (
		"msg_1_2_10" => "Elementet '%s' ('%s:%s') er opdateret.",
		"msg_2_9_1" => "Fil '%s' gemt, bytes: %s, MD5: %s "
	),
	"de" => Array (
	),
	"no" => Array (
	),
	"it" => Array (
		"type_1" => "DB",

		"type_2" => "File",
		"action_2_1" => "Invia",
		"action_2_2" => "Copia",
		"action_2_3" => "Muovi",
		"action_2_4" => "Cancella",
		"action_2_5" => "Rinomina",
		"action_2_6" => "Nuovo",
		"action_2_7" => "Unzip",

		"type_254" => "Configurazione",
		"action_254_1" => "Cambio",

		"type_255" => "Login",
		"action_255_1" => "Login",
		"action_255_2" => "Uscita",
		"action_255_3" => "Tentativo"
	),
	"fr" => Array (
	),
	"es" => Array (
	),
	"nl" => Array (
	),
	"cz" => Array (
		"type_1" => "DB",
		"action_1_1" => "Vlo�en�",
		"action_1_2" => "Aktualizace",
		"action_1_3" => "Odstran�n�",
		"action_1_4" => "P�esun",
		"action_1_4" => "Kontrola",
		"msg_1_2_10" => "Z�znam '%s' (%s) byl aktualizov�n.",

		"type_2" => "SOUBOR",
		"action_2_1" => "Upload",
		"action_2_2" => "Kopie",
		"action_2_3" => "P�esun",
		"action_2_4" => "Odstran�n�",
		"action_2_5" => "P�ejmenov�n�",
		"action_2_6" => "Nov�",
		"action_2_7" => "Unzip",

		"type_254" => "NASTAVEN�",
		"action_254_1" => "Zm�na",

		"type_255" => "LOGIN",
		"action_255_1" => "LOGIN",
		"action_255_2" => "LOGOUT",
		"action_255_3" => "POKUS"
	),
	"pl" => Array (
		"title" => "Log systemu",
		
		
		"type_1" => "DB",
		"action_1_1" => "Wstawienie",
		"action_1_2" => "Aktualizacja",
		"action_1_3" => "Usuni�cie",
		"action_1_4" => "Przeniesienie",
		"action_1_4" => "Sprawdzenie",
		"msg_1_2_10" => "Rekord '%s' (%s) zosta� zmieniony.",

		"type_2" => "FILE",
		"action_2_1" => "Upload",
		"action_2_2" => "Kopiowanie",
		"action_2_3" => "Przeniesienie",
		"action_2_4" => "Usuni�cie",
		"action_2_5" => "Zmiana nazwy",
		"action_2_6" => "Stworzenie nowego",
		"action_2_7" => "Rozpakowanie",

		"type_254" => "SETTING",
		"action_254_1" => "Zmiana",

		"type_255" => "LOGIN",
		"action_255_1" => "LOGIN",
		"action_255_2" => "LOGOUT",
		"action_255_3" => "PR�BA"
	),
    "si" => Array (
		"title" => "Sistemski dnevnik",

		"type_1" => "BAZA",
		"action_1_1" => "Vstavi",
		"action_1_2" => "Posodobi",
		"action_1_3" => "Bri�i",
		"action_1_4" => "Premakni",
		"action_1_4" => "Preveri",
		"msg_1_2_10" => "Zapis '%s' (%s) je bil posodobljen.",

		"type_2" => "DATOTEKA",
		"action_2_1" => "Prenesi",
		"action_2_2" => "Kopiraj",
		"action_2_3" => "Premakni",
		"action_2_4" => "Bri�i",
		"action_2_5" => "Preimenuj",
		"action_2_6" => "Nova",
		"action_2_7" => "Unzip",

		"type_254" => "NASTAVITVE",
		"action_254_1" => "Spremeni",

		"type_255" => "PRIJAVA",
		"action_255_1" => "PRIJAVA",
		"action_255_2" => "ODJAVA",
		"action_255_3" => "POSKUS"
	),
	"tr" => Array (
		"type_1" => "VB",
		"action_1_1" => "Ekle",
		"action_1_2" => "G�ncelle",
		"action_1_3" => "Sil",
		"action_1_4" => "Ta��",
		"action_1_4" => "Kontrol et",
		
		"msg_1_0_1" => "Referer host '%s' ve sunucu host '%s' e�le�tirilemedi!",
		"msg_1_1_11" => "Sayfa �zerinde kay�t eklemeyi dene '%s' (%s) bu tablonun, %s, izin verilmedi�i aral�kta",
		"msg_1_1_12" => "Sayfa �zerinde bir kay�t eklemeyi dene '%s' (%s) tablodan '%s' izinsiz. Veya sayfa var olmaks�z�n.",
		"msg_1_2_1" => "Tabloyu modifiye etmeyi dene '%s' izinsiz",
		"msg_1_2_2" => "Kay�t� modifiye etmeyi dene '%s' (%s) izinsiz. Veya sayfa var olmaks�z�n.",
		"msg_1_2_10" => "Kay�t '%s' (%s) g�ncellendi.",
		"msg_1_2_12" => "MySQL hata: '%s' (%s)",
		"msg_1_4_1" => "Kay�t� ta��may� dene '%s' (%s) sonraki var olmayan kay�ta (uid=%s)",
		"msg_1_4_2" => "Kay�t ta��nd� '%s' (%s) sayfaya '%s' (%s)",
		"msg_1_4_3" => "Kay�t ta��nd� '%s' (%s) sayfadan '%s' (%s)",
		"msg_1_4_4" => "Kay�t ta��nd� '%s' (%s) sayfa �zerine '%s' (%s)",
		"msg_1_4_10" => "Sayfay� ta��may� dene '%s' (%s) kendi k�k�izgisinin i�ine (sayfada '%s' (%s))",
		"msg_1_4_11" => "Sayfa �zerinde kay�t eklemeyi dene '%s' (%s) bu tablonun, %s, izin verilmedi�i aral�kta",
		"msg_1_4_12" => "Sayfa �zerinde bir kay�t eklemeyi dene '%s' (%s) tablodan '%s' izinsiz. Veya sayfa var olmaks�z�n.",
		"msg_1_4_13" => "Kay�t� ta��may� dene '%s' (%s) sonraki ba�ka kay�ta, yine de tablo sat�r� olmadan.",
		"msg_1_4_14" => "Kay�t� ta��may� dene '%s' (%s) bunu yapmay� sa�layan izinlere sahip olmadan",
		"msg_1_5_1" => "doktype' sayfas�n�n arzu edilen de�erini'%s' de�i�tiemezsiniz.",
		"msg_1_5_2" => "'doktype' sayfas� '%s' de�i�tirilemez ��nk� sayfa i�erik kay�tlar� izin al�nmayan tablolardan sa�lan�yor; %s",
		"msg_1_5_3" => "De�erlerin listelenmesinde �ok az nesne var. (%s)",
		"msg_1_5_10" => "Silinemeyen dosya '%s' (mevcut de�il). (%s)",
		"msg_1_5_11" => "Kopyalanan dosya '%s' hatal�!: Herhangi bir hedef dosya (%s) olanakl� de�il!. (%s)",
		"msg_1_5_12" => "Dosya uzant�s� '%' izin verilmedi. (%s)",
		"msg_1_5_13" => "Dosya ebat� (%s) dosyan�n '%s' limitini a��yor (%s). (%s)",
		"msg_1_5_14" => "Hedef (%s) veya kaynak dosya (%s) mevcut de�il. (%s)",
		"msg_1_5_15" => "Kopyalanan dosya '%s' hatal�! (%s)",
		"msg_1_5_16" => "Kopyalanan dosya '%s' hatal�!: Hedef yolu (%s) yazmaya kar�� korumal� olabilir. L�tfen yaz�labilir duruma �evirin!. (%s)",
		
		"type_2" => "DOSYA",
		"action_2_1" => "Y�kleme",
		"action_2_2" => "Kopyala",
		"action_2_3" => "Ta��",
		"action_2_4" => "Sil",
		"action_2_5" => "Yeniden adland�r",
		"action_2_6" => "Yeni",
		"action_2_7" => "S�k��t�r�lm�� dosyay� a�",
		"action_2_8" => "Yeni dosya",
		"action_2_9" => "D�zenle",
		
		"msg_2_9_1" => "Dosyay� kaydet '%s', bytelara: %s, MD5: %s ",
		
		
		"type_254" => "AYAR",
		"action_254_1" => "De�i�tir",
		
		"type_255" => "G�R��",
		"action_255_1" => "G�R��",
		"action_255_2" => "�IKI�",
		"action_255_3" => "DENE"
	)
);
?>