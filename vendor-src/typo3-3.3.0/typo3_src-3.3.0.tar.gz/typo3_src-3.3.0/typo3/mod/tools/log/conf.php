<?php
define("TYPO3_MOD_PATH", "mod/tools/log/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Viewing log";
$MLANG["default"]["tabs"]["tab"] = "Log";
$MLANG["default"]["tabs_images"]["tab"] = "log.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Allows you access to the full backend changelog in Typo3.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Log-visning";
$MLANG["dk"]["tabs"]["tab"] = "Log";
$MLANG["dk"]["labels"]["tabdescr"] = "Giver dig mulighed for at se den komplette opdateringslog i Typo3.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["labels"]["tablabel"] = "Log-Ansicht";
$MLANG["de"]["tabs"]["tab"] = "Log";
$MLANG["de"]["labels"]["tabdescr"] = "Gibt Ihnen Zugriff zu der kompletten Typo3 �nderungsprotokollierung.<BR><em>Zugriff nur durch Administratoren!</em>";

$MLANG["no"]["labels"]["tablabel"] = "Logg-visning";
$MLANG["no"]["tabs"]["tab"] = "Logg";
$MLANG["no"]["labels"]["tabdescr"] = "Gir deg mulighet til � se den komplette oppdateringsloggen i Typo3.<BR><em>Adgang kun for 'admin' brukere!</em>";

$MLANG["it"]["labels"]["tablabel"] = "Mostra log";
$MLANG["it"]["tabs"]["tab"] = "Log";
$MLANG["it"]["labels"]["tabdescr"] = "Accesso a tutto il log dei cambiamenti dell'amministrazione di Typo3. <br><em>Accesso riservato solo agli utenti di tipo 'admin'!</em>";

$MLANG["fr"]["labels"]["tablabel"] = "Visualisation du fichier journal";
$MLANG["fr"]["tabs"]["tab"] = "Fichier journal";
$MLANG["fr"]["labels"]["tabdescr"] = "Vous pouvez acc�der depuis ici � tous les fichiers journaux de Typo3.<br><em>Acc�s pour l'Administrateur uniquement</em>";

$MLANG["es"]["labels"]["tablabel"] = "Bit�cora de visitas";
$MLANG["es"]["tabs"]["tab"] = "Bit�cora";
$MLANG["es"]["labels"]["tabdescr"] = "Permite acceder a la bit�cora completa del backend de Typo3.<BR><em>�Acceso solamente para 'administradores'!</em>";

$MLANG["nl"]["labels"]["tablabel"] = "Toon log";
$MLANG["nl"]["tabs"]["tab"] = "Log";
$MLANG["nl"]["labels"]["tabdescr"] = "Geeft je toegang tot het log van wijzigingen voor de BeheerSite van Typo3.<BR><em>Alleen toegang voor 'admin' gebruikers!</em>";

$MLANG["cz"]["labels"]["tablabel"] = "Uk�zat log";
$MLANG["cz"]["tabs"]["tab"] = "Log";
$MLANG["cz"]["labels"]["tabdescr"] = "Umo��uje p�istoupit k z�znamu zm�n v backendu v Typo3.<br><em>P��stup pouze pro 'admin' u�ivatele!</em>";

$MLANG["pl"]["labels"]["tablabel"] = "Poka� logi";
$MLANG["pl"]["tabs"]["tab"] = "Log";
$MLANG["pl"]["labels"]["tabdescr"] = "Dost�p do logu systemowego Typo3.<br><em>Dost�p tylko dla administrator�w!<em>";

$MLANG["si"]["labels"]["tablabel"] = "Ogled dnevnika";
$MLANG["si"]["tabs"]["tab"] = "Dnevnik";
$MLANG["si"]["labels"]["tabdescr"] = "Dnevnik sprememb v Typo3 'backendu'.<BR><em>Uporaba dovoljena le 'admin' uporabnikom!</em>";

$MLANG["fi"]["labels"]["tablabel"] = "Katsele lokia";
$MLANG["fi"]["labels"]["tabdescr"] = "T��lt� on mahdollisuus katsella Typo3n backend lokia.<BR><em>P��sy vain 'Admin' k�ytt�jille !</em>";
$MLANG["fi"]["tabs"]["tab"] = "Loki";

$MLANG["tr"]["labels"]["tablabel"] = "Log un g�sterilmesi";
$MLANG["tr"]["tabs"]["tab"] = "Log";
$MLANG["tr"]["labels"]["tabdescr"] = "Typo3 i�inde t�m arkaplan log de�i�ikliklerinin eri�imine izin verir.<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";


$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_log";
?>