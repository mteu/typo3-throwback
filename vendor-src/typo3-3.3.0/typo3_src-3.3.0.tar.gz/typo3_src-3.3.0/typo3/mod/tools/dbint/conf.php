<?php
define("TYPO3_MOD_PATH", "mod/tools/dbint/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Database integrity check";
$MLANG["default"]["tabs"]["tab"] = "DB check";
$MLANG["default"]["tabs_images"]["tab"] = "db.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Here you can check the integrity of the database tables configured by the \$TCA. For instance all records must belong to a page record. In addition the existence of uploaded files attached to records (normally residing in uploads/* folders) are verified as well. You can also get a view of the total pagetree including deleted pages. Finally you've got access to a global database search facility.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Database integritets check";
$MLANG["dk"]["tabs"]["tab"] = "DB check";
$MLANG["dk"]["labels"]["tabdescr"] = "Her kan du verificere integriteten af databasetabellerne konfigureret med \$TCA. For eksempel skal alle elementer tilh�re et side-element. Derudover bliver det unders�gt om filer, tilknyttet databaseelementer eksisterer (normalt beliggende i uploads/* mappen). Du kan ogs� f� et totaloverblik over sidetr�et inklusiv slettede sider. Endeligt har du adgang til en overordnet databases�gningsfunktion.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["labels"]["tablabel"] = "Databank Integrit�ts-Check";
$MLANG["de"]["labels"]["tabdescr"] = "Hier kann die Integrit�t der Datenbanktabellen, welche von \$TCA angelegt wurden, �berpr�ft werden. Zum Beispiel m�ssen alle Datens�tze zu einer Seite geh�ren. Zus�tzlich wird die Existenz von mit Datens�tzen verkn�pften hochgeladenen Dateien �berpr�ft (diese liegen normalerweise im Verzeichnis uploads/*). Es kann ebenfalls die komplette Seitenstruktur, inklusive gel�schter Seiten, angezeigt werden. Abschlie�end haben Sie noch Zugriff zu einer globalen Datenbank-Suchfunktion.<BR><em>Zugriff nur f�r Administratoren!</em>";
$MLANG["de"]["tabs"]["tab"] = "DB �berpr�fung";

$MLANG["no"]["labels"]["tablabel"] = "Database integritets sjekk";
$MLANG["no"]["tabs"]["tab"] = "DB check";
$MLANG["no"]["labels"]["tabdescr"] = "Her kan du verifisere integriteten for databasetabellene som er konfigurert med \$TCA. For eksempel skal alle elementer tilh�re et sideelement. Utover dette blir det kontrollert om filer tilknyttet databaseelementer eksisterer (normalt ligger disse i uploads/* mappen). Du kan ogs� f� en totaloversikt over sidetreet inklusive slettede sider. Videre har du adgang til en overordnet databases�kfunksjon.<BR><em>Adgang kun for 'admin' brukere!</em>";

$MLANG["it"]["labels"]["tablabel"] = "Controllo integrita' database";
$MLANG["it"]["tabs"]["tab"] = "Controllo Database";
$MLANG["it"]["labels"]["tablabel"] = "In questo modulo potete controllare l'integrit� delle tabelle del database configurate da \$TCA. Per esempio, viene controllato che ogni record appartenga ad una pagina, e che tutti i file inviati sul server siano effettivamente presenti (di solito nelle sottocartelle di uploads/*. E' inoltre presente l'intero albero delle pagine (comprese quelle cancellate). Potete anche ricercare un termine all'interno di tutto il database.<br><em>Accesso riservato ai soli utenti 'admin'!</em>";

$MLANG["fr"]["labels"]["tablabel"] = "V�rification de l'int�grit� de la base de donn�es";
$MLANG["fr"]["tabs"]["tab"] = "V�rification BD";
$MLANG["fr"]["labels"]["tabdescr"] = "Ici, vous pouvez contr�ler l'int�grit� de la base de donn�es, selon le \$TCA. Pour l'instant, tous les enregistrements doivent correspondre � une page. Les fichiers Uploder orphelins sont eux aussi contr�l�.";

$MLANG["es"]["labels"]["tablabel"] = "Verificaci�n de la integridad de la base de datos";
$MLANG["es"]["tabs"]["tab"] = "Verificaci�n BD";
$MLANG["es"]["labels"]["tabdescr"] = "Aqu� puede verificar la integridad de las tablas de la base de datos configuradas mendiante \$TCA. Por ejemplo, todos los registros deben pertenecer a un registro de p�gina. As� mismo la existencia de archivos enviados anexados a registros (normamente en el directorio uploads/*) tambi�n se verifican. Tambi�n obtiene una vista del �rbol de p�ginas incluyendo las p�ginas eliminadas. Finalmente tiene acceso a una herramienta de b�squeda global.<BR><em>�Acceso solamente a usuarios 'admin'</em>";

$MLANG["nl"]["labels"]["tablabel"] = "Integriteitscontrole van de database";
$MLANG["nl"]["tabs"]["tab"] = "DB controle";
$MLANG["nl"]["labels"]["tabdescr"] = "Hier kan je de integriteit van de databasetabellen controleren geconfigureerd door de \$TCA. Zo moeten bijvoorbeeld records gekoppeld zijn aan een paginarecord. Bovendien wordt de aanwezigheid van de geuploade bestanden (normaal gesproken gevonden in de map uploads/*) gekoppeld aan records ook geverifieerd. Je kan ook een totaaloverzicht van de totale paginastruktuur inclusief verwijderde pagina's opvragen. Tenslotte heb je de mogelijkheid de totale database te doorzoeken.<BR><em>Alleen toegang voor 'admin' gebruikers!</em>";

$MLANG["cz"]["labels"]["tablabel"] = "Kontrola integrity datab�ze";
$MLANG["cz"]["tabs"]["tab"] = "DB kontrola";
$MLANG["cz"]["labels"]["tabdescr"] = "Zde m��ete kontroloavat integritu datab�zov�ch tabulek konfigurovan�ch v \$TCA. Nap��kal v�echny z�znamy mus� pat�it k z�znamu strany. Nav�c je ov��ena i existence z�znam� pro uploadovan� soubory p�i�azen� k z�znam�m (norm�ln� v uploads/* slo�k�ch). Tak� m��ete vid�t celkov� strom v�etn� odstran�n�ch str�nek. Tak� m�te p��stup ke glob�ln�mu vyhled�v�n�.<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";

$MLANG["pl"]["labels"]["tablabel"] = "Kontrola integralno�ci bazy";
$MLANG["pl"]["labels"]["tabdescr"] = "Tutaj mo�esz sprawdzi� poprawno�� tabel bazy danych ze wzorem zawartym w \$TCA. Dla przyk�adu, wszystkie rekordy musz� nale�e� do jakiej� strony. Ponadto pliki uploadowane do katalog�w uploads/* musz� mie� powi�zanie z odpowiednim rekordem, co r�wnie� jest kontrolowane. Opr�cz tego mo�esz tu zobaczy� i przeszuka� ca�� struktur� witryny, ��cznie ze stronami usuni�tymi.<br><em>Dost�p tylko dla administrator�w!<em>";
$MLANG["pl"]["tabs"]["tab"] = "Kontrola bazy";

$MLANG["si"]["labels"]["tablabel"] = "Preverjanje integritete baze podatkov";
$MLANG["si"]["tabs"]["tab"] = "Preverjanje baze";
$MLANG["si"]["labels"]["tabdescr"] = "Tukaj lahko preverite integriteto tabel, konfiguriranih v \$TCA. Primer: vsi zapisi morajo pripadati neki strani. Preverite lahko tudi obstoj poslanih datotek, pripetih k zapisom (ponavadi so v uploads/* mapah). Na voljo je �e ogled celotnega drevesa strani, vklju�no z izbrisanimi. Nazadnje je tu tudi globalni iskalnik po podatkovni bazi.<BR><em>Uporaba je dovoljena le 'admin' uporabnikom!</em>";

$MLANG["fi"]["labels"]["tablabel"] = "Tietokannan eheyden tarkistus";
$MLANG["fi"]["labels"]["tabdescr"] = "T��lt� voit tarkistaa tietokannan taulujen eheyden kuten se on ohjelmoitu \$TCA lla. Esim. kaikkien tietuiden tulee kuulua johonkin sivuun. My�s palvelimelle tuotujen tiedostojen kuuluminen tietueille tarkistetaan. N�et my�s koko sivu rakenteen poistetut sivut mukaan lukien. Lis�ksi p��set globaaliin tietokanta hakuun.<BR><em>P��sy vain 'Admin' k�tt�jille!</em>";
$MLANG["fi"]["tabs"]["tab"] = "DB tarkistus";

$MLANG["tr"]["labels"]["tablabel"] = "Veritaban� b�t�nl���n�n kontrolu";
$MLANG["tr"]["tabs"]["tab"] = "VB kontrol";
$MLANG["tr"]["labels"]["tabdescr"] = "\$TCA taraf�ndan konfig�re edilen veritaban� tablolar�n�n b�t�nl���n� buradan kontrol edebilirsiniz. �rne�in, t�m kay�tlar kesinlikle sayfa kay�t�na aittir. Buna ek olarak kay�tlarla ili�kili y�klenen dosyalar�n (normal olarak y�klemeler i�ine ba�lan�yor/* klas�rler) varl���da kan�tlanm�� olur. Birde toplam sayfa a�ac�n�n g�r�nt�lenmesi silinen sayfalar� i�eriyor. Son olarak global veritaban� ara�t�rma servisine eri�mi� oluyorsunuz.<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";



$MCONF["script"]="index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_dbint";
?>