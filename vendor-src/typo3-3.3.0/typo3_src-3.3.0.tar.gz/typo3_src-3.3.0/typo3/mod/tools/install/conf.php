<?php
define("TYPO3_MOD_PATH", "mod/tools/install/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Install Tool";
$MLANG["default"]["tabs"]["tab"] = "Install";
$MLANG["default"]["tabs_images"]["tab"] = "install.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Provides a simple link to the Install Tool. Notice the Install Tool (in typo3/install/) must be enabled.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Install Tool";
$MLANG["dk"]["tabs"]["tab"] = "Installation";
$MLANG["dk"]["labels"]["tabdescr"] = "Dette er et simpelt link til installations-v�rkt�jet (Install Tool). V�r opm�rksom p�, at 'Install Tool' (ligger i typo3/install/) skal v�re sl�et til.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["no"]["labels"]["tablabel"] = "Install Tool";
$MLANG["no"]["labels"]["tabdescr"] = "Dett er en enkel link til installasjonsverkt�yet (Install Tool). V�r oppmerksom p� at 'Install Tool' (ligger i typo3/install/) m� v�re aktivert.<BR><em>Adgang kun for 'admin' brukere!</em>";
$MLANG["no"]["tabs"]["tab"] = "Installasjon";

$MLANG["de"]["labels"]["tablabel"] = "Installations-Tool";
$MLANG["de"]["labels"]["tabdescr"] = "Bietet einen simplen Verweis auf das Installations-Werkzeug. Zu beachten ist, dass das Installations-Werkzeug (in typo3/install/) aktiviert seien muss.<BR><em>Zugriff nur f�r Administratoren!</em>";
$MLANG["de"]["tabs"]["tab"] = "Installation";

$MLANG["it"]["labels"]["tablabel"] = "Tool di installazione";
$MLANG["it"]["labels"]["tabdescr"] = "Link verso il tool di installazione (che deve essere attivato, in typo3/install/)<br><em>Accesso riservato ai soli utenti 'admin'!</em>";
$MLANG["it"]["tabs"]["tab"] = "Installa";

$MLANG["fr"]["labels"]["tablabel"] = "Assistant d'installation";
$MLANG["fr"]["labels"]["tabdescr"] = "Liaison simple avec l'assistant d'installation. Notez que cette assistant doit �tre activ� manuellement.";
$MLANG["fr"]["tabs"]["tab"] = "Installation";

$MLANG["pl"]["labels"]["tablabel"] = "Narz�dzie instalacyjne";
$MLANG["pl"]["labels"]["tabdescr"] = "Udost�pnia szybkie wywo�anie narz�dzia instalacyjnego, pod warunkiem, �e jest w��czone. <br><em>Dost�p tylko dla administrator�w!<em>";
$MLANG["pl"]["tabs"]["tab"] = "Instalacja";

$MLANG["es"]["labels"]["tablabel"] = "Herramienta de Instalaci�n";
$MLANG["es"]["labels"]["tabdescr"] = "Proporciona una liga sencilla a la liga de instalaci�n. Nota: la herramienta de instalaci�n (in typo3/install/) debe estar habilitada.<BR><em>�Acceso solamente para usuarios 'administrador'!</em>";
$MLANG["es"]["tabs"]["tab"] = "Instalar";

$MLANG["si"]["labels"]["tablabel"] = "Orodje za in�talacijo";
$MLANG["si"]["tabs"]["tab"] = "In�talacija";
$MLANG["si"]["labels"]["tabdescr"] = "Dostop do orodja za in�talacijo (typo3/install/) mora biti posebej omogo�en.<BR><em>Uporaba je dovoljena le 'admin' uporabnikom!</em>";

$MLANG["nl"]["labels"]["tablabel"] = "Installatie Werkset";
$MLANG["nl"]["labels"]["tabdescr"] = "Biedt een link naar de Installatie Werkset. Denk er aan dat het Install Gereedschap (in/typo3/install/) geactiveerd dient te zijn.<BR><em>Alleen toegang voor 'admin' gebruikers!</em>";
$MLANG["nl"]["tabs"]["tab"] = "Installatie";

$MLANG["cz"]["labels"]["tablabel"] = "Instala�n� pom�cka";
$MLANG["cz"]["labels"]["tabdescr"] = "POskytuje jednoduch� odkaz na instala�n� pom�cku. Uv�domte si, �e instala�n� pom�cka (v typo3/install) mus� b�t aktivov�na.<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";
$MLANG["cz"]["tabs"]["tab"] = "Instalace";

$MLANG["fi"]["labels"]["tablabel"] = "Asennus ty�kalu";
$MLANG["fi"]["labels"]["tabdescr"] = "Tarkoituksen mukainen linkki Typo3 asennukselle. Huomattavaa on ett� ty�kalu on asennettu ja k�ytett�viss�.  <BR><em>Sallittu vain 'Admin'  k�ytt�jille.</em> ";
$MLANG["fi"]["tabs"]["tab"] = "Asenna";

$MLANG["tr"]["labels"]["tablabel"] = "Kurulum Arac�";
$MLANG["tr"]["tabs"]["tab"] = "Kurulum";
$MLANG["tr"]["labels"]["tabdescr"] = "Kurulum Arac�na basit link sa�lar. Kurulum Arac�n�n (typo3/install un i�inde/) �al���r durumda oldu�undan mutlaka emin olun.<BR><em>Sadece kullan�c�lar�n  'y�netim' i�in ge�i�i!</em>";



$MCONF["script"]="../../../install/index.php";
$MCONF["access"]="admin";
$MCONF["name"]="tools_install";
?>