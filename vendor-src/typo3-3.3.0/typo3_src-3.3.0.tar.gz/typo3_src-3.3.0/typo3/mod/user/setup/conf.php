<?php
define("TYPO3_MOD_PATH", "mod/user/setup/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Personal user setup";
$MLANG["default"]["tabs"]["tab"] = "Setup";
$MLANG["default"]["tabs_images"]["tab"] = "setup.gif";
$MLANG["default"]["labels"]["tabdescr"] = "This module allows you to customize your backend user profile. Here you can change your active system language, name and email address. You may also configure other general features in the system.";

$MLANG["dk"]["labels"]["tablabel"] = "Personlig ops�tning";
$MLANG["dk"]["tabs"]["tab"] = "Indstillinger";
$MLANG["dk"]["labels"]["tabdescr"] = "Dette modul giver dig mulighed for at skr�ddersy indstillingerne i din brugerprofil. Du kan �ndre det aktive systemsprog samt navn og email adresse. Du kan ogs� indstille andre funktioner i systemet.";

$MLANG["de"]["labels"]["tablabel"] = "Einstellungen";
$MLANG["de"]["tabs"]["tab"] = "Einst.";
$MLANG["de"]["labels"]["tabdescr"] = "Dieses Modul dient zur Einstellung Ihres Backend Benutzerprofils. Hier k�nnen Sie Ihren Namen, Ihre Email Adresse, die benutzte Backend Sprache und viele andere allgemeine Eigenschaften des Systems f�r Ihren Benutzer einstellen.";

$MLANG["no"]["labels"]["tablabel"] = "Personlig oppsett";
$MLANG["no"]["tabs"]["tab"] = "Oppsett";
$MLANG["no"]["labels"]["tabdescr"] = "Med denne modulen kan du skreddersy oppsettet for din brukerprofil. Du kan endre aktivt systemspr�k samt navn og e-post adresse. Du kan ogs� sette opp andre funksjoner i systemet. ";

$MLANG["it"]["labels"]["tablabel"] = "Setup personale";
$MLANG["it"]["tabs"]["tab"] = "Setup";
$MLANG["it"]["labels"]["tabdescr"] = "Questo modulo vi consente di personalizzare il vostro profilo utente (amministratore). Potete modificare la lingua di default, nome e indirizzo email. Potete anche configurare altre caratteristiche del sistema";

$MLANG["fr"]["labels"]["tablabel"] = "Personnalisation";
$MLANG["fr"]["tabs"]["tab"] = "Configuration";
$MLANG["fr"]["labels"]["tabdescr"] = "Ce module vous permet de personnaliser votre profil. Vous pouvez changer ici, votre langue d'interface par d�faut, votre nom, votre adresse e-mail. Vous pouvez aussi modifier quelques options g�n�rales du syst�me.";

$MLANG["es"]["labels"]["tablabel"] = "Personalizaci�n";
$MLANG["es"]["tabs"]["tab"] = "Configuraci�n";
$MLANG["es"]["labels"]["tabdescr"] = "Este m�dulo le permite el personalizar su perfil de usuario del backend. Aqu� podr� cambiar el lenguaje activo, su nombre y direcci�n de email. Tambi�n podr� configurar otras caracter�sticas generales en el sistema";

$MLANG["nl"]["labels"]["tablabel"] = "Persoonlijke setup (gebruiker)";
$MLANG["nl"]["tabs"]["tab"] = "Setup";
$MLANG["nl"]["labels"]["tabdescr"] = "Deze module biedt je de mogelijkheid je BeheerSitegebruikersprofiel aan te passen. Hier kan je je huidige systeemtaal, naam en emailadres wijzigen. Je kan hier ook algemene onderdelen van het systeem configureren.";

$MLANG["cz"]["labels"]["tablabel"] = "U�ivatelsk� nastaven�";
$MLANG["cz"]["tabs"]["tab"] = "Setup";
$MLANG["cz"]["labels"]["tabdescr"] = "Tento modul umo��uje p�izp�sobit profil u�ivatele backendu. Zde m��ete zm�nit jazyk, jm�no, emailovou adresu. Tak� zde m��ete konfigurovat dal�� obecn� vlastnosti syst�mu.";

$MLANG["si"]["labels"]["tablabel"] = "Uporabni�ke nastavitve";
$MLANG["si"]["tabs"]["tab"] = "Nastavitve";
$MLANG["si"]["labels"]["tabdescr"] = "Ta modul vam omogo�a urejanje va�ih uporabni�kih nastavitev. Tu lahko spremenite jezik vmesnika, svoje ime in email naslov, kot tudi �tevilne druge mo�nosti.";

$MLANG["pl"]["labels"]["tablabel"] = "Ustawienia osobiste u�ytkownika";
$MLANG["pl"]["labels"]["tabdescr"] = "Centrum zada� umo�liwia dost�p do twoich zada�, wiadomo�ci, notesu, akcji, itp. Zawiera r�wnie� skr�ty do dost�pnych dla ciebie modu��w i ostatnio edytowanych przez ciebie stron. Centrum zada� pozwala efektywnie zarz�dza� prac� w systemie.";
$MLANG["pl"]["tabs"]["tab"] = "Ustawienia";

$MLANG["fi"]["labels"]["tablabel"] = "Henkil�kohtaiset perustiedot";
$MLANG["fi"]["labels"]["tabdescr"] = "T�ll� modulilla voit muokata backend k�ytt�j�n profiiliasi. Voit vaihtaa aktiivisen j�rjestelm�n kielt�, nime�si ja s�hk�postiosoitetta. Voit asentaa my�s muita j�rjestelm�n ominaisuuksia.";
$MLANG["fi"]["tabs"]["tab"] = "Asetukset";

$MLANG["tr"]["labels"]["tablabel"] = "Ki�isel kullan�c� kurulumu";
$MLANG["tr"]["tabs"]["tab"] = "Kurulum";
$MLANG["tr"]["labels"]["tabdescr"] = "Bu mod�l sizin arkaplan kullan�c� profilini ki�iselle�tirmeyi sa�lar. Buarada sizin aktif sistem dilini, isminizi ve email adresinizi de�i�tirebilirsiniz. Birde sistemde di�er genel �zellikleri konfig�re edebilirsiniz.";



$MCONF["script"]="index.php";
$MCONF["access"]="group,user";
$MCONF["name"]="user_setup";
?>