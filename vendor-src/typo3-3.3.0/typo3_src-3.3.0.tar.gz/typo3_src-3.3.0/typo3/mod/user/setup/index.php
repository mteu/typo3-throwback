<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: User configuration
 * 
 * This module lets users viev and change their individual settings
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include_once(PATH_t3lib."class.t3lib_tcemain.php");


// ***************************
// Script Classes
// ***************************
class SC_mod_user_setup_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $content;
	var $overrideConf;
	var $OLD_BE_USER;
	
	function getRealScriptUserObj()	{
		return is_object($this->OLD_BE_USER) ? $this->OLD_BE_USER : $GLOBALS["BE_USER"];
	}
	function simulateUser()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		
		// *******************************************************************************
		// If admin, allow simulation of another user
		// *******************************************************************************
		$this->simUser = 0;
		$this->simulateSelector="";
		unset($this->OLD_BE_USER);
		if ($BE_USER->isAdmin())	{
			$this->simUser = t3lib_div::GPvar("simUser");
		
				// Make user-selector:
			$users = t3lib_BEfunc::getUserNames("username,usergroup,usergroup_cached_list,uid,realName");
			$opt=array();
			reset($users);
			$opt[]='<option></option>';
			while(list(,$rr)=each($users))	{
				if ($rr["uid"]!=$BE_USER->user["uid"])	{
					$opt[]='<option value="'.$rr["uid"].'"'.($this->simUser==$rr["uid"]?" SELECTED":"").'>'.htmlspecialchars($rr["username"]." (".$rr["realName"].")").'</option>';
				}
			}
			$this->simulateSelector = '<select name="simulateUser" onChange="document.location=\'index.php?simUser=\'+this.options[this.selectedIndex].value;">'.implode("",$opt).'</select>';
		}
		
		if ($this->simUser>0)	{	// This can only be set if the previous code was executed.
			$this->OLD_BE_USER = $BE_USER;	// Save old user...
			unset($BE_USER);	// Unset current
		
			$BE_USER = t3lib_div::makeInstance("t3lib_beUserAuth");	// New backend user object
			$BE_USER->OS = TYPO3_OS;
			$BE_USER->setBeUserByUid($this->simUser);
			$BE_USER->fetchGroupData();
			$BE_USER->backendSetUC();
			$GLOBALS["BE_USER"] = $BE_USER;	// Must do this, because unsetting $BE_USER before apparently unsets the reference to the global variable by this name!
		}
	}
	function storeIncomingData()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// *******************************************************************************
		// First check if something is submittet in the data-array from HTTP_POST_VARS
		// *******************************************************************************
		if (is_array($HTTP_POST_VARS["data"]))	{
			$d=$HTTP_POST_VARS["data"];
		
			$save_before=md5(serialize($BE_USER->uc));
		
			$BE_USER->uc["lang"]=$d["lang"];
			$BE_USER->uc["helpText"]=$d["helpText"];
			$BE_USER->uc["thumbnailsByDefault"]=$d["thumbnailsByDefault"];
			$BE_USER->uc["alternativeBackend"]=$d["alternativeBackend"];
			if (isset($d["condensedMode"]))	$BE_USER->uc["condensedMode"]=$d["condensedMode"];
			if (isset($d["noMenuMode"]))	$BE_USER->uc["noMenuMode"]=$d["noMenuMode"];
			$BE_USER->uc["startInTaskCenter"]=$d["startInTaskCenter"];
			$BE_USER->uc["emailMeAtLogin"]=$d["emailMeAtLogin"];
			$BE_USER->uc["titleLen"]=intval($d["titleLen"]);
		#	$BE_USER->uc["winW"]=intval($d["winW"]);
		#	$BE_USER->uc["winH"]=intval($d["winH"]);
			$BE_USER->uc["copyLevels"]=t3lib_div::intInRange($d["copyLevels"],0,100);
			$BE_USER->uc["recursiveDelete"]=$d["recursiveDelete"];
		
			$BE_USER->uc["edit_wideDocument"]=$d["edit_wideDocument"];
			$BE_USER->uc["edit_showFieldHelp"]=$d["edit_showFieldHelp"];
			if ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["RTEenabled"])	{	$BE_USER->uc["edit_RTE"]=$d["edit_RTE"];	}
			$BE_USER->uc["edit_maxRecords"]=t3lib_div::intInRange($d["edit_maxRecords"],0,100);
			$BE_USER->uc["edit_docModuleUpload"]=$d["edit_docModuleUpload"];
			$BE_USER->uc["disableCMlayers"]=$d["disableCMlayers"];
			
			$BE_USER->uc["dontEditInPageModule"]=$d["dontEditInPageModule"];
		
			if ($HTTP_POST_VARS["data"]["setValuesToDefault"])	{	// If every value should be default
				$BE_USER->resetUC();
			}
			$BE_USER->overrideUC();	// Inserts the overriding values.
		
			$save_after=md5(serialize($BE_USER->uc));
			if ($save_before!=$save_after)	{	// If something in the uc-array of the user has changed, we save the array...
				$BE_USER->writeUC($BE_USER->uc);
				$BE_USER->writelog(254,1,0,1,"Personal settings changed",Array());
			}
		
			// If email and name is changed, set it in the users record:
			$be_user_data=t3lib_div::GPvar("ext_beuser",1);
			if ($be_user_data["email"]!=$BE_USER->user["email"] || $be_user_data["realName"]!=$BE_USER->user["realName"])	{
				$storeRec=array();
				$BE_USER->user["realName"] = $storeRec["be_users"][$BE_USER->user["uid"]]["realName"] = substr($be_user_data["realName"],0,80);
				$BE_USER->user["email"] = $storeRec["be_users"][$BE_USER->user["uid"]]["email"] = substr($be_user_data["email"],0,80);
		
				$tce = t3lib_div::makeInstance("t3lib_TCEmain");
				$tce->start($storeRec,Array(),$BE_USER);
				$tce->admin=1;
				$tce->process_datamap();
				unset($tce);
			}
		}
	}
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		$scriptUser = $this->getRealScriptUserObj();
		$scriptUser->modAccess($this->MCONF,1);
		
		$this->overrideConf = $BE_USER->getTSConfigProp("setup.override");
		
		$this->doc = t3lib_div::makeInstance("mediumDoc");
		$this->doc->endJS=0;
		$this->doc->backPath = $BACK_PATH;
		$this->doc->form='<form action="index.php" method="POST" enctype="application/x-www-form-urlencoded">';
		$this->doc->tableLayout = Array (
			"defRow" => Array (
				"0" => Array('<TD align="left" width=300>','</td>'),
				"defCol" => Array('<td valign="top">','</td>')
			)
		);
		$this->doc->table_TR = '<TR bgColor="'.$this->doc->bgColor4.'">';
		$this->doc->table_TABLE = '<TABLE border=0 cellspacing=1 cellpadding=2>';

	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content.=$this->doc->startPage($LANG->getLL("UserSettings"));
		$this->content.=$this->doc->header($LANG->getLL("UserSettings")." - [".$BE_USER->user["username"]."]");
		$this->content.=$this->doc->spacer(5);
		
		
		// ************
		// Simulate:
		// ************
		if ($this->simulateSelector)	{
			$this->content.=$this->doc->section($LANG->getLL("simulate").":",$this->simulateSelector,1,0,($this->simUser?2:0));
		}
		
		
		// ************
		// Languages:
		// ************
		$theDirs=t3lib_div::get_dirs($BACK_PATH."lang/");
		if (is_array($theDirs))	{
			reset($theDirs);
		
			$code='<option value="">'.$LANG->getLL("lang_default").'</option>';		// ['.$LANG->getLL("default").']
			while(list(,$val)=each($theDirs))	{
				$code.='<option value="'.$val.'"'.($BE_USER->uc["lang"]==$val?' selected':'').'>'.$LANG->getLL("lang_".$val).'</option>';
			}
			$code='<select name="data[lang]">'.$code.'</select>';
			$this->content.=$this->doc->section($LANG->getLL("language").":",$code,0,1);
		}
		
		
		// ************
		// Startup:
		// ************
		$code = Array();
		
		if (trim($TYPO3_CONF_VARS["BE"]["interfaces"])!="alternative")	{
			$code[1][1] = $this->setLabel("alternativeBackend","alternativeBackend").':';
			$code[1][2] = '<input type="Checkbox" name="data[alternativeBackend]"'.($BE_USER->uc["alternativeBackend"]?' checked':'').'>';
		}
		
		//if ($BE_USER->uc["alternativeBackend"] || )	{
			$code[2][1] = $this->setLabel("condensedMode","condensedMode").':';
			$code[2][2] = '<input type="hidden" name="data[condensedMode]" value="0"><input type="Checkbox" name="data[condensedMode]"'.($BE_USER->uc["condensedMode"]?' checked':'').'>';
			$code[3][1] = $this->setLabel("noMenuMode","noMenuMode").':';
			$code[3][2] = '<select name="data[noMenuMode]">
			<option value=""'.(!$BE_USER->uc["noMenuMode"]?' selected':'').'>'.$this->setLabel("noMenuMode_def").'</option>
			<option value="1"'.($BE_USER->uc["noMenuMode"] && (string)$BE_USER->uc["noMenuMode"]!="icons"?' selected':'').'>'.$this->setLabel("noMenuMode_sel").'</option>
			<option value="icons"'.((string)$BE_USER->uc["noMenuMode"]=="icons"?' selected':'').'>'.$this->setLabel("noMenuMode_icons").'</option>
		</select>';
		//}
		
		$code[4][1] = $this->setLabel("startInTaskCenter","startInTaskCenter").':';
		$code[4][2] = '<input type="Checkbox" name="data[startInTaskCenter]"'.($BE_USER->uc["startInTaskCenter"]?' checked':'').'>';
		$code[5][1] = $this->setLabel("showThumbs","thumbnailsByDefault").':';
		$code[5][2] = '<input type="Checkbox" name="data[thumbnailsByDefault]"'.($BE_USER->uc["thumbnailsByDefault"]?' checked':'').'>';
		$code[6][1] = $this->setLabel("helpText").':';
		$code[6][2] = '<input type="Checkbox" name="data[helpText]"'.($BE_USER->uc["helpText"]?' checked':'').'>';
		$code[7][1] = $this->setLabel("maxTitleLen","titleLen").':';
		$code[7][2] = '<input type="Text" name="data[titleLen]" value="'.$BE_USER->uc["titleLen"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(5).' maxlength="5">';
		
		/*
		$code[6][1] = $LANG->getLL("typo3Win").':';
		$code[6][2] = '<input type="Text" name="data[winW]" value="'.$BE_USER->uc["winW"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(5).' maxlength="5"> '.$this->setLabel("width","winW")."<BR>";
		$code[6][2].= '<input type="Text" name="data[winH]" value="'.$BE_USER->uc["winH"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(5).' maxlength="5"> '.$this->setLabel("height","winH");
		*/
		$this->content.=$this->doc->section($LANG->getLL("opening").":",$this->doc->table($code),0,1);
		
		
		
		// *********************
		// Advanced Operations:
		// *********************
		$code = Array();
		$code[1][1] = $this->setLabel("copyLevels").':';
		$code[1][2] = '<input type="Text" name="data[copyLevels]" value="'.$BE_USER->uc["copyLevels"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(5).' maxlength="5"> '.$this->setLabel("levels","copyLevels");
		
		$code[2][1] = $this->setLabel("recursiveDelete").':';
		$code[2][2] = '<input type="Checkbox" name="data[recursiveDelete]"'.($BE_USER->uc["recursiveDelete"]?' checked':'').'>';
		
		$this->content.=$this->doc->section($LANG->getLL("functions").":",$this->doc->table($code),0,1);
		
		
		
		// ******
		// Edit
		// ******
		$code = Array();
		
		$code[1][1] = $this->setLabel("edit_maxRecords").':';
		$code[1][2] = '<input type="Text" name="data[edit_maxRecords]" value="'.$BE_USER->uc["edit_maxRecords"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(5).' maxlength="5">';
		
		$code[2][1] = $this->setLabel("edit_wideDocument").':';
		$code[2][2] = '<input type="Checkbox" name="data[edit_wideDocument]"'.($BE_USER->uc["edit_wideDocument"]?' checked':'').'>';
		
		if ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["RTEenabled"])	{
			$code[3][1] = $this->setLabel("edit_RTE").':';
			$code[3][2] = '<input type="Checkbox" name="data[edit_RTE]"'.($BE_USER->uc["edit_RTE"]?' checked':'').'>';
		}
		
		$code[4][1] = $this->setLabel("edit_docModuleUpload").':';
		$code[4][2] = '<input type="Checkbox" name="data[edit_docModuleUpload]"'.($BE_USER->uc["edit_docModuleUpload"]?' checked':'').'>';
		
		//$code[5][1] = $this->setLabel("allSaveFunctions").':';
		//$code[5][2] = '<input type="Checkbox" name="data[allSaveFunctions]"'.($BE_USER->uc["allSaveFunctions"]?' checked':'').'>';
		$code[5][1] = $this->setLabel("dontEditInPageModule").':';
		$code[5][2] = '<input type="Checkbox" name="data[dontEditInPageModule]"'.($BE_USER->uc["dontEditInPageModule"]?' checked':'').'>';
		
		
		$code[6][1] = $this->setLabel("edit_showFieldHelp").':';
		$code[6][2] = '<select name="data[edit_showFieldHelp]">
			<option value=""></option>
			<option value="icon"'.($BE_USER->uc["edit_showFieldHelp"]=="icon"?' selected':'').'>'.$this->setLabel("edit_showFieldHelp_icon").'</option>
			<option value="text"'.($BE_USER->uc["edit_showFieldHelp"]=="text"?' selected':'').'>'.$this->setLabel("edit_showFieldHelp_message").'</option>
		</select>';
			
		$code[7][1] = $this->setLabel("disableCMlayers").':';
		$code[7][2] = '<input type="Checkbox" name="data[disableCMlayers]"'.($BE_USER->uc["disableCMlayers"]?' checked':'').'>';
		
		$this->content.=$this->doc->section($LANG->getLL("edit_functions").":",$this->doc->table($code),0,1);
		
			
		// ***********
		// Security:
		// ***********
		$code = Array();
		
		$code[1][1] = $this->setLabel("beUser_realName").':';
		$code[1][2] = '<input type="Text" name="ext_beuser[realName]" value="'.$BE_USER->user["realName"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(20).'>';
		
		$code[2][1] = $this->setLabel("beUser_email").':';
		$code[2][2] = '<input type="Text" name="ext_beuser[email]" value="'.$BE_USER->user["email"].'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(20).'>';
		
		$code[3][1] = $this->setLabel("emailMeAtLogin").' ('.$GLOBALS["BE_USER"]->user[email].'):';
		$code[3][2] = '<input type="Checkbox" name="data[emailMeAtLogin]"'.($BE_USER->uc["emailMeAtLogin"]?' checked':'').'>';
		
		$this->content.=$this->doc->section($LANG->getLL("security").":",$this->doc->table($code),0,1);
		
		
		// ********
		// Submit:
		// ********
		$this->content.=$this->doc->spacer(20);
		$this->content.=$this->doc->section('','<input type="Submit" name="submit" value="'.$LANG->getLL("save").'"> &nbsp; <B>'.$LANG->getLL("setToStandard").': </b><input type="Checkbox" name="data[setValuesToDefault]"><input type="hidden" name="simUser" value="'.$this->simUser.'">');
		
		
		// ********
		// Notice
		// ********
		$this->content.=$this->doc->spacer(5);
		$this->content.=$this->doc->section('',$LANG->getLL("activateChanges"));
	}
	function printContent()	{
		global $SOBE;

		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
	function setLabel($str,$key="")	{
		$out = $GLOBALS["LANG"]->getLL($str);
		if (isset($this->overrideConf[($key?$key:$str)]))	{
			$out = '<font color="#999999">'.$out.'</font>';
		}
		return $out;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/user/setup/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/user/setup/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_user_setup_index");
$SOBE->simulateUser();
$SOBE->storeIncomingData();

// *************************************************************
// These includes MUST be afterwards the settings are saved...
// *************************************************************
include ($BACK_PATH."template.php");
include ("locallang.php");

$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>