<?php

$MLANG["default"]["labels"]["tablabel"] = "Your personal tasks, overview and setup";
$MLANG["default"]["tabs"]["tab"] = "User";
$MLANG["default"]["tabs_images"]["tab"] = "user.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Dine personlige opgaver, overblik og indstillinger";
$MLANG["dk"]["tabs"]["tab"] = "Bruger";

$MLANG["no"]["labels"]["tablabel"] = "Dine personlige oppgaver, oversikt og oppsett";
$MLANG["no"]["tabs"]["tab"] = "Bruker";

$MLANG["de"]["labels"]["tablabel"] = "Ihre pers�nliche Aufgaben, �bersicht und Einstellungen";
$MLANG["de"]["tabs"]["tab"] = "Benutzer";

$MLANG["fr"]["labels"]["tablabel"] = "Vos t�ches personnelles, r�sum� et configuration";
$MLANG["fr"]["tabs"]["tab"] = "Utilisateur";

$MLANG["pl"]["labels"]["tablabel"] = "Twoje zadania i ustawienia osobiste";
$MLANG["pl"]["tabs"]["tab"] = "U�ytkownik";

$MLANG["es"]["labels"]["tablabel"] = "Sus tareas personales, res�men y configuraci�n";
$MLANG["es"]["tabs"]["tab"] = "Usuario";

$MLANG["si"]["labels"]["tablabel"] = "Va�e naloge";
$MLANG["si"]["tabs"]["tab"] = "Uporabnik";

$MLANG["nl"]["labels"]["tablabel"] = "Je persoonlijke taken, overzicht en setup";
$MLANG["nl"]["tabs"]["tab"] = "Gebruiker";

$MLANG["cz"]["labels"]["tablabel"] = "Va�e osbn� �koly, p�ehled a nastaven�";
$MLANG["cz"]["tabs"]["tab"] = "U�ivatel";

$MLANG["it"]["labels"]["tablabel"] = "Lavori personali , vista e setup";
$MLANG["it"]["tabs"]["tab"] = "Utente";

$MLANG["fi"]["labels"]["tablabel"] = "Sinun henkil�kohtaiset toimet, yleis- ja perustiedot.";
$MLANG["fi"]["tabs"]["tab"] = "K�ytt�j�";

$MLANG["tr"]["labels"]["tablabel"] = "Ki�isel g�revleriniz, genel g�r�nt� ve kurulumunuz";
$MLANG["tr"]["tabs"]["tab"] = "Kullan�c�";



$MCONF["defaultMod"]="task";
$MCONF["name"]="user";
$MCONF["access"]="user,group";

?>