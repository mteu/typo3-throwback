<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Task Frameset</title>
</head>
<frameset cols="245,8,*" framespacing="0" frameborder="0" border="0">
	<frame name="nav_frame" src="overview.php<?php echo (isset($HTTP_GET_VARS["AB"])&&$HTTP_GET_VARS["AB"])?"?AB=1":""; ?>" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
	<frame name="border_frame" src="../../../border.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
	<frame name="list_frame" src="index.php<?php echo (isset($HTTP_GET_VARS["AB"])&&$HTTP_GET_VARS["AB"])?"?AB=1":""; ?>" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
</frameset>
</html>
