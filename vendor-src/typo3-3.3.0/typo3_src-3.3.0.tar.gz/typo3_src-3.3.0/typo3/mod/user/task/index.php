<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * User Task Center
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
include ("locallang.php");
include_once("class.mod_user_task.php");
include_once(PATH_t3lib."class.t3lib_tceforms.php");
include_once(PATH_t3lib."class.t3lib_tcemain.php");

$BE_USER->modAccess($MCONF,1);




// ***************************
// Script Classes
// ***************************
class SC_mod_user_task_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $include_once=array();
	var $content;
	var $modTSconfig;
	var $t3lib_TCEforms;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		$this->menuConfig();

		switch($this->MOD_SETTINGS["function"])	{
			case "actions":
				$this->include_once[]= PATH_t3lib."class.t3lib_fullsearch.php";
				$this->include_once[]= PATH_t3lib."class.t3lib_xml.php";
				$this->include_once[]= PATH_t3lib."class.t3lib_loaddbgroup.php";
				$this->include_once[]= PATH_t3lib."class.t3lib_tcemain.php";
			break;
		}

		
		$this->t3lib_TCEforms = t3lib_div::makeInstance("t3lib_TCEforms");
		$this->t3lib_TCEforms->backPath = $BACK_PATH;
		$this->doc = t3lib_div::makeInstance("mediumDoc");
		$this->doc->form='<form action="index.php" method="POST" name="editform">';
		$this->doc->backPath = $BACK_PATH;
		$this->doc->JScode = '
		<script>
			script_ended = 0;
			function jumpToUrl(URL)	{
				document.location = URL;
			}
		'.$this->t3lib_TCEforms->dbFileCon().'
		</SCRIPT>
		';

	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// MENU-ITEMS:
			// If array, then it's a selector box menu
			// If empty string it's just a variable, that'll be saved. 
			// Values NOT in this array will not be saved in the settings-array for the module.
		$this->MOD_MENU = array(
				// function is not actually displayed as a menu here, but linked from the left frame.
			"function" => array(
				"tasks" => "",
				"messages" => "",
				"note" => "",
				"recent" => "",
				"mod" => "",
				"actions" => ""
			),
			"messages_box" => array(
				"inbox" => $LANG->getLL("messages_inbox"),
				"archive" => $LANG->getLL("messages_archive"),
				"sent" => $LANG->getLL("messages_sent")
			)
		);
	
			// page/be_user TSconfig settings and blinding of menu-items
		$this->modTSconfig = t3lib_BEfunc::getModTSconfig(0,"mod.".$this->MCONF["name"]);	// id=0 - no page tree here!
		$this->MOD_MENU["function"] = t3lib_BEfunc::unsetMenuItems($this->modTSconfig["properties"],$this->MOD_MENU["function"],"menu.function");
		
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"]);
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// **************************
		// Initializing
		// **************************
		
		$this->content="";
		$this->content.=$this->doc->startPage($LANG->getLL($this->MOD_SETTINGS["function"]));
		$this->content.=$this->doc->header($LANG->getLL($this->MOD_SETTINGS["function"]));
		$this->content.=$this->doc->spacer(5);
		
		$modObj = t3lib_div::makeInstance("mod_user_task");
		$modObj->backPath = $BACK_PATH;
		
		/*
		if (!$BE_USER->isAdmin())	{
					// This is used to test with other users. Development ONLY!
				$BE_USER = t3lib_div::makeInstance("t3lib_beUserAuth");	// New backend user object
				$BE_USER->OS = TYPO3_OS;
				$BE_USER->setBeUserByUid(4);
				$BE_USER->fetchGroupData();
		}
		*/
		
				
		$modObj->init($BE_USER);
		
		switch($this->MOD_SETTINGS["function"])	{
			case "note":
				$this->content.=$modObj->renderNote();
			break;
			case "actions":
				$this->content.=$modObj->renderActions();
			break;
			case "recent":
				$this->content.=$modObj->renderRecent();
			break;
			case "messages":
				$this->content.=$modObj->renderMessages();
			break;
			case "tasks":
				$this->content.=$modObj->renderTasks();
			break;
		}
	}
	function printContent()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/user/task/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/user/task/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_user_task_index");
$SOBE->init();

// Include files?
reset($SOBE->include_once);	
while(list(,$INC_FILE)=each($SOBE->include_once))	{include_once($INC_FILE);}

$SOBE->main();
$SOBE->printContent();
?>