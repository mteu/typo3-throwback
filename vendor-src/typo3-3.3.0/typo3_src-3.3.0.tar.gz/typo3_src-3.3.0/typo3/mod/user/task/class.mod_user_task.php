<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module class for task module
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
class mod_user_task	{
	var $backPath;
	var $numberOfRecent=6;
	var $numberOfRecentAll=20;
	var $charWidth=60;
	var $AB;
	var $logWhere=" AND sys_log.event_pid>0 AND sys_log.type=1 AND sys_log.action=2 AND sys_log.error=0";
	var $getUserNamesFields = "username,usergroup,usergroup_cached_list,uid,realName,email";
	
	var $userGroupArray=array();
	var $todoTypesCache = array();
	var $xCol="";
	var $insCounter=0;

		// Constructor
	function mod_user_task()	{
		$this->AB = 1;//$GLOBALS["AB"];
	}
	function getQuickNote($be_user_id)	{
		$query = "SELECT * FROM sys_notepad WHERE cruser_id=".intval($be_user_id)." ORDER BY crdate LIMIT 1";
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_assoc($res);
		return $row;
	}
	function getRecentResPointer($be_user_id)	{
		$query = "SELECT sys_log.*, max(sys_log.tstamp) as tstamp_MAX 
			FROM sys_log,pages 
			WHERE pages.uid=event_pid
			 AND sys_log.userid=".intval($be_user_id).$this->logWhere."
			 AND pages.module=''
			 AND pages.doktype < 200
			 AND ".$this->perms_clause." 
			GROUP BY sys_log.event_pid 
			ORDER BY tstamp_MAX DESC 
			LIMIT ".$this->numberOfRecent;
//		debug($query);
	
		$res = mysql(TYPO3_db,$query);
		return $res;
	}
	function getActionResPointer($uid=0)	{
		if ($this->BE_USER->isAdmin())	{
			$wQ="";
			if (intval($uid)>0)	$wQ.=" AND sys_action.uid=".intval($uid);
			$query = "SELECT * FROM sys_action WHERE sys_action.pid=0".$wQ." ORDER BY sys_action.title";
		} else {
			$wQ = "be_groups.uid IN (".($this->BE_USER->groupList?$this->BE_USER->groupList:0).")";
			$hQ = "AND sys_action.hidden=0 ";
			if (intval($uid)>0)	$wQ.=" AND sys_action.uid=".intval($uid);
			$query = t3lib_BEfunc::mm_query("sys_action.*","sys_action","sys_action_asgr_mm","be_groups"," AND ".$wQ." AND sys_action.pid=0 ".$hQ."GROUP BY sys_action.uid ORDER BY sys_action.title");
		}

		$res = mysql(TYPO3_db,$query);
		echo mysql_error();
		return $res;
	}
	function setQuickNote($uid,$inRow,$be_user_id)	{
		$uid = intval($uid);
		$query = "SELECT * FROM sys_notepad WHERE uid=".$uid;
		$res = mysql(TYPO3_db,$query);
		$row = mysql_fetch_assoc($res);
		if (is_array($row))	{ 	// update...
			if ($be_user_id==$row["cruser_id"])	{
				$query = t3lib_BEfunc::DBcompileUpdate("sys_notepad","uid=".$uid,$inRow);
			}
		} else {
			$query = t3lib_BEfunc::DBcompileInsert("sys_notepad",$inRow);
		}
		if ($query)	{
			$res = mysql(TYPO3_db,$query);
		}
	}
	function breakLines($str,$implChar="\n",$charWidth=0)	{
		return t3lib_div::breakLinesForEmail($str,$implChar,$charWidth?$charWidth:$this->charWidth);
	}
	function fixed_lgd($str,$len=0)	{
		return t3lib_div::fixed_lgd($str,$len?$len:$this->BE_USER->uc["titleLen"]);
	}
	function helpBubble()	{
		return '<img src="'.$this->backPath.'gfx/helpbubble.gif" width="14" height="14" hspace=2 align=top'.$GLOBALS["SOBE"]->doc->helpStyle().'>';
	}
	function loadLeftFrameJS()	{
		$str = '<script>if (parent.nav_frame)	parent.nav_frame.document.location="overview.php";</script>';
		return $str;
	}
	function accessMod($mod)	{
		return $this->BE_USER->modAccess(array("name"=>$mod,"access"=>"user,group"),0);
	}
	function dateTimeAge($tstamp,$prefix=1)	{
		return t3lib_BEfunc::dateTimeAge($tstamp,$prefix);
	}
	function getEditRedirectUrlForReference($recRef)	{
		$parts = explode(":",$recRef);
		if ($parts[0]=="pages")	{
			$outUrl = $this->backPath."db_layout.php?id=".$parts[1]."&AB=1&SET[function]=0&edit_record=".$parts[0].":".$parts[1]."&returnUrl=".rawurlencode(getenv("REQUEST_URI"));
		} else {
			$outUrl = $this->backPath."alt_doc.php?returnUrl=".rawurlencode(getenv("REQUEST_URI"))."&edit[".$parts[0]."][".$parts[1]."]=edit";
		}
		return $outUrl;
	}
	function init($BE_USER)	{
		$this->BE_USER = $BE_USER;
		$this->perms_clause = $this->BE_USER->getPagePermsClause(1);
	}
	function errorIcon()	{
		return '<img src="'.$this->backPath.'gfx/icon_fatalerror.gif" width="18" height="16" align=top>';
	}
	function printUserGroupName($uid,$icon=0)	{
		if ($uid>0)	{
			return ($icon?t3lib_iconWorks::getIconImage("be_users",t3lib_BEfunc::getRecord("be_users",$uid),$this->backPath,$params=" align=top"):"").
				$this->userGroupArray[2][$uid]["username"].($this->userGroupArray[2][$uid]["realName"]?" (".$this->userGroupArray[2][$uid]["realName"].")":"");
		} else {
			$grRec = t3lib_BEfunc::getRecord("be_groups",abs($uid));
			return ($icon?t3lib_iconWorks::getIconImage("be_groups",$grRec,$this->backPath,$params=" align=top"):"").
				$grRec["title"];
		}
	}
	function overview_main($MOD_MENU)	{
		global $SOBE;

		$content="";
		
		if (isset($MOD_MENU["function"]["tasks"]))	{
			$icon = '<img src="'.$this->backPath.'gfx/i/tc_todos.gif" width=18 height=16 align=absmiddle>';
			$content.=$SOBE->doc->section($icon."&nbsp;".$this->headLink("tasks"),$this->renderTaskList(),1,1);
		}
		
		if (isset($MOD_MENU["function"]["messages"]))	{
			$icon = '<img src="'.$this->backPath.'gfx/i/tc_mails.gif" width=18 height=16 align=absmiddle>';
			$content.=$SOBE->doc->section($icon."&nbsp;".$this->headLink("messages",0,"&SET[messages_box]=inbox"),$this->renderMessagesList(),1,1);
		}
			
		if (isset($MOD_MENU["function"]["note"]))	{
			$icon = '<img src="'.$this->backPath.'gfx/i/tc_notepad.gif" width=18 height=16 align=absmiddle>';
			$noteRow = $this->getQuickNote($this->BE_USER->user["uid"]);
			$noteVal = nl2br(t3lib_div::fixed_lgd(implode(chr(10),t3lib_div::trimExplode(chr(10),$noteRow["note"],1)),50));
			$content.=$SOBE->doc->section($icon."&nbsp;".$this->headLink("note",0),'<a href="index.php?SET[function]=note" target="list_frame" onClick="this.blur();"><img src="'.$this->backPath.'gfx/edit2.gif" width="11" height="12" hspace=2 border="0" align=top>'.$noteVal.'</a>',1,1);
		}
			
		if (isset($MOD_MENU["function"]["recent"]) && $this->accessMod("web_layout"))	{
			$mC = $this->renderRecentList();
			if ($mC)	{
				$icon = '<img src="'.$this->backPath.'gfx/i/tc_pages.gif" width=18 height=16 align=absmiddle>';
				$content.=$SOBE->doc->section($icon."&nbsp;".$this->headLink("recent",0),$mC,1,1);
			}
		}
			
		// Modules might have a link to a totals-page where an overview of the modules content are present.
		if (isset($MOD_MENU["function"]["mod"]) && $this->accessMod("web_modules"))	{
			$mC = $this->renderModulesList();
			if ($mC)	{
				$icon = '<img src="'.$this->backPath.'gfx/i/tc_modules.gif" width=18 height=16 align=absmiddle>';
				$content.=$SOBE->doc->section($icon."&nbsp;".$this->headLink("mod",1),$mC,1,1);	
			}
		}
		
		if (isset($MOD_MENU["function"]["actions"]))	{
			$mC = $this->renderActionList();
			if ($mC)	{
				$icon = '<img src="'.$this->backPath.'gfx/i/tc_actions.gif" width=18 height=16 align=absmiddle>';
				$content.=$SOBE->doc->section($icon."&nbsp;".$this->headLink("actions",1),$mC,1,1);
			}
		}
		
		if ($GLOBALS["BE_USER"]->isAdmin())	{
			$headContent='<a href="'.$GLOBALS["BACK_PATH"].'db_list.php?id=0&AB=1" target="list_frame">'.htmlspecialchars($GLOBALS["LANG"]->getLL("webListModule")).'</a>';
			$content.=$SOBE->doc->section($headContent,"",1,1);
		}
		return $content;
	}
	function headLink($key,$dontLink=0,$params="")	{
		$str = $GLOBALS["LANG"]->getLL($key);
		if (!$dontLink)	$str = '<a href="index.php?SET[function]='.$key.$params.'&AB='.$this->AB.'" target="list_frame" onClick="this.blur();">'.$str.'</a>';
		return $str;
	}
	function sendEmail($email,$subject,$message)	{
		$sender = $this->BE_USER->user["realName"]." <".$this->BE_USER->user["email"].">";
		$message.='

--------
'.sprintf($GLOBALS["LANG"]->getLL("messages_emailFooter"),$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"],getenv("HTTP_HOST"));
		mail($email,$GLOBALS["TYPO3_CONF_VARS"]["BE"]["notificationPrefix"]." ".$subject,$message,"From: ".$sender);

//		debug($email);
//		debug($message);
	}



	function getUserAndGroupArrays()	{
			// Get groupnames for todo-tasks
		$be_group_Array=t3lib_BEfunc::getListGroupNames("title,uid");
		$groupArray=array_keys($be_group_Array);
			// Usernames
		$be_user_Array = $be_user_Array_o = t3lib_BEfunc::getUserNames($this->getUserNamesFields);
		if (!$GLOBALS["BE_USER"]->isAdmin())		$be_user_Array = t3lib_BEfunc::blindUserNames($be_user_Array,$groupArray,1);

		$this->userGroupArray = array($be_user_Array,$be_group_Array,$be_user_Array_o);
		return $this->userGroupArray;
	}








	// ************************
	// TODO-tasks
	// ***********************
	function renderTaskList()	{
		global $SOBE, $LANG;

		$query = $this->todos_getQueryForTodoRels(" AND sys_todos_users_mm.finished_instance=0");
//		debug($query,1);
		$res = mysql(TYPO3_db,$query);
		$lines=array();
		while($row=mysql_fetch_assoc($res))	{
			$lines[]='<nobr>'.$this->todos_link('<img src="'.$this->backPath.'gfx/todoicon_'.($row["cruser_id"]==$this->BE_USER->user["uid"]?"user":"group").'.gif" width="18" hspace=6 height="10" align=top border=0><strong>'.$this->fixed_lgd($row["title"]),-$row["mm_uid"]).'</strong></nobr><BR>';
		}

		$query = $this->todos_getQueryForTodoRels("", "count(*)", 1);
		$res = mysql(TYPO3_db,$query);
		list($mc) = mysql_fetch_row($res);
		$lines[]='<nobr>'.$this->todos_link(sprintf($LANG->getLL("todos_index_msgs"),$mc),"0").'</nobr><BR>';

		$out = implode("",$lines);
		return $out;
	}
	function todos_link($str,$id)	{
		$str='<a href="index.php?SET[function]=todos&sys_todos_uid='.$id.'#todo" target="list_frame" onClick="this.blur();">'.$str.'</a>';
		return $str;
	}
	function tasks_makeTargetSelector($be_user_Array,$be_group_Array,$type,$returnOptsOnly=0)	{	
		global $LANG;
		// Plain todo
		$opt=array();
		reset($be_user_Array);
		$opt[]='<option value="'.$this->BE_USER->user["uid"].'">'.$this->BE_USER->user["username"].' ['.$LANG->getLL("todos_self").']</option>';
		while(list($uid,$dat)=each($be_user_Array))	{
			if ($uid!=$this->BE_USER->user["uid"])	{
				$opt[]='<option value="'.$uid.'"'.($dat["uid"]==$this->BE_USER->user["uid"]?" selected":"").'>'.htmlspecialchars($dat["username"].($dat["uid"]==$this->BE_USER->user["uid"]?' ['.$LANG->getLL("todos_self").']':' ('.$dat["realName"].')')).'</option>';
			}
		}
		if (count($be_group_Array))	{
			$opt[]='<option value="0">'.$LANG->getLL("listSeparator_Groups").'</option>';
			reset($be_group_Array);
			while(list($uid,$dat)=each($be_group_Array))	{
				$opt[]='<option value="-'.$uid.'">'.htmlspecialchars($dat["title"]).'</option>';
			}
		}
		if ($returnOptsOnly)	return $opt;
		return array($LANG->getLL("todos_target").":&nbsp;", '<select name="data[sys_todos]['.$type.'][target_user]">'.implode("",$opt).'</select>');
	}
	function renderTasks()	{
		global $SOBE, $LANG;
		$theCode="";
			
			// Setting up general things for the function:
		$this->xCol = t3lib_div::modifyHTMLColor($GLOBALS["SOBE"]->doc->bgColor,-10,-10,-10);
		$tUid = intval(t3lib_div::GPvar("sys_todos_uid"));
		$SOBE->doc->tableLayout = Array (
			"defRow" => Array (
				"0" => Array('<TD valign=top nowrap>','</td>'),
				"defCol" => Array('<td valign="top" width=99%>','</td>')
			)
		);
		$SOBE->doc->table_TR = '<TR bgColor="'.$this->xCol.'">';
		$SOBE->doc->table_TABLE = '<TABLE border=0 cellspacing=1 cellpadding=2 width=100%>';
		
		$this->todos_processIncoming($tUid);

			// Get groupnames for todo-tasks
		$this->getUserAndGroupArrays();	// Users and groups blinded due to permissions, plus (third) the original user array with all users
//		debug($this->userGroupArray);

			// Create Todo types array (workflows):
		$todoTypes=array();
		$todoTypes["plain"]='['.$LANG->getLL("todos_plain").']';
		if ($this->BE_USER->isAdmin())	{
			$query = "SELECT * FROM sys_workflows 
				WHERE sys_workflows.pid=0 
				ORDER BY sys_workflows.title";
		} else {
			$query = t3lib_BEfunc::mm_query("sys_workflows.*","sys_workflows","sys_workflows_algr_mm","be_groups","
			 AND be_groups.uid IN (".($this->BE_USER->groupList?$this->BE_USER->groupList:0).")
			 AND sys_workflows.pid=0
			 AND sys_workflows.hidden=0
			GROUP BY sys_workflows.uid
			ORDER BY sys_workflows.title");
		}
//		debug($query);
		$res = mysql(TYPO3_db,$query);
		echo mysql_error();
		while($row=mysql_fetch_assoc($res))	{
			$todoTypes["wf_".$row["uid"]]=$row["title"];
		}

			// Printing the todo list of a user:
		$theCode.= $this->todos_displayLists($todoTypes,$tUid);

			// Display todo:
		if ($tUid)	{
			$theCode.= $this->todos_displayTodo($todoTypes,$tUid);
		}

			// New todo:
		$theCode.= $this->todos_createForm($todoTypes);

		return $theCode;
	}
	function todos_finalizeWorkflow($workflowRecord,$relRecord)	{
		global $TCA;
		list($table,$uid)=explode(":",$relRecord["rec_reference"]);

//		debug($workflowRecord);
//		debug($relRecord);

		if ($workflowRecord["tablename"]==$table && $TCA[$table])	{
			$itemRecord = t3lib_BEfunc::getRecord($table,$uid);
			
			if (is_array($itemRecord))	{
				$dataArr=array();
				$cmdArr=array();
	
					// Changing permissions for the page:
				if ($table=="pages" && $workflowRecord["final_set_perms"])	{
					$dataArr[$table][$uid]["perms_userid"] = $workflowRecord["final_perms_userid"];
					$dataArr[$table][$uid]["perms_groupid"] = $workflowRecord["final_perms_groupid"];
					$dataArr[$table][$uid]["perms_user"] = $workflowRecord["final_perms_user"];
					$dataArr[$table][$uid]["perms_group"] = $workflowRecord["final_perms_group"];
					$dataArr[$table][$uid]["perms_everybody"] = $workflowRecord["final_perms_everybody"];
				}
				
					// Unhide:
				if ($workflowRecord["final_unhide"])	{
					$hCol = is_array($TCA[$table]["ctrl"]["enablecolumns"]) ? $TCA[$table]["ctrl"]["enablecolumns"]["disabled"] : "";
					if ($hCol)	{
						$dataArr[$table][$uid][$hCol]=0;
					}	
				}
				
					// Target:
				list($target_pid) = explode(",",$workflowRecord["final_target"]);
				$targetPage = t3lib_BEfunc::getRecord("pages",$target_pid);
				if (is_array($targetPage))	{
					$cmdArr[$table][$uid]["move"]=$targetPage["uid"];
				}
//debug($workflowRecord["final_target"]);
//debug($cmdArr);
				
				
					// Perform it (as ADMIN)
				$tce = t3lib_div::makeInstance("t3lib_TCEmain");
				$tce->start($dataArr,$cmdArr,$this->BE_USER);
				$tce->admin=1;	// Set ADMIN permission for this operation.
				$tce->process_datamap();
				$tce->process_cmdmap();
				unset($tce);
				
				return true;
			} else {
				debug("ERROR: The reference record was not there!");
			}
		} else {
			debug("ERROR: Stange thing, the table name was not valid!");
		}
	}
	function todos_beginWorkflow($workflowRecord)	{
		global $TCA;
		list($working_area_pid) = explode(",",$workflowRecord["working_area"]);
		$table=$workflowRecord["tablename"];
		$workingPage = t3lib_BEfunc::getRecord("pages",$working_area_pid);
		if (is_array($workingPage) && $TCA[$table])	{
			$data[$table]["NEW"]=array();
			$data[$table]["NEW"]["pid"]=$workingPage["uid"];
		
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
			$TCAdefaultOverride = $this->BE_USER->getTSConfigProp("TCAdefaults");
			if (is_array($TCAdefaultOverride))	{
				$tce->setDefaultsFromUserTS($TCAdefaultOverride);
			}
			$tce->start($data,array(),$this->BE_USER);
			$tce->admin=1;	// Set ADMIN permission for this operation.
			$tce->process_datamap();

			if ($tce->substNEWwithIDs["NEW"])	{
				return $table.":".$tce->substNEWwithIDs["NEW"];
			}
		} else {
			debug("ERROR: No working area page for workflow is defined!");
		}
	}
	function todos_processIncoming($tUid)	{
		global $SOBE, $LANG;

			// PROCESSING:
		$data = t3lib_div::GPvar("data",1);
//debug($data);
//debug(t3lib_div::GPvar("create_todo"));

		// ********************************
		// Instance updated 
		// ********************************
		if (t3lib_div::GPvar("newStatus") && is_array($data["sys_todos_users_mm"]))	{	// A status is updated
			$RD_URL="";
			reset($data["sys_todos_users_mm"]);
			while(list($key)=each($data["sys_todos_users_mm"]))	{
				$key = intval($key);
				$query = $this->todos_getQueryForTodoRels(" AND sys_todos_users_mm.mm_uid=".$key, "sys_todos_users_mm.*,sys_todos.cruser_id,sys_todos.type", 1);
				$res = mysql(TYPO3_db,$query);
				if ($row = mysql_fetch_assoc($res))	{
					if ($data["sys_todos_users_mm"][$key]["status"]["code"]>0)	{
						$wF = $row["type"];
						if (substr($wF,0,3)=="wf_")	{
							$workflowRecord=t3lib_BEfunc::getRecord("sys_workflows",substr($wF,3));
						} else {unset($workflowRecord);}
	
						$noUpdate=0;
	//	debug($row);
	
						$status_log = unserialize($row["status_log"]);
						if (!is_array($status_log))	$status_log=array();
						$statLogDat = array(
							"code" => $data["sys_todos_users_mm"][$key]["status"]["code"],
							"issuer" => $GLOBALS["BE_USER"]->user["uid"],
							"tstamp" => time(),
							"uid_foreign_before" => $row["uid_foreign"],
							"comment" => $data["sys_todos_users_mm"][$key]["status"]["comment"]
						);
						
						$field_values=array();
						$field_values["status"]=$data["sys_todos_users_mm"][$key]["status"]["code"];
						$field_values["tstamp"]=time();
						$field_values["is_read"]=0;	// Not used yet, but the point is that this flag is set when a target users looks at the item for the first time. This may later be used to inform the owner of the item whether it has been looked at or not. Here it's reset for every change to the log. Maybe it should be changed for each new target only.?
	
						// target:
						switch($field_values["status"])	{
							case 1:		// todos_status_comment, no change of target
							break;
							case 2:		// todos_status_begin, no change of target (at this point)
								if (is_array($workflowRecord) && $workflowRecord["tablename"] && !$row["rec_reference"])	{
									$recId = $this->todos_beginWorkflow($workflowRecord);
									if ($recId)	{
										$field_values["rec_reference"]=$recId;
										$RD_URL = $this->getEditRedirectUrlForReference($recId);
									} else {
										debug("ERROR: The record was not created, so either the workflow is not properly configured or the user did not have permissions to create the record (check the system log for details if this is the case)");
									}
								} else {
									debug("ERROR: No workflow record found OR no tablename defined OR there was already a record reference in the record!");
								}
							break;
							case 3:		// todos_status_end, pass on to reviewer if found (may select reviewer in form), else back to admin
								$first=0;
									// Trying to find a review user if any and apply this user instead of the owner.
								if (is_array($workflowRecord) && $workflowRecord["tablename"])	{
									$revUsers = $this->todos_getReviewUsers($workflowRecord["uid"]);
									reset($revUsers);
									while(list($u_id)=each($revUsers))	{
											// CHECK IF the submittet target user matches one of the reviewers
										if (!$first)	$first=$u_id;
										if ($u_id == $data["sys_todos_users_mm"][$key]["status"]["newTarget"])	{
											$field_values["uid_foreign"]=$u_id;
											break;
										}
									}
									
								}
								if (!$field_values["uid_foreign"])	{	// IF the target is NOT found yet (may have been between the submitted targets.)
									$field_values["uid_foreign"]= $first ? $first : $row["cruser_id"];	// ... select the first review user and if that is not set, select the owner
								}
							break;
							case 4:		// todos_status_passOn, just pass on to selected target
								if (intval($data["sys_todos_users_mm"][$key]["status"]["newTarget"]))	{
									$field_values["uid_foreign"]=$data["sys_todos_users_mm"][$key]["status"]["newTarget"];
								}
							break;
							case 5:		// todos_status_reject, target = sender user
								$field_values["uid_foreign"]=$row["cruser_id"];
							break;
	
							
							case 100:		// Reset status-log
								if ($this->BE_USER->user["uid"]==$row["cruser_id"])	{	// Must own
									$statLogDat["status_log_clear"]=1;
								} else {$noUpdate=1;}
							break;
							case 103:		// Finalize
								if ($this->BE_USER->user["uid"]==$row["cruser_id"])	{	// Must own
									$field_values["uid_foreign"]=$row["cruser_id"];
									$field_values["finalized"] = $this->todos_finalizeWorkflow($workflowRecord,$row) ? 1 : 0;
								} else {$noUpdate=1;}
							break;
	/*							case 101:
								if ($this->BE_USER->user["uid"]==$row["cruser_id"])	{	// Must own
									$field_values["deleted"]=1;
	//								debug("DELETE");
								}
							break;
	*/						case 102:
								if ($this->BE_USER->user["uid"]==$row["cruser_id"])	{	// Must own
									$statLogDat["uid_foreign"] = $data["sys_todos_users_mm"][$key]["status"]["newTarget"];
									$field_values=array();
									$field_values["uid_local"]=$row["uid_local"];
									$field_values["uid_foreign"]=$statLogDat["uid_foreign"];
									$field_values["status"]=102;
									$field_values["tstamp"]=time();
									$field_values["status_log"]=serialize(array($statLogDat));
									
									$q = t3lib_BEfunc::DBcompileInsert("sys_todos_users_mm",$field_values);
									$res = mysql(TYPO3_db,$q);
	
	//									debug($field_values);
								
									$noUpdate=1;
								}
							break;
						}
	
						if (!$noUpdate)	{
							if (isset($field_values["uid_foreign"]))	$statLogDat["uid_foreign"] = $field_values["uid_foreign"];
							$status_log[]=$statLogDat;
							$field_values["status_log"]=serialize($status_log);
			
							$q = t3lib_BEfunc::DBcompileUpdate("sys_todos_users_mm","mm_uid=".$key,$field_values);
							$res = mysql(TYPO3_db,$q);
						}
					}
					
						// Finished?
					if (isset($data["sys_todos_users_mm"][$key]["finished_instance"]) && $this->BE_USER->user["uid"]==$row["cruser_id"])	{
						$field_values=array();
						$field_values["finished_instance"]=$data["sys_todos_users_mm"][$key]["finished_instance"]?1:0;
						$q = t3lib_BEfunc::DBcompileUpdate("sys_todos_users_mm","mm_uid=".$key,$field_values);
						$res = mysql(TYPO3_db,$q);
					}
				} else {
//							debug("No way!");
				}
			}


				// If redirect, do that.
			if ($RD_URL)	{
				header("Location: ".$RD_URL);
			}
		}

		// ***********************************
		// sys_todos are created/updated
		// ***********************************
		if (t3lib_div::GPvar("create_todo") && is_array($data["sys_todos"]))	{	// A todo is created 
			reset($data["sys_todos"]);
			$key = key($data["sys_todos"]);
			if ($key=="NEW")	{
				if ($data["sys_todos"][$key]["target_user"] && $data["sys_todos"][$key]["type"] && $data["sys_todos"][$key]["title"])	{
					$fields_values=array();
					$fields_values["title"]=$data["sys_todos"][$key]["title"];
					$fields_values["type"]=$data["sys_todos"][$key]["type"];
					$fields_values["deadline"]=$data["sys_todos"][$key]["deadline"];
					$fields_values["description"]=$data["sys_todos"][$key]["description"];
					$fields_values["deleted"]=0;
					$fields_values["finished"]=0;
					$fields_values["tstamp"]=time();
					$fields_values["crdate"]=time();
					$fields_values["cruser_id"]=$this->BE_USER->user["uid"];

					$query = t3lib_BEfunc::DBcompileInsert("sys_todos",$fields_values);
					$res=mysql(TYPO3_db,$query);

						// Relation:
					if (!mysql_error())	{
						$fields_values=array();
						$fields_values["uid_local"]=mysql_insert_id();
						$fields_values["uid_foreign"]=$data["sys_todos"][$key]["target_user"];
						$fields_values["tstamp"]=time();
						$query = t3lib_BEfunc::DBcompileInsert("sys_todos_users_mm",$fields_values);
						$res=mysql(TYPO3_db,$query);
					}

						// SEnding email notification and filling the emRec array:
					$tempQ="";
					$emRec=array();
					if ($data["sys_todos"][$key]["target_user"]>0)		{	// Ordinary user
						$tempQ = "SELECT uid,username,realName,email FROM be_users WHERE uid=".intval($data["sys_todos"][$key]["target_user"]).t3lib_BEfunc::deleteClause("be_users");
					} 
					if ($data["sys_todos"][$key]["target_user"]<0)		{	// Users in group
						$tempQ = "SELECT uid,username,realName,email FROM be_users WHERE ".t3lib_BEfunc::listQuery("usergroup_cached_list",abs($data["sys_todos"][$key]["target_user"])).t3lib_BEfunc::deleteClause("be_users");
					}
					if ($tempQ)	{
						$sAE = t3lib_div::GPvar("sendAsEmail");	// This flag must be set in order for the email to get sent
						$res = mysql(TYPO3_db,$tempQ);
						while($brow=mysql_fetch_assoc($res))	{
							$sendM=0;
							if ($sAE && strstr($brow["email"],"@") && $brow["uid"]!=$this->BE_USER->user["uid"])	{	// Send-flag must be set, the user must have an email address and finally mails are not sent to the creating user, should he be in the group.
								$this->sendEmail($brow["email"],$data["sys_todos"][$key]["title"],$data["sys_todos"][$key]["description"]);
								$sendM=1;
							}
							$emRec[] = $brow["username"].($sendM ? " (".$brow["email"].")" : "");
						}	
					}
					if (count($emRec))	{	// $emRec just stores the users which is in the target group/target-user and here the list is displayed for convenience.
						$emailList=implode("<BR>&nbsp;&nbsp;",$emRec);
						$theCode.= $SOBE->doc->section($LANG->getLL("todos_created"),$LANG->getLL("todos_created_msg")."<BR>&nbsp;&nbsp;".$emailList,0,1,1);
					}
				} else {
//					$theCode.= $SOBE->doc->section($LANG->getLL("todos_created"),$this->errorIcon().rfw($LANG->getLL("todos_createdError_msg")),0,1);
				}
			} else {	// Edit todo:
				$editRow = t3lib_BEfunc::getRecordRaw("sys_todos","uid=".$key);
				if (is_array($editRow) && $editRow["cruser_id"]==$this->BE_USER->user["uid"] && $data["sys_todos"][$key]["title"])	{
					$fields_values=array();
					$fields_values["title"]=$data["sys_todos"][$key]["title"];
					$fields_values["deadline"]=$data["sys_todos"][$key]["deadline"];
					$fields_values["description"]=$data["sys_todos"][$key]["description"];
					$fields_values["tstamp"]=time();

					$query = t3lib_BEfunc::DBcompileUpdate("sys_todos","uid=".$key,$fields_values);
					$res=mysql(TYPO3_db,$query);
				}
			}
		}
		
		
		// *************************************************
		// sys_todos / instances are updated regarding DONE		
		// *************************************************
		if (t3lib_div::GPvar("marked_todos"))	{
			$action = t3lib_div::GPvar("marked_todos_action");
			$done = t3lib_div::GPvar("DONE",1);
			if (is_array($done))	{
				while(list($uidKey,$value)=each($done))	{
					$uidKey = intval($uidKey);
					if ($uidKey<0)	{
						$uidKey = abs($uidKey);
						$sys_todos_users_mm_row = t3lib_BEfunc::getRecordRaw("sys_todos_users_mm","mm_uid=".$uidKey);
						if (is_array($sys_todos_users_mm_row))	{
							$sys_todos_row = t3lib_BEfunc::getRecordRaw("sys_todos","uid=".intval($sys_todos_users_mm_row["uid_local"]));
							if (is_array($sys_todos_row) && $sys_todos_row["cruser_id"]==$this->BE_USER->user["uid"])	{
								$fields_values=array();
								if ($action==127 && $value)	$fields_values["deleted"]=1;
								$fields_values["finished_instance"]=$value?1:0;
								$query = t3lib_BEfunc::DBcompileUpdate("sys_todos_users_mm","mm_uid=".$uidKey,$fields_values);
								$res=mysql(TYPO3_db,$query);
								
									// Check if there are any sys_todos_users_mm left, which are not deleted. If there are not, delete the sys_todos item
								$isNotDeleted = t3lib_BEfunc::getRecordRaw("sys_todos_users_mm","uid_local=".intval($sys_todos_row["uid"])." AND deleted=0");
								if (!is_array($isNotDeleted))	{
										// Delete sys_todos
									$fields_values=array();
									$fields_values["finished"]=1;
									$fields_values["deleted"]=1;
									$query = t3lib_BEfunc::DBcompileUpdate("sys_todos","uid=".$sys_todos_row["uid"],$fields_values);
//									debug($query);
									$res=mysql(TYPO3_db,$query);
								}
							}
						}
						
					} else {
						$sys_todos_row = t3lib_BEfunc::getRecordRaw("sys_todos","uid=".$uidKey);
						if (is_array($sys_todos_row) && $sys_todos_row["cruser_id"]==$this->BE_USER->user["uid"])	{
							$fields_values=array();
							$fields_values["finished"]=$value?1:0;
							if ($action==127 && $value)	$fields_values["deleted"]=1;
							$query = t3lib_BEfunc::DBcompileUpdate("sys_todos","uid=".$uidKey,$fields_values);
							$res=mysql(TYPO3_db,$query);

								// Also set status for instances, if they are checked for main item:
							if ($fields_values["deleted"])	{
								$inst_fields_values=array();
								$inst_fields_values["deleted"]=1;
									// Update all relations to the sys_todos
								$query = t3lib_BEfunc::DBcompileUpdate("sys_todos_users_mm","uid_local=".$uidKey,$inst_fields_values);
								$res=mysql(TYPO3_db,$query);
							}
						}
					}
				}
			}
		}
		return $theCode;
	}
	function todos_workflowTitle($todoTypes,$type)	{
		if (!isset($this->todoTypesCache[$type]))	{
			if (isset($todoTypes[$type]))	{
				$this->todoTypesCache[$type] = $todoTypes[$type];
			} elseif (substr($type,0,3)=="wf_") {
				$workflowRecord=t3lib_BEfunc::getRecord("sys_workflows",substr($type,3));
				$this->todoTypesCache[$type] = $workflowRecord["title"];
			}
		} 
		return $this->todoTypesCache[$type];
	}
	function todos_displayTodo($todoTypes,$tUid)	{
		global $SOBE, $LANG;

		if ($tUid>0)	{
			$query = "SELECT * FROM sys_todos WHERE uid=".intval($tUid)." AND cruser_id=".$this->BE_USER->user["uid"]." AND NOT deleted";
		} else {
			$query = $this->todos_getQueryForTodoRels(" AND sys_todos_users_mm.mm_uid=".abs($tUid));
//debug($query);
		}
		$res = mysql(TYPO3_db,$query);
		$msg=array();
		$workflowRecord="";
		if ($row = mysql_fetch_assoc($res))	{
//debug($row);
			$editIcon = $row["cruser_id"]==$this->BE_USER->user["uid"] ? '<a href="index.php?sys_todos_uid='.$tUid.'&editTodo=1#todo"><img src="'.$this->backPath.'gfx/edit2.gif" width="11" height="12" vspace=2 border="0" align=top></a>' : '';
			$iconName = 'tc_todos'.($row["cruser_id"]==$this->BE_USER->user["uid"]?'':'_foreign').'.gif';
			$header=fw('<nobr><img src="'.$this->backPath.'gfx/i/'.$iconName.'" width="18" height="16" hspace=2 border=0 align=top title="'.$LANG->getLL("todos_item").' #'.$row["uid"].'">'.$editIcon.' <strong>'.htmlspecialchars($row["title"]).'</strong></nobr><BR>');
			$formA=array();
			$formA[]=array($LANG->getLL("todos_createdBy").":&nbsp;", $this->userGroupArray[2][$row["cruser_id"]]["username"]." (".$this->userGroupArray[2][$row["cruser_id"]]["realName"]."), ".$this->dateTimeAge($row["crdate"],-1));
			$dLine = $this->dateTimeAge($row["deadline"],-1)."&nbsp;";
			if ($row["deadline"]<time())	$dLine = rfw($dLine);
			$formA[]=array($LANG->getLL("todos_deadline").":&nbsp;", $dLine);
			$formA[]=array($LANG->getLL("todos_description").":&nbsp;", nl2br($row["description"])."&nbsp;");

			if ($row["type"] && $row["type"]!="plain")	{
				$formA[]=array($LANG->getLL("todos_type").":&nbsp;", $this->todos_workflowTitle($todoTypes,$row["type"]));
				$wF = $row["type"];
				if (substr($wF,0,3)=="wf_")	{
					$workflowRecord=t3lib_BEfunc::getRecord("sys_workflows",substr($wF,3));
					if (is_array($workflowRecord) && $workflowRecord["tablename"])	{
						$formA[]=array($LANG->getLL("todos_workflowDescr").":&nbsp;", $workflowRecord["description"]);
	//					debug($workflowRecord);
					}
				}
			}

			$msg[] = $header.$SOBE->doc->table($formA);

			if (!t3lib_div::GPvar("editTodo"))	{
				$query=t3lib_BEfunc::mm_query("sys_todos_users_mm.*","sys_todos","sys_todos_users_mm","","
				 AND NOT sys_todos_users_mm.deleted
				 AND NOT sys_todos.deleted".($tUid<0?" AND sys_todos_users_mm.mm_uid=":" AND sys_todos.uid=").abs($tUid));
	
				// Display todo log:
				$res = mysql(TYPO3_db,$query);
				$this->insCounter=0;
				while ($rel_row = mysql_fetch_assoc($res))	{
					$msg[] = "<HR>".$this->todos_printStatus($rel_row,$row,$workflowRecord,$tUid,mysql_num_rows($res));
				}
				$msg[]='<BR><input type="submit" name="newStatus" value="'.$LANG->getLL("todos_newStatus").'"> <input type="submit" name="cancel" value="'.$LANG->getLL("lCancel").'" onClick="document.editform.sys_todos_uid.value=0;">
				<input type="hidden" name="sys_todos_uid" value="'.$tUid.'"><BR>';
			}

			if (count($msg))	{
				$theCode.= $SOBE->doc->spacer(20);
				$theCode.= $SOBE->doc->section('<a name="todo"></a>'.$LANG->getLL("todo_details"),implode("",$msg),0,1);
			}

				// Edit form:			
			if (t3lib_div::GPvar("editTodo") && $row["cruser_id"]==$this->BE_USER->user["uid"])	{
				$theCode.=$this->todos_createForm($todoTypes,$row);
			}
		}
		return $theCode;
	}
	function todos_printStatus($rel_row,$todo_row,$workflow_row,$tUid,$countOfInstances=0)	{
		global $SOBE, $LANG, $TCA;

		if (is_array($workflow_row))	{
			$revUsers = $this->todos_getReviewUsers($workflow_row["uid"]);
		} else $revUsers=array();
		
		$noExtraFields=0;
		
		$theCode="";
		$statusLabels = array();
		$statusLabels[1]=htmlspecialchars($LANG->getLL("todos_status_comment"));
		$statusLabels[2]=htmlspecialchars($LANG->getLL("todos_status_begin"));
		$statusLabels[3]=htmlspecialchars($LANG->getLL("todos_status_end"));
		$statusLabels[4]=htmlspecialchars($LANG->getLL("todos_status_passOn"));
		$statusLabels[5]=htmlspecialchars($LANG->getLL("todos_status_reject"));

		$statusLabels[100]=htmlspecialchars($LANG->getLL("todos_status_resetStatus"));
		$statusLabels[103]=htmlspecialchars($LANG->getLL("todos_status_finalize"));
//		$statusLabels[101]=htmlspecialchars($LANG->getLL("todos_status_delete"));
		$statusLabels[102]=htmlspecialchars($LANG->getLL("todos_status_newInstance"));
		
		$allowedTargetCodes = "2,3,4,102";
		
		$this->insCounter++;
		//$this->insCounter.' /
		$iSt = ' ('.$LANG->getLL("todos_instance").' #'.$rel_row["mm_uid"].')';

		$theCode.=fw('<BR><strong>'.$LANG->getLL("todos_logEntries").$iSt.':</strong><BR>');
		$log = unserialize($rel_row["status_log"]);
		$prevUsersGroups=array();
		if (is_array($log))	{
			$lines=array();

			reset($log);
			$c=0;
			while(list(,$logDat)=each($log))	{
				$prevUsersGroups[] = $logDat["uid_foreign_before"];
		//		debug($logDat);
				if ($logDat["status_log_clear"])	{
					$c=0;
					$lines=array();
				}
		
				$c++;
				$bgColor=' bgColor="'.(($c+1)%2 ? $GLOBALS["SOBE"]->doc->bgColor : $this->xCol).'"';
				$lines[]='<tr'.$bgColor.'>
					<td valign=top nowrap width=10%>'.
						'<strong>'.$statusLabels[$logDat["code"]].'</strong><BR>'.
						$this->printUserGroupName($logDat["issuer"]).'<BR>'.
						$this->dateTimeAge($logDat["tstamp"],1).'<BR>'.
						(isset($logDat["uid_foreign"]) ? "<em>".$LANG->getLL("todos_logEntries_lTarget")."</em>:<BR>".$this->printUserGroupName($logDat["uid_foreign"]).'<BR>' : '').
					'<BR></td>
					<td valign=top>&nbsp;&nbsp;&nbsp;</td>
					<td valign=top width=80%>'.nl2br(htmlspecialchars($logDat["comment"])).'</td>
				</tr>';
			}

			array_unshift($lines,'<tr bgcolor="'.$SOBE->doc->bgColor5.'">
				<td nowrap><strong>'.fw($LANG->getLL("todos_logEntries_lStatusInfo").':').'</strong></td>
				<td>&nbsp;</td>
				<td nowrap><strong>'.fw($LANG->getLL("todos_logEntries_lDetails").':').'</strong></td>
			</tr>');

			$theCode.= '<table border=0 cellpadding=0 cellspacing=0 width="100%">'.implode("",$lines).'</table>';
		} else {
			$theCode.=fw($LANG->getLL("todos_logEntries_msg1"))."<BR>";
		}
		if ($rel_row["uid_foreign"])	{
			$theCode.=fw("<BR>".$LANG->getLL("todos_logEntries_lTargetedAt").": <strong>".$this->printUserGroupName($rel_row["uid_foreign"],1)."</strong><BR>");
		} else {
			$theCode.=fw("<BR><strong>".$LANG->getLL("todos_logEntries_lnoTarget")."</strong>");
		}
		
		if ($rel_row["rec_reference"])	{
			$theCode.="<BR>".fw($LANG->getLL("todos_logEntries_lRecordRelated").":<BR>");
			$recRelParts = explode(":",$rel_row["rec_reference"]);
			$recordRelated=t3lib_BEfunc::getRecord($recRelParts[0],$recRelParts[1]);
			if ($recordRelated)	{
				$theCode.=fw('<a href="'.$this->getEditRedirectUrlForReference($rel_row["rec_reference"]).'"><img src="'.$this->backPath.'gfx/edit2.gif" width="11" height="12" hspace=3 vspace=2 border="0" align=top></a>'.
							($recRelParts[0]=="pages" ? $SOBE->doc->viewPageIcon($recRelParts[1],$this->backPath,'align=top hspace=2') : "").
							t3lib_iconWorks::getIconImage($recRelParts[0],$recordRelated,$this->backPath," align=top hspace=2").
							htmlspecialchars($recordRelated[$TCA[$recRelParts[0]]["ctrl"]["label"]])
						);
			} else {
				$theCode.=rfw("<strong>".$LANG->getLL("todos_errorNoRecord")."</strong>");
			}
			
		}
		$theCode.="<BR><BR>";
		
		// ****************************
		// Status selector
		// ****************************
		$opt=Array();
		$statusLabels_copy = $statusLabels;

			// Unset certain items which we do not present in the menu under certain circumstances.
		if (!is_array($workflow_row) || !$workflow_row["tablename"] || $rel_row["rec_reference"])		unset($statusLabels_copy[2]);
		if (!is_array($workflow_row) || !$workflow_row["tablename"] || !$rel_row["rec_reference"])		unset($statusLabels_copy[103]);
		if (!count($revUsers) || (!$rel_row["rec_reference"] && is_array($workflow_row)))	unset($statusLabels_copy[3]);
		if ($this->BE_USER->user["uid"]!=$todo_row["cruser_id"])	{
			unset($statusLabels_copy[100]);
//			unset($statusLabels_copy[101]);
			unset($statusLabels_copy[102]);
			unset($statusLabels_copy[103]);
		} else {
			unset($statusLabels_copy[5]);
		}
		
		if ($tUid<0)	unset($statusLabels_copy[102]);		// Don't allow new instance creation if we're not looking at the TODO item but an instance.

			// If finalized:
		if ($rel_row["finalized"])	{
			$statusLabels_copy = array();
			if ($this->BE_USER->user["uid"]==$todo_row["cruser_id"])	{
//				$statusLabels_copy[101] = $statusLabels[101];
				$statusLabels_copy[102] = $statusLabels[102];
				$noExtraFields=1;
			}
		}

		$formCodeAccu="";
		if (count($statusLabels_copy))	{
			reset($statusLabels_copy);
			if ($countOfInstances>1 || $this->BE_USER->user["uid"]==$todo_row["cruser_id"])	$opt[]='<option value="0"></option>';
			while(list($kk,$vv)=each($statusLabels_copy))	{
				$opt[]='<option value="'.$kk.'">'.$vv.'</option>';
			}
				$onChange="var allowedCodes=',".$allowedTargetCodes.",'; 
					if (allowedCodes.indexOf(','+this.options[this.selectedIndex].value+',')==-1) {
						document.editform['data[sys_todos_users_mm][".$rel_row["mm_uid"]."][status][newTarget]'].selectedIndex=0;
					}";
			$formCodeAccu.=htmlspecialchars($LANG->getLL("todos_status_addStatus")).':<BR><select name="data[sys_todos_users_mm]['.$rel_row["mm_uid"].'][status][code]" onChange="'.$onChange.'">'.implode("",$opt).'</select><BR>';
			
			if (!$noExtraFields)	{
				$opt=Array();
				$opt[]='<option value="0"></option>';
//				$opt[]='<option value="0">[ '.htmlspecialchars($LANG->getLL("todos_selectTargetUG")).' ]</option>';
				
					// Sender
				$revUserRec = t3lib_BEfunc::getRecord("be_users",$todo_row["cruser_id"]);
				$opt[]='<option value="'.$todo_row["cruser_id"].'">'.htmlspecialchars($LANG->getLL("todos_sender").': '.$revUserRec["username"].($revUserRec["realName"]?" (".$revUserRec["realName"].")":"")).'</option>';
		
					// Review users:
				reset($revUsers);
				while(list($u_id,$revUserRec)=each($revUsers))	{
						// CHECK IF they
					$opt[]='<option value="'.$u_id.'">'.htmlspecialchars($LANG->getLL("todos_reviewer").': '.$revUserRec["username"].($revUserRec["realName"]?" (".$revUserRec["realName"].")":"")).'</option>';
				}
				
				// Users through time:
				$prevUsersGroups[]=$this->BE_USER->user["uid"];
				$prevUsersGroups[]=$rel_row["uid_foreign"];
				if (is_array($prevUsersGroups) && count($prevUsersGroups))	{
					$opt[]='<option value="0"></option>';
					$opt[]='<option value="0">'.htmlspecialchars($LANG->getLL("todos_pastUG")).'</option>';
					$prevUsersGroups = array_unique($prevUsersGroups);
					reset($prevUsersGroups);
					while(list(,$UGuid)=each($prevUsersGroups))	{
						if ($UGuid)		$opt[]='<option value="'.$UGuid.'">'.htmlspecialchars(($UGuid>0?$LANG->getLL("todos_user"):$LANG->getLL("todos_group")).": ".$this->printUserGroupName($UGuid)).'</option>';
					}
				}

				if ($this->BE_USER->user["uid"]==$todo_row["cruser_id"])	{
					$opt[]='<option value="0"></option>';
					$opt[]='<option value="0">'.htmlspecialchars($LANG->getLL("todos_allUG")).'</option>';

					if ($todo_row["type"]=="plain")	{
						$opt = array_merge($opt,$this->tasks_makeTargetSelector($this->userGroupArray[0],$this->userGroupArray[1],0,1));
					} elseif (is_array($workflow_row))	{
						$grL = implode(",",t3lib_div::intExplode(",",$workflow_row["target_groups"]));
						$wf_groupArray=t3lib_BEfunc::getGroupNames("title,uid","AND uid IN (".($grL?$grL:0).")");
						$wf_userArray = t3lib_BEfunc::blindUserNames($this->userGroupArray[2],array_keys($wf_groupArray),1);
						$opt = array_merge($opt,$this->tasks_makeTargetSelector($wf_userArray,$wf_groupArray,0,1));
					}
				}
				
				$onChange="var allowedCodes=',".$allowedTargetCodes.",'; 
					if (allowedCodes.indexOf(
						','
						+ document.editform['data[sys_todos_users_mm][".$rel_row["mm_uid"]."][status][code]'].options[document.editform['data[sys_todos_users_mm][".$rel_row["mm_uid"]."][status][code]'].selectedIndex].value
						+',')==-1 || this.options[this.selectedIndex].value==0) {
							this.selectedIndex=0;
						}";
				$formCodeAccu.=htmlspecialchars($LANG->getLL("todos_status_selectTarget")).':<BR><select name="data[sys_todos_users_mm]['.$rel_row["mm_uid"].'][status][newTarget]" onChange="'.$onChange.'">'.implode("",$opt).'</select><BR>';

				$formCodeAccu.=htmlspecialchars($LANG->getLL("todos_statusNote")).':<BR><textarea rows="10" name="data[sys_todos_users_mm]['.$rel_row["mm_uid"].'][status][comment]"'.$SOBE->doc->formWidthText(40).'></textarea><BR>';
			}
		}
		if ($this->BE_USER->user["uid"]==$todo_row["cruser_id"])	{
			$formCodeAccu.='<input type="hidden" name="data[sys_todos_users_mm]['.$rel_row["mm_uid"].'][finished_instance]" value="0"><input type="checkbox" name="data[sys_todos_users_mm]['.$rel_row["mm_uid"].'][finished_instance]" value="1"'.($rel_row["finished_instance"]?" checked":"").'>'.
				htmlspecialchars($LANG->getLL("todos_finished"));
		}
		
		
		return $theCode.fw($formCodeAccu);
	}
	function negateList($list)	{
		$listArr = explode(",",$list);
		while(list($k,$v)=each($listArr))	{
			$listArr[$k]=$v*-1;
		}
//		debug(implode(",",$listArr));
		return implode(",",$listArr);
	}
	function todos_getQueryForTodoRels($extraWhere="",$selectFields="",$allowOwn=0)	{
		$groupQ = $this->BE_USER->user["usergroup_cached_list"] ? " OR sys_todos_users_mm.uid_foreign IN (".$this->negateList($this->BE_USER->user["usergroup_cached_list"]).")" : "";
		if ($allowOwn)	$groupQ.=" OR sys_todos.cruser_id=".intval($this->BE_USER->user["uid"]);
		$query=t3lib_BEfunc::mm_query($selectFields?$selectFields:"sys_todos.*,sys_todos_users_mm.mm_uid,sys_todos_users_mm.uid_foreign,sys_todos_users_mm.finished_instance","sys_todos","sys_todos_users_mm","",
			" AND (sys_todos_users_mm.uid_foreign=".intval($this->BE_USER->user["uid"]).$groupQ.")".	// UID foreign must match the current users id OR be within the group-list of the user
			" AND sys_todos.deleted=0 AND sys_todos_users_mm.deleted=0".		// Todo AND it's relation must not be deleted
			" AND ((sys_todos.finished=0 AND sys_todos_users_mm.finished_instance=0) OR sys_todos.cruser_id=".intval($this->BE_USER->user["uid"]).")".	// Either the user must own his todo-item (in which case finished items are displayed) OR the item must NOT be finished (which will remove it from others lists.)
			$extraWhere.
			" ORDER BY sys_todos.deadline");	// Sort by deadline
			
		return $query;
	}
	function todos_getReviewUsers($wfUid)	{
		$query = t3lib_BEfunc::mm_query("be_users.uid,be_users.username,be_users.realName","sys_workflows","sys_workflows_rvuser_mm","be_users",
			t3lib_BEfunc::deleteClause("be_users").
			t3lib_BEfunc::deleteClause("sys_workflows").
			" AND sys_workflows.uid=".$wfUid.
			" ORDER BY be_users.username");

		$res = mysql(TYPO3_db, $query);
		$outARr=array();
		while($row = mysql_fetch_assoc($res))	{
			$outARr[$row["uid"]]=$row;
		}
		return $outARr;
	}
	function todos_displayLists($todoTypes,$tUid)	{
		global $SOBE, $LANG;

		$lines=array();
		$ownCount=0;
		$bgColor_H=' bgcolor="'.$GLOBALS["SOBE"]->doc->bgColor5.'"';
			$lines[]='<tr>
				<td'.$bgColor_H.'>'.fw("&nbsp;").'</td>
				<td'.$bgColor_H.' width=50%><strong>'.fw($LANG->getLL("todos_title").":").'</strong></td>
				<td'.$bgColor_H.' width=25%><strong>'.fw($LANG->getLL("todos_type").":").'</strong></td>
				<td'.$bgColor_H.' width=25%><strong>'.fw($LANG->getLL("todos_deadline").":").'</strong></td>
				<td'.$bgColor_H.'><strong>'.fw($LANG->getLL("todos_finished").":").'</strong></td>
			</tr>';
			
			// SELECT Incoming todos (incl. own todos):
			// Incoming todos are those set for a user which he must carry out. Those are the relations in sys_todos_users_mm where uid_foreign is either the users uid or the negative uid of a group his a member of
		$query = $this->todos_getQueryForTodoRels();
		
		$res = mysql(TYPO3_db,$query);
		echo mysql_error();
		$out="";
		if (mysql_num_rows($res))	{

			$c=0;
			while($row=mysql_fetch_assoc($res))	{
				$c++;
				if ($tUid==-$row["mm_uid"])	{
					$bTb="<B>";
					$bTe="</B>";
					$active='<img src="'.$this->backPath.'gfx/content_client.gif" width="7" height="10" border="0" align=top>';
				} else {
					$bTb=$bTe="";
					$active="";
				}
				$t_dL=$this->dateTimeAge($row["deadline"],-1);
				$t_dL = ($row["deadline"]>time()) ? fw($t_dL) : rfw($t_dL);
				$iconName = 'tc_todos'.($row["cruser_id"]==$this->BE_USER->user["uid"]?'':'_foreign').($row["uid_foreign"]>=0?'':'_group').'.gif';
				$bgColor=' bgColor="'.(($c+1)%2 ? $GLOBALS["SOBE"]->doc->bgColor : $this->xCol).'"';
				$lines[]='<tr>
					<td'.$bgColor.'>'.$this->linkTodos('<img src="'.$this->backPath.'gfx/i/'.$iconName.'" width="18" height="16" hspace=2 border=0 title="'.$LANG->getLL("todos_instance").' #'.$row["mm_uid"].',  '.htmlspecialchars($LANG->getLL("todos_createdBy").": ".$this->userGroupArray[2][$row["cruser_id"]]["username"]." (".$this->userGroupArray[2][$row["cruser_id"]]["realName"].")").'">',-$row["mm_uid"]).'</td>
					<td'.$bgColor.' nowrap>'.$this->linkTodos($active.fw($bTb."&nbsp;".$this->fixed_lgd($row["title"])."&nbsp;".$bTb),-$row["mm_uid"]).'</td>
					<td'.$bgColor.' nowrap>'.fw("&nbsp;".t3lib_div::fixed_lgd($this->todos_workflowTitle($todoTypes,$row["type"]),15)."&nbsp;").'</td>
					<td'.$bgColor.' nowrap>'.$t_dL.'&nbsp;</td>
					<td'.$bgColor.' align=right>'.($row["cruser_id"]==$this->BE_USER->user["uid"]?'<input type="hidden" name="DONE['.-$row["mm_uid"].']" value=0><input type="checkbox" name="DONE['.-$row["mm_uid"].']" value="1"'.($row["finished_instance"]?" checked":"").'>':fw('&nbsp;')).'</td>
				</tr>';
				
				if ($row["cruser_id"]==$this->BE_USER->user["uid"])	$ownCount++;
			}
		}
		
			
			
			// SELECT Master todos for list:
			// A master todo is an OUTGOING todo you have created, in this case for other users.
		$query=t3lib_BEfunc::mm_query("sys_todos.*,sys_todos_users_mm.uid_foreign","sys_todos","sys_todos_users_mm","",
			" AND sys_todos_users_mm.uid_foreign!=".intval($this->BE_USER->user["uid"]).
			" AND sys_todos.cruser_id=".intval($this->BE_USER->user["uid"]).
			" AND sys_todos.deleted=0".
			" GROUP BY sys_todos.uid".
			" ORDER BY sys_todos.deadline");

		$res = mysql(TYPO3_db,$query);
		echo mysql_error();
		$out="";
		if (mysql_num_rows($res))	{

			$lines[]='<tr><td colspan=5>&nbsp;</td></tr>';
			$lines[]='<tr>
				<td'.$bgColor_H.'>&nbsp;</td>
				<td'.$bgColor_H.' colspan=4><strong>'.fw($LANG->getLL("todos_list_master").':').'</strong></td>
			</tr>';

			$c=0;
			while($row=mysql_fetch_assoc($res))	{
				$c++;
				$bgColor=' bgColor="'.(($c+1)%2 ? $GLOBALS["SOBE"]->doc->bgColor : $this->xCol).'"';
				if ($tUid==$row["uid"])	{
					$bTb="<B>";
					$bTe="</B>";
					$active='<img src="'.$this->backPath.'gfx/content_client.gif" width="7" height="10" border="0" align=top>';
				} else {
					$bTb=$bTe="";
					$active="";
				}
				$t_dL=$this->dateTimeAge($row["deadline"],-1);
				$t_dL = ($row["deadline"]>time()) ? fw($t_dL) : rfw($t_dL);
				$iconName = 'tc_todos'.($row["uid_foreign"]>=0?'':'_group').'.gif';
				$bgColor=' bgColor="'.(($c+1)%2 ? $GLOBALS["SOBE"]->doc->bgColor : $this->xCol).'"';
				$lines[]='<tr>
					<td'.$bgColor.'>'.$this->linkTodos('<img src="'.$this->backPath.'gfx/i/'.$iconName.'" width="18" height="16" hspace=2 border=0 title="'.$LANG->getLL("todos_item").' #'.$row["uid"].', '.htmlspecialchars($LANG->getLL("todos_createdBy").": ".$this->userGroupArray[2][$row["cruser_id"]]["username"]." (".$this->userGroupArray[2][$row["cruser_id"]]["realName"].")").'">',$row["uid"]).'</td>
					<td'.$bgColor.' nowrap>'.$this->linkTodos($active.fw($bTb."&nbsp;".$this->fixed_lgd($row["title"])."&nbsp;".$bTb),$row["uid"]).'</td>
					<td'.$bgColor.' nowrap>'.fw("&nbsp;".t3lib_div::fixed_lgd($this->todos_workflowTitle($todoTypes,$row["type"]),15)."&nbsp;").'</td>
					<td'.$bgColor.' nowrap>'.$t_dL.'&nbsp;</td>
					<td'.$bgColor.' align=right>'.($row["cruser_id"]==$this->BE_USER->user["uid"]?'<input type="hidden" name="DONE['.$row["uid"].']" value=0><input type="checkbox" name="DONE['.$row["uid"].']" value="1"'.($row["finished"]?" checked":"").'>':fw('&nbsp;')).'</td>
				</tr>';
				
				if ($row["cruser_id"]==$this->BE_USER->user["uid"])	$ownCount++;
			}

//			$out = '<table border=0 cellpadding=0 cellspacing=0>'.implode("",$lines).'</table>';
//			$theCode.= $SOBE->doc->spacer(10);
//			$theCode.= $SOBE->doc->section($LANG->getLL("todos_list_master"),$out,1,0);
		}

		if (count($lines)>1)	{
			$out = '<table border=0 cellpadding=0 cellspacing=0>'.implode("",$lines).'</table>';
			
			if ($ownCount)	{
				$bMenu = '<BR><div align=right><select name="marked_todos_action">
				<option value=-1></option>
				<option value=127>'.$LANG->getLL("todos_purge").'</option>
				</select><input type="submit" name="marked_todos" value="'.$LANG->getLL("todos_updateMarked").'"></div>';
				$bMenu = fw($bMenu);
			} else $bMenu = "";
			
			
			$theCode.= $SOBE->doc->section($LANG->getLL("todos_list"),$out.$bMenu,0,1);
		}
		return $theCode;
	}
	function todos_createForm($todoTypes,$editRec="")	{
		global $SOBE, $LANG;

			// CREATE/EDIT/VIEW TODO:
		$wF = is_array($editRec) ? $editRec["type"] : t3lib_div::GPvar("workflow_type");
		if ($wF && isset($todoTypes[$wF]))	{
			$type = is_array($editRec) ? $editRec["uid"] : "NEW";
			$formA=array();

			if (!is_array($editRec))	{
					// Making the target_user/group selector:
				if ($wF=="plain")	{		// If the type is plain, the todo-item may be assigned to all users accessible for the current user.
						// Title selector:
					$formA[]=array($LANG->getLL("todos_type").":&nbsp;", $LANG->getLL("todos_plain"));
					$formA[] = $this->tasks_makeTargetSelector($this->userGroupArray[0],$this->userGroupArray[1],$type);
	
				} elseif (substr($wF,0,3)=="wf_")	{	// If it's a workflow from sys_workflows table, the list of target groups and users is re-fetched, according the the target_groups definition.
					$workflowRecord=t3lib_BEfunc::getRecord("sys_workflows",substr($wF,3));
					if (is_array($workflowRecord) && $workflowRecord["tablename"])	{
						$formA[]=array($LANG->getLL("todos_type").":&nbsp;", $workflowRecord["title"]);
							// Get groupnames for todo-tasks

						$grL = implode(",",t3lib_div::intExplode(",",$workflowRecord["target_groups"]));
						$wf_groupArray=t3lib_BEfunc::getGroupNames("title,uid","AND uid IN (".($grL?$grL:0).")");
						$wf_groupArrayUids=array_keys($wf_groupArray);
						$wf_userArray = t3lib_BEfunc::blindUserNames($this->userGroupArray[2],$wf_groupArrayUids,1);
						$formA[] = $this->tasks_makeTargetSelector($wf_userArray,$wf_groupArray,$type);
					}
				}
			}
			
				// Title selector:
			$formA[]=array($LANG->getLL("todos_title").":&nbsp;", '<input type="text" name="data[sys_todos]['.$type.'][title]" value="'.htmlspecialchars(is_array($editRec)?$editRec["title"]:$todoTypes[$wF]).'" max=255'.$SOBE->doc->formWidth(40).'>');

				// Deadline selector:
			$curTodoTime=time();
			$formA[]=array($LANG->getLL("todos_deadline").":&nbsp;", '<input type="text" name="data[sys_todos]['.$type.'][deadline]_hr'.'" onChange="typo3FormFieldGet(\'data[sys_todos]['.$type.'][deadline]\', \'datetime\', \'\', 0,0);"'.$SOBE->doc->formWidth(20).'>
			<input type="hidden" value="'.intval($editRec["deadline"]).'" name="data[sys_todos]['.$type.'][deadline]">
			<select name="_time_selector" onChange="
				document.forms[0][\'data[sys_todos]['.$type.'][deadline]\'].value=(this.options[this.selectedIndex].value>0?this.options[this.selectedIndex].value:(document.forms[0][\'data[sys_todos]['.$type.'][deadline]\'].value!=\'0\'?document.forms[0][\'data[sys_todos]['.$type.'][deadline]\'].value:'.time().')-this.options[this.selectedIndex].value); 
				this.selectedIndex=0; 
				typo3FormFieldSet(\'data[sys_todos]['.$type.'][deadline]\', \'datetime\', \'\', 0,0);
			">
				<option value="0"></option>
				<option value="'.(mktime(0,0,0)+3600*12).'">'.$LANG->getLL("todos_DL_today").'</option>
				<option value="'.(mktime(0,0,0)+3600*24+3600*12).'">'.$LANG->getLL("todos_DL_tomorrow").'</option>
				<option value="'.(mktime(0,0,0)+3600*24*7+3600*12).'">'.$LANG->getLL("todos_DL_weekLater").'</option>
				<option value="'.(mktime(0,0,0)+3600*24*31+3600*12).'">'.$LANG->getLL("todos_DL_monthLater").'</option>
				<option value="'.(-3600*24*1).'">+1 '.$LANG->getLL("todos_DL_day").'</option>
				<option value="'.(-3600*24*2).'">+2 '.$LANG->getLL("todos_DL_days").'</option>
				<option value="'.(-3600*24*4).'">+4 '.$LANG->getLL("todos_DL_days").'</option>
				<option value="'.(-3600*24*7).'">+7 '.$LANG->getLL("todos_DL_days").'</option>
				<option value="'.(-3600*24*14).'">+14 '.$LANG->getLL("todos_DL_days").'</option>
				<option value="'.(-3600*24*31).'">+31 '.$LANG->getLL("todos_DL_days").'</option>
			</select>
			');
			$GLOBALS["SOBE"]->t3lib_TCEforms->extJSCODE.='typo3FormFieldSet("data[sys_todos]['.$type.'][deadline]", "datetime", "", 0,0);';

				// Description:
			$formA[]=array($LANG->getLL("todos_description").":&nbsp;", '<textarea rows="10" name="data[sys_todos]['.$type.'][description]"'.$SOBE->doc->formWidthText(40).'>'.t3lib_div::formatForTextarea(is_array($editRec)?$editRec["description"]:"").'</textarea>');
			
				// Notify email:
			if (!is_array($editRec) && $this->BE_USER->user["email"])	{
				$formA[]=array("&nbsp;", '<input type="checkbox" name="sendAsEmail" value=1>'.$LANG->getLL("todo_email").'<BR>('.$LANG->getLL("messages_replyAddress").': '.$this->BE_USER->user["email"].')');
			}
	
			$formA[]=array("&nbsp;","&nbsp;");
			$onClick = "if (document.forms[0]['data[sys_todos][".$type."][title]'].value=='') {alert(unescape('".rawurlencode($LANG->getLL("todos_mustFillIn"))."'));return false;}";
			$hidden = '<input type=hidden name="data[sys_todos]['.$type.'][type]" value="'.htmlspecialchars($wF).'">';
			if ($type=="NEW")	{
				$formA[]=array("&nbsp;", '<input type="submit" name="create_todo" value="'.$LANG->getLL("lCreate").'" onClick="'.$onClick.'"> <input type="submit" value="'.$LANG->getLL("lCancel").'">');
			} else {
				$formA[]=array("&nbsp;", '<input type="submit" name="create_todo" value="'.$LANG->getLL("lUpdate").'"><input type="hidden" name="sys_todos_uid" value="'.$editRec["uid"].'">');
			}
	
			$theCode.= $SOBE->doc->spacer(20);
			$theCode.= $SOBE->doc->section('<a name="new"></a>'.$LANG->getLL(is_array($editRec)?"todos_update":"todos_new"),$SOBE->doc->table($formA).$hidden.$GLOBALS["SOBE"]->t3lib_TCEforms->JSbottom(),0,!is_array($editRec));
		} else {
			// Todo type:
			$opt_type=array();
			reset($todoTypes);
			$opt_type[]='<option value="0"></option>';
			while(list($uid,$title)=each($todoTypes))	{
				$opt_type[]='<option value="'.$uid.'">'.htmlspecialchars($title).'</option>';
			}
//				$type_onChange="if (document.forms[0]['data[sys_todos][".$type."][title]'].value=='') document.forms[0]['data[sys_todos][".$type."][title]'].value=document.forms[0]['data[sys_todos][".$type."][type]'].options[document.forms[0]['data[sys_todos][".$type."][type]'].selectedIndex].text;";
			$formA=array();
			$formA[]=array($LANG->getLL("todos_type").":&nbsp;", '<select name="workflow_type" onChange="document.location=\'index.php?workflow_type=\'+this.options[this.selectedIndex].value+\'#new\';">'.implode("",$opt_type).'</select>');
			$theCode.= $SOBE->doc->spacer(20);
			$theCode.= $SOBE->doc->section($LANG->getLL("todos_new"),$SOBE->doc->table($formA),0,1);
		}
		return $theCode;
	}
	function linkTodos($str,$id)	{
		$str='<a href="index.php?sys_todos_uid='.$id.'&AB='.$this->AB.'#todo">'.$str.'</a>';
		return $str;
	}


	
	
	
	
	
	
	
	
	

	// ************************
	// MESSAGES
	// ***********************
	function messages_insertRel($mes_id,$mRow,$brow,$sAE,&$emRec,$status=0)	{
		$fields_values=array();
		$fields_values["uid_local"]=$mes_id;
		$fields_values["uid_foreign"]=$brow["uid"];
		$fields_values["tstamp"]=time();
		$fields_values["status"]=$status;
		if ($status==126)	{	// If the relation is for the user himself (sent) set the is_read flag.
			$fields_values["is_read"]=1;
		}
		$query = t3lib_BEfunc::DBcompileInsert("sys_messages_users_mm",$fields_values);
		$res2=mysql(TYPO3_db,$query);

		if ($sAE && strstr($brow["email"],"@"))	{
			$this->sendEmail($brow["email"],$mRow["title"],$mRow["note"]);
			$emRec[] = $brow["username"]." (".$brow["email"].")";
		} else {
			$emRec[] = $brow["username"];
		}
	}
	function messages_selectFromStatus($ss,$fields="sys_messages.*,sys_messages_users_mm.*",$where="")	{
		$main_query=t3lib_BEfunc::mm_query($fields,"sys_messages","sys_messages_users_mm","be_users").
			" AND sys_messages_users_mm.uid_foreign=".intval($this->BE_USER->user["uid"]).
			" AND sys_messages_users_mm.status=".$ss.
			$where.
			" ORDER BY sys_messages.crdate DESC";
		return $main_query;
	}
	function renderMessagesList()	{
		global $SOBE, $LANG;

		$query = $this->messages_selectFromStatus(0,"sys_messages.*,sys_messages_users_mm.*"," AND sys_messages_users_mm.is_read=0");
		$res = mysql(TYPO3_db,$query);
		$lines=array();
		while($row=mysql_fetch_assoc($res))	{
			$lines[]='<nobr>'.$this->messages_link('<img src="'.$this->backPath.'gfx/mailicon.gif" width="18" hspace=6 height="10" align=top border=0><b>'.$this->fixed_lgd($row["title"]),$row["mm_uid"]).'</b></nobr><BR>';
		}

		$query = $this->messages_selectFromStatus(0,"count(*)");
		$res = mysql(TYPO3_db,$query);
		list($mc) = mysql_fetch_row($res);
		$lines[]='<nobr>'.$this->messages_link(sprintf($LANG->getLL("messages_index_msgs"),$mc),"0").'</nobr><BR>';

		$out = implode("",$lines);
		return $out;
	}
	function messages_link($str,$id,$box="inbox")	{
		$str='<a href="index.php?SET[function]=messages&SET[messages_box]='.$box.'&sys_messages_MM_uid='.$id.'#msg" target="list_frame" onClick="this.blur();">'.$str.'</a>';
		return $str;
	}
	function renderMessages()	{
		global $SOBE, $LANG;
		$theCode="";
			
			// Setting up general things for the function:
		$this->xCol = t3lib_div::modifyHTMLColor($GLOBALS["SOBE"]->doc->bgColor,-10,-10,-10);
		$SOBE->doc->tableLayout = Array (
			"defRow" => Array (
				"0" => Array('<TD valign=top nowrap>','</td>'),
				"defCol" => Array('<td valign="top" width=99%>','</td>')
			)
		);
		$SOBE->doc->table_TR = '<TR bgColor="'.$this->xCol.'">';
		$SOBE->doc->table_TABLE = '<TABLE border=0 cellspacing=1 cellpadding=2 width=100%>';
		
			// This is the id of the relation record which connects the mails with the user
		$mUid_MM = t3lib_div::intInRange(t3lib_div::GPvar("sys_messages_MM_uid"),0);

			// PROCESSING:
		$data = t3lib_div::GPvar("data",1);
			
			// Deleted and marked mails
		if (t3lib_div::GPvar("marked_mails") || t3lib_div::GPvar("marked_mails"))	{
			$marked_mails = @array_keys(t3lib_div::GPvar("MARKED"));
			if (is_array($marked_mails))	{
				$ss = t3lib_div::GPvar("marked_mails_action");
				if (t3lib_div::inList("0,1,127",$ss))	{
					$query = "UPDATE sys_messages_users_mm SET status=".$ss." WHERE mm_uid IN (".implode(",",$marked_mails).") AND uid_foreign=".$this->BE_USER->user["uid"];
					$res = mysql(TYPO3_db,$query);
				}
			}
			// Create mails (new and replys)
		} elseif (is_array($data["sys_messages"]))	{
			reset($data["sys_messages"]);
			$key = key($data["sys_messages"]);

			// If "key" is an integer it's a reply
			$uQ=t3lib_BEfunc::mm_query("sys_messages.*","sys_messages","sys_messages_users_mm","be_users",
				" AND sys_messages_users_mm.mm_uid=".intval($key).
				" AND be_users.uid=".intval($this->BE_USER->user["uid"])
				);
			$rres = mysql(TYPO3_db,$uQ);
			if ($r_row=mysql_fetch_assoc($rres))	{
			} else {
				$key=="NEW";
			}

			if ($data["sys_messages"][$key]["recipient"] && $data["sys_messages"][$key]["title"] && $data["sys_messages"][$key]["note"])	{
				$fields_values=array();
				$fields_values["title"]=$data["sys_messages"][$key]["title"];
				$fields_values["note"]=$data["sys_messages"][$key]["note"];
				$fields_values["parent"]=is_array($r_row)?($r_row["parent"]?$r_row["parent"]:$r_row["uid"]):0;
				$fields_values["orig_recipient"] = $data["sys_messages"][$key]["recipient"];
				$fields_values["crdate"]=time();
				$fields_values["cruser_id"]=$this->BE_USER->user["uid"];
				$query = t3lib_BEfunc::DBcompileInsert("sys_messages",$fields_values);
				$res=mysql(TYPO3_db,$query);
				$mes_id = mysql_insert_id();
				
					// Relation:
				$tempQ="";
				$emRec=array();
				if ($data["sys_messages"][$key]["recipient"]>0)		{	// Ordinary user
					$tempQ = "SELECT uid,username,realName,email FROM be_users WHERE uid=".intval($data["sys_messages"][$key]["recipient"]).t3lib_BEfunc::deleteClause("be_users");
				} 
				if ($data["sys_messages"][$key]["recipient"]<0)		{	// Users in group
					$tempQ = "SELECT uid,username,realName,email FROM be_users WHERE ".t3lib_BEfunc::listQuery("usergroup_cached_list",abs($data["sys_messages"][$key]["recipient"])).t3lib_BEfunc::deleteClause("be_users");
				}
				if ($tempQ)	{
					$sAE = t3lib_div::GPvar("sendAsEmail");
					$res = mysql(TYPO3_db,$tempQ);
					while($brow=mysql_fetch_assoc($res))	{
						if ($brow["uid"]!=$this->BE_USER->user["uid"] || $data["sys_messages"][$key]["recipient"]>0)	{	// Send mail to all in group except user himself (unless the mail is targeted directly to the user!)
							$this->messages_insertRel($mes_id,$fields_values,$brow,$sAE,$emRec);
						}
					}	
						// Sending to whole group (REPLYs only)
					if (is_array($r_row) && t3lib_div::GPvar("replyAll"))	{
						$uQ=t3lib_BEfunc::mm_query("be_users.username,be_users.realName,be_users.uid,be_users.email","sys_messages","sys_messages_users_mm","be_users",
						" AND sys_messages_users_mm.uid_local=".intval($r_row["uid"]).
						" AND sys_messages_users_mm.status!=126"
						);
						$rres = mysql(TYPO3_db,$uQ);
						while($brow=mysql_fetch_assoc($rres))	{
							if ($brow["uid"]!=$this->BE_USER->user["uid"])	{	// Send mail to all in group except user himself (unless the mail is targeted directly to the user!)
								$this->messages_insertRel($mes_id,$fields_values,$brow,$sAE,$emRec);
							}
						}
					}

						// Setting the sent mail at the sending user
					$temp=array();
					$this->messages_insertRel($mes_id,$fields_values,$this->BE_USER->user,0,$temp,126);
				}
				if (count($emRec))	{
					$emailList=implode("<BR>&nbsp;&nbsp;",$emRec);
					$theCode.= $SOBE->doc->section($LANG->getLL("messages_sent"),$LANG->getLL("messages_sent_msg")."<BR>&nbsp;&nbsp;".$emailList,0,1,1);
				}
			} else {
				$theCode.= $SOBE->doc->section($LANG->getLL("messages_sent"),$this->errorIcon().rfw($LANG->getLL("messages_sentError_msg")),0,1);
			}
			$mUid_MM=0;	// No display of messages if one is just created og replied to.
		}
		
			// Get groupnames for todo-tasks
		list($be_user_Array,$be_group_Array,$be_user_Array_o)=$this->getUserAndGroupArrays();

			// Creating main query for selecting mails:
		$main_query=t3lib_BEfunc::mm_query("sys_messages.*,sys_messages_users_mm.*","sys_messages","sys_messages_users_mm","be_users");
		
			// Display message:
		$msg_buffer="";
		$currentSender="";
		$doUpdate=0;
		if ($mUid_MM)	{
			$query = $main_query.
			" AND sys_messages_users_mm.uid_foreign=".intval($this->BE_USER->user["uid"]).
			" AND mm_uid=".intval($mUid_MM);
			$res = mysql(TYPO3_db,$query);
			$msg=array();
			while ($row = mysql_fetch_assoc($res))	{
					// Update 'is_read' flag:
				if (!$row["is_read"])	{
					$uQ = "UPDATE sys_messages_users_mm SET is_read=1 WHERE mm_uid=".$row["mm_uid"];
					$uRes = mysql(TYPO3_db,$uQ);
					$row["is_read"]=1;
					$doUpdate=1;
				}

				$currentSender = $row["cruser_id"];
				$currentSubject = $row["title"];
				$currentUid = $row["uid"];
				$currentSenderName = $be_user_Array_o[$row["cruser_id"]]["username"]." (".$be_user_Array_o[$row["cruser_id"]]["realName"].")";
				$replySep=" \n\n".$LANG->getLL("messages_replySeparator").chr(10);
				$currentContent = $replySep.$row["note"];
				$currentContent_formatted = $replySep."> ".implode(chr(10)."> ",explode(chr(10),$this->breakLines($row["note"])));
				
					// Getting recipient list (all relations which are not 126 (sent)):
				$recipArray = array();
				$uQ=t3lib_BEfunc::mm_query("be_users.username,be_users.realName,be_users.uid,sys_messages_users_mm.is_read","sys_messages","sys_messages_users_mm","be_users",
				" AND sys_messages_users_mm.uid_local=".intval($row["uid"]).
				" AND sys_messages_users_mm.status!=126");
				$rres = mysql(TYPO3_db,$uQ);
				while($r_row=mysql_fetch_assoc($rres))	{
					$recipArray[$r_row["uid"]]=$r_row["username"]." (".$r_row["realName"].") ";
					if (!$r_row["is_read"])	{$recipArray[$r_row["uid"]]=dfw($recipArray[$r_row["uid"]]);}
				}

				// Getting thread:
				$pUid = $row["parent"] ? $row["parent"] : $row["uid"];
				$uQ=t3lib_BEfunc::mm_query("sys_messages.*,sys_messages_users_mm.*","sys_messages","sys_messages_users_mm","be_users",
				" AND (sys_messages.uid=".intval($pUid)." OR sys_messages.parent=".intval($pUid).")".
				" AND sys_messages_users_mm.uid_foreign=".intval($this->BE_USER->user["uid"]).
//				" AND sys_messages_users_mm.status!=126".
				" ORDER BY sys_messages.crdate");
				$rres = mysql(TYPO3_db,$uQ);
				while($r_row=mysql_fetch_assoc($rres))	{
					if ($mUid_MM==$r_row["mm_uid"])	{
						$active='<img src="'.$this->backPath.'gfx/content_client.gif" width="7" height="10" border="0" align=top>';
					} else {
						$active='';
					}
					$thSender = $be_user_Array_o[$r_row["cruser_id"]]["username"]." (".$be_user_Array_o[$r_row["cruser_id"]]["realName"]."), ".$this->dateTimeAge($r_row["crdate"]);
					$thread_lines[]=$this->linkMessage('<img src="'.$this->backPath.'gfx/i/'.($r_row["orig_recipient"]<0?'tc_mails_group.gif':'tc_mails.gif').'" width="18" height="16" hspace=2 border=0 align=top>'.$active."&nbsp;".$thSender,$r_row["mm_uid"]);
					//debug($r_row);
				}
//				debug($recipArray);
				

				$header=fw('<img src="'.$this->backPath.'gfx/i/'.($row["orig_recipient"]<0?'tc_mails_group.gif':'tc_mails.gif').'" width="18" height="16" hspace=2 border=0 align=top> <strong>'.$row["title"].'</strong><BR>');
				$formA=array();
				$formA[]=array($LANG->getLL("messages_lSender").":&nbsp;", $currentSenderName);
//				if (count($recipArray)>1)		{
					$formA[]=array($LANG->getLL("messages_lRecipients").":&nbsp;", implode("<BR>",$recipArray));
//				}
				$formA[]=array($LANG->getLL("messages_lDateTime").":&nbsp;", $this->dateTimeAge($row["crdate"]));
				$formA[]=array($LANG->getLL("messages_message").":&nbsp;", nl2br($row["note"]));
				if (count($thread_lines)>1)	{
					$formA[]=array($LANG->getLL("messages_thread").":&nbsp;", implode("<BR>",$thread_lines));
				}

				$msg[] = $header.$SOBE->doc->table($formA);
			}
			$msg_buffer.= $SOBE->doc->spacer(20);
			$msg_buffer.= $SOBE->doc->section('<a name="msg"></a>'.$LANG->getLL("messages_content"),implode("",$msg),0,1);
		}


			// SELECT messages for list:
		switch($GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"])	{
			case "archive":
				$ss = 1;
			break;
			case "deleted":
				$ss = 127;
			break;
			case "sent":
				$ss = 126;
			break;
			default:
				$ss = 0;
			break;
		}
		
		
		$query = $this->messages_selectFromStatus($ss);
		$res = mysql(TYPO3_db,$query);
		$out="";
		$marked_code = $GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"]=="sent" ? "" : '<strong>'.fw($LANG->getLL("messages_lMark").":").'</strong>';
		if (mysql_num_rows($res))	{
			$lines=array();
			$bgColor=' bgcolor="'.$GLOBALS["SOBE"]->doc->bgColor5.'"';
			$lines[]='<tr>
				<td'.$bgColor.'>'.fw("&nbsp;").'</td>
				<td'.$bgColor.' width=33%><strong>'.fw($LANG->getLL("messages_lSubject").":").'</strong></td>
				<td'.$bgColor.' width=33%><strong>'.fw($LANG->getLL("messages_lSender").":").'</strong></td>
				<td'.$bgColor.' width=33%><strong>'.fw($LANG->getLL("messages_lDateTime").":").'</strong></td>
				<td'.$bgColor.'>'.$marked_code.'</td>
			</tr>';

			$c=0;
			while($row=mysql_fetch_assoc($res))	{
//			debug($row);
				$c++;
				$bgColor=' bgColor="'.(($c+1)%2 ? $GLOBALS["SOBE"]->doc->bgColor : $this->xCol).'"';
				if ($mUid_MM==$row["mm_uid"])	{
					$active='<img src="'.$this->backPath.'gfx/content_client.gif" width="7" height="10" border="0" align=top>';
				} else {
					$bTb=$bTe="";
					$active='';
				}
				if (!$row["is_read"])	{
					$bTb="<B>";
					$bTe="</B>";
				} else {
					$bTb=$bTe="";
				}
				$marked_code = $GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"]=="sent" ? "" : '<input type="checkbox" name="MARKED['.$row["mm_uid"].']" value="1">';
				$lines[]='<tr>
					<td'.$bgColor.'>'.$this->linkMessage('<img src="'.$this->backPath.'gfx/i/'.($row["orig_recipient"]<0?'tc_mails_group.gif':'tc_mails.gif').'" width="18" height="16" hspace=2 border=0>',$row["mm_uid"]).'</td>
					<td'.$bgColor.' nowrap>'.$this->linkMessage($active.fw($bTb."&nbsp;".$this->fixed_lgd($row["title"])."&nbsp;".$bTe),$row["mm_uid"]).'</td>
					<td'.$bgColor.' nowrap>'.$this->linkMessage(fw($bTb."&nbsp;".$this->fixed_lgd($be_user_Array_o[$row["cruser_id"]]["username"]." (".$be_user_Array_o[$row["cruser_id"]]["realName"].")")."&nbsp;".$bTb),$row["mm_uid"]).'</td>
					<td'.$bgColor.' nowrap>'.fw($this->dateTimeAge($row["crdate"])).'</td>
					<td'.$bgColor.' align=right>'.$marked_code.'</td>
				</tr>';
			}
			$out = '<table border=0 cellpadding=0 cellspacing=0>'.implode("",$lines).'</table>';
		}
		$labelKey = $LANG->getLL("messages_".$GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"]);
		$lMenu = t3lib_BEfunc::getFuncMenu("","SET[messages_box]",$GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"],$GLOBALS["SOBE"]->MOD_MENU["messages_box"]);
		if ($c && $GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"]!="sent")	{
			$bMenu = '<BR><div align=right><select name="marked_mails_action">
			<option value=-1></option>
			<option value=0>'.$LANG->getLL("messages_moveTo").' '.$LANG->getLL("messages_inbox").'</option>
			<option value=1>'.$LANG->getLL("messages_moveTo").' '.$LANG->getLL("messages_archive").'</option>
			<option value=127>'.$LANG->getLL("messages_moveDelete").'</option>
			</select><input type="submit" name="marked_mails" value="'.$LANG->getLL("messages_moveMarked").'"></div>';
			$bMenu = fw($bMenu);
		} else $bMenu = "";
		$theCode.= $SOBE->doc->section($labelKey,$lMenu.$out.$bMenu,0,1);
		$theCode.=$msg_buffer;

			
			// CREATE MAIL:
		// New mail/reply form:
		$opt=array();
		$opt[]='<option value="0"></option>';
		reset($be_user_Array);
		while(list($uid,$dat)=each($be_user_Array))	{
			$opt[]='<option value="'.$uid.'">'.htmlspecialchars($dat["username"].($dat["uid"]==$this->BE_USER->user["uid"]?' ['.$LANG->getLL("todos_self").']':' ('.$dat["realName"].')')).'</option>';
		}
		if (count($be_group_Array))	{
			$opt[]='<option value="0">'.$LANG->getLL("listSeparator_Groups").'</option>';
			reset($be_group_Array);
			while(list($uid,$dat)=each($be_group_Array))	{
				$tempQ = "SELECT count(*) FROM be_users WHERE ".t3lib_BEfunc::listQuery("usergroup_cached_list",$uid).t3lib_BEfunc::deleteClause("be_users");
				$res = mysql(TYPO3_db,$tempQ);
				list($grCount) = mysql_fetch_row($res);
				$opt[]='<option value="-'.$uid.'">'.htmlspecialchars($dat["title"]." (".$grCount." recipients)").'</option>';
			}
		}

		$type = ($currentSender && $GLOBALS["SOBE"]->MOD_SETTINGS["messages_box"]!="sent") ? $mUid_MM : "NEW";
		$replyContent="";
		$formA=array();
		if ($type=="NEW")	{
			$formA[]=array($LANG->getLL("messages_recipient").":&nbsp;", '<select name="data[sys_messages]['.$type.'][recipient]">'.implode("",$opt).'</select>');
			$formA[]=array($LANG->getLL("messages_subject").":&nbsp;", '<input type="text" name="data[sys_messages]['.$type.'][title]" max=255'.$SOBE->doc->formWidth(40).'>');
		} else {
			$formA[]=array($LANG->getLL("messages_recipient").":&nbsp;", '<input type="hidden" name="data[sys_messages]['.$type.'][recipient]" value="'.$currentSender.'">'.$currentSenderName);
			$currentSubject = $LANG->getLL("messages_RE").": ".ereg_replace("[[:alnum:]]:[ ]*","",$currentSubject);
			$formA[]=array($LANG->getLL("messages_subject").":&nbsp;", '<input type="hidden" name="data[sys_messages]['.$type.'][title]" value="'.htmlspecialchars($currentSubject).'">'.$this->fixed_lgd($currentSubject,50));
		}
		$insert = $type=="NEW" ? '' : '<BR><input type=hidden name="insertContentStore" value="'.htmlspecialchars($currentContent).'"><input type=hidden name="insertContentStore_formatted" value="'.htmlspecialchars($currentContent_formatted).'"><strong><a href="#" onClick="document.forms[0][\'data[sys_messages]['.$type.'][note]\'].value+=document.forms[0].insertContentStore.value; return false;">Insert original</a> - <a href="#"  onClick="document.forms[0][\'data[sys_messages]['.$type.'][note]\'].value+=document.forms[0].insertContentStore_formatted.value; return false;">Insert formatted</a></strong>';
		$formA[]=array($LANG->getLL("messages_message").":&nbsp;", '<textarea wrap="virtual" rows="10" name="data[sys_messages]['.$type.'][note]"'.$SOBE->doc->formWidthText(40).'>'.t3lib_div::formatForTextarea($replyContent).'</textarea>'.$insert);
		if ($this->BE_USER->user["email"])	{
			$formA[]=array("&nbsp;", '<input type="checkbox" name="sendAsEmail" value=1>'.$LANG->getLL("messages_email").'<BR>('.$LANG->getLL("messages_replyAddress").': '.$this->BE_USER->user["email"].')');
		}
		if ($type!="NEW" && count($recipArray)>1)	{
			$formA[]=array("&nbsp;", '<input type="checkbox" name="replyAll" value=1>'.sprintf($LANG->getLL("messages_replyAll"),count($recipArray)));
		}

		$formA[]=array("&nbsp;","&nbsp;");
		$onClick = "if (document.forms[0]['data[sys_messages][".$type."][title]'].value=='' || document.forms[0]['data[sys_messages][".$type."][note]'].value=='' || document.forms[0]['data[sys_messages][".$type."][recipient]'].options[document.forms[0]['data[sys_messages][".$type."][recipient]'].selectedIndex].value==0) {alert(unescape('".rawurlencode($LANG->getLL("messages_mustFillIn"))."'));return false;}";
		if ($type=="NEW")	{
			$formA[]=array("&nbsp;", '<input type="submit" name="submit" value="'.$LANG->getLL("lSendNew").'" onClick="'.$onClick.'">');
		} else {
			$formA[]=array("&nbsp;", '<input type="submit" name="submit" value="'.$LANG->getLL("lSendReply").'">');
		}
			
		$update = $doUpdate ? '<script>if (parent.list_frame) {parent.nav_frame.document.location = "overview.php";}</script>' : '';
		$theCode.= $SOBE->doc->spacer(20);
		$theCode.= $SOBE->doc->section($LANG->getLL($type=="NEW"?"messages_new":"messages_reply"),$SOBE->doc->table($formA).$update,0,1);
		return $theCode;
	}
	function linkMessage($str,$id)	{
		$str='<a href="index.php?sys_messages_MM_uid='.$id.'&AB='.$this->AB.'#msg">'.$str.'</a>';
		return $str;
	}


	
	
	
	
	// ************************
	// NOTES:
	// ***********************
	function renderNote()	{
		global $SOBE, $LANG;

		$out = '';

			// Saving / creating note:		
		$incoming = t3lib_div::GPvar("data",1);
		if (is_array($incoming["sys_notepad"]))	{
			$dataArr = array();
			$key = key($incoming["sys_notepad"]);
			if ($key=="NEW")	{
				$dataArr["note"] = $incoming["sys_notepad"]["NEW"]["note"];
				$dataArr["cruser_id"]=$this->BE_USER->user["uid"];
				$dataArr["crdate"]=time();
				$dataArr["tstamp"]=time();
				$this->setQuickNote(0,$dataArr,$this->BE_USER->user["uid"]);
			} else {
				$uid = intval($key);
				$dataArr["note"] = $incoming["sys_notepad"][$uid]["note"];
				$dataArr["tstamp"]=time();
				$this->setQuickNote($uid,$dataArr,$this->BE_USER->user["uid"]);
			}
			$out.=$this->loadLeftFrameJS();
		}
		
			// Displaying edit form for note:
		$note = $this->getQuickNote($this->BE_USER->user["uid"]);
		if (!is_array($note))	{
			$note["uid"]="NEW";
		}

		$out.= '<textarea rows=30'.$SOBE->doc->formWidthText().' name="data[sys_notepad]['.$note["uid"].'][note]">'.t3lib_div::formatForTextarea($note["note"]).'</textarea>';
		$out.= '<BR><input type="submit" value="'.$LANG->getLL("lUpdate").'">';

			// Help text:
		if ($this->BE_USER->uc["helpText"])	{
			$out.= '<BR><BR>'.$this->helpBubble().$LANG->getLL("note_helpText");
		}

		return $SOBE->doc->section("",$out,0,1);
	}







	// ************************
	// RECENT
	// ***********************
	function renderRecentList()	{
		global $SOBE, $LANG;

		$res = $this->getRecentResPointer($this->BE_USER->user["uid"]);
		$lines=array();
		while($row=mysql_fetch_assoc($res))	{
			$pageRow = t3lib_BEfunc::getRecord("pages",$row["event_pid"]);
			if (is_array($pageRow))	{
				$path = t3lib_BEfunc::getRecordPath ($pageRow["uid"],$this->perms_clause,$this->BE_USER->uc["titleLen"]);
				$lines[]='<nobr>'.t3lib_iconworks::getIconImage("pages",$pageRow,$this->backPath,'hspace=2 align=top title="'.htmlspecialchars($path).' - '.t3lib_BEfunc::titleAttribForPages($pageRow,"",0).'"').$this->recent_linkLayoutModule($this->fixed_lgd($pageRow["title"]),$pageRow["uid"]).'</nobr><BR>';
			}
		}
		$out = implode("",$lines);
		
		return $out;
	}
	function renderRecent()	{
		global $SOBE, $LANG, $TCA;
		$out = $SOBE->doc->section($LANG->getLL("recent_allRecs"),$this->_renderRecent(),0,1);
		return $out;
	}
	function _renderRecent()	{
		global $SOBE, $LANG, $TCA;


		$query = "SELECT sys_log.*, max(sys_log.tstamp) as tstamp_MAX
			FROM sys_log,pages 
			WHERE pages.uid=sys_log.event_pid AND sys_log.userid=".intval($this->BE_USER->user["uid"]).$this->logWhere." AND ".$this->perms_clause." 
			GROUP BY tablename,recuid
			ORDER BY tstamp_MAX DESC
			LIMIT ".$this->numberOfRecentAll;
		$res = mysql(TYPO3_db,$query);
		$lines=array();
		while($row=mysql_fetch_assoc($res))	{
//debug($row);
			$elRow = t3lib_BEfunc::getRecord($row["tablename"],$row["recuid"]);
			if (is_array($elRow))	{
				$path = t3lib_BEfunc::getRecordPath ($elRow["pid"],$this->perms_clause,$this->BE_USER->uc["titleLen"]);
				$lines[]='<tr>
					<td bgColor="'.$SOBE->doc->bgColor4.'">'.$this->recent_linkEdit('<img src="'.$this->backPath.'gfx/edit2.gif" width="11" height="12" border="0">',$row["tablename"],$row["recuid"]).'</td>
					<td bgColor="'.$SOBE->doc->bgColor4.'" nowrap>'.$this->recent_linkEdit(t3lib_iconworks::getIconImage($row["tablename"],$elRow,$this->backPath,'hspace=2 align=top title="'.htmlspecialchars($path).'"').$this->fixed_lgd($elRow[$TCA[$row["tablename"]]["ctrl"]["label"]]),$row["tablename"],$row["recuid"]).'&nbsp;</td>
					<td bgColor="'.$SOBE->doc->bgColor4.'">'.$this->dateTimeAge($row["tstamp_MAX"]).'</td>
				</tr>';
			}
		}
		$out = implode("",$lines);
		$out='<table border=0 cellpadding=1 cellspacing=1>'.$out.'</table>';

		return $out;
	}
	function recent_linkLayoutModule($str,$id)	{
		$str='<a href="'.$this->backPath.'db_layout.php?id='.$id.'&AB='.$this->AB.'" target="list_frame" onClick="this.blur();">'.$str.'</a>';
		return $str;
	}
	function recent_linkEdit($str,$table,$id)	{
		$params="&edit[".$table."][".$id."]=edit";
		$str='<A HREF="#" onClick="'.t3lib_BEfunc::editOnClick($params,$GLOBALS["BACK_PATH"]).'">'.$str.'</a>';
		return $str;
	}



	
	// ************************
	// MODULES:
	// ***********************
	function renderModulesList()	{
		global $SOBE, $LANG;
	
		$mList = $this->getModuleList();
		$modList = t3lib_BEfunc::getListOfBackendModules(implode("','",explode(",",$mList)),$this->perms_clause,$this->backPath);

		$lines=array();
		if (is_array($modList["rows"]))	{
			reset($modList["rows"]);
			while(list(,$pageRow)=each($modList["rows"]))	{
				$path = t3lib_BEfunc::getRecordPath ($pageRow["uid"],$this->perms_clause,$this->BE_USER->uc["titleLen"]);
				$lines[]='<nobr>'.t3lib_iconworks::getIconImage("pages",$pageRow,$this->backPath,'hspace=2 align=top title="'.htmlspecialchars($path)." - ".t3lib_BEfunc::titleAttribForPages($pageRow,"",0).'"').$this->recent_linkModulesModule($this->fixed_lgd($pageRow["title"]),$pageRow["uid"]).'</nobr><BR>';
			}
		}
		$out = implode("",$lines);

		return $out;
	}
	function recent_linkModulesModule($str,$id)	{
		$str='<a href="'.$this->backPath.'mod/web/modules/index.php?id='.$id.'&AB='.$this->AB.'" target="list_frame" onClick="this.blur();">'.$str.'</a>';
		return $str;
	}
	function getModuleList()	{
		global $TCA;
		$lP=array();
		if (is_array($TCA["pages"]["columns"]["module"]["config"]["items"]))	{
			reset($TCA["pages"]["columns"]["module"]["config"]["items"]);
			while(list(,$p)=each($TCA["pages"]["columns"]["module"]["config"]["items"]))	{
				if (trim($p[1]))	{
					$lP[]=trim($p[1]);
				}
			}
		}
		return implode(",",$lP);
	}
	







	// ************************
	// ACTIONS
	// ***********************
	function renderActions()	{
		global $SOBE, $LANG;
		$uid = t3lib_div::intInRange(t3lib_div::GPvar("sys_action_uid"),0);
		$out="";
		$header="";
		if ($uid)	{
			$res = $this->getActionResPointer($uid);
			if($actionRow=mysql_fetch_assoc($res))	{
			
					// Action header:
				$header = t3lib_iconworks::getIconImage("sys_action",$actionRow,$this->backPath,'hspace=2 align=absmiddle').'<b>'.$actionRow["title"].'</b>';
				$out.='<table border=0 cellpadding=0 cellspacing=1 width=100%>
					<tr><td colspan=2 bgColor="'.$SOBE->doc->bgColor5.'">'.fw($header).'</td></tr>
					<tr>
						<td width=1% valign=top bgColor="'.$SOBE->doc->bgColor4.'">'.fw($LANG->sL(t3lib_BEfunc::getItemLabel("sys_action","type"))."&nbsp;").'</td>
						<td valign=top bgColor="'.$SOBE->doc->bgColor4.'">'.fw(t3lib_BEfunc::getProcessedValue("sys_action","type",$actionRow["type"])).'</td>
					</tr>
					<tr>
						<td width=1% valign=top bgColor="'.$SOBE->doc->bgColor4.'">'.fw($LANG->sL(t3lib_BEfunc::getItemLabel("sys_action","description"))."&nbsp;").'</td>
						<td valign=top bgColor="'.$SOBE->doc->bgColor4.'">'.fw(nl2br($actionRow["description"])).'</td>
					</tr>';
				$out.='</table>';
				$theCode = $SOBE->doc->section("",$out,0,1);



					// Types of actions:
				switch($actionRow["type"])	{
					case 1:
						$actionContent="";
						$beRec = t3lib_BEfunc::getRecord("be_users",intval($actionRow["t1_copy_of_user"]));
						if (is_array($beRec))	{
							// Create or update:
							$inData = t3lib_div::GPvar("data",1);
//	debug($inData);
							$userRecord="";
							$newFlag=0;
							if (is_array($inData["be_users"]))	{
								$nId = $this->action_t1_createUpdateBeUser($inData["be_users"],$actionRow);
								$userRecord=t3lib_BEfunc::getRecord("be_users",$nId);
							} 
							if (t3lib_div::GPvar("be_users_uid"))	{
								$userRecord=t3lib_BEfunc::getRecord("be_users",t3lib_div::GPvar("be_users_uid"));
							}
							if (!is_array($userRecord))	{
								$userRecord=array();
								if (is_array($inData["be_users"]["NEW"]))	{	$userRecord=$inData["be_users"]["NEW"];		}
								$userRecord["uid"]="NEW";
								$newFlag=1;
							}



								// List of users...
							$query="SELECT * FROM be_users WHERE pid=0 AND cruser_id=".intval($this->BE_USER->user["uid"])." AND createdByAction=".$actionRow["uid"].t3lib_BEfunc::deleteClause("be_users")." ORDER BY username";
							$res = mysql(TYPO3_db,$query);
							$lines=array();
							while($uRow=mysql_fetch_assoc($res))	{
								$lines[]="<nobr>".($uRow["uid"]==$userRecord["uid"]?"<b>":"").$this->action_linkUserName(t3lib_iconworks::getIconImage("be_users",$uRow,$this->backPath,'title="uid='.$uRow["uid"].'" hspace=2 align=top').$uRow["username"]." (".$uRow["realName"].")".($uRow["uid"]==$userRecord["uid"]?"</b>":"")."</nobr>",$actionRow["uid"],$uRow["uid"])."<br>";
							}
							if (count($lines))	{
								$theCode.= $SOBE->doc->section($LANG->getLL("action_t1_listOfUsers"),implode("",$lines),0,1);
							}

							$formA=Array();
							$opt=array();
							
							$grList = t3lib_div::trimExplode(",",$actionRow["t1_allowed_groups"],1);
							reset($grList);
							$opt[]='<option value=""></option>';
							while(list(,$gu)=each($grList))	{
								$checkGr = t3lib_BEfunc::getRecord("be_groups",$gu);
								if (is_array($checkGr))	$opt[]='<option value="'.$checkGr["uid"].'"'.(t3lib_div::inList($userRecord["usergroup"],$checkGr["uid"])?" selected":"").'>'.htmlspecialchars($checkGr["title"]).'</option>';
							}
							
							$formA[]=array($LANG->getLL("action_BEu_hidden").":&nbsp;", '<input type="checkbox" name="data[be_users]['.$userRecord["uid"].'][disable]" value=1'.($userRecord["disable"]?" checked":"").'>');
							$formA[]=array($LANG->getLL("action_BEu_username").":&nbsp;", '<input type="text" name="data[be_users]['.$userRecord["uid"].'][username]" max=15 value="'.htmlspecialchars($userRecord["username"]).'"'.$SOBE->doc->formWidth(15).'>');
							$formA[]=array($LANG->getLL("action_BEu_password").":&nbsp;", '<input type="password" name="data[be_users]['.$userRecord["uid"].'][password]" max=40'.$SOBE->doc->formWidth(15).'>');
							$formA[]=array($LANG->getLL("action_BEu_realName").":&nbsp;", '<input type="text" name="data[be_users]['.$userRecord["uid"].'][realName]" value="'.htmlspecialchars($userRecord["realName"]).'"'.$SOBE->doc->formWidth(30).'>');
							$formA[]=array($LANG->getLL("action_BEu_email").":&nbsp;", '<input type="text" name="data[be_users]['.$userRecord["uid"].'][email]" value="'.htmlspecialchars($userRecord["email"]).'"'.$SOBE->doc->formWidth(30).'>');
							if (count($grList)) {
								$formA[]=array($LANG->getLL("action_BEu_usergroups").":&nbsp;", '<select size='.t3lib_div::intInRange(count($opt),2).' multiple name="data[be_users]['.$userRecord["uid"].'][usergroups][]">'.implode("",$opt).'</select>');
							}
								// DB mounts:
							$loadDB = t3lib_div::makeInstance("t3lib_loadDBGroup");
							$loadDB->start($userRecord["db_mountpoints"],"pages");
							$params=array(
								"size" => 3
							);
							$formA[]=array($LANG->getLL("action_BEu_db_mount").":&nbsp;", $GLOBALS["SOBE"]->t3lib_TCEforms->dbFileIcons('data[be_users]['.$userRecord["uid"].'][db_mountpoints]','db','pages',$loadDB->itemArray,"",$params));

							$formA[]=array("&nbsp;","&nbsp;");
							$formA[]=array("&nbsp;", '<input type=hidden value="'.$uid.'" name="sys_action_uid"><input type=hidden value="'.t3lib_div::GPvar("be_users_uid").'" name="be_users_uid"><input type=hidden value="'.$uid.'" name="sys_action_uid"><input type="submit" name="submit" value="'.$LANG->getLL($newFlag?"lCreate":"lUpdate").'">'.(!$newFlag?' <input type="submit" name="_delete_" value="'.$LANG->getLL("lDelete").'" onClick="return confirm(unescape(\''.rawurlencode($LANG->getLL("lDelete_warning")).'\'));">':''));

							if (!$newFlag)	{
								$p = 'uid='.$userRecord["uid"].", ".$LANG->getLL("lHomedir").": ";
								$hPath=$this->action_getUserMainDir();
								if ($hPath && @is_dir($hPath.$userRecord["uid"]."/"))	{
									$p.= $hPath;
								} else {
									$p.= $LANG->getLL("lNone");
								}
								$actionContent.=t3lib_iconworks::getIconImage("be_users",$userRecord,$this->backPath,'title="'.htmlspecialchars($p).'" hspace=2 align=top').$userRecord["username"]." (".$userRecord["realName"].")";
							}
							$actionContent.=$SOBE->doc->table($formA);
							$theCode.= $SOBE->doc->section($LANG->getLL($newFlag?"action_Create":"action_Update"),$actionContent,0,1);
						} else {
							$theCode.= $SOBE->doc->section($LANG->getLL("action_error"),rfw($LANG->getLL("action_notReady")),0,1);
						}
					break;
					case 2:	
						$sql_query = unserialize($actionRow["t2_data"]);
						if (is_array($sql_query) && strtoupper(substr(trim($sql_query["qSelect"]),0,6))=="SELECT")	{
							$fullsearch = t3lib_div::makeInstance("t3lib_fullsearch");
							$fullsearch->formW = 40;
							$fullsearch->noDownloadB=1;
							$actionContent="";
//		debug($sql_query);
							$type = $sql_query["qC"]["search_query_makeQuery"];
							$res = mysql(TYPO3_db,$sql_query["qSelect"]);
							if (!mysql_error())	{
								$fullsearch->formW=48;
								$cP=$fullsearch->getQueryResultCode($type,$res,$sql_query["qC"]["queryTable"]);
								$actionContent=$cP["content"];
								if ($type=="csv" || $type=="xml")	{
									$actionContent.='<BR><BR><a href="'.getenv("REQUEST_URI").'&download_file=1"><strong>'.$LANG->getLL("action_download_file").'</strong></a>';
								}
							} else {
								$actionContent.=mysql_error();
							}
							if ($this->BE_USER->isAdmin())	{
								$actionContent.="<HR>".$fullsearch->tableWrap($sql_query["qSelect"]);
								$actionContent.='<BR><strong><a href="../../tools/dbint/index.php?id='.
									'&SET[function]=search'.
									'&SET[search]=query'.
									'&storeControl[STORE]=-'.$actionRow["uid"].
									'&storeControl[LOAD]=1'.
									'">Edit Query</a></strong>';
							}
							$theCode.= $SOBE->doc->section($LANG->getLL("action_t2_result"),$actionContent,0,1);
						} else {
							$theCode.= $SOBE->doc->section($LANG->getLL("action_error"),rfw($LANG->getLL("action_notReady")),0,1);
						}
					break;
					case 3:
						Header("Location: ".$this->backPath."db_list.php?id=".intval($actionRow["t3_listPid"])."&AB=1&table=".$actionRow["t3_tables"]);
						exit;
					break;
					case 4:
						$dbAnalysis = t3lib_div::makeInstance("t3lib_loadDBGroup");
						$dbAnalysis->fromTC=0;
						$dbAnalysis->start($actionRow["t4_recordsToEdit"],"*");
						$dbAnalysis->getFromDB();
						
						$lines=array();
						reset($dbAnalysis->itemArray);
						while(list(,$el)=each($dbAnalysis->itemArray))	{
							$path = t3lib_BEfunc::getRecordPath ($el["id"],$this->perms_clause,$this->BE_USER->uc["titleLen"]);
							$lines[]='<tr>
								<td nowrap bgcolor="'.$SOBE->doc->bgColor4.'">'.
									'<a href="'.$this->backPath.'alt_doc.php?returnUrl='.rawurlencode(getenv("REQUEST_URI")).'&edit['.$el["table"].']['.$el["id"].']=edit">'.
									t3lib_iconworks::getIconImage($el["table"],$dbAnalysis->results[$el["table"]][$el["id"]],$this->backPath,'hspace=2 align=top'.t3lib_BEfunc::titleAttrib($path,1)).
									t3lib_BEfunc::getRecordTitle($el["table"],$dbAnalysis->results[$el["table"]][$el["id"]],1).'</a></td>
								</tr>';
						}
						$actionContent = '<table border=0 cellpadding=0 cellspacing=2>'.implode("",$lines).'</table>';
						$theCode.= $SOBE->doc->section($LANG->getLL("action_t4_edit"),$actionContent,0,1);
					break;
					default:
						$theCode.= $SOBE->doc->section($LANG->getLL("action_error"),rfw($LANG->getLL("action_noType")),0,1);
					break;
				}

			}
		}
		return $theCode;
	}
	function renderActionList()	{
		global $SOBE, $LANG;
	
		$res = $this->getActionResPointer();
		$lines=array();
		while($actionRow=mysql_fetch_assoc($res))	{
			$lines[]='<nobr>'.t3lib_iconworks::getIconImage("sys_action",$actionRow,$this->backPath,'hspace=2 align=top').$this->action_link($this->fixed_lgd($actionRow["title"]),$actionRow["uid"],$actionRow["description"]).'</nobr><BR>';
		}
		$out = implode("",$lines);
		return $out;
	}
	function action_link($str,$id,$title="")	{
		$str='<a href="index.php?SET[function]=actions&sys_action_uid='.$id.'&AB='.$this->AB.'" target="list_frame" onClick="this.blur();"'.t3lib_BEfunc::titleAttrib($title,1).'>'.$str.'</a>';
		return $str;
	}
	function action_linkUserName($str,$id,$bid)	{
		$str='<a href="index.php?sys_action_uid='.$id.'&AB='.$this->AB.'&be_users_uid='.$bid.'" onClick="this.blur();">'.$str.'</a>';
		return $str;
	}
	function action_t1_createUpdateBeUser($arr,$actionRow=array())	{
		reset($arr);
		$key = key($arr);
		$data="";
		$nId=0;
		$BEuid = $actionRow["t1_copy_of_user"];
		if ($key=="NEW")	{
			$beRec = t3lib_BEfunc::getRecord("be_users",intval($BEuid));
			if (is_array($beRec) && trim($arr[$key]["password"]) && $this->fixUsername($arr[$key]["username"],$actionRow["t1_userprefix"]))	{
//				debug($arr[$key]);
				$data=array();
				$data["be_users"][$key]=$beRec;
				$data["be_users"][$key]["username"]=$this->fixUsername($arr[$key]["username"],$actionRow["t1_userprefix"]);
				$data["be_users"][$key]["password"]=md5(trim($arr[$key]["password"]));
				$data["be_users"][$key]["realName"]=$arr[$key]["realName"];
				$data["be_users"][$key]["email"]=$arr[$key]["email"];
				$data["be_users"][$key]["disable"]=intval($arr[$key]["disable"]);
				$data["be_users"][$key]["admin"]=0;
				$data["be_users"][$key]["usergroup"] = $this->fixUserGroup($data["be_users"][$key]["usergroup"],$actionRow["t1_allowed_groups"],$arr[$key]["usergroups"]);
				$data["be_users"][$key]["db_mountpoints"]=$arr[$key]["db_mountpoints"];
				$data["be_users"][$key]["createdByAction"]=$actionRow["uid"];
			}
		} else {
			$beRec = t3lib_BEfunc::getRecord("be_users",intval($key));
			if (is_array($beRec) && $beRec["cruser_id"]==$this->BE_USER->user["uid"])	{
				if (t3lib_div::GPvar("_delete_"))	{
						// delete... ?
					$cmd=array();
					$cmd["be_users"][$key]["delete"]=1;

					$tce = t3lib_div::makeInstance("t3lib_TCEmain");
					$tce->start(Array(),$cmd,$this->BE_USER);
					$tce->admin=1;
					$tce->process_cmdmap();
//					debug($cmd);
					$nId = 0;
				} elseif ($this->fixUsername($arr[$key]["username"],$actionRow["t1_userprefix"]))	{
					// check ownership...
					$data=array();
					$data["be_users"][$key]["username"]=$this->fixUsername($arr[$key]["username"],$actionRow["t1_userprefix"]);
					if (trim($arr[$key]["password"]))	{$data["be_users"][$key]["password"]=md5(trim($arr[$key]["password"]));}
	
					$data["be_users"][$key]["realName"]=$arr[$key]["realName"];
					$data["be_users"][$key]["email"]=$arr[$key]["email"];
					$data["be_users"][$key]["disable"]=intval($arr[$key]["disable"]);
					$data["be_users"][$key]["admin"]=0;
					$data["be_users"][$key]["usergroup"] = $this->fixUserGroup($beRec["usergroup"],$actionRow["t1_allowed_groups"],$arr[$key]["usergroups"]);
					$data["be_users"][$key]["db_mountpoints"]=$arr[$key]["db_mountpoints"];
					$nId=$key;
				}
			}
		}

		if (is_array($data))	{
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
			$tce->start($data,Array(),$this->BE_USER);
			$tce->admin=1;
			$tce->process_datamap();
			$nId = intval($tce->substNEWwithIDs["NEW"]);
			if ($nId)	{	// Create
				$this->action_createDir($nId);
			} else {	// update
				$nId=intval($key);
			}
			unset($tce);
		}
		return $nId;
	}
	function fixUsername($username,$prefix)	{
		$username=trim($username);
		$prefix=trim($prefix);
		$username=ereg_replace("^".quotemeta($prefix),"",$username);
		
		if ($username)	{
			return $prefix.$username;
		} else return false;
	}
	function fixUserGroup($curUserGroup,$allowedGroups,$inGroups)	{
			// User group:
			// All current groups:
		$cGroups = array_flip(t3lib_div::trimExplode(",",$curUserGroup,1));	
		$grList = t3lib_div::intExplode(",",$allowedGroups);
		reset($grList);
		while(list(,$gu)=each($grList))	{
			unset($cGroups[$gu]);	// Remove the group if it's in the array for some reason...
		}
			// reverse array again and set incoming groups:
		$cGroups=array_keys($cGroups);
		if (is_array($inGroups))	{
			reset($inGroups);
			while(list(,$gu)=each($inGroups))	{
				$checkGr = t3lib_BEfunc::getRecord("be_groups",$gu);
				if (is_array($checkGr) && in_array($gu,$grList))	{
					$cGroups[]=$gu;
				}
			}
		}
		return implode(",",$cGroups);
	}
	function action_createDir($uid)	{
		$path = $this->action_getUserMainDir();
		if ($path)	{
			@mkdir($path.$uid,"0755");
			@mkdir($path.$uid."/_temp_","0755");
//			debug($path);
		}
	}
	function action_getUserMainDir()	{
		$path = $GLOBALS["TYPO3_CONF_VARS"]["BE"]["userHomePath"];
		if ($path && @is_dir($path) &&
				$GLOBALS["TYPO3_CONF_VARS"]["BE"]["lockRootPath"] && 
				t3lib_div::isFirstPartOfStr($path,$GLOBALS["TYPO3_CONF_VARS"]["BE"]["lockRootPath"]) &&
				substr($path,-1)=="/"
			)	{
			return $path;
		}
	}
}
?>