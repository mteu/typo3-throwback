<?php
define("TYPO3_MOD_PATH", "mod/user/task/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Task Center with overviews, messages, ToDo lists";
$MLANG["default"]["tabs"]["tab"] = "Task center";
$MLANG["default"]["tabs_images"]["tab"] = "task.gif";
$MLANG["default"]["labels"]["tabdescr"] = "The task center provides access to your internal To-Do list, messages, Quick-note, actions etc. It also provides shortcuts to your available frontend modules and most recently edited pages. The Task Center is where you keep track of your daily tasks and workflows.";

$MLANG["dk"]["labels"]["tablabel"] = "Arbejdsstyring med overblik, beskeder, opgavelister";
$MLANG["dk"]["tabs"]["tab"] = "Opgaver";
$MLANG["dk"]["labels"]["tabdescr"] = "Opgaver-modulet giver dig adgang til din interne opgaveliste, beskeder, Kvik-note, handlinger osv. Det giver dig ogs� genveje til dine tilg�ngelige website moduler og senest �ndrede sider. Opgaver-modulet er d�r, hvor du holder styr p� dine daglige opgaver og arbejdsgange.";

$MLANG["de"]["labels"]["tablabel"] = "Aufgaben mit �bersichten, Nachrichten, To-Do-Listen";
$MLANG["de"]["labels"]["tabdescr"] = "Das Aufgaben-Center bietet Ihnen Zugriff auf Ihre interne To-Do-Liste, Nachrichten, Notizen, Befehle, usw. Es bietet Ihnen ebenso Verweise auf die verf�gbaren Frontend-Module und die am h�ufigsten bearbeiteten Seiten. Im Aufgaben Center k�nnen Sie Ihre t�glichen Aufgaben und Workflows verfolgen k�nnen.";
$MLANG["de"]["tabs"]["tab"] = "Aufgaben";

$MLANG["no"]["labels"]["tablabel"] = "Arbeidsstyring med oversikt, beskjeder, oppgavelister";
$MLANG["no"]["labels"]["tabdescr"] = "Oppgaver-modulen gir deg tilgang til din interne oppgaveliste, beskjeder, Hurtig-notater, handlinger osv. Den gir deg ogs� snarveier til dine tilgjengelige webomr�de moduler og sist endrede sider. Det er i Oppgaver-modulen at du holder styr p� dine daglige oppgaver og arbeidsgangen.";
$MLANG["no"]["tabs"]["tab"] = "Oppgaver";

$MLANG["it"]["tabs"]["tab"] = "Task center";
$MLANG["it"]["labels"]["tablabel"] = "Task Center con visione d'insieme, messaggi, lista dei da-fare";
$MLANG["it"]["labels"]["tabdescr"] = "Task Center d� l'accesso alla lista dei da-fare, ai messaggi, alle note, alle 'azioni', etc. Vi d� inoltre accesso ai moduli frontend e alle pagine modificate recentemente. Task Center � il modulo in cui tenete traccia delle attivit� quotidiane e dei workflows.";

$MLANG["fr"]["labels"]["tablabel"] = "Centre de T�ches avec r�sum�, messages et listes 'A faire'";
$MLANG["fr"]["labels"]["tabdescr"] = "Le Centre de T�ches vous donne acc�s au notes internes, aux t�ches 'A faire', aux actions, ... Il vous donne aussi acc�s � vos modules 'Frontend' et les pages �dit�es r�cemment. Le Centre de T�ches est l'endroit ou vous voyez votre travail quotidien et le workflow";
$MLANG["fr"]["tabs"]["tab"] = "Centre de T�ches";

$MLANG["pl"]["labels"]["tablabel"] = "Centrum zada� z wiadomo�ciami";
$MLANG["pl"]["labels"]["tabdescr"] = "Centrum zada� umo�liwia dost�p do twoich zada�, wiadomo�ci, notesu, akcji, itp. Zawiera r�wnie� skr�ty do dost�pnych dla ciebie modu��w i ostatnio edytowanych przez ciebie stron. Tutaj przechowywane s� informacje o twojej aktywno�ci na serwerze Typo3.";
$MLANG["pl"]["tabs"]["tab"] = "Centrum zada�";

$MLANG["es"]["labels"]["tablabel"] = "Centro de Tareas con res�menes, mensajes, pendientes.";
$MLANG["es"]["labels"]["tabdescr"] = "El centro de tareas le da acceso a su lista de pendientes interna, mensajes, notas, aciones, etc. Tambi�n tiene accesos directos a los m�dules sus m�dulos disponibles de frontend y las p�ginas que edit� mas recientemente. El Centro de Tareas es donde ud. mantiene nota de sus tareas diarias y flujo de trabajo.";
$MLANG["es"]["tabs"]["tab"] = "Centro de Tareas";

$MLANG["si"]["labels"]["tablabel"] = "Va�a bele�ka v Typo3";
$MLANG["si"]["tabs"]["tab"] = "Naloge";
$MLANG["si"]["labels"]["tabdescr"] = "Modul 'naloge' vam omogo�a uporabo bele�ke va�ih opravkov v Typo3, pa tudi po�iljanje sporo�il, urejanje zaznamkov, itd. Ponuja tudi dostop do va�ih 'frontend' modulov in bli�njice do nedavno urejanih strani.";

$MLANG["nl"]["labels"]["tablabel"] = "Taak Centrum met overzichten, berichten, TeDoen lijsten";
$MLANG["nl"]["labels"]["tabdescr"] = "Het Taak Centrum geeft toegang tot je interne TeDoen lijst, berichten, NotitieBlok, Akties enz. Het bevat ook snelkoppelingen naar de voor jou beschikbare modules en onlangs aangepaste pagina's. In het Taak Centrum volg je je dagelijkse taken en werkschema's.";
$MLANG["nl"]["tabs"]["tab"] = "Taakcentrum";

$MLANG["cz"]["labels"]["tablabel"] = "Task Center s p�ehledy, vzkazy a seznamem �kol�";
$MLANG["cz"]["labels"]["tabdescr"] = "Task Center poskytuje p�istup k va�emu vnit�n�mu seznamu �kol�, vzkaz�m, rychl� pozn�mce, akc�m atd. Tak� poskytuje zkratky k va�im dostupn�m frontendov�m modul�m a naposled editovan�m str�nk�m. V Task Center m��ete udr�ovat p�ehled o va�ich denn�ch �kolech a workflow.";
$MLANG["cz"]["tabs"]["tab"] = "Task Center";

$MLANG["fi"]["labels"]["tablabel"] = "Task Center ";
$MLANG["fi"]["labels"]["tabdescr"] = "Task Center mahdollistaa p��syn sis�isiin To-Do listaan, viesteihin, pikamuistio, toimintoihin jne. Sill� on mahdollisuus tehd� oikoteit� saatavilla oleviin frontend-moduleihin ja viimeksi muotoilluille sivuille. Task Center on paikka jossa seuraat p�ivitt�isi� toimintojasi ja ty�kulkua.";
$MLANG["fi"]["tabs"]["tab"] = "Task Center";

$MLANG["tr"]["labels"]["tablabel"] = "G�rev merkezi ile genel g�r�nt�, mesajlar, Yap�lacaklar listesi";
$MLANG["tr"]["tabs"]["tab"] = "G�rev merkezi";
$MLANG["tr"]["labels"]["tabdescr"] = "G�rev merkezi sizin i� k�sma ait yap�lacak listenize, mesajlara, h�zl� notunuza, aksiyonlar�n�za vs eri�im imkan� sa�lar. Birde sizin mevcut �nplan mod�lleri ve en son d�zenlenen sayfalar�n�za k�sayol imkan� sa�lar. G�rev Merkezi sizin g�nl�k g�revlerinizi ve i� ak��lar�n�z� takip etmenizi sa�layan yerdir.";


$MCONF["script"]="frameset.php";
$MCONF["access"]="group,user";
$MCONF["name"]="user_task";
?>