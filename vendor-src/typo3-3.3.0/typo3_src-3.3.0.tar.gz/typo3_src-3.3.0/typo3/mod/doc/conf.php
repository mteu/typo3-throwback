<?php
$MLANG["default"]["labels"]["tablabel"] = "Editing of records and documents";
$MLANG["default"]["tabs"]["tab"] = "Doc";
$MLANG["default"]["tabs_images"]["tab"] = "document.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Redigering af records og dokumenter";
$MLANG["dk"]["tabs"]["tab"] = "Dok.";

$MLANG["de"]["labels"]["tablabel"] = "Bearbeiten von Datens�tzen und Dokumenten";
$MLANG["de"]["tabs"]["tab"] = "Dok.";

$MLANG["no"]["labels"]["tablabel"] = "Redigering av records og dokumenter";
$MLANG["no"]["tabs"]["tab"] = "Dok.";

$MLANG["it"]["labels"]["tablabel"] = "Edita i documenti e i records";
$MLANG["it"]["tabs"]["tab"] = "Doc";

$MLANG["fr"]["labels"]["tablabel"] = "Edition enregistrements et documents";
$MLANG["fr"]["tabs"]["tab"] = "Doc";

$MLANG["es"]["labels"]["tablabel"] = "Edici�n de registros y documentos";
$MLANG["es"]["tabs"]["tab"] = "Doc";

$MLANG["nl"]["labels"]["tablabel"] = "Bewerken van records en documenten";
$MLANG["nl"]["tabs"]["tab"] = "Doc";

$MLANG["cz"]["labels"]["tablabel"] = "Editace z�znam� a dokument�";
$MLANG["cz"]["tabs"]["tab"] = "Doc";

$MLANG["pl"]["labels"]["tablabel"] = "Edycja rekord�w i dokument�w";
$MLANG["pl"]["tabs"]["tab"] = "Dokumenty";

$MLANG["si"]["labels"]["tablabel"] = "Urejanje zapisov in dokumantov";
$MLANG["si"]["tabs"]["tab"] = "Doc";

$MLANG["fi"]["labels"]["tablabel"] = "Tietueiden ja dokumettien muotoilu";
$MLANG["fi"]["tabs"]["tab"] = "Doc";

$MLANG["tr"]["labels"]["tablabel"] = "Kay�tlar�n ve d�k�manlar�n d�zenlenmesi";
$MLANG["tr"]["tabs"]["tab"] = "D�k�man";


$MCONF["script"]="../../alt_doc.php";
$MCONF["access"]="group,user";
?>