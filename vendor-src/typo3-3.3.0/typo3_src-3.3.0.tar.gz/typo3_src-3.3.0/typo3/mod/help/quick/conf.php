<?php
define("TYPO3_MOD_PATH", "mod/help/quick/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Typo3 user manual";
$MLANG["default"]["tabs"]["tab"] = "User manual";
$MLANG["default"]["tabs_images"]["tab"] = "help.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Online access to the Typo3 User Manual. This covers general issues and may not provide you with specific information about your actual Typo3 system";

$MLANG["dk"]["labels"]["tablabel"] = "Typo3 bruger manual";
$MLANG["dk"]["tabs"]["tab"] = "Bruger manual";
$MLANG["dk"]["labels"]["tabdescr"] = "Online adgang til Typo3 brugermanualen. Denne omfatter vejledning indenfor generelle emner og kan muligvis ikke give dig specifik information om dit aktuelle Typo3 system.";

$MLANG["de"]["labels"]["tablabel"] = "Typo3 Benutzeranleitung";
$MLANG["de"]["labels"]["tabdescr"] = "Onlinezugriff auf die Typo3 Benutzeranleitung. Diese umfasst allgemeine Themen und bietet keine spezifischen Informationen zu Ihrer aktuellen Typo3-System.";
$MLANG["de"]["tabs"]["tab"] = "Benutzeranleitung";

$MLANG["no"]["labels"]["tablabel"] = "Typo3 brukermanual";
$MLANG["no"]["labels"]["tabdescr"] = "Online tilgang til brukermanualen. Denne gir veiledning innenfor generelle emner og kan muligens ikke gi deg spesifikk informasjon om ditt aktuelle Typo3 system.";
$MLANG["no"]["tabs"]["tab"] = "Brukermanual";

$MLANG["it"]["labels"]["tablabel"] = "Manuale utente Typo3";
$MLANG["it"]["labels"]["tabdescr"] = "Accesso al manuale utente di Typo3 (online). Vengono trattati aspetti di carattere generale, quindi possono mancare le informazioni specifiche che riguardano l'implementazione di Typo3 in certi siti.";
$MLANG["it"]["tabs"]["tab"] = "Manuale Utente";

$MLANG["fr"]["labels"]["tablabel"] = "Manuel d'utilisateur";
$MLANG["fr"]["labels"]["tabdescr"] = "Acc�s en ligne au manuel utilisateur de Typo3.";
$MLANG["fr"]["tabs"]["tab"] = "Manuel utilisateur";

$MLANG["pl"]["labels"]["tablabel"] = "Instrukcja u�ytkownika";
$MLANG["pl"]["labels"]["tabdescr"] = "Wersja online instrukcji u�ytkownika. Ta instrukcja omawia og�ln� koncepcj� i mo�e nie zawiera� informacji specyficznych dla twojego systemu Typo3";
$MLANG["pl"]["tabs"]["tab"] = "Instrukcja u�ytkownika";

$MLANG["es"]["labels"]["tablabel"] = "Manual del usuario de Typo3 ";
$MLANG["es"]["labels"]["tabdescr"] = "El 'm�dulo integrado de tercero' la interfase phpMyAdmin. Le perimite acceder las tablas de la base de datos a bajo nivel. El acceso al phpMyAdmin es autentificado mediante el Typo3. Pero es la �nica interacci�n - phpMyAdmin le permitir� modificar lo que sea, as� que �tenga cuidado!<BR><em>�Acceso solamente para usuarios 'administrador'!</em>";
$MLANG["es"]["tabs"]["tab"] = "Manual del usuario";

$MLANG["si"]["labels"]["tablabel"] = "Typo3 uporabni�ki priro�nik";
$MLANG["si"]["labels"]["tabdescr"] = "Online dostop do uporabni�kega priro�nika Typo3. Ta ponuja le splo�ne informacije, zato morda ne bo poplnoma veljaven za va�o verzijo programa.";
$MLANG["si"]["tabs"]["tab"] = "Uporabni�ki priro�nik";

$MLANG["nl"]["labels"]["tablabel"] = "Typo3 gebruikershandleiding";
$MLANG["nl"]["labels"]["tabdescr"] = "Online toegang tot de Typo3 Gebruikershandleiding. Dit behandelt algemene kwesties en geeft geen info over jouw eigenlijke Typo3 systeem.";
$MLANG["nl"]["tabs"]["tab"] = "Handleiding";

$MLANG["cz"]["labels"]["tablabel"] = "U�ivatelsk� manu�l Typo3";
$MLANG["cz"]["labels"]["tabdescr"] = "Online p��stup do u�ivatelsk�ho manu�lu Typo3. Pokr�v� obecn� t�mata a nemus� poskytovat specifick� informace o aktu�ln� verzi syst�mu Typo3";
$MLANG["cz"]["tabs"]["tab"] = "U�ivatelsk� manu�l";

$MLANG["fi"]["labels"]["tablabel"] = "Typo3 k�ytt�j�n k�sikirja";
$MLANG["fi"]["labels"]["tabdescr"] = "Online mahdollisuus Typo3 k�ytt�j�n k�sikirjaan. K�sikirja on yleisluontoinen eik� mahdollisesti anna apua erityisiin ja yksityiskohtaiiin ongelmiin.";
$MLANG["fi"]["tabs"]["tab"] = "K�ytt�j�n k�sikirja";

$MLANG["tr"]["labels"]["tablabel"] = "Typo3 kullan�c� k�lavuzu";
$MLANG["tr"]["tabs"]["tab"] = "Kullan�c� k�lavuzu";
$MLANG["tr"]["labels"]["tabdescr"] = "Online Typo3 kullan�c� k�lavuzuna eri�im. Bu yaln�zca genel konular� i�erir, sizin Typo3 kurulumunuza �zg� bilgileri sa�lamayabilir.";


$MCONF["script"]="index.php";
$MCONF["name"]="help_quick";
?>