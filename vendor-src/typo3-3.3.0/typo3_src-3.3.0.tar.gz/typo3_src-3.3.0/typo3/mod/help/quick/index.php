<?php
unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
$BE_USER->modAccess($MCONF,1);



// ***************************
// Script Classes
// ***************************
class SC_mod_help_quick_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();

	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		// **********************
		// *** Online Support ***
		// **********************
		// This document redirects to the Typo3-website for usersupport.
		
		
		if (substr($LANG->typo3_help_url,0,4)=="http")	{
			Header("Location: ".$LANG->typo3_help_url);
		} else {
			Header("Location: ".$BACK_PATH.$LANG->typo3_help_url."index.htm");
		}
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/help/quick/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/help/quick/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_help_quick_index");
$SOBE->main();
?>