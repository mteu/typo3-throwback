<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module:Welcome
 *
 * This module simply welcomes users with a series of animations they can watch
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
include ("locallang.php");
$BE_USER->modAccess($MCONF,1);




// ***************************
// Script Classes
// ***************************
class SC_mod_help_welcome_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $content;
	var $animation;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		$this->animation = t3lib_div::GPvar("animation");
		if (!$LANG->getLL($this->animation."_head"))	{
			$this->animation=1;
		}
		
		// **************************
		// Initializing
		// **************************
		$this->doc = t3lib_div::makeInstance("bigDoc");
		$this->doc->backPath = $BACK_PATH;
		
		
		// **************************
		// Content creation
		// **************************
		$this->doc->form = '<form action="" method="POST">';
		$this->doc->JScode = '';
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content.=$this->doc->startPage($LANG->getLL("title"));
		$this->content.=$this->doc->header($LANG->getLL("title"));
		$this->content.=$this->doc->spacer(5);
		
		if ($this->animation==1)	{
			if (!trim($BE_USER->uc["interfaceSetup"]))	{
				$this->content.=$this->doc->spacer(10);
				$this->content.=$this->doc->section("",$this->boxText($LANG->getLL("firstTime")));
			}
			$this->content.=$this->doc->spacer(10);
			$this->content.=$this->doc->section("",$LANG->getLL("welcome"));
			$this->content.=$this->doc->spacer(20);
		}
			// Displaying animation information:
		$text = '<b>'.strtoupper($LANG->getLL($this->animation."_head")).'</b><BR>';
		$this->content.=$this->doc->spacer(10);
		$this->content.=$this->doc->section("",$text);
		
		$this->content.=$this->doc->spacer(10);
		$this->content.=$this->doc->section("",$this->control($this->animation,1));
		
		$this->content.=$this->doc->spacer(10);
		$this->content.=$this->doc->section("",$this->control($this->animation));
		
		$text = $LANG->getLL($this->animation."_text");
		$this->content.=$this->doc->spacer(10);
		$this->content.=$this->doc->section("",$text);
		
		$this->content.=$this->doc->sectionEnd();
		
			// Displaying the animation itself
		$aniFile = $this->animation.".gif";
		if (@is_file($aniFile))	{
			$imageInfo = @getimagesize($aniFile);
			$this->content.='<BR>';
			$this->content.=$this->imageTable('<img src="'.$aniFile.'" '.$imageInfo[3].'>', $imageInfo);
		}
		
		
		$this->content.=$this->doc->divider(10);
		$this->content.=$this->doc->section("",$LANG->getLL("general"));
		
		
		
		
		if ($BE_USER->mayMakeShortcut())	{
			$this->content.=$this->doc->spacer(20).$this->doc->section('',$this->doc->makeShortcutIcon("animation","",$this->MCONF["name"]));
		}
	}
	function printContent()	{
		global $SOBE;

		$this->content.=$this->doc->spacer(20);
		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
	function imageTable($image,$info)	{
		$o = -50;
		$color = t3lib_div::modifyHTMLColor("#9BA1A8",$o,$o,$o);
		$w = 128;
		$w2=464;
		$thick=10;
		$totalBr = $info[0]+2*$thick;
		if ($totalBr > $w2)	{
			$w = t3lib_div::intInRange($w-(($totalBr-$w2)/2),0,$w);
		}
		
		$code = '<table border=0 cellpadding=0 cellspacing=0 width=1>
		<tr>
			<td><img src="clear.gif" height="1" width="'.$w.'"></td>
			<td><img src="clear.gif" height="1" width="'.$w2.'"></td>
		</tr>
		<tr>
			<td></td>
			<td align=center>'.$this->borderWrap($image,$color,$thick).'</td>
		</tr>
		</table>';
		return $code;
	}
	function borderWrap($str,$color,$thick)	{
		$code = '<table border=0 cellpadding='.$thick.' cellspacing=0 width=1>
		<tr>
			<td bgcolor="'.$color.'">'.$str.'</td>
		</tr>
		</table>';
		return $code;
	}
	function control($animation,$sel=0)	{
		$list = "1,2,4,5,3,6,7,8,9,10,11";
		$back1="silver";
		$back2="red";
		$pad="&nbsp;&nbsp;";
		$listArr = explode(",",$list);
		$valArr=array();
		$nextVal = 0;
		$passedActive=0;
		$opt=array();
		while(list($count,$val)=each($listArr))	{
				// Selector:
			$opt[]='<option value="'.$val.'"'.($val==$animation?" selected":"").'>'.htmlspecialchars($GLOBALS["LANG"]->getLL($val."_head")).'</option>';
				// Bar:
			if ($val==$animation)	{
				$passedActive = 1;
				$valArr[]='<td bgcolor="'.$back2.'">'.$this->linkAnim(fw('<font color=white><strong>'.$pad.($count+1).$pad.'</strong></font>'),$val).'</td>';
			} else {
				if ($passedActive)	{$nextVal=$val; $passedActive=0;}
				$valArr[]='<td bgcolor="'.$back1.'">'.$this->linkAnim(fw('<strong>'.$pad.($count+1).$pad.'</strong>'),$val).'</td>';
			}
		}
			
			// Finish selector:
		$selector='
		<select name="animation" onChange="submit()">
		'.implode("",$opt).'
		</select>
		';
	
			// Finish table:
		if ($nextVal)	{
			$valArr[]='<td bgcolor="'.$back1.'">'.$this->linkAnim(fw('<strong>'.$pad.$GLOBALS["LANG"]->getLL("next")." >".$pad.'</strong>'),$nextVal).'</td>';
		}
		
		$cells = '<tr>'.implode($valArr,'<td>'.fw("-").'</td>').'</tr>';
		$theTable = '<table border=0 cellpadding=2 cellspacing=0>'.$cells.'</table>';
	
			// Output:
		return $sel ? $selector : $theTable;
	}
	function linkAnim($str,$anim)	{
		return '<a href="index.php?animation='.$anim.'">'.$str.'</a>';
	}
	function boxText($str)	{
		$bg=" bgcolor='black'";
		$m=20;
		$code='<div align=center>
		<table border=0 cellpadding=0 cellspacing=0 width=350>
		<tr>
			<td'.$bg.' colspan=5><img src=clear.gif width=1 height=1></td>
		</tr>	
		<tr>
			<td'.$bg.'><img src=clear.gif width=1 height=1></td>
			<td><img src=clear.gif width='.$m.' height=1></td>
			<td align=center><BR>'.fw($str).'<BR><BR></td>
			<td><img src=clear.gif width='.$m.' height=1></td>
			<td'.$bg.'><img src=clear.gif width=1 height=1></td>
		</tr>	
		<tr>
			<td'.$bg.' colspan=5><img src=clear.gif width=1 height=1></td>
		</tr>	
		</table></div>
		';
		return $code;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/help/welcome/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/help/welcome/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_help_welcome_index");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>