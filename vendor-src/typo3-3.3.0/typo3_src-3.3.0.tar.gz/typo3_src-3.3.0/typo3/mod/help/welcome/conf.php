<?php
define("TYPO3_MOD_PATH", "mod/help/welcome/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "First-time introduction to Typo3";
$MLANG["default"]["tabs"]["tab"] = "Welcome";
$MLANG["default"]["tabs_images"]["tab"] = "smile.gif";
$MLANG["default"]["labels"]["tabdescr"] = "This module features 11 small animations, all related to the classic interface in Typo3. This may be a great introduction if you're new to Typo3. However if you're using the Alternative Backend the concepts shown may not relate very well to your situation.";

$MLANG["dk"]["labels"]["tablabel"] = "F�rstegangs-introduktion til Typo3";
$MLANG["dk"]["tabs"]["tab"] = "Velkommen";
$MLANG["dk"]["labels"]["tabdescr"] = "Dette modul indeholder 11 sm� animationer, alle relaterede til det klassiske interface i Typo3. Dette er formentlig en virkelig god introduktion, hvis du er ny i Typo3. Hvis du benytter det Alternative Backend interface er det dog ikke sikkert, at de passer s� godt til din situation.";

$MLANG["de"]["labels"]["tablabel"] = "Erste Einf�hrung in Typo3";
$MLANG["de"]["labels"]["tabdescr"] = "Dieses Modul bietet 11 kleine Animationen, alle bezogen auf das 'Classic'-Benutzerinterface in Typo3. Diese Animationen sind eine gro�e Hilfe, wenn Sie Typo3 zum ersten Mal benutzen. Sollten Sie allerdings das alternative Benutzerinterface benutzen, werden Sie nicht viele Verbindungen zur dieser Hilfe finden.";
$MLANG["de"]["tabs"]["tab"] = "Willkommen";

$MLANG["no"]["labels"]["tablabel"] = "F�rstegangsintroduksjon til Typo3";
$MLANG["no"]["labels"]["tabdescr"] = "Denne modulen inneholder 11 sm� animasjoner, alle relatert til det klassiske grensesnittet i Typo3. Dette er virkelig en god introduksjon dersom du er nybegynner i Typo3. Dersom du derimot benytter det alternative grensesnittet er det ikke sikkert du vil ha like stor nytte av dem.";
$MLANG["no"]["tabs"]["tab"] = "Velkommen";

$MLANG["it"]["labels"]["tablabel"] = "Prima introduzione a Typo3";
$MLANG["it"]["labels"]["tabdescr"] = "In questo modulo troverete 11 piccole animazioni che vi introdurranno all'uso della interfaccia classica di Typo3. Ottime se non siete molto esperti. I concetti presentati non vi saranno di molto aiuto se invece usate l'Alternative Backend.";
$MLANG["it"]["tabs"]["tab"] = "Benvenuti";

$MLANG["si"]["labels"]["tablabel"] = "Uvod v Typo3 za za�etnike";
$MLANG["si"]["tabs"]["tab"] = "Dobrodo�li";
$MLANG["si"]["labels"]["tabdescr"] = "Tukaj si lahko ogledate 11 majhnih animacij, ki pojasnjujejo delo s standardnim Typo3 vmesnikom. �e uporabljate alternativni vmesnik, za vas to ne pride v po�tev.";

$MLANG["fr"]["labels"]["tablabel"] = "Introduction de d�part";
$MLANG["fr"]["labels"]["tabdescr"] = "Ce module comporte 11 petites animations, toutes en relation avec l'interface classic de Typo3. Ce peut �tre une bonne introduction si vous utilisez Typo3 pour la premi�re fois. Si vous utilisez l'interface alternative, ces exemples ne correspondent pas vraiement � vos besoins.";
$MLANG["fr"]["tabs"]["tab"] = "Bienvenue";

$MLANG["es"]["labels"]["tablabel"] = "Primera intrucci�n al Typo3";
$MLANG["es"]["labels"]["tabdescr"] = "Este m�dulo contiene 11 peque�as animaciones relacionadas con la interfase cl�sica de Typo3. Esta puede ser una gran introducci�n si es nuevo al Typo3. Sin embargo si est� usando la interface Alternativa al Backend los conceptos mostrados podr�an no relacionarse muy bi�n con su situaci�n.";
$MLANG["es"]["tabs"]["tab"] = "�Bienvenido!";

$MLANG["pl"]["labels"]["tablabel"] = "Wprowadzenie dla pocz�tkuj�cych";
$MLANG["pl"]["labels"]["tabdescr"] = "Ten modu� zawiera 11 animacji dotycz�cych klasycznego interfejsu co mo�e by� niez�ym wprowadzeniem. Je�li u�ywasz interfejsu alternatywnego niekt�re wyja�nienia mog� nie przystawa� do twojej sytuacji.";
$MLANG["pl"]["tabs"]["tab"] = "Witamy";

$MLANG["nl"]["labels"]["tablabel"] = "Een eerste kennismaking met Typo3";
$MLANG["nl"]["labels"]["tabdescr"] = "In deze module bevinden zich 11 kleine animaties die slaan op de klassieke interface van Typo3. Dit kan een geweldige introductie zijn als je nieuw bent bij Typo3. Als je echter gebruik maakt van de Alternatieve BeheerSite dan zijn deze animaties niet voor jou bedoeld.";
$MLANG["nl"]["tabs"]["tab"] = "Welkom";

$MLANG["cz"]["labels"]["tablabel"] = "Prvn� �vod do Typo3";
$MLANG["cz"]["labels"]["tabdescr"] = "Tento modul m� 11 mal�ch animac�, v�echny se vztahuj� ke klasick�mu interaface Typo3. M��e to b�t skv�l� �vod, pokud jste v Typo3 poprv�. Nicm�n� pokud pou��v�te Alternativn� Backend, nemus� se zde ukazovan� koncepty vztahovat k va�� situaci.";
$MLANG["cz"]["tabs"]["tab"] = "V�tejte";

$MLANG["fi"]["labels"]["tablabel"] = "Ensikertalaisen Typo3 esittely";
$MLANG["fi"]["labels"]["tabdescr"] = "T�ss� modulissa kuvataa 11 pient� animaatiota, jotka kaikki liittyv�t klassiseen Typo3n liittym��n. T�st� voi olla suurta hy�ty� muodostaessasi yleisen k�sitykse Typo3n toiminnasta ja mahdollisuuksista. Huomattavaa ett� uusi k�ytt�j� liittym� ei vastaa esitettyj� animaatioita.";
$MLANG["fi"]["tabs"]["tab"] = "Tervetuloa";

$MLANG["tr"]["labels"]["tablabel"] = "Typo3 e ilk giri�";
$MLANG["tr"]["tabs"]["tab"] = "Ho�geldiniz";
$MLANG["tr"]["labels"]["tabdescr"] = "Bu mod�lde 11 k���k animasyonun �nemli bir rol� var, hepsi Typo3 �n klasik arabirimiyle ilgilidir. E�er Typo3 e yeniyseniz, bu �nemli bir ba�lang�� olabilir. Bununla birlikte alternatif y�netim b�l�m� kullan�yorsan�z, g�sterilen i�erikler sizin durumunuzu tam anlam�yla g�stermeyebilir.";

$MCONF["script"]="index.php";
$MCONF["access"]="user,group";
$MCONF["name"]="help_welcome";
?>