<?php
define("TYPO3_MOD_PATH", "mod/help/aboutmodules/");
$BACK_PATH="";

$MLANG["default"]["labels"]["tablabel"] = "Information about modules";
$MLANG["default"]["tabs"]["tab"] = "About modules";
$MLANG["default"]["tabs_images"]["tab"] = "aboutmodules.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Shows this page about available modules.";

$MLANG["dk"]["tabs"]["tab"] = "Om moduler";
$MLANG["dk"]["labels"]["tablabel"] = "Information om moduler";
$MLANG["dk"]["labels"]["tabdescr"] = "Viser denne side omkring de tilg�ngelige moduler.";

$MLANG["de"]["labels"]["tablabel"] = "Informationen �ber Module";
$MLANG["de"]["labels"]["tabdescr"] = "Zeigt alle f�r diese Seite vorhandenen Module an.";
$MLANG["de"]["tabs"]["tab"] = "�ber Module";

$MLANG["no"]["labels"]["tablabel"] = "Informasjon om moduler";
$MLANG["no"]["labels"]["tabdescr"] = "Viser denne siden om tilgjengelige moduler";
$MLANG["no"]["tabs"]["tab"] = "Om moduler";

$MLANG["it"]["labels"]["tablabel"] = "Informazione sui Moduli";
$MLANG["it"]["labels"]["tabdescr"] = "Mostra questa pagina introduttiva sui moduli disponibili.";
$MLANG["it"]["tabs"]["tab"] = "Informazione sui Moduli";

$MLANG["fr"]["labels"]["tablabel"] = "Informations sur le modules";
$MLANG["fr"]["labels"]["tabdescr"] = "Afficher cette page sur les modules disponibles";
$MLANG["fr"]["tabs"]["tab"] = "Sur les modules";

$MLANG["pl"]["labels"]["tablabel"] = "Informacje o modu�ach";
$MLANG["pl"]["labels"]["tabdescr"] = "Pokazuje informacje o dost�pnych modu�ach";
$MLANG["pl"]["tabs"]["tab"] = "O modu�ach";

$MLANG["es"]["labels"]["tablabel"] = "Informaci�n sobre los m�dulos";
$MLANG["es"]["labels"]["tabdescr"] = "Muestra esta p�gina acerca de los m�dulos disponibles.";
$MLANG["es"]["tabs"]["tab"] = "Acerca de los m�dulos";

$MLANG["si"]["labels"]["tablabel"] = "Informacije o modulih";
$MLANG["si"]["labels"]["tabdescr"] = "Prika�e to stran o razpolo�ljivih modulih.";
$MLANG["si"]["tabs"]["tab"] = "O modulih";

$MLANG["nl"]["labels"]["tablabel"] = "Info over modules";
$MLANG["nl"]["labels"]["tabdescr"] = "Toont de pagina over beschikbare modules";
$MLANG["nl"]["tabs"]["tab"] = "Over modules";

$MLANG["cz"]["labels"]["tablabel"] = "Informace o modulech";
$MLANG["cz"]["labels"]["tabdescr"] = "Uk�e tuto stranu o dostupn�ch modulech";
$MLANG["cz"]["tabs"]["tab"] = "O modulech";

$MLANG["fi"]["labels"]["tablabel"] = "Tietoja moduleista";
$MLANG["fi"]["labels"]["tabdescr"] = "N�ytt�� t�ll� sivulla tietoa moduleista";
$MLANG["fi"]["tabs"]["tab"] = "Moduleista";

$MLANG["tr"]["labels"]["tablabel"] = "Mod�ller hakk�nda bilgi";
$MLANG["tr"]["tabs"]["tab"] = "Mod�ller hakk�nda";
$MLANG["tr"]["labels"]["tabdescr"] = "Mevcut mod�llere ili�kin sayfay� g�ster.";


$MCONF["script"]="../../../alt_intro.php";
$MCONF["name"]="web_list";

?>