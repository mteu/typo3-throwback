<?php
$LOCAL_LANG = Array (
	"default" => Array (
		"welcome" => "Typo3 Professional Web Content Management System",
		"minor" => 'Typo3 is a flexible and professional Open Source Web-CMS based on PHP4 and MySQL.<br><br>Typo3 is <B>freely available</b> under the <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3-license (GNU/GPL)</a>.<br><br>%s %s<br>'
	),
	"dk" => Array (
		"welcome" => "Typo3 Professionelt Web Content Management System",
		"minor" => 'Typo3 er et flexibelt og professionelt Open Source Web-CMS baseret p� PHP4 og MySQL.<br><br>Typo3 er til <B>fri afbenyttelse</b> under <A HREF="http://www.typo3.dk/?price_dk" target="_blank">Typo3-licensen (GNU/GPL)</a>.<br><br>%s %s<br>'
	),
	"de" => Array (
		"welcome" => "Typo3 Professionelles Web Content Managment System",
		"minor" => 'Typo3 ist ein flexibles und professionelles Open Source Web-CMS basierend auf PHP4 und MySQL.<br><br>Typo3 ist <b>frei verf�gbar</b> unter der <a href="http://www.typo3.com/?price_uk" target="_blank">Typo3-Lizenz (GNU/GPL)</a>.<br><br>%s %s<br>',
	),
	"no" => Array (
		"welcome" => "Typo3 profesjonelt Web Content Management System",
		"minor" => 'Typo3 er et fleksibelt og profesjonelt Open Source Web-CMS basert p� PHP4 og MySQL.<br><br>Typo3 kan <B>fritt benyttes</b> under <A HREF="http://www.typo3.dk/?price_dk" target="_blank">Typo3-lisensen (GNU/GPL)</a>.<br><br>%s %s<br>',
	),
	"it" => Array (
		"welcome" => "Typo3 Professional Web Content Management System",
		"minor" => 'Typo3 � un flessibile e professionale Web-CMS Open Source, basato su PHP4 e MySQL.<br><br>Typo3 � <B>liberamente disponibile</b> su <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3-license (GNU/GPL)</a>.<br><br>%s %s<br>',
	),
	"fr" => Array (
		"welcome" => "Typo3 CMS Solution professionnel pour la gestion de contenu d'un site web.",
		"minor" => "Typo3 est un web-CMS Opensource flexible et professionnel bas� sur PHP4 et mySQL.",
	),
	"es" => Array (
		"welcome" => "Typo3 Professional Web Content Management System",
		"minor" => 'Typo3 es un CMS flexible y profesional, con su c�digo fuente abierto, basado en PHP4 y MySQL. <br><br>Typo3 est� <B>disponible libremente</b> bajo la <A HREF="http://www.typo3.com/?price_uk" target="_blank">licencia Typo3 (GNU/GPL)</a>.<br><br>%s %s<br>'
	),
	"nl" => Array (
		"welcome" => "Typo3 Professioneel Web Content Management Systeem",
		"minor" => 'Typo3 is een flexibel en professioneel Open Source Web-CMS gebaseerd op PHP4 en MySQL.<br><br>Typo3 is <b>gratis verkrijgbaar</b> onder de <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3-licentie (GNU/GPL)</a>.<br><br>%s %s<br>',
	),
	"cz" => Array (
		"welcome" => "Profesion�ln� syst�m pro spr�vu obsahu webu Typo3",
		"minor" => 'Typo3 je flexibiln� a profesion�ln� Open Source Web-CMS zalo�en� na PHP4 a MySQL.<br><br>Typo3 je <b>voln� dostupn�</b> pod <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3-licenc� GNU/GPL)</a>.<br><br>%s %s<br> ',
	),
 	"si" => array (
		"welcome" => "Typo3 - sistem za urejanje spletne vsebine (Web CMS)",
		"minor" => 'Typo3 je prilagodljiv profesionalen sistem za urejanje spletne vsebine. Deluje na podlagi PHP4 in  MySQL.<br><br>Typo3 je <b>dosegljiv zastonj</b> upo�tevajo� <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3 licenco (GNU/GPL)</a>.<br><br>Typo3 je v slovenski jezik prevedel Andrej Blatnik, ablatnik@email.si<br><br>%s %s<br>'
  	),
	"pl" => Array (
		"welcome" => "Typo3 Profesjonalny System do Zarz�dzania Tre�ci�",
		"minor" => 'Typo3 jest elastycznym i profesjonalnym systemem klasy Web-CMS o Otwartym Kodzie (Open Source), opartym na PHP4 i MySQL.<br><br>Typo3 jest<b>dost�pny bez op�at</b> na zasadach <A HREF="http://www.typo3.com/?price_uk" target="_blank">licencji Typo3 (GNU/GPL)</a>.<br><br>%s %s<br>',
	),
	"fi" => Array (
		"welcome" => "Typo3 Professional Web Content Management System",
		"minor" => 'Typo3 on joustava ja ammattimaisesti tehty avoin www-sivujen hallinta ohjelmisto.joka perustuu PHP4 ja MySQL ohjelmistoihin. <br><br>Typo3 on <B>vapaasti saatavissa</b>, www-sivuilta <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3-lisenssin mukaisesti (GNU/GPL)</a>.<br><br>%s %s<br>',
	),
	"tr" => Array (
		"welcome" => "Typo3 Profesyonel Web ��erik Y�netim Sistemi�",
		"minor" => 'Typo3 PHP4 ve Mysql tabanl� profesyonel ve esnek kaynak kodu a��k bir Web-CMS\'dir.<br><br>Typo3<b>serbest�e elde edilebilir</b> a�a��daki <A HREF="http://www.typo3.com/?price_uk" target="_blank">Typo3 lisans� (GNU/GPL)</a>.<br><br>%s %s<br>'
	)	
);
?>