<?php
define("TYPO3_MOD_PATH", "mod/help/about/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "About Typo3";
$MLANG["default"]["tabs"]["tab"] = "About";
$MLANG["default"]["tabs_images"]["tab"] = "info.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Displays the basic facts about the Typo3 application, version and licensing terms.";

$MLANG["dk"]["labels"]["tablabel"] = "Information om Typo3";
$MLANG["dk"]["tabs"]["tab"] = "Om Typo3";
$MLANG["dk"]["labels"]["tabdescr"] = "Viser grundl�ggende fakta omkring Typo3 systemet, versionsnummer og licensbetingelser.";

$MLANG["de"]["labels"]["tablabel"] = "Informationen �ber Typo3";
$MLANG["de"]["tabs"]["tab"] = "�ber Typo3";
$MLANG["de"]["labels"]["tabdescr"] = "Zeigt Ihnen die grundlegenden Informationen zu Typo3, Versionsinformationen und Lizenzbedingungen an.";

$MLANG["no"]["labels"]["tablabel"] = "Informasjon om Typo3";
$MLANG["no"]["tabs"]["tab"] = "Om Typo3";
$MLANG["no"]["labels"]["tabdescr"] = "Grunnleggende informasjon om Typo3 systemet, versjonsnummer og lisensbetingelser.";

$MLANG["it"]["labels"]["tablabel"] = "Notizie su Typo3";
$MLANG["it"]["tabs"]["tab"] = "Notizie";
$MLANG["it"]["labels"]["tabdescr"] = "Mostra notizie di carattere generale su Typo3, quali la versione e la licenza d'uso.";

$MLANG["fr"]["labels"]["tablabel"] = "A propos de Typo3";
$MLANG["fr"]["tabs"]["tab"] = "A propos";
$MLANG["fr"]["labels"]["tabdescr"] = "Affiche des informations basiques sur Typo3, version, licence, ...";

$MLANG["es"]["labels"]["tablabel"] = "Acerca de Typo3";
$MLANG["es"]["tabs"]["tab"] = "Acerca de";
$MLANG["es"]["labels"]["tabdescr"] = "Muestra ";

$MLANG["nl"]["labels"]["tablabel"] = "Over Typo3";
$MLANG["nl"]["tabs"]["tab"] = "Over";
$MLANG["nl"]["labels"]["tabdescr"] = "Toont de belangrijkste gegevens over de Typo3 applicatie, versie en licentie bepalingen.";

$MLANG["cz"]["labels"]["tablabel"] = "O Typo3";
$MLANG["cz"]["tabs"]["tab"] = "O Typo3";
$MLANG["cz"]["labels"]["tabdescr"] = "Zobraz� z�kladn� informace o aplikaci Typo3, verzi a licen�n�ch podm�nk�ch.";

$MLANG["pl"]["labels"]["tablabel"] = "Informacje o Typo3";
$MLANG["pl"]["tabs"]["tab"] = "O Typo3";
$MLANG["pl"]["labels"]["tabdescr"] = "Wy�wietla podstawowe informacje o Typo3 oraz wersj� i warunki licencji.";

$MLANG["si"]["labels"]["tablabel"] = "O Typo3";
$MLANG["si"]["tabs"]["tab"] = "O Typo3";
$MLANG["si"]["labels"]["tabdescr"] = "Prika�e osnovne informacije o programu Typo3: verzija in licen�ni pogoji.";

$MLANG["fi"]["labels"]["tablabel"] = "Tietoa Typo3sta";
$MLANG["fi"]["labels"]["tabdescr"] = "N�ytt�� yleisi� tietoja Typo3sta";
$MLANG["fi"]["tabs"]["tab"] = "Tietoa Typo3sta";

$MLANG["tr"]["labels"]["tablabel"] = "Typo3 hakk�nda";
$MLANG["tr"]["tabs"]["tab"] = "Hakk�nda";
$MLANG["tr"]["labels"]["tabdescr"] = "Typo3 ba�vurusu, versiyon ve lisans ko�ullar� hakk�nda temel olgular� g�sterir.";


$MCONF["script"]="index.php";
$MCONF["name"]="help_about";
?>