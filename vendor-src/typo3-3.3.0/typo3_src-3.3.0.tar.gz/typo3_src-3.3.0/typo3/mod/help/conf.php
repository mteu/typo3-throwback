<?php
$MLANG["default"]["labels"]["tablabel"] = "Help and support";
$MLANG["default"]["tabs"]["tab"] = "Help";
$MLANG["default"]["tabs_images"]["tab"] = "help.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Hj�lp og support";
$MLANG["dk"]["tabs"]["tab"] = "Hj�lp";

$MLANG["de"]["labels"]["tablabel"] = "Hilfe und Support";
$MLANG["de"]["tabs"]["tab"] = "Hilfe";

$MLANG["no"]["labels"]["tablabel"] = "Hjelp og support";
$MLANG["no"]["tabs"]["tab"] = "Hjelp";

$MLANG["it"]["labels"]["tablabel"] = "Aiuto e supporto";
$MLANG["it"]["tabs"]["tab"] = "Aiuto";

$MLANG["fr"]["labels"]["tablabel"] = "Aide et support technique";
$MLANG["fr"]["tabs"]["tab"] = "Aide";

$MLANG["es"]["labels"]["tablabel"] = "Ayuda y soporte";
$MLANG["es"]["tabs"]["tab"] = "Ayuda";

$MLANG["nl"]["labels"]["tablabel"] = "Help en ondersteuning";
$MLANG["nl"]["tabs"]["tab"] = "Help";

$MLANG["cz"]["labels"]["tablabel"] = "Help a podpora";
$MLANG["cz"]["tabs"]["tab"] = "Help";

$MLANG["si"]["labels"]["tablabel"] = "Pomo� in podpora";
$MLANG["si"]["tabs"]["tab"] = "Pomo�";

$MLANG["pl"]["labels"]["tablabel"] = "Pomoc i wsparcie";
$MLANG["pl"]["tabs"]["tab"] = "Pomoc";

$MLANG["fi"]["labels"]["tablabel"] = "Help-toiminnot ja tuki";
$MLANG["fi"]["tabs"]["tab"] = "Help-toiminnot";

$MLANG["tr"]["labels"]["tablabel"] = "Yard�m ve destek";
$MLANG["tr"]["tabs"]["tab"] = "Yard�m";


$MCONF["defaultMod"]="welcome";
$MCONF["name"]="help";
?>