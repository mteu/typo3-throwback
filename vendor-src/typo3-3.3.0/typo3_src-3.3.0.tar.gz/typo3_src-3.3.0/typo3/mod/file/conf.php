<?php
$MLANG["default"]["labels"]["tablabel"] = "File administration on the server";
$MLANG["default"]["tabs"]["tab"] = "File";
$MLANG["default"]["tabs_images"]["tab"] = "file.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Fil-administration p� serveren";
$MLANG["dk"]["tabs"]["tab"] = "Filer";

$MLANG["de"]["labels"]["tablabel"] = "Datei-Administration auf dem Server";
$MLANG["de"]["tabs"]["tab"] = "Datei";

$MLANG["no"]["labels"]["tablabel"] = "Fil-administratoren p� serveren";
$MLANG["no"]["tabs"]["tab"] = "Filer";

$MLANG["it"]["labels"]["tablabel"] = "File di amministrazione sul server";
$MLANG["it"]["tabs"]["tab"] = "File";

$MLANG["fr"]["labels"]["tablabel"] = "Administration des fichiers sur le serveur";
$MLANG["fr"]["tabs"]["tab"] = "Fichier";

$MLANG["es"]["labels"]["tablabel"] = "Administraci�n de archivos en el servidor";
$MLANG["es"]["tabs"]["tab"] = "Archivos";

$MLANG["nl"]["labels"]["tablabel"] = "Bestandenbeheer op de server";
$MLANG["nl"]["tabs"]["tab"] = "Bestand";

$MLANG["cz"]["labels"]["tablabel"] = "Spr�va soubor� na serveru";
$MLANG["cz"]["tabs"]["tab"] = "Soubory";

$MLANG["pl"]["labels"]["tablabel"] = "Administracja plikami na serwerze";
$MLANG["pl"]["tabs"]["tab"] = "Pliki";

$MLANG["si"]["labels"]["tablabel"] = "Administracija datotek na stre�niku";
$MLANG["si"]["tabs"]["tab"] = "Datoteke";

$MLANG["fi"]["labels"]["tablabel"] = "Tiedosto hallinta palvelimella";
$MLANG["fi"]["tabs"]["tab"] = "Tiedosto";

$MLANG["tr"]["labels"]["tablabel"] = "Sunucuda dosya y�netimi";
$MLANG["tr"]["tabs"]["tab"] = "Dosya";

$MCONF["access"]="group,user";
$MCONF["name"]="file";
?>