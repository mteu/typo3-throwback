<?php
define("TYPO3_MOD_PATH", "mod/file/list/");
$BACK_PATH="";

$MLANG["default"]["labels"]["tablabel"] = "Listing of files in the directory";
$MLANG["default"]["tabs"]["tab"] = "Filelist";
$MLANG["default"]["tabs_images"]["tab"] = "list.gif";
$MLANG["default"]["labels"]["tabdescr"] = "This is the file administration system in Typo3. It allows you to access the file mounts of your login. Through this module you can upload, copy, move an delete files on the server.";

$MLANG["dk"]["labels"]["tablabel"] = "Listning af filer i kataloget";
$MLANG["dk"]["tabs"]["tab"] = "Filliste";
$MLANG["dk"]["labels"]["tabdescr"] = "Dette er filadminstrations-delen af Typo3. Her kan du som bruger tilg� dine fildrev p� serveren. Via dette modul kan du uploade, kopiere, flytte og slette filer p� serveren.";

$MLANG["de"]["labels"]["tablabel"] = "Anzeige von Dateien im Ordner";
$MLANG["de"]["tabs"]["tab"] = "Dateiliste";
$MLANG["de"]["labels"]["tabdescr"] = "Dies ist das Dateiverwaltungssystem von Typo3. Es erlaubt den Zugriff auf die f�r Ihren Login g�ltigen Dateifreigaben. Mit diesem Modul k�nnen Sie Dateien auf dem Server hochladen, kopieren, verschieben und l�schen.";

$MLANG["no"]["labels"]["tablabel"] = "Listing av filer i katalogen";
$MLANG["no"]["tabs"]["tab"] = "Filliste";
$MLANG["no"]["labels"]["tabdescr"] = "Dette er filadministrasjonsdelen av Typo3. Her kan du som bruker f� tilgang til dine fildrev p� serveren. Via denne modulen kan du laste opp, kopiere, flytte og slette filer p� serveren.";

$MLANG["it"]["labels"]["tablabel"] = "Lista dei files nella cartella";
$MLANG["it"]["labels"]["tabdescr"] = "Sistema per la gestione dei file di Typo3. Consente di accedere alle cartelle per cui avete i permessi. Attraverso questo modulo potete fare l'upload sul server di un file, e potete copiarlo, spostarlo o cancellarlo";
#$MLANG["it"]["tabs"]["tab"] = "Lista";

$MLANG["fr"]["labels"]["tablabel"] = "Liste des fichiers du r�pertoire";
#$MLANG["fr"]["tabs"]["tab"] = "Liste";
$MLANG["fr"]["labels"]["tabdescr"] = "C'est le syst�me d'administration des fichiers de Typo3. Il vous permet d'acc�der au Points de montage de votre identification. Avec ce module, vous pouvez uploader, copier, d�placer et supprimer des fichiers de ce serveur.";

$MLANG["es"]["labels"]["tablabel"] = "Relaci�n de archivos en el directorio";
#$MLANG["es"]["tabs"]["tab"] = "Relaci�n";
$MLANG["es"]["labels"]["tabdescr"] = "Este es el sistema de administraci�n de archivos de Typo3. Permite accesar los puntos de montaje de su cuenta. Mediante este m�dulo, ud. puede enviar, copiar, mover y borrar archivos en el servidor.";

$MLANG["nl"]["labels"]["tablabel"] = "Lijst van bestanden in de map";
$MLANG["nl"]["tabs"]["tab"] = "Bestand (lijst)";
#$MLANG["nl"]["tabs"]["tab"] = "Lijst";
$MLANG["nl"]["labels"]["tabdescr"] = "Dit is het bestandsbeheersysteem in Typo3. Het biedt je toegang tot de bestandsstartpunten behorende bij je login. Door middel van deze module kan je bestanden uploaden, kopi�ren, verplaatsen en verwijderen op de server.";

$MLANG["cz"]["labels"]["tablabel"] = "Seznam soubor� ve slo�ce";
#$MLANG["cz"]["tabs"]["tab"] = "Seznam";
$MLANG["cz"]["labels"]["tabdescr"] = "Toto je syst�m administrace soubor� v Typo3. Dovoluje v�m p�istupovat k soubor�m. T�mto modulem m��ete uploadovat, kop�rovat, p�esunovat a odstra�ovat soubory ze serveru.";

$MLANG["pl"]["labels"]["tablabel"] = "Lista plik�w w katalogu";
$MLANG["pl"]["tabs"]["tab"] = "Lista plik�w";
$MLANG["pl"]["labels"]["tabdescr"] = "To jest modu� do administrowania plikami. Tutaj masz dost�p do swoich plik�w. Dzi�ki temu modu�owi mozesz uploadowa�, kopiowa�, przenosi� i usuwa� pliki na serwerze.";

$MLANG["si"]["labels"]["tablabel"] = "Seznam datotek v mapi";
#$MLANG["si"]["tabs"]["tab"] = "Seznam";
$MLANG["si"]["labels"]["tabdescr"] = "To je sistem za delo z datotekami. Z njim lahko dostopate do svojih datotek na stre�niku. Lahko jih prena�ate, kopirate, preimenujete ali izbri�ete.";

$MLANG["fi"]["labels"]["tablabel"] = "Hakemiston tiedostoluettelo";
$MLANG["fi"]["labels"]["tabdescr"] = "T�m� on Typo3 tiedostonhallinta j�rjestelm�. Se antaa mahdollisuuden k�yt�ss�si olevien tiedotojen hallinnan. Modulin kautta voit vie, kopioida, siirt�� ja poistaa tiedostoja palvelimella.";
$MLANG["fi"]["tabs"]["tab"] = "Tiedostolista";

$MLANG["tr"]["labels"]["tablabel"] = "Dizindeki dosyalar�n listesi";
$MLANG["tr"]["tabs"]["tab"] = "Dosya listesi";
$MLANG["tr"]["labels"]["tabdescr"] = "Bu Typo3 �n i�indeki sistem y�netimi dosyas�d�r. Mount dosyas�na giri�iniz buna eri�im imkan� sa�lar. Bu mod�l arac�l���yla sunucudaki dosyalar� y�kleyebilir, kopyalayabilir, ta��yabilir ve silebilirsiniz.";


$MCONF["script"]="../../../file_list.php";
$MCONF["access"]="user,group";
$MCONF["name"]="file_list";

?>