<?php
$LOCAL_LANG = Array (
	"default" => Array (
		"title" => "Images"
	),
	"dk" => Array (
		"title" => "Billeder"
	),
	"de" => Array (
		"title" => "Bilder"
	),
	"no" => Array (
		"title" => "Bilder"
	),
	"es" => Array (
		"title" => "Im�genes"
	),
	"fr" => Array (
		"title" => "Images"
	),
	"it" => Array (
		"title" => "Immagini"	
	),
	"nl" => Array (
		"title" => "Afbeeldingen"
	),
	"cz" => Array (
		"title" => "Obr�zky"
	),
	"pl" => Array (
		"title" => "Obrazki"
	),
 	"si" => Array (
		"title" => "Slike"
	),
	"fi" => Array (
		"title" => "Luvat",
	),
	"tr" => Array (
		"title" => "G�r�nt�ler"
	)
);
?>