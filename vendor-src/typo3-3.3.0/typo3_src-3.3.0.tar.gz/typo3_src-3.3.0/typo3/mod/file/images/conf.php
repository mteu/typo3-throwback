<?php
define("TYPO3_MOD_PATH", "mod/file/images/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Listing of images in the directory";
$MLANG["default"]["tabs"]["tab"] = "Images";
$MLANG["default"]["tabs_images"]["tab"] = "images.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Lists the images in large dimensions, five at a time. The pixeldimensions of the images are displayed as well.";

$MLANG["dk"]["labels"]["tablabel"] = "Listning af billeder i kataloget";
$MLANG["dk"]["tabs"]["tab"] = "Billeder";
$MLANG["dk"]["labels"]["tabdescr"] = "Viser billeder i stort format, fem ad gangen. Pixeldimensionerne p� billederne bliver ogs� vist.";

$MLANG["de"]["labels"]["tablabel"] = "Anzeige der Bilder im Ordner";
$MLANG["de"]["tabs"]["tab"] = "Bilder";
$MLANG["de"]["labels"]["tabdescr"] = "Zeigt die Bilder im gro�en Format an. Die Anzeige ist auf je 5 Bilder begrenzt. Die Pixelgr��e der Bilder wird ebenfalls angezeigt.";

$MLANG["no"]["labels"]["tablabel"] = "Listing av bilder i katalogen";
$MLANG["no"]["tabs"]["tab"] = "Bilder";
$MLANG["no"]["labels"]["tabdescr"] = "Viser bilder i stort format, fem om gangen. Pixeldimensjonene p� bildene vises ogs�.";

$MLANG["it"]["labels"]["tablabel"] = "Lista delle immagini nella cartella";
$MLANG["it"]["labels"]["tabdescr"] = "Elenca le immagini in dimensione allargata, 5 per volta.Le dimensioni in pixel delle immagini sono quelle effettive.";
$MLANG["it"]["tabs"]["tab"] = "Immagini";

$MLANG["fr"]["labels"]["tablabel"] = "Liste des images du r�pertoire";
$MLANG["fr"]["tabs"]["tab"] = "Images";
$MLANG["fr"]["labels"]["tabdescr"] = "Lister les images en haute r�solution par groupe de cinq. Les dimensions de l'images sont aussi affich�e.";

$MLANG["es"]["labels"]["tablabel"] = "Relaci�n de im�genes en el directorio";
$MLANG["es"]["tabs"]["tab"] = "Im�genes";
$MLANG["es"]["labels"]["tabdescr"] = "Muestra las im�genes, cinco a la vez. Tambi�n indica el tama�o en pixeles";

$MLANG["nl"]["labels"]["tablabel"] = "Lijst van afbeeldingen in de map";
$MLANG["nl"]["tabs"]["tab"] = "Afbeeldingen";
$MLANG["nl"]["labels"]["tabdescr"] = "Toont een lijst van de afbeeldingen in de maximale grootte, vijf per keer. De pixelmaten van de afbeeldingen worden ook getoond.";

$MLANG["cz"]["labels"]["tablabel"] = "Seznam obr�zk� ve slo�ce";
$MLANG["cz"]["tabs"]["tab"] = "Obr�zky";
$MLANG["cz"]["labels"]["tabdescr"] = "Seznam obr�zkl ve v�t��m rozm�ru, p�t najednou. Rozm�ry obr�zku v bodech jsou zobrazeny tak�.";

$MLANG["pl"]["labels"]["tablabel"] = "Lista plik�w graficznych w folderze";
$MLANG["pl"]["labels"]["tabdescr"] = "W�wietla powi�kszone obrazki, pi�� za jednym razem. Podaje rownie� wielko�ci w pikselach.";
$MLANG["pl"]["tabs"]["tab"] = "Obrazki";

$MLANG["si"]["labels"]["tablabel"] = "Seznam slik v mapi";
$MLANG["si"]["tabs"]["tab"] = "Slike";
$MLANG["si"]["labels"]["tabdescr"] = "Prika�e slike v velikem formatu, po pet naenkrat. Prika�e tudi dimenzije slik v to�kah.";

$MLANG["fi"]["labels"]["tablabel"] = "Hakemistossa olevien kuvien luettelo";
$MLANG["fi"]["labels"]["tabdescr"] = "Listaa kuvat suurina, viisi kerrallaan. Kuvien pixel-mitat n�ytet��n my�s";
$MLANG["fi"]["tabs"]["tab"] = "Kuvat";

$MLANG["tr"]["labels"]["tablabel"] = "Dizindeki resimlerin listelenmesi";
$MLANG["tr"]["tabs"]["tab"] = "Resim";
$MLANG["tr"]["labels"]["tabdescr"] = "Resimlerin b�y�k boyutlarda listelenmesi, bir defada 5 resim. Ayn� zamanada resimin piksel boyutlar�da g�steriliyor.";


$MCONF["script"]="index.php";
$MCONF["access"]="group,user";
$MCONF["name"]="file_images";

?>