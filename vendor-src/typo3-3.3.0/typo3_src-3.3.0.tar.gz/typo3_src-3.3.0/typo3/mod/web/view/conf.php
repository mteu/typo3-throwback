<?php
define("TYPO3_MOD_PATH", "mod/web/view/");
$BACK_PATH="../../../";

$MLANG["default"]["tabs"]["tab"] = "View";
$MLANG["default"]["tabs_images"]["tab"] = "view.gif";
$MLANG["default"]["labels"]["tablabel"] = "View page";
$MLANG["default"]["labels"]["tabdescr"] = "Shows the look of the current page and lets you edit the content directly.";

$MLANG["dk"]["labels"]["tablabel"] = "Vis siden";
$MLANG["dk"]["tabs"]["tab"] = "Vis";
$MLANG["dk"]["labels"]["tabdescr"] = "Viser udseendet af den nuv�rende side og lader dig redigere indholdet direkte.";

$MLANG["nl"]["labels"]["tablabel"] = "Bekijk pagina";
$MLANG["nl"]["labels"]["tabdescr"] = "Laat zien hoe de huidige pagina er uit ziet en geeft je de mogelijkheid de inhoud direct te bewerken.";
$MLANG["nl"]["tabs"]["tab"] = "Beeld";

$MLANG["de"]["labels"]["tablabel"] = "Seite anzeigen";
$MLANG["de"]["labels"]["tabdescr"] = "Zeigt die aktuelle Seite an und l�sst Sie den Inhalt direkt bearbeiten.";
$MLANG["de"]["tabs"]["tab"] = "Anzeigen";

$MLANG["no"]["labels"]["tablabel"] = "Vis siden";
$MLANG["no"]["labels"]["tabdescr"] = "Viser utseende til den n�v�rende siden og lar deg redigere innholdet direkte";
$MLANG["no"]["tabs"]["tab"] = "Vis";

$MLANG["pl"]["labels"]["tablabel"] = "Zobacz stron�";
$MLANG["pl"]["labels"]["tabdescr"] = "Pokazuje, jak wygl�da strona i pozwala edytowa� zawarto��.";
$MLANG["pl"]["tabs"]["tab"] = "Zobacz";

$MLANG["tr"]["labels"]["tablabel"] = "Sayfan�n g�r�n�m�";
$MLANG["tr"]["labels"]["tabdescr"] = "G�ncel sayfan�n g�r�n�m�n� g�ster ve i�eri�in do�rudan d�zeltilmesine izin ver.";
$MLANG["tr"]["tabs"]["tab"] = "G�r�n�m";

$MLANG["fi"]["labels"]["tablabel"] = "N�yt� sivu";
$MLANG["fi"]["labels"]["tabdescr"] = "N�ytt�� valitun sivun ulkoasun ja voit suoraan muokata sis�lt��.";
$MLANG["fi"]["tabs"]["tab"] = "N�yt�";


$MCONF["script"]="frameset.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_view";

?>