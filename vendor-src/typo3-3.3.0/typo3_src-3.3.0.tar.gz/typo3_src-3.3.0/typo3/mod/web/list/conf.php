<?php
define("TYPO3_MOD_PATH", "mod/web/list/");
$BACK_PATH="";

$MLANG["default"]["labels"]["tablabel"] = "List of database-records";
$MLANG["default"]["tabs"]["tab"] = "List";
$MLANG["default"]["tabs_images"]["tab"] = "list.gif";
$MLANG["default"]["labels"]["tabdescr"] = "The Web>List module provides the most lowlevel access to the records one a page. While the other modules are mainly specialized in certain operations on certain database tables, this module provides ultimate access to the bare records available to a user.";

$MLANG["dk"]["labels"]["tablabel"] = "Liste over database-records";
$MLANG["dk"]["tabs"]["tab"] = "Liste";
$MLANG["dk"]["labels"]["tabdescr"] = "Modulet Web>Liste giver dig den mest grundliggende tilgang til databaseelementerne p� en side. Mens andre moduler hovedsagligt er specialiserede indenfor enkelte operationer p� enkelte databasetabeller, s� giver dette modul ultimativ adgang til de egentlige databaseelementer som er tilg�ngelige for en bruger.";

$MLANG["de"]["labels"]["tablabel"] = "Liste der Datens�tze";
$MLANG["de"]["tabs"]["tab"] = "Liste";
$MLANG["de"]["labels"]["tabdescr"] = "Das Web-Listen Modul bietet den grundlegensten Zugriff auf die Datens�tze einer Seite. W�hrend die anderen Module haupts�chlich mit bestimmten Operationen auf bestimmte Datens�tze spezialisiert sind, bietet dieses Modul den entscheidenen Zugriff auf die Datens�tze, die f�r den jeweiligen Benutzer zug�nglich sind.";

$MLANG["no"]["labels"]["tablabel"] = "Liste over database-records";
$MLANG["no"]["tabs"]["tab"] = "Liste";
$MLANG["no"]["labels"]["tabdescr"] = "Modulen Web>Liste gir den mest grunnleggende tilgangen til databaseelementene p� en side. Mens andre moduler hovedsakelig er spesialiserte for enkelte operasjoner p� enkelte databasetabeller, gir denne modulen ultimat  tilgang til de egentlige databaseelementene som er tilgjengelige for brukeren.";

$MLANG["it"]["labels"]["tablabel"] = "Lista dei records del database";
$MLANG["it"]["tabs"]["tab"] = "Lista";
$MLANG["it"]["labels"]["tabdescr"] = "Il modulo Web>Lista fornisce l'accesso pi� 'a basso livello' ai record di una pagina. Mentre gli altri moduli sono specializzati in determinate funzioni su certe tabelle del database, questo modulo fornisce l'accesso a tutti i record della pagina che l'utente pu� visualizzare.";

$MLANG["fr"]["labels"]["tablabel"] = "Liste des enregistrements de base de donn�es";
$MLANG["fr"]["tabs"]["tab"] = "Liste";
$MLANG["fr"]["labels"]["tabdescr"] = "Le module Web>Liste vous offre un contr�le de bas niveau de tous les �l�ments d'une page. Contrairement aux autres modules, plus sp�cialis�, celui-ci vous donne acc�s � un maximum d'informations.";

$MLANG["es"]["labels"]["tablabel"] = "Lista de registros";
$MLANG["es"]["tabs"]["tab"] = "Lista";
$MLANG["es"]["labels"]["tabdescr"] = "El m�dulo WebList provee del acceso a mas bajo nivel de los registros que forman una p�gina. En tanto que los otros m�dulos est�n especializados en cietas operaciones en ciertas tablas, este m�dulo permite el acceso total a los registros en crudo disponibles para el usuario.";

$MLANG["nl"]["labels"]["tablabel"] = "Lijst van databaserecords";
$MLANG["nl"]["labels"]["tabdescr"] = "De Web>Lijstmodule biedt de meest basale toegang tot de records in een pagina. Terwijl de andere modules voornamelijk gespecialiseerd zijn in bepaalde bewerkingen van databasetabellen, geeft deze module fundamentele toegang tot de records die beschikbaar zijn voor de gebruiker.";
$MLANG["nl"]["tabs"]["tab"] = "Lijst";

$MLANG["cz"]["labels"]["tablabel"] = "Seznam datab�zov�ch z�znam�";
$MLANG["cz"]["tabs"]["tab"] = "Seznam";
$MLANG["cz"]["labels"]["tabdescr"] = "Modul Web>Seznam poskytuje z�kladn� p��stup k z�znam�m na ka�d� stran�. Jin� moduly jsou specializov�ny zejm�na na ur�it� operace na ur�it�ch datab�zov�ch tabulk�ch, tento modul poskytuje p��m� p��stup k z�kladn�m z�znam�m dostupn�m u�ivateli.";

$MLANG["pl"]["labels"]["tablabel"] = "Lista zawarto�ci bazy";
$MLANG["pl"]["tabs"]["tab"] = "Lista";
$MLANG["pl"]["labels"]["tabdescr"] = "Modu� Web>Lista zapewnia dost�p niskiego poziomu do rekord�w zawartych na stronie. O ile inne modu�y pe�ni� wyspecjalizowane funkcje dotycz�ce konkretnych tablic, ten modu� umo�liwia dostep do wi�kszo�ci rekord�w dost�pnych dla u�ytkownika.";

$MLANG["si"]["labels"]["tablabel"] = "Seznam zapisov v bazi podatkov";
$MLANG["si"]["tabs"]["tab"] = "Seznam";

$MLANG["fi"]["labels"]["tablabel"] = "Luettelo tietokannan tietueista";
$MLANG["fi"]["labels"]["tabdescr"] = "Web-List moduli mahdollistaa alemman tason k�sittelun sivun tietueille. Kun muut modilit p��s��nt�isesti ovat erikoistuneet tiettyihin toimenpiteisiin tietyiss� tietokannan tauluissa, on t�ll� modulilla mahdollisuus ��rimm�isiin toimiin pelkill� tietueilla.";
$MLANG["fi"]["tabs"]["tab"] = "Luettelo";

$MLANG["tr"]["labels"]["tablabel"] = "Veritaban� kay�tlar�n�n listelenmesi";
$MLANG["tr"]["tabs"]["tab"] = "Liste";
$MLANG["tr"]["labels"]["tabdescr"] = "Web>Listesi mod�l� her sayfada bir kay�ta en d���k seviyede eri�im imkan� sa�lar.Di�er mod�ller belli veritaban� tablolar�ndaki belli uygulamalar i�in �zelle�tirilmi�ken, bu mod�l kullan�c�n�n eri�ebilmesine izin verilen t�m kay�tlara eri�ebilmesine imkan sa�lar.";


$MCONF["script"]="../../../db_list.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_list";

?>