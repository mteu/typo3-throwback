<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: Advanced functions
 *
 * Advanced Functions for manipulating the database
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
include ("locallang.php");
include_once(PATH_t3lib."class.t3lib_page.php");
include_once(PATH_t3lib."class.t3lib_htmlmail.php");
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");

$BE_USER->modAccess($MCONF,1);




// ***************************
// Script Classes
// ***************************
class importFileFunctions extends t3lib_basicFileFunctions	{
	function printMenu($kind, $ext)	{
		$content = "";		// If set, then this function returns content and not a menu
		
		switch($kind)	{
			case "clipboard":
					// Clipboard
				$output.= '<table border=0 cellpadding=0 cellspacing=0 width=460>';
				$output.= '<tr><td colspan=3 bgColor="'.$GLOBALS[doc]->bgColor5.'"><b>'.fw('CLIPBOARD').'</b></td></tr>';
				if (is_array($GLOBALS["HTTP_GET_VARS"][file]))	{
					reset($GLOBALS["HTTP_GET_VARS"][file]);
					while(list(,$fileref)=each($GLOBALS["HTTP_GET_VARS"][file]))	{
						$theFile = t3lib_div::split_fileref($fileref);
						if (!$theFile["file"])	{
							$dat = $this->dirData(t3lib_div::split_fileref(substr($fileref,0,-1)));
							$output.= '<tr><td colspan=3 valign=top>'.fw('<img src="'.$this->backPath.$dat[1].'" width=18 height=16 border=0 title="'.$theFile[file].'" align=top> '.$dat[0]).'</td></tr>';
							
							$files = $this->readDirectory($dat[2],$ext);
							if (is_array($files["file"]))	{
								$output.=$this->renderFileList($files["file"],'<img src="'.$this->backPath.'t3lib/gfx/ol/blank.gif" width=18 height=16 border=0 title="'.$theFile[file].'" align=top>');
							} else {
								$output.= '<tr><td colspan=3 valign=top>'.fw('<img src="'.$this->backPath.'t3lib/gfx/ol/blank.gif" width=18 height=16 border=0 title="'.$theFile[file].'" align=top> (No files with the extension: '.$ext.')').'</td></tr>';
							}							
						}
					}
					$singleFiles=array();
					reset($GLOBALS["HTTP_GET_VARS"][file]);
					while(list(,$fileref)=each($GLOBALS["HTTP_GET_VARS"][file]))	{
						$theFile = t3lib_div::split_fileref($fileref);
						if ($theFile["file"])	{
							if (!$ext || t3lib_div::inList($ext,$theFile["fileext"]))	{
								$singleFiles[]=$fileref;
							}
						}
					}
					$output.=$this->renderFileList($singleFiles);
				}

				$output.= '<tr><td colspan=3>&nbsp;</td></tr>';
				$output.= '<tr><td colspan=3 bgColor="'.$GLOBALS[doc]->bgColor4.'"><b>'.fw('<a href="#" onClick="readClipboard(\''.($this->script.'?id='.$this->id.'&source=clipboard').'\');">Click here to reload clipboard!</a>').'</b></td></tr>';
				$output.= '</table><BR>';
				
				if ($GLOBALS["HTTP_GET_VARS"]["SET"]["import_source"]=="clipboard" && !isset($GLOBALS["HTTP_GET_VARS"]["file"]))	{
					$output='<script language="javascript">readClipboard(\''.($this->script.'?id='.$this->id.'&source=clipboard').'\');</script>';
				}
			break;
			case "direct":
					// Direct Input
				$output.= '<table border=0 cellpadding=0 cellspacing=0 width=460>';
				$output.= '<tr><td bgColor="'.$GLOBALS[doc]->bgColor5.'"><b>'.fw('Direct Input').'</b></td></tr>';
				$output.= '<tr><td><textarea name="directInput"'.$GLOBALS["TBE_TEMPLATE"]->formWidthText().' rows=20 ></textarea><BR><input type="Submit" name="submit" value="Send Direct Input"></td></tr>';
				$output.= '</table>';			
			break;
			case "url":
					// URL
				$output.= '<table border=0 cellpadding=0 cellspacing=0 width=460>';
				$output.= '<tr><td colspan=3 bgColor="'.$GLOBALS[doc]->bgColor5.'"><b>'.fw('URL').'</b></td></tr>';
				$output.='<tr><td><img src="clear.gif" width=200 height=1></td><td><img src="clear.gif" width=20 height=1></td><td><img src="clear.gif" width=240 height=1></td></tr>';
				if ($GLOBALS["SOBE"]->MOD_SETTINGS["import_enteredURL"])	{
					$parts=parse_url($GLOBALS["SOBE"]->MOD_SETTINGS["import_enteredURL"]);
					if ($parts["scheme"] && $parts["host"])	{
						if (!$parts["path"] || substr($parts["path"],-1)=="/")	{
							$res = $this->getURLDirectory($GLOBALS["SOBE"]->MOD_SETTINGS["import_enteredURL"], $ext);
							if (is_array($res))	{
								if (!count($res))	{
									$output.= '<tr><td colspan=3 valign=top>'.fw('No files with the extension: '.$ext).'</td></tr>';
								} else {
									if (is_array($res[dir]))	{
										while(list(,$dir)=each($res[dir]))	{
											if (!strpos(".".$GLOBALS["SOBE"]->MOD_SETTINGS["import_enteredURL"],$dir))	{
												$name='<B>'.basename($dir).'</B>';
												$info= "";
												$img = "";
												$output.='<tr><td colspan=3 valign=top>'.fw('<img src="'.$this->backPath.'gfx/fileicons/folder.gif" width=18 height=16 border=0 title="'.htmlspecialchars($dir).'" align=top>'.$name).'</td></tr>';
											}
										}
										$output.='<tr><td colspan=3 valign=top>&nbsp;</td></tr>';
									}
									if (is_array($res[file]))	{
										while(list(,$values)=each($res[file]))	{
											$a_tag='<a href="'.$this->script.'?id='.$this->id.'&importFile='.rawurlencode($values["file"]).'">';
											$name=$a_tag.'<B>'.basename($values["file"]).'</B></a>';
											$info= $values["info"]? "<BR>".nl2br(trim($GLOBALS["LANG"]->sL(t3lib_div::getURL($values["info"])))):"";
											$img = $values["icon"]? $a_tag.'<img src="'.$values["icon"].'" title="Preview image.'.chr(10).'Click to import file \''.basename($values["file"]).'\'" border=0></a>' :"";
											$output.='<tr><td valign=top>'.fw($name.$info).'</td><td></td><td valign=top>'.$img.'</td></tr>';
										}
									}
//									debug($res);
								}
							}
						}
					}
				}
		
				$output.= '<tr><td colspan=3><BR><nobr><input name="SET[import_enteredURL]"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(30).' value="'.htmlspecialchars($GLOBALS["SOBE"]->MOD_SETTINGS["import_enteredURL"]).'"> &nbsp; <input type="Submit" name="submit" value="Set URL"></nobr></td></tr>';
				$output.= '</table><BR>';			
			break;
			default:
					// Temp folder
				$path = $this->findTempFolder();
				if ($path)		{
					$files = $this->readDirectory($path,$ext);
					$output.= '<table border=0 cellpadding=0 cellspacing=0 width=460>';
					$output.= '<tr><td colspan=3 bgColor="'.$GLOBALS[doc]->bgColor5.'"><b>'.fw('TEMP-folder:').'</b></td></tr>';
					if (is_array($files["file"]))	{
						$output.=$this->renderFileList($files["file"]);
					} else {
						$output.= '<tr><td colspan=3 valign=top>'.fw('No files with the extension: '.$ext).'</td></tr>';
					}
					$output.= '</table><BR>';
				}
			break;
		}

		return $output;
	}
	function renderFilelist($arr,$iconPrefix="")	{
		reset($arr);
		while(list(,$fileref)=each($arr))	{
			$theFile = t3lib_div::split_fileref($fileref);
			$ext = $theFile["fileext"];
			$icon = t3lib_BEfunc::getFileIcon($ext);
			$output.= '<tr><td valign=top>'.fw($iconPrefix.'<a href="'.$this->script.'?id='.$this->id.'&importFile='.rawurlencode($fileref).'"><img src="'.$this->backPath.'gfx/fileicons/'.$icon.'" width=18 height=16 border=0 title="'.$theFile[file].'" align=top> '.$theFile[file].'</a>').'</td><td>'.fw(t3lib_div::formatSize(@filesize($theFile[path].$theFile[file]))).'</td><td>'.fw(t3lib_BEfunc::datetime(@filectime($theFile[path].$theFile[file]))).'</td></tr>';
		}
		return $output;
	}
	function dirData($theFile)	{
			// Returns some data specific for the directories...
			// THIS FUNCTION IS AN EXACT COPY OF THE ONE IN typo3/file_list.php (01-12-2000)
		$path = $theFile[path].$theFile[file]."/";
		$webpath=t3lib_BEfunc::getPathType_web_nonweb($path);

		$title=$theFile[file];
		$icon = 'gfx/i/_icon_'.$webpath.'folders.gif';
		if ($title=="_temp_")	{
			$icon = 'gfx/i/sysf.gif';
			$title="<b>TEMP</b>";
		}
		if ($title=="_recycler_")	{
			$icon = 'gfx/i/recycler.gif';
			$title="<b>RECYCLER</b>";
		}
		$icon = $theFile["writable"] ? "gfx/i/_icon_".$webpath."folders_ro.gif" : $icon;
		return Array($title,$icon,$path);
	}

	function readDirectory($path,$ext)	{
		$path = $this->is_directory($path);	// Cleaning name...
		$type="file";
		if($path && $this->checkPathAgainstMounts($path."/"))	{
			$d = @dir($path);
			$tempArray=Array();
			if (is_object($d))	{
				while($entry=$d->read()) {
					if ($entry!="." && $entry!="..")	{
						$wholePath = $path."/".$entry;		// Because of odd PHP-error where  <BR>-tag is sometimes placed after a filename!!
						if (@file_exists($wholePath) && (!$type || filetype($wholePath)==$type))	{
							$fI = t3lib_div::split_fileref($wholePath);
							if (!$ext || t3lib_div::inList($ext,$fI["fileext"]))	{
								$tempArray["file"][] = $wholePath;
							}
						}
					}
				}
				$d->close();
			}
		}
		return $tempArray;
	}

	function getURLDirectory($URL,$ext)	{
		$tempArray = array();
		$analyse = t3lib_div::makeInstance("t3lib_htmlmail");
		$get = $analyse->fetchHTML($URL);
		if ($get)	{
			if ($analyse->extractFramesInfo())	{
				debug ("Document was a frameset. Stopped");
			} else {
				$analyse->extractMediaLinks();
				$analyse->extractHyperLinks();

				$mediaInfList=Array();
				if (is_array($analyse->theParts["html"]["hrefs"]))	{
					reset($analyse->theParts["html"]["hrefs"]);
					while(list(,$values)=each($analyse->theParts["html"]["hrefs"]))	{
						$mediaInfList[]=strtolower($values["absRef"]);
					}
				}
				if (is_array($analyse->theParts["html"]["media"]))	{
					reset($analyse->theParts["html"]["media"]);
					while(list(,$values)=each($analyse->theParts["html"]["media"]))	{
						$mediaInfList[]=strtolower($values["absRef"]);
					}
				}
				if (is_array($analyse->theParts["html"]["hrefs"]))	{
					reset($analyse->theParts["html"]["hrefs"]);
					while(list(,$values)=each($analyse->theParts["html"]["hrefs"]))	{
						$newParts = parse_url($values["absRef"]);
						if (!trim($newParts["query"]))	{
							$fI = t3lib_div::split_fileref($newParts["path"]);
							if ($fI[file])	{
								if (!$ext || t3lib_div::inList($ext,$fI["fileext"]))	{
									$noExt = strtolower(ereg_replace("[^\.]*$","",$values["absRef"]));
									$info="";
									$icon="";
									if (t3lib_div::inArray($mediaInfList,$noExt."inf"))	{
										$info=$noExt."inf";
									}
									if (t3lib_div::inArray($mediaInfList,$noExt."gif"))	{
										$icon=$noExt."gif";
									}
									$tempArray["file"][] = array("file"=>$values["absRef"], "info"=>$info, "icon"=>$icon);
								}
							} else {
								$tempArray["dir"][] = $values["absRef"];
							}
						}
					}
				}
			}
		}
		return $tempArray;
	}
	function readUrl($URL,$ext)	{
		$parts = parse_url($URL);
		if ($parts["scheme"]&&$parts["host"])	{
			if (!$parts["path"] || substr($parts["path"],-1)=="/")	{
			} else {
				if($fd = @fopen($URL,"r"))	{
					$content = "";
					$c=0;
					$error=0;
					while (!feof($fd))	{
						$content.=fread($fd, 5000);
						$c++;
						if ($c > 1000)	{
							$error=1;
							break;
						}
					}
					fclose($fd);
				}
				if ($error)	{
					debug("Error: Document greater than 5 MB");
				} else {
					return $content;
				}
			}
		}
	}
}
class SC_mod_web_func_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $include_once=array();
	
	var $content;
	var $perms_clause;
	var $modTSconfig;
	var $CMD;
	var $pageinfo;
	var $fileProcessor;
	var $id;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];
		$this->id = intval(t3lib_div::GPvar("id"));

		$this->CMD = t3lib_div::GPvar("CMD");
		$this->perms_clause = $BE_USER->getPagePermsClause(1);
		
		$this->menuConfig();

			// Includes:
		switch($this->MOD_SETTINGS["function"])	{
			case 1:
				if ($this->MOD_SETTINGS["import_function"]=="extHtml")	{
					$this->include_once[] = "class.existingHTMLimport.php";
				} else {
					$this->include_once[] = "class.import.php";
				}
			break;	// end of import
			case 2:
				$this->include_once[] = "class.export.php";
			break;
			case 3:
				$this->include_once[] = PATH_t3lib."class.t3lib_tcemain.php";
			break;
		}

	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->MOD_MENU = array(
				// Top level:
			"function" => array(
	//			0 => $LANG->getLL("menu_0"),	// [SELECT FUNCTION]
				1 => $LANG->getLL("menu_1"),
//				2 => $LANG->getLL("menu_2"),
				3 => $LANG->getLL("menu_3")
			),
	
				// IMPORT:
			"import_function" => array(
				0 => "[ SELECT TYPE ]",
//				"trd" => "Typo Record Document (.trd)",
//				"csv" => "Comma Separated Values (.csv)",
				"txt" => "Import Text (.txt)",
//				"extHtml" => "Import Existing Site"
			),
			"import_txt_format" => array(
				0 => "Plain",
				1 => htmlspecialchars("---new_page---/---new_section---")
			),
			"import_source" => array(
	//			0 => "TEMP Folder",
//				"upload" => "Upload",
//				"clipboard" => "Clipboard",
//				"url" => "URL",
				"direct" => "Direct Input"
			),
			"import_enteredURL" => "",
			"import_txt_trimWhiteSpace" => "",
	
	
				// EXPORT
			"export_function" => array(
				0 => "[ SELECT TYPE ]",
				"trd" => "Typo Record Document (.trd)",
				"xml" => "XML (.xml)",
				"csv" => "Comma Separated Values (.csv)"
			),
			"export_source" => array(
				0 => "[ SELECT SOURCE ]",
				"clipboard" => "Current page",
				"clipboard" => "Clipboard",
				"clipboard" => "SQL query"
			),
			"export_destination" => array(
				0 => "TEMP Folder",
				"file" => "Download File"
			),
			"export_filename" => "",
			"csv_separator" => array(
				0 => ",",
				1 => ";",
				2 => ":",
				1 => "TAB"
			),
			
				// Wizards:
			"wiz" => array(
				"sort" => $LANG->getLL("wiz_sort"),
				"crMany" => $LANG->getLL("wiz_crMany")
			)
		);

			// page/be_user TSconfig settings and blinding of menu-items
		$this->modTSconfig = t3lib_BEfunc::getModTSconfig($this->id,"mod.".$this->MCONF["name"]);
		$this->MOD_MENU["function"] = t3lib_BEfunc::unsetMenuItems($this->modTSconfig["properties"],$this->MOD_MENU["function"],"menu.function");
		
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"]);
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $FILEMOUNTS;
		
		$this->fileProcessor = t3lib_div::makeInstance("importFileFunctions");
		$this->fileProcessor->init($FILEMOUNTS, $TYPO3_CONF_VARS["BE"]["fileExtensions"]);
		$this->fileProcessor->script = "index.php";
		$this->fileProcessor->id = $this->id;
		$this->fileProcessor->backPath = $BACK_PATH;
		
/*		if (isset($SET["export_filename"]))	{
			$SET["export_filename"] = $this->fileProcessor->cleanFileName($SET["export_filename"]);
		}
	*/		
		
		
		// Access check...
		// The page will show only if there is a valid page and if this page may be viewed by the user
		$this->pageinfo = t3lib_BEfunc::readPageAccess($this->id,$this->perms_clause);
		$access = is_array($this->pageinfo) ? 1 : 0;
		
		
		// **************************
		// Main
		// **************************
		if ($this->id && $access)	{
			$this->doc = t3lib_div::makeInstance("mediumDoc");
			$this->doc->backPath = $BACK_PATH;
		
				// JavaScript
			$this->doc->JScode = '
<script>
	script_ended = 0;
	function jumpToUrl(URL)	{
//		alert(URL);
		document.location = URL;
	}

	function getClipbrd()	{
		var clipBrd = top.clipBrd;
		var result="";
		if (clipBrd.bankCount[clipBrd.pad])	{
			for (var i = 0; i < clipBrd.bankCount[clipBrd.pad]; i++) {
				var item = clipBrd.bank[clipBrd.pad][i+1];
				if (item && item.act)	{
					switch(item.type)	{
						case "db":
							result+= "&data["+item.table+"][]="+item.uid;
						break;
						case "file":
							result+= "&file[]="+top.rawurlencode(item.fullpath);
						break;
					}
				}
			}
		}
		return result;
	}	
	function readClipboard(theUrl)	{
		document.location = theUrl+getClipbrd();
	}	
</SCRIPT>
			';
			
			$this->doc->postCode='
<script language="javascript">
	script_ended = 1;
	if (top.theMenu) top.theMenu.recentuid = '.intval($this->id).';
</script>
			';
			$this->doc->form='<form action="index.php" method="POST"><input type="hidden" name="id" value="'.$this->id.'">';

			$headerSection = $this->doc->getHeader("pages",$this->pageinfo,$this->pageinfo["_thePath"]).'<br>'.$LANG->php3Lang["labels"]["path"].': '.t3lib_div::fixed_lgd_pre($this->pageinfo["_thePath"],50);
		
				// Draw the header.
			$this->content.=$this->doc->startPage($LANG->getLL("title"));
			$this->content.=$this->doc->header($LANG->getLL("title"));
			$this->content.=$this->doc->spacer(5);
			$this->content.=$this->doc->section('',$this->doc->funcMenu($headerSection,t3lib_BEfunc::getFuncMenu($this->id,"SET[function]",$this->MOD_SETTINGS["function"],$this->MOD_MENU["function"])));
			$this->content.=$this->doc->divider(5);
		
		
		
		
		
		
		// Main menu:
			$theOutput="";
		//	$menu = $LANG->php3Lang["labels"]["menu"]." ".t3lib_BEfunc::getFuncMenu($this->id,"SET[function]",$this->MOD_SETTINGS["function"],$this->MOD_MENU["function"]);
		//	$menu.= "&nbsp;";
			switch($this->MOD_SETTINGS["function"])	{
				case 1:
					$menu.= "Type: ".t3lib_BEfunc::getFuncMenu($this->id,"SET[import_function]",$this->MOD_SETTINGS["import_function"],$this->MOD_MENU["import_function"]);
				break;			
				case 2:
					$menu.= "Type: ".t3lib_BEfunc::getFuncMenu($this->id,"SET[export_function]",$this->MOD_SETTINGS["export_function"],$this->MOD_MENU["export_function"]);
				break;			
				case 3:
					$menu.= $LANG->getLL("wiz_lWizards").": ".t3lib_BEfunc::getFuncMenu($this->id,"SET[wiz]",$this->MOD_SETTINGS["wiz"],$this->MOD_MENU["wiz"]);
				break;			
			}
			$theOutput.=$this->doc->section("",'<NOBR>'.$menu.'</NOBR>');
			$this->content.=$theOutput;	
			$this->content.=$this->doc->spacer(5);
		
		
		
		
			$theOutput="";
			switch($this->MOD_SETTINGS["function"])	{
				case 1:
					if ($this->MOD_SETTINGS["import_function"]=="extHtml")	{
						$incObj = t3lib_div::makeInstance("existingHTMLimport");
					} else {
						$incObj = t3lib_div::makeInstance("import");
					}
					$theOutput = $incObj->main();
				break;	// end of import
				case 2:
					$incObj = t3lib_div::makeInstance("export");
					$theOutput = $incObj->main();
				break;
				case 3:
					$theOutput=$this->main_pages();
				break;
			}
			$this->content.=$theOutput;	
		
		
			
			
			// ShortCut
			if ($BE_USER->mayMakeShortcut())	{
				$this->content.=$this->doc->spacer(20).$this->doc->section('',$this->doc->makeShortcutIcon("id","function,wiz,import_function,export_function",$this->MCONF["name"]));
			}
			
			$this->content.=$this->doc->spacer(10);
		} else {
				// If no access or if ID == zero
		
			$this->doc = t3lib_div::makeInstance("mediumDoc");
			$this->doc->backPath = $BACK_PATH;
		
			$this->content.=$this->doc->startPage($LANG->getLL("title"));
			$this->content.=$this->doc->header($LANG->getLL("title"));
			$this->content.=$this->doc->section("","<BR>".$LANG->getLL("clickAPage_content"),0,1);
			$this->content.=$this->doc->spacer(5);
			$this->content.=$this->doc->spacer(10);
		}
	}
	function printContent()	{
		global $SOBE;

		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}



	function main_pages()	{
		global $SOBE,$LANG;
	
		$theCode="";
		switch($this->MOD_SETTINGS["wiz"])	{
			case "sort":
					// check if user has modify permissions to 
				$sys_pages = t3lib_div::makeInstance("t3lib_pageSelect");
				$sortByField = t3lib_div::GPvar("sortByField");
				if ($sortByField)	{
					$menuItems=array();
					if (t3lib_div::inList("title,subtitle,crdate,tstamp",$sortByField))	{
						$menuItems = $sys_pages->getMenu($this->id,"uid,pid,title",$sortByField);
					} elseif ($sortByField=="REV") {
						$menuItems = $sys_pages->getMenu($this->id,"uid,pid,title");
						$menuItems = array_reverse($menuItems);
					}
					if (count($menuItems))	{
						$tce = t3lib_div::makeInstance("t3lib_TCEmain");
						$menuItems = array_reverse($menuItems);
						$cmd=array();
						reset($menuItems);
						while(list(,$r)=each($menuItems))	{
							$cmd["pages"][$r["uid"]]["move"]=$this->id;
						}
						$tce->start(array(),$cmd);
						$tce->process_cmdmap();
						t3lib_BEfunc::getSetUpdateSignal("updatePageTree");
					}
				}
	
					//
				$menuItems = $sys_pages->getMenu($this->id);
				reset($menuItems);
				$lines=array();
					$lines[]= '<tr>
						<td bgColor="'.$this->doc->bgColor5.'"><B>'.fw($this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_title"),"title")).'</B></td>
						<td bgColor="'.$this->doc->bgColor5.'"><B>'.fw($this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_subtitle"),"subtitle")).'</B></td>
						<td bgColor="'.$this->doc->bgColor5.'"><B>'.fw($this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_tChange"),"tstamp")).'</B></td>
						<td bgColor="'.$this->doc->bgColor5.'"><B>'.fw($this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_tCreate"),"crdate")).'</B></td>
						</tr>';
				while(list(,$rec)=each($menuItems))	{
					$m_perms_clause = $GLOBALS["BE_USER"]->getPagePermsClause(2);	// edit permissions for that page!
					$pRec = t3lib_BEfunc::getRecord ("pages",$rec["uid"],"uid"," AND ".$m_perms_clause);
					$lines[]= '<tr><td nowrap>'.t3lib_iconWorks::getIconImage("pages",$rec,$GLOBALS["BACK_PATH"],'align=top '.t3lib_BEfunc::titleAttribForPages($rec)).
						(!is_array($pRec)?rfw('<B>'.$LANG->getLL("wiz_W").'</B> '):'').
						fw(htmlspecialchars(t3lib_div::fixed_lgd($rec["title"],$GLOBALS["BE_USER"]->uc["titleLen"]))."&nbsp;").'</td>
						<td nowrap>'.fw(htmlspecialchars(t3lib_div::fixed_lgd($rec["subtitle"],$GLOBALS["BE_USER"]->uc["titleLen"]))."&nbsp;").'</td>
						<td nowrap>'.fw(t3lib_Befunc::datetime($rec["tstamp"])."&nbsp;&nbsp;").'</td>
						<td nowrap>'.fw(t3lib_Befunc::datetime($rec["crdate"])."&nbsp;&nbsp;").'</td>
						</tr>';
				}
				
				$theCode.= '<B>'.$LANG->getLL("wiz_currentPageOrder").':</B><BR><BR>
				<table border=0 cellpadding=0 cellspacing=0>'.implode("",$lines).'</table><BR>';
	
				if (count($menuItems))	{
						// Menu:
					$lines=array();
					$lines[] = $this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_title"),"title");
					$lines[] = $this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_subtitle"),"subtitle");
					$lines[] = $this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_tChange"),"tstamp");
					$lines[] = $this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_tCreate"),"crdate");
					$lines[] = "";
					$lines[] = $this->wiz_linkOrder($LANG->getLL("wiz_changeOrder_REVERSE"),"REV");
					$theCode.= '<B>'.$LANG->getLL("wiz_changeOrder").':</B><BR><BR>'.implode("<BR>",$lines);
				}			
			break;
			case "crMany":
				$m_perms_clause = $GLOBALS["BE_USER"]->getPagePermsClause(8);	// create new pages here?
				$pRec = t3lib_BEfunc::getRecord ("pages",$this->id,"uid"," AND ".$m_perms_clause);
				$sys_pages = t3lib_div::makeInstance("t3lib_pageSelect");
				$menuItems = $sys_pages->getMenu($this->id);
				if (is_array($pRec))	{
					$data = t3lib_div::GPvar("data");
					if (is_array($data["pages"]))	{
						if (t3lib_div::GPvar("createInListEnd"))	{
							$endI = end($menuItems);
							$thePid = -intval($endI["uid"]);
							if (!$thePid)	$thePid = $this->id;
						} else {
							$thePid = $this->id;
						}
		//				debug($thePid);
							// Save
		//				reset($data["pages"]);
						while(list($k,$dat)=each($data["pages"]))	{
							if (!trim($dat["title"]))	{
								unset($data["pages"][$k]);
							} else {
								$data["pages"][$k]["pid"]=$thePid;
								$data["pages"][$k]["hidden"] = t3lib_div::GPvar("hidePages") ? 1 : 0;
							}
						}
						if (count($data["pages"]))	{
							reset($data);
							$tce = t3lib_div::makeInstance("t3lib_TCEmain");
							$tce->reverseOrder=1;
							$tce->start($data,array());
							$tce->process_datamap();
							t3lib_BEfunc::getSetUpdateSignal("updatePageTree");
						} else {
							$theCode.=rfw($LANG->getLL("wiz_newPages_noCreate")."<BR><BR>");
						}
	//						debug($data);
						
							// Display result:
						$menuItems = $sys_pages->getMenu($this->id);
						reset($menuItems);
						$lines=array();
						while(list(,$rec)=each($menuItems))	{
							$lines[]= '<nobr>'.t3lib_iconWorks::getIconImage("pages",$rec,$GLOBALS["BACK_PATH"],'align=top '.t3lib_BEfunc::titleAttribForPages($rec)).
								htmlspecialchars(t3lib_div::fixed_lgd($rec["title"],$GLOBALS["BE_USER"]->uc["titleLen"])).'</nobr>';
						}
						$theCode.= '<B>'.$LANG->getLL("wiz_newPages_currentMenu").':</B><BR><BR>'.implode("<BR>",$lines);
					} else {
							// Display create form:
						$lines=array();
						for ($a=0;$a<9;$a++)	{
							$lines[]=$LANG->getLL("wiz_newPages_page").' '.($a+1).': <input type="text" name="data[pages][NEW'.$a.'][title]"'.$this->doc->formWidth(35).'>';
						}
						
						$theCode.= '<B>'.$LANG->getLL("wiz_newPages").':</B><BR><BR>'.implode("<BR>",$lines).
						'<BR><BR>
						<input type="checkbox" name="createInListEnd" value="1">'.$LANG->getLL("wiz_newPages_listEnd").'<BR>
						<input type="checkbox" name="hidePages" value="1">'.$LANG->getLL("wiz_newPages_hidePages").'<BR>
						<input type="submit" name="create" value="'.$LANG->getLL("wiz_newPages_lCreate").'" onClick="return confirm(unescape(\''.rawurlencode($GLOBALS["LANG"]->getLL("wiz_newPages_lCreate_msg1")).'\'))"> <input type="Reset" value="'.$LANG->getLL("wiz_newPages_lReset").'">';
						
							// Help text:
						if ($GLOBALS["BE_USER"]->uc["helpText"])	{
							$theCode.= '<BR><BR>'.$this->helpBubble().$LANG->getLL("wiz_newPages_helpText");
						}
					}
				} else {
					$theCode.=rfw($LANG->getLL("wiz_newPages_errorMsg1"));
				}
			break;
		}
		
		$out=$this->doc->section($LANG->getLL("wiz_".$this->MOD_SETTINGS["wiz"]),$theCode,0,1);
		return $out;
	}	
	function wiz_linkOrder($title,$order)	{
		return '&nbsp; &nbsp;<a href="index.php?id='.$GLOBALS["SOBE"]->id.'&sortByField='.$order.'" onClick="return confirm(unescape(\''.rawurlencode($GLOBALS["LANG"]->getLL("wiz_changeOrder_msg1")).'\'))">'.$title.'</a>';
	}
	function helpBubble()	{
		return '<img src="'.$GLOBALS["BACK_PATH"].'gfx/helpbubble.gif" width="14" height="14" hspace=2 align=top'.$this->doc->helpStyle().'>';
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/func/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/func/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_web_func_index");
$SOBE->init();

// Include files?
reset($SOBE->include_once);	
while(list(,$INC_FILE)=each($SOBE->include_once))	{include_once($INC_FILE);}

$SOBE->main();
$SOBE->printContent();
?>