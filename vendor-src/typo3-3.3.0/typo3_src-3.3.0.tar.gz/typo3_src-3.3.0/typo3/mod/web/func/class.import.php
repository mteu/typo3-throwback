<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: Func / Import
 *
 * Include-file
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class import {

	function cleanEnds($string)	{
		$parts = explode(chr(10),$string);
		if (!trim($parts[(count($parts)-1)]))	unset($parts[(count($parts)-1)]);
		if (!trim($parts[0]))	unset($parts[0]);
		return implode($parts,chr(10));
	}
	function main() {
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$extension = $GLOBALS["SOBE"]->MOD_SETTINGS["import_function"];
		if (isset($HTTP_POST_VARS["directInput"]) || $HTTP_GET_VARS["importFile"])	{
		
		//	$theOutput.=$SOBE->doc->section("IMPORT:", $HTTP_POST_VARS["directInput"].$HTTP_GET_VARS["importFile"]);
		
			$sourceData = stripslashes($HTTP_POST_VARS["directInput"]);
			$theData = Array();	
			switch($GLOBALS["SOBE"]->MOD_SETTINGS["import_txt_format"])	{
				case 0:
					if ($GLOBALS["SOBE"]->MOD_SETTINGS["import_txt_trimWhiteSpace"])	{$sourceData = trim($sourceData);}
					$pageKey=$SOBE->id;
					$theData[$pageKey][uniqid("NEW")]["bodytext"]=$sourceData;
				break;
				case 1:
					$pages = split(sql_regcase("---new_page---"), $sourceData);
					
					while(list($theKey,$theVal)=each($pages))	{
						if (trim($theVal))	{
							if ($theKey)	{	// If $theKey, then it's a new page. Otherwise it's the current page
								$pageKey = uniqid("NEW");
							} else {
								$pageKey=$SOBE->id;
							}
							$sections = split(sql_regcase("---new_section---"), $theVal);
		//					debug($sections);
							while(list($c,$theContent)=each($sections))	{
								$secId = uniqid("NEW");
								$theContent=$this->cleanEnds($theContent);
								if ($GLOBALS["SOBE"]->MOD_SETTINGS["import_txt_trimWhiteSpace"])	{$theContent = trim($theContent);}
								if ($theKey && !$c)	{	// A new page-header is created.
									$parts = split(chr(10),$theContent,3);
									$theData[$pageKey]["title"]=trim($parts[0]) ? trim($parts[0]) : "[NO TITLE]";
									$theData[$pageKey]["subtitle"]=trim($parts[1]);
										// If there are more than the two lines, then a new section is created by setting the content-var again
									if (trim($parts[2]))	{
										$theContent=  $GLOBALS["SOBE"]->MOD_SETTINGS["import_txt_trimWhiteSpace"] ? trim($parts[2]) : $parts[2];
										$theContent= chr(10).$theContent;	// The header is set to "" by adding a single linebreak...
									} else {
										$theContent="";
									}
								}
								if (trim($theContent)) {
									$parts = split(chr(10),$theContent,2);
										// If the first line is longer than (80) chars, then it's regarded a part of the content.
									if (strlen($parts[0])>80)	{
										$parts[1]=$parts[0].chr(10).$parts[1];
										$parts[0]="";
									}
											// Prependes "http://" and "mailto:" to all webadresses starting with www and all email-adresses.
									$parts[1]=" ".$parts[1];	// Add space in the beginning (because of the regexes...
									$parts[1]=ereg_replace("([ ".chr(10).chr(13)."])(".sql_regcase("www")."\.)","\\1http://\\2",$parts[1]);
									$parts[1]=ereg_replace("([ ".chr(10).chr(13)."])([^ ]*@)","\\1mailto:\\2",$parts[1]);
									$parts[1]=substr($parts[1],1);	// Strip the space in the beginning.
											// If a paragraph starts with "-" then it's regarded as a quote and set in italics
									$lines = explode(chr(10),$parts[1]);
									while(list($a,$b)=each($lines))	{
										if (substr(trim($b),0,1)=="-")	{
											$lines[$a]='<i>'.$lines[$a].'</i>';
										}
									}
									$parts[1]=implode($lines,chr(10));
											// putting the content
									$theData[$pageKey][$secId]["header"]=$parts[0];
									$theData[$pageKey][$secId]["bodytext"]=$parts[1];
								}
							}
						}
					}
				break;
			}
		
			
		
			$output = "";
			reset($theData);
			while(list($key,$val)=each($theData))	{
				$output.="<HR><b>PAGE: ".$key."</b><BR>";
				if (!t3lib_div::testInt($key))	{
					$output.='<input type="hidden" name="data[pages]['.$key.'][pid]" value="'.$GLOBALS["SOBE"]->pageinfo["uid"].'">';
					$output.='<input type="hidden" name="data[pages]['.$key.'][hidden]" value="0">';
					$output.='Title:<BR><input type="text" size=50 name="data[pages]['.$key.'][title]" value="'.htmlspecialchars($val["title"]).'"><BR>';
					$output.='Subtitle:<BR><input type="text"'.$GLOBALS["TBE_TEMPLATE"]->formWidth().' name="data[pages]['.$key.'][subtitle]" value="'.htmlspecialchars($val["subtitle"]).'"><BR>';
				}
				while(list($theSectionKey,$theSectionVal)=each($val))	{
					if (strstr($theSectionKey,"NEW"))	{
						$output.='<input type="hidden" name="data[tt_content]['.$theSectionKey.'][pid]" value="'.$key.'">';
						$output.='Header:<BR><input type="text"'.$GLOBALS["TBE_TEMPLATE"]->formWidth().' name="data[tt_content]['.$theSectionKey.'][header]" value="'.htmlspecialchars($theSectionVal[header]).'"><BR>';
						$output.='Bodytext:<BR><textarea'.$GLOBALS["TBE_TEMPLATE"]->formWidthText().' rows=6 name="data[tt_content]['.$theSectionKey.'][bodytext]">'.t3lib_div::formatForTextarea($theSectionVal[bodytext]).'</textarea><BR>';
					}
				}
			}
		
		
			$output='</form><form action="'.$BACK_PATH.'tce_db.php" method="POST" name="editform">'.$output;
			$output.='<input type="Submit" name="submit" value="SAVE"><input type="hidden" name="flags[reverseOrder]" value="1">';
//			$output.='<input type="Hidden" name="redirect" value="status.php?JScommand='.rawurlencode("top.modPane_web.click('modPane_web_list'); top.buttons['refresh_web'].click();").'">';
			$output.='<input type="Hidden" name="redirect" value="'.htmlspecialchars(t3lib_div::linkThisUrl(getenv("REQUEST_URI"),array("id"=>$SOBE->id))).'">';
			$output.='&nbsp;&nbsp;<input type="Submit" value="Abort" onClick="jumpToUrl(\'index.php?id='.$SOBE->id.'\'); return false;">';
		
			$theOutput.=$SOBE->doc->section("Edit:",$output);	
		} else {
			switch($extension)	{
				case "trd":
				break;
				case "csv":
				break;
				case "txt":
					$Nmenu=array();
					$Nmenu[]= array(fw("Format:"), t3lib_BEfunc::getFuncMenu($SOBE->id,"SET[import_txt_format]",$GLOBALS["SOBE"]->MOD_SETTINGS["import_txt_format"],$GLOBALS["SOBE"]->MOD_MENU["import_txt_format"]));
		
					$Nmenu[]= array(fw("Trim whitespace:"),t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[import_txt_trimWhiteSpace]",$GLOBALS["SOBE"]->MOD_SETTINGS["import_txt_trimWhiteSpace"]));
					
					$theOutput.=$SOBE->doc->section("Select options:",$SOBE->doc->menuTable($Nmenu));
					$theOutput.=$SOBE->doc->divider(5);
				break;
				default:
					$extension = "";
				break;
			}
		
			if ($extension)	{
				$Nmenu= "Source: ".t3lib_BEfunc::getFuncMenu($SOBE->id,"SET[import_source]",$GLOBALS["SOBE"]->MOD_SETTINGS["import_source"],$GLOBALS["SOBE"]->MOD_MENU["import_source"]);
				$theOutput.=$SOBE->doc->section("Select file source:",'<NOBR>'.$Nmenu.'</NOBR><BR><BR>'.$GLOBALS["SOBE"]->fileProcessor->printMenu($GLOBALS["SOBE"]->MOD_SETTINGS["import_source"],$extension));
			}
		}
		return $theOutput;
	}
}


// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/func/class.import.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/func/class.import.php"]);
}

?>