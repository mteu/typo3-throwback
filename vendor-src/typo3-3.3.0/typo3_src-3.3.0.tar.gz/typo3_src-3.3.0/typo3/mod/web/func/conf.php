<?php
define("TYPO3_MOD_PATH", "mod/web/func/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Advanced functions";
$MLANG["default"]["tabs"]["tab"] = "Functions";
$MLANG["default"]["tabs_images"]["tab"] = "func.gif";
$MLANG["default"]["labels"]["tabdescr"] = "You'll find general export and import functions here. In addition this module contains specialized functions - wizards - usefull in specific situations. For instance you can batch create pages and perform sorting of pages.";

$MLANG["dk"]["labels"]["tablabel"] = "Avancerede funktioner";
$MLANG["dk"]["tabs"]["tab"] = "Funktioner";
$MLANG["dk"]["labels"]["tabdescr"] = "Her vil du finde generelle eksport og import funktioner. Derudover indeholder dette modul specialiserede funktioner - guider - som er nyttige i s�rlige situationer. For eksempel kan du oprette mange sider i �n arbejdsgang og udf�re sortering af sider.";

$MLANG["de"]["labels"]["tablabel"] = "Erweiterte Funktionen";
$MLANG["de"]["labels"]["tabdescr"] = "Hier finden Sie allgemeine Export- und Importfunktionen. Zus�tzlich enth�lt dieses Modul spezielle Funktionen (Assistenten), welche in bestimmten Situationen sehr n�tzlich sind. Zum Beispiel k�nnen Seiten automatisiert angelegt und auch umsortiert werden.";
$MLANG["de"]["tabs"]["tab"] = "Funktionen";

$MLANG["no"]["labels"]["tablabel"] = "Avanserte funksjoner";
$MLANG["no"]["labels"]["tabdescr"] = "Her finner du generelle eksport og import funksjoner. Videre inneholder modulen spesielle funksjoner ' guider ' som vil v�re nyttige i spesielle tilfeller. For eksempel kan du opprette mange sider i en operasjon og utf�re sortering av sidene.";
$MLANG["no"]["tabs"]["tab"] = "Funksjoner";

$MLANG["it"]["labels"]["tablabel"] = "Funzioni avanzate";
$MLANG["it"]["labels"]["tabdescr"] = "Nel modulo sono presenti funzioni per importare / esportare pagine e record in diversi formati. Sono anche presenti degli assistenti (wizard) molto utili in alcune situazioni, ad esempio quando � necessario creare velocemente un certo numero di pagine, o quando bisogna riordinarle.";
$MLANG["it"]["tabs"]["tab"] = "Funzione";

$MLANG["fr"]["labels"]["tablabel"] = "Fonctions avanc�es";
$MLANG["fr"]["labels"]["tabdescr"] = "Vous trouverez ici les foncions g�n�rales d'import/export. En plus ce module contient des fonctions sp�cialis�es - assistants - utiles dans des situations sp�cifiques. Pour l'instant, vous pouvez automatiser la cr�ation de pages et trier les pages.";
$MLANG["fr"]["tabs"]["tab"] = "Fonctions";

$MLANG["es"]["labels"]["tablabel"] = "Funciones avanzadas";
$MLANG["es"]["labels"]["tabdescr"] = "Encontrar� funciones generales de importaci�n y exportaci�n. Adicionalmente este m�dulo contiene funciones especializadas - expertos - �tiles en situaciones espec�ficas. Por ejemplo puede crear p�ginas por lotes y ejecutar su ordenamiento.";
$MLANG["es"]["tabs"]["tab"] = "Funciones";


$MLANG["nl"]["labels"]["tablabel"] = "Bijzondere functies";
$MLANG["nl"]["labels"]["tabdescr"] = "Hier vind je algemene export en import functies. Bovendien bevat deze module gespecialiseerde functies - wizards - die nuttig kunnen zijn in bepaalde situaties. Je kan hier bijvoorbeeld in een keer meerdere pagina's aanmaken en pagina's op verschillende manieren sorteren.";
$MLANG["nl"]["tabs"]["tab"] = "Functies";

$MLANG["cz"]["labels"]["tablabel"] = "Pokro�il� funkce";
$MLANG["cz"]["labels"]["tabdescr"] = "Zde najdete obecn� funkce pro import a export. Nav�c obsahuje tento modul specializovan� funkce - pomocn�ky - u�ite�n� p�i specifick�ch situac�ch";
$MLANG["cz"]["tabs"]["tab"] = "Funkce";

$MLANG["pl"]["labels"]["tablabel"] = "Funkcje zaawansowane";
$MLANG["pl"]["labels"]["tabdescr"] = "Znajdziesz tutaj funkcje eksportu i importu danych. Ponadto modu� zawiera kilka funkcji specjalistycznych. Na przyk�ad do automatycznego tworzenia lub sortowania stron.";
$MLANG["pl"]["tabs"]["tab"] = "Funkcje";

$MLANG["si"]["labels"]["tablabel"] = "Napredne funkcije";
$MLANG["si"]["tabs"]["tab"] = "Funkcije";
$MLANG["si"]["labels"]["tabdescr"] = "Tu najdete splo�ne funcije za izvoz in uvoz podatkov. Ta modul vsebuje tudi posebne funkcije - �arovnike - ki so uporabni naprimer za paketno dodajanje strani ali njihovo sortiranje.";

$MLANG["fi"]["labels"]["tablabel"] = "Laajennetut toiminnat";
$MLANG["fi"]["labels"]["tabdescr"] = "T��lt� l�yd�t yleisi� ulos ja sis��nvienti toimintoja. Lis�ksi moduli sis�lt�� erkoistoimintoja - ohjeistuksia - k�ytt�kelpoisia tiettuihin tilanteisiin. Voit esimerkiksi kerralla luoda joukon sivuja tai lajitella sivujen j�rjestyst�.";
$MLANG["fi"]["tabs"]["tab"] = "Toiminnot";

$MLANG["tr"]["labels"]["tablabel"] = "Geli�mi� fonksiyonlar";
$MLANG["tr"]["tabs"]["tab"] = "Fonksiyonlar";
$MLANG["tr"]["labels"]["tabdescr"] = "Burada genel export ve import fonksiyonlar� bulabileceksiniz. Buna ek olarak bu mod�l uzmanla�m�� fonksiyonlar� kapsar - sihirbazlar - spesifik durumlarda kullan�m�. �rnek olarak bu �zel fonksiyonlar toplu sayfa yarat�lmas� i�in veya sayfalar�n s�n�fland�r�lmas� i�in kullan�labilir.";


$MCONF["script"]="index.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_func";
?>