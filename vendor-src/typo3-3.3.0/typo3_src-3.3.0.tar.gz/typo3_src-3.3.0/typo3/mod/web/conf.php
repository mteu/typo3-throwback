<?php
$MLANG["default"]["labels"]["tablabel"] = "Webpages and databasecontent";
$MLANG["default"]["tabs"]["tab"] = "Web";
$MLANG["default"]["tabs_images"]["tab"] = "website.gif";

$MLANG["dk"]["labels"]["tablabel"] = "Websider og database-indhold";
$MLANG["dk"]["tabs"]["tab"] = "Web";

$MLANG["de"]["labels"]["tablabel"] = "Webseiten und Datenbankinhalt";
$MLANG["de"]["tabs"]["tab"] = "Web";

$MLANG["no"]["labels"]["tablabel"] = "Websider og database-innhold";
$MLANG["no"]["tabs"]["tab"] = "Web";

$MLANG["it"]["labels"]["tablabel"] = "Pagine web e contenuto database";
$MLANG["it"]["tabs"]["tab"] = "Web";

$MLANG["fr"]["labels"]["tablabel"] = "Pages web et contenu base de donn�es";
$MLANG["fr"]["tabs"]["tab"] = "Web";

$MLANG["es"]["labels"]["tablabel"] = "P�ginas web y contenido de la base de datos";
$MLANG["es"]["tabs"]["tab"] = "Web";

$MLANG["nl"]["labels"]["tablabel"] = "Webpagina's en database-inhoud";
$MLANG["nl"]["tabs"]["tab"] = "Web";

$MLANG["cz"]["labels"]["tablabel"] = "Webov� str�nky a obsah datab�ze";
$MLANG["cz"]["tabs"]["tab"] = "Web";

$MLANG["pl"]["labels"]["tablabel"] = "Struktura witryny";
$MLANG["pl"]["tabs"]["tab"] = "Web";

$MLANG["si"]["labels"]["tablabel"] = "Spletne strani in vsebina";
$MLANG["si"]["tabs"]["tab"] = "Web";

$MLANG["fi"]["labels"]["tablabel"] = "WWW-sivut ja tietokannan sis�lt�";
$MLANG["fi"]["tabs"]["tab"] = "WWW";

$MLANG["tr"]["labels"]["tablabel"] = "Websayfalar� ve veritaban� i�eri�i";
$MLANG["tr"]["tabs"]["tab"] = "Web";


$MCONF["defaultMod"]="list";
$MCONF["name"]="web";
$MCONF["access"]="user,group";

?>