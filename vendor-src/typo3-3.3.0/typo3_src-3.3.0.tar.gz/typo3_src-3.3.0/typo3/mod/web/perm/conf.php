<?php
define("TYPO3_MOD_PATH", "mod/web/perm/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Page editing permissions";
$MLANG["default"]["tabs"]["tab"] = "Access";
$MLANG["default"]["tabs_images"]["tab"] = "perm.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Setting of page permissions is vital in order to control access to the pages for the backend users. You can assign a user and a group as owners of a page and set access permissions for each.";

$MLANG["dk"]["labels"]["tablabel"] = "Sideredigerings rettigheder";
$MLANG["dk"]["tabs"]["tab"] = "Adgang";
$MLANG["dk"]["labels"]["tabdescr"] = "Ops�tning af rettigheder er vigtigt for at kontrollere tilgangen til siderne for opdateringsbrugerne. Du kan ops�tte en ejerbruger og -gruppe for en side og tilf�je adgangsbetingelser for hver.";

$MLANG["de"]["labels"]["tablabel"] = "Seiten-Bearbeitungsrechte";
$MLANG["de"]["tabs"]["tab"] = "Zugriff";
$MLANG["de"]["labels"]["tabdescr"] = "Das Setzen der Seitenzugriffsrechte ist elementar, um den Zugriff der Backend Benutzer auf die einzelnen Seiten zu steuern. Sie k�nnen einzelnen Benutzern und Benutzergruppen als Besitzer der Seite definieren und deren Zugriffsrechte festlegen.";

$MLANG["no"]["labels"]["tablabel"] = "Side redigerings rettigheter";
$MLANG["no"]["tabs"]["tab"] = "Adgang";
$MLANG["no"]["labels"]["tabdescr"] = "Oppsettet av rettigheter er viktig for � kunne kontrollere adgangen til sidene for oppdateringsbrukerne. Du kan sette opp en eierbruker og -gruppe for en side og legge til adgangsbetingelser for hver.";

$MLANG["it"]["labels"]["tablabel"] = "Pagina i editing dei permessi";
$MLANG["it"]["tabs"]["tab"] = "Accesso";
$MLANG["it"]["labels"]["tabdescr"] = "Il settaggio dei permessi e' vitale per il controllo degli accessi alle pagine degl'utenti autenticati. Poi assegnare la porprieta' della pagina ad un utente o ad un gruppo";

$MLANG["fr"]["labels"]["tablabel"] = "Permissions d'�dition des pages";
$MLANG["fr"]["tabs"]["tab"] = "Acc�s";
$MLANG["fr"]["labels"]["tabdescr"] = "Mettre en place la s�curit� au niveau des pages est un point crucial. Pr�parer avec soins les acc�s que vous souhaitez donner � vos utilisateurs et groupes.";

$MLANG["es"]["labels"]["tablabel"] = "Edici�n de permisos de la p�gina";
$MLANG["es"]["tabs"]["tab"] = "Acceso";
$MLANG["es"]["labels"]["tabdescr"] = "El especificar los permisos de las p�ginas es primordial para el control de acceso a las p�ginas por parte de los usuarios del backend. Ud. puede asignar un usuario y grupo como due�os de la p�gina y especificar los permisos de acceso para cada uno.";

$MLANG["nl"]["labels"]["tablabel"] = "Rechten voor het bewerken van pagina's";
$MLANG["nl"]["tabs"]["tab"] = "Toegang";
$MLANG["nl"]["labels"]["tabdescr"] = "De instelling van paginarechten is van vitaal belang om toegang te regelen voor de pagina's van de BeheerSitegebruikers. Je kan een gebruiker en een groep de rechten van eigenaar van een pagina toekennen en toegangsrechten voor ieder bepalen.";

$MLANG["cz"]["labels"]["tablabel"] = "P��stupov� pr�va ke stran�m";
$MLANG["cz"]["tabs"]["tab"] = "P��stup";
$MLANG["cz"]["labels"]["tabdescr"] = "Nastaven� p��stupov�ch pr�v je z�sadn� pro kontrolu p��stupu u�ivatel� backendu ke stran�m. M��ete p�i�adit u�ivatele a skupinu jako vlastn�ky strany a nastavit p��stupov� pr�va.";

$MLANG["pl"]["labels"]["tablabel"] = "Uprawnienia dost�pu do stron";
$MLANG["pl"]["tabs"]["tab"] = "Uprawnienia";
$MLANG["pl"]["labels"]["tabdescr"] = "Uprawnienia do stron s� potrzebne, je�li chcesz kontrolowa� prawa jakie maj� poszczeg�lni u�ytkownicy. Mo�esz przydziela� niezale�nie prawa dla w�a�ciciela strony lub dla ca�ej grupy.";

$MLANG["si"]["labels"]["tablabel"] = "Privilegiji dostopa do strani";
$MLANG["si"]["tabs"]["tab"] = "Dostop";
$MLANG["si"]["labels"]["tabdescr"] = "Urejanje privilegijev dostopa do strani.";

$MLANG["fi"]["labels"]["tablabel"] = "Sivujen muotoilun oikeudet";
$MLANG["fi"]["labels"]["tabdescr"] = "Sivujen k�ytt�oikeuksien m��rittely on t�rke�� backend-k�ytt�jien oikeuksia valvottaessa. Voit osoittaa k�ytt�ji� ja ryhmi� tiettyjen sivujen omistajiksi sek� asettaa k�ytt�oikeuksia kullekin.";
$MLANG["fi"]["tabs"]["tab"] = "P��sy k�ytt��n";

$MLANG["tr"]["labels"]["tablabel"] = "Sayfa d�zenleme yetkileri";
$MLANG["tr"]["tabs"]["tab"] = "Eri�im";
$MLANG["tr"]["labels"]["tabdescr"] = "Sayfa izinlerinin atanmas� arkaplan kullan�c�lar�n�n sayfalar�na eri�imini kontrol etmek  a��s�ndan hayati �nem ta��yor. Sayfan�n sahipleri olarak bir kullan�c� ve bir grup atayabilir ve herbiri i�in eri�im izinleri kurabilirsiniz.";


$MCONF["script"]="index.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_perm";
?>