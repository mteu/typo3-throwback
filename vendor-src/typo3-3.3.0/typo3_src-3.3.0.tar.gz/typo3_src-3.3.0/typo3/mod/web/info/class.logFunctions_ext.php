<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Extension class/classes for the script named as the latter part of the filename of this file
 * Eg. if this file is named "class.show_item.php" then it's used by "show_item.php"
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

class logFunctions_ext extends t3lib_BEDisplayLog {
	function initArray()	{
		global $LANG;
		$codeArr=Array();
		$codeArr[$i][]=$LANG->getLL("chLog_l_time");
		$codeArr[$i][]=$LANG->getLL("chLog_l_user");
		$codeArr[$i][]=$LANG->getLL("chLog_l_error");
		$codeArr[$i][]=$LANG->getLL("chLog_l_action");
		$codeArr[$i][]=$LANG->getLL("chLog_l_table");
		$codeArr[$i][]=$LANG->getLL("chLog_l_details");
		return $codeArr;
	}
}


if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/info/class.logFunctions_ext.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/info/class.logFunctions_ext.php"]);
}

?>