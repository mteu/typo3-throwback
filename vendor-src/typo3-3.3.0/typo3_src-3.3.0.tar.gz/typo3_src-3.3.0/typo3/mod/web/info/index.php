<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: Log check
 *
 * This module checks the log
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
include ("locallang.php");
include_once(PATH_t3lib."class.t3lib_page.php");

$BE_USER->modAccess($MCONF,1);




// ***************************
// Script Classes
// ***************************
class SC_mod_web_info_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $include_once=array();
	var $content;
	
	var $modTSconfig;
	var $perms_clause;
	var $be_user_Array;
	var $CALC_PERMS;
	var $pageinfo;
	var $id;

	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];
		$this->id = intval(t3lib_div::GPvar("id"));

		$this->perms_clause = $BE_USER->getPagePermsClause(1);
	
		$this->menuConfig();

		switch((string)$this->MOD_SETTINGS["function"])	{
			case "page":
			case "hits":
				$this->include_once[]=PATH_t3lib."class.t3lib_pagetree.php";
				$this->include_once[]=PATH_t3lib."class.t3lib_recordlist.php";
				$this->include_once[]=PATH_typo3."class.db_list.inc";
				$this->include_once[]=PATH_typo3."class.db_layout.inc";
			break;
			case "log":
				$this->include_once[]=PATH_t3lib."class.t3lib_pagetree.php";
				$this->include_once[]=PATH_t3lib."class.t3lib_bedisplaylog.php";
				$this->include_once[]="class.logFunctions_ext.php";
			break;
			case "tsconf":
				$this->include_once[]=PATH_t3lib."class.t3lib_tstemplate.php";
				$this->include_once[]=PATH_typo3."mod/web/ts/tsparser_ext.php";
			break;
		}
	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

			// MENU-ITEMS:
			// If array, then it's a selector box menu
			// If empty string it's just a variable, that'll be saved. 
			// Values NOT in this array will not be saved in the settings-array for the module.
		$this->MOD_MENU = array(
			"function" => array(
				"page" => $LANG->getLL("page_title"),
				"hits" => $LANG->getLL("hits_title"),
				"log" => $LANG->getLL("chLog_title"),
				"tsconf" => $LANG->getLL("tsconf_title")
			),
			"log_users" => array(
				0 => $LANG->getLL("chLog_users_0"),
				"-1" => $LANG->getLL("chLog_users_-1")
			),
			"log_time" => array(
				0 => $LANG->getLL("chLog_time_0"),
				1 => $LANG->getLL("chLog_time_1"),
				2 => $LANG->getLL("chLog_time_2"),
				10 => $LANG->getLL("chLog_time_10"),
				11 => $LANG->getLL("chLog_time_11"),
				12 => $LANG->getLL("chLog_time_12"),
				20 => $LANG->getLL("chLog_time_20")
			),
			"depth" => array(
				0 => $LANG->getLL("depth_0"),
				1 => $LANG->getLL("depth_1"),
				2 => $LANG->getLL("depth_2"),
				3 => $LANG->getLL("depth_3")
			),
			"pages" => array (
				0 => $LANG->getLL("pages_0"),
				2 => $LANG->getLL("pages_2"),
				1 => $LANG->getLL("pages_1")
			),
			"stat_type" => array(
				0 => $LANG->getLL("stat_type_0"),
				1 => $LANG->getLL("stat_type_1"),
				2 => $LANG->getLL("stat_type_2"),
			),
			"tsconf_parts" => array(
				0 => $LANG->getLL("tsconf_parts_0"),
				1 => $LANG->getLL("tsconf_parts_1"),
				"1a" => $LANG->getLL("tsconf_parts_1a"),
				"1b" => $LANG->getLL("tsconf_parts_1b"),
				"1c" => $LANG->getLL("tsconf_parts_1c"),
				"1d" => $LANG->getLL("tsconf_parts_1d"),
				"1e" => $LANG->getLL("tsconf_parts_1e"),
				"1f" => $LANG->getLL("tsconf_parts_1f"),
				"1g" => $LANG->getLL("tsconf_parts_1g"),
				2 => "RTE.",
				5 => "TCEFORM.",
				6 => "TCEMAIN.",
				3 => "TSFE.",
				4 => "user.",
				99 => $LANG->getLL("tsconf_configFields")
			)
		);
	
			// page/be_user TSconfig settings and blinding of menu-items
		$this->modTSconfig = t3lib_BEfunc::getModTSconfig($this->id,"mod.".$this->MCONF["name"]);
		$this->MOD_MENU["function"] = t3lib_BEfunc::unsetMenuItems($this->modTSconfig["properties"],$this->MOD_MENU["function"],"menu.function");
		if (!$BE_USER->isAdmin())	unset($this->MOD_MENU["tsconf_parts"][99]);
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"]);
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// Access check...
		// The page will show only if there is a valid page and if this page may be viewed by the user
		$this->pageinfo = t3lib_BEfunc::readPageAccess($this->id,$this->perms_clause);
		$access = is_array($this->pageinfo) ? 1 : 0;
		
		if (($this->id && $access) || ($BE_USER->user["admin"] && !$this->id))	{
			$this->CALC_PERMS = $BE_USER->calcPerms($this->pageinfo);
			if ($BE_USER->user["admin"] && !$this->id)	{
				$this->pageinfo=array("title" => "[root-level]","uid"=>0,"pid"=>0);
			}
		
			$this->doc = t3lib_div::makeInstance("mediumDoc");
			$this->doc->backPath = $BACK_PATH;
			$this->doc->tableLayout = Array (
				"0" => Array (
					"0" => Array('<TD valign="top"><b>','</b></td>'),
					"defCol" => Array('<TD><img src="'.$this->doc->backPath.'clear.gif" width=10 height=1></td><td valign="top"><b>','</b></td>')
				),
				"defRow" => Array (
					"0" => Array('<TD valign="top">','</td>'),
					"defCol" => Array('<TD><img src="'.$this->doc->backPath.'clear.gif" width=10 height=1></td><td valign="top">','</td>')
				)
			);
				
				// JavaScript
			$this->doc->JScode = '
		<script>
			script_ended = 0;
			function jumpToUrl(URL)	{
				document.location = URL;
			}
		</SCRIPT>
				';
			
		$this->doc->postCode='
		<script language="javascript">
		script_ended = 1;
		if (top.theMenu) top.theMenu.recentuid = '.intval($this->id).';
		</script>
		';
		
		
			$headerSection = $this->doc->getHeader("pages",$this->pageinfo,$this->pageinfo["_thePath"]).'<br>'.$LANG->php3Lang["labels"]["path"].': '.t3lib_div::fixed_lgd_pre($this->pageinfo["_thePath"],50);
		
				// Draw the header.
			$this->doc->form='<form action="" method="POST">';
			$this->content.=$this->doc->startPage($LANG->getLL("title"));
			$this->content.=$this->doc->header($LANG->getLL("title"));
			$this->content.=$this->doc->spacer(5);
			$this->content.=$this->doc->section('',$this->doc->funcMenu($headerSection,t3lib_BEfunc::getFuncMenu($this->id,"SET[function]",$this->MOD_SETTINGS["function"],$this->MOD_MENU["function"])));
		//	$this->content.=$this->doc->divider(5);
		
			
			switch((string)$this->MOD_SETTINGS["function"])	{
				case "page":
				case "hits":
					$this->content.=$this->main_page_hits();
				break;
				case "log":
					$this->content.=$this->main_log();
				break;
				case "tsconf":
					$this->content.=$this->main_tsconf();
				break;
			}
				
			
		
		
			// ShortCut
			if ($BE_USER->mayMakeShortcut())	{
				$this->content.=$this->doc->spacer(20).$this->doc->section('',$this->doc->makeShortcutIcon("id",implode(",",array_keys($this->MOD_MENU)),$this->MCONF["name"]));
			}
		
			$this->content.=$this->doc->spacer(10);
		} else {
				// If no access or if ID == zero
		
			$this->doc = t3lib_div::makeInstance("mediumDoc");
			$this->doc->backPath = $BACK_PATH;
		
			$this->content.=$this->doc->startPage($LANG->getLL("title"));
			$this->content.=$this->doc->header($LANG->getLL("title"));
			$this->content.=$this->doc->spacer(5);
			$this->content.=$this->doc->spacer(10);
		}
	}
	function printContent()	{
		global $SOBE;

		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
	
	
	// ***********************************
	// MAIN function for log display
	// ***********************************
	function main_log()	{
		global $SOBE,$LOCAL_LANG,$LANG;
	// Menu!
	
		// If log-viewing is the thing:
		include_once(PATH_typo3."mod/tools/log/locallang_log.php");
		$LOCAL_LANG=t3lib_div::array_merge_recursive_overrule($LOCAL_LANG_LOG,$LOCAL_LANG);
	
	
		$lF = t3lib_div::makeInstance("logFunctions_ext");	
	
		$theOutput="";
		$menu="";
		$menu.=  "&nbsp;".$LANG->getLL("chLog_menuUsers").": ".t3lib_BEfunc::getFuncMenu($this->id,"SET[log_users]",$this->MOD_SETTINGS["log_users"],$this->MOD_MENU["log_users"]);
		$menu.=  "&nbsp;".$LANG->getLL("chLog_menuDepth").": ".t3lib_BEfunc::getFuncMenu($this->id,"SET[depth]",$this->MOD_SETTINGS["depth"],$this->MOD_MENU["depth"]);
		$menu.=  "&nbsp;".$LANG->getLL("chLog_menuTime").": ".t3lib_BEfunc::getFuncMenu($this->id,"SET[log_time]",$this->MOD_SETTINGS["log_time"],$this->MOD_MENU["log_time"]);
		$theOutput.=$this->doc->section($LANG->getLL("chLog_title"),'<NOBR>'.$menu.'</NOBR>',0,1);
	
		
			
		// Build query
		
		$where_part="";
		
		// Get the idlist of pages for the treestructure.
		$tree = t3lib_div::makeInstance("t3lib_pageTree");
		$tree->init("AND ".$this->perms_clause);
		$tree->makeHTML=0;
		$tree->fieldArray = Array("uid");
		if ($this->MOD_SETTINGS["depth"])	{
			$tree->getTree($this->id, $this->MOD_SETTINGS["depth"], "");
		}
		$tree->ids[]=$this->id;
		$idList = implode($tree->ids,",");
		
		//$where_part.=" AND ((tablename='pages' and recuid in (".$idList.")) OR (tablename!='pages' and recpid in (".$idList.")))";		// DB
		$where_part.=" AND (event_pid in (".$idList."))";		// DB
									
		// Time:
		$starttime=0;
		$endtime=time();
		switch($this->MOD_SETTINGS["log_time"])		{
			case 0:
				// This week
				$week = (date("w") ? date("w") : 7)-1;
				$starttime = mktime (0,0,0)-$week*3600*24;
			break;
			case 1:
				// Last week
				$week = (date("w") ? date("w") : 7)-1;
				$starttime = mktime (0,0,0)-($week+7)*3600*24;
				$endtime = mktime (0,0,0)-$week*3600*24;
			break;
			case 2:
				// Last 7 days
				$starttime = mktime (0,0,0)-7*3600*24;
			break;
			case 10:
				// This month
				$starttime = mktime (0,0,0, date("m"),1);
			break;
			case 11:
				// Last month
				$starttime = mktime (0,0,0, date("m")-1,1);
				$endtime = mktime (0,0,0, date("m"),1);
			break;
			case 12:
				// Last 31 days
				$starttime = mktime (0,0,0)-31*3600*24;
			break;
		}
		if ($starttime)	{
			$where_part.=" AND tstamp>=".$starttime." AND tstamp<".$endtime;	
		}
		
		$where_part.=" AND type=1";		// DB
		
		
			// Users
		$this->be_user_Array = t3lib_BEfunc::getUserNames();
		if (!$this->MOD_SETTINGS["log_users"])	{	// All users
				// Get usernames and groupnames
			if (!$GLOBALS["BE_USER"]->isAdmin())		{
				$groupArray = explode(",",$GLOBALS["BE_USER"]->user["usergroup_cached_list"]);
				$this->be_user_Array = t3lib_BEfunc::blindUserNames($this->be_user_Array,$groupArray,1);
			}
		
			if (is_array($this->be_user_Array))	{
				while(list(,$val)=each($this->be_user_Array))	{
					$selectUsers[]=$val["uid"];
				}
			}
			$selectUsers[] = $GLOBALS["BE_USER"]->user["uid"];
			$where_part.=" AND userid in (".implode($selectUsers,",").")";
		} else {
			$where_part.=" AND userid=".$GLOBALS["BE_USER"]->user["uid"];	// Self user
		}
		
		
		
		
		
		$query="SELECT * FROM sys_log WHERE 1=1".$where_part." order by uid desc limit 100";
		$log = mysql(TYPO3_db,$query);
		echo mysql_error();
		
		$codeArr=$lF->initArray();
		$oldHeader="";
		while($row=mysql_fetch_assoc($log))	{
			$header=$this->doc->formatTime($row["tstamp"],10);
			if (!$oldHeader)	$oldHeader=$header;
		
			if ($header!=$oldHeader)	{
				$theOutput.=$this->doc->spacer(10);
				$theOutput.=$this->doc->section($oldHeader,$this->doc->table($codeArr));
				$codeArr=$lF->initArray();
				$oldHeader=$header;
				$lF->reset();
			}
		
			$i++;
			$codeArr[$i][]=$lF->getTimeLabel($row["tstamp"]);  
			$codeArr[$i][]=$lF->getUserLabel($row["userid"]);
			$codeArr[$i][]=$row["error"] ? $lF->getErrorFormatting($lF->errorSign[$row["error"]]) : "";
			$codeArr[$i][]=$lF->getActionLabel($row["type"]."_".$row["action"]);
			$codeArr[$i][]=$row["tablename"];
			$codeArr[$i][]=$lF->formatDetailsForList($row);
		}
		$theOutput.=$this->doc->spacer(10);
		$theOutput.=$this->doc->section($header,$this->doc->table($codeArr));
	
		return $theOutput;	
	}
	
	
	
	
	// *******************************************
	// MAIN function for page TS config display
	// *******************************************
	function main_tsconf()	{
		global $SOBE,$LANG;
		
		$menu=t3lib_BEfunc::getFuncMenu($this->id,"SET[tsconf_parts]",$this->MOD_SETTINGS["tsconf_parts"],$this->MOD_MENU["tsconf_parts"]);
	
		if ($this->MOD_SETTINGS["tsconf_parts"]==99)	{
			$TSparts = t3lib_BEfunc::getPagesTSconfig($this->id,"",1);
			reset($TSparts);
			$lines=array();
			$pUids=array();
			while(list($k,$v)=each($TSparts))	{
				if ($k!="uid_0")	{
					if ($k=="defaultPageTSconfig")	{
						$pTitle='<strong>'.htmlspecialchars($GLOBALS["LANG"]->getLL("editTSconfig_default")).'</strong>';
						$editIcon="";
					} else {
						$pUids[]=substr($k,4);
						$row=t3lib_BEfunc::getRecord("pages",substr($k,4));
						$pTitle = $this->doc->getHeader("pages",$row,"",0);
	
						$editIdList=substr($k,4);
						$params="&edit[pages][".$editIdList."]=edit&columnsOnly=TSconfig";
						$editIcon='<a href="#" onClick="'.t3lib_BEfunc::editOnClick($params,$GLOBALS["BACK_PATH"],"",1).'"><img src="'.$GLOBALS["BACK_PATH"].'gfx/edit2.gif" width=11 height=12 vspace=2 border=0 align="top"'.t3lib_BEfunc::titleAttrib($GLOBALS["LANG"]->getLL("editTSconfig")).'></a>';
					}
					$lines[]='
						<tr><td nowrap bgColor="'.$this->doc->bgColor5.'">'.$pTitle.'</td></tr>
						<tr><td nowrap bgColor="'.$this->doc->bgColor4.'">'.nl2br(htmlspecialchars(trim($v).chr(10))).$editIcon.'</td></tr>
						<tr><td>&nbsp;</td></tr>
					';
				}
			}
	
			if (count($pUids))	{
				$params="&edit[pages][".implode(",",$pUids)."]=edit&columnsOnly=TSconfig";
				$editIcon='<a href="#" onClick="'.t3lib_BEfunc::editOnClick($params,$GLOBALS["BACK_PATH"],"",1).'"><img src="'.$GLOBALS["BACK_PATH"].'gfx/edit2.gif" width=11 height=12 vspace=2 border=0 align="top"'.t3lib_BEfunc::titleAttrib($GLOBALS["LANG"]->getLL("editTSconfig_all")).'><strong>'.htmlspecialchars($GLOBALS["LANG"]->getLL("editTSconfig_all")).'</strong></a>';
			} else $editIcon='';
	
			$theOutput.=$this->doc->section($LANG->getLL("tsconf_title"),
				$menu.'<BR><BR><table border=0 cellpadding=0 cellspacing=1>'.implode("",$lines).'</table><BR>'.$editIcon,
				0,
				1
			);
		} else {
			$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
			$tmpl->tt_track = 0;	// Do not log time-performance information
			
			$tmpl->fixedLgd=0;
			$tmpl->linkObjects=0;
			$tmpl->bType="";
			$tmpl->ext_expandAllNotes=1;
			$tmpl->ext_noPMicons=1;
			
			switch($this->MOD_SETTINGS["tsconf_parts"])	{
				case "1":
					$modTSconfig = t3lib_BEfunc::getModTSconfig($this->id,"mod");
				break;
				case "1a":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_layout",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "1b":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_view",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "1c":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_modules",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "1d":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_list",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "1e":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_info",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "1f":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_func",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "1g":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("mod.web_ts",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "2":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("RTE",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "5":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("TCEFORM",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "6":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("TCEMAIN",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "3":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("TSFE",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				case "4":
					$modTSconfig = $GLOBALS["BE_USER"]->getTSConfig("user",t3lib_BEfunc::getPagesTSconfig($this->id));
				break;
				default:
					$modTSconfig["properties"] = t3lib_BEfunc::getPagesTSconfig($this->id);
				break;
			}
			$modTSconfig = $modTSconfig["properties"];
		
			if (!is_array($modTSconfig))	$modTSconfig=array();
		
			$theOutput.=$this->doc->section($LANG->getLL("tsconf_title"),
				$menu.'<table border=0 cellpadding=0 cellspacing=0><tr><td nowrap>'.$tmpl->ext_getObjTree($modTSconfig,"","").'</td></tr></table>',
				0,
				1
			);
		}
	
		return $theOutput;
	}
	
	
	
	
	// *******************************************
	// MAIN function for page overview
	// *******************************************
	function main_page_hits()	{
		global $BACK_PATH,$LANG,$SOBE;
	
		$dblist = t3lib_div::makeInstance("recordList_layout");
		$dblist->backPath = $BACK_PATH;
		$dblist->thumbs = 0;
		$dblist->AB=1;	// hardcoding, because we run this as if we're in the alternative backend
		$dblist->headLineCol = $this->doc->bgColor2;
		$dblist->script = "index.php";
		$dblist->showIcon = 0;
		$dblist->setLMargin=0;
		$dblist->agePrefixes=$LANG->php3Lang["labels"]["minutesHoursDaysYears"];
	
		$dblist->pI_showUser=1;
		$dblist->pI_showStat=0;
		
		
			// PAGES:
		$this->MOD_SETTINGS["pages_levels"]=$this->MOD_SETTINGS["depth"];		// ONLY for the sake of dblist module which uses this value.
		
		$h_func = t3lib_BEfunc::getFuncMenu($this->id,"SET[depth]",$this->MOD_SETTINGS["depth"],$this->MOD_MENU["depth"],"index.php");
		if ($this->MOD_SETTINGS["function"]=="hits")	{
			$h_func.= t3lib_BEfunc::getFuncMenu($this->id,"SET[stat_type]",$this->MOD_SETTINGS["stat_type"],$this->MOD_MENU["stat_type"],"index.php");
	
			if ($this->MOD_SETTINGS["stat_type"]==1)	$dblist->stat_select_field="rl0";
			if ($this->MOD_SETTINGS["stat_type"]==2)	$dblist->stat_select_field="rl1";
	
				// Timespan		
			for ($a=0;$a<30;$a++)	{
				$dblist->stat_codes[]="HITS_days:".(-$a);
			}
			$timespan_b = mktime (0,0,0);
			$timespan_e = mktime (0,0,0)-(30-1)*3600*24+1;
			$header="<BR>".fw(sprintf($LANG->getLL("stat_period"),t3lib_BEfunc::date($timespan_b),t3lib_BEfunc::date($timespan_e)))."<bR>";
			
				//
			$dblist->start($this->id,"pages",0);
			$dblist->pages_noEditColumns=1;
			$dblist->generateList();
			
	
			$theOutput.=$this->doc->section($LANG->getLL("hits_title"),
				$h_func.$header.$dblist->HTMLcode,
				0,
				1
			);
		} else {
			$h_func.= t3lib_BEfunc::getFuncMenu($this->id,"SET[pages]",$this->MOD_SETTINGS["pages"],$this->MOD_MENU["pages"],"index.php");
	
			$dblist->start($this->id,"pages",0);
			$dblist->generateList();
			$theOutput.=$this->doc->section($LANG->getLL("page_title"),
				$h_func.$dblist->HTMLcode,
				0,
				1
			);
			
				// SYS_NOTES:
			$dblist->start($this->id,"sys_note",0);
			$dblist->generateList();
			if ($dblist->HTMLcode)	{
				$theOutput.=$this->doc->spacer(10);
				$theOutput.=$this->doc->section($LANG->getLL("page_sysnote"),
					$dblist->HTMLcode,
					0,
					1
				);
			}
				// PAGE INFORMATION
			if ($this->pageinfo["uid"])	{
				$theOutput.=$this->doc->spacer(10);
				$theOutput.=$this->doc->section($LANG->getLL("pageInformation"),$dblist->getPageInfoBox($this->pageinfo,$this->CALC_PERMS&2),0,1);
			}
		}
		
		
		return $theOutput;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/info/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/info/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_web_info_index");
$SOBE->init();

// Include files?
reset($SOBE->include_once);	
while(list(,$INC_FILE)=each($SOBE->include_once))	{include_once($INC_FILE);}

$SOBE->main();
$SOBE->printContent();
?>