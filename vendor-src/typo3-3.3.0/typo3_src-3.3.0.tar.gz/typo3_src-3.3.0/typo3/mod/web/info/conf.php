<?php
define("TYPO3_MOD_PATH", "mod/web/info/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Page related information, eg. hit statistics, change log, record counts";
$MLANG["default"]["tabs"]["tab"] = "Info";
$MLANG["default"]["tabs_images"]["tab"] = "info.gif";
$MLANG["default"]["labels"]["tabdescr"] = "The Web>Info module is focused on statistic information about pages. This includes statistics of pagehits and a changelog which lets you browse the history of page changes. You can also get an overview of the number of records on each page as well as page settings presented in a classic tree structure.";

$MLANG["dk"]["labels"]["tablabel"] = "Siderelateret information, fx. visningsstatestik, �ndrings-log, element-opt�lling";
$MLANG["dk"]["tabs"]["tab"] = "Info";
$MLANG["dk"]["labels"]["tabdescr"] = "Modulet Web>Info fokuserer p� statistisk information om sider. Dette omfatter sidevisningsstatestik samt en opdateringslog som lader dig gennemse �ndringsforl�bet for en side. Du kan ogs� f� et overblik over antallet af elementer p� hver side samt sidernes indstillinger alt sammen pr�senteret i den klassiske tr�struktur.";

$MLANG["de"]["labels"]["tablabel"] = "Seitenbezogene Informationen, z.B. Zugriffsstatistik, �nderungsprotokollierung, Datensatzanzahl";
$MLANG["de"]["labels"]["tabdescr"] = "Das Web-Info Modul ist spezialisiert auf statistische Informationen �ber Webseiten. Dies beinhaltet Statistiken �ber Seitenzugriffe und eine �nderungsprotokollierung, welche Sie durch alle �nderung der Seite navigieren l�sst. Sie k�nnen sich ebenso eine �bersicht der verwendeten Datens�tze auf den einzelnen Seiten als auch die Seiteneinstellungen in Form einer Baumansicht ansehen.";
$MLANG["de"]["tabs"]["tab"] = "Info";

$MLANG["no"]["labels"]["tablabel"] = "Siderelatert informasjon, for eksempel visningsstatistikk, endringslogg, antall elementer.";
$MLANG["no"]["labels"]["tabdescr"] = "Modulen Web>Info omhandler statistisk informasjon omsider. Dette omfatter sidevisningsstatistikk samt en oppdateringslogg hvor du kan bla gjennom endringsforl�pet for en side. Du kan ogs� f� en oversikt over antall elementer p� hver side samt sidenes innstillinger alt dette presentert i den klassiske trestrukturen.";
$MLANG["no"]["tabs"]["tab"] = "Info";

$MLANG["it"]["labels"]["tablabel"] = "Informazioni correlate alla pagina, quali log dei cambiamenti e statistiche sulla pagina e sui record";
$MLANG["it"]["labels"]["tabdescr"] = "Il modulo Web>Info si occupa di informazioni di tipo statistico sulle pagine. Fra queste informazioni troviamo il 'pagehit' ed il log dei cambiamenti che permette di scorrere la storia delle modifiche alla pagina. C'� anche una vista d'insieme sul numero dei record, sul loro tipo e su altri parametri, presentati nella classica struttura ad albero.";
$MLANG["it"]["tabs"]["tab"] = "Informazioni";

$MLANG["fr"]["labels"]["tablabel"] = "Informations en relation avec la page, ex. statistiques, logs, ...";
$MLANG["fr"]["labels"]["tabdescr"] = "Le module Web>Info est cibl� sur la pr�sentation des statistiques d'acc�s � la page.";
$MLANG["fr"]["tabs"]["tab"] = "Info";

$MLANG["pl"]["labels"]["tablabel"] = "Informacje dotycz�ce strony, np. ilo�� ods�on, log zmian, liczba rekord�w";
$MLANG["pl"]["labels"]["tabdescr"] = "Modu� Web>Informacje skupia si� na statystykach ods�on i historii zmian na stronie. Podawana jest tu r�wnie� liczba rekord�w na stronie i ustawienia strony w klasycznym uj�ciu typu drzewko.";
$MLANG["pl"]["tabs"]["tab"] = "Informacje";

$MLANG["es"]["labels"]["tablabel"] = "Informaci�n de las p�ginas, i.e.: estad�sticas, bit�cora, conteo de registros.";
$MLANG["es"]["labels"]["tabdescr"] = "El m�dulo WebInfo est� enfocado en la informaci�n estad�stica de las p�ginas. Incluye estad�sticas de los accesos y bit�cora de cambios que le permite el recorrer el hist�rico de modificaciones de cada p�gina. Todo ello mostrado en la estructura cl�sica de �rbol.";
$MLANG["es"]["tabs"]["tab"] = "Informaci�n";

$MLANG["si"]["labels"]["tablabel"] = "Informacije o straneh, npr. statistika obiskov, dnevnik sprememb, �tevilo zapisov";
$MLANG["si"]["tabs"]["tab"] = "Info";
$MLANG["si"]["labels"]["tabdescr"] = "Info modul je prikazuje predvsem statisti�ne informacije o straneh. To vklju�uje statistiko obiska strani in dnevnik sprememb, preko katerega imate vpogled v zgodovino strani. Ogledate si lahko �a seznam zapisov na posamezni strani ter nastavitve.";

$MLANG["nl"]["tabs"]["tab"] = "Info";
$MLANG["nl"]["labels"]["tablabel"] = "Pagina gerelateerde informatie, zoals statistieken van hits, logwijzigingen, aantal records";
$MLANG["nl"]["labels"]["tabdescr"] = "De Web>Infomodule richt zich op statistische informatie over pagina's. Dit omvat statistieken van paginahits en een log van wijzigingen met de mogelijkheid te zoeken door voorgaande paginawijzigingen. Er is ook een overzicht beschikbaar van het aantal records op elke pagina alsmede de pagina-instellingen gepresenteerd in de klassieke boomstructuur.";

$MLANG["cz"]["labels"]["tablabel"] = "Informace, kter� se v�ou ke str�nce, nap�. statistika p��stup�, z�znam zm�n, po�ty z�znam�";
$MLANG["cz"]["labels"]["tabdescr"] = "Modul Web>Info je zam��en na statistick� informace o stran�ch. To zahrnuje statistiku p��stup� a z�znam zm�n, kter� umo��uje proch�zet proveden� zm�ny. M��ete tak� z�skat p�ehled o po�tu z�znam� na ka�d� stran�, stejn� jako nastaven� stran v klasick� stromov� struktu�e.";
$MLANG["cz"]["tabs"]["tab"] = "Info";

$MLANG["fi"]["labels"]["tablabel"] = "Sivuihin liittyv�� tietoa, esim. sattumien m��r�, muutosloki. tietueiden m��r� jne.";
$MLANG["fi"]["labels"]["tabdescr"] = "WebInfo modulin tarkoituksena on antaa tilastotietoa sivusta. Tietoja ovat tilastot sattumista sivuille, muutosloki josta selvi�� sivujen muutos historia. N�et my�s lukum��r� tiedot tietueista kuten my�s sivujen asetukset perinteisest� sivusto rakenteesta.";
$MLANG["fi"]["tabs"]["tab"] = "Tiedot";

$MLANG["tr"]["labels"]["tablabel"] = "Sayfa bilgi, eri�im istatistikleri, de�i�im logu, kay�t say�lar�na gibi ba�lant� kurdu";
$MLANG["tr"]["tabs"]["tab"] = "Bilgi";
$MLANG["tr"]["labels"]["tabdescr"] = "Web>Bilgi mod�l� sayfadaki istatistik bilgisine odakland�. Bu sayfa eri�imlerinin istatistiklerini ve de�i�im loglar� i�eriyor ki sayfa tarihinin de�i�ikliklerine g�zatman�za izin veriyor. Birde her bir sayfada kay�tlar�n numaras�n�n genel g�r�nt�s�n� elde edebilirsiniz bunun yan�s�ra klasik a�a� yap�s�nda sayfa ayarlar� sunuldu.";



$MCONF["script"]="index.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_info";
?>