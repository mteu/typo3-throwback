<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Module: TypoScript Tools
 *
 *
 * 	$TYPO3_CONF_VARS["MODS"]["web_ts"]["onlineResourceDir"]  = Directory of default resources. Eg. "fileadmin/res/" or so.
 *
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */
 


unset($MCONF);
include ("conf.php");
include ($BACK_PATH."init.php");
include ($BACK_PATH."template.php");
include_once(PATH_t3lib."class.t3lib_page.php");
include_once(PATH_t3lib."class.t3lib_tstemplate.php");
include_once("tsparser_ext.php");

$BE_USER->modAccess($MCONF,1);


// ***************************
// Script Classes
// ***************************
class SC_mod_web_ts_index {
	var $MCONF=array();
	var $MOD_MENU=array();
	var $MOD_SETTINGS=array();
	var $doc;	

	var $include_once=array();
	var $content;
	
	var $perms_clause;
	var $modTSconfig;
	var $e;
	var $sObj;
	var $edit;
	var $textExtensions = "html,htm,txt,css,tmpl,inc";
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		$this->MCONF = $GLOBALS["MCONF"];

		$this->id = intval(t3lib_div::GPvar("id"));
		$this->e = t3lib_div::GPvar("e");
		$this->sObj = t3lib_div::GPvar("sObj");
		$this->edit = t3lib_div::GPvar("edit");

		$this->perms_clause = $BE_USER->getPagePermsClause(1);

		$this->menuConfig();

		if (t3lib_div::GPvar("clear_all_cache"))	{
			$this->include_once[]=PATH_t3lib."class.t3lib_tcemain.php";
		}
		switch($this->MOD_SETTINGS["function"])	{
			case 1:
				$this->include_once[]="ts_constants_editor.php";
			break;			
			case 2:
				$this->include_once[]="ts_browser.php";
			break;			
			case 3:
				$this->include_once[]="ts_analyzer.php";
			break;			
			default:
				$this->include_once[]="ts_template_editor.php";
			break;			
		}
	}
	function menuConfig()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

			// MENU-ITEMS:
			// If array, then it's a selector box menu
			// If empty string it's just a variable, that'll be saved. 
			// Values NOT in this array will not be saved in the settings-array for the module.
		$this->MOD_MENU = array(
			"function" => array(
				0 => "Info/Modify",
				1 => "Constant editor",
				2 => "TypoScript Object browser",
				3 => "Template analyzer"
			),
	//		"constant_editor_cat" => array(),
	//		"templatesOnPage" => array(),
	
			"ts_browser_type" => array(
				"setup" => "Setup",
				"const" => "Constants"
			),
			"ts_browser_toplevel_setup" => array(
				"0" => "ALL"
			),
			"ts_browser_toplevel_const" => array(
				"0" => "ALL"
			),
			"ts_browser_const" => array(
				"0" => "Plain substitution (default)",
				"subst" => "Substituted constants in green",
				"const" => "UN-substituted constants in green"
			),
			"ts_browser_regexsearch" => "",
			"ts_browser_fixedLgd" => "1",
			"ts_browser_linkObjects" => "1",
	
			"ts_analyzer_checkSetup" => "",
			"ts_analyzer_checkConst" => "",
			"ts_analyzer_checkLinenum" => "",
			"ts_analyzer_checkComments" => "",
			"ts_analyzer_checkCrop" => "",
	
			"ts_template_editor_TArows" => ""
		);
		
			// page/be_user TSconfig settings and blinding of menu-items
		$this->modTSconfig = t3lib_BEfunc::getModTSconfig($this->id,"mod.".$this->MCONF["name"]);
		$this->MOD_MENU["function"] = t3lib_BEfunc::unsetMenuItems($this->modTSconfig["properties"],$this->MOD_MENU["function"],"menu.function");
		
			// CLEANSE SETTINGS
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"], "","ts_browser_toplevel_setup,ts_browser_toplevel_const,ts_browser_TLKeys_setup,ts_browser_TLKeys_const","ts_browser_linkObjects,ts_browser_fixedLgd");
	}
	function clearCache()	{
		if (t3lib_div::GPvar("clear_all_cache"))	{
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
			$tce->start(Array(),Array());
			$tce->clear_cacheCmd("all");
		}
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		// Access check...
		// The page will show only if there is a valid page and if this page may be viewed by the user
		$pageinfo = t3lib_BEfunc::readPageAccess($this->id,$this->perms_clause);
		$access = is_array($pageinfo) ? 1 : 0;
		
		if ($this->id && $access)	{
			$this->doc = t3lib_div::makeInstance("mediumDoc");
			$this->doc->backPath = $BACK_PATH;
		
				// JavaScript
			$this->doc->JScode = '
		<script>
			script_ended = 0;
			function jumpToUrl(URL)	{
				document.location = URL;
			}
			function uFormUrl(aname)	{
				document.forms[0].action = "index.php?id='.$this->id.'#"+aname;
			}
			function brPoint(lnumber,t)	{
				document.location = "index.php?id='.$this->id.'&AB=1&SET[function]=2&SET[ts_browser_type]="+(t?"setup":"const")+"&breakPointLN="+lnumber;
				return false;
			}
		</SCRIPT>
		';
			
			$this->doc->postCode='
		<script language="javascript">
			script_ended = 1;
			if (top.theMenu) top.theMenu.recentuid = '.intval($this->id).';
		</script>
		';
		
			$headerSection = $this->doc->getHeader("pages",$pageinfo,$pageinfo["_thePath"]).'<br>'.$LANG->php3Lang["labels"]["path"].': '.t3lib_div::fixed_lgd_pre($pageinfo["_thePath"],50);
		
				// Draw the header.
			$this->doc->form='<form action="index.php?id='.$this->id.'" method="POST" ENCTYPE="multipart/form-data" name="editForm">';
			$this->content.=$this->doc->startPage("Template Tools");
			$this->content.=$this->doc->header("Template Tools");
			$this->content.=$this->doc->spacer(5);
			$this->content.=$this->doc->section('',$this->doc->funcMenu($headerSection,t3lib_BEfunc::getFuncMenu($this->id,"SET[function]",$this->MOD_SETTINGS["function"],$this->MOD_MENU["function"])));

			switch($this->MOD_SETTINGS["function"])	{
				case 1:
					$incObj = t3lib_div::makeInstance("ts_constants_editor");
					$this->content.=$incObj->main();
				break;			
				case 2:
					$incObj = t3lib_div::makeInstance("ts_browser");
					$this->content.=$incObj->main();
				break;			
				case 3:
					$incObj = t3lib_div::makeInstance("ts_analyzer");
					$this->content.=$incObj->main();
				break;			
				default:
					$incObj = t3lib_div::makeInstance("ts_template_editor");
					$this->content.=$incObj->main();
				break;			
			}
		
			// ShortCut
			if ($BE_USER->mayMakeShortcut())	{
				$this->content.=$this->doc->spacer(20).$this->doc->section('',$this->doc->makeShortcutIcon("id,e,sObj,template","function,ts_browser_type,constant_editor_cat",$this->MCONF["name"]));
			}
			$this->content.=$this->doc->spacer(10);
		} else {
				// If no access or if ID == zero
		
			$this->doc = t3lib_div::makeInstance("mediumDoc");
			$this->doc->backPath = $BACK_PATH;
		
			$this->content.=$this->doc->startPage("Template Tools");
			$this->content.=$this->doc->header("Template Tools");
			$this->content.=$this->doc->spacer(5);
		
			
				// Template pages:
			$query="SELECT pages.uid, count(*) AS count, max(sys_template.root) AS root_max_val, min(sys_template.root) AS root_min_val FROM pages,sys_template WHERE pages.uid=sys_template.pid".
				t3lib_BEfunc::deleteClause("pages").
				t3lib_BEfunc::deleteClause("sys_template").
				" GROUP BY pages.uid";
			$res = mysql(TYPO3_db,$query);
			echo mysql_error();
			$templateArray=array();
			$pArray=array();
			while($row=mysql_fetch_assoc($res))	{
				$this->setInPageArray(
					$pArray,
					t3lib_BEfunc::BEgetRootLine ($row["uid"],"AND 1=1"),
					$row
				);
			}
			
			$lines=array();
			$lines[]='<tr bgColor="'.$this->doc->bgColor5.'">
				<td nowrap><strong>Page name</strong></td>
				<td nowrap><strong># Templates</strong></td>
				<td nowrap><strong>Is Root?</strong></td>
				<td nowrap><strong>Is Ext?</strong></td>
				</tr>';
			$lines=array_merge($lines,$this->renderList($pArray));
		
			$table = '<table border=0 cellpadding=0 cellspacing=1>'.implode("",$lines).'</table>';
			$this->content.=$this->doc->section("",'
			<BR>
			This is an overview of the pages in the database containing one or more template records. Click a page title to go to the page.
			<BR><BR>
			'.$table);
		//	debug($pArray);
			// ********************************************
			// RENDER LIST of pages with templates, END
			// ********************************************
		
		
		
			// ShortCut
			if ($BE_USER->mayMakeShortcut())	{
				$this->content.=$this->doc->spacer(20).$this->doc->section('',$this->doc->makeShortcutIcon("id","",$this->MCONF["name"]));
			}
			
			$this->content.=$this->doc->spacer(10);
		}
	}
	function printContent()	{
		global $SOBE;
		$this->content.=$this->doc->middle();
		$this->content.=$this->doc->endPage();
		echo $this->content;
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
	function getCountCacheTables($humanReadable)	{
		$out=array();
		$res = mysql(TYPO3_db,"SELECT count(*) FROM cache_pages");
		list($out["cache_pages"])=mysql_fetch_row($res);
		$res = mysql(TYPO3_db,"SELECT count(*) FROM cache_pagesection");
		list($out["cache_pagesection"])=mysql_fetch_row($res);
		$res = mysql(TYPO3_db,"SELECT count(*) FROM cache_hash");
		list($out["cache_hash"])=mysql_fetch_row($res);
		
		if ($humanReadable)	{
			$newOut=array();
			reset($out);
			while(list($k,$v)=each($out))	{
				$newOut[]=$k.":".$v;
			}
			$out=implode($newOut,", ");
		}
		return $out;
	}
	
	function linkWrapTemplateTitle($title,$onlyKey="")	{
		if ($onlyKey)	{
			$title = '<a href="index.php?id='.$GLOBALS["SOBE"]->id.'&e['.$onlyKey.']=1&SET[function]=0">'.$title.'</a>';
		} else {
			$title = '<a href="index.php?id='.$GLOBALS["SOBE"]->id.'&e[constants]=1&e[config]=1&SET[function]=0">'.$title.'</a>';
		}
		return $title;
	}
	function noTemplate($newStandardTemplate=0)	{
		global $SOBE;
	
		$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
		$tmpl->tt_track = 0;	// Do not log time-performance information
		$tmpl->init();
	
		$confirm = ' onClick="return confirm(\'Are you sure, you want to do this?\');"';
		
			// No template
		$theOutput.=$this->doc->spacer(10);
		$theOutput.=$this->doc->section(rfw("No template"),"There was no template on this page!<BR>Create a template record first in order to edit constants!");	
			// New standard?
		if ($newStandardTemplate)	{
			$query = "SELECT title,uid FROM static_template ORDER BY title";
			$res = mysql(TYPO3_db,$query);
			$opt="";
			while($row=mysql_fetch_assoc($res))	{
				if (substr(trim($row["title"]),0,8)=="template")	{
					$opt.='<option value="'.$row["uid"].'">'.htmlspecialchars($row["title"]).'</option>';
				}
			}
			$selector = '<select name="createStandard"><option></option>'.$opt.'</select>';
				// Extension?
			$theOutput.=$this->doc->spacer(10);
			$theOutput.=$this->doc->section("Create new website",'If you want this page to be the root of a new website, optionally based on one of the standard templates, then press the button below:<BR>
			<BR>
			'.$selector.'<BR>
			<img src="'.$GLOBALS["BACK_PATH"].'t3lib/gfx/icon_warning.gif" width=18 height=16 hspace=5 align=top><input type="Submit" name="newWebsite" value="Create template for a new site"'.$confirm.'>',0,1);	
		}
			// Extension?
		$theOutput.=$this->doc->spacer(10);
		$theOutput.=$this->doc->section("Create extension template",sprintf('An extension template allows you to enter TypoScript values that will affect only this page and subpages.<BR><BR><img src="'.$GLOBALS["BACK_PATH"].'t3lib/gfx/icon_warning.gif" width=18 height=16 hspace=5 align=top>%s<strong>Click here to create an extension template.</strong>%s','<a href="index.php?id='.$this->id.'&createExtension=1"'.$confirm.'>','</a>'),0,1);	
	
			// Go to first appearing...
		$first = $tmpl->ext_prevPageWithTemplate($this->id,$this->perms_clause);
		if ($first)	{
			$theOutput.=$this->doc->spacer(10);
			$theOutput.=$this->doc->section("Go to closest page with template",sprintf("Closest template is on page '%s' (uid %s).<BR><BR>%s<strong>Click here to go.</strong>%s",$first["title"],$first["uid"],'<a href="index.php?id='.$first["uid"].'">','</a>'),0,1);	
		}
		return $theOutput;
	}
	function templateMenu()	{
		$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
		$tmpl->tt_track = 0;	// Do not log time-performance information
		$tmpl->init();
		$all = $tmpl->ext_getAllTemplates($this->id,$this->perms_clause);
		$menu="";
		if (count($all)>1)	{
			reset($all);
			$this->MOD_MENU["templatesOnPage"]=array();
			while(list(,$d)=each($all))	{
				$this->MOD_MENU["templatesOnPage"][$d["uid"]] = $d["title"];
			}
			$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::GPvar("SET"), $this->MCONF["name"]);
			$menu = t3lib_BEfunc::getFuncMenu($this->id,"SET[templatesOnPage]",$this->MOD_SETTINGS["templatesOnPage"],$this->MOD_MENU["templatesOnPage"]);
		}
		return $menu;
	}
	function createTemplate($id)	{
		if (t3lib_div::GPvar("createExtension"))	{
			include_once(PATH_t3lib."class.t3lib_tcemain.php");
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
			$recData=array();
			$recData["sys_template"]["NEW"] = array(
				"pid" => $id,
				"title" => "+ext",
				"sorting" => time()
			);
			$tce->start($recData,Array());
			$tce->process_datamap();
		} elseif (t3lib_div::GPvar("newWebsite"))	{
			include_once(PATH_t3lib."class.t3lib_tcemain.php");
			$tce = t3lib_div::makeInstance("t3lib_TCEmain");
			$recData=array();
			if (intval(t3lib_div::GPvar("createStandard")))	{	
				$staticT = intval(t3lib_div::GPvar("createStandard"));
				$recData["sys_template"]["NEW"] = array(
					"pid" => $id,
					"title" => "NEW SITE, based on standard",
					"sorting" => 0,
					"root" => 1,
					"clear" => 3,
					"include_static" => $staticT.",57"	// 57 is cSet
				);
			} else {
				$recData["sys_template"]["NEW"] = array(
					"pid" => $id,
					"title" => "NEW SITE",
					"sorting" => 0,
					"root" => 1,
					"clear" => 3,
					"config" => '
	# Default PAGE object:
	page = PAGE
	page.typeNum = 0
	page.10 = TEXT
	page.10.value = HELLO WORLD!
					'
				);
			}
			$tce->start($recData,Array());
			$tce->process_datamap();
			$tce->clear_cacheCmd("all");
		}
	}
	// ********************************************
	// RENDER LIST of pages with templates, BEGIN
	// ********************************************
	function setInPageArray(&$pArray,$rlArr,$row)	{
		ksort($rlArr);
		reset($rlArr);
		if (!$rlArr[0]["uid"])		array_shift($rlArr);
		
		$cEl = current($rlArr);
		$pArray[$cEl["uid"]]=$cEl["title"];
		array_shift($rlArr);
		if (count($rlArr))	{
			if (!isset($pArray[$cEl["uid"]."."]))	$pArray[$cEl["uid"]."."]=array();
			$this->setInPageArray($pArray[$cEl["uid"]."."],$rlArr,$row);
		} else {
			$pArray[$cEl["uid"]."_"]=$row;
		}
	}
	function renderList($pArray,$lines=array(),$c=0)	{
		if (is_array($pArray))	{
			reset($pArray);
			while(list($k,$v)=each($pArray))	{
				if (t3lib_div::testInt($k))	{
					if (isset($pArray[$k."_"]))	{
						$lines[]='<tr bgColor="'.$this->doc->bgColor4.'">
							<td nowrap><img src=clear.gif width=1 height=1 hspace='.($c*10).' align=top>'.
							'<a href="'.t3lib_div::linkThisScript(array("id"=>$k)).'">'.
							t3lib_iconWorks::getIconImage("pages",t3lib_BEfunc::getRecord("pages",$k),$GLOBALS["BACK_PATH"]," align=top".t3lib_BEfunc::titleAttrib("ID: ".$k)).
							t3lib_div::fixed_lgd($pArray[$k],30).'</a></td>
							<td align=center>'.$pArray[$k."_"]["count"].'</td>
							<td align=center>'.($pArray[$k."_"]["root_max_val"]>0?"x":"&nbsp;").'</td>
							<td align=center>'.($pArray[$k."_"]["root_min_val"]==0?"x":"&nbsp;").'</td>
							</tr>';
					} else {
						$lines[]='<tr>
							<td nowrap colspan=3><img src=clear.gif width=1 height=1 hspace='.($c*10).' align=top>'.
							t3lib_iconWorks::getIconImage("pages",t3lib_BEfunc::getRecord("pages",$k),$GLOBALS["BACK_PATH"]," align=top").
							t3lib_div::fixed_lgd($pArray[$k],30).'</td>
							</tr>';
					}
					$lines=$this->renderList($pArray[$k."."],$lines,$c+1);
				}
			}
		}
		return $lines;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/index.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/index.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_mod_web_ts_index");
$SOBE->init();

// Include files?
reset($SOBE->include_once);	
while(list(,$INC_FILE)=each($SOBE->include_once))	{include_once($INC_FILE);}

$SOBE->clearCache();
$SOBE->main();
$SOBE->printContent();
?>