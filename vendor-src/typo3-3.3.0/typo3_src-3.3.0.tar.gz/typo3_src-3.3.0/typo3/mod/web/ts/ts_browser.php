<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TypoScript Constant editor
 *
 * Module Include-file
 *
 * localconf-variables:
 * $TYPO3_CONF_VARS["MODS"]["web_ts"]["onlineResourceDir"] = "fileadmin/fonts/";		// This is the path (must be in "fileadmin/" !!) where the web_ts/constant-editor submodule fetches online resources. Put fonts (ttf) and standard images here!
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 

class ts_browser {

	function verify_TSobjects($propertyArray,$parentType,$parentValue)	{
		$TSobjTable = array(
			"PAGE" => array(
				"prop" => array (
					"typeNum" => "int",
					"1,2,3" => "COBJ",
					"bodyTag" => "string"
				)
			),
			"TEXT" => array(
				"prop" => array (
					"value" => "string"
				)
			),
			"HTML" => array(
				"prop" => array (
					"value" => "stdWrap"
				)
			),
			"stdWrap" => array(
				"prop" => array (
					"field" => "string",
					"current" => "boolean"
				)
			),
		);
		$TSobjDataTypes = array(
			"COBJ" => "TEXT,CONTENT",
			"PAGE" => "PAGE",
			"stdWrap" => ""
		);
		debug($propertyArray);
	
		if ($parentType)	{
			if (isset($TSobjDataTypes[$parentType]) && (!$TSobjDataTypes[$parentType] || t3lib_div::inlist($TSobjDataTypes[$parentType],$parentValue)))	{
				$ObjectKind = $parentValue;
			} else {
				$ObjectKind = ""; 	// Object kind is "" if it should be known.
			}
		} else {
			$ObjectKind = $parentValue;	// If parentType is not given, then it can be anything. Free.
		}
	
		if ($ObjectKind && is_array($TSobjTable[$ObjectKind]))	{
			$result=array();
			if (is_array($propertyArray))		{
				reset($propertyArray);
				while(list($key,$val)=each($propertyArray))	{
					if (t3lib_div::testInt($key))	{	// If num-arrays
						$result[$key]=$TSobjTable[$ObjectKind]["prop"]["1,2,3"];
					} else {	// standard
						$result[$key]=$TSobjTable[$ObjectKind]["prop"][$key];
					}
				}
			}
			return $result;
		}
	}
	function initialize_editor($pageId,$template_uid=0)	{
			// Initializes the module. Done in this function because we may need to re-initialize if data is submitted!
		global $tmpl,$tplRow,$theConstants;
		
		$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
		$tmpl->tt_track = 0;	// Do not log time-performance information
		$tmpl->init();
		
				// Gets the rootLine
		$sys_page = t3lib_div::makeInstance("t3lib_pageSelect");
		$rootLine = $sys_page->getRootLine($pageId);
		$tmpl->runThroughTemplates($rootLine,$template_uid);	// This generates the constants/config + hierarchy info for the template.
	
		$tplRow = $tmpl->ext_getFirstTemplate($pageId,$template_uid);	// Get the row of the first VISIBLE template of the page. whereclause like the frontend.
		if (is_array($tplRow))	{	// IF there was a template...
			return 1;
		}
	}
	function main()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $tmpl,$tplRow,$theConstants;
		
		// **************************
		// Checking for more than one template an if, set a menu...
		// **************************
		$manyTemplatesMenu = $SOBE->templateMenu();
		$template_uid = 0;
		if ($manyTemplatesMenu)	{
			$template_uid = $SOBE->MOD_SETTINGS["templatesOnPage"];
		}
		
		
		
		
		
		// **************************
		// Main
		// **************************
		
		// BUGBUG: Should we check if the uset may at all read and write template-records???
		$bType= $SOBE->MOD_SETTINGS["ts_browser_type"];
		$existTemplate = $this->initialize_editor($SOBE->id,$template_uid);		// initialize
		if ($existTemplate)	{
			$theOutput.=$SOBE->doc->divider(5);
			$theOutput.=$SOBE->doc->section("Current template:",'<img src="'.$BACK_PATH.t3lib_iconWorks::getIcon("sys_template",$tplRow).'" width=18 height=16 align=top><b>'.$SOBE->linkWrapTemplateTitle($tplRow["title"], ($bType=="setup"?"config":"constants")).'</b>'.(trim($tplRow["sitetitle"])?' - ('.$tplRow["sitetitle"].')':''),0,0);
			if ($manyTemplatesMenu)	{
				$theOutput.=$SOBE->doc->section("",$manyTemplatesMenu);
				$theOutput.=$SOBE->doc->divider(5);
			}
		
			if ($GLOBALS["HTTP_POST_VARS"]["add_property"] || $GLOBALS["HTTP_POST_VARS"]["update_value"] || $GLOBALS["HTTP_POST_VARS"]["clear_object"])	{
					// add property
				$line="";
		//		debug($GLOBALS["HTTP_POST_VARS"]);
				if (is_array($GLOBALS["HTTP_POST_VARS"]["data"]))	{
					if ($GLOBALS["HTTP_POST_VARS"]["add_property"])	{
						reset($GLOBALS["HTTP_POST_VARS"]["data"]);
						$name = key($GLOBALS["HTTP_POST_VARS"]["data"]);
						$property = trim($GLOBALS["HTTP_POST_VARS"]["data"][$name]["name"]);
						if (ereg_replace("[^a-zA-Z0-9_\.]*","",$property)!=$property)	{
							$theOutput.=$SOBE->doc->spacer(10);
							$theOutput.=$SOBE->doc->section(rfw("BAD PROPERTY!"),'You must enter a property with characters a-z, A-Z and 0-9, no spaces!<BR>Nothing was updated!',0,0);
						} else {
							$pline= $name.".".$property." = ".trim(stripslashes($GLOBALS["HTTP_POST_VARS"]["data"][$name]["propertyValue"]));
							$theOutput.=$SOBE->doc->spacer(10);
							$theOutput.=$SOBE->doc->section(rfw("PROPERTY ADDED"),htmlspecialchars($pline),0,0);
							$line.=chr(10).$pline;
						}
					}
					if ($GLOBALS["HTTP_POST_VARS"]["update_value"])	{
						reset($GLOBALS["HTTP_POST_VARS"]["data"]);
						$name = key($GLOBALS["HTTP_POST_VARS"]["data"]);
						$pline= $name." = ".trim(stripslashes($GLOBALS["HTTP_POST_VARS"]["data"][$name]["value"]));
						$theOutput.=$SOBE->doc->spacer(10);
						$theOutput.=$SOBE->doc->section(rfw("VALUE UPDATED"),htmlspecialchars($pline),0,0);
						$line.=chr(10).$pline;
					}
					if ($GLOBALS["HTTP_POST_VARS"]["clear_object"])	{
						reset($GLOBALS["HTTP_POST_VARS"]["data"]);
						$name = key($GLOBALS["HTTP_POST_VARS"]["data"]);
						if ($GLOBALS["HTTP_POST_VARS"]["data"][$name]["clearValue"])	{
							$pline= $name." >";
							$theOutput.=$SOBE->doc->spacer(10);
							$theOutput.=$SOBE->doc->section(rfw("Object cleared"),htmlspecialchars($pline));
							$line.=chr(10).$pline;
						}
					}
				}
				if ($line)	{
					include_once(PATH_t3lib."class.t3lib_tcemain.php");
						// Set the data to be saved
					$recData=array();
					$field =$bType=="setup"?"config":"constants";
					$recData["sys_template"][$tplRow[uid]][$field] = addslashes($tplRow[$field].$line);
						// Create new  tce-object
					$tce = t3lib_div::makeInstance("t3lib_TCEmain");
						// Initialize
					$tce->start($recData,Array());
						// Saved the stuff
					$tce->process_datamap();
						// Clear the cache (note: currently only admin-users can clear the cache in tce_main.php)
					$tce->clear_cacheCmd("all");
						
						// re-read the template ...
					$this->initialize_editor($SOBE->id,$template_uid);
				}
			}
		}
		
		$update=0;
		if (is_array($GLOBALS["HTTP_GET_VARS"]["tsbr"]))	{		// If any plus-signs were clicked, it's registred.
			$SOBE->MOD_SETTINGS["tsbrowser_depthKeys_".$bType] = $tmpl->ext_depthKeys($GLOBALS["HTTP_GET_VARS"]["tsbr"], $SOBE->MOD_SETTINGS["tsbrowser_depthKeys_".$bType]);
			$update=1;
		}
		if (is_array($GLOBALS["HTTP_GET_VARS"]["addKey"]))	{		// If any plus-signs were clicked, it's registred.
			reset($GLOBALS["HTTP_GET_VARS"]["addKey"]);
			if (current($GLOBALS["HTTP_GET_VARS"]["addKey"]))	{
				$SOBE->MOD_SETTINGS["ts_browser_TLKeys_".$bType][key($GLOBALS["HTTP_GET_VARS"]["addKey"])] = key($GLOBALS["HTTP_GET_VARS"]["addKey"]);
			} else {
				unset($SOBE->MOD_SETTINGS["ts_browser_TLKeys_".$bType][key($GLOBALS["HTTP_GET_VARS"]["addKey"])]);
			}
			$update=1;
		}
		if ($GLOBALS["HTTP_POST_VARS"]["Submit"])	{		// If any POST-vars are send, update the condition array
			$SOBE->MOD_SETTINGS["tsbrowser_conditions"] = $GLOBALS["HTTP_POST_VARS"]["conditions"];
			$update=1;
		}
		if ($update){	$GLOBALS["BE_USER"]->pushModuleData($SOBE->MCONF["name"],$SOBE->MOD_SETTINGS);}
		
		
		$tmpl->matchAlternative = $SOBE->MOD_SETTINGS["tsbrowser_conditions"];
		$tmpl->matchAlternative[] = "dummydummydummydummydummydummydummydummydummydummydummy";	// This is just here to make sure that at least one element is in the array so that the tsparser actually uses this array to match.
		
		$tmpl->constantMode = $SOBE->MOD_SETTINGS["ts_browser_fixedLgd"] ? "" : $SOBE->MOD_SETTINGS["ts_browser_const"];
		if ($SOBE->sObj && $tmpl->constantMode)	{$tmpl->constantMode = "untouched";}
		
		$tmpl->regexMode = $SOBE->MOD_SETTINGS["ts_browser_regexsearch"];
		$tmpl->fixedLgd=$SOBE->MOD_SETTINGS["ts_browser_fixedLgd"];
		$tmpl->linkObjects=$SOBE->MOD_SETTINGS["ts_browser_linkObjects"];
		$tmpl->bType=$bType;
		$tmpl->resourceCheck=1;
		$tmpl->uplPath = PATH_site.$tmpl->uplPath;
		$tmpl->removeFromGetFilePath = PATH_site;
		//debug($tmpl->uplPath);
		
		if ($SOBE->MOD_SETTINGS["ts_browser_type"]=="const")	{
			$tmpl->ext_constants_BRP=intval(t3lib_div::GPvar("breakPointLN"));
		} else {
			$tmpl->ext_config_BRP=intval(t3lib_div::GPvar("breakPointLN"));
		}
		$tmpl->generateConfig();
		
		if ($bType=="setup")	{
			$theSetup = $tmpl->setup;
		} else {
			$theSetup = $tmpl->setup_constants;
		}
		
			// EDIT A VALUE:
		if ($SOBE->sObj)	{
			list($theSetup,$theSetupValue) = $tmpl->ext_getSetup($theSetup, ($SOBE->sObj?$SOBE->sObj:""));
			$theOutput.=$SOBE->doc->divider(5);
			if ($existTemplate)	{
					// Value
				$out="";
				$out=$SOBE->sObj." =<BR>";
				$out.='<input type="Text" name="data['.$SOBE->sObj.'][value]" value="'.htmlspecialchars($theSetupValue).'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(40).'>';
				$out.='<input type="Submit" name="update_value" value="Update">';
				$theOutput.=$SOBE->doc->section("Edit object/property value:",$out,0,0);
		
					// Property
				$url=$BACK_PATH."wizard_tsconfig.php?mode=tsref&onlyProperty=1";
				$params=array();
				$params["formName"]="editForm";
				$params["itemName"]="data[".$SOBE->sObj."][name]";
				$TSicon='<a href="#" onClick="vHWin=window.open(\''.$url.t3lib_div::implodeArrayForUrl("",array("P"=>$params)).'\',\'popUp'.$md5ID.'\',\'height=500,width=780,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="'.$BACK_PATH.'gfx/wizard_tsconfig_s.gif" width="22" height="16" border="0"'.t3lib_BEfunc::titleAttrib("TSref reference").' align=absmiddle hspace=2></a>';
		
				$out="";
				$out="<nobr>".$SOBE->sObj.".";
				$out.='<input type="Text" name="data['.$SOBE->sObj.'][name]"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(20).'>'.$TSicon.' = </nobr><BR>';
				$out.='<input type="Text" name="data['.$SOBE->sObj.'][propertyValue]"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(40).'>';
				$out.='<input type="Submit" name="add_property" value="Add">';
		
		
				
				$theOutput.=$SOBE->doc->spacer(20);
				$theOutput.=$SOBE->doc->section("Add object property:",$out,0,0);
					
					// clear
				$out="";
				$out=$SOBE->sObj." <b>CLEAR?</b> &nbsp;&nbsp;";
				$out.='<input type="Checkbox" name="data['.$SOBE->sObj.'][clearValue]" value="1">';
				$out.='<input type="Submit" name="clear_object" value="Clear">';
				$theOutput.=$SOBE->doc->spacer(20);
				$theOutput.=$SOBE->doc->section("Clear object:",$out,0,0);
		
				$theOutput.=$SOBE->doc->spacer(10);
			} else {
				$theOutput.=$SOBE->doc->section("EDIT:",rfw("You cannot edit properties and values, if there's no current template."),0,0);
			}
				// Links:
			$out="";
			if (!$SOBE->MOD_SETTINGS["ts_browser_TLKeys_".$bType][$SOBE->sObj])	{
				if (count($theSetup))	{
					$out = '<a href="index.php?id='.$SOBE->id.'&addKey['.$SOBE->sObj.']=1&SET[ts_browser_toplevel_'.$bType.']='.rawurlencode($SOBE->sObj).'"><b>Add key</b></a> "'.$SOBE->sObj.'" to Object List (OL)';
				}
			} else {
				$out = '<a href="index.php?id='.$SOBE->id.'&addKey['.$SOBE->sObj.']=0&SET[ts_browser_toplevel_'.$bType.']=0"><b>Remove key</b></a> "'.$SOBE->sObj.'" from Object List (OL)';
			}
			if ($out)	{
				$theOutput.=$SOBE->doc->divider(5);
				$theOutput.=$SOBE->doc->section("",$out);
			}
			
				// back
			$out = "< Back";
			$out = '<a href="index.php?id='.$SOBE->id.'"><b>'.$out.'</b></a>';
			$theOutput.=$SOBE->doc->divider(5);
			$theOutput.=$SOBE->doc->section("",$out);
		
		} else {
			$tmpl->tsbrowser_depthKeys=$SOBE->MOD_SETTINGS["tsbrowser_depthKeys_".$bType];
		//	debug($tmpl->tsbrowser_depthKeys);
		
			$HTTP_POST_VARS["search_field"] = stripslashes($HTTP_POST_VARS["search_field"])	;
			if ($GLOBALS["HTTP_POST_VARS"]["search"] && $GLOBALS["HTTP_POST_VARS"]["search_field"])	{		// If any POST-vars are send, update the condition array
				$tmpl->tsbrowser_depthKeys=$tmpl->ext_getSearchKeys($theSetup, "",	$GLOBALS["HTTP_POST_VARS"]["search_field"], array());
		//		debug($tmpl->tsbrowser_depthKeys);
		//		debug($tmpl->tsbrowser_searchKeys);
			}
		
			
		
			// Expanding menu 
		/*	if (is_array($theSetup))	{
				reset($theSetup);
				while(list($tkey,$tval)=each($theSetup))	{
					if (substr($tkey,-1)==".")	{
						$tkey=substr($tkey,0,-1);
					}
					if ($theSetup[$tkey."."] && $tkey!="types" && $tkey!="TSConstantEditor")	{
						$SOBE->MOD_MENU["ts_browser_toplevel_".$bType][$tkey]=$tkey;
					}
				}
			}*/
			if (count($SOBE->MOD_SETTINGS["ts_browser_TLKeys_".$bType]))	{
		//		$SOBE->MOD_MENU["ts_browser_toplevel_".$bType]["-"]="---";
				$SOBE->MOD_MENU["ts_browser_toplevel_".$bType] = $SOBE->MOD_MENU["ts_browser_toplevel_".$bType] + $SOBE->MOD_SETTINGS["ts_browser_TLKeys_".$bType];
			}
		
		//	debug($SOBE->MOD_MENU["ts_browser_toplevel"]);
			
			$theOutput.=$SOBE->doc->spacer(5);
			$theOutput.=$SOBE->doc->section("Object tree:","",0,1);
		
			$menu = "Browse: ".t3lib_BEfunc::getFuncMenu($SOBE->id,"SET[ts_browser_type]",$bType,$SOBE->MOD_MENU["ts_browser_type"]);
			$menu.= "&nbsp;&nbsp;OL: ".t3lib_BEfunc::getFuncMenu($SOBE->id,"SET[ts_browser_toplevel_".$bType."]",$SOBE->MOD_SETTINGS["ts_browser_toplevel_".$bType],$SOBE->MOD_MENU["ts_browser_toplevel_".$bType]);
			$theOutput.=$SOBE->doc->section("",'<NOBR>'.$menu.'</NOBR>');
		
		
			$theKey=$SOBE->MOD_SETTINGS["ts_browser_toplevel_".$bType];
			if (!$theKey || !str_replace("-","",$theKey))	{$theKey="";}
			list($theSetup,$theSetupValue) = $tmpl->ext_getSetup($theSetup, ($SOBE->MOD_SETTINGS["ts_browser_toplevel_".$bType]?$SOBE->MOD_SETTINGS["ts_browser_toplevel_".$bType]:""));
			$tree = $tmpl->ext_getObjTree($theSetup, $theKey, "", "", $theSetupValue);
			$tree = $tmpl->substituteCMarkers($tree);
		
			
			
				// Parser Errors:
			$pEkey = ($bType=="setup"?"config":"constants");
			if (count($tmpl->parserErrors[$pEkey]))	{
				reset($tmpl->parserErrors[$pEkey]);
				$errMsg=array();
				while(list(,$inf)=each($tmpl->parserErrors[$pEkey]))	{
					$errMsg[]=($inf[1]).": &nbsp; &nbsp;".$inf[0];
				}
				$theOutput.=$SOBE->doc->spacer(10);
				$theOutput.=$SOBE->doc->section(rfw("Errors and warnings"),fw(implode($errMsg,"<BR>")),0,1);
			}
		
			
			
			if (isset($SOBE->MOD_SETTINGS["ts_browser_TLKeys_".$bType][$theKey]))	{
				$remove='<td width="1%" nowrap><a href="index.php?id='.$SOBE->id.'&addKey['.$theKey.']=0&SET[ts_browser_toplevel_'.$bType.']=0"><b>'.fw('Remove key from OL').'</b></a></td>';
			} else {
				$remove="";
			}
			$label = $theKey ? $theKey : ($bType=="setup"?"SETUP ROOT":"CONSTANTS ROOT");
			$theOutput.=$SOBE->doc->spacer(15);
			$theOutput.=$SOBE->doc->sectionEnd();
			$theOutput.='<table border=0 cellpadding=1 cellspacing=0>';
			$theOutput.='<tr>
						<td><img src=clear.gif width='.($SOBE->doc->lMarg*2).' height=1></td>
						<td bgcolor="'.$SOBE->doc->bgColor2.'">
							<table border=0 cellpadding=0 cellspacing=0 bgcolor="'.$SOBE->doc->bgColor5.'" width="100%"><tr><td nowrap width="99%"><b>'.fw($label).'</b></td>'.$remove.'</tr></table>			
						</td>
					</tr>';
			$theOutput.='<tr>
						<td><img src=clear.gif width='.($SOBE->doc->lMarg*2).' height=1></td>
						<td bgcolor="'.$SOBE->doc->bgColor2.'">
							<table border=0 cellpadding=0 cellspacing=0 bgcolor="#D9D5C9" width="100%"><tr><td nowrap>'.$tree.'</td></tr></table><img src=clear.gif width=465 height=1></td>
					</tr>
				</table>
			';
		
		
				// Conditions:
			if (is_array($tmpl->sections))	{
				$theOutput.=$SOBE->doc->divider(15);
				
				$out="";
				reset($tmpl->sections);
				while(list($key,$val)=each($tmpl->sections))	{
					$out.='<tr><td><input type="Checkbox" name="conditions['.$key.']" value="'.htmlspecialchars($val).'"'.($SOBE->MOD_SETTINGS["tsbrowser_conditions"][$key]?" checked":"").'></td><td nowrap>'.fw(htmlspecialchars($val)."&nbsp;&nbsp;").'</td></tr>';
				}
				$theOutput.='
					<table border=0 cellpadding=1 cellspacing=0>
						<tr>
							<td><img src=clear.gif width='.($SOBE->doc->lMarg*2).' height=1></td>
							<td bgcolor="'.$SOBE->doc->bgColor2.'">
								<table border=0 cellpadding=0 cellspacing=0 bgcolor="#D9D5C9">'.$out.'
								<tr>
									<td>&nbsp;</td>
									<td><img src=clear.gif height=10 width=240><BR><input type="Submit" name="Submit" value="Set conditions"><BR></td>
								</tr>
								</table>			
							</td>
						</tr>
					</table>
					
				';
			}
		
				// Search:
			$theOutput.='<br>
			
				<table border=0 cellpadding=1 cellspacing=0>
					<tr>
						<td><img src=clear.gif width='.($SOBE->doc->lMarg*2).' height=1></td>
						<td bgcolor="'.$SOBE->doc->bgColor2.'">
							<table border=0 cellpadding=0 cellspacing=0 bgcolor="#D9D5C9">
							<tr>
								<td>'.fw("&nbsp;Enter search phrase:&nbsp;&nbsp;").'<input type="Text" name="search_field" value="'.htmlspecialchars($HTTP_POST_VARS["search_field"]).'"'.$GLOBALS["TBE_TEMPLATE"]->formWidth(20).'></td>
								<td><input type="Submit" name="search" value="Search"></td>
							</tr>
							<tr>
								<td>'.fw("&nbsp;Use ereg(), not stristr():&nbsp;&nbsp;").t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_browser_regexsearch]",$SOBE->MOD_SETTINGS["ts_browser_regexsearch"]).'</td>
								<td>&nbsp;</td>
							</tr>
							</table>			
						</td>
					</tr>
				</table>
			<br>
			';
		
				// Menu in the bottom:
			$menu= "Crop lines".t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_browser_fixedLgd]",$SOBE->MOD_SETTINGS["ts_browser_fixedLgd"]);
			$menu.= "&nbsp;&nbsp;Enable object links".t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_browser_linkObjects]",$SOBE->MOD_SETTINGS["ts_browser_linkObjects"]);
			if ($bType=="setup" && !$SOBE->MOD_SETTINGS["ts_browser_fixedLgd"])	{
				$menu.= "<BR>Constants display: ".t3lib_BEfunc::getFuncMenu($SOBE->id,"SET[ts_browser_const]",$SOBE->MOD_SETTINGS["ts_browser_const"],$MOD_MENU["ts_browser_const"]);
			}
			$theOutput.=$SOBE->doc->section("",'<NOBR>'.$menu.'</NOBR>');
			
			$theOutput.=$SOBE->doc->spacer(10);
			$theOutput.=$SOBE->doc->section("Cache",'Click here to <a href="index.php?id='.$SOBE->id.'&clear_all_cache=1"><strong>clear all cache</strong></a>',0,1);
			
				// Ending section:
			$theOutput.=$SOBE->doc->sectionEnd();
		}
		return $theOutput;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_browser.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_browser.php"]);
}

?>