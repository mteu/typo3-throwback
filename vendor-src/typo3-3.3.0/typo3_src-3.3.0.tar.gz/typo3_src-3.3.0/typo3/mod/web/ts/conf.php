<?php
define("TYPO3_MOD_PATH", "mod/web/ts/");
$BACK_PATH="../../../";

$MLANG["default"]["labels"]["tablabel"] = "Template tools";
$MLANG["default"]["tabs"]["tab"] = "Template";
$MLANG["default"]["tabs_images"]["tab"] = "ts1.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Here you manage the TypoScript templates which are in charge of the look of your website on the frontend. The module provides specialized features like an object browser, a constant editor and raw editing facilities.<BR><em>Access for 'admin' users only!</em>";

$MLANG["dk"]["labels"]["tablabel"] = "Skabelon v�rkt�jer";
$MLANG["dk"]["tabs"]["tab"] = "Skabelon";
$MLANG["dk"]["labels"]["tabdescr"] = "Her bearbejder du dine TypoScript skabeloner som er afg�rende for udseendet af dit website. Modulet giver dig adgang til specielle funktioner s�som en 'Object Browser', 'Constant Editor' samt egentlige redigeringsfaciliteter.<BR><em>Adgang kun for 'admin' brugere!</em>";

$MLANG["de"]["labels"]["tablabel"] = "Template Werkzeuge";
$MLANG["de"]["labels"]["tabdescr"] = "Hier k�nnen Sie die TypoScript Templates verwalten. Diese Templates sind f�r das Erscheinungsbild Ihrer Webseite verantwortlich. Das Modul bietet spezielle Funktionen wie einen Objekt-Browser, einen Konstanteneditor und einfache Bearbeitungsm�glichkeiten.<BR><em>Zugriff nur f�r Administratoren!</em>";
$MLANG["de"]["tabs"]["tab"] = "Template";

$MLANG["no"]["labels"]["tablabel"] = "Mal verkt�y";
$MLANG["no"]["labels"]["tabdescr"] = "Her arbeider du med dine TypoScript maler som er avgj�rende for utseendet p� webomr�det ditt. Modulen gir deg adgang til spesielle funksjoner slik som 'Objekt Browser', 'Constant Editor' samt egentlige redigeringsfasiliteter. <BR><em>Kun adgang for 'admin' brukere!</em>";
$MLANG["no"]["tabs"]["tab"] = "Mal";

$MLANG["it"]["labels"]["tablabel"] = "Strumenti templates";
$MLANG["it"]["labels"]["tabdescr"] = "Attraverso questo modulo potete gestire i template Typoscript, che sono responsabili del layout del sito web. Il modulo offre speciali funzioni, tra le quali l'object browser e l'editor di costanti.<br><em>L'accesso � consentito solo agli utenti 'Admin'!</em> ";
$MLANG["it"]["tabs"]["tab"] = "Template";

$MLANG["fr"]["labels"]["tablabel"] = "Outils de gabarit.";
$MLANG["fr"]["labels"]["tabdescr"] = "Ici, vous pouvez manipuler les Gabarit TypoScript qui sont en charge de l'aspect visuel de votre site. <br><em>Acc�s r�serv� � l'Administrateur, uniquement!<em>";
$MLANG["fr"]["tabs"]["tab"] = "Gabarit";

$MLANG["es"]["labels"]["tablabel"] = "Herramientas de Templates";
$MLANG["es"]["labels"]["tabdescr"] = "El m�dulo WebList provee del acceso a mas bajo nivel de los registros que forman una p�gina. En tanto que los otros m�dulos est�n especializados en cietas operaciones en ciertas tablas, este m�dulo permite el acceso total a los registros en crudo disponibles para el usuario.";
$MLANG["es"]["tabs"]["tab"] = "Template";

$MLANG["nl"]["labels"]["tablabel"] = "Sjabloon werkset";
$MLANG["nl"]["labels"]["tabdescr"] = "Hier regel je de TypoScriptsjablonen die bepalen hoe je website er uit gaat zien. Deze module biedt gespecialiseerde onderdelen zoals een 'object browser', een 'constant editor' en simpele mogelijkheden om variabelen te aan te passen.<BR><em>Alleen toegankelijk voor 'admin' gebruikers!</em> ";
$MLANG["nl"]["tabs"]["tab"] = "Sjabloon";

$MLANG["cz"]["labels"]["tablabel"] = "N�stroje pro �ablony";
$MLANG["cz"]["labels"]["tabdescr"] = "Zde ovl�d�te �ablony Typoscriptu, kter� odpov�daj� za vzhled va�eho website ve frontendu. Tento modul m� specializovan� funkce jako je prohl�e� objekt�, editor konstant a p��m� editovac� mo�nosti.<BR><em>P��stup pouze pro 'admin' u�ivatele!</em>";
$MLANG["cz"]["tabs"]["tab"] = "�ablona";

$MLANG["pl"]["labels"]["tablabel"] = "Narz�dzia szablonu";
$MLANG["pl"]["labels"]["tabdescr"] = "Tutaj zarz�dzasz szablonami, kt�re s� odpowiedzialne za wygl�d witryny. Modu� umo�liwia przegl�danie obiekt�w i edycj�.<br><em>Dost�p tylko dla administrator�w!</em>";
$MLANG["pl"]["tabs"]["tab"] = "Szablon";

$MLANG["si"]["labels"]["tablabel"] = "Orodja za predloge";
$MLANG["si"]["tabs"]["tab"] = "Predloge";
$MLANG["si"]["labels"]["tabdescr"] = "Tukaj urejate TypoScript predloge, ki so osnova izgleda va�ih strani. Modul ima posebne mo�nosti kot so pregledovalnik objektov, a urejevalnik konstant in neobdelanega besedila.<BR><em>Uporaba je dovoljena le 'admin' uporabnikom!</em>";

$MLANG["fi"]["labels"]["tablabel"] = "Malli ty�kalut";
$MLANG["fi"]["labels"]["tabdescr"] = "T��ll� hoidat TypoScript mmalleja, joiden avulla www-sivusi saavat ulkon�k�ns�. Moduli sis�lt�� ominaisuuksia kuten objekstien selailua, m��ritysten muotilua ja suoria editointi mahdollisuuksia.<BR><em>Oikeudet vain 'Admin' k�ytt�jille!</em>";
$MLANG["fi"]["tabs"]["tab"] = "Malli";

$MLANG["tr"]["labels"]["tablabel"] = "�ablon ara�lar�";
$MLANG["tr"]["tabs"]["tab"] = "�ablon";
$MLANG["tr"]["labels"]["tabdescr"] = "Burada websitenizin �nplan� �zerinde olan Typoscript �ablonlar�n� kontroll� bir �ekilde bakarak y�netebilirsiniz. Bu mod�l uzmanla�m�� �zellikleri sa�lar taray�c� madde, s�rekli d�zenleyici ve hen�z yap�lmam�� donan�mlar gibi.<BR><em>Sadece kullan�c�lar�n 'y�netim' i�in ge�i�i!</em>";


$MCONF["script"]="index.php";
$MCONF["access"]="admin";		// If this is changed so not only admin-users can manipulate templates, there need to be done something with the constant editor that are not allowed to "clear all cache" then!!
$MCONF["name"]="web_ts";
?>