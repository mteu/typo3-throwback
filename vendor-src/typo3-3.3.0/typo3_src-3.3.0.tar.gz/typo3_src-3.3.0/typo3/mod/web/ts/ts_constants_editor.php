<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TypoScript Constant editor
 *
 * Module Include-file
 *
 * localconf-variables:
 * $TYPO3_CONF_VARS["MODS"]["web_ts"]["onlineResourceDir"] = "fileadmin/fonts/";		// This is the path (must be in "fileadmin/" !!) where the web_ts/constant-editor submodule fetches online resources. Put fonts (ttf) and standard images here!
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
class ts_constants_editor {
	
	function initialize_editor($pageId,$template_uid=0)	{
			// Initializes the module. Done in this function because we may need to re-initialize if data is submitted!
		global $tmpl,$tplRow,$theConstants;
		
		$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
		$tmpl->tt_track = 0;	// Do not log time-performance information
		$tmpl->init();
		
		$tplRow = $tmpl->ext_getFirstTemplate($pageId,$template_uid);	// Get the row of the first VISIBLE template of the page. whereclause like the frontend.
		if (is_array($tplRow))	{	// IF there was a template...
				// Gets the rootLine
			$sys_page = t3lib_div::makeInstance("t3lib_pageSelect");
			$rootLine = $sys_page->getRootLine($pageId);
			$tmpl->runThroughTemplates($rootLine,$template_uid);	// This generates the constants/config + hierarchy info for the template.
			$theConstants = $tmpl->generateConfig_constants();	// The editable constants are returned in an array.
			$tmpl->ext_categorizeEditableConstants($theConstants);	// The returned constants are sorted in categories, that goes into the $tmpl->categories array
			$tmpl->ext_regObjectPositions($tplRow["constants"]);		// This array will contain key=[expanded constantname], value=linenumber in template. (after edit_divider, if any)
			return 1;
		}
	}
	function displayExample($theOutput)	{
		global $SOBE,$tmpl;
		if ($tmpl->helpConfig["imagetag"] || $tmpl->helpConfig["description"] || $tmpl->helpConfig["header"])	{
	//		$theOutput.=$SOBE->doc->divider(20);
			$theOutput.=$SOBE->doc->spacer(30);
			$theOutput.=$SOBE->doc->section($tmpl->helpConfig["header"],
				'<div align="center">'.$tmpl->helpConfig["imagetag"].'</div><BR>'.
				($tmpl->helpConfig["description"] ? implode(explode("//",$tmpl->helpConfig["description"]),"<BR>")."<BR>" : "").
				($tmpl->helpConfig["bulletlist"] ? "<ul><li>".implode(explode("//",$tmpl->helpConfig["bulletlist"]),"<li>")."</ul>" : "<BR>")
				);
		}
		return $theOutput;
	}
	
	function main()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $tmpl,$tplRow,$theConstants;
	
			
		// **************************
		// Create extension template
		// **************************
		$GLOBALS["SOBE"]->createTemplate($SOBE->id);
		
		
		
		
		// **************************
		// Checking for more than one template an if, set a menu...
		// **************************
		$manyTemplatesMenu = $GLOBALS["SOBE"]->templateMenu();
		$template_uid = 0;
		if ($manyTemplatesMenu)	{
			$template_uid = $GLOBALS["SOBE"]->MOD_SETTINGS["templatesOnPage"];
		}
		
		
		
		// **************************
		// Main
		// **************************
		
		// BUGBUG: Should we check if the uset may at all read and write template-records???
		$existTemplate = $this->initialize_editor($SOBE->id,$template_uid);		// initialize
		
		if ($existTemplate)	{
				// Update template ?
		//	debug($GLOBALS["HTTP_POST_VARS"]);
		//	debug($GLOBALS["HTTP_POST_FILES"]);
			if ($GLOBALS["HTTP_POST_VARS"]["submit"])	{
				include_once(PATH_t3lib."class.t3lib_tcemain.php");
				$tmpl->changed=0;
				$tmpl->ext_procesInput($GLOBALS["HTTP_POST_VARS"],$GLOBALS["HTTP_POST_FILES"],$theConstants,$tplRow);
		//		debug($tmpl->changed);
		//		debug($tmpl->raw);
		//		$tmpl->changed=0;
				if ($tmpl->changed)	{
						// Set the data to be saved
					$recData=array();
					$recData["sys_template"][$tplRow[uid]]["constants"] = addslashes(implode($tmpl->raw,chr(10)));
						// Create new  tce-object
					$tce = t3lib_div::makeInstance("t3lib_TCEmain");
						// Initialize
					$tce->start($recData,Array());
						// Saved the stuff
					$tce->process_datamap();
						// Clear the cache (note: currently only admin-users can clear the cache in tce_main.php)
					$tce->clear_cacheCmd("all");
						
						// re-read the template ...
					$this->initialize_editor($SOBE->id,$template_uid);
				}
			}
			
			// Output edit form
			$tmpl->ext_readDirResources($TYPO3_CONF_VARS["MODS"]["web_ts"]["onlineResourceDir"]);
			$tmpl->ext_resourceDims();
			
				// Resetting the menu (start). I wonder if this in any way is a violation of the menu-system. Haven't checked. But need to do it here, because the menu is dependent on the categories available.
			$GLOBALS["SOBE"]->MOD_MENU["constant_editor_cat"] = $tmpl->ext_getCategoryLabelArray();
			$GLOBALS["SOBE"]->MOD_SETTINGS = t3lib_BEfunc::getModuleData($GLOBALS["SOBE"]->MOD_MENU, t3lib_div::GPvar("SET"), $GLOBALS["SOBE"]->MCONF["name"]);
				// Resetting the menu (stop)
				
			$theOutput.=$SOBE->doc->spacer(5);
			$theOutput.=$SOBE->doc->section("Edit constants for template:",'<img src="'.$BACK_PATH.t3lib_iconWorks::getIcon("sys_template",$tplRow).'" width=18 height=16 align=top><b>'.$GLOBALS["SOBE"]->linkWrapTemplateTitle($tplRow["title"],"constants").'</b>'.(trim($tplRow["sitetitle"])?' - ('.$tplRow["sitetitle"].')':''),0,1);
			if ($manyTemplatesMenu)	{
				$theOutput.=$SOBE->doc->section("",$manyTemplatesMenu);
				$theOutput.=$SOBE->doc->divider(5);
			}
		
			$theOutput.=$SOBE->doc->spacer(5);
			$menu = "Category: ".t3lib_BEfunc::getFuncMenu($SOBE->id,"SET[constant_editor_cat]",$GLOBALS["SOBE"]->MOD_SETTINGS["constant_editor_cat"],$GLOBALS["SOBE"]->MOD_MENU["constant_editor_cat"]);
			$theOutput.=$SOBE->doc->section("",'<NOBR>'.$menu.'</NOBR>');
		
		
					// Category and constant editor config:
			$category = $GLOBALS["SOBE"]->MOD_SETTINGS["constant_editor_cat"];
		/*	$TSCE_tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
			$TSCE_tmpl->tt_track = 0;	// Do not log time-performance information
			$TSCE_tmpl->init();
			$TSCE_tmpl->constants=array($tplRow["constants"]);
			debug($tplRow);
			$TSCE_tmpl->generateConfig_constants();
			debug($TSCE_tmpl->setup);
			*/
			$tmpl->ext_getTSCE_config($category);
		
			if ($BE_USER_modOptions["properties"]["constantEditor."]["example"]=="top")	{
				$theOutput=$this->displayExample($theOutput);
			}
		
			$printFields = trim($tmpl->ext_printFields($theConstants,$category));
			if ($printFields)	{
				$theOutput.=$SOBE->doc->spacer(20);
				$theOutput.=$SOBE->doc->section("",'<input type="Submit" name="submit" value="Update">');
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("",$printFields);
				$theOutput.=$SOBE->doc->spacer(10);
				$theOutput.=$SOBE->doc->section("",'<input type="Submit" name="submit" value="Update">');
			}
		
			if ($BE_USER_modOptions["properties"]["constantEditor."]["example"]!="top")	{
				$theOutput=$this->displayExample($theOutput);
			}
		
			$theOutput.=$SOBE->doc->spacer(10);
			$theOutput.=$SOBE->doc->section("Cache",'Click here to <a href="index.php?id='.$SOBE->id.'&clear_all_cache=1"><strong>clear all cache</strong></a>',0,1);
		} else {
			$theOutput.=$GLOBALS["SOBE"]->noTemplate(1);
		}
		return $theOutput;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_constants_editor.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_constants_editor.php"]);
}

?>