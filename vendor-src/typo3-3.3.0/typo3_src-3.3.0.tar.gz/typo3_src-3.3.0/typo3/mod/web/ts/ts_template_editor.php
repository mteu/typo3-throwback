<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TypoScript editor
 *
 * Module Include-file
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */


class ts_template_editor {

	function tableRow($label,$data,$field)	{
		$ret='<tr><td bgcolor="#D9D5C9" width="1%">';
		$ret.='<a href="index.php?id='.$GLOBALS["SOBE"]->id.'&e['.$field.']=1"><img src="'.$GLOBALS["BACK_PATH"].'gfx/edit2.gif" width=11 height=12 hspace=3 border=0 title="Edit field"></a>';
		$ret.='</td><td bgcolor="#D9D5C9" width="1%"><b>'.fw($label."&nbsp;&nbsp;").'</b></td><td bgcolor="#D9D5C9" width="99%">'.fw($data."&nbsp;").'</td></tr>';
		return $ret;
	}
	function procesResources($resources,$func=0)	{
		$arr = t3lib_div::trimExplode(",",$resources.",,",1);
		$out="";
		if ($func)	{$bgcol=' bgColor="'.$GLOBALS[doc]->bgColor4.'"';} else {$bgcol="";}
		while(list($k,$v)=each($arr))	{
			$path = PATH_site.$GLOBALS["TCA"]["sys_template"]["columns"]["resources"]["config"]["uploadfolder"]."/".$v;
			$functions="";
			if ($func)	{
				$functions='<td bgcolor=red nowrap>'.fw("Delete: ").'<input type="Checkbox" name="data[remove_resource]['.$k.']" value="'.htmlspecialchars($v).'"></td>';
				$functions.='<td'.$bgcol.' nowrap>'.fw("To top: ").'<input type="Checkbox" name="data[totop_resource]['.$k.']" value="'.htmlspecialchars($v).'"></td>';
				$functions.='<td'.$bgcol.' nowrap>';
				$fI=t3lib_div::split_fileref($v);
				if (t3lib_div::inList($GLOBALS["SOBE"]->textExtensions,$fI["fileext"]))	{
					$functions.='<a href="index.php?id='.$GLOBALS["SOBE"]->id.'&e[file]='.rawurlencode($v).'"><img src="'.$GLOBALS["BACK_PATH"].'gfx/edit2.gif" width=11 height=12 hspace=3 border=0 title="Edit file"></a>';
				}
				$functions.='</td>';
			}
			$thumb=t3lib_BEfunc::thumbCode(array("resources"=>$v),"sys_template","resources",$GLOBALS["BACK_PATH"],"");
			$out.='<tr><td'.$bgcol.' nowrap>'.fw($v."&nbsp;&nbsp;").'</td><td'.$bgcol.' nowrap>'.fw("&nbsp;".t3lib_div::formatSize(@filesize($path))."&nbsp;").'</td>'.$functions.'<td'.$bgcol.'>'.trim($thumb).'</td></tr>';
		}
		if ($out)	{
			if ($func)	{
				$out = '<table border=0 cellpadding=1 cellspacing=1 width="100%">'.$out.'</table>';
				$out='<table border=0 cellpadding=0 cellspacing=0>
					<tr><td bgcolor="'.$GLOBALS[doc]->bgColor2.'">'.$out.'<img src=clear.gif width=465 height=1></td></tr>
				</table>';
			} else {
				$out = '<table border=0 cellpadding=0 cellspacing=0>'.$out.'</table>';
			}
		}
		return $out;
	}
	function resourceListForCopy($id,$template_uid)	{
		global $tmpl;
		$sys_page = t3lib_div::makeInstance("t3lib_pageSelect");
		$rootLine = $sys_page->getRootLine($id);
		$tmpl->runThroughTemplates($rootLine,$template_uid);	// This generates the constants/config + hierarchy info for the template.
		$theResources = t3lib_div::trimExplode(",",$tmpl->resources,1);
		reset($theResources);
		while(list($k,$v)=each($theResources))	{
			$fI=pathinfo($v);
			if (t3lib_div::inList($GLOBALS["SOBE"]->textExtensions,strtolower($fI["extension"])))	{
				$path = PATH_site.$GLOBALS["TCA"]["sys_template"]["columns"]["resources"]["config"]["uploadfolder"]."/".$v;
				$thumb=t3lib_BEfunc::thumbCode(array("resources"=>$v),"sys_template","resources",$GLOBALS["BACK_PATH"],"");
				$out.='<tr><td'.$bgcol.' nowrap>'.fw($v."&nbsp;&nbsp;").'</td><td'.$bgcol.' nowrap>'.fw("&nbsp;".t3lib_div::formatSize(@filesize($path))."&nbsp;").'</td><td'.$bgcol.'>'.trim($thumb).'</td><td><input type="Checkbox" name="data[makecopy_resource]['.$k.']" value="'.htmlspecialchars($v).'"></td></tr>';
			}
		}
		$out = $out ? '<table border=0 cellpadding=0 cellspacing=0>'.$out.'</table>' : "";
		return $out;
	}
	function initialize_editor($pageId,$template_uid=0)	{
			// Initializes the module. Done in this function because we may need to re-initialize if data is submitted!
		global $tmpl,$tplRow,$theConstants;
		
		$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
		$tmpl->tt_track = 0;	// Do not log time-performance information
		$tmpl->init();
	
		$tplRow = $tmpl->ext_getFirstTemplate($pageId,$template_uid);	// Get the row of the first VISIBLE template of the page. whereclause like the frontend.
		if (is_array($tplRow))	{
			return 1;
		}
	}
	function main()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $tmpl,$tplRow,$theConstants;

		$edit = $GLOBALS["SOBE"]->edit;
		$e = $GLOBALS["SOBE"]->e;
		
		t3lib_div::loadTCA("sys_template");
		
		// **************************
		// Create extension template
		// **************************
		$GLOBALS["SOBE"]->createTemplate($SOBE->id);
		
		
		// **************************
		// Checking for more than one template an if, set a menu...
		// **************************
		$manyTemplatesMenu = $GLOBALS["SOBE"]->templateMenu();
		$template_uid = 0;
		if ($manyTemplatesMenu)	{
			$template_uid = $GLOBALS["SOBE"]->MOD_SETTINGS["templatesOnPage"];
		}
		
		
		
		
		
		// **************************
		// Initialize
		// **************************
		$existTemplate = $this->initialize_editor($SOBE->id,$template_uid);		// initialize
		if ($existTemplate)	{
		
				// Update template ?
		//		debug($GLOBALS["HTTP_POST_VARS"]);
		
			if ($GLOBALS["HTTP_POST_VARS"]["submit"])	{
				include_once(PATH_t3lib."class.t3lib_tcemain.php");
					// Set the data to be saved
				$recData=array();
				$alternativeFileName=array();
				$resList = $tplRow["resources"];
				if (is_array($GLOBALS["HTTP_POST_VARS"]["data"]))	{
					while(list($field,$val)=each($GLOBALS["HTTP_POST_VARS"]["data"]))	{
						switch($field)	{
							case "constants":
							case "config":
							case "title":
							case "sitetitle":
							case "description":
								$recData["sys_template"][$tplRow[uid]][$field] = $val;
							break;
							case "resources":
								if ($tmp_name = $GLOBALS["HTTP_POST_FILES"]["resources"]["tmp_name"])	{
									if ($tmp_name!="none" && $GLOBALS["HTTP_POST_FILES"]["resources"]["name"])	{
										$alternativeFileName[$tmp_name] = trim($GLOBALS["HTTP_POST_FILES"]["resources"]["name"]);
										$resList = $tmp_name.",".$resList;
									}
								}
							break;
							case "new_resource":
								$newName = trim(t3lib_div::GPvar("new_resource"));
								if ($newName)	{
									$newName.=".".t3lib_div::GPvar("new_resource_ext");
									$tmp_name = tempnam("","");
									$alternativeFileName[$tmp_name] = $newName;
									$resList = $tmp_name.",".$resList;
								}
							break;
							case "makecopy_resource":
								if (is_array($val))	{
									reset($val);
									$resList=",".$resList.",";
									while(list($k,$file)=each($val))	{
										$tmp_name = PATH_site.$TCA["sys_template"]["columns"]["resources"]["config"]["uploadfolder"]."/".$file;
		//								debug($tmp_name);
										$resList = $tmp_name.",".$resList;
									}
								}
							break;
							case "remove_resource":
								if (is_array($val))	{
									reset($val);
									$resList=",".$resList.",";
									while(list($k,$file)=each($val))	{
										$resList = str_replace(",".$file.",", ",", $resList);
									}
								}
							break;
							case "totop_resource":
								if (is_array($val))	{
									reset($val);
									$resList=",".$resList.",";
									while(list($k,$file)=each($val))	{
										$resList = str_replace(",".$file.",", ",", $resList);
										$resList = ",".$file.$resList;
									}
								}
		//						debug($resList);
							break;
						}
					}
				}
				$resList=implode(t3lib_div::trimExplode(",",$resList,1),",");
				if (strcmp($resList,$tplRow["resources"]))	{
					$recData["sys_template"][$tplRow[uid]]["resources"] = $resList;
		//			debug("update resource - ".$resList);
				}
				if (count($recData))	{
						// Create new  tce-object
					$tce = t3lib_div::makeInstance("t3lib_TCEmain");
					$tce->alternativeFileName = $alternativeFileName;
						// Initialize
		//				debug($recData);
					$tce->start($recData,Array());
						// Saved the stuff
					$tce->process_datamap();
						// Clear the cache (note: currently only admin-users can clear the cache in tce_main.php)
					$tce->clear_cacheCmd("all");
						
						// re-read the template ...
					$this->initialize_editor($SOBE->id,$template_uid);
				}
				
					// If files has been edited:
				if (is_array($edit))		{
					if ($edit["filename"] && $tplRow["resources"] && t3lib_div::inList($tplRow["resources"], $edit["filename"]))	{		// Check if there are resources, and that the file is in the resourcelist.
						$path = PATH_site.$TCA["sys_template"]["columns"]["resources"]["config"]["uploadfolder"]."/".$edit["filename"];
						$fI=t3lib_div::split_fileref($edit["filename"]);
						if (@is_file($path) && t3lib_div::inList($GLOBALS["SOBE"]->textExtensions,$fI["fileext"]))	{		// checks that have already been done.. Just to make sure
							if (filesize($path)<(30*1024))	{	// checks that have already been done.. Just to make sure
								t3lib_div::writeFile($path,stripslashes($edit[file]));
		
								$theOutput.=$SOBE->doc->spacer(10);
								$theOutput.=$SOBE->doc->section("<font color=red>FILE CHANGED</font>","Resource '".$edit["filename"]."' has been updated.");
		
									// Clear cache - the file has probably affected the template setup
								$tce = t3lib_div::makeInstance("t3lib_TCEmain");
								$tce->start(Array(),Array());
								$tce->clear_cacheCmd("all");
							}
						}
					}
				}
			}
		
			$theOutput.=$SOBE->doc->spacer(5);
			$theOutput.=$SOBE->doc->section("Template information:",'<img src="'.$BACK_PATH.t3lib_iconWorks::getIcon("sys_template",$tplRow).'" width=18 height=16 align=top><b>'.$tplRow["title"].'</b>'.(trim($tplRow["sitetitle"])?' - ('.$tplRow["sitetitle"].')':''),0,1);
			if ($manyTemplatesMenu)	{
				$theOutput.=$SOBE->doc->section("",$manyTemplatesMenu);
				$theOutput.=$SOBE->doc->divider(5);
			}
		
		/*	$e[constants]=1;
			$e[config]=1;
			$e[title]=1;
			$e[sitetitle]=1;
			*/
			$numberOfRows= t3lib_div::intInRange($GLOBALS["SOBE"]->MOD_SETTINGS["ts_template_editor_TArows"],0,150);
			if (!$numberOfRows)	$numberOfRows = 35;
		
			if ($HTTP_POST_VARS[abort])		{unset($e);}	// If abort pressed, nothing should be edited.
		
			if (is_array($e))	{
				$theOutput.=$SOBE->doc->section("",'<BR><input type="Submit" name="submit" value="Update"> <input type="Submit" name="abort" value="Cancel">');
			}
			if ($e["title"])	{
				$outCode='<input type="Text" name="data[title]" value="'.htmlspecialchars($tplRow[title]).'"'.$SOBE->doc->formWidth().'>';
				$outCode.='<input type="Hidden" name="e[title]" value="1">';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("Title:",$outCode);
			}	
			if ($e["sitetitle"])	{
				$outCode='<input type="Text" name="data[sitetitle]" value="'.htmlspecialchars($tplRow[sitetitle]).'"'.$SOBE->doc->formWidth().'>';
				$outCode.='<input type="Hidden" name="e[sitetitle]" value="1">';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("Sitetitle:",$outCode);
			}	
			if ($e["description"])	{
				$outCode='<textarea name="data[description]" rows="5" wrap="off"'.$SOBE->doc->formWidthText().'>'.t3lib_div::formatForTextarea($tplRow[description]).'</textarea>';
				$outCode.='<input type="Hidden" name="e[description]" value="1">';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("Description:",$outCode);
			}	
			if ($e["resources"])	{
					// Upload
				$outCode='<input type="File" name="resources"'.$SOBE->doc->formWidth().'>';
				$outCode.='<input type="Hidden" name="data[resources]" value="1">';
				$outCode.='<input type="Hidden" name="e[resources]" value="1">';
				$outCode.='<BR>Allowed extensions: <b>'.$TCA["sys_template"]["columns"]["resources"]["config"]["allowed"].'</b>';
				$outCode.='<BR>Max file size: <b>'.t3lib_div::formatSize($TCA["sys_template"]["columns"]["resources"]["config"]["max_size"]*1024).'</b>';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("Upload resource:",$outCode);
		
					// New
				$opt=explode(",",$GLOBALS["SOBE"]->textExtensions);
				$optTags="";
				while(list(,$extVal)=each($opt))	{
					$optTags.='<option value="'.$extVal.'">.'.$extVal.'</option>';
				}
				$outCode='<input type="text" name="new_resource"'.$SOBE->doc->formWidth(20).'>
					<select name="new_resource_ext">'.$optTags.'</select>';
				$outCode.='<input type="Hidden" name="data[new_resource]" value="1">';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("New text resource (enter name):",$outCode);
		
					// Make copy
				$rL = $this->resourceListForCopy($SOBE->id,$template_uid);
				if ($rL)	{
					$theOutput.=$SOBE->doc->spacer(20);
					$theOutput.=$SOBE->doc->section("Make a copy of resource:",$rL);
				}
				
					// Update resource list
				$rL = $this->procesResources($tplRow["resources"],1);
				if ($rL)	{
					$theOutput.=$SOBE->doc->spacer(20);
					$theOutput.=$SOBE->doc->section("Update resource list:",$rL);
				}
			}	
			if ($e["constants"])	{
				$outCode='<textarea name="data[constants]" rows="'.$numberOfRows.'" wrap="off"'.$SOBE->doc->formWidthText(48,"width:98%;height:70%").'>'.t3lib_div::formatForTextarea($tplRow["constants"]).'</textarea>';
				$outCode.='<input type="Hidden" name="e[constants]" value="1">';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("Constants:","");
				$theOutput.=$SOBE->doc->sectionEnd().$outCode;
			}	
			if ($e["file"])	{
				$path = PATH_site.$TCA["sys_template"]["columns"]["resources"]["config"]["uploadfolder"]."/".$e[file];
		//		debug($path);
				$fI=t3lib_div::split_fileref($e[file]);
				if (@is_file($path) && t3lib_div::inList($GLOBALS["SOBE"]->textExtensions,$fI["fileext"]))	{
					if (filesize($path)<(30*1024))	{
						$fileContent = t3lib_div::getUrl($path);
						$outCode='File: <b>'.$e[file].'</b><BR>';
						$outCode.='<textarea name="edit[file]" rows="'.$numberOfRows.'" wrap="off"'.$SOBE->doc->formWidthText(48,"width:98%;height:70%").'>'.t3lib_div::formatForTextarea($fileContent).'</textarea>';
						$outCode.='<input type="Hidden" name="edit[filename]" value="'.$e[file].'">';
						$outCode.='<input type="Hidden" name="e[file]" value="'.htmlspecialchars($e[file]).'">';
						$theOutput.=$SOBE->doc->spacer(15);
						$theOutput.=$SOBE->doc->section("Edit Resource:","");
						$theOutput.=$SOBE->doc->sectionEnd().$outCode;				
					} else {
						$theOutput.=$SOBE->doc->spacer(15);
						$theOutput.=$SOBE->doc->section('<font color=red>Filesize exceeded 30 Kbytes</font>','Files larger than 30 KByes are not allowed to be edited.');
					}
				}
			}	
			if ($e["config"])	{
				$outCode='<textarea name="data[config]" rows="'.$numberOfRows.'" wrap="off"'.$SOBE->doc->formWidthText(48,"width:98%;height:70%").'>'.t3lib_div::formatForTextarea($tplRow["config"]).'</textarea>';
				
				$url=$BACK_PATH."wizard_tsconfig.php?mode=tsref";
				$params=array();
				$params["formName"]="editForm";
				$params["itemName"]="data[config]";
				$outCode.='<a href="#" onClick="vHWin=window.open(\''.$url.t3lib_div::implodeArrayForUrl("",array("P"=>$params)).'\',\'popUp'.$md5ID.'\',\'height=500,width=780,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="'.$BACK_PATH.'gfx/wizard_tsconfig.gif" width="22" height="27" border="0"'.t3lib_BEfunc::titleAttrib("TSref reference").'></a>';
		
				$outCode.='<input type="Hidden" name="e[config]" value="1">';
				$theOutput.=$SOBE->doc->spacer(15);
				$theOutput.=$SOBE->doc->section("Setup:","");
				$theOutput.=$SOBE->doc->sectionEnd().$outCode;
			}	
			if (is_array($e))	{
				$theOutput.=$SOBE->doc->section("",'<BR><input type="Submit" name="submit" value="Update"> <input type="Submit" name="abort" value="Cancel">');
			}
		
					// Processing:
		//	debug($tplRow);
			$outCode="";
			$outCode.=$this->tableRow("Title:",$tplRow["title"],"title");
			$outCode.=$this->tableRow("Sitetitle:",$tplRow["sitetitle"],"sitetitle");
			$outCode.=$this->tableRow("Description:",nl2br($tplRow["description"]),"description");
			$outCode.=$this->tableRow("Resources:",$this->procesResources($tplRow["resources"]),"resources");
			$outCode.=$this->tableRow("Constants:","(edit to view, ".(trim($tplRow[constants]) ? count(explode(chr(10), $tplRow[constants])):0)." lines)","constants");
			$outCode.=$this->tableRow("Setup:","(edit to view, ".(trim($tplRow[config]) ? count(explode(chr(10), $tplRow[config])):0)." lines)","config");
			$outCode='<table border=0 cellpadding=1 cellspacing=1 width="100%">'.$outCode.'</table>';
		
			$outCode='<table border=0 cellpadding=0 cellspacing=0>
				<tr><td bgcolor="'.$SOBE->doc->bgColor2.'">'.$outCode.'<img src=clear.gif width=465 height=1></td></tr>
			</table>';
			
				// Edit all icon:
			$outCode.='<BR><a href="#" onClick="'.t3lib_BEfunc::editOnClick("&edit[sys_template][".$tplRow["uid"]."]=edit",$BACK_PATH,"",1).'"><strong>Click here to edit whole template record</strong></a>';
			
			$theOutput.=$SOBE->doc->spacer(25);
			$theOutput.=$SOBE->doc->section("",$outCode);
		
			$theOutput.=$SOBE->doc->spacer(10);
			$theOutput.=$SOBE->doc->section("Cache",'Click here to <a href="index.php?id='.$SOBE->id.'&clear_all_cache=1"><strong>clear all cache</strong></a>.<BR><br>
			Status: '.$GLOBALS["SOBE"]->getCountCacheTables(1),0,1);
			
		//	$theOutput.=$SOBE->doc->divider(5);
			$menu = htmlspecialchars("Rows in <TEXTAREA> fields: ").t3lib_BEfunc::getFuncInput($SOBE->id,"SET[ts_template_editor_TArows]",$GLOBALS["SOBE"]->MOD_SETTINGS["ts_template_editor_TArows"]);
			$theOutput.=$SOBE->doc->section("CONFIG:",$menu,0,1);
		} else {
			$theOutput.=$GLOBALS["SOBE"]->noTemplate(1);
		}
		return $theOutput;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_template_editor.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_template_editor.php"]);
}

?>