<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TypoScript Constant editor
 *
 * Module Include-file
 *
 * localconf-variables:
 * $TYPO3_CONF_VARS["MODS"]["web_ts"]["onlineResourceDir"] = "fileadmin/fonts/";		// This is the path (must be in "fileadmin/" !!) where the web_ts/constant-editor submodule fetches online resources. Put fonts (ttf) and standard images here!
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



class ts_analyzer {
	function initialize_editor($pageId,$template_uid=0)	{
			// Initializes the module. Done in this function because we may need to re-initialize if data is submitted!
		global $tmpl,$tplRow,$theConstants,$rootLine;
		
		$tmpl = t3lib_div::makeInstance("TSparser");	// Defined global here!
		$tmpl->tt_track = 0;	// Do not log time-performance information
		$tmpl->init();
		
			// Gets the rootLine
		$sys_page = t3lib_div::makeInstance("t3lib_pageSelect");
		$rootLine = $sys_page->getRootLine($pageId);
		$tmpl->runThroughTemplates($rootLine,$template_uid);	// This generates the constants/config + hierarchy info for the template.
	
		$tplRow = $tmpl->ext_getFirstTemplate($pageId,$template_uid);	// Get the row of the first VISIBLE template of the page. whereclause like the frontend.
		if (is_array($tplRow))	{	// IF there was a template...
			return 1;
		}
	}
	function main()	{
			// Initializes the module. Done in this function because we may need to re-initialize if data is submitted!
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $tmpl,$tplRow,$theConstants,$rootLine;
		
		// **************************
		// Checking for more than one template an if, set a menu...
		// **************************
		$manyTemplatesMenu = $GLOBALS["SOBE"]->templateMenu();
		$template_uid = 0;
		if ($manyTemplatesMenu)	{
			$template_uid = $GLOBALS["SOBE"]->MOD_SETTINGS["templatesOnPage"];
		}
		
		// **************************
		// Main
		// **************************
		
		// BUGBUG: Should we check if the uset may at all read and write template-records???
		$existTemplate = $this->initialize_editor($SOBE->id,$template_uid);		// initialize
		if ($existTemplate)	{
			$theOutput.=$SOBE->doc->divider(5);
			$theOutput.=$SOBE->doc->section("Current template:",'<img src="'.$BACK_PATH.t3lib_iconWorks::getIcon("sys_template",$tplRow).'" width=18 height=16 align=top><b>'.$GLOBALS["SOBE"]->linkWrapTemplateTitle($tplRow["title"]).'</b>'.(trim($tplRow["sitetitle"])?' - ('.$tplRow["sitetitle"].')':''));
		}
		if ($manyTemplatesMenu)	{
			$theOutput.=$SOBE->doc->section("",$manyTemplatesMenu);
		}
		
		//	debug($tmpl->hierarchyInfo);
		
		$tmpl->clearList_const_temp = array_flip($tmpl->clearList_const);
		$tmpl->clearList_setup_temp = array_flip($tmpl->clearList_setup);
		
		$pointer = count($tmpl->hierarchyInfo);
		$tmpl->hierarchyInfoArr = $tmpl->ext_process_hierarchyInfo(array(), $pointer);
		
		
		$hierarArr = array();
		$head= '<tr>';
		$head.= '<td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw("Title&nbsp;&nbsp;").'</b></td>';
		$head.= '<td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw("Rootlevel&nbsp;&nbsp;").'</b></td>';
		$head.= '<td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw("C. Setup&nbsp;&nbsp;").'</b></td>';
		$head.= '<td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw("C. Const&nbsp;&nbsp;").'</b></td>';
		$head.= '<td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw("PID/RL&nbsp;&nbsp;").'</b></td>';
		$head.= '<td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw("NL&nbsp;&nbsp;").'</b></td>';
		$head.= '</tr>';
		$hierar = implode(array_reverse($tmpl->ext_getTemplateHierarchyArr($tmpl->hierarchyInfoArr, "",array(),1)),"");
		$hierar= '<table border=0 cellpadding=0 cellspacing=0>'.$head.$hierar.'</table>';
		
		$theOutput.=$SOBE->doc->spacer(5);
		$theOutput.=$SOBE->doc->section("Template hierarchy:",fw($hierar),0,1);
		
		
			// Output constants
		$theOutput.=$SOBE->doc->spacer(25);
		$theOutput.=$SOBE->doc->divider(0);
		$theOutput.=$SOBE->doc->section("",
			fw("Linenumbers").t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_analyzer_checkLinenum]",$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkLinenum"]).
			"&nbsp;&nbsp;&nbsp;".fw("Comments").t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_analyzer_checkComments]",$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkComments"]).
			"&nbsp;&nbsp;&nbsp;".fw("Crop lines").t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_analyzer_checkCrop]",$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkCrop"])
			);
		$theOutput.=$SOBE->doc->divider(2);
		//$theOutput.=$SOBE->doc->section("Constants:",t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_analyzer_checkConst]",$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkConst"]).fw("Enable"));
		$theOutput.=$SOBE->doc->section("Constants:","",0,1);
		$theOutput.=$SOBE->doc->sectionEnd();
		if (1==1 || $GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkConst"]) 	{
			$theOutput.='
				<table border=0 cellpadding=1 cellspacing=0>
			';
			$tmpl->ext_lineNumberOffset=-2;	// Don't know why -2 and not 0... :-) But works.
			$tmpl->ext_lineNumberOffset_mode="const";	
			$tmpl->ext_lineNumberOffset+=count(explode(chr(10),"".$GLOBALS["TYPO3_CONF_VARS"]["FE"]["defaultTypoScript_constants"]))+1;
			
			reset($tmpl->constants);
			reset($tmpl->clearList_const);
			while(list($key,$val)=each($tmpl->constants))	{
				$cVal = current($tmpl->clearList_const);
				if ($cVal==$GLOBALS[HTTP_GET_VARS]["template"] || $GLOBALS[HTTP_GET_VARS]["template"]=="all")	{
					$theOutput.='
						<tr>
							<td><img src=clear.gif width=3 height=1></td><td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw($tmpl->templateTitles[$cVal]).'</b></td></tr>
						<tr>
							<td><img src=clear.gif width=3 height=1></td>
							<td bgcolor="'.$SOBE->doc->bgColor2.'"><table border=0 cellpadding=0 cellspacing=0 bgcolor="#D9D5C9" width="100%"><tr><td nowrap>'.fw($tmpl->ext_outputTS(array($val),$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkLinenum"],$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkComments"],$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkCrop"])).'</td></tr></table>
							</td>
						</tr>
					';
					if ($GLOBALS[HTTP_GET_VARS]["template"]!="all") 	break;			
				}
				$tmpl->ext_lineNumberOffset+=count(explode(chr(10),$val))+1;
				next($tmpl->clearList_const);
			}
			$theOutput.='
				</table>
			';
		}
		
			// Output setup
		$theOutput.=$SOBE->doc->spacer(15);
		//$theOutput.=$SOBE->doc->section("SETUP:",t3lib_BEfunc::getFuncCheck($SOBE->id,"SET[ts_analyzer_checkSetup]",$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkSetup"]).fw("Enable"));
		$theOutput.=$SOBE->doc->section("SETUP:","",0,1);
		$theOutput.=$SOBE->doc->sectionEnd();
		if (1==1 || $GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkSetup"]) 	{
			$theOutput.='
				<table border=0 cellpadding=1 cellspacing=0>
			';
			$tmpl->ext_lineNumberOffset=0;
			$tmpl->ext_lineNumberOffset_mode="setup";	
			$tmpl->ext_lineNumberOffset+=count(explode(chr(10),"".$GLOBALS["TYPO3_CONF_VARS"]["FE"]["defaultTypoScript_setup"]))+1;
			
			reset($tmpl->config);
			reset($tmpl->clearList_setup);
			while(list($key,$val)=each($tmpl->config))	{
				if (current($tmpl->clearList_setup)==$GLOBALS[HTTP_GET_VARS]["template"] || $GLOBALS[HTTP_GET_VARS]["template"]=="all")	{
					$theOutput.='
						<tr>
							<td><img src=clear.gif width=3 height=1></td><td bgcolor="'.$SOBE->doc->bgColor2.'"><b>'.fw($tmpl->templateTitles[current($tmpl->clearList_setup)]).'</b></td></tr>
						<tr>
							<td><img src=clear.gif width=3 height=1></td>
							<td bgcolor="'.$SOBE->doc->bgColor2.'"><table border=0 cellpadding=0 cellspacing=0 bgcolor="#D9D5C9" width="100%"><tr><td nowrap>'.fw($tmpl->ext_outputTS(array($val),$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkLinenum"],$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkComments"],$GLOBALS["SOBE"]->MOD_SETTINGS["ts_analyzer_checkCrop"])).'</td></tr></table>
							</td>
						</tr>
					';
					if ($GLOBALS[HTTP_GET_VARS]["template"]!="all") 	break;
				}
				$tmpl->ext_lineNumberOffset+=count(explode(chr(10),$val))+1;
				next($tmpl->clearList_setup);
			}
			$theOutput.='
				</table>
			';
		}
		return $theOutput;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_analyzer.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/mod/web/ts/ts_analyzer.php"]);
}

?>