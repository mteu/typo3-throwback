<?php
define("TYPO3_MOD_PATH", "mod/web/modules/");
$BACK_PATH="../../../";

/*
$MLANG["default"]["labels"]["tablabel"] = "Website modules, eg. Board, Shop, Direct Mailer";
$MLANG["default"]["tabs"]["tab"] = "Modules";
$MLANG["default"]["tabs_images"]["tab"] = "modules.gif";
$MLANG["default"]["labels"]["tabdescr"] = "'Modules' in this sense refers to special features on the frontend website, eg. boards, shops, guestbooks, direct mail etc. Here you gain access to specialized facilities regarding each of the available frontend modules.";

$MLANG["dk"]["labels"]["tablabel"] = "Website moduler, fx forum, butik og Direct Mail udsendelse";
$MLANG["dk"]["tabs"]["tab"] = "Moduler";
$MLANG["dk"]["labels"]["tabdescr"] = "'Moduler' i denne sammenh�ng henviser til specielle funktioner p� selve websitet, fx. debatfora, e-handelsbutik, g�steb�ger, nyhedsbrevsudsendelse osv. Her f�r du direkte adgang til de specialiserede funktioner i forbindelse med hver af disse websitefunktioner.";

$MLANG["de"]["labels"]["tablabel"] = "Webseiten Module, z.B. Forum, Shop, Direct Mail";
$MLANG["de"]["labels"]["tabdescr"] = "'Module'";
$MLANG["de"]["tabs"]["tab"] = "Module";

$MLANG["no"]["labels"]["tablabel"] = "Webomr�de moduler, for eksempel forum, butikk (webshop) og Direct Mail utsendelse.";
$MLANG["no"]["labels"]["tabdescr"] = "'Moduler' i denne sammenhengen viser til spesielle funksjoner p� selve webomr�det, for eksempel debattforum, webshop, gjesteb�ker, nyhetsbrevutsendelse osv. Her f�r du direkte adgang til spesielle funksjoner i forbindelse med hver av disse webomr�defunksjonene.";
$MLANG["no"]["tabs"]["tab"] = "Moduler";

$MLANG["it"]["labels"]["tablabel"] = "Website modules, eg. Board, Shop, Direct Mailer";
$MLANG["it"]["labels"]["tabdescr"] = "'Modules' in this sense refers to special features on the frontend website, eg. boards, shops, guestbooks, direct mail etc. Here you gain access to specialized facilities regarding each of the available frontend modules.";
$MLANG["it"]["tabs"]["tab"] = "Moduli";

$MLANG["fr"]["labels"]["tablabel"] = "Modules Website, ex. Forums, Magasin, Direct Mail";
$MLANG["fr"]["labels"]["tabdescr"] = "'Modules' in this sense englobe des fonctions sp�ciales dans le site web Frontend. Ici vous pouvez acc�der � de nombreuses facilit�s pour la configuration de ces modules.";
$MLANG["fr"]["tabs"]["tab"] = "Modules";

$MLANG["pl"]["labels"]["tablabel"] = "Modu�y witryny. np. Forum, Sklep, Mailing bezpo�redni";
$MLANG["pl"]["labels"]["tabdescr"] = "Modu�y w tym znaczeniu to funkcjonalno�� jak� mo�e mie� twoja witryna, np. fora dyskusyjne, sklepy, ksi�gi go�ci, biuletyny wysy�ane emailem. Tutaj masz dost�p do tych specjalistycznych modu��w.";
$MLANG["pl"]["tabs"]["tab"] = "Modu�y";

$MLANG["es"]["labels"]["tablabel"] = "M�dulos del Website, i.e.: Tablero, Tienda, Correo Directo";
$MLANG["es"]["labels"]["tabdescr"] = "La palabra 'M�dulos' en este contexto se refiere a caracter�sticas especiales en el frontend. i.e.: tableros, tiendas, listas de visitantes, correo directo, etc.. Aqu� tiene acceso a las facilidades especializadas referentes a dichos m�dulos.";
$MLANG["es"]["tabs"]["tab"] = "M�dulos";

$MLANG["si"]["labels"]["tablabel"] = "Spletni moduli, npr. oglasna deska, trgovina, direct-mailer";
$MLANG["si"]["tabs"]["tab"] = "Moduli";
$MLANG["si"]["labels"]["tabdescr"] = "'Moduli' v o�jem pomenu so posebni dodatki, ki jih lahko vgradite na svojo spleto stran, npr. oglasna deska, trgovina, direct-mail.";

$MLANG["nl"]["tabs"]["tab"] = "Modules";
$MLANG["nl"]["labels"]["tablabel"] = "Websitemodules, zoals Forum, winkel, Direct Mail";
$MLANG["nl"]["labels"]["tabdescr"] = "'Modules' in deze betekenis refereert aan de speciale onderdelen die voorkomen in de website zelf, zoals forums, winkels, gastenboeken, direct mail enzovoorts. Hier kan je toegang verkrijgen tot gespecialiseerde faciliteiten betreffende elk van de beschikbare website modules.";

$MLANG["cz"]["labels"]["tablabel"] = "Moduly, nap�. n�st�nka, obchod, direct mail";
$MLANG["cz"]["labels"]["tabdescr"] = "'Moduly' v tomto smyslu znamenaj� speci�ln� vlastnosti na frontendov� stran� website, nap�. n�st�nky, obchody, n�v�t�vn� knihy, direct mail etd. Zde m��ete z�skat p��stup ke specializovan�m slu�b�m, kter� se t�kaj� dostupn�ch frontendov�ch modul�.";
$MLANG["cz"]["tabs"]["tab"] = "Moduly";

$MLANG["fi"]["labels"]["tablabel"] = "WWW-sivuston modulit, kuten Board, Shop ja Direct Mail";
$MLANG["fi"]["labels"]["tabdescr"] = "Modulit t�ss� yhteydess� tarkoittavat www-sivuston erkoistointoja kuten esimerkiksi keskustelua, kauppaa, vieraskirjaa, suora mailia jne. T��lt� on p��sy kaikkiin erikoistoimintoihin jotka ovat k�ytett�viss� sivustossa.";
$MLANG["fi"]["tabs"]["tab"] = "Modulit";
*/

$MLANG["default"]["labels"]["tablabel"] = "Website plugins, eg. Board, Shop, Direct Mailer";
$MLANG["default"]["tabs"]["tab"] = "Plugins";
$MLANG["default"]["tabs_images"]["tab"] = "modules.gif";
$MLANG["default"]["labels"]["tabdescr"] = "Plugins represents special features on the website, eg. boards, shops, guestbooks, direct mail etc. Here you gain access to specialized facilities regarding each of the available frontend plugins.";

$MLANG["dk"]["labels"]["tablabel"] = "Website plugins, fx forum, butik og Direct Mail udsendelse";
$MLANG["dk"]["tabs"]["tab"] = "Plugins";
$MLANG["dk"]["labels"]["tabdescr"] = "Plugins repr�senterer specielle funktioner p� selve websitet, fx. debatfora, e-handelsbutik, g�steb�ger, nyhedsbrevsudsendelse osv. Her f�r du direkte adgang til de specialiserede funktioner i forbindelse med hver af disse websitefunktioner.";

$MLANG["nl"]["labels"]["tablabel"] = "Website plugins, zoals Forum, Winkel, Direct Mail";
$MLANG["nl"]["labels"]["tabdescr"] = "Plugins vertegenwoordigt speciale onderdelen op de website, zoals forums, winkels, gastenboeken, direct mail enzovoorts. Hier heb je toegang tot de specifieke opties behorende bij elk van de beschikbare website plugins.";
$MLANG["nl"]["tabs"]["tab"] = "Plugins";

$MLANG["de"]["labels"]["tablabel"] = "Webseiten Erweiterungen, z.B. Forum, Shop, Direct Mailer";
$MLANG["de"]["labels"]["tabdescr"] = "Erweiterungen repr�sentieren spezielle Erweiterungen auf der Webseite, wie z.B. Foren, Shops, G�steb�cher usw. Hier erhalten Sie Zugriff auf die besonderen Eigenschaften aller Erweiterungen.";
$MLANG["de"]["tabs"]["tab"] = "Erweiterungen";

$MLANG["no"]["labels"]["tablabel"] = "Webomr�de plugins, for eksempel forum, butikk (webshop) og Direct Mail utsendelse.";
$MLANG["no"]["labels"]["tabdescr"] = "'Plugins' er spesielle funksjoner p� selve webomr�det, for eksempel debattforum, webshop, gjesteb�ker, nyhetsbrevutsendelse osv. Her f�r du direkte adgang til spesielle funksjoner i forbindelse med hver av disse webomr�defunksjonene.";
$MLANG["no"]["tabs"]["tab"] = "Plugins";

$MLANG["pl"]["labels"]["tablabel"] = "Wtyczki, np.  Forum, Sklep, Biuletyn";
$MLANG["pl"]["labels"]["tabdescr"] = "Wtyczki zapewniaj� dodatkow� funkcjonalno�� witrynie, takie jak Forum dyskusyjne, Sklep, Ksi�ga go�ci, Biuletyn, itp. Tutaj mo�esz kontrolowa� dost�pne wtyczki.";
$MLANG["pl"]["tabs"]["tab"] = "Wtyczki";

$MLANG["tr"]["labels"]["tablabel"] = "Website eklentileri, �lan tahtas�, Ma�aza, Do�rudan Mail gibi";
$MLANG["tr"]["labels"]["tabdescr"] = "Eklenti sunumlar�n�n website �zerinde �zel bir �nemi vard�r, ilan tahtalar�, ma�azalar, ziyaret�i defterleri, do�rudan mail v.s gibi. Burada her bir �nplan eklentisi i�in �zelle�tirme olanaklar�na eri�im sa�lar. ";
$MLANG["tr"]["tabs"]["tab"] = "Eklentiler";

$MLANG["fi"]["labels"]["tablabel"] = "Websivuston pluginit, esim. Ilmoitustaulu, Kauppa, Suora postitus";
$MLANG["fi"]["labels"]["tabdescr"] = "Pluginit ovat websivuston erityistoimintoja, esim. ilmoitustaulu, kauppa, suora postitus jne. T�st� valinnasta p��set kaikkiin valittavissa oleviin erityistoimintoihin.";
$MLANG["fi"]["tabs"]["tab"] = "Pluginit";


$MCONF["script"]="index.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_modules";
?>