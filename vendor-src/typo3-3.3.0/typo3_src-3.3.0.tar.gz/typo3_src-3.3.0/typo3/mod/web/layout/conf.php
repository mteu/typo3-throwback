<?php
define("TYPO3_MOD_PATH", "mod/web/layout/");
$BACK_PATH="";

$MLANG["default"]["tabs"]["tab"] = "Page";
$MLANG["default"]["tabs_images"]["tab"] = "layout.gif";
$MLANG["default"]["labels"]["tablabel"] = "Page content";
$MLANG["default"]["labels"]["tabdescr"] = "This module allows you to create and edit webpages. It provides a Quick-Editor for instant access to the primary page content. In addition you can manage different languages and columns of content per page. Finally you may access special page content like guestbook, board and shopping items. The module also presents pagehit statistics for the individual pages.";

$MLANG["dk"]["labels"]["tablabel"] = "Sideindhold";
$MLANG["dk"]["tabs"]["tab"] = "Side";
$MLANG["dk"]["labels"]["tabdescr"] = "Dette modul giver dig mulighed for at oprette og redigere websider. Kvik-redigerings-funktionen giver dig �jeblikkelig adgang til det prim�re indhold p� siderne. Herudover kan du styre forskellige sprog og kolonner per side. Endeligt kan du tilg� specialiseret sideindhold s� som g�stebog-, forum- og produktelementer. Modulet fremviser ogs� en sidevisningsstatestik for de enkelte sider.";

$MLANG["de"]["labels"]["tablabel"] = "Seiten-Info und Inhalt";
$MLANG["de"]["tabs"]["tab"] = "Seite";
$MLANG["de"]["labels"]["tabdescr"] = "Mit diesem Modul k�nnen Sie neue Webseiten anlegen und bearbeiten. Es bietet einen Quickeditor f�r schnellen Zugriff auf den Hauptseiteninhalt. Zus�tzlich k�nnen Sie verschiedene Sprachen und Inhaltsspalten Ihre Seite verwalten. Zus�tzlich k�nnen Sie speziellen Seiteninhalt wie G�steb�cher-, Forums- und Shop-Eintr�ge verwalten. Das Modul zeigt Ihnen auch Seitenzugriffstatistiken f�r die einzelnen Seiten an.";

$MLANG["no"]["labels"]["tablabel"] = "Side-info og innhold";
$MLANG["no"]["tabs"]["tab"] = "Side";
$MLANG["no"]["labels"]["tabdescr"] = "Hurtigredigeringsfunksjonen gir deg rask tilgang til det prim�re innholdet p� sidene. Du kan ogs� velge forskjellige spr�k og kolonner per side. Utover dette har du tilgang til spesielt sideinnhold som gjestebok-, forum- og produktelementer. Modulen viser ogs� sidevisningsstatistikk for de enkelte sidene.";

$MLANG["it"]["labels"]["tablabel"] = "Contenuto della pagina";
$MLANG["it"]["tabs"]["tab"] = "Pagina";
$MLANG["it"]["labels"]["tabdescr"] = "Questo modulo permette di creare e editare le pagine. Fornisce un Quick-Editor per modificare velocemente il contenuto. Potete gestire i paragrafi in multilingua, su differenti colonne, e potete accedere a pagine di tipo speciale, come guestbook, forum di discussione, shopping. Attraverso questo modulo potete, infine, vedere alcune statistiche sulla pagina.";

$MLANG["fr"]["labels"]["tablabel"] = "Contenu page";
$MLANG["fr"]["tabs"]["tab"] = "Page";
$MLANG["fr"]["labels"]["tabdescr"] = "Ce modules vous permet de cr�er et d'editer les pages web. Il vous apporte un Editeur rapide pour un acc�s imm�diat au contenu primaire de la page. En plus, vous pouvez g�rer plusieurs langues et colone pour le contenu de la page. Finalement, vous pouvez acc�der au contenu sp�cial des pages comme les livres d'or, les forums de discitions et le magasin en ligne. Ce module pr�sente aussi les statistiques pour chaque page.";

$MLANG["es"]["labels"]["tablabel"] = "Contenido de la p�gina";
$MLANG["es"]["tabs"]["tab"] = "P�gina";
$MLANG["es"]["labels"]["tabdescr"] = "Ese m�dulo le permite el crear y editar p�ginas web. Tiene un Quick-Editor para acceso instant�neo al contenido primario de la p�gina. Adicionalmente puede administrar los diferentes lenguajes y columnas de contenido por p�gina. Finalmente puede accesar contenido especial como lista de visitantes, tablero de mensajes y art�culos de la tienda. El m�dulo tambi�n muestra una estad�tica de consulta de las p�ginas individuales.";

$MLANG["nl"]["labels"]["tablabel"] = "Pagina-inhoud";
$MLANG["nl"]["tabs"]["tab"] = "Pagina";
$MLANG["nl"]["labels"]["tabdescr"] = "Via deze module kan je webpagina's aanmaken en bewerken. Je vindt hier een Quick-Editor die je directe toegang geeft tot de primaire pagina-inhoud. Bovendien kan je de diverse talen en kolommen inhoud per pagina manipuleren. Tenslotte heb je toegang tot speciale pagina-inhoud zoals gastenboek, forum en winkelartikelen. Deze module introduceert ook statistieken van de pagina-treffers voor individuele pagina's.";

$MLANG["cz"]["labels"]["tablabel"] = "Obsah strany";
$MLANG["cz"]["tabs"]["tab"] = "Strana";
$MLANG["cz"]["labels"]["tabdescr"] = "Tento modul umo��uje vytv��et a editovat webov� str�nky. Poskytuje Quick-Editor pro okam�it� p��stup k z�kladn�mu obsahu strany. Nav�c m��ete spravovat r�zn� jazyky a sloupce obsahu na stran�. Nav�c m�te p��stupn� i speci�ln� obsah stran jako je n�v�t�vn� kniha, n�st�nka nebo zbo�� obchodu. Modul tak� ukazuje statistiku p��stup� pro jednotliv� str�nky.";

$MLANG["pl"]["labels"]["tablabel"] = "Zawarto�� strony";
$MLANG["pl"]["tabs"]["tab"] = "Uk�ad";
$MLANG["pl"]["labels"]["tabdescr"] = "Ten modu� pozwala tworzy� i edytowa� strony. Do dyspozycji masz Szybki-Edytor do b�yskawicznej edycji tre�ci zawartej na stronie. Mo�esz r�wnie� zarz�dza� tre�ci� w kolumnach oraz r�nymi wersjami j�zykowymi dla strony. Masz dost�p r�wnie� do specjalnej zawarto�ci typu wpisy w forum dyskusyjnym, ksi�dze go�ci czy asortyment sklepu. Modu� wy�wietla te� statystyki ods�on dla poszczeg�lnych stron.";

$MLANG["si"]["labels"]["tablabel"] = "Vsebina strani";
$MLANG["si"]["tabs"]["tab"] = "Stran";
$MLANG["si"]["labels"]["tabdescr"] = "Ta modul vam omogo�a ustvarjanje in urejanje spletnih strani. Vsebuje hitri urejevalnik za takoj�nji dostop do primarne vsebine strani. Omogo�a tudi upravljanje razli�nih jezikovnih verzij strani. Lahko uporabite tudi posebno vsebino, naprimer knjigo gostov, oglasno desko, ali online trgovino. Tudi v tem modulu si lahko ogledate statistiko obiska strani.";

$MLANG["fi"]["labels"]["tablabel"] = "Sivun sis�lt�";
$MLANG["fi"]["labels"]["tabdescr"] = "T�ll� modulilla luot, muotoilet ja yll�pid�t www-sivujasi. QuichEdit teksturilla k�sittelet sivujen sis�lt��. Lis�ksi voit hallita useita erikieli� ja sarakkeita sivuillasi. Lis�ksi p��set spesiaali sis�lt�ihin kuten esimerkiksi vieraskijaan, keskustelusivuille ja kauppasivuille. Moduli n�ytt�� my�s sivuittain k�ytt�tilastot.";
$MLANG["fi"]["tabs"]["tab"] = "Sivu";

$MLANG["tr"]["tabs"]["tab"] = "Sayfa";
$MLANG["tr"]["labels"]["tablabel"] = "Sayfa i�eri�i";
$MLANG["tr"]["labels"]["tabdescr"] = "Bu mod�l websayfalar� yaratman�za ve d�zenlemenize izin verir. H�zl� D�zenleyici birincil sayfa i�eri�ine acil eri�im imkan� sa�lar. Buna ek olarak de�i�ik dilleri ve her sayfa i�eri�inin s�t�nlar�n� y�netebilirsiniz. Son olarak �zel sayfa i�eri�ine eri�ebilirsiniz ziyaret�i defteri, ilan tahtas� ve al��veri� nesneleri gibi. Birde mod�l k���sel sayfalar i�in sayfa eri�im istatistikleri sunuyor.";



$MCONF["script"]="../../../db_layout.php";
$MCONF["access"]="user,group";
$MCONF["name"]="web_layout";

?>