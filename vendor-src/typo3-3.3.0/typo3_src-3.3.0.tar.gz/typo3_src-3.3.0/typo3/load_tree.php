<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Loading page/directory tree to JavaScript backend 
 *
 * This script is called to load the file- og pagetree in the interface
 *
 * GET_VARS:
 * $type		:	"web" / "file"
 * $expData	:	information about an already expanded tree to reexpand (see main.php)
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */






// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








$BACK_PATH="";
include("init.php");
include("template.php");





// ********************
// ***  Functions  ****
// ********************
	// titlelength:
$titleLen=intval($GLOBALS["BE_USER"]->uc["titleLen"]);	

function drawmenu ($parent_id, $depth)	{
		// This generates the page tree
	global $TCA, $expUIDs;
	if (is_array($TCA[pages]))	{
		$query = "SELECT * FROM pages WHERE pid = '$parent_id' AND NOT deleted AND ".$GLOBALS[perms_clause]." ORDER BY sorting";
		$result = mysql(TYPO3_db,$query);
		if (mysql_numrows($result))	{		
			$first = 1;			
			while ($row = mysql_fetch_assoc($result))	{
				if ($first)	{$pid = $row["pid"]; $first=0;}
				$title = ($row["treeStop"]&&!$GLOBALS["USER_disableJSStop"]?"<b><font color=red>+ </font></b>":"").t3lib_div::fixed_lgd(strip_tags($row["title"]),$GLOBALS["titleLen"]);
				echo "
e.aI(".$row["uid"].",".$pid.",'".rawurlencode($title)."','".str_replace("'","\'",t3lib_BEfunc::getRecordIconAltText($row))."','".$row["alias"]."','".t3lib_iconWorks::getIcon("pages",$row)."');";
				if (is_array($expUIDs[$row["uid"]]))	{
					printPreToggle($expUIDs[$row["uid"]]);
				}
				if ($depth>=0 && !($row["treeStop"]&&!$GLOBALS["USER_disableJSStop"]))	{drawmenu($row["uid"], ($depth-1));}		// Draws sub-items
				$pid = -$row[uid];
			}
		}
	}
}
function printPreToggle($arr)	{
		// If an items should be expanded based on the content of $expData, this executes a command that pre-toggles the branch
	global $expUIDs;
	reset($arr);
	while(list(,$val)=each($arr))	{
		echo "
e.preToggle(e.lastAddedEntry, ".intval($val[1]).",".intval($val[0]).") ";
	}
}
function loadfolders ($files_path,$depth,$maxdepth,$menu_pid)	{
		// This generates the directory tree
	global $expUIDs;
	$tableName = "pages";
	$dirs = t3lib_div::get_dirs($files_path);
	if (is_array($dirs))	{
		sort($dirs);
		$first=1;
		while (list($key,$val)= each($dirs))	{
			$val = ereg_replace("^\./","",$val);
			$title = $val;
			$path = $files_path.$val."/";
			$webpath=t3lib_BEfunc::getPathType_web_nonweb($path);

			$path = t3lib_div::slashJS($path);
			$pid = ($first) ? ($menu_pid) : -$nextpid;

			$md5_uid = md5($path);
			$specUID=hexdec(substr($md5_uid,0,6));
			

			$icon = 'gfx/i/_icon_'.$webpath.'folders.gif';
			if ($val=="_temp_")	{
				$icon = 'gfx/i/sysf.gif';
				$title="<b>TEMP</b>";
			}
			if ($val=="_recycler_")	{
				$icon = 'gfx/i/recycler.gif';
				$title="<b>RECYCLER</b>";
			}
			echo "
e.aI(".$specUID.",".$pid.",'".rawurlencode($title)."','".$path."','".$md5_uid."', '".$icon."');";
			if (is_array($expUIDs[$specUID]))	{
				printPreToggle($expUIDs[$specUID]);
			}
			$nextpid = $specUID;
			if ($depth+1 < $maxdepth)	{
				$test = loadfolders ($path,$depth+1,$maxdepth,$specUID);
				if (is_string($test) && $test=="error")	{
					echo "
e.entry[e.lastAddedEntry].image = 'gfx/i/_icon_".$webpath."folders_ro.gif';";
				}
			}
			$first = 0;
		}
	}
	return $dirs;
}









// ********
// Main
// ********

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE>Loading Tree</TITLE>
</HEAD>
<BODY bgcolor="#F7F3EF" LINK="#000000" marginwidth="3" marginheight="1">
<script language="javascript">
<?php

// ***************************
// Registering Incoming data
// ***************************
t3lib_div::setGPvars("type,expData,interfaceConf");

$USER_disableJSStop = $BE_USER->getTSConfigVal("options.disableJSStop");

// **************************
// ExpData
// **************************

if (!isset($expData) && $BE_USER->uc["saveTreePositions"])	{
	$interfaceConf=unserialize($BE_USER->uc["interfaceSetup"]);
	if (is_array($interfaceConf))	{
		switch($type)	{
			case "web":
				$expData=$interfaceConf["pageTree"];
			break;
			case "file":
				$expData=$interfaceConf["dirTree"];
			break;
		}
	}
}

// Process the expandData for the menu
$expUIDs = Array();
$expUIDmapToJS = Array();
if ($expData)	{
	$elements = explode("|",$expData);
	while(list(,$val)=each($elements))	{
		if ($val)	{
			$subElement = explode(",",$val);
			$expUIDs[$subElement[2]][]=Array($subElement[0],$subElement[1]);
		}
	}
}








// **************************
// *** Loading the Pages: ***
// **************************

if ($type=="web")	{
	$perms_clause = $BE_USER->getPagePermsClause(1);


	echo '

  // Create menu and mount the mounts
var oldMode = parent.theMenu.mode;
parent.createTheMenu();
var e = parent.theMenu;';

	if (is_array($WEBMOUNTS) && count($WEBMOUNTS))	{
	
			// Get mounts... We check if they exist and if we have the proper permissions to read them
		$idlist = implode($WEBMOUNTS,",");
		$mounts = Array();
		$query = "select uid, pid, ".$TCA["pages"]["ctrl"]["label"]." from pages where uid in ($idlist) AND NOT deleted AND ".$GLOBALS["perms_clause"];
		$res = mysql(TYPO3_db,$query);
		echo mysql_error();
		while ($row = mysql_fetch_assoc($res))	{
			$rl[$row["uid"]] = t3lib_BEfunc::BEgetRootLine($row["uid"],"AND ".$GLOBALS["perms_clause"]);
			$mounts[$row["uid"]] = $row;
		}
		if (t3lib_div::inList($idlist,"0"))	{		// This adds the root mount if any
			$mounts[0] = 1;
			$rl[0] = Array(Array("uid"=>0));
		}
		if (is_array($mounts))	{
			reset($mounts);
			while(list($theMountID,)=each($mounts))	{
				reset($rl);
				while(list($thisKey,$theRL)=each($rl))	{
					if ($thisKey!=$theMountID)	{
						while(list(,$val)=each($theRL))		{
							if ($val["uid"]==$theMountID)	{
								unset($rl[$thisKey]);
								break;
							}
						}
					}
				}
			}
		}

		$readThese=Array();
		if (is_array($rl))	{
			reset($rl);
			while(list($key,)=each($rl))	{
				$readThese[]=$key;
			}
		}

			// Check that the webmounts were actually pages!
		reset ($WEBMOUNTS);
		$newWebmounts=array();
		while (list($key,$uid) = each($WEBMOUNTS))	{
			if ($mounts[$uid])	{
				$newWebmounts[]=$uid;
			}
		}
		$WEBMOUNTS=$newWebmounts;	
		
			// Any mount that was found (+ if a mount was the root) is mounted
		reset ($WEBMOUNTS);
		while (list($key,$uid) = each($WEBMOUNTS))	{
			if ($mounts[$uid])	{
				echo "
e.addMount (".($key+1).");";
			}
		}

		reset ($WEBMOUNTS);
		while (list($key,$uid) = each($WEBMOUNTS))	{
			if ($mounts[$uid])	{
				if ($uid==0)	{
					$title = $GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"];				
					$pid = 0;
				} else {
					$title = strip_tags($mounts[$uid][$TCA[pages][ctrl][label]]);
					$pid = 100000;	// This is a temporary pid
				}
				echo "
e.aI(".$uid.",".$pid.",'".rawurlencode($title)."','','','_icon_website');";
				if (is_array($expUIDs[$uid]))	{
					printPreToggle($expUIDs[$uid]);
				}
			}
		}
echo "

  // Load the pages ";
		reset($readThese);
		while(list(,$val)=each($readThese))	{
			echo "\n\n";
			drawmenu($val,20);
		}
	}
	echo "

parent.theMenu.mode=oldMode;
parent.theMenu.resetLastPMClicked();
if (parent.content.nav_frame)	{ 
	parent.content.nav_frame.location = 'db_navframe.html';
	
}";

}	// Web finished






// *******************************
// *** Loading the folders: ***
// *******************************

if ($type=="file")	{
	echo "
  // Create menu and mount 
var oldMode = parent.fileMenu.mode;
parent.createFileMenu();
var e = parent.fileMenu;
var pagesTable = parent.TCA.pagesTable;";

	if (is_array($FILEMOUNTS))	{
		reset ($FILEMOUNTS);
		$foldercount = count($FILEMOUNTS);
		$c=0;
		while (list($key,) = each($FILEMOUNTS))	{
			$c++;
			echo "\ne.addMount (".$c.");";
		}
		reset ($FILEMOUNTS);
		$c=0;
		while (list($key,$val) = each($FILEMOUNTS))	{
			$md5_uid = md5($val[path]);		// The "m_" is prepended to ensure that the mounts are not overridden by ordinary folders...
			$specUID=hexdec(substr($md5_uid,0,6));
			switch($val[type])	{
				case "user":	$icon = "gfx/i/_icon_ftp_user.gif";	break;
				case "group":	$icon = "gfx/i/_icon_ftp_group.gif";	break;
				default:		$icon = "gfx/i/_icon_ftp.gif";	break;
			}
			$c++;
			echo "
e.aI(".($specUID).",".($c+100000).",'".rawurlencode($val[name])."','".$val[path]."','".$md5_uid."','".$icon."');";
			if (is_array($expUIDs[$specUID]))	{
				printPreToggle($expUIDs[$specUID]);
			}
		}
		reset ($FILEMOUNTS);
		while (list(,$val) = each($FILEMOUNTS))	{
			$md5_uid = md5($val[path]);
			$specUID=hexdec(substr($md5_uid,0,6));
			loadfolders ($val[path],0,8,$specUID);
		}

	echo "

parent.fileMenu.mode=oldMode;
parent.fileMenu.resetLastPMClicked();
if (parent.content.nav_frame)	{ 
	parent.content.nav_frame.location = 'file_navframe.html';
	
}";
	}
}


?>

parent.busy.set(0);
</script>
</body>
</HTML>
<?php
if ($TYPO3_CONF_VARS["BE"]["compressionLevel"])	{
	new gzip_encode($TYPO3_CONF_VARS["BE"]["compressionLevel"]);
}
?>