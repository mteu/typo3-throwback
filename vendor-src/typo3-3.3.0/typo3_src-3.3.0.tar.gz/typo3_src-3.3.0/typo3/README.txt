The "typo3 standard interface".

This is the official "backend-frontend" to Typo3. These scripts 
provides an interface for you to edit the database-content.
Other interfaces could be written utilizing the "main.php"
class from t3lib.

The standard-interface also provides an important framework for 
developers of modules.