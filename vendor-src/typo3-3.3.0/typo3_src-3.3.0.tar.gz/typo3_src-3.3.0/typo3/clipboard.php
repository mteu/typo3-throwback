<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This is the frameset to the clipboard window
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */







// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








include("init.php");



// ******************************
// Starting document output
// ******************************
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Typo 3.3 Clipboard</title>
</head>
<script language="javascript">
	function closing()	{
		if (parent.typoWin && parent.typoWin.clipBrd) {
			parent.typoWin.clipBrd.detach();
			close();
		} else {
			close();
		}
	}
	function reloadContent()	{
		parent.content.location='clipboard_content.html';
		parent.typoWin.clipBrd.updateButtons();
	}
	function uploadFiles(pad)	{
		parent.content.location='file_clipupload.php?pad='+pad;
	}
	function removeItem(itemNum)	{
		var item = parent.typoWin.clipBrd.bank[parent.typoWin.clipBrd.pad][itemNum];
		if (item)	{
			parent.typoWin.clipBrd.removeItem(parent.typoWin.clipBrd.pad, item.table, item.uid);
			reloadContent();
		}
	}
	function viewItem(itemNum)	{
		var item = parent.typoWin.clipBrd.bank[parent.typoWin.clipBrd.pad][itemNum];
		if (item)	{
			parent.typoWin.launchView(item.type=="db"?item.table:item.fullpath, item.uid);
		}
	}
	function select(cmd)	{
		parent.typoWin.clipBrd.select(parent.typoWin.clipBrd.pad,cmd);
		reloadContent();
	}
	function toggleItem(itemNum)	{
		var item = parent.typoWin.clipBrd.bank[parent.typoWin.clipBrd.pad][itemNum];
		if (item)	{
			item.act = item.act^1;
			reloadContent();
		}
	}
	function writeStyleSheet(document) {
		parent.typoWin.writeStyleSheet(document);
	}
	if (!parent.typoWin)	{
		alert("...");	// clipboard is opened
	}
	if (parent.typoWin)	{
		window.typoWin = parent.typoWin;
		globalBackgroundColor = parent.typoWin.TS.globalBackgroundColor;
		theBrowser = parent.typoWin.theBrowser;
		document.writeln ('<frameset rows="'+((parent.theBrowser.code=='NS')?'49':'46')+',*" framespacing="0" frameborder="0" border="no" onUnload="closing();">');
		document.writeln ('<frame name="menu" src="clipboard_menu.php" marginwidth="0" marginheight="0" frameborder="no" scrolling="no" noresize>');
		document.writeln ('<frame name="content" src="clipboard_content_dummy.html" marginwidth="0" marginheight="0" frameborder="no" scrolling="auto" noresize>');
		document.writeln ('</frameset>');
	}
	
</script>
</html>