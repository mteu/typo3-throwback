<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This script is called to load the file- og pagetree in the interface
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 

$BACK_PATH="";
include("init.php");
include("template.php");
//include("lang/LL_rte_user.php");


// ***************************
// Script Classes
// ***************************
class SC_rte_cleaner {
	var $content;
	var $siteURL;
	var $doc;	
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->siteURL = "http://".dirname(t3lib_div::getThisUrl());

		$this->doc = t3lib_div::makeInstance("template");
		$this->doc->backPath = $BACK_PATH;
		$this->doc->form = '';
		$this->doc->JScode='
		<script>
			var RTEobj = self.parent.parent;
		
			function setSelectedTextContent(content)	{
				var oSel = RTEobj.GLOBAL_SEL;
				var sType = oSel.type;
				if (sType=="Text")	{
					oSel.pasteHTML(content);
				}
			}
		</script>
		';
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$this->content="";
		$this->content.=$this->doc->startPage("RTE cleaner");

		$this->content.='
		<script>
//			alert(unescape("'.rawurlencode(t3lib_div::GPvar("processContent")).'"));
			setSelectedTextContent(unescape("'.rawurlencode(strip_tags(t3lib_div::GPvar("processContent"))).'"));
			RTEobj.edHidePopup();
		</script>
		';
	}
	function printContent()	{
		global $SOBE;
		$this->content.= $this->doc->endPage();
		echo $this->content;
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/rte_cleaner.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/rte_cleaner.php"]);
}





// Make instance:
$SOBE = t3lib_div::makeInstance("SC_rte_cleaner");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();
?>