<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Alternative TBE: Main frameset
 *
 * This is an alternative Typo3 Backend interface using the same modules, but designed to work with less capable browsers than MSIE.
 * This is probably in pre-alpha test as this time... so dont expect anything useful.
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



include("init.php");
include("template.php");


// ***************************
// Script Classes
// ***************************
class SC_alt_toplogo {
	var $content;
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_TEMPLATE,$TBE_STYLES;
		
		$this->content.='
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Logoframe</title>
</head>
<body bgColor="'.$TBE_TEMPLATE->bgColor2.'">';

		if ($TBE_STYLES["logo"])	{
			if (substr($TBE_STYLES["logo"],0,3)=="../")	{
				$imgInfo = @getimagesize(PATH_site.substr($TBE_STYLES["logo"],3));
			}
			$this->content.='<img src="'.$TBE_STYLES["logo"].'" '.$imgInfo[3].'>';
		} else {
			$this->content.='<a href="http://www.typo3.com/" target="_blank" onClick="'.$TBE_TEMPLATE->thisBlur().'"><img src="gfx/alt_backend_logo3.gif" width="117" height="32" border=0></a>';
		}
		$this->content.='
<BR>
</body>
</html>
		';
	}
	function printContent()	{
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_toplogo.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_toplogo.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_toplogo");
$SOBE->main();
$SOBE->printContent();

?>
