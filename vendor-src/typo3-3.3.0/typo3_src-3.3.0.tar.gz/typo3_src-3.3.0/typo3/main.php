<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * This configures the Typo3 Interface with all specific configuration like 
 * - tables / fields 
 * - buttons
 * - panes
 * - labels and messages
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */






// ***********************************************************************
// 
// THIS SCRIPT IS USED ONLY BY THE CLASSIC (and thereby obsolete) BACKEND
// Therefore no further development is planned.
// 
// ***********************************************************************








include("init.php");
include("template.php");
$interfaceConf=unserialize($BE_USER->uc["interfaceSetup"]);



if ($TYPO3_CONF_VARS["BE"]["disableClassic"])	{
	t3lib_BEfunc::typo3PrintError ("Interface Error","You cannot use the classic backend with this Typo3 installation.",0);
	exit;
}




// ******************************
// Start document output
// ******************************

?>
<!DOCTYPE html public "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE><?php echo ($GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"] ? $GLOBALS["TYPO3_CONF_VARS"]["SYS"]["sitename"]." [Typo".$TYPO_VERSION."]" : "Typo".$TYPO_VERSION);?></TITLE>
<META name="GENERATOR" content="Typo <?php echo$TYPO_VERSION;?> by www.typo3.com, (c) Kasper Sk�rh�j 1998-2002">

<SCRIPT LANGUAGE="JavaScript" SRC="md5.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript" SRC="main.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript" SRC="t3lib/jsfunc.evalfield.js"></SCRIPT>

<SCRIPT language="JavaScript">
/*
onerror = stopError;
function stopError() {
	alert("An error has occured");
	return true;
}
*/
<?php


// ******************************
// The modules are loaded
// ******************************
include_once(PATH_t3lib."class.t3lib_loadmodules.php");
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
$loadModules = t3lib_div::makeInstance("t3lib_loadModules");
$loadModules->load($TBE_MODULES);

//debug($LANG->mainLang[tabs_images]);
//t3lib_div::print_array($LANG->mainLang);
//t3lib_div::print_array($loadModules->modules);
//t3lib_div::print_array($loadModules->modListGroup);
//t3lib_div::print_array($loadModules->modListUser);
//t3lib_div::print_array($BE_USER->user);



// ********************************************
// Doing initialization of the user-settings
// *******************************************
$pane_web=explode(",",$BE_USER->uc["pane_web"]);
$pane_web_count=t3lib_div::intInRange(count($pane_web),1,7);
reset($pane_web);
while(list($n,$val)=each($pane_web))	{
	$LANG->mainLang[tabs]["webnav_".$n]=$val;	// These additions to the mainLang-array should generate the tabs in the webtree pane...
}

$pane_file=explode(",",$BE_USER->uc["pane_file"]);
$pane_file_count=t3lib_div::intInRange(count($pane_file),1,7);
reset($pane_file);
while(list($n,$val)=each($pane_file))	{
	$LANG->mainLang[tabs]["filenav_".$n]=$val;	// These additions to the mainLang-array should generate the tabs in the filetree pane...
}

$pane_clip_count = intval($BE_USER->uc["pane_clip_count"]);
if ($pane_clip_count>5) $pane_clip_count=5;		// max of 7 webtree tabs



// **********************************
// Beginning to spit out JavaScript
// **********************************
?>
// *************************
// ***   Initializing    ***
// *************************
function typoSetup	()	{
	this.fileicons = new Array();
<?php
	if (is_array($FILEICONS))	{
	reset ($FILEICONS);
		while (list($key,$val) = each($FILEICONS))	{
		echo "
	this.fileicons['".$key."'] = '".$val."';";
		}
	}
?>

	this.image_files = ',<?php echo $GLOBALS["TYPO3_CONF_VARS"]["GFX"]["imagefile_ext"];?>,';

	this.username = "<?php echo $BE_USER->user[username];?>";
	this.admin = <?php echo intval($BE_USER->user[admin]);?>;
	this.path = "gfx/";
	this.typo3Path = "<?php echo trim(PATH_typo3);?>";
	this.outline_path = "t3lib/gfx/ol/";
	this.iconpath = ""; // this.path+"i/";	
	this.notFoundIcon = "notfound.gif";
	this.serverpath = "";
	this.bP = <?php echo ($CLIENT["BROWSER"]=="net") ? "1" : "0";?>;
	this.thumbScript = '<?php echo ($GLOBALS["TYPO3_CONF_VARS"]["GFX"]["thumbnails"] ? "thumbs.php" : "gfx/notfound_thumb.gif");?>';
	this.helpUrl = '<?php echo t3lib_div::slashJS($LANG->typo3_help_url);?>';
	this.veriCode = '<?php echo $BE_USER->veriCode();?>';
	this.fieldHelpMode = '<?php echo $BE_USER->uc["edit_showFieldHelp"];?>';
	this.dontEditInPageModule = <?php echo (!$loadModules->modules["web"]["sub"]["layout"]||$BE_USER->uc["dontEditInPageModule"]?1:0);?>;
	this.classicPageEditMode = <?php echo ($BE_USER->uc["classicPageEditMode"]?1:0);?>;
	this.fe_script = '../index.php';
	this.fe_uid = 'id';
	this.maxDocs = 30;
	this.maxItemsDefault = 1;
	this.decimalSign = ".";
	this.charSetMeta = '<meta http-equiv="Content-Type" content="text/html; charset="<?php echo ($GLOBALS["TYPO3_CONF_VARS"]["BE"]["charSet"] ? $GLOBALS["TYPO3_CONF_VARS"]["BE"]["charSet"] : "iso-8859-1") ?>">';
	this.globalBackgroundColor = "<?php echo $GLOBALS["TBE_TEMPLATE"]->bgColor;?>";
	this.globalBackgroundColor2 = "<?php echo $GLOBALS["TBE_TEMPLATE"]->bgColor2;?>";
	this.globalFont_b = <?php echo $CLIENT["SYSTEM"]=="unix" ? '\'<FONT face="Sans-serif" size="2">\';' : '\'<FONT face="VERDANA, ARIAL" size="1">\';';?>
	this.globalFont_e = '</FONT>';
	this.maxNumberFaner =<?php echo $pane_clip_count;?>;
	this.webModeCount =<?php echo $pane_web_count;?>;	// At least 1 max 7
	this.fileModeCount =<?php echo $pane_file_count;?>;	// At least 1 max 7
	this.clipCount =<?php echo $pane_clip_count;?>;	// Number of number-tabs on the clipBoard
	this.thumbmode = <?php echo intval($BE_USER->uc[thumbnailsByDefault]);?>;	// If thumbnails are shown as standard in file-listings
	this.passwordDummy = "********";
	this.docLarge = "<?php echo $BE_USER->uc["edit_wideDocument"] ? "_large" : ""; ?>";
	this.docUpload = <?php echo $BE_USER->uc["edit_docModuleUpload"] ? 1 : 0; ?>;
	this.isUpload = <?php
		$fileProcessor = t3lib_div::makeInstance("t3lib_basicFileFunctions");
		$fileProcessor->init($FILEMOUNTS, $TYPO3_CONF_VARS["BE"]["fileExtensions"]);
		$path = $fileProcessor->findTempFolder();	// The closest TEMP-path is found
		echo $path ? 'unescape("'.rawurlencode($path).'")' : 0;
	?>;
	this.docRTE = <?php echo ($BE_USER->isRTE()) ? 1 : 0; ?>;
	this.RTEkeyList = '<?php 
		$RTEkeyList = isset($BE_USER->userTS["options."]["RTEkeyList"]) ? $BE_USER->userTS["options."]["RTEkeyList"] : "*";
		echo rawurlencode($RTEkeyList); 
		?>';
	this.langKey = '<?php echo $LANG->lang;?>';
	this.which_os = '<?php echo TYPO3_OS;?>';
	this.uniqueID = '<?php echo t3lib_div::shortMD5(uniqid(""));      // shortMD5 260900     
	?>'; 
	
	this.maxTextareaWidth = 48;
	this.formStyle = <?php echo $GLOBALS["CLIENT"]["FORMSTYLE"] ? 1 : 0; ?>;
	this.largeComp = <?php echo $GLOBALS["TBE_TEMPLATE"]->form_largeComp; ?>;
	this.rowsToStylewidth = <?php echo $GLOBALS["TBE_TEMPLATE"]->form_rowsToStylewidth; ?>;
	this.charsPerRow =<?php
		echo (($CLIENT["BROWSER"]=="net") ? "30" : "25") ;
	?>;
}

	TS = new typoSetup();	// Typo setup object
	var path = TS.path;		// Backwards komp..

		// globale vars:
	var statusTimeout = 0;
	var pageX = 0;
	var pageY = 0;
	var mouseX = 0;
	var mouseY = 0;

	
		// Objects in Typo
	var data = new dataObj();							// Dataobject. Contains the records as they are loaded
	var editWin = new editWinObj();						// Controls the documents
	var fileCmd = new fileCmd();						// Execute file-administration commands
	var funcMgr = new funcManager();					// Takes care of a lot of functions regarding the clickmenus
	var propertyFrame = new pFrame ('help');			// Manages the switching between sections in Typo
	var langObj = new langVer();						// Contains the labels and messages in the selected language
	var rollMenu = new rollMenu();						// The Roll-menu is used as a menu different places
	var executeStat = new executeStat;					// This object is used to execute JS-code if a document from another domain does not have the proper rights (eg. the document-property is readonly sometimes)
	var busy = new busy(<?php echo $BE_USER->auth_timeout_field;?>);	// Controls if Typo is currently busy doing something (like communicating with the server
	var dbPathRef = new thumbRef();						// This holds some references to paths of records
	var thumbRef = new thumbRef();						// This holds some references to thumbsnails of images


	var evalFunc = new evalFunc;
	var theBrowser = new browserInfo;					// Contains browserinformation
	var buttons = new Array();
	var bottonsFrameLoaded=0;
	
// *****************
// ***  Language ***
// *****************
<?php
$LANG->printJS();
?>

// ******************
// ***   Images   ***
// ******************

	var glImage = new glImageObj();
		// Number tabs for clipBoard.
	for (a=1; a <= TS.maxNumberFaner; a++)	{
		glImage.add ('fane_'+a, 20, 12, TS.path+'mode'+a+'_n.gif');
	}


		// Images for buttons
<?php
$LANG->printButtonsToJS();	
?>


// Images for tabs in the panes
	glImage.add ('fane_spacer', 3, 12, 'clear.gif');
<?php
$LANG->printTabsToJS();	
?>

// Misc
	glImage.add ('sys_busy', 19, 14, 'clear.gif', 'gfx/refresh.gif', 'gfx/working.gif');
	glImage.add ('refresh', 14, 14, TS.path+'refresh_n.gif', '', TS.path+'refresh_h.gif', '');

		// Images for the click-menus:
	glImage.add ('menu_dummy', 114, 12, TS.path+'clickmenu/menu_dummy.gif');
<?php
$LANG->printClickmenuToJS();	
?>




// ***********************************************
// ***   TCAtables   (Typo Config Array = $TCA) ***
// ***********************************************
function tcaTablesItem (name, title, typeField, mainpalette, orderBy, labelCol, iconfile)	{
	this.name = name;
	this.title = title;
	this.iconfile = iconfile ? iconfile : name+'.gif';
	this.fields = new Array();
	this.fieldNames = new Array();
	this.fieldCount = 0;
	
	this.types = new tcaTablesItemType();
	this.typeCount = 0;
	
	this.typeField = typeField;
	this.mainpalette = mainpalette;
	this.orderBy = orderBy;
	this.labelCol = labelCol;
}
function tcaTables (pagesTable, contentTable)	{
	this.pagesTable = pagesTable;
	this.contentTable = contentTable;
	
	this.tables = new tcaTablesItem('','','');
	this.tableNames = new Array();
	this.tableCount = 0;
	
	this.palettes = new tcaTablesPalette ('','','');
	this.paletteNames = new Array();
	this.paletteCount = 0;
<?php
function prItem($arr,$key, $name)	{
	if (isset($arr[config][$key]))	{
		$value = $arr[config][$key];
		if (ereg("['".chr(10).chr(13)."]",$value))	{
			echo $name."=unescape('".rawurlencode($value)."');";	
		} elseif (intval($value) || (string)$value=="0") 	{
			echo $name."=".$value.";";
		} else {	echo $name."='".$value."';";	}
	}
}


if (is_array($TCA))	{
		// Getting descriptions (only if chosen)
	if ($BE_USER->uc["edit_showFieldHelp"])	{
		$TCA_DESCR=t3lib_BEfunc::loadTablesDescriptions($LANG->lang!="default"?$LANG->lang:"");
		$TCA_DESCR_outputArray=array();
	}
		// TCA:
	$temp_tc=Array();
	reset ($TCA);
	while (list($tableName,$tableValue) = each($TCA))	{
		t3lib_div::loadTCA($tableName);
		$temp_tc[$tableName]=$LANG->sL($tableValue["ctrl"]["title"]);
	}
	reset ($TCA);
	while (list($tableName,$tableValue) = each($TCA))	{
	if ($BE_USER->check("tables_select",$tableName))	{
		if ($BE_USER->uc["edit_showFieldHelp"])	{
			t3lib_BEfunc::loadSingleTableDescription($tableName,$LANG->lang);
		}
	
		echo "

// New tabel 
	this.tableCount++;
	this.tables['$tableName'] = new tcaTablesItem('$tableName', '".t3lib_div::slashJS($LANG->sL($tableValue[ctrl][title]))."','".$tableValue[ctrl][type]."','".$tableValue[ctrl][mainpalette]."','".$tableValue[ctrl][sortby]."','".$tableValue[ctrl][label]."','".t3lib_iconWorks::getIcon($tableName)."');
	this.tableNames[this.tableCount] = '$tableName';	\n";
		if (is_array($tableValue["columns"]))	{
			reset ($tableValue["columns"]);
			$a=0;
			while (list($fieldName,$fieldValue) = each($tableValue["columns"]))	{
				if ((!$fieldValue["exclude"] || $BE_USER->check("non_exclude_fields",$tableName.":".$fieldName)) && $fieldValue["config"]["type"]!="passthrough")	{
						// setting the description:
					if ($BE_USER->uc["edit_showFieldHelp"] && is_array($TCA_DESCR[$tableName]["columns"][$fieldName]))	{
						$TCA_DESCR_outputArray[$tableName.".".$fieldName]=$BE_USER->uc["edit_showFieldHelp"]=="icon"?1:$TCA_DESCR[$tableName]["columns"][$fieldName]["description"];
					}
				
					$type = $fieldValue["config"]["type"];
					$a++;
					echo "		this.tables['$tableName'].fieldNames[$a] = '$fieldName';	
		this.tables['$tableName'].fields['$fieldName'] = new fielddraw_$type('$tableName','$fieldName'".(($fieldValue[label])? ",'".$LANG->sL($fieldValue[label])."'" : "").");";
					echo "			with(this.tables['$tableName'].fields['$fieldName'])	{";
					$aa=0;	// Item-counter
					if (is_array($fieldValue["config"]["items"]))	{
						if ($type=="select" && $fieldValue["config"]["itemsProcFunc"])  {
							$iPF_params=array();
							$iPF_params["items"] = &$fieldValue["config"]["items"];
							$iPF_params["config"] = $fieldValue["config"];
							$iPF_params["TSconfig"] = array();
							$iPF_params["table"] = $tableName;
							$iPF_params["row"] = array();
							$iPF_params["field"] = $fieldName;
							$_dummy="";
							t3lib_div::callUserFunction($fieldValue["config"]["itemsProcFunc"],$iPF_params,$_dummy,"user_",1);
						}
						reset ($fieldValue["config"]["items"]);
						while (list($itemName,$itemValue) = each($fieldValue["config"]["items"]))	{
							$aa++;
							echo " itemNames[$aa] = '".t3lib_div::slashJS($LANG->sL($itemValue[0]))."';";
							echo " itemValues[$aa] = '".t3lib_div::slashJS($itemValue[1])."';";
						}
						echo " itemNum = $aa;";
					}
					prItem($fieldValue,"default","defVal");
					if ($type == "input")	{
						prItem($fieldValue,"size","size");
						prItem($fieldValue,"max","max");
						if (isset($fieldValue[config]['checkbox']))	{echo "checkbox='1';checkboxValue='".$fieldValue[config]['checkbox']."';";}
						prItem($fieldValue,"eval","evallist");
						prItem($fieldValue,"is_in","is_in");
						if (isset($fieldValue[config]['range']['upper']))	{echo " range_upper = '".$fieldValue[config]['range']['upper']."';";}
						if (isset($fieldValue[config]['range']['lower']))	{echo " range_lower = '".$fieldValue[config]['range']['lower']."';";}
					}
					if ($type == "text")	{
						prItem($fieldValue,"cols","cols");
						prItem($fieldValue,"rows","rows");
						prItem($fieldValue,"wrap","wrap");
					}
					if ($type == "select")	{
						prItem($fieldValue,"size","size");
						prItem($fieldValue,"multiple","multiple");
						prItem($fieldValue,"maxitems","maxitems");
						prItem($fieldValue,"minitems","minitems");

						// 	 * This code below is PARALLEL to the one found in class.t3lib_tceforms.php. 
						//   * If anything is changed here, consider the same change in the other script as well!
						
						if ($fieldValue["config"]["foreign_table"])	{
							$query = t3lib_BEfunc::foreign_table_where_query($fieldValue);
							$res = @mysql (TYPO3_db, $query);
							if (mysql_error())	{ 
								echo "}\n</script>\n";
								debug(array(mysql_error()."\n\nQuery:\n ".$query."\n\nThis may indicate a table defined in tables.php is not existing in the database!"));
								exit;
							}
							while ($row = mysql_fetch_assoc($res))	{
								$aa++;
								echo " itemNames[$aa]=unescape('".rawurlencode(t3lib_div::fixed_lgd($LANG->sL($fieldValue["config"]["foreign_table_prefix"]).strip_tags(t3lib_BEfunc::getRecordTitle($fieldValue["config"]["foreign_table"],$row)),$BE_USER->uc["titleLen"]))."');";
								echo " itemValues[$aa]='".$row[uid]."';";
							}
							if ($fieldValue["config"]["neg_foreign_table"])	{
								$query = t3lib_BEfunc::foreign_table_where_query($fieldValue,"",array(),"neg_");
								$res = @mysql (TYPO3_db, $query);
								if (mysql_error())	{ 
									echo "}\n</script>\n";
									debug(array(mysql_error()."\n\nQuery:\n ".$query."\n\nThis may indicate a table defined in tables.php is not existing in the database!"));
									exit;
								}
								while ($row = mysql_fetch_assoc($res))	{
									$aa++;
									echo " itemNames[$aa]=unescape('".rawurlencode(t3lib_div::fixed_lgd($LANG->sL($fieldValue["config"]["neg_foreign_table_prefix"]).strip_tags(t3lib_BEfunc::getRecordTitle($fieldValue["config"]["foreign_table"],$row)),$BE_USER->uc["titleLen"]))."');";
									echo " itemValues[$aa]='".(-$row["uid"])."';";
								}
							}
							echo " itemNum = $aa;";
						}
						if ($fieldValue["config"]["special"])	{
							switch ($fieldValue["config"]["special"])	{
								case "tables":
									reset($temp_tc);
									while (list($theTableNames,$tableTitle)=each($temp_tc))	{
										if (!$TCA[$theTableNames]["ctrl"]["adminOnly"])	{
											$aa++;
											echo " itemNames[$aa]='".t3lib_div::slashJS($tableTitle)."';";
											echo " itemValues[$aa]='".$theTableNames."';";
										}
									}
									echo " itemNum = $aa;";
								break;
								case "pagetypes":
									$theTypes = $TCA["pages"]["columns"]["doktype"]["config"]["items"];
									reset($theTypes);
									while (list(,$theTypeArrays)=each($theTypes))	{
										$aa++;
										echo " itemNames[$aa]='".$LANG->sL($theTypeArrays[0])."';";
										echo " itemValues[$aa]='".$theTypeArrays[1]."';";
									}
									echo " itemNum = $aa;";
								break;
								case "exclude":
									$theTypes = t3lib_BEfunc::getExcludeFields();
									reset($theTypes);
									while (list(,$theTypeArrays)=each($theTypes))	{
										$aa++;
										echo " itemNames[$aa]='".t3lib_div::slashJS(ereg_replace(":$","",stripslashes($theTypeArrays[0])))."';";
										echo " itemValues[$aa]='".$theTypeArrays[1]."';";
									}
									echo " itemNum = $aa;";
								break;
								case "modListGroup":
									if (is_array($loadModules->modListGroup))	{
										reset($loadModules->modListGroup);
										while (list(,$theMod)=each($loadModules->modListGroup))	{
											$aa++;
											echo " itemNames[$aa]='".$theMod."';";
											echo " itemValues[$aa]='".$theMod."';";
										}
									}
									echo " itemNum = $aa;";
								break;
								case "modListUser":
									if (is_array($loadModules->modListUser))	{
										reset($loadModules->modListUser);
										while (list(,$theMod)=each($loadModules->modListUser))	{
											$aa++;
											echo " itemNames[$aa]='".$theMod."';";
											echo " itemValues[$aa]='".$theMod."';";
										}
									}
									echo " itemNum=$aa;";
								break;
							}
						}
					}
					if ($type == "group")	{
						prItem($fieldValue,"internal_type","internal_type");
						prItem($fieldValue,"show_thumbs","show_thumbs");
						prItem($fieldValue,"multiple","multiple");
						prItem($fieldValue,"size","size");
						prItem($fieldValue,"maxitems","maxitems");
						prItem($fieldValue,"minitems","minitems");
							// Files
						prItem($fieldValue,"allowed","allowed");
						prItem($fieldValue,"disallowed","disallowed");
						prItem($fieldValue,"max_size","max_size");
						if (isset($fieldValue[config]['uploadfolder']))	{echo "uploadfolder='../".$fieldValue[config]['uploadfolder']."/';";}
							// Tables
						prItem($fieldValue,"allowed","tables");
						$info="";
						if ($fieldValue[config]['internal_type']=="file")	{
							$tempFT = t3lib_div::trimExplode(",",$fieldValue[config]['allowed'],1);
							reset($tempFT);
							if (!count($tempFT))	{$info.='*';}
							while(list(,$ext)=each($tempFT))	{
								if ($ext)	{
									$info.=strtoupper($ext)." ";
								}
							}
							$tempFT = t3lib_div::trimExplode(",",$fieldValue[config]['disallowed'],1);
							reset($tempFT);
							if (count($tempFT))	{$info.='<BR>';}
							while(list(,$ext)=each($tempFT))	{
								if ($ext)	{
									$info.="-".strtoupper($ext)." ";
								}
							}
						}
						if ($fieldValue["config"]["internal_type"]=="db")	{
							$tempFT = explode(",",$fieldValue["config"]["allowed"]);
							if (!strcmp(trim($tempFT[0]),"*"))	{
								$info.='<NOBR>&nbsp;&nbsp;&nbsp;&nbsp;'.$LANG->mainLang["labels"]["allTables"].'</NOBR><BR>';
							} else {
								while(list(,$theT)=each($tempFT))	{
									if ($theT)	{
										$info.='<NOBR>&nbsp;&nbsp;&nbsp;&nbsp;<img src="'.t3lib_iconWorks::getIcon($theT).'" width=18 height=16 align="top"> '.$LANG->sL($TCA[$theT]["ctrl"]["title"]).'</NOBR><BR>';
									}
								}
							}
						}
						echo "info=unescape('".rawurlencode($info)."');";
					}
					if ($type == "check")	{
						prItem($fieldValue,"cols","cols");
						prItem($fieldValue,"showIfRTE","showIfRTE");
						if (!$fieldValue[config][items])	{
							echo " itemNames[1] = '';";
							echo " itemValues[1] = ".intval($fieldValue[config]['default']).";";
							echo " itemNum = 1;";
						}
					}
				echo "}\n";
				}
			}	
			echo "\n		this.tables['$tableName'].fieldCount = $a;";}			
			// all field for one table finish...
			
		if (is_array($tableValue["types"]))	{
			reset ($tableValue["types"]);
			while (list($typeName,$typeValue) = each($tableValue["types"]))	{
				echo "
		this.tables['$tableName'].types['$typeName'] = new tcaTablesItemType('');";
				echo "		with(this.tables['$tableName'].types['$typeName'])	{";
				$fields = explode(",", $typeValue["showitem"]);
				while (list($itemName,$itemValue) = each($fields))	{
					$parts = explode(";", $itemValue);
					$parts[1] = trim($LANG->sL($parts[1]));
					echo " items['$itemName'] = '".trim($parts[0])."';";
					echo ($parts[1]) ? " altlabel['$itemName'] = '".$parts[1]."';" : "";
					echo (trim($parts[2])) ? " palette['$itemName'] = '".trim($parts[2])."';" : "";
					echo (trim($parts[3])) ? " specConf['$itemName'] = '".trim($parts[3])."';" : "";
				}
					echo " itemCount = '".count($fields)."';   }";
			}
		}
		if (is_array($tableValue["palettes"]))	{
			reset ($tableValue["palettes"]);
			while (list($palName,$palValue) = each($tableValue["palettes"]))	{
				echo "
	// Palette-configuration:			
	this.paletteCount++;
	this.palettes['".$tableName."_".$palName."'] = new tcaTablesPalette ('".$palValue[title]."','".$tableName."',this.paletteCount);
	this.paletteNames[this.paletteCount] = '".$tableName."_".$palName."';	";
				$fields = explode(",", $palValue[showitem]);
				while (list($itemName,$itemValue) = each($fields))	{
					$parts = explode(";", $itemValue);
					echo "\n		this.palettes['".$tableName."_".$palName."'].items['$itemName'] = '".trim($parts[0])."';";
					echo (trim($parts[1])) ? "\n		this.palettes['".$tableName."_".$palName."'].altlabel['$itemName'] = '".trim($parts[1])."';" : "";
				}
					echo "\n		this.palettes['".$tableName."_".$palName."'].itemCount = '".count($fields)."';";
			}
		}
	}	// if...
	}	// while
}	


?>

// Diverse:
	this.getField = tcaTables_getField;
	this.getRecord = tcaTables_getRecord;
	this.getPalette = tcaTables_getPalette;
	
	this.currentPaletteNum = 0;
	this.currentPaletteTable = '';
	this.currentPaletteID = '';
	this.showPalette = tcaTables_showPalette;
}
var TCA = new tcaTables('pages','<?php echo $GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"];?>');
<?php

	// Finalizing descriptions:
	echo "\nvar TCA_DESCR = new array();";
	if ($BE_USER->uc["edit_showFieldHelp"])	{
		reset($TCA_DESCR_outputArray);
		if ($BE_USER->uc["edit_showFieldHelp"]=="icon")	{
			while(list($uk,$descrVal)=each($TCA_DESCR_outputArray))	{
				echo "\n TCA_DESCR['".$uk."']=1;";
			}
		} else {
			while(list($uk,$descrVal)=each($TCA_DESCR_outputArray))	{
				echo "\n TCA_DESCR['".$uk."']=unescape('".str_replace("%20"," ",rawurlencode($descrVal))."');";
			}
		}
	}
?>

// ****************************
// ***   Modules and Panes  ***
// ****************************

	// Pane for clipboard
		faner_clip = new faneBar ('parent.clipBrd.clipboard.menu', TS.path+'faner/', 'clip_faner', 'parent.typoWin.faner_clip', 245, '#CCCCCC', '#848284', 23);
		faner_clip.add ('normal', 1, 'clipBrd.swPad(this.current); clipBrd.clipboard.reloadContent();', 'fane_normal', langObj.get('l_clipNormal'));

		label = langObj.get('l_cliptabs');
		for (var a=1; a <= TS.clipCount; a++)	{
			faner_clip.add ('mode'+a, 1, 'clipBrd.swPad(this.current); clipBrd.clipboard.reloadContent();', 'fane_'+a, label+a);
		}

		faner_clip.add ('_', 1, '', 'fane_spacer', '');
<?php
	if ($loadModules->modules["web"])	{
	echo "
		faner_clip.add ('db', 1, 'clipBrd.swPad(this.current); clipBrd.clipboard.reloadContent();', 'fane_web_tab', langObj.get('l_dblist'));";
	}
	if ($loadModules->modules["file"])	{
	echo "
		faner_clip.add ('file', 1, 'clipBrd.swPad(this.current); clipBrd.clipboard.reloadContent();', 'fane_file_tab', langObj.get('l_filelist'));";
	}
?>

// Main pane, upper left
		mods = new modArray();	// modules object

		menuFaner = new faneBar ('parent.mainMenu_frame', TS.path+'faner/', 'menuFaner', 'parent.menuFaner', 425, '#CCCCCC', '#848284', 20);
		menuFaner.current='help';
<?php
	if (is_array($loadModules->modules))	{
		reset ($loadModules->modules);
		while(list($ref,$data)=each($loadModules->modules))	{
			if (!is_array($data))	{
				echo "
		menuFaner.add ('_', 1, 'parent.propertyFrame.loadMod(\"datatest\");', 'fane_spacer', '');";
			} else {
				$pal = (is_array($data[sub]) && count($data[sub])) ? "modLayer".$ref : "";
				$cpal = ($data[cpalScript]) ? "modLayer".$ref : "";
				$fr = t3lib_div::split_fileref($data["script"]);
				echo "
		menuFaner.add ('".$ref."', 1, 'mods.load(\"".$ref."\");', 'fane_".$ref."_tab', langObj.get ('l_".$ref."_tablabel'));
		mods.add('".$ref."','".$fr[file]."','".$pal."','".$cpal."','".$fr[path]."','".$data["defaultMod"]."');";
/*
				if ($interfaceConf[mod][$ref][currentURL])	{
					echo "
		mods.modules['".$ref."'].currentUrl='".t3lib_div::slashJS($interfaceConf[mod][$ref][currentURL])."';";
				}
				*/
				if ($interfaceConf[mod][$ref][currentSub])	{
					echo "
		mods.modules['".$ref."'].currentSub='".t3lib_div::slashJS($interfaceConf[mod][$ref][currentSub])."';";
				}
			}
		}
	}
	
	
	if ($loadModules->modules["web"])	{		// the special pane for the web-tree
?>

	buttons['refresh_web'] = new button ('refresh_web', 1, 'parent.theWebTreeIsLoaded=0;parent.reloadCurrentWin();', 'refresh', langObj.get('l_refresh'), 'parent.palette_frame.dom_getObj("modLayerweb")', 'parent.buttons[\'refresh_web\']');
	
	// Pane for the WebTree
		faner_nf = new faneBar ('parent.palette_frame.dom_getObj("modLayerweb")', TS.path+'faner/', 'webbanks', 'parent.faner_nf', 220, '#CCCCCC', '#848284', 6);
		label = langObj.get('l_webtabs');
<?php
		if (is_array($pane_web))	{
			reset($pane_web);
			while(list($n,$tableValue)=each($pane_web))	{
				echo "
				faner_nf.add ('webbank".($n+1)."', 1, 'parent.executeStat.set(\"parent.theMenu.chMode(".($n+1).");\");', 'fane_webnav_".$n."', label+'".($n+1)."');	";
			}
		}
	}
	if ($loadModules->modules["file"])	{		// the special pane for the directory-tree
?>

	buttons['refresh_file'] = new button ('refresh_file', 1, 'parent.theFileTreeIsLoaded=0;parent.reloadCurrentWin();', 'refresh', langObj.get('l_refresh'), 'parent.palette_frame.dom_getObj("modLayerfile")', 'parent.buttons[\'refresh_file\']');
	
	// Pane for the DirectoryTree
		faner_dir = new faneBar ('parent.palette_frame.dom_getObj("modLayerfile")', TS.path+'faner/', 'filebanks', 'parent.faner_dir', 220, '#CCCCCC', '#848284', 6);
		label = langObj.get('l_filetabs');
<?php
		if (is_array($pane_file))	{
			reset($pane_file);
			while(list($n,$tableValue)=each($pane_file))	{
				echo "
				faner_dir.add ('filebank".($n+1)."', 1, 'parent.executeStat.set(\"parent.fileMenu.chMode(".($n+1).");\");', 'fane_filenav_".$n."', label+'".($n+1)."');	";
			}
		}
	}


	if (is_array($loadModules->modules))	{
		reset ($loadModules->modules);
		while(list($ref,$data)=each($loadModules->modules))	{
			if (is_array($data) && is_array($data[sub]) && count($data[sub]))	{
				echo "
	// Pane for the module ".$ref."
		modPane_".$ref." = new faneBar ('parent.palette_frame.dom_getObj(\"modLayer".$ref."\")', TS.path+'faner/', 'mod_".$ref."', 'parent.modPane_".$ref."', ".(($ref=="web"||$ref=="file")?395:643).", '#CCCCCC', '#848284', 6);";
				reset($data[sub]);
				while(list($subref,$subdata)=each($data[sub]))	{
					if (!is_array($subdata))	{
						echo "
		modPane_".$ref.".add ('_', 1, '', 'fane_spacer', '');";
					} else {
						$cpal = ($subdata[cpalScript]) ? "modLayer".$ref."SUB".$subref : "";
						$fr = t3lib_div::split_fileref($subdata["script"]);
				//		$submodUrl = $interfaceConf[submod][$ref."_".$subref][currentURL];
				//		$submodUrl = $submodUrl ? $submodUrl : $fr[file];
						$submodUrl = $fr[file];
						echo "
		modPane_".$ref.".add ('modPane_".$ref."_".$subref."', 1, 'mods.loadSub(\"".$ref."\", \"".$subref."\");', 'fane_".$ref."_".$subref."_tab', langObj.get ('l_".$ref."_".$subref."_tablabel'));
		mods.modules['".$ref."'].add('".$subref."','".$submodUrl."','".$cpal."','".$fr[path]."');
		";			
					}
				}
			}
		}
	}
?>

function writeFrameContent(theContent)	{
	theCode = '';
	switch (theContent)	{
		case "editMenu":
			theCode+='<FORM action="" method="POST" name="docForm"><TABLE border="0" cellpadding="0" cellspacing="0" width="200"><TR><TD>';
			theCode+=buttons['pilleft'].draw('');
			theCode+='</TD><TD><SELECT name="docs" onChange="swDoc(this);"><OPTION value="">_____________________________</OPTION><OPTION></OPTION><OPTION></OPTION><OPTION></OPTION><OPTION></OPTION><OPTION></OPTION><OPTION></OPTION><OPTION></OPTION></SELECT></TD><TD>';
			theCode+=parent.buttons['pilright'].draw('');
			theCode+='</TD><TD><IMG src="clear.gif" width="20" height="1">';
			theCode+='</TD><TD>';
			theCode+=rollMenu.menu['editMenu'].write(0);
			theCode+='</TD><TD><IMG src="clear.gif" width="20" height="1">';
			theCode+='</TD><TD>';
			theCode+=parent.buttons['savedok'].draw('');
			theCode+='</TD><TD><IMG src="clear.gif" width="5" height="1">';
			theCode+='</TD><TD>';
			theCode+=parent.buttons['saveandclosedok'].draw('');
			theCode+='</TD><TD><IMG src="clear.gif" width="5" height="1">';
			theCode+='</TD><TD>';
			theCode+=parent.buttons['closedok'].draw('');
			theCode+='</TD><TD><IMG src="clear.gif" width="5" height="1">';
			theCode+='</TD><TD>';
			theCode+=parent.buttons['viewdok'].draw('');
			theCode+='</TD>';
			theCode+='</TR></TABLE></FORM>';
		break;
<?php		
	if (is_array($loadModules->modules))	{
		reset ($loadModules->modules);
		while(list($ref,$data)=each($loadModules->modules))	{
			if (is_array($data) && is_array($data[sub]) && count($data[sub]))	{
				echo "
		case \"modLayer_".$ref."_pal\":
			theCode+='<table border=0 cellpadding=0 cellspacing=0 width=643>';
			theCode+='<tr><td>';";

				if ($ref=="web")	{
					echo "
			theCode+=faner_nf.draw('', '<img src=\"clear.gif\" width=1 height=1>');
			theCode+='</td><td nowrap>&nbsp;'+buttons['refresh_web'].draw('')+'&nbsp;&nbsp;';";
				}
				if ($ref=="file")	{
					echo "
			theCode+=faner_dir.draw('', '<img src=\"clear.gif\" width=1 height=1>');
			theCode+='</td><td nowrap>&nbsp;'+buttons['refresh_file'].draw('')+'&nbsp;&nbsp;';";
				}
				if ($ref=="web" || $ref=="file")	{
					echo "
			theCode+='</td><td width=100%>';
			theCode+='</td><td>';";
				}
				
				echo "
			theCode+=modPane_".$ref.".draw('', '<img src=\"clear.gif\" width=1 height=1>');
			theCode+='</td>';
			theCode+='</tr></table>';
		break;	";					
			}
		}
	}
?>

}
	return theCode;
}



// ***************************************
// ***   Restore interface positions   ***
// ***************************************
<?php
if ($BE_USER->uc["startInTaskCenter"] && $BE_USER->check("modules","user_task"))	{
		echo "
	menuFaner.current='user';
	mods.modules['user'].currentSub='task';";
} elseif (is_array($interfaceConf) && $interfaceConf["currentMenuFane"])	{
		echo "
	menuFaner.current='".$interfaceConf["currentMenuFane"]."';";
}
	
?>

// *******************
// ***   Diverse   ***
// *******************
<?php
$res = mysql (TYPO3_db, "select uid from sys_log order by uid DESC limit 0,1");
if ($row = mysql_fetch_assoc($res))	{
	echo "var logid = ".$row[uid].";";
} else {
	echo "var logid = 0;";
}
?>

				// **************************
				// ***   INITIALIZATION   ***
				// **************************


		
// *******************
// ***   Buttons   ***
// *******************



		buttons['clipboard'] = new button ('clipboard', 1, 'parent.clipBrd.open();', 'button_clipboard', langObj.get('l_clip'), 'parent.nButtons_frame', 'parent.buttons[\'clipboard\']');
		buttons['logout'] = new button ('logout', 1, 'parent.logout();', 'button_logout', langObj.get('l_logout'), 'parent.nButtons_frame', 'parent.buttons[\'logout\']');
	
		glImage.add ('selectmode', 21, 16, TS.path+'selectmode_n.gif', TS.path+'selectmode_d.gif', TS.path+'selectmode_h.gif', TS.path+'selectmode_s.gif');
		glImage.add ('copymode', 21, 16, TS.path+'copymode_n.gif', '', TS.path+'copymode_h.gif', TS.path+'copymode_s.gif');
		glImage.add ('thumbmode', 21, 16, TS.path+'thumb_n.gif', '', TS.path+'thumb_h.gif', TS.path+'thumb_s.gif');
		buttons['selectmode'] = new button ('img_selectmode', 1, 'parent.funcMgr.selectmodeToggle();', 'selectmode', langObj.get('l_selectmode'), 'parent.nButtons_frame', 'parent.buttons[\'selectmode\']');
		buttons['thumbmode'] = new button ('img_thumbmode', 1, 'parent.thumbmodeToggle();', 'thumbmode', langObj.get('l_thumbmode'), 'parent.nButtons_frame', 'parent.buttons[\'thumbmode\']');
		buttons['thumbmode'].state = TS.thumbmode;
		buttons['thumbmode_clip'] = new button ('img_thumbmode', 1, 'parent.clipBrd.thumbmodeToggle();', 'thumbmode', langObj.get('l_thumbmode_clip'), 'parent.clipBrd.clipboard.menu', 'parent.typoWin.buttons[\'thumbmode_clip\']');
		buttons['copymode_clip'] = new button ('img_copymode', 1, 'parent.clipBrd.copymodeToggle();', 'copymode', langObj.get('l_copymode'), 'parent.clipBrd.clipboard.menu', 'parent.typoWin.buttons[\'copymode_clip\']');
		buttons['clear_clip'] = new button ('clear', 1, 'parent.clipBrd.clrSelected(parent.clipBrd.pad);', 'button_clear', langObj.get('l_clearClip'), 'parent.clipBrd.clipboard.menu', 'parent.typoWin.buttons[\'clear_clip\']');
		
		glImage.add ('pilleft', 14, 14, TS.path+'pilleft_n.gif');
		glImage.add ('pilright', 14, 14, TS.path+'pilright_n.gif');
		buttons['pilleft'] = new button ('img_pilleft', 1, 'parent.editWin.prevnextDoc("prev");', 'pilleft', langObj.get('l_prevDoc'), 'parent.propmenu.dom_getObj("edit")', 'parent.buttons[\'pilleft\']');
		buttons['pilright'] = new button ('img_pilright', 1, 'parent.editWin.prevnextDoc("next");', 'pilright', langObj.get('l_nextDoc'), 'parent.propmenu.dom_getObj("edit")', 'parent.buttons[\'pilright\']');

		glImage.add ('savedok', 21, 16, TS.path+'savedok.gif');
		glImage.add ('closedok', 21, 16, TS.path+'closedok.gif');
		glImage.add ('saveandclosedok', 21, 16, TS.path+'saveandclosedok.gif');
		glImage.add ('viewdok', 21, 16, TS.path+'viewdok.gif');
		buttons['savedok'] = new button ('img_savedok', 1, 'editWin.saveCur("");', 'savedok', langObj.get('rm_saveDoc'), 'parent.propmenu.dom_getObj("edit")', 'parent.buttons[\'savedok\']');
		buttons['closedok'] = new button ('img_closedok', 1, 'editWin.closeCur("");', 'closedok', langObj.get('rm_closeDoc'), 'parent.propmenu.dom_getObj("edit")', 'parent.buttons[\'closedok\']');
		buttons['saveandclosedok'] = new button ('img_saveandclosedok', 1, 'editWin.saveCur("",1);', 'saveandclosedok', langObj.get('rm_saveCloseDoc'), 'parent.propmenu.dom_getObj("edit")', 'parent.buttons[\'saveandclosedok\']');
		buttons['viewdok'] = new button ('img_viewdok', 1, 'editWin.viewCur("");', 'viewdok', langObj.get('rm_viewDoc'), 'parent.propmenu.dom_getObj("edit")', 'parent.buttons[\'viewdok\']');

	
// ********************
// ***  Clickmenu   ***
// ********************

	glImage.add ('menu_top', 104, 12, TS.path+'clickmenu/menu_top.gif','','',TS.path+'clickmenu/menu_top_a.gif',9);
	glImage.add ('menu_bottom', 104, 12, TS.path+'clickmenu/menu_bottom.gif','','',TS.path+'clickmenu/menu_bottom_a.gif',9);
	glImage.add ('menu_dummy', 104, 12, TS.path+'clickmenu/menu_dummy.gif','','',TS.path+'clickmenu/menu_dummy.gif',9);
	glImage.add ('menu_spacer', 104, 12, TS.path+'clickmenu/menu_spacer.gif','','',TS.path+'clickmenu/menu_spacer_a.gif',9);
	glImage.add ('menu_arrow', 10, 12, TS.path+'clickmenu/menu_arrow_n.gif','',TS.path+'clickmenu/menu_arrow_h.gif','',5);

	var dbTreeMenu = new clickMenu ("parent", "content.nav_frame", TS.path, TS.knappath, "menu_", "menuLayer1", "dbTreeMenu", 15);
	dbTreeMenu.aI ('view', 'parent.editWin.viewME(this.clickIdent,0,0);', 'cm_view');
	dbTreeMenu.aI ('preview', 'parent.editWin.viewME(this.clickIdent,0,1);', 'cm_preview');
	dbTreeMenu.aI ('edit', 'parent.editWin.editME(this.clickIdent);', 'cm_edit');
	dbTreeMenu.aI ('new', 'parent.editWin.newME(this.clickIdent);', 'cm_new');
	dbTreeMenu.aI ('copy', 'parent.funcMgr.dbTreeCmd("copy",this.clickIdent);', 'cm_copy');
	dbTreeMenu.aI ('cut', 'parent.funcMgr.dbTreeCmd("cut",this.clickIdent);', 'cm_cut');
	dbTreeMenu.aI ('cb_pasteinto', 'parent.funcMgr.dbTreeCmd("movecb_into",this.clickIdent);', 'cm_pasteinto');
	dbTreeMenu.aI ('cb_pasteafter', 'parent.funcMgr.dbTreeCmd("movecb_after",this.clickIdent);', 'cm_pasteafter');
	dbTreeMenu.aI ('pasteinto', 'parent.funcMgr.dbTreeCmd("pasteinto",this.clickIdent);', 'cm_pasteinto');
	dbTreeMenu.aI ('pasteafter', 'parent.funcMgr.dbTreeCmd("pasteafter",this.clickIdent);', 'cm_pasteafter');
	dbTreeMenu.aI ('select', 'parent.funcMgr.dbTreeCmd("select",this.clickIdent);', 'cm_select');
	dbTreeMenu.aI ('deselect', 'parent.funcMgr.dbTreeCmd("deselect",this.clickIdent);', 'cm_deselect');
	dbTreeMenu.aI ('selectto', 'parent.funcMgr.dbTreeCmd("select_to",this.clickIdent);', 'cm_selectto');
	dbTreeMenu.aI ('deselectto', 'parent.funcMgr.dbTreeCmd("deselect_to",this.clickIdent);', 'cm_deselectto');
	dbTreeMenu.aI ('delete', 'parent.editWin.deleteME(this.clickIdent);', 'cm_delete');
	dbTreeMenu.aI ('info', 'parent.funcMgr.dbTreeCmd("info",this.clickIdent);', 'cm_info');


	var dbListMenu = new clickMenu ("parent", "content.db_list_frame", TS.path, TS.knappath, "menu_", "menuLayer1", "dbListMenu", 14);
	dbListMenu.aI ('view', 'parent.editWin.viewME(this.clickIdent, 1);', 'cm_view');
	dbListMenu.aI ('edit', 'parent.editWin.editME(this.clickIdent, 1,1);', 'cm_edit');
	dbListMenu.aI ('new', 'parent.editWin.newME(this.clickIdent, 1);', 'cm_new');
	dbListMenu.aI ('copy', 'parent.funcMgr.dbListCmd("copy",this.clickIdent);', 'cm_copy');
	dbListMenu.aI ('cut', 'parent.funcMgr.dbListCmd("cut",this.clickIdent);', 'cm_cut');
	dbListMenu.aI ('cb_pasteinto', 'parent.funcMgr.dbListCmd("movecb_into",this.clickIdent);', 'cm_pasteinto');
	dbListMenu.aI ('cb_pasteafter', 'parent.funcMgr.dbListCmd("movecb_after",this.clickIdent);', 'cm_pasteafter');
	dbListMenu.aI ('pasteinto', 'parent.funcMgr.dbListCmd("pasteinto",this.clickIdent);', 'cm_pasteinto');
	dbListMenu.aI ('pasteafter', 'parent.funcMgr.dbListCmd("pasteafter",this.clickIdent);', 'cm_pasteafter');
	dbListMenu.aI ('select', 'parent.funcMgr.dbListCmd("select",this.clickIdent);', 'cm_select');
	dbListMenu.aI ('deselect', 'parent.funcMgr.dbListCmd("deselect",this.clickIdent);', 'cm_deselect');
	dbListMenu.aI ('selectto', 'parent.funcMgr.dbListCmd("select_to",this.clickIdent);', 'cm_selectto');
	dbListMenu.aI ('deselectto', 'parent.funcMgr.dbListCmd("deselect_to",this.clickIdent);', 'cm_deselectto');
	dbListMenu.aI ('delete', 'parent.editWin.deleteME(this.clickIdent, 1);', 'cm_delete');
	dbListMenu.aI ('info', 'parent.funcMgr.dbListCmd("info",this.clickIdent);', 'cm_info');


	var fileTreeMenu = new clickMenu ("parent", "content.nav_frame", TS.path, TS.knappath, "menu_", "menuLayer1", "fileTreeMenu", 14);
	fileTreeMenu.aI ('upload', 'parent.fileCmd.upload(this.clickIdent);', 'cm_upload');
	fileTreeMenu.aI ('new', 'parent.fileCmd.newFolder(this.clickIdent);', 'cm_new');
	fileTreeMenu.aI ('rename', 'parent.fileCmd.renameFolder(this.clickIdent);', 'cm_rename');
	fileTreeMenu.aI ('copy', 'parent.funcMgr.fileTreeCmd("copy",this.clickIdent);', 'cm_copy');
	fileTreeMenu.aI ('cut', 'parent.funcMgr.fileTreeCmd("cut",this.clickIdent);', 'cm_cut');
	fileTreeMenu.aI ('cb_pasteinto', 'parent.funcMgr.fileTreeCmd("movecb_into",this.clickIdent);', 'cm_pasteinto');
	fileTreeMenu.aI ('pasteinto', 'parent.funcMgr.fileTreeCmd("pasteinto",this.clickIdent);', 'cm_pasteinto');
	fileTreeMenu.aI ('select', 'parent.funcMgr.fileTreeCmd("select",this.clickIdent);', 'cm_select');
	fileTreeMenu.aI ('deselect', 'parent.funcMgr.fileTreeCmd("deselect",this.clickIdent);', 'cm_deselect');
	fileTreeMenu.aI ('selectto', 'parent.funcMgr.fileTreeCmd("select_to",this.clickIdent);', 'cm_selectto');
	fileTreeMenu.aI ('deselectto', 'parent.funcMgr.fileTreeCmd("deselect_to",this.clickIdent);', 'cm_deselectto');
	fileTreeMenu.aI ('delete', 'parent.fileCmd.deleteFolder(this.clickIdent);', 'cm_delete');
	fileTreeMenu.aI ('info', 'parent.fileCmd.infoFolder(this.clickIdent);', 'cm_info');

	var fileListMenu = new clickMenu ("parent", "content.file_list_frame", TS.path, TS.knappath, "menu_", "menuLayer1", "fileListMenu", 14);
	fileListMenu.aI ('edit', 'parent.fileCmd.editFile(this.clickIdent);', 'cm_edit');
	fileListMenu.aI ('rename', 'parent.fileCmd.renameFile(this.clickIdent);', 'cm_rename');
	fileListMenu.aI ('open', 'parent.fileCmd.openFile(this.clickIdent);', 'cm_open');
	fileListMenu.aI ('copy', 'parent.funcMgr.fileListCmd("copy",this.clickIdent);', 'cm_copy');
	fileListMenu.aI ('cut', 'parent.funcMgr.fileListCmd("cut",this.clickIdent);', 'cm_cut');
	fileListMenu.aI ('select', 'parent.funcMgr.fileListCmd("select",this.clickIdent);', 'cm_select');
	fileListMenu.aI ('deselect', 'parent.funcMgr.fileListCmd("deselect",this.clickIdent);', 'cm_deselect');
	fileListMenu.aI ('selectto', 'parent.funcMgr.fileListCmd("select_to",this.clickIdent);', 'cm_selectto');
	fileListMenu.aI ('deselectto', 'parent.funcMgr.fileListCmd("deselect_to",this.clickIdent);', 'cm_deselectto');
	fileListMenu.aI ('delete', 'parent.fileCmd.deleteFile(this.clickIdent);', 'cm_delete');
	if (TS.which_os!="WIN")	{
		fileListMenu.aI ('unzip', 'parent.fileCmd.unzipFile(this.clickIdent);', 'cm_unzip');
	}
	fileListMenu.aI ('info', 'parent.fileCmd.infoFile(this.clickIdent);', 'cm_info');

	var editMenu1 = new clickMenu ("parent", "content", TS.path, TS.knappath, "menu_", "menuLayer1", "editMenu1", 14);
	editMenu1.offsetX = 5;
	editMenu1.aI ('save', 'parent.editWin.recFunctions("save",this.clickIdent);', 'cm_save');
	editMenu1.aI ('delete', 'parent.editWin.recFunctions("delete",this.clickIdent);', 'cm_delete');
	editMenu1.aI ('createnew', 'parent.editWin.recFunctions("createnew",this.clickIdent);', 'cm_createnew');
	editMenu1.aI ('view', 'parent.editWin.recFunctions("show",this.clickIdent);', 'cm_view');
	editMenu1.aI ('copy', 'parent.editWin.recFunctions("copy",this.clickIdent);', 'cm_copy');
	editMenu1.aI ('select', 'parent.editWin.recFunctions("copy",this.clickIdent);', 'cm_select');
	
	
// ********************
// ***   RollMenu   ***
// ********************
	rollMenu.add('editMenu','parent.rollMenu');
	rollMenu.menu['editMenu'].aI('',langObj.get('rm_menu'),'');
	rollMenu.menu['editMenu'].aI('save',langObj.get('rm_saveDoc'),'editWin.saveCur("");');
<?php if ($BE_USER->uc["allSaveFunctions"])	{?>
	rollMenu.menu['editMenu'].aI('saveall',langObj.get('rm_saveAllDocs'),'editWin.saveAll();');
<?php }?>
	rollMenu.menu['editMenu'].aI('saveclose',langObj.get('rm_saveCloseDoc'),'editWin.saveCur("",1);');
<?php if ($BE_USER->uc["allSaveFunctions"])	{?>
	rollMenu.menu['editMenu'].aI('savecloseall',langObj.get('rm_saveCloseAllDocs'),'editWin.saveAll(1);');
<?php }?>

	rollMenu.menu['editMenu'].aI('close',langObj.get('rm_closeDoc'),'editWin.closeCur();');
	rollMenu.menu['editMenu'].aI('closeall',langObj.get('rm_closeAllDocs'),'editWin.closeAll();');

<?php 
	$CC_all = $BE_USER->isAdmin() ? "1" : $BE_USER->getTSConfigVal("options.clearCache.all");
	$CC_pages = $BE_USER->isAdmin() ? "1" : $BE_USER->getTSConfigVal("options.clearCache.pages");
	if ($CC_all || $CC_pages)	{
?>
	rollMenu.menu['editMenu'].aI('div1',' - - - ','');
	<?php if ($CC_pages)	{ ?>rollMenu.menu['editMenu'].aI('clearCache_pages',langObj.get('rm_clearCache_pages'),'editWin.clearCache("pages");');	<?php } ?>
	<?php if ($CC_all)	{ ?>	rollMenu.menu['editMenu'].aI('clearCache_all',langObj.get('rm_clearCache_all'),'editWin.clearCache("all");'); <?php } ?>
<?php
	}
?>
	
	rollMenu.add('clipMenu','parent.typoWin.rollMenu','parent.clipBrd.clipboard.menu.document.docForm.clipMenu');
	rollMenu.menu['clipMenu'].aI('',langObj.get('rm_menu'),'');
	rollMenu.menu['clipMenu'].aI('edit',langObj.get('rm_edit'),'clipBrd.edit();');
<?php if ($BE_USER->uc["deleteCmdInClipboard"])	{?>
	rollMenu.menu['clipMenu'].aI('delete',langObj.get('rm_delete'),'clipBrd.deleteI();');
<?php }?>
//	if (TS.isUpload)	{
		rollMenu.menu['clipMenu'].aI('upload',langObj.get('rm_upload'),'clipBrd.upload(clipBrd.pad);');
//	}
	

// ******************
// ***   Menues   ***
// ******************
	var menuGifs = new glImageObj();
		menuGifs.add ('iconPlusTop', 18, 16, TS.outline_path+'plustop.gif');
		menuGifs.add ('iconPlus', 18, 16, TS.outline_path+'plus.gif');
		menuGifs.add ('iconPlusBottom', 18, 16, TS.outline_path+'plusbottom.gif');
		menuGifs.add ('iconPlusOnly', 18, 16, TS.outline_path+'plusonly.gif');
		menuGifs.add ('iconMinusTop', 18, 16, TS.outline_path+'minustop.gif');
		menuGifs.add ('iconMinus', 18, 16, TS.outline_path+'minus.gif');
		menuGifs.add ('iconMinusBottom', 18, 16, TS.outline_path+'minusbottom.gif');
		menuGifs.add ('iconMinusOnly', 18, 16, TS.outline_path+'minusonly.gif');
		menuGifs.add ('iconLine', 18, 16, TS.outline_path+'line.gif');
		menuGifs.add ('iconBlank', 18, 16, TS.outline_path+'blank.gif');
		menuGifs.add ('iconJoinTop', 18, 16, TS.outline_path+'jointop.gif');
		menuGifs.add ('iconJoin', 18, 16, TS.outline_path+'join.gif');
		menuGifs.add ('iconJoinBottom', 18, 16, TS.outline_path+'joinbottom.gif');

	var menuImages = new glImageObj();
		menuImages.add ('_icon_website', 18, 16, 'gfx/i/_icon_website.gif');
		menuImages.add ('_icon_ftp', 18, 16, 'gfx/i/_icon_ftp.gif');
		menuImages.add ('_icon_folders', 18, 16, 'gfx/i/_icon_folders.gif');

	// Iconer
	for (var a=1; a <= TCA.tableCount; a++)	{
		tableName = TCA.tableNames[a];
		menuImages.add ('icon_'+tableName, 18, 16, TS.iconpath+TCA.tables[tableName].iconfile);
	}

function createTheMenu()	{
	parent.theMenu = new Menu(TS.webModeCount);
	parent.theMenu.autoScrolling = (parent.theBrowser.code == "NS") ? false : true;	
	parent.theMenu.name = "theMenu";
	parent.theMenu.container = "top.content.nav_frame";
	parent.theMenu.reverseRef = "top";
	parent.theMenu.contentFrame = "content.db_list_frame";
	parent.theMenu.defaultTarget = "db_list_frame";
	parent.theMenu.rooticon = '_icon_website';
	parent.theMenu.clickmenu = 'dbTreeMenu';
}
createTheMenu();
var theWebTreeIsLoaded=0;
	
function createFileMenu()	{
	parent.fileMenu = new Menu(TS.fileModeCount);
	parent.fileMenu.autoScrolling = (parent.theBrowser.code == "NS") ? false : true;
	parent.fileMenu.name = "fileMenu";
	parent.fileMenu.container = "top.content.nav_frame";
	parent.fileMenu.reverseRef = "top";
	parent.fileMenu.contentFrame = "content.file_list_frame";
	parent.fileMenu.defaultTarget = "file_list_frame";
	parent.fileMenu.rooticon = '_icon_ftp';
	parent.fileMenu.clickmenu = 'fileTreeMenu';
}
createFileMenu();
var theFileTreeIsLoaded=0;



	glImage.add ('required', 10, 10, 'clear.gif', '', TS.path+'required_h.gif');
	glImage.add ('contentMode', 7, 10, 'clear.gif', TS.path+'content_default.gif', TS.path+'content_client.gif', TS.path+'content_fresh.gif');



	// *********************
	// ***   ClipBoard   ***
	// *********************
		var clipBrd = new clipBrdObj();

	for(var a=0;a<TS.clipCount;a++)	{
		clipBrd.addBank('mode'+(a+1));	
	}
	clipBrd.addBank('db');	
	clipBrd.addBank('file');	
	
	busy_checkLoginTimeout_timer();	
	window.defaultStatus = "";	
	var no_login = false;
	
	self.focus();
</SCRIPT>
</HEAD>
<?php





// ******************************
// Output frameset
// ******************************

$shortcutFrame=array();
if ($BE_USER->getTSConfigVal("options.shortcutFrame"))	{
	$shortcutFrame["rowH"]="30,";
	$shortcutFrame["frameDef"]='<frame name="shortcutFrame" src="alt_shortcut.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>';
}

	$loadFrameSize=0;
	$theFrameSet = $CLIENT["SYSTEM"]=="unix" ? "26,85,*," : ($CLIENT["BROWSER"]=="net" ? "26,64,*," : "23,60,*,");
	$theFrameSet.= $shortcutFrame["rowH"].($loadFrameSize+1);
	
	$baseW = 225;
	if ($LANG->lang=="fr")	$baseW+=50;

	echo '
<frameset rows="'.$theFrameSet.'" framespacing="0" frameborder="0" border="0" onUnload="">
	<frameset cols="*,'.$baseW.'" framespacing="0" frameborder="0" border="0">
		<frame name="mainMenu_frame" src="main_menu.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
		<frame name="nButtons_frame" src="buttons_frame.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
	</frameset>

	<frameset cols="*,10" rows="'.($CLIENT["SYSTEM"]=="unix"?40:26).',*" framespacing="0" frameborder="0" border="0">
		<frame name="propmenu" src="propframe.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
		<frame name="temp1" src="propframe_dummy.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
		<frame name="palette_frame" src="palettes.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
		<frame name="temp2" src="palette_dummy.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
	</frameset>
		
	<frame name="content" src="dummy.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
	'.$shortcutFrame["frameDef"].'
	<frame name="load_frame" src="dummy_loadframe.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
</frameset>';

?>
</HTML>
<?php
if ($TYPO3_CONF_VARS["BE"]["compressionLevel"])	{
	new gzip_encode($TYPO3_CONF_VARS["BE"]["compressionLevel"]);
}
?>