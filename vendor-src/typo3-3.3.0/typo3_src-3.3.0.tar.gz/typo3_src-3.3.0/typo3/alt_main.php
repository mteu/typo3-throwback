<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * Alternative TBE: Main frameset
 *
 * This is an alternative Typo3 Backend interface using the same modules, but designed to work with less capable browsers than MSIE.
 * This is probably in pre-alpha test as this time... so dont expect anything useful.
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */



include("init.php");
include("template.php");
include_once(PATH_t3lib."class.t3lib_loadmodules.php");
include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
include_once("class.alt_menu_functions.inc");



// ***************************
// Script Classes
// ***************************
class SC_alt_main {
	var $content;
	var $mainJScode;
	var $loadModules;
	var $alt_menuObj;
	
		// Constructor:
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TBE_MODULES;
		
		$this->loadModules = t3lib_div::makeInstance("t3lib_loadModules");
		$this->loadModules->load($TBE_MODULES);

		$this->alt_menuObj = t3lib_div::makeInstance("alt_menu_functions");
		$AB=1;
	}
	function generateJScode()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;

		$pt3=dirname(t3lib_div::getIndpEnv("SCRIPT_NAME"));
		
		$this->mainJScode='
	function rawurlencode(str)	{
		var output = escape(str);
		output = str_replace("*","%2A", output);
		output = str_replace("+","%2B", output);
		output = str_replace("/","%2F", output);
		output = str_replace("@","%40", output);
		return output;
	}
	function str_replace(match,replace,string)	{
		var input = ""+string;
		var matchStr = ""+match;
		if (!matchStr)	{return string;}
		var output = "";
		var pointer=0;
		var pos = input.indexOf(matchStr);
		while (pos!=-1)	{
			output+=""+input.substr(pointer, pos-pointer)+replace;
			pointer=pos+matchStr.length;
			pos = input.indexOf(match,pos+1);
		}
		output+=""+input.substr(pointer);
		return output;
	}
	
		// Object: TS:
	function typoSetup	()	{
		this.serverpath = "";
		this.PATH_typo3 = "'.($pt3.(substr($pt3,-1)=="/"?"":"/")).'";
		this.veriCode = "'.$BE_USER->veriCode().'";
		this.bP = '.(($CLIENT["BROWSER"]=="net") ? "1" : "0").';
		this.fe_script = "../index.php";
		this.fe_uid = "id";
		this.uniqueID = "'.t3lib_div::shortMD5(uniqid("")).'";
	}
	var TS = new typoSetup();
	
		// Object: theMenu
	function theMenu()	{
		this.recentuid=0;
		this.refresh = theMenu_refresh;
	}
	function theMenu_refresh (flag)	{
		if (top.content.nav_frame)	{
			top.content.nav_frame.location = top.content.nav_frame.location;
		}
	}
	var theMenu = new theMenu();

	
	function busy()	{
		this.loginRefreshed = busy_loginRefreshed;
		this.checkLoginTimeout = busy_checkLoginTimeout;
		this.openRefreshWindow = busy_OpenRefreshWindow;
		this.busyloadTime=0;
		this.openRefreshW=0;
		
		this.checkMD5 = busy_dummy1;
		this.set = busy_dummy2;
	}
	function busy_dummy1()	{
	}
	function busy_dummy2()	{
	}
	function busy_loginRefreshed()	{
		var date = new Date();
		this.busyloadTime = Math.floor(date.getTime()/1000);
		this.openRefreshW=0;
	}
	function busy_checkLoginTimeout()	{
		var date = new Date();
		var theTime = Math.floor(date.getTime()/1000);
		if (theTime > this.busyloadTime+'.intval($BE_USER->auth_timeout_field).'-10)	{
			return true;
		}
	}
	function busy_OpenRefreshWindow()	{
		vHWin=window.open("login_frameset.php","relogin","height=300,width=400,status=0,menubar=0");
		vHWin.focus();
		this.openRefreshW=1;
	}
	function busy_checkLoginTimeout_timer()	{
		if (busy.checkLoginTimeout())	{
			if (!busy.openRefreshW && confirm("'.$LANG->mainLang["mess"]["refresh_login"].'"))	{
				busy.openRefreshWindow();
			}
		}
		window.setTimeout("busy_checkLoginTimeout_timer();",10*1000);
	}
	

		// issueCommand function
	function issueCommand (cmd,backPath)	{
		if (cmd.length < 2000)	{
			if (!backPath) {var bP="";} else {var bP=backPath;}
			var path = TS.serverpath+bP+"tce_db.php?redirect="+rawurlencode(TS.serverpath+"status.php?AB=1")+"&prErr=1&uPT=1&vC="+TS.veriCode+cmd;
//			alert(path);
	//		parent.load_frame.location = path;
		} else {
			alert("System Error:\n\n Commandstring is longer than 2000 characters!");
		}
	}
	function showInFrontend(theId, backPath)	{
		var tempWin = window.open(backPath+TS.fe_script+"?"+TS.fe_uid+"="+theId, "frontend"+TS.uniqueID);
		tempWin.focus();
	} 	
		// edit
	function editWin()	{
		this.edit = editWin_edit;
	}
	var editWin= new editWin();
	function editWin_edit(params,backPath)	{
		if (!backPath || !TS.bP) {var bP="";} else {var bP=backPath;}
	//	alert(TS.serverpath+bP+"alt_doc.php?"+params);
		parent.content.location = TS.serverpath+bP+"alt_doc.php?"+params;
	}
	
		// Info view:
	function launchView(table,uid,bP)	{
		var backPath= bP ? bP : "";
		var thePreviewWindow="";
		thePreviewWindow = window.open(TS.PATH_typo3+"show_item.php?table="+escape(table)+"&uid="+escape(uid),"ShowItem"+TS.uniqueID,"height=300,width=410,status=0,menubar=0,resizable=0,location=0,directories=0,scrollbars=1,toolbar=0");	//+backPath
		if (thePreviewWindow && thePreviewWindow.focus)	{
			thePreviewWindow.focus();
		}
	}
	
	function loadTopMenu(url)	{
		top.topmenuFrame.location = url;
	}
	
	
	function rawurlencode(str)	{
		var output = escape(str);
		output = str_replace("*","%2A", output);
		output = str_replace("+","%2B", output);
		output = str_replace("/","%2F", output);
		output = str_replace("@","%40", output);
		return output;
	}
	function str_replace(match,replace,string)	{
		var input = ""+string;
		var matchStr = ""+match;
		if (!matchStr)	{return string;}
		var output = "";
		var pointer=0;
		var pos = input.indexOf(matchStr);
		while (pos!=-1)	{
			output+=""+input.substr(pointer, pos-pointer)+replace;
			pointer=pos+matchStr.length;
			pos = input.indexOf(match,pos+1);
		}
		output+=""+input.substr(pointer);
		return output;
	}
	
	
	var file_recent_id = "";
	var condensedMode = '.($BE_USER->uc["condensedMode"]?1:0).';

	var busy = new busy();	
	busy.loginRefreshed();
	busy_checkLoginTimeout_timer();

	var nextLoadModuleUrl="";
	function getModuleUrl(inUrl)	{
		var nMU;
		if (top.nextLoadModuleUrl)	{
//alert(top.nextLoadModuleUrl);
			nMU=top.nextLoadModuleUrl+"&AB=1";
			top.nextLoadModuleUrl="";
			return nMU;
		} else {
			return inUrl;
		}
	}

	/**
	 * Print properties of an object
	 */
	function debugObj(obj,name)	{
		var acc;
		for (i in obj) {
			if (obj[i])	{
				acc+=i+":  "+obj[i]+"\n";
			}
		}			  
		alert("Object: "+name+"\n\n"+acc);
	}

		';
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $TYPO_VERSION;
		
		$this->content.='
<!DOCTYPE html public "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE>'.($TYPO3_CONF_VARS["SYS"]["sitename"] ? $TYPO3_CONF_VARS["SYS"]["sitename"]." [Typo".$TYPO_VERSION."]" : "Typo".$TYPO_VERSION).'</TITLE>
<META name="GENERATOR" content="Typo '.$TYPO_VERSION.' by www.typo3.com, (c) Kasper Sk�rh�j 1998-2002">

<SCRIPT LANGUAGE="JavaScript" SRC="md5.js"></SCRIPT>
<!-- <SCRIPT LANGUAGE="JavaScript" SRC="main.js"></SCRIPT> -->
<SCRIPT LANGUAGE="JavaScript" SRC="t3lib/jsfunc.evalfield.js"></SCRIPT>

<script>
';

		$this->generateJScode();
		$this->content.=$this->mainJScode;
		$this->content.="
var currentModuleLoaded = '';
function goToModule(modName,cMR_flag)	{
	var cMR = 0;
	if (cMR_flag)	cMR=1;

	currentModuleLoaded=modName;
	
	switch(modName)	{".$this->alt_menuObj->topMenu($this->loadModules->modules,0,"",4)."
	}
}
</script>

</HEAD>
";


		$topFHeight = ($CLIENT["BROWSER"]=="net" && $CLIENT["VERSION"]<6) ? 36:32;
		//$topFHeight=300;
		
		$fr_content = '<frame name="content" src="'.($BE_USER->uc["startInTaskCenter"]?"mod/user/task/frameset.php":"alt_intro.php?AB=1").'" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>';
		$fr_load = '<frame name="load_frame" src="dummy_loadframe.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>';
		$fr_toplogo = '<frame name="toplogo" src="alt_toplogo.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>';
		$fr_topmenu = '<frame name="topmenuFrame" src="alt_topmenu_dummy.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>';

		$shortcutFrame=array();
		if ($BE_USER->getTSConfigVal("options.shortcutFrame"))	{
			$shortcutFrame["rowH"]="30,";
			$shortcutFrame["frameDef"]='<frame name="shortcutFrame" src="alt_shortcut.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>';
		}
		
		if ($GLOBALS["BE_USER"]->uc["noMenuMode"])	{
			$this->content.= '
			<frameset rows="'.$topFHeight.',*,'.$shortcutFrame["rowH"].'1" framespacing="0" frameborder="0" border="0">
				'.(!strcmp($GLOBALS["BE_USER"]->uc["noMenuMode"],"icons") ? '
				<frameset cols="130,*" framespacing="0" frameborder="0" border="0">
					'.$fr_toplogo.'
					'.$fr_topmenu.'
				</frameset>' : '
				<frameset cols="130,130,*" framespacing="0" frameborder="0" border="0">
					'.$fr_toplogo.'
					<frame name="menu" src="alt_menu_sel.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="no" noresize>
					'.$fr_topmenu.'
				</frameset>').'
				'.$fr_content.'
				'.$shortcutFrame["frameDef"].'
				'.$fr_load.'
			</frameset>
			';
		} else {
			$this->content.='
			<frameset rows="'.$topFHeight.',*,'.$shortcutFrame["rowH"].'1" framespacing="0" frameborder="0" border="0">
				<frameset cols="130,*" framespacing="0" frameborder="0" border="0">
					'.$fr_toplogo.'
					'.$fr_topmenu.'
				</frameset>
				<frameset cols="130,*" framespacing="0" frameborder="0" border="0">
					<frame name="menu" src="alt_menu.php" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
					'.$fr_content.'
				</frameset>
				'.$shortcutFrame["frameDef"].'
				'.$fr_load.'
			</frameset>
			';
		}
		$this->content.='</HTML>';
	}
	function printContent()	{
		echo $this->content;
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_main.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/alt_main.php"]);
}











// ******************************
// Starting document output
// ******************************

// Make instance:
$SOBE = t3lib_div::makeInstance("SC_alt_main");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();

?>
