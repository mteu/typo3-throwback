<?php
// *******************************
// Set error reporting 
// *******************************
error_reporting (E_ALL ^ E_NOTICE); 


?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Webtab Frameset</title>
</head>
<frameset cols="<?php echo $HTTP_GET_VARS["w"]?$HTTP_GET_VARS["w"]:"245"?>,8,*" framespacing="0" frameborder="0" border="0">
	<frame name="nav_frame" src="alt_db_navframe.php?currentSubScript=<?php echo rawurlencode($HTTP_GET_VARS["script"]);?>" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
	<frame name="border_frame" src="border.html" marginwidth="0" marginheight="0" frameborder="0" scrolling="0" noresize>
	<frame name="db_list_frame" src="<?php echo $HTTP_GET_VARS["exScript"]?$HTTP_GET_VARS["exScript"]:($HTTP_GET_VARS["script"].($HTTP_GET_VARS["id"]?"?AB=1&id=".$HTTP_GET_VARS["id"]:""));?>" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" noresize>
</frameset>
</html>
