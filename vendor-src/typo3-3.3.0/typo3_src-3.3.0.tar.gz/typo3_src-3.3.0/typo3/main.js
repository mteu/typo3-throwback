/***************************************************************
*
*  JavaScript Functions for Typo3
*
*
*
*
*  Copyright notice
* 
*  (c) 1998-2000 Kasper Sk�rh�j
*  All rights reserved
*
*  This script is part of the standard PHP-code library provided by
*  Kasper Sk�rh�j, kasper@typo3.com
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* 
*  This copyright notice MUST APPEAR in all copies of this script
***************************************************************/



// ****************
// ***   Tree   ***
// ****************
function menuItem (owner, id, nextItem, prevItem, parent, uid, pid, title, path, values, image) {
	this.owner = owner;
	this.id = id;
	this.table = "pages";
	this.nextItem = nextItem;
	this.prevItem = prevItem;
	this.parent = parent;
	this.uid = uid;
	this.pid = pid;
	this.title = title;
	this.path = path;
	this.values = values;
	this.image = image;
	this.target = owner.defaultTarget; 
	this.isopen = new Array();	
	for (var a=1; a<=owner.totalStates; a++)	{
		this.isopen[a] = false;
	}

	this.firstChild = -1;

	this.draw = DrawItem;
	this.PMIconName = getPMIconName;
	this.setIsOpen = SetIsOpen;
	this.getFirstChild = getFirstChild;
}
function getFirstChild ()	{
	var child = this.firstChild;
	if (child>0) {return child} else {return 0}
}
function DrawItem (indentStr, altImage) {
	var aLine = '';
	var iconTag = menuGifs.getTag(this.PMIconName(),'n','','','');
	if (this.getFirstChild() != 0) {
		var theUrl = 'void(top.'+this.owner.name+'.toggle('+this.id+','+this.owner.mountPointer+'))';
		aLine += '<A HREF="javascript:' + theUrl + ';" name="plusMinus' + this.id +'_'+ this.owner.mountPointer +'" '+top.theBrowser.blurOnClick+'>' + iconTag + '</A>';
	} else {
		aLine += iconTag;
	}
	var alt="";
	if (this.owner.name=="theMenu")	{
		alt = this.path;
	}
	var menuCall = 'top.funcMgr.openCM(\''+this.id+'\', \''+this.owner.clickmenu+'\'); return false;';
	var submoduleCall = 'top.'+this.owner.name+'.itemClicked(' + this.id + '); return false;';
	var addRightClick = ''; //'onMouseDown="if(event.button==2){'+menuCall+'} return false;" ';

//onMouseDown="alert(event.button);alert('+this.id+');"
	
	aLine += '<A HREF="#" onClick="'+menuCall+'" '+addRightClick+top.theBrowser.blurOnClick+'>';
	aLine += menuImages.getIconTag((altImage)?altImage:this.image,'n','item'+this.id+'_'+this.owner.mountPointer,alt,'');
	aLine += '</A>';

	theUrl = this.url;
	if (theUrl != '') {
		aLine += '<A HREF="#" onClick="'+submoduleCall+'" '+addRightClick+'>'+this.title+'</A>';
	} else {
		aLine += fixed_lgd(this.title,10);
	}
	return '<nobr>' + indentStr + aLine + '</nobr>';
}
function getPMIconName() {
	var mode = this.owner.statePointer(this.owner.mountPointer);
	var n = 'icon' + ((this.getFirstChild() != 0) ? ((this.isopen[mode] == true) ? 'Minus' : 'Plus') : 'Join');
	n += (this.id != this.owner.mountArray[this.owner.mountPointer]) ? ((this.nextItem == 0) ? 'Bottom' : '') : ((this.owner.mountCount==1) ? 'Only' : ((this.owner.mountPointer==1) ? 'Top' : ((this.owner.mountPointer==this.owner.mountCount) ? 'Bottom' : '')) );
	return n;
}
function SetIsOpen (isOpen, mountPointer) {
	var i = this.owner.statePointer(mountPointer);
	if ((this.isopen[i] != isOpen)) {
		this.isopen[i] = isOpen;
		return true;
	} else {
		return false;
	}
}

function Menu (modeCount) {
	this.modeCount = modeCount;
	this.count = 0;	
	this.lastAddedEntry=0;
	this.firstEntry = 0;  
	this.autoScrolling = true;	
	this.entry = new menuItem (this);	
	this.entryNums = new Array();		
	this.amBusy = true;					
	this.aI = menuAddItem;			
	this.updateItem = menuUpdateItem;
	this.deleteItem = menuDeleteItem;
	this.findItem = menuFindItem;
	this.deleteItemChilds = menuDeleteItemChilds;
	this.entryIsMounted = menuEntryIsMounted;
	this.addMount = menuAddMount;		
	this.mountCount = 0;				
	this.mountArray = new Array();		
	this.mountPointer = 0;				
	this.totalStates = 0;				
	this.draw = menuDraw;				
	this.drawALevel = menuDrawALevel;	
	this.pagesTable = TCA.pagesTable;
	
	this.mode = 1;			
	this.modeItem = new Array;	
	for (var a=1; a<=this.modeCount; a++)	{
		this.modeItem[a] = new modeItem(a);
	}

	this.statePointer = menuStatePointer;
	this.chMode = chMode;
	this.lastPMClicked = new Array;
	for (var a=1; a<=this.modeCount; a++)	{
		this.lastPMClicked[a] = 0;
	}

	this.selectmode = false;
			
	this.name = 'theMenu';
	this.rooticon = '_icon_website';
	this.clickmenu = '';
	this.container = 'nav_frame';
	this.reverseRef = 'top';
	this.contentFrame = 'content';
	this.loadFrame = 'load_frame';
	this.defaultTarget = 'content';
	this.contentWin = getContentWin;
	this.loadWin = getLoadWin;
	this.refresh = reloadMenu;
	this.reload = reloadMenu;
	this.itemClicked = itemClicked;
	this.setEntry = setEntry;
	this.setAllChildren = setAllChildren;
	this.setAll = setAll;
	this.openAll = openAll;
	this.closeAll = closeAll;
	this.toggle = toggle;
	this.preToggle = preToggle;
	this.getPath = menuGetPath;
	this.reloadListFrame = menuReloadListFrame;
	this.resetLastPMClicked = menuResetLastPMClicked;
	this.recentuid = '';

	this.expRec = menu_expRec;
}
function menuResetLastPMClicked()	{
	for (var a=1; a<=this.modeCount; a++)	{
		this.lastPMClicked[a] = 0;
	}
}
function menuReloadListFrame()	{
	if (''+this.recentuid!='')	{
		switch (this.name)	{
			case "fileMenu":
				parent.mods.load("file");
			break;
			case "theMenu":
				parent.mods.load("web");
			break;
		}
	}
}
function menuGetPath(entryNum, limitLength)	{
	var safetyCounter = 0;
	var path="";
	var thePart="";
	var minChars = 4;
	while (this.entry[entryNum] && this.entry[entryNum].parent != 0)	{
		safetyCounter++;
		thePart = this.entry[entryNum].title;
		if (limitLength)	{
			thePart = fixed_lgd(thePart,10);
		}
		path = thePart+"/"+path;
		entryNum = this.entry[entryNum].parent;
		if (safetyCounter > 100)	{
			break;
		}
	}
	return path;
}
function modeItem(mode) {
	this.mode = mode;
	this.addExpRec = mode_addExpRec;
	this.clearExpRec = mode_clearExpRec;
	
	this.ExpRecMP = new Array();
	this.ExpRecID = new Array();
	this.ExpRecCount = 0;
}
function mode_addExpRec(id, mountPointer)	{
	this.ExpRecCount++;
	this.ExpRecID[this.ExpRecCount] = id;
	this.ExpRecMP[this.ExpRecCount] = mountPointer;
}
function mode_clearExpRec()	{
	this.ExpRecCount=0;
}
function menu_expRec(action)	{
	var dump = "";
	for (var i=1; i <= this.modeCount; i++) {
		for (var j=1; j <= this.modeItem[i].ExpRecCount; j++) {
			dump+=i+","+this.modeItem[i].ExpRecMP[j]+","+this.modeItem[i].ExpRecID[j]+"|";
		}
	}
	return dump;
}
function chMode(newMode)	{
	this.mode = newMode;
	this.refresh(true);
}
function getContentWin() {
	return eval('self.' + this.contentFrame);
}
function getLoadWin() {
	return eval('self.' + this.loadFrame);
}
function menuStatePointer(mP)	{
	return (this.mode-1)*this.mountCount + parseInt(mP);
}
function menuEntryIsMounted (entryID)	{
	for (var i=1; i <= this.mountCount; i++) {
		if (this.mountArray[i] == entryID)	{return true;}
	}
	return false;
}
function menuAddMount(ID)	{
	this.mountCount++;
	this.mountArray[this.mountCount] = ID;
	this.firstEntry = 1;
	this.totalStates = this.modeCount * this.mountCount;
}
function menuAddItem(uid, pid, title, path, values, image)	{
	var table="pages"
	var keyname = table+'_'+uid;
	if (this.entryNums[keyname])		{
		this.lastAddedEntry=this.updateItem(table, uid, pid, title, path, values, image);
		return this.lastAddedEntry;
	} else {
		var nextItem = 0;
		var prevItem = 0;
		var parentID = 0;
		this.count++;
		var entryID = this.count;
		if (pid >=0)	{
			var thisPid = pid;
			if (this.entryNums[this.pagesTable+'_'+thisPid])	{
				parentID = this.entryNums[this.pagesTable+'_'+thisPid];
				var parent = this.entry[parentID];
				if (parent.firstChild > 0)	{
					nextItem = parent.firstChild;
					prevItem = 0;
					this.entry[parent.firstChild].prevItem = entryID;
				}
				parent.firstChild = entryID;
			}
		} else {
			var thisPid = Math.abs(pid);
			if (this.entryNums[table+'_'+thisPid])	{
				prevItem = this.entryNums[table+'_'+thisPid];
				nextItem = this.entry[this.entryNums[table+'_'+thisPid]].nextItem;
				this.entry[prevItem].nextItem = entryID;
				if (this.entry[nextItem])	{this.entry[nextItem].prevItem = entryID;}
				var parentID = this.entry[this.entryNums[table+'_'+thisPid]].parent;
				thisPid = this.entry[this.entryNums[table+'_'+thisPid]].pid;
			}
		}
		title = unescape(title)  || '<i>[no title]</i>';
		this.entry[entryID] = new menuItem (this, entryID, nextItem, prevItem, parentID, uid, thisPid, title, path, values, image);
		this.entryNums[keyname] = entryID;
		this.lastAddedEntry = entryID;
		return entryID;
	}
}
function menuUpdateItem (table, uid, pid, title, path, values, image)	{
	var keyname = table+'_'+uid;
	if (this.entryNums[keyname])	{
		var entryID = this.entryNums[keyname];
		if (pid!= null && (keyname != TCA.pagesTable+'_0') && uid!=pid)	{
			var nextItem = this.entry[entryID].nextItem;
			var prevItem = this.entry[entryID].prevItem;
			var parentID = this.entry[entryID].parent;

			if (this.entry[this.entry[entryID].prevItem])	{
				this.entry[this.entry[entryID].prevItem].nextItem = this.entry[entryID].nextItem;
			} else {
				if (this.entry[this.entry[entryID].parent])	{
					this.entry[this.entry[entryID].parent].firstChild = this.entry[entryID].nextItem;
				}				
			}
			if (this.entry[this.entry[entryID].nextItem])	{
				this.entry[this.entry[entryID].nextItem].prevItem = this.entry[entryID].prevItem;
			}
			if (pid >=0)	{
				var thisPid = pid;
				if (this.entryNums[this.pagesTable+'_'+thisPid])	{
					parentID = this.entryNums[this.pagesTable+'_'+thisPid];
					var parent = this.entry[parentID];
					prevItem = 0;
					nextItem = 0;
					if (parent.firstChild > 0)	{
						if (parent.firstChild != entryID)	{
							nextItem = parent.firstChild;
							prevItem = 0;
							this.entry[parent.firstChild].prevItem = entryID;
						}
					}
					parent.firstChild = entryID;
				}
			} else {
				var thisPid = Math.abs(pid);
				if (this.entryNums[table+'_'+thisPid])	{
					prevItem = this.entryNums[table+'_'+thisPid];
					nextItem = this.entry[prevItem].nextItem;
					this.entry[prevItem].nextItem = entryID;
					if (this.entry[nextItem])	{this.entry[nextItem].prevItem = entryID;}
					var parentID = this.entry[this.entryNums[table+'_'+thisPid]].parent;
					thisPid = this.entry[this.entryNums[table+'_'+thisPid]].pid;
				}
			}
			this.entry[entryID].nextItem = nextItem;
			this.entry[entryID].prevItem = prevItem;
			this.entry[entryID].parent = parentID;
			this.entry[entryID].pid = thisPid;
		}
		if (title!=null)	{this.entry[entryID].title = (unescape(title)  || '<i>[no title]</i>');}
		if (path!=null)		{this.entry[entryID].path = path;	}
		if (values!=null)	{this.entry[entryID].values = values;	}
		if (image!=null)	{this.entry[entryID].image = image;	}
		return entryID;
	}
}
function menuDeleteItem (table, uid)	{
	var keyname = table+'_'+uid;
	var entryID = this.entryNums[keyname];
	if (entryID)	{
		if (this.entry[this.entry[entryID].prevItem])	{
			this.entry[this.entry[entryID].prevItem].nextItem = this.entry[entryID].nextItem;
		} else {
			if (this.entry[this.entry[entryID].parent])	{
				this.entry[this.entry[entryID].parent].firstChild = this.entry[entryID].nextItem;
			}				
		}
		if (this.entry[this.entry[entryID].nextItem])	{
			this.entry[this.entry[entryID].nextItem].prevItem = this.entry[entryID].prevItem;
		}
		this.deleteItemChilds(entryID);
		this.entryNums[table+'_'+uid] = '';	
		this.entry[entryID] = null;
	}	
}
function menuDeleteItemChilds(parentID)	{
	var e = null;
	var parent_e = null;
	var currEntry = '';
	var OldCurrEntry = '';
	if (parentID != 0)	{
		parent_e = this.entry[parentID];
	}

	if (parentID != 0)	{
		currEntry = parent_e.firstChild;
	} else {
		currEntry = this.firstEntry;
	}
	while (currEntry > 0) {
		e = this.entry[currEntry];
		this.deleteItemChilds(currEntry);
		oldCurrEntry = currEntry;
		currEntry = e.nextItem;
		this.entryNums[e.table+'_'+e.uid] = '';
		this.entry[oldCurrEntry] = null;
	}
}
function menuFindItem(thePropertyName, theString)	{
	var foundItem = 0;
	for (var i=1; i<=this.count; i++) {
	if (this.entry[i] && this.entry[i][thePropertyName]==theString) {foundItem = i;break;}}
	return foundItem;
}
function menuDraw(theDoc) {
	this.mountPointer = 0;
	this.modeItem[this.mode].clearExpRec();
	for (var i=1; i <= this.mountCount; i++) {
		this.mountPointer++;
		if (this.entry[this.mountArray[i]])	{
 			theDoc.write('<DIV>' + this.entry[this.mountArray[i]].draw('','') + '</DIV>');
 			var e = this.entry[this.mountArray[i]];
 			if (e.getFirstChild() != 0 && e.isopen[this.statePointer(this.mountPointer)]) {
				var content = menuGifs.getTag(((i==this.mountCount) ? 'iconBlank' : 'iconLine'), 'n', '', '','');
				theDoc.writeln(this.drawALevel(this.mountArray[i], content));
				this.modeItem[this.mode].addExpRec(e.uid, this.mountPointer);
			}
		}
	}
	if ((this.lastPMClicked[this.mode] != 0) && this.autoScrolling) {
		var l = eval(this.container).location.pathname + '#plusMinus' + this.lastPMClicked[this.mode];
		eval(this.container).location.href = l;
	}
}	
function menuDrawALevel(parentID, indentStr) {
	var padImg = "";
	var aLine = "";
	var theLevel = "";
	var e = null;
	var parent_e = null;
	var currEntry = '';
	var hasBeenFurtherOut=0;

	if (parentID != 0)	{
		parent_e = this.entry[parentID];
	}
	if (parentID != 0)	{
		currEntry = parent_e.getFirstChild();
	} else {
		currEntry = this.firstEntry;
	}
	while (currEntry > 0) {
		e = this.entry[currEntry];	aLine = e.draw(indentStr);
		aLine = '<DIV>' + aLine + '</DIV>';
		theLevel += aLine;
		if (e.getFirstChild() != 0 && e.isopen[this.statePointer(this.mountPointer)]) {
			padImg = menuGifs.getTag(((e.nextItem == 0) ? 'iconBlank' : 'iconLine'), 'n', '', '','');
			theLevel += this.drawALevel(e.id, indentStr + padImg);
			hasBeenFurtherOut=1;
		}
		currEntry = e.nextItem;
	}
	if (!hasBeenFurtherOut)	{
		this.modeItem[this.mode].addExpRec(parent_e.uid, this.mountPointer);
	}
	return theLevel;
}
function reloadMenu(positionMenu) {
	if (this.amBusy == false) {
		var co = eval(this.container);
		this.amBusy = true;
 		var newLoc = fixPath(co.location.pathname);
 		if ((positionMenu) && (theBrowser.mustMoveAfterLoad == false)) {
 			newLoc += "#plusMinus" + this.lastPMClicked[this.mode];
 		}
		eval(this.container).location.href = newLoc;
	}
}
function itemClicked(entryNo) {
	var e = this.entry[entryNo];
	switch (this.name)	{
		case "fileMenu":
			this.recentuid = e.path;
		break;
		default:
			this.recentuid = e.uid;
		break;
	}
	this.reloadListFrame();
}
function setEntry(entryNo, mountPointer, state) {
	var cl = ',' + entryNo + ',';
	var e = this.entry[entryNo];
	this.lastPMClicked[this.mode] = entryNo+'_'+mountPointer;
	var mc = e.setIsOpen(state, mountPointer);
	var p = e.parent;
	while (p > 0) {
		cl += p + ',';
		e = this.entry[p];
		mc |= (e.setIsOpen(true, mountPointer));
		p = e.parent;
	}
	return mc;
}
function setAllChildren(state, parentID, mountPointer) {
	this.entry[parentID].setIsOpen(state, mountPointer);
	var currEntry = this.entry[parentID].getFirstChild();
	while (currEntry > 0) {
		var e = this.entry[currEntry];
		if (e.getFirstChild() > 0) {
			this.setAllChildren(state, currEntry, mountPointer);
		}
		currEntry = e.nextItem;
	}
}
function setAll(state) {
	for (var i=1; i<=this.mountCount; i++) {
		if (this.entry[this.mountArray[i]])	{
			this.setAllChildren(state, this.mountArray[i], i);
		}
	}
	this.refresh(true);
}
function openAll() {this.setAll(true);}
function closeAll() {this.setAll(false)}
function toggle(entryNo, mountPointer) {
	var e = this.entry[entryNo];
	var chg = this.setEntry(entryNo, mountPointer, e.isopen[this.statePointer(mountPointer)] ^ 1);
	if (chg) {this.refresh(this.autoScrolling && (this.lastPMClicked[this.mode] > 0));}
}
function preToggle(entryNo, mountPointer, mode) {
	var e = this.entry[entryNo];
	var tempMode=this.mode;
	this.mode = mode;
	this.setEntry(entryNo, mountPointer, 1);
	this.mode = tempMode;
}


// ****************************
// ***   Global Image Obj   ***
// ****************************
function glImageItem(name, w, h, source_n, source_d, source_h, source_s) {
	this.name = name;
	this.w = w;
	this.h = h;
	
	this.type = new Array();
	this.type["n"]	= source_n;	
	this.type["d"]	= (source_d) ? source_d : "";
	this.type["h"]	= (source_h) ? source_h : "";
	this.type["s"]	= (source_s) ? source_s : "";

	this.obj = new Array();
	this.obj["n"] = "";
	this.obj["d"] = "";	
	this.obj["h"] = "";
	this.obj["s"] = "";
}
function glImageObj() {
	this.count = 0;
	this.globalRollover = 1;
	this.img = new glImageItem('',0,0,'','','','');
	this.imgNum = new Array();
	this.add = glImage_add;
	this.getSrc = glImage_getSrc;
	this.getTag = glImage_getTag;
	this.getIconTag = glImage_getIconTag;
}
function glImage_add(name, w, h, source_n, source_d, source_h, source_s, preload) {
	this.count++;
	this.img[name] = new glImageItem(name, w, h, source_n, source_d, source_h, source_s);

	if (preload&1)	{
		this.img[name].obj["n"] = new Image(w,h);
		this.img[name].obj["n"].src = this.img[name].type["n"];
	}
	if (preload&2)	{
		this.img[name].obj["d"] = new Image(w,h);
		this.img[name].obj["d"].src = this.img[name].type["d"];
	}
	if (preload&4)	{
		this.img[name].obj["h"] = new Image(w,h);
		this.img[name].obj["h"].src = this.img[name].type["h"];
	}
	if (preload&8)	{
		this.img[name].obj["s"] = new Image(w,h);
		this.img[name].obj["s"].src = this.img[name].type["s"];
	}
	
	this.img[this.count] = name;
}
function glImage_getSrc(name, type) {
	var obj = this.img[name];
	if (obj)	{
		if (!type) {type = 'n';}
		if (type=="h" && !this.globalRollover)	{
			type = "n";
		}
		if (obj.obj[type] && !(theBrowser.code=="NS" && theBrowser.version >= 4.5))	{
			return obj.obj[type].src;
		} else {
			if (!obj.type[type])	{
				type = "n";
			} 
			if (obj.type[type])	{
				obj.obj[type] = new Image(obj.w,obj.h);
				obj.obj[type].src = obj.type[type];
				return obj.obj[type].src;
			}
		}
	} else {alert('System Error:\n\n Image '+name+' not an object!!');}
	return false;
}
function glImage_getTag(name, type, imgName, altText, dotclear) {
	var obj = this.img[name];
	if (obj)	{
		if (!type)	{type='n';}
		if (obj.type[type] == '') {return '';}
		var tag = '<img src="' + ((dotclear) ? 'clear.gif' : obj.type[type]) +  '" width=' + obj.w + ' height=' + obj.h + ' border=0 align="top"';
		tag += (imgName) ? ' name="' + imgName + '"' : '';
		tag += ' title="' + altText +  '">';
		return tag;
	} else return '';
}
function glImage_getIconTag(name, type, imgName, altText, dotclear) {
	return this.getTag(name,type,imgName,altText,dotclear)  || ('<img src="' + name + '" width=18 height=16 title="' + altText + '" border="0" align="top">');
}



// *******************
// ***   Buttons   ***
// *******************
function button (imgName, enabled, url, image, alttext, target, objReverseRef)	{
	this.imgName = imgName;
	this.enabled = enabled;
	this.url = url;
	this.image = image;
	this.alttext = alttext;
	this.target = target;

	this.state = false;
	this.stateImg = new Image();
			
	this.reverseRef = objReverseRef;

	this.mouseover = button_mover;
	this.click = button_click;
	this.enable = button_enable;
	this.draw = button_draw;
	this.init = button_init;
}
function button_mover (active) {
	if ((this.enabled || this.toggle) && eval(this.target) && dom_getImg(eval(this.target),this.imgName))	{
		if (active)	{
			dom_getImg(eval(this.target),this.imgName).src = glImage.getSrc(this.image,"h");
		} else {
			dom_getImg(eval(this.target),this.imgName).src = (this.state) ? glImage.getSrc(this.image,"s") : glImage.getSrc(this.image,"n");
		}
	}
}
function button_enable (enable) {
	if (dom_getImg(eval(this.target),this.imgName)) {
		if (!enable)	{
			this.enabled = 0;
			dom_getImg(eval(this.target),this.imgName).src = glImage.getSrc(this.image,"d");
		} else {
			this.enabled = 1;
			dom_getImg(eval(this.target),this.imgName).src = (this.state) ? glImage.getSrc(this.image,"s") : glImage.getSrc(this.image,"n");
		}
	}
}
function button_click (url) {
	if (this.enabled || this.toggle)	{
		if (!busy.isBusy(1,'button'))	{
			eval (url || this.url);
		}
	}
	this.init()
}
function button_draw (url)	{
	var res = '';
	res+= '<a href="javascript:'+this.reverseRef+'.click(\''+url+'\');" '+top.theBrowser.blurOnClick+' onMouseOver="'+this.reverseRef+'.mouseover(1);" onMouseOut="'+this.reverseRef+'.mouseover(0);">';
	res+= glImage.getTag(this.image, '', this.imgName, this.alttext, 0);
	res+= '</a>';
	return res;
}
function button_init ()	{
	this.mouseover(0);
}

// ****************
// ***   Pane   ***
// ****************
function faneItem (number, name, enabled, url, image, alttext)	{
	this.number = number;
	this.name = name;
	this.enabled = enabled;
	this.url = url;
	this.image = image;
	this.alttext = alttext;
}
function faner_add (name, enabled, url, image, alttext)	{
	if (glImage.img[image])	{
		this.elements++;
		this.fane[name] = new faneItem(this.elements, name, enabled, url, image, alttext);
		this.faneNum[this.elements] = name;
	} else {
		alert("System Error:\n\n Global image '"+image+"' did not exist!");
	}
}
function faneBar (target, path, setName, objReverseRef, tablewidth, content_bgcolor, foot_bgcolor, contentHeight) {
	this.path = path;
	this.target = target;
	this.name = setName;
	this.reverseRef = objReverseRef;
	
	this.defaultItem = "list";
	this.current = "";
	this.mouseover = faner_mover;
	this.mouseout = faner_mout;
	this.select = faner_select;
	this.setStatus = faner_setStatus;
	this.click = faner_click;
	this.enable = faner_enable;
	this.add = faner_add;
	this.draw = faner_draw;
	this.init = faner_init;
	this.clear = faner_clear;
	this.itemH = 12;
	
	this.tablewidth = tablewidth;
	this.content_bgcolor = content_bgcolor;
	this.foot_bgcolor = foot_bgcolor;
	this.contentHeight = contentHeight;

	this.fane = new faneItem(0,"",0,"","");
	this.faneNum = new Array();	
	this.elements = 0;

	this.imgFaneL_h = new Image(4, 18);
	this.imgFaneL_h.src = this.path + "fanevenstre_h.gif";
	this.imgFaneR_h = new Image(4, 18);
	this.imgFaneR_h.src = this.path + "fanehoejre_h.gif";
	this.imgFaneT_h = new Image(1, 4);
	this.imgFaneT_h.src = this.path + "fanetop_h.gif";
	this.imgFaneB_h = new Image(1, 2);
	this.imgFaneB_h.src = this.path + "fanebottom_h.gif";

	this.imgFaneStart = new Image(4, 18);
	this.imgFaneStart.src = this.path + "fane_start.gif";
	this.imgFaneStart_ = new Image(4, 18);
	this.imgFaneStart_.src = this.path + "fane_start_.gif";
	this.imgFaneMidt = new Image(4, 18);
	this.imgFaneMidt.src = this.path + "fane_midt.gif";
	this.imgFaneSlut = new Image(4, 18);
	this.imgFaneSlut.src = this.path + "fane_slut.gif";
	this.imgFaneT_n = new Image(1, 4);
	this.imgFaneT_n.src = this.path + "fanetop.gif";
	this.imgFaneB_n = new Image(1, 2);
	this.imgFaneB_n.src = this.path + "fanebottom.gif";
}
function faner_clear()	{
	for (var i = 1; i <= this.elements; i++) {
		this.fane[this.faneNum[i]] = '';
		this.faneNum[i] = '';
	}
	this.elements = 0;
}
function faner_mover (fane) {
	if (this.fane[fane].enabled && this.current != fane && eval(this.target))	{
		dom_getImg(eval(this.target),fane).src = glImage.getSrc(this.fane[fane].image,"h");
	}
}
function faner_mout (fane)	{
	if (this.fane[fane].enabled && this.current != fane && eval(this.target))	{
		dom_getImg(eval(this.target),fane).src = glImage.getSrc(this.fane[fane].image,"n");
	}
}
function faner_enable (fane, enable) {
	if (this.fane[fane])	{
		if (!enable)	{
			if (this.current == fane)	{this.select (fane); }
			this.fane[fane].enabled = 0;
			dom_getImg(eval(this.target),fane).src = glImage.getSrc(this.fane[fane].image,"d");
		} else {
			this.fane[fane].enabled = 1;
			dom_getImg(eval(this.target),fane).src = glImage.getSrc(this.fane[fane].image,"n");
		}
	} else {
		alert('System Error:\n\n The requested tab "'+fane+'" didn\'t exist!');
	}
}
function faner_click (fane, url) {
	if (this.fane[fane] && this.fane[fane].enabled)	{
		this.mouseout(fane);
		if (!busy.isBusy(1,'faner'))	{
			this.select(fane);
			eval (this.fane[fane].url);
		}
	}
	if (parent.funcMgr) {parent.funcMgr.setSelectmode(0);}
}
function faner_select (fane)	{
	if (this.current) {this.setStatus (this.current, "normal");}
	if (fane && this.fane[fane] && this.fane[fane].enabled)	{
		this.setStatus (fane, "selected");
		this.current = fane;
	}
}
function faner_setStatus (fane, mode)	{
	var win = eval(this.target);
	if (this.fane[fane] && win && dom_getImg(win,this.name + "_S" + this.fane[fane].number) && fane!="_")	{
		switch (mode) {
			case "selected":
				dom_getImg(win,this.name + "_T" + this.fane[fane].number).src = this.imgFaneT_h.src;
				dom_getImg(win,this.name + "_B" + this.fane[fane].number).src = this.imgFaneB_h.src;
				dom_getImg(win,this.name + "_S" + (this.fane[fane].number-1)).src = this.imgFaneL_h.src;
				dom_getImg(win,this.name + "_S" + this.fane[fane].number).src = this.imgFaneR_h.src;
			break;
			case "normal":
				dom_getImg(win,this.name + "_T" + this.fane[fane].number).src = this.imgFaneT_n.src;
				dom_getImg(win,this.name + "_B" + this.fane[fane].number).src = this.imgFaneB_n.src;
				dom_getImg(win,this.name + "_S" + (this.fane[fane].number-1)).src = (this.fane[fane].number == 1) ? this.imgFaneStart.src : ((this.faneNum[this.fane[fane].number-1]=='_') ? this.imgFaneStart_.src : this.imgFaneMidt.src );
				dom_getImg(win,this.name + "_S" + this.fane[fane].number).src = (this.fane[fane].number == this.elements || this.faneNum[this.fane[fane].number+1]=='_') ? this.imgFaneSlut.src : this.imgFaneMidt.src ;
			break;
		}
	}
}
function faner_draw (targetdoc, content)	{
	var res = '';
	if (this.elements>0)	{
		var faner_width = (this.elements+2)*4;
		var counter = 0;
		var imageName = '';
		var faneName = '';
		res+= '<table border=0 cellspacing=0 cellpadding=0 width='+this.tablewidth+'><tr>';
		for (var i = 1; i <= this.elements; i++) {
			imageName = this.fane[this.faneNum[i]].image;
			res+= '<td rowspan=3><img src="clear.gif" name="'+this.name+'_S'+counter+'" width=4 height='+(this.itemH+6)+' border="0"></td>';
			res+= '<td><img src="clear.gif" width='+ glImage.img[imageName].w +' name="'+this.name+'_T'+(counter+1)+'" height=4 border="0"></td>';
			faner_width+= glImage.img[imageName].w;
			counter++;
		}
		res+= '<td rowspan=3><img src="clear.gif" name="'+this.name+'_S'+counter+'" width=4 height='+(this.itemH+6)+' border="0"></td><td rowspan=2><img src="clear.gif" width=1 height=1 border="0"></td><td rowspan=2><img src="clear.gif" width=1 height=1 border="0"></td></tr>';
		res+= '<tr>';
		for (var i = 1; i <= this.elements; i++) {
			faneName = this.faneNum[i];
			imageName = this.fane[faneName].image;
			res+= '<td><a href="javascript:'+this.reverseRef+'.click(\''+faneName+'\');" '+top.theBrowser.blurOnClick+' onMouseOver="'+this.reverseRef+'.mouseover(\''+faneName+'\');" onMouseOut="'+this.reverseRef+'.mouseout(\''+faneName+'\');">';
			res+= glImage.getTag(imageName, '', this.fane[faneName].name, this.fane[faneName].alttext, 1);
			res+= '</a></td>';
		}
		res+= '</tr><tr>';
		counter = 0;
		for (var i = 1; i <= this.elements; i++) {
			imageName = this.fane[this.faneNum[i]].image;
			res+= '<td><img src="'+this.path+'fanebottom.gif" name="'+this.name+'_B'+(counter+1)+'" width=' + glImage.img[imageName].w + ' height=2 border="0"></td>';
			counter++;
		}
		res+='<td><img src="'+this.path+'fanebottom.gif" width='+((this.tablewidth-faner_width <= 0) ? 1 : (this.tablewidth-faner_width))+' height=2 border="0"></td>';
		res+='<td><img src="'+this.path+'fanefoot_h1.gif" width=4 height=2 border="0"></td>';
		res+='</tr>';
		res+='<tr><td><img src="'+this.path+'fanefoot_v2.gif" width=4 height='+this.contentHeight+' border="0"></td>';
		res+='<td colspan='+(this.elements*2+1)+' bgcolor="'+this.content_bgcolor+'">';
		res+=content;
		res+='</td><td><img src="'+this.path+'fanefoot_h2.gif" width=4 height='+this.contentHeight+' border="0"></td>';
		res+='</tr><tr>';
		res+='<td><img src="'+this.path+'fanefoot_v3.gif" width=4 height=2 border="0"></td>';
		res+='<td colspan='+(this.elements*2+1)+' bgcolor="'+this.foot_bgcolor+'"><img src="clear.gif" width=1 height=1 border="0"></td>';
		res+='<td><img src="'+this.path+'fanefoot_h3.gif" width=4 height=2 border="0"></td>';
		res+='</tr></table>';
	}
	return res;
}
function faner_init ()	{
	for (var i = 1; i <= this.elements; i++) {
		this.setStatus (this.faneNum[i], "normal");
		dom_getImg(eval(this.target),this.faneNum[i]).src = glImage.getSrc(this.fane[this.faneNum[i]].image, this.fane[this.faneNum[i]].enabled ? 'n' : 'd' );
	}	
}

// **********************
// ***   Clickmenus   ***
// **********************

function clickMenuItem (owner, number, name, url, image)	{
	this.owner = owner;
	this.number = number;
	this.name = name;
	this.url = url;
	this.image = image;
	this.arrowImage = this.owner.arrowImage;
	this.update = clickMenuItem_update;
}
function clickMenuItem_update (itemnum)	{
	var theItem = this.owner.structure[itemnum];
	var thisTarget = dom_getObj(this.owner.layerName, eval(this.owner.target+".document"));
	thisTarget.ref[this.owner.imagesBaseName + itemnum].src = glImage.getSrc(this.image,'n');
	if (thisTarget && thisTarget.ref)	{
		if (this.name.substr(0,1)=="_")	{
			thisTarget.ref[this.owner.imagesArrowName + itemnum].src = glImage.getSrc(this.image,'s');
		} else {
			thisTarget.ref[this.owner.imagesArrowName + itemnum].src = glImage.getSrc(this.arrowImage,'n');
		}
	}
}
function clickMenu_aI (name, url, image)	{
	this.item[name] = new clickMenuItem(this, this.elements, name, url, image);
	this.itemNum[this.elements] = name;
	this.elements++;
}
function clickMenu (targetParent, targetWin, path, itempath, designImagePre, menuLayerName, objName, size) {
	this.path = path;
	this.itempath = itempath;
	this.layerName = menuLayerName;
	this.parentWin = targetParent;
	this.target = targetParent+'.'+targetWin;

	this.is_visible = false;
	this.imagesBaseName = "img";
	this.imagesArrowName = "arr";
	this.imgPre = designImagePre;
	this.arrowImage = this.imgPre+"arrow";

	this.clickIdent = '';
			
	this.name = objName;
	this.itemWidth = 114;
	this.itemHeight = 12;
	this.menuHeight = '';
	this.menuAura = 10;
	this.offsetX = -5;
	this.offsetY = 0;

	this.bottomLimit = 430;
	this.distToWinborderY = 103;
	
	this.menuLeft = -1000;
	this.menuRight = 10000;
	this.menuTop = -1000;
	this.menuBottom = 10000;
	
	
	this.mouseover = clickMenu_mover;
	this.click = clickMenu_click;
	this.aI = clickMenu_aI;
	this.writeMenu = clickMenu_write;
	this.hide = clickMenu_hideLayer;
	this.show = clickMenu_openMenu;
	this.ready = 0;

	this.maxItemsInMenu = size;
	
	this.structure = new Array();
	this.structureElements = 0;
	this.build = clickMenu_build;
	this.buildAdd = clickMenu_buildAdd;
	this.clr = clickMenu_clr;
	this.update = clickMenu_update;

	this.item = new clickMenuItem(this,0,"",0,"","","");
	this.itemNum = new Array();
	this.elements = 0;

	this.aI ('_top', '', this.imgPre+'top');
	this.aI ('_bottom', '', this.imgPre+'bottom');
	this.aI ('_dummy', '', this.imgPre+'dummy');
	this.aI ('_spacer', '', this.imgPre+'spacer');
}
function clickMenu_mover (itemnum,type) {
	var theItem = this.item[this.structure[itemnum]];
	var thisTarget = dom_getObj(this.layerName, eval(this.target+".document"));
	if (theItem && theItem.url && thisTarget.ref)	{
		thisTarget.ref[this.imagesArrowName + itemnum].src = glImage.getSrc("menu_arrow",type);
	}
}
function clickMenu_click (itemnum) {
	var theItem = this.item[this.structure[itemnum]];
	this.mouseover(itemnum,'n');
	if (theItem && !busy.isBusy(1,'click'))	{
		eval (theItem.url);
	}
	this.hide();
}
function clickMenu_build (itemList)	{
	if (this.ready)	{
		this.clr();
		var prevItem = '_top';
		var theNextWord='';
		this.buildAdd (prevItem);
		if (itemList)	{
			var index=1;
			var theWord = split(itemList, ",", index);
			while (theWord) {
				index++;
				theNextWord = split(itemList, ",", index);
				if (theWord == "-")	{
					theWord = "_spacer";
					if (prevItem!="_top" && prevItem!="_spacer" && theNextWord!='' && theNextWord!="-")	{
						this.buildAdd (theWord);
						prevItem = theWord;
					}
				} else {
					this.buildAdd (theWord);
					prevItem = theWord;
				}
				theWord = theNextWord;
			}
		}
		this.buildAdd ('_bottom');
		this.update();
	}
}
function clickMenu_buildAdd(name)	{
	if (this.item[name])	{
		this.structure[this.structureElements] = name;
		this.structureElements++;
		this.menuHeight += this.itemHeight;
	}
}
function clickMenu_clr ()	{
	this.menuHeight = 0;
	this.structureElements = 0;
	this.structure = new Array();
}
function clickMenu_update()	{
	for (var i = 0; i < this.maxItemsInMenu; i++) {
		itemname = this.structure[i];
		if (this.item[itemname])	{
			this.item[itemname].update(i);
		} else {
			this.item["_dummy"].update(i);
		}
	}
}
function clickMenu_write (target)	{
	this.menuHeight = 24;
	result = "";
	result+= '<table border=0 cellspacing=0 cellpadding=0 width=' + this.itemWidth + '>';	
	for (var i = 0; i < this.maxItemsInMenu; i++) {
		result+= ('<tr><td><img name="'+this.imagesArrowName + i + '" src="' + this.path + 'menu_dummy.gif" width=10 height=' + this.itemHeight + '></td><td><a href="javascript: topFrame.'+this.name+'.click('+i+');" '+top.theBrowser.blurOnClick+' onMouseOver="topFrame.'+this.name+'.mouseover('+i+',\'h\')" onMouseOut="topFrame.'+this.name+'.mouseover('+i+',\'n\')"><img name="'+ this.imagesBaseName + i + '" src="' + this.path + 'menu_dummy.gif" width=' + (this.itemWidth-10) + ' height=' + this.itemHeight + ' border="0"></a></td></tr>');
	}
	result+= '</table>';	
	return result;
}
function clickMenu_openMenu(clickIdent)	{
	if (this.ready)	{
		var leftVal = eval(this.parentWin).pageX-this.offsetX;
		var topVal = eval(this.parentWin).pageY-this.offsetY;
	
		this.clickIdent = clickIdent;
	
		var thisTarget = eval(this.target);
		var layerObj = dom_getObj(this.layerName, eval(this.target+".document"));

		var scrTop = theBrowser.code=="NS"?0:thisTarget.document.body.scrollTop;
		var scrLeft = theBrowser.code=="NS"?0:thisTarget.document.body.scrollLeft;
	
		var thePagePos = (theBrowser.code=="NS")? parent.mouseY-parent.screenY-this.distToWinborderY : eval(this.parentWin).pageY;
		if (this.menuHeight + thePagePos > this.bottomLimit)	{
			topVal = topVal-this.menuHeight;
		}
	
		layerObj.css.left = leftVal + scrLeft;
		layerObj.css.top = topVal + scrTop;
		
		this.menuLeft = leftVal - this.menuAura;
		this.menuRight = leftVal + this.itemWidth + this.menuAura;
		this.menuTop = topVal - this.menuAura;
		this.menuBottom = topVal + this.menuHeight + this.menuAura;
	
		layerObj.css.visibility = "visible";

//debug(layerObj.css.left,layerObj.css.top,layerObj.css.visibility);

		this.is_visible = true;
	}
}
function clickMenu_hideLayer()	{
	var layerObj = dom_getObj(this.layerName, eval(this.target+".document"));
	layerObj.css.visibility = "hidden";
	this.is_visible = false;
}
function checkCursorPosition (obj)	{
	if (obj.is_visible)	{
		if (pageX < obj.menuLeft || pageX > obj.menuRight || pageY < obj.menuTop || pageY > obj.menuBottom)	{
			obj.hide();
		}
	}
}



// *********************
// ***   Clipboard   ***
// *********************
function clipBrdItem(table, uid, type, title,fullpath,filetype,image)	{
	this.table = table;
	this.uid = uid;
	this.type = type;
	this.title = title;	
	this.fullpath = fullpath;
	this.filetype = filetype;
	this.image = image;
	this.act = 1;
}
function clipBrd_aI(pad, table, uid, type, filename,fp,filetype,imagefile,action)	{
	var fullpath = fp;
	if (type=="file")	{var fullpath=syncPaths(TS.typo3Path,fullpath);}

	if (this.bank[pad] && type!= '' && (pad=='normal' || this.bankType[pad]==type || this.bankType[pad]==''))	{
		if (pad=='normal')	{
			this.clr(pad);
			if (action) this.action = action;
		}
		var key = this.isReg(pad,table,uid) || 1+this.bankCount[pad];
		this.bank[pad][key] = new clipBrdItem(table, uid, type, filename,fullpath,filetype,imagefile);
		this.bankType[pad] = type;
		if (key == 1+this.bankCount[pad])	{
			this.bankItemName[pad][table + uid] = key;
			this.bankCount[pad]++;
		}
	} else {return false;}
}	
function clipBrd_removeItem(pad, table, uid)	{
	if (this.bank[pad])	{
		var key = this.isReg(pad,table,uid);
		if (!key)	{
			key = table;
		}
		if (this.bank[pad][key])	{
			var name = this.bank[pad][key].table + this.bank[pad][key].uid;
			this.bankItemName[pad][name] = '';
			this.bank[pad][key] = '';
			if (this.countItems(pad)==0)	{
				this.clr(pad);
			}
		}
	}
}	
function clipBrdObj ()	{
	this.open = clipBrd_open;
	this.openBrowser = clipBrd_openBrowser;
	this.detach = clipBrd_detach;
	this.detachBrowser = clipBrd_browserDetach;
	this.clipboard = '';
	this.browserWin = '';
	this.pad = 'normal';
	this.init = clipBrd_initOnLoad;

	this.aI = clipBrd_aI;
	this.removeItem = clipBrd_removeItem;
	this.isReg = clipBrd_isReg;
	
	this.bank = new Array();
	this.bankItemName = new Array();
	this.bankCount = new Array();
	this.bankType = new Array();

	this.bank["normal"] = new clipBrdItem();
	this.bankItemName["normal"] = new Array();
	this.bankCount["normal"] = 0;
	this.bankType["normal"] = '';

	this.action = 'cut';
	this.thumbmode = 1;
	this.copymode = 0;
	this.uploadFlag=0;
	
	this.numberBanks = 1;
	this.addBank = clipBrd_addBank;
	
	this.wr = clipBrd_write;
	this.swPad = clipBrd_swPad;
	this.thumbmodeToggle = clipBrd_thumbmodeToggle;
	this.copymodeToggle = clipBrd_copymodeToggle;
	this.clr = clipBrd_clr;
	this.clrSelected = clipBrd_clrSelected;
	this.upload = clipBrd_upload;
	this.edit = clipBrd_edit;
	this.deleteI = clipBrd_deleteI;
	this.countItems = clipBrd_count;
	this.select = clipBrd_select;
	this.empty = clipBrd_empty;
	this.whichTable = clipBrd_whichTable;
	this.isClipBrdNormal = clipBrd_isClipBrdNormal;
	this.updateButtons = clipBrd_updateButtons;
	this.update = clipBrd_update;
}
function clipBrd_update()	{
	if (this.clipboard)	{
		this.clipboard.content.location='clipboard_content.html';
		this.updateButtons();
	}
}
function clipBrd_empty()	{
	var count=0;
	for (var a=1;a<=this.bankCount[this.pad];a++)	{
		if (this.bank[this.pad][a] && this.bank[this.pad][a].act)	{count++;}
	}
	return count;
}
function clipBrd_isClipBrdNormal()	{
	return (this.pad == 'normal' || !this.clipboard);
}
function clipBrd_whichTable ()	{
	var table = '';
	var count=0;
	var thePad = this.isClipBrdNormal() ? "normal" : this.pad;
	for (var a=1;a<=this.bankCount[thePad];a++)	{
		if (this.bank[thePad][a] && this.bank[thePad][a].act)	{
			if (table && table!=this.bank[thePad][a].table)	{
				table = '';
				break;	
			}
			table = this.bank[thePad][a].table;
		}
	}
	return table;
}
function clipBrd_updateButtons()	{
	if (this.countItems(this.pad))	{
		rollMenu.menu['clipMenu'].setMode('clear',1);
		if (this.bankType[this.pad]=="db")	{
			rollMenu.menu['clipMenu'].setMode('edit',1);
			rollMenu.menu['clipMenu'].setMode('delete',1);
		} else {
			rollMenu.menu['clipMenu'].setMode('edit',0);
			rollMenu.menu['clipMenu'].setMode('delete',0);
		}
		if (this.pad=="normal" || this.bankType[this.pad]!="db")	{
			rollMenu.menu['clipMenu'].setMode('upload',1);
		} else {
			rollMenu.menu['clipMenu'].setMode('upload',0);
		}
	} else {
		rollMenu.menu['clipMenu'].setMode('edit',0);
		rollMenu.menu['clipMenu'].setMode('delete',0);
		rollMenu.menu['clipMenu'].setMode('upload',1);
	}
	rollMenu.menu['clipMenu'].update();
}
function clipBrd_addBank (name)	{
	if (!this.bank[name])	{
		this.bank[name] = new clipBrdItem();
		this.bankItemName[name] = new Array();
		this.bankCount[name] = 0;
		this.bankType[name] = '';
		this.numberBanks++;
	}
}
function clipBrd_isReg (pad,table,uid) 	{
		var number = this.bankItemName[pad][table+uid];
		if (number)	{
			return number;
		} else {
			return false;
		}
}
function clipBrd_count (pad)	{
	var count=0;
	for (var a=1;a<=this.bankCount[pad];a++)	{
		if (this.bank[pad][a])	{count++;}
	}
	return count;
}
function clipBrd_select (pad,cmd)	{
	if (this.bankCount[pad])	{
		switch(cmd)	{
			case "all":
				for (var a=1;a<=this.bankCount[pad];a++)	{this.bank[pad][a].act=1;}
			break;
			case "none":
				for (var a=1;a<=this.bankCount[pad];a++)	{this.bank[pad][a].act=0;}
			break;
			case "inverse":
				for (var a=1;a<=this.bankCount[pad];a++)	{this.bank[pad][a].act=this.bank[pad][a].act^1;}
			break;
		}
	}
}
function clipBrd_open (upload) {
	this.uploadFlag = upload;
	if (!this.clipboard)	{	
		this.clipboard = window.open('clipboard.php','Clipboard'+TS.uniqueID,'height=300,width=250,status=0,menubar=0');	
		this.clipboard.typoWin = parent;
		this.clipboard.focus();
	} else {
		this.clipboard.focus();
		if (this.uploadFlag)	{
			this.update();
		}
	}
	buttons['thumbmode_clip'].state = this.thumbmode
}
function clipBrd_openBrowser (mode,params) {
	if (!this.browserWin)	{	
		this.browserWin = window.open('browser.php?mode='+mode+'&params='+params,'Browser'+TS.uniqueID,'height=350,width='+(mode=="db"?670:500)+',status=0,menubar=0,resizable=1');	
		this.browserWin.typoWin = parent;
		this.browserWin.focus();
	} else {
		this.browserWin.focus();
		this.browserWin.setParams(mode,params);
	}
}
function clipBrd_detach () {
	this.clipboard = '';
	parent.buttons['selectmode'].enable(0);
}
function clipBrd_browserDetach () {
	this.browserWin = '';
}
function clipBrd_swPad (pad) {
	this.copymode = 0;
	buttons['copymode_clip'].state=this.copymode;
	buttons['copymode_clip'].init();
	if (this.bank[pad])	{
		this.pad = pad;
		if (pad == 'normal')	{
			parent.buttons['selectmode'].enable(0);
		} else {
			parent.buttons['selectmode'].enable(1);
		}
	}
	this.update();
}
function clipBrd_thumbmodeToggle()	{
	this.thumbmode = this.thumbmode^1;
	buttons['thumbmode_clip'].state = this.thumbmode
	this.update();
}
function clipBrd_copymodeToggle()	{
	this.copymode = (this.pad=="normal") ? 0 : this.copymode^1;
	buttons['copymode_clip'].state=this.copymode;
}
function clipBrd_initOnLoad ()	{
	faner_clip.click(this.pad);
}
function clipBrd_write(targetWin)	{
	var action="";
	var f1 = parent.TS.globalFont_b;
	var f2 = parent.TS.globalFont_e;
	var bc = parent.TS.globalBackgroundColor;
	var bc2 = parent.TS.globalBackgroundColor2;
	var color="";
	var removeLabel = langObj.get('l_removeItem');
	var viewLabel = langObj.get('l_viewItem');
	if (this.bankCount[this.pad])	{
		targetWin.writeln('<table border=0 cellpadding=0 cellspacing=1>');
		targetWin.writeln('<tr><td><A HREF="javascript: parent.select(\'all\');"><img src="gfx/selectall.gif" width=11 height=10 hspace=2 border=0 title="'+langObj.get('l_selectAll')+'"></a><A HREF="javascript: parent.select(\'none\');"><img src="gfx/selectnone.gif" width=11 height=10 hspace=2 border=0 title="'+langObj.get('l_selectNone')+'"></A><A HREF="javascript: parent.select(\'inverse\');"><img src="gfx/switch.gif" width=11 height=10 hspace=2 border=0 title="'+langObj.get('l_inverseSelection')+'"></A></td><td></td><td></td></tr>');
		targetWin.writeln('<tr><td><img src="clear.gif" width=2 hspace=27 height=1></td><td><img src="clear.gif" width=2 hspace=70 height=1></td><td></td></tr>');
		if (parent.theBrowser.code=="NS" && this.countItems(this.pad)>5)	{var wANDh = ' width="56" height="40"';	} else {var wANDh = '';	}
		for (var i = 0; i < this.bankCount[this.pad]; i++) {
			var item = this.bank[this.pad][i+1];
			if (item)	{
				color = item.act ? bc : bc2;
				action = this.pad=="normal" ? ' <b>('+this.action+')</b>' : '';
				targetWin.writeln ('<tr><td align="center" bgColor="'+color+'"><A HREF="javascript: parent.toggleItem('+(i+1)+');">');
				switch(item.type)	{
					case "db":
						targetWin.writeln (menuImages.getIconTag(item.image,'n','',item.fullpath,''));
					break;
					case "file":
						if (this.thumbmode && item.filetype && parent.TS.image_files.indexOf(',' + item.filetype + ',')!=-1)	{
							targetWin.writeln ('<img src="'+TS.serverpath+TS.thumbScript+'?dummy='+Math.random()+'&file='+rawurlencode(item.fullpath)+'" border=0'+wANDh+'>');
						} else {
							targetWin.writeln ('<img src="gfx/fileicons/'+item.image+'" width=18 height=16 border=0 align="top">');
						}
					break;
				}
				targetWin.writeln ('</A></td><td nowrap bgColor="'+color+'">'+f1+'&nbsp;<A HREF="javascript: parent.toggleItem('+(i+1)+');">'+fixed_lgd(item.title,24)+action+f2+'</A></td><td nowrap bgColor="'+color+'"><A HREF="javascript: parent.viewItem('+(i+1)+');"><img src="gfx/zoom2.gif" width=12 hspace=1 height=12 border=0 title="'+viewLabel+'"></A><A HREF="javascript: parent.removeItem('+(i+1)+');"><img src="gfx/close_12h.gif" width=11 height=12 hspace=1 border=0 title="'+removeLabel+'"></A></td></tr>');
			}
		}
		targetWin.writeln('</table>');
	}
}
function clipBrd_clr (pad)	{
	this.bank[pad] = new clipBrdItem();
	this.bankItemName[pad] = new Array();
	this.bankCount[pad] = 0;
	this.bankType[pad] = '';
	if (this.pad == pad)	{
		this.update()
	}
}

function clipBrd_clrSelected (pad)	{
	for (var a=1;a<=this.bankCount[pad];a++)	{
		if (this.bank[pad][a] && this.bank[pad][a].act)	{this.removeItem(pad, this.bank[pad][a].table, this.bank[pad][a].uid);}
	}
	if (this.pad == pad)	{
		this.update();
	}
}
function clipBrd_upload ()	{
	if (this.clipboard)	{
		this.clipboard.uploadFiles(this.pad);
	}
}
function clipBrd_edit ()	{
	var params = '';
	for (var i = 0; i < this.bankCount[this.pad]; i++) {
		var item = this.bank[this.pad][i+1];
		if (item && item.act)	{
			params+= '&edit[' + item.table + '][' + item.uid + ']=edit';
		}
	}
	parent.editWin.edit(params);
}
function clipBrd_deleteI ()	{
	var params = '';
	var c=0;
	for (var i = 0; i < this.bankCount[this.pad]; i++) {
		var item = this.bank[this.pad][i+1];
		if (item && item.act)	{
			c++;
			params+= '&cmd['+item.table+']['+item.uid+'][delete]=1';
		}
	}
	if (confirm(langObj.get('mess_deleteClip',c)))	{
		parent.issueCommand(params);
		this.clrSelected(this.pad);
	}
}


// *********************
// ***   fileAdmin   ***
// *********************
function fileCmd(ID)	{
	this.upload = fileCmd_upload;
	this.newFolder = fileCmd_newFolder;
	this.renameFolder = fileCmd_renameFolder;
	this.deleteFolder = fileCmd_deleteFolder;
	this.editFile = fileCmd_editFile;
	this.renameFile = fileCmd_renameFile;
	this.deleteFile = fileCmd_deleteFile;
	this.unzipFile = fileCmd_unzipFile;

	this.infoFile = fileCmd_infoFile;
	this.infoFolder = fileCmd_infoFolder;
}
function fileCmd_infoFolder(ID)	{
	parent.launchView(fileMenu.entry[ID].path);
}
function fileCmd_infoFile(ID)	{
	var obj = parent.clipBrd.bank['file'];
	if (obj[ID])	{
		parent.launchView(obj[ID].fullpath);
	}
}
function fileCmd_upload(ID)	{
	var path = fileMenu.entry[ID].path;
	var name = fileMenu.entry[ID].title;
	top.content.file_list_frame.location = "file_upload.php?target="+rawurlencode(path);
}
function fileCmd_newFolder(ID)	{
	var path = fileMenu.entry[ID].path;
	var name = fileMenu.entry[ID].title;
	top.content.file_list_frame.location = "file_newfolder.php?target="+rawurlencode(path);
}
function fileCmd_renameFolder(ID)	{
	var path = fileMenu.entry[ID].path;
	var name = fileMenu.entry[ID].title;
	top.content.file_list_frame.location = "file_rename.php?target="+rawurlencode(path);
}
function fileCmd_deleteFolder(ID)	{
	var menuItem = fileMenu.entry[ID];
	if (confirm(langObj.get('mess_delete',menuItem.title)))	{
		parent.issueFileCommand('&file[delete][1][data]='+rawurlencode(menuItem.path));
	}
}
function fileCmd_editFile(ID)	{
	var obj = parent.clipBrd.bank['file'];
	if (obj[ID])	{
		var path = obj[ID].fullpath;
		var name = obj[ID].title;
		top.content.file_list_frame.location = "file_edit.php?target="+rawurlencode(path);
	}
}
function fileCmd_renameFile(ID)	{
	var obj = parent.clipBrd.bank['file'];
	if (obj[ID])	{
		var path = obj[ID].fullpath;
		var name = obj[ID].title;
		top.content.file_list_frame.location = "file_rename.php?target="+rawurlencode(path);
	}
}
function fileCmd_deleteFile(ID)	{
	var obj = parent.clipBrd.bank['file'];
	if (obj[ID])	{
		if (confirm(langObj.get('mess_delete',obj[ID].title)))	{
			parent.issueFileCommand('&file[delete][1][data]='+rawurlencode(obj[ID].fullpath));
		}
	}
}
function fileCmd_unzipFile(ID)	{
	var obj = parent.clipBrd.bank['file'];
	if (obj[ID])	{
		if (confirm(langObj.get('mess_unzip',obj[ID].title)))	{
			parent.issueFileCommand('&file[unzip][1][data]='+rawurlencode(obj[ID].fullpath));
		}
	}
}


// *************************************
// ***   EditWindow / Typo Documents ***
// *************************************

// ** Typo Doc element (record)
function typodocRec(table, id, next, prev, pid)	{
	this.table = table;
	this.id = id;
	this.pid = pid;
	this.next = next;
	this.prev = prev;
	this.maximized = 1;
	this.reload = typodocRec_reload;
}
function typodocRec_reload ()	{
	editWin.reloadContent();
}

// ** Typo Doc
function typodoc(did)	{	// Document-obj
	this.addRec = typodoc_addRec;
	this.removeRec = typodoc_removeRec;
	this.findPos = typodoc_findPos;
	this.cleanUpDoc = typodoc_cleanUpDoc;
	this.canBeSaved = typodoc_canBeSaved;
	this.canBeClosed = typodoc_canBeClosed;
	this.getTitle = typodoc_getTitle;
	
	this.items = new typodocRec();
	this.itemNums = new Array();
	this.itemCount = 0;
	this.firstItem = -1;
	this.did = did;
}
function typodoc_getTitle()	{
	if (this.items[this.firstItem])	{
		return data.getLabel(this.items[this.firstItem].table,this.items[this.firstItem].id) || "Document "+this.did;
	} else {
		return "Document "+this.did;
	}
}
function typodoc_canBeSaved()	{
	var nextItem = this.firstItem;
	var safetyCounter=100;
	var savedFields = '';
	while (nextItem!=-1) {
		safetyCounter--;
		if (safetyCounter < 0)	{alert('System Error:\n\n More than 100 records or overflow!!'); break;}
		var table = this.items[nextItem].table;
		var id = this.items[nextItem].id;
		var theFields = data.checkFieldsWithData(table,id,'required');
		savedFields += (theFields) ? '\n\n******     '+data.getLabel(table,id)+'     ******'+theFields : '';
		nextItem = this.items[nextItem].next;
	}
	return savedFields;
}
function typodoc_canBeClosed()	{
	var nextItem = this.firstItem;
	var safetyCounter=100;
	var isChanged = false;
	while (nextItem!=-1) {
		safetyCounter--;
		if (safetyCounter < 0)	{alert('System Error:\n\n More than 100 records or overflow!!'); break;}
		var table = this.items[nextItem].table;
		var id = this.items[nextItem].id;
		isChanged |= data.checkFieldsWithData(table,id,'changed');
		nextItem = this.items[nextItem].next;
	}
	return !isChanged;	
}
function typodoc_cleanUpDoc()	{
	var nextItem = this.firstItem;
	var safetyCounter=100;
	while (nextItem!=-1) {
		safetyCounter--;
		if (safetyCounter < 0)	{alert('System Error:\n\n More than 100 records or overflow!!'); break;}
		var table = this.items[nextItem].table;
		var id = this.items[nextItem].id;
		nextItem = this.items[nextItem].next;
		this.removeRec(table, id);
	}
}
function typodoc_findPos (table, id, pid)	{
	var nextItem = this.firstItem;
	var pageFound = 0;		var samePID = 0;		var sameTable = 0;
	var itemID = this.itemCount;
	var safetyCounter=100;
	if (table != TCA.pagesTable)	{
		while (nextItem!=-1) {
			safetyCounter--;
			if (safetyCounter < 0)	{alert('System Error:\n\n More than 100 records or overflow!!'); break;}
			var theUid =''+id;
			if (theUid.indexOf("NEW")==-1)	{
				if (this.items[nextItem].table==TCA.pagesTable && this.items[nextItem].id == pid)	{
					pageFound = nextItem;
				}
				if (this.items[nextItem].table!=TCA.pagesTable && this.items[nextItem].pid == pid)	{
					samePID = nextItem;
					if (this.items[nextItem].table==table)	{
						sameTable = nextItem;
					}
				}
			} else {
				if (this.items[nextItem].table==TCA.pagesTable && this.items[nextItem].id == pid)	{
					pageFound = nextItem;
				}
				if (this.items[nextItem].table!=TCA.pagesTable && '-'+this.items[nextItem].id == ''+pid)	{
					pageFound = nextItem;
				}
			}
			nextItem = this.items[nextItem].next;
		}
	} else {
		while (nextItem!=-1) {
			safetyCounter--;
			if (safetyCounter < 0)	{break;}
			if (this.items[nextItem].table!=TCA.pagesTable && this.items[nextItem].pid == id)	{
				samePID = this.items[nextItem].prev;
				if (!samePID) {samePID = -1;}
				break;
			}
			nextItem = this.items[nextItem].next;
		}
	}
	return sameTable || samePID || pageFound || this.itemCount;	
}
function typodoc_removeRec (table,id)	{
	var keyname = table+'_'+id;
	var ID = this.itemNums[keyname];
	if (this.items[ID])	{
		if (this.firstItem==ID)	{
			this.firstItem = this.items[ID].next;
		}
		if (this.items[this.items[ID].prev])	{
			this.items[this.items[ID].prev].next = this.items[ID].next;
		}
		if (this.items[this.items[ID].next])	{
			this.items[this.items[ID].next].prev = this.items[ID].prev;
		}
		this.items[ID] = '';
		this.itemNums[keyname] = 0;
		parent.data.del(table,id,1);
	}
}
function typodoc_addRec (table, id, pid)	{
	var keyname = table+'_'+id;
	if (!this.itemNums[keyname])	{
		var prev = this.findPos (table,id,pid);
		if (prev)	{
			if (prev<=0)	{
				var next = this.firstItem;
				prev=0;
			} else {
				var next = this.items[prev].next;
			}
		} else {
			var next = -1;
		}
		this.itemCount++;
		this.items[this.itemCount] = new typodocRec(table, id, next, prev, pid);
		this.itemNums[keyname] = this.itemCount;
		if (prev > 0)	{
			this.items[prev].next = this.itemCount;
		} else {
			this.firstItem = this.itemCount;
		}
		if (next > 0)	{
			this.items[next].prev = this.itemCount;
		}
	}
	return this.itemCount;
}
function editWin_deleteDocRecord(table,id)	{
	for (var a=1; a <= this.docCount; a++)	{
		if (this.docs[a])	{
			this.docs[a].removeRec(table,id);
		}
	}
}

// ** EditWindow
function editWinObj ()	{
	this.edit = editWin_edit;
	this.del = editWin_delete;
	this.editME = editWin_editME;
	this.deleteME = editWin_deleteME;
	this.viewME = editWin_viewME;
	this.newME = editWin_newME;
	this.statME = editWin_statME;
	this.permsME = editWin_permsME;
	
	this.recFunctions = editWin_recFunctions;

	this.reloadContent = editWin_reloadContent;
	this.reloadFaner = editWin_reloadFaner;
	this.reloadAll = editWin_reloadAll;
	this.initFaner = editWin_initFaner;

	this.addDoc = editWin_addDoc;
	this.deleteDocRecord = editWin_deleteDocRecord;
	this.findDocWithPID = editWin_findDocWithPID;
	this.recExist = editWin_recExist;
	this.drawDoc = editWin_draw;
	this.loadDoc = editWin_load;
	this.saveCur = editWin_saveCur;
	this.saveAll = editWin_saveAll;
	this.closeDoc = editWin_closeDoc;
	this.closeCur = editWin_closeCur;
	this.viewCur = editWin_viewCur;
	this.closeAll = editWin_closeAll;
	this.clearCache = editWin_clearCache;
	this.countTheDocs = editWin_countTheDocs;
	this.prevnextDoc = editWin_prevnextDoc;
	
	this.docs = new Array();
	this.docCount = 0;
	this.currentDoc = 0;
}
function editWin_countTheDocs()	{
	var index = 0;
	for (var a=1; a <= this.docCount; a++)	{
		if (this.docs[a])	{index++;}
	}
	return index;
}
function editWin_addDoc ()	{
	var index = 0;
	menuFaner.enable('doc',1);
	for (var a=1; a <= this.docCount; a++)	{
		if (!this.docs[a])	{index=a; break;	}
	}
	if (index)	{
		this.docs[index] = new typodoc(index);
		return index;
	} else {
		if (this.docCount < parent.TS.maxDocs)	{
			this.docCount++;
			this.docs[this.docCount] = new typodoc(this.docCount);
		}
		return this.docCount;
	}
}
function editWin_findDocWithPID(pid)	{
	var index=0;
	for (var a=1; a <= this.docCount; a++)	{
		if (this.docs[a])	{
			for (var b=1; b <= this.docs[a].itemCount; b++)	{
				if ((this.docs[a].items[b].table==TCA.pagesTable && this.docs[a].items[b].id==pid) || (this.docs[a].items[b].table!=TCA.pagesTable && this.docs[a].items[b].pid==pid))	{
					index=a; break;	
				}	
			}
		}
	}
	return index;
}
function editWin_recExist(table,id)	{
	var index=0;
	for (var a=1; a <= this.docCount; a++)	{
		if (this.docs[a])	{
			for (var b=1; b <= this.docs[a].itemCount; b++)	{
				if (this.docs[a].items[b].table==table && this.docs[a].items[b].id==id)	{
					index=a; break;	
				}	
			}
		}
	}
	return index;
}
function editWin_draw (targetDoc)	{
	var doc = this.docs[this.currentDoc];
	if (doc)	{
		var nextItem = doc.firstItem;
		var safetyCounter=100;
		var currentPID = 0;
		var currentPageMini = false;
		var thisPID;
		var prevID;
		var lastKnownRealPageId;
		var newMiniDoc=1;
		while (nextItem!=-1) {
			safetyCounter--;
			if (safetyCounter < 0)	{break;}
			var minimized = 0;
			if (!doc.items[nextItem].maximized || ((doc.items[nextItem].id > 0) && !data.isLoaded(doc.items[nextItem].table, doc.items[nextItem].id)) )	{
				minimized = 1;
			}
			thisPID = (doc.items[nextItem].table==TCA.pagesTable) ? doc.items[nextItem].id : doc.items[nextItem].pid;
			if (doc.items[nextItem].table==TCA.pagesTable || !lastKnownRealPageId)	{
				lastKnownRealPageId=doc.items[nextItem].id;
			}

			if (newMiniDoc)	{
				var theEntryNum = theMenu.entryNums[TCA.pagesTable+'_'+thisPID];
				if (theMenu.entry[theEntryNum])	{
					targetDoc.write('<table border=0 cellpadding=0 cellspacing=0 width=100><tr><td><img src="clear.gif" width=125 height=1></td><td nowrap bgcolor="'+TS.globalBackgroundColor2+'"><NOBR>&nbsp;');
					targetDoc.write(fixed_lgd_pre(theMenu.getPath(theEntryNum),70));
					targetDoc.write('</NOBR><BR><img src="clear.gif" width='+(TS.docLarge?470+150:470)+' height=1></td></tr></table>');
				}
				currentPID = thisPID;
				newMiniDoc=0;
			}
			var theType = data.get(doc.items[nextItem].table, doc.items[nextItem].id, TCA.tables[doc.items[nextItem].table].typeField);
			theType = ((theType != '') ? theType : 0);
			targetDoc.writeln(TCA.getRecord(doc.items[nextItem].table, doc.items[nextItem].id, theType, minimized, nextItem));

			prevID = doc.items[nextItem].id;
			prevPID = doc.items[nextItem].pid;
			
			nextItem = doc.items[nextItem].next;
			
			recordsNotConnected=1;
			if (doc.items[nextItem])	{
				if (doc.items[nextItem].pid == currentPID)	{recordsNotConnected=0;} 
					else if (''+doc.items[nextItem].pid=='-'+prevID) {recordsNotConnected=0;}
						else if (''+doc.items[nextItem].pid==''+prevPID) {recordsNotConnected=0;}
							else if (lastKnownRealPageId == doc.items[nextItem].pid) {recordsNotConnected=0;}
			}
			
			if (nextItem==-1 || doc.items[nextItem].table==TCA.pagesTable || recordsNotConnected)	{
				targetDoc.writeln(TS.docLarge?'<img src="gfx/docmiddle_large.gif" width=755 height=20 border="0"><BR>':'<img src="gfx/docmiddle.gif" width=605 height=20 border="0"><BR>');
				newMiniDoc=1;
			} else {
				targetDoc.writeln(TS.docLarge?'<img src="gfx/stiblet_large.gif" width=755 height=1 border="0"><BR>':'<img src="gfx/stiblet.gif" width=605 height=1 border="0"><BR>');
			}
		}
	}
}
function editWin_load (targetDoc)	{
	var doc = this.docs[this.currentDoc];
	if (doc)	{
		nextItem = doc.firstItem;
		for (var a=1; a <= doc.itemCount; a++)	{
			if (nextItem == -1)	{break;}
			data.loadRecFields(targetDoc, doc.items[a].table, doc.items[a].id);
		}
	}
}
function editWin_recFunctions(type,clickIdent)	{
	var params = '';
	var recObj = this.docs[this.currentDoc].items[clickIdent];
	if (recObj)	{
		switch(type)	{
			case "delete":
				editWin.del(recObj.table,recObj.id,"titel");
			break;
			case "save":
				var dataCheck = data.checkFieldsWithData(recObj.table,recObj.id,'required');
				if (dataCheck)	{
					alert(langObj.get('mess_miss_field',dataCheck));
				} else {
					parent.load_frame.location = 'save.html?action=rec&dataRec='+recObj.table+'_'+recObj.id;
					parent.busy.set(1);
				}
			break;
			case "copy":
			case "select":
				if (recObj=="copy")	{
					clipBrd.action = "copy";
					var thePad = "normal";
				} else {
					var thePad = clipBrd.pad;
				}
				clipBrd.aI(thePad, recObj.table, recObj.id, 'db', data.getLabel(recObj.table,recObj.id), '', '', data.getImage(recObj.table,recObj.id));
				clipBrd.update();
			break;
			case "show":
				var theUrl = "";
				if (recObj.table == "pages")	{
					theUrl = TS.fe_script+"?"+TS.fe_uid+"="+recObj.id;
				} else {
					var theUid =''+recObj.id;
					if (theUid.indexOf("NEW")==-1)	{
						theUrl = TS.fe_script+"?"+TS.fe_uid+"="+recObj.pid;
					} else {
						alert(langObj.get('err_1'));
					}
				}
				if (theUrl)	{
					var tempWin = window.open(theUrl, "frontend");	
					tempWin.focus();
				}
			break;
			case "createnew":
				var theUid =''+recObj.id;
				if (recObj.table==TCA.pagesTable)	{
					if (TCA.contentTable && TCA.tables[TCA.contentTable])	{
						params = '&edit[' + TCA.contentTable + '][' + recObj.id + ']=new&samedoc=1';
					} else {
						params = '&edit[' + recObj.table + '][-' + recObj.id + ']=new&samedoc=1';
					}
				} else {
					params = '&edit[' + recObj.table + '][-' + recObj.id + ']=new&samedoc=1';
				}
				this.edit(params);
			break;
		}
	}
}
function editWin_saveCur(theDoc, closeDoc)	{
	if (!theDoc)	{
		var theDoc = this.currentDoc;
	}
	if (this.docs[theDoc])	{
		var message=this.docs[theDoc].canBeSaved();
		if (message)	{
			alert(langObj.get('mess_miss_field_in_doc',this.docs[theDoc].getTitle(),message));
		} else {
			parent.load_frame.location = 'save.html?action=one&document='+theDoc+(closeDoc ? '&closeDocuments=1' : '');
			parent.busy.set(1);
		}
	}
}
function editWin_clearCache(code)	{
	if (!busy.isBusy(1,'clearCache'))	{
		parent.load_frame.location = 'tce_db.php?cacheCmd='+code+'&vC='+TS.veriCode;
		parent.busy.set(1);
	}
}
function editWin_saveAll(closeDoc)	{
	parent.shift_palette('','',0);
	var canSave = 1;
	for (var theDoc=1; theDoc <= this.docCount; theDoc++)	{
		if (this.docs[theDoc])	{
			var message=this.docs[theDoc].canBeSaved();
			if (message)	{
				alert(langObj.get('mess_miss_field_in_doc',this.docs[theDoc].getTitle(),message));
				canSave = false;
			}
		}
	}
	if (canSave)	{
		parent.load_frame.location = 'save.html?action=all'+(closeDoc ? '&closeDocuments=all' : '');
		parent.busy.set(1);
	}
}
function editWin_prevnextDoc (direction)	{
	parent.shift_palette('','',0);
	var newCurrent = '';
	if (direction == "next")	{
		for (var a=this.currentDoc+1; a <= this.docCount; a++)	{
			if (this.docs[a])	{newCurrent = a; break;}
		}
	} else {
		for (var a=this.currentDoc-1; a > 0; a--)	{
			if (this.docs[a])	{newCurrent = a; break;}
		}
	}
	if (newCurrent)	{
		this.currentDoc = newCurrent;
		editWin.reloadAll();
	}
}
function editWin_closeCur(theDoc)	{
	if (!theDoc)	{
		var theDoc = this.currentDoc;
	}
	parent.shift_palette('','',0);
	if (this.closeDoc(theDoc))	{
		editWin.reloadAll();
		if (!this.countTheDocs())	{
			parent.menuFaner.click("web");
		}
	}
}
function editWin_viewCur(theDoc)	{
	if (this.docs[this.currentDoc] && this.docs[this.currentDoc].items[1])	{
		this.recFunctions("show",1);
	}
}
function editWin_closeAll()	{
	parent.shift_palette('','',0);
	for (var a=1; a <= this.docCount; a++)	{
		this.closeDoc(a);
	}
	editWin.reloadAll();
	if (!this.countTheDocs())	{
		parent.menuFaner.click("web");
	}
}
function editWin_closeDoc(docID,dontAsk)	{
	if (this.docs[docID] && (dontAsk || this.docs[docID].canBeClosed() || langObj.get('mess_docIsChanged',this.docs[docID].getTitle())))	{
		this.docs[docID].cleanUpDoc();
		this.docs[docID] = null;
		if (this.currentDoc == docID)	{
			var newCurrent = '';
			for (var a=this.currentDoc+1; a <= this.docCount; a++)	{
				if (this.docs[a])	{newCurrent = a; break;}
			}
			if (!newCurrent)	{
				for (var a=this.currentDoc-1; a > 0; a--)	{
					if (this.docs[a])	{newCurrent = a; break;}
				}
			}
			if (newCurrent)	{
				this.currentDoc = newCurrent;
			}
		}
		return true;
	} else {return false;}
}
function editWin_initFaner()	{
	var element = dom_getObj('edit',parent.propmenu.document).ref.forms[0].docs;
	element.length=0;
	var valnum = 0;
	for (var a=1; a <= this.docCount; a++)	{
		if (this.docs[a])	{
			element.length++;
			element.options[valnum].value = a;
			element.options[valnum].text = fixed_lgd(this.docs[a].getTitle(),30);
			if (this.currentDoc == a)	{
				element.selectedIndex = valnum;
			}
			valnum++;
		}
	}
}	
function editWin_reloadContent()	{
	parent.content.location='editwin_content.html';
}
function editWin_reloadFaner()	{
	this.initFaner()
}
function editWin_reloadAll ()	{
	this.reloadFaner();
	this.reloadContent();
}
function editWin_edit(params,backPath)	{
//alert(backPath);
	if (!backPath || !TS.bP) {var bP="";} else {var bP=backPath;}
//	alert(TS.serverpath+bP+'load_edit.php?'+params);
	parent.load_frame.location = TS.serverpath+bP+'load_edit.php?'+params;
	parent.busy.set(1);
}
function editWin_delete(table, uid, title)	{
	if (confirm(langObj.get('mess_delete',title)))	{
		parent.issueCommand('&cmd['+table+']['+uid+'][delete]=1');
	}
}
function editWin_editME(ID, cb, noContent)	{
	var params = '';
	var menuItem = (cb) ? parent.clipBrd.bank['db'][ID] :parent.theMenu.entry[ID];
	if (!TS.dontEditInPageModule && menuItem.table=="pages" && !cb)	{
		if (TS.classicPageEditMode)	{
			top.content.document.location='alt_doc.php?returnUrl='+rawurlencode(top.content.document.location)+'&edit['+menuItem.table+']['+menuItem.uid+']=edit&editRegularContentFromId='+menuItem.uid;
		} else {
			theMenu.recentuid = menuItem.uid;
			parent.modPane_web.click('modPane_web_layout');
		}
	} else {
		params = '&edit[' + menuItem.table + '][' + menuItem.uid + ']=edit';
		if (!noContent) {
			params+='&edit_content=1';
		}
		this.edit(params);
	}
}
function editWin_newME(ID, cb)	{
	var params = '';
	var menuItem = (cb) ? parent.clipBrd.bank['db'][ID] :parent.theMenu.entry[ID];
	if (menuItem.table == TCA.pagesTable)	{
		parent.content.db_list_frame.location = 'db_new.php?id='+menuItem.uid;
	} else {
		params = '&edit[' + menuItem.table + '][-' + menuItem.uid + ']=new';
		parent.editWin.edit(params);
	}
}
function editWin_viewME(ID, cb, preview)	{
	var menuItem = (cb) ? parent.clipBrd.bank['db'][ID] :parent.theMenu.entry[ID];
	var prevStr = preview ? "&preview=1" : "";
	if (menuItem.table == TCA.pagesTable)	{
		showInFrontend(menuItem.uid+prevStr,'');
	}
}
function editWin_deleteME(ID, cb)	{
	var menuItem = (cb) ? parent.clipBrd.bank['db'][ID] : parent.theMenu.entry[ID];
	this.del(menuItem.table,menuItem.uid,menuItem.title);
}
function editWin_statME(ID, cb)	{
	var menuItem = (cb) ? parent.clipBrd.bank['db'][ID] : parent.theMenu.entry[ID];
	propertyFrame.wideDoc("pagestat","stat.php?id="+menuItem.uid);
}
function editWin_permsME(ID, cb)	{
	var menuItem = (cb) ? parent.clipBrd.bank['db'][ID] : parent.theMenu.entry[ID];
	parent.content.db_list_frame.location = "perms.php?id="+menuItem.uid;
}


// ************************
// *** Function Manager ***
// ************************
function funcManager()	{
	this.listCmd = funcManager_listCmd;

	this.dbListCmd = funcManager_dbListCmd;
	this.dbTreeCmd = funcManager_dbTreeCmd;
	this.fileListCmd = funcManager_fileListCmd;
	this.fileTreeCmd = funcManager_fileTreeCmd;

	this.lastClickedItem = new Array();
	this.lastClickedItem['fileTreeMenu'] = '';
	this.lastClickedItem['fileListMenu'] = '';
	this.lastClickedItem['dbTreeMenu'] = '';
	this.lastClickedItem['dbListMenu'] = '';
	
	this.isClipBrdNormal = funcManager_isClipBrdNormal;
	this.isNormalEmpty = funcManager_isNormalEmpty;
	this.canRecieveItems = funcManager_canRecieveItems;
		
	this.openCM = funcManager_openCM;
	this.params = 0;
	this.addP = funcManager_addP;
	
	this.selectmode = 0;
	this.selectmodeToggle = funcManager_SelectmodeToggle;
	this.setSelectmode = funcManager_setSelectmode;
}
function funcManager_SelectmodeToggle()	{
	this.selectmode = this.selectmode^1;
	if (this.selectmode) {buttons['selectmode'].state=true;} else {buttons['selectmode'].state=false;}
	buttons['selectmode'].init();
}
function funcManager_setSelectmode(state)	{
	this.selectmode = state;
	if (this.selectmode) {buttons['selectmode'].state=true;} else {buttons['selectmode'].state=false;}
	buttons['selectmode'].init();
}
function funcManager_isClipBrdNormal()	{
	return (parent.clipBrd.pad == 'normal' || !parent.clipBrd.clipboard);
}
function funcManager_isNormalEmpty(type)	{
	return !(parent.clipBrd.bankType['normal'] == type && parent.clipBrd.countItems('normal'));
}
function funcManager_canRecieveItems(type)	{
	return (parent.clipBrd.bankType[parent.clipBrd.pad] == type || parent.clipBrd.countItems(parent.clipBrd.pad)==0);
}
function funcManager_addP(theName)	{
	if (theName)	{
		this.params+=theName+",";
	}
}
function funcManager_openCM(ID, menuName)	{
	// Opens clickmenu
	this.params = '';
	var lastClickedID = this.lastClickedItem[menuName];		

	switch (menuName)	{
	case "dbTreeMenu":
		var table = parent.theMenu.entry[ID].table;
		var uid = parent.theMenu.entry[ID].uid;
		var isPages = (table == TCA.pagesTable);

		this.addP("view");
		if (uid!=0)	this.addP("edit");
		this.addP("new");
		this.addP("info");	
		if (this.isClipBrdNormal())	{
			this.addP("-"); 
			this.addP("copy"); 
			if (uid!=0)	this.addP("cut"); 
			if (!this.isNormalEmpty('db'))	{
				this.addP("pasteinto"); 
				if (uid!=0 && parent.clipBrd.whichTable()=='pages')	this.addP("pasteafter"); 
			}
		} else {
			if (this.canRecieveItems('db'))	{
				this.addP("-"); 
				var selectto = (parent.theMenu.entry[ID] && parent.theMenu.entry[lastClickedID] && parent.theMenu.entry[ID].parent == parent.theMenu.entry[lastClickedID].parent);
				if (parent.clipBrd.bankItemName[parent.clipBrd.pad][table+uid])	{
					this.addP("deselect");
					if (selectto) {		this.addP("deselectto");		}
				} else {
					this.addP("select");
					if (selectto) {		this.addP("selectto");		}
				}
				if (parent.clipBrd.empty())	{
					this.addP("cb_pasteinto"); 
					if (uid!=0 && parent.clipBrd.whichTable()=='pages')	this.addP("cb_pasteafter"); 
				}
			}
		}
		this.addP("-"); 
		if (uid!=0)	this.addP("delete"); 
		if (this.selectmode)	{
			if (uid!=0)	{
				this.dbTreeCmd("select",ID);
			}
		} else {
			parent[menuName].build(this.params);
			parent[menuName].show(ID);
		}
	break;
	case "dbListMenu":
		var obj = parent.clipBrd.bank['db'];
		if (obj[ID])	{
			var uid = obj[ID].uid;
			var table = obj[ID].table;
			var isPages = (table == TCA.pagesTable);
			if (isPages)	{
				this.addP("view");
			}
			this.addP("edit");	
			this.addP("new");
			this.addP("info");	
			if (this.isClipBrdNormal())	{
				this.addP("-"); 
				this.addP("copy"); 
				this.addP("cut"); 
				if (!this.isNormalEmpty('db'))	{
					if (isPages)	this.addP("pasteinto");
//					if (table == parent.clipBrd.bank['normal'][1].table && TCA.tables[table].orderBy)	{		// changed 24-10-00
					if (table == parent.clipBrd.bank['normal'][1].table)	{
						this.addP("pasteafter"); 
					}
				}
			} else {
				if (this.canRecieveItems('db'))	{
					this.addP("-"); 
					if (parent.clipBrd.bankItemName[parent.clipBrd.pad][table+uid])	{
						this.addP("deselect");
						if (lastClickedID) {		this.addP("deselectto");		}
					} else {
						this.addP("select");
						if (lastClickedID) {		this.addP("selectto");		}
					}
					if (parent.clipBrd.empty())	{
						if (isPages)	this.addP("cb_pasteinto"); 
						if (table==parent.clipBrd.whichTable() && TCA.tables[table].orderBy)	{
							this.addP("cb_pasteafter"); 
						}
					}
				}
			}
			this.addP("-"); 
			this.addP("delete"); 
			if (this.selectmode)	{
				this.dbListCmd("select",ID);
			} else {
				parent[menuName].build(this.params);
				parent[menuName].show(ID);
			}
		} else {
			alert(langObj.get('err_2'));
		}
	break;
	case "fileTreeMenu":
		var table = '';
		var uid = fileMenu.entry[ID].values;
		var isRoot = (fileMenu.entry[ID].parent==0);
		this.addP("upload"); 
		this.addP("new");
		if (!isRoot) this.addP("rename");
		this.addP("info");	
		if (this.isClipBrdNormal())	{
			this.addP("-");
			if (!isRoot) this.addP("copy");
			if (!isRoot) this.addP("cut");
			if (!this.isNormalEmpty('file'))	{
				this.addP("pasteinto");
			}
		} else {
			if (this.canRecieveItems('file'))	{
				this.addP("-"); 
				if (!isRoot)	{
					var selectto = (parent.fileMenu.entry[ID] && parent.fileMenu.entry[lastClickedID] && parent.fileMenu.entry[ID].parent == parent.fileMenu.entry[lastClickedID].parent);
					if (parent.clipBrd.bankItemName[parent.clipBrd.pad][table+uid])	{
						this.addP("deselect");
						if (selectto) {		this.addP("deselectto");		}
					} else {
						this.addP("select");
						if (selectto) {		this.addP("selectto");		}
					}
				}
				if (parent.clipBrd.empty())	{
					this.addP("cb_pasteinto"); 
				}
			}
		}
		this.addP("-"); 
		if (!isRoot) this.addP("delete"); 
		if (this.selectmode)	{
			if (!isRoot)	{
				this.fileTreeCmd("select",ID);
			}
		} else {
			parent[menuName].build(this.params);
			parent[menuName].show(ID);
		}
	break;
	case "fileListMenu":
		var obj = parent.clipBrd.bank['file'];
		if (obj[ID])	{
			var uid = obj[ID].uid;
			var table = obj[ID].table;
			this.addP("view");	
			this.addP("edit");	
			this.addP("rename");
			this.addP("info");	
			if (this.isClipBrdNormal())	{
				this.addP("-");
				this.addP("copy");
				this.addP("cut");
			} else {
				if (this.canRecieveItems('file'))	{
				this.addP("-");
					if (parent.clipBrd.bankItemName[parent.clipBrd.pad][table+uid])	{
						this.addP("deselect");
						if (lastClickedID) {		this.addP("deselectto");		}
					} else {
						this.addP("select");
						if (lastClickedID) {		this.addP("selectto");		}
					}
				}
			}
			this.addP("-"); 
			if (TS.image_files.indexOf(','+obj[ID].filetype+',') >= 0)	{
				this.addP("imageprocessing"); 
			}
			if (obj[ID].filetype == "zip")	{
				this.addP("unzip"); 
			}
			this.addP("delete"); 
			if (this.selectmode)	{
				parent.funcMgr.fileListCmd("select",ID);
			} else {
				parent[menuName].build(this.params);
				parent[menuName].show(ID);
			}
		} else {
			alert(langObj.get('err_2'));
		}
	break;
	case "editMenu1":
		shift_palette('','',0);
		this.addP("view"); 
		this.addP("save"); 
		this.addP("createnew"); 
		this.addP("-"); 
		if (this.isClipBrdNormal())	{
			this.addP("copy"); 
		} else {
			this.addP("select"); 
		}
		this.addP("-"); 
		this.addP("delete"); 
		parent[menuName].build(this.params);
		parent[menuName].show(ID);
	break;
	case "valueMenu":
		this.addP("edit"); 
		this.addP("new"); 
		this.addP("delete"); 
		this.addP("deletevalues"); 
		this.addP("deleterecursive"); 
		parent[menuName].build(this.params);
		parent[menuName].show(ID);
	break;
	}
}
function funcManager_dbListCmd (command,ID)	{
	return this.listCmd(command, ID, "db", "dbListMenu");
}
function funcManager_fileListCmd (command,ID)	{
	return this.listCmd(command, ID, "file", "fileListMenu");
}
function funcManager_listCmd (command,ID, type, listname)	{
	var pad = type;
	var cbType = type;
	var obj = parent.clipBrd.bank[pad];
	var menuName = listname;
	var lastClickedID = this.lastClickedItem[menuName];
	var title = obj[ID].title;
	var uid = obj[ID].uid;
	var previd = obj[ID].uid;

	if (obj[ID])	{
		switch (command)	{
			case "info":
				parent.launchView(obj[ID].table, obj[ID].uid);
			break;
			case "copy":
			case "cut":
				clipBrd.action = command;
				clipBrd.bankType['normal'] = '';
				clipBrd.aI('normal', obj[ID].table, obj[ID].uid, cbType, obj[ID].title, obj[ID].fullpath, obj[ID].filetype, obj[ID].image);
			break;
			case "select":
				clipBrd.aI(clipBrd.pad, obj[ID].table, obj[ID].uid, cbType, obj[ID].title, obj[ID].fullpath, obj[ID].filetype, obj[ID].image);
			break;
			case "deselect":
				clipBrd.removeItem(clipBrd.pad, obj[ID].table, obj[ID].uid, cbType);
			break;
			case "select_to":
			case "deselect_to":
				if (obj[lastClickedID])	{
					var firstFound = 0;
					for (var nextItem=1;nextItem<=parent.clipBrd.bankCount[pad];nextItem++)	{
						if (obj[nextItem])	{
							if (!firstFound && (nextItem==ID || nextItem==lastClickedID))	{firstFound = nextItem;}
							if (firstFound)	{
								if (command=="select_to")	{
									clipBrd.aI(clipBrd.pad, obj[nextItem].table, obj[nextItem].uid, cbType, obj[nextItem].title, obj[nextItem].fullpath, obj[nextItem].filetype, obj[nextItem].image);
								} else {
									clipBrd.removeItem(clipBrd.pad, obj[nextItem].table, obj[nextItem].uid, cbType);
								}
							}
							if (firstFound && nextItem!=firstFound && (nextItem==ID || nextItem==lastClickedID))	{break;}
						}
					}
				}
			break;
	// Only with database items:
			case "pasteinto":		
			case "pasteafter":
				insertItem = clipBrd.bank['normal'][1];
				if (insertItem)	{
					var pasteinto_OK = (command=="pasteinto" && cbType=="db");
					if (clipBrd.action == 'copy')	{
						var theLabel = ((pasteinto_OK)?'mess_copy_into':'mess_copy_after');
						if (confirm(langObj.get(theLabel, insertItem.title, title)))	{
							parent.issueCommand('&cmd['+insertItem.table+']['+insertItem.uid+'][copy]='+ ((pasteinto_OK)?uid:-previd) );
						};
					} else {
						var theLabel = ((pasteinto_OK)?'mess_move_into':'mess_move_after');
						if (confirm(langObj.get(theLabel, insertItem.title, title)))	{
							parent.issueCommand('&cmd['+insertItem.table+']['+insertItem.uid+'][move]='+ ((pasteinto_OK)?uid:-previd) );
							clipBrd.clr('normal');
						};
					}
				}
			break;
			case "movecb_into":
			case "movecb_after":
				var pasteinto_OK = (command=="movecb_into" && cbType=="db")?"into":"after";
				var theMode = ((clipBrd.copymode)?'copy':'move');
				if (clipBrd.bankType[clipBrd.pad]=="db" && confirm(langObj.get('mess_'+theMode+'cb_'+pasteinto_OK, clipBrd.empty(), title)))	{
					cmdstring = '';
					for (var n = clipBrd.bankCount[clipBrd.pad]; n >= 1 ; n--)	{
						var itm = clipBrd.bank[clipBrd.pad][n];
						if (itm && itm.act)	{
							cmdstring+= '&cmd['+itm.table+']['+itm.uid+']['+theMode+']='+ ((pasteinto_OK=="into")?uid:-previd);
						}
					}
					parent.issueCommand(cmdstring);
					if (theMode=="move")	{
						clipBrd.clrSelected(clipBrd.pad);
					}
				}
			break;
		}
		this.lastClickedItem[menuName] = ID;
		clipBrd.update();
	}
}
function funcManager_dbTreeCmd (command,ID)	{
	var table = parent.theMenu.entry[ID].table;
	var uid = parent.theMenu.entry[ID].uid;

	var title = parent.theMenu.entry[ID].title;
	var previd = parent.theMenu.entry[ID].uid;
	var menuName = 'dbTreeMenu';
	var lastClickedID = this.lastClickedItem[menuName];
		
	switch (command)	{
		case "info":
			parent.launchView(table, uid);
		break;
		case "copy":
		case "cut":
			clipBrd.action = command;
			clipBrd.bankType['normal'] = '';
			clipBrd.aI('normal', table, uid, 'db', title, '', '', parent.theMenu.entry[ID].image);
		break;
		case "pasteinto":
		case "pasteafter":
			insertItem = clipBrd.bank['normal'][1];
			if (insertItem)	{
				var pasteinto_OK = (command=="pasteinto");
				if (clipBrd.action == 'copy')	{
					var theLabel = ((pasteinto_OK)?'mess_copy_into':'mess_copy_after');
					if (confirm(langObj.get(theLabel, insertItem.title, title)))	{
						parent.issueCommand('&cmd['+insertItem.table+']['+insertItem.uid+'][copy]='+ ((pasteinto_OK)?uid:-previd) );
					};
				} else {
					var theLabel = ((pasteinto_OK)?'mess_move_into':'mess_move_after');
					if (confirm(langObj.get(theLabel, insertItem.title, title)))	{
						parent.issueCommand('&cmd['+insertItem.table+']['+insertItem.uid+'][move]='+ ((pasteinto_OK)?uid:-previd) );
						clipBrd.clr('normal');
					};
				}
			}
		break;
		case "movecb_into":
		case "movecb_after":
			var pasteinto_OK = (command=="movecb_into")?"into":"after";
			var theMode = ((clipBrd.copymode)?'copy':'move');
			if (clipBrd.bankType[clipBrd.pad]=="db" && confirm(langObj.get('mess_'+theMode+'cb_'+pasteinto_OK, clipBrd.empty(), title)))	{
				cmdstring = '';
				for (var n = clipBrd.bankCount[clipBrd.pad]; n >= 1 ; n--)	{
					var itm = clipBrd.bank[clipBrd.pad][n];
					if (itm && itm.act && (command!="movecb_after" || itm.table==TCA.pagesTable))	{
						cmdstring+= '&cmd['+itm.table+']['+itm.uid+']['+theMode+']='+ ((pasteinto_OK=="into")?uid:-previd);
					}
				}
				parent.issueCommand(cmdstring);
				if (theMode=="move")	{
					clipBrd.clrSelected(clipBrd.pad);
				}
			}
		break;
		case "select":
			clipBrd.aI(clipBrd.pad, table, uid, 'db', title, '', '', parent.theMenu.entry[ID].image);
		break;
		case "deselect":
			clipBrd.removeItem(clipBrd.pad, table, uid, 'db');
		break;
		case "select_to":
		case "deselect_to":
			if (theMenu.entry[ID] && theMenu.entry[lastClickedID] && theMenu.entry[ID].parent == theMenu.entry[lastClickedID].parent)	{
				var nextItem = theMenu.entry[theMenu.entry[ID].parent].firstChild;
				var firstFound = 0;
				while(nextItem>0)	{
					if (!firstFound && (nextItem==ID || nextItem==lastClickedID))	{firstFound = nextItem;}
					if (firstFound)	{
						if (command=="select_to")	{
							clipBrd.aI(clipBrd.pad, table, theMenu.entry[nextItem].uid, 'db', theMenu.entry[nextItem].title, '', '', theMenu.entry[nextItem].image);
						} else {
							clipBrd.removeItem(clipBrd.pad, table, theMenu.entry[nextItem].uid);
						}
					}
					if (firstFound && nextItem!=firstFound && (nextItem==ID || nextItem==lastClickedID))	{break;}
					nextItem = theMenu.entry[nextItem].nextItem;
				}
			}
		break;
	}
	this.lastClickedItem[menuName] = ID;
	clipBrd.update();
}
function funcManager_fileTreeCmd (command, ID)	{
	var menuName = 'fileTreeMenu';
	var lastClickedID = this.lastClickedItem[menuName];
	
	var uid = fileMenu.entry[ID].values;
	var filename = fileMenu.entry[ID].title;
	var fullpath = fileMenu.entry[ID].path;
	var filetype = "folder";
	var imagefile = "folder.gif";
	
	switch (command)	{
		case "copy":
		case "cut":
			clipBrd.action = command;
			clipBrd.bankType['normal'] = '';
			clipBrd.aI('normal', '', uid, 'file', filename, fullpath, filetype, imagefile);
		break;
		case "pasteinto":
			insertItem = clipBrd.bank['normal'][1];
			if (insertItem)	{
				if (clipBrd.action == 'copy')	{
					if (confirm(langObj.get("mess_copy_into", insertItem.title, filename)))	{
						if (TS.which_os!="WIN" || insertItem.filetype!="folder")	{
							parent.issueFileCommand('&file[copy][1][data]='+rawurlencode(insertItem.fullpath)+'&file[copy][1][target]='+rawurlencode(fullpath));
						}
					};
				} else {
					if (langObj.get("mess_move_into", insertItem.title, filename))	{
						parent.issueFileCommand('&file[move][1][data]='+rawurlencode(insertItem.fullpath)+'&file[move][1][target]='+rawurlencode(fullpath));
						clipBrd.clr("normal");
					};
				}
			}
		break;
		case "movecb_into":
			var theMode = ((clipBrd.copymode)?'copy':'move');
			if (clipBrd.bankType[clipBrd.pad]=="file" && confirm(langObj.get('mess_'+theMode+'cb_into', clipBrd.empty(), filename)))	{
				cmdstring = '';
				for (var n=1; n<=clipBrd.bankCount[clipBrd.pad]; n++)	{
					var itm = clipBrd.bank[clipBrd.pad][n];
					if (itm && itm.act)	{
						cmdstring+= '&file['+theMode+']['+n+'][data]='+rawurlencode(itm.fullpath)+'&file['+theMode+']['+n+'][target]='+rawurlencode(fullpath);
					}
				}
				parent.issueFileCommand(cmdstring);
				if (theMode=="move")	{
					clipBrd.clrSelected(clipBrd.pad);
				}
			}
		break;
		case "select":
			clipBrd.aI(clipBrd.pad, '', uid, 'file', filename, fullpath, filetype, imagefile);
		break;
		case "deselect":
			clipBrd.removeItem(clipBrd.pad, '', uid, 'file');
		break;
		case "select_to":
		case "deselect_to":
			if (fileMenu.entry[ID] && fileMenu.entry[lastClickedID] && fileMenu.entry[ID].parent == fileMenu.entry[lastClickedID].parent)	{
				var nextItem = fileMenu.entry[fileMenu.entry[ID].parent].firstChild;
				var firstFound = 0;
				while(nextItem>0)	{
					if (!firstFound && (fileMenu.entry[nextItem].uid==fileMenu.entry[ID].uid || fileMenu.entry[nextItem].uid==fileMenu.entry[lastClickedID].uid))	{firstFound = fileMenu.entry[nextItem].uid;}
					if (firstFound)	{
						if (command=="select_to")	{
							clipBrd.aI(clipBrd.pad, '', fileMenu.entry[nextItem].values, 'file', fileMenu.entry[nextItem].title, fileMenu.entry[nextItem].path, filetype, imagefile);
						} else {
							clipBrd.removeItem(clipBrd.pad, '', fileMenu.entry[nextItem].values, 'file');
						}
					}
					if (firstFound && fileMenu.entry[nextItem].uid!=firstFound && (fileMenu.entry[nextItem].uid==fileMenu.entry[ID].uid || fileMenu.entry[nextItem].uid==fileMenu.entry[lastClickedID].uid))	{break;}
					nextItem = fileMenu.entry[nextItem].nextItem;
				}
			}
		break;
	}
	this.lastClickedItem[menuName] = ID;
	clipBrd.update();
}


// ****************
// ***   Data   ***
// ****************
function dataItem(table, field, data, pointer)	{
	this.name = field;
	this.name = table;

	this.data = new Array();
	this.data['server'] = '';
	this.data['client'] = '';
	this.data['fresh'] = '';
	this.data['default'] = '';

	this.pres = new Array();
	this.pres['server'] = 0;
	this.pres['client'] = 0;
	this.pres['fresh'] = 0;
	this.pres['default'] = 1;

	if (TCA && TCA.tables[table] && TCA.tables[table].fields[field] && TCA.tables[table].fields[field].defVal)	{
		this.data['default'] = TCA.tables[table].fields[field].defVal;
		this.pres['default'] = 1;
	}
	this.checkbox = 0;	
	this.checkbox_tempvalue = '';	
	this.RTEloaded = 0;	
	
	if (!pointer)	{
		this.pointer = 'server';
	} else {
		this.pointer = pointer;
	}
	this.pres[this.pointer] = 1;
	this.data[this.pointer] = data;
}
function recItem(table, id, pid, typeField, recPath, recCount)	{
	this.table = table;
	this.id = id;
	this.name = table+'_'+id;

	this.pid = pid;
	this.typeField = typeField;
	this.recPath = recPath;
	this.recCount = recCount;

	this.pres = new Array();
	this.pres['server'] = 0;
	this.pres['client'] = 0;
	this.pres['fresh'] = 0;
	this.pres['default'] = 0;

	this.field = new dataItem('','','','');
	this.fieldCount = 0;
	this.fieldNames = new Array();
	this.add = recItem_add;
	this.update = recItem_update;
	this.setPointer = recItem_setPointer;
	
	this.image = (TCA && TS && TCA.tables[table]) ? TS.iconpath+TCA.tables[table].iconfile : '';
}
function recItem_add(field, data, pointer)	{
	if (!this.field[field])	{	
		this.fieldCount++;
		this.fieldNames[this.fieldCount] = field;
	}
	this.field[field] = new dataItem(this.table, field, data, pointer);
}
function recItem_update(field, data, type)	{
	if (this.field[field])	{
		this.field[field].data[type] = data;
		this.field[field].pres[type] = 1;
	}
}
function recItem_setPointer(field, type)	{
	if (this.field[field] && this.field[field].pres[type])	{
		this.field[field].pointer = type;
	}
}
function dataObj()	{
	this.rec = new recItem();
	this.recNames = new Array();
	this.recCount = 0;

	this.create = data_create; 
	this.load = data_load;
	this.update = data_update;
	this.setFlags = data_setFlags;
	this.loadField = data_loadField;
	this.loadRecFields = data_loadRecFields;
	this.getFieldName = data_getFieldName;
	this.get = data_get;
	this.getFromPointer = data_getFromPointer;
	this.getPointer = data_getPointer;
	this.getLabel = data_getLabel;
	this.getPid = data_getPid;
	this.checkFieldsWithData = data_checkFieldsWithData;
	this.canFieldBeSaved = data_canFieldBeSaved;
	this.changed = data_ischanged;
	this.isLoaded = data_isLoaded;
	this.registerNewData = data_registerNewData;
	this.del = data_delete;
	this.setImage = data_setImage;
	this.getImage = data_getImage;
	this.setRTEFlag = data_setRTEFlag;
	this.getRTELoaded = data_getRTELoaded;
}
function data_create(table, id, pid, typeField, recPath)	{
	var name = table+'_'+id;
	if (!this.rec[name])	{
		this.recCount++;
		this.recNames[this.recCount] = name;
		this.rec[name] = new recItem(table, id, pid, typeField, recPath, this.recCount);
		return true;
	} else {return false;}
}
function data_load(table, id, field, data, type)	{
	var name = table+'_'+id;
	if (this.rec[name])	{
		this.rec[name].add(field, data, type);
	}
}
function data_setRTEFlag(table, id, field)	{
	var name = table+'_'+id;
	if (this.rec[name])	{
		this.rec[name].field[field].RTEloaded = 1;
	}
}
function data_getRTELoaded(table, id, field)	{
	var name = table+'_'+id;
	if (this.rec[name] && this.rec[name].field[field])	{
		var value = this.rec[name].field[field].RTEloaded;
		return value;
	} return '';
}
function data_setImage(table,id,imagefile)		{
	var name = table+'_'+id;
	if (this.rec[name])	{
		this.rec[name].image = imagefile;
	}
}
function data_getImage(table,id)		{
	var name = table+'_'+id;
	if (this.rec[name])	{
		return this.rec[name].image;
	}
}
function data_update(table, id, field, data, type, notSetPointer)	{
	var name = table+'_'+id;
	if (this.rec[name])	{
		this.rec[name].update(field, data, type);
		if (!notSetPointer)	{
			this.rec[name].setPointer(field, type);
		}
		if (TCA.tables[table].typeField == field)	{
			return "reload";
		} else {
			return true;
		}
	}
}
function data_setFlags(table, id, field, targetDoc)	{
	var FObj = TCA.tables[table].fields[field];
	var value = this.get(table, id, field);
	var isNotSet = isRequiredNotOK(FObj, value);
	if (targetDoc)	{
		var theImg = targetDoc['req_'+table+'_'+id+'_'+field] || targetDoc['req_'+table+'_'+field];
		if (theImg)	{
			theImg.src = glImage.getSrc('required',(isNotSet)?'h':'n');
		}
		var theImg = targetDoc['cm_'+table+'_'+id+'_'+field] || targetDoc['cm_'+table+'_'+field];
		if (theImg)	{
			var theImgType = "n";
			switch (this.getPointer(table,id,field))	{
				case "default": 	theImgType = "d";	break;
				case "fresh": 	theImgType = "s";	break;
				case "client": 	theImgType = "h";	break;
			}
			theImg.src = glImage.getSrc('contentMode',theImgType);
		}
	}
	return isNotSet;
}
function data_checkFieldsWithData(table,id,type)	{
	var TObj = TCA.tables[table];
	var name = table+'_'+id;
	var savedList='';
	var hasBeenChanged = 0;
	if (TObj && this.rec[name])	{
		var theType = this.get(table, id, TObj.typeField);
		theType = ((theType != '') ? theType : 0);
		if (!TObj.types[theType])	{var theType=1;}

		var count = TObj.types[theType].itemCount;
		for (var a=0; a < count; a++) {
			var field = TObj.types[theType].items[a];
			if (TObj.fields[field])	{
				var theFieldName = (TObj.types[theType].altlabel[a] || TObj.fields[field].label);
				if (!this.canFieldBeSaved(table, id, field))	{
					savedList +='\n'+ theFieldName;
				}
				hasBeenChanged |= this.changed(table, id, field);
			}
			if (TObj.fields[field] || field=="--palette--")	{
				var palName = table+'_'+TObj.types[theType].palette[a];
				if (TCA.palettes[palName])	{
					var palCount = TCA.palettes[palName].itemCount;	
					for (var b=0; b < palCount; b++) {
						var field = TCA.palettes[palName].items[b];
						if (!this.canFieldBeSaved(table, id, field))	{
							savedList +='\n'+ theFieldName+'/'+(TCA.palettes[palName].altlabel[b] || TObj.fields[field].label);
						}
						hasBeenChanged |= this.changed(table, id, field);
					}
				}
			}
		}

		var palName = table+'_'+TObj.mainpalette;
		if (TCA.palettes[palName])	{
			var palCount = TCA.palettes[palName].itemCount;
			for (var b=0; b < palCount; b++) {
				var field = TCA.palettes[palName].items[b];
					if (!this.canFieldBeSaved(table, id, field))	{
						savedList +='\n'+'OPTIONS/'+(TCA.palettes[palName].altlabel[b] || TObj.fields[field].label);
					}
					hasBeenChanged |= this.changed(table, id, field);
			}
		}
		switch (type)	{
			case "changed":
				return hasBeenChanged;
			break;
			case "required":
				return savedList;
			break;
		}
	}
	return false;
}
function data_canFieldBeSaved(table,id,field)	{
	return !isRequiredNotOK(TCA.tables[table].fields[field], this.get(table, id, field));
}
function data_get(table, id, field)	{
	var name = table+'_'+id;
	if (this.rec[name] && this.rec[name].field[field])	{
		var value = this.rec[name].field[field].data[ this.rec[name].field[field].pointer ];
		return value;
	} return '';
}
function data_getFromPointer(table, id, field, pointer)	{
	var name = table+'_'+id;
	if (this.rec[name] && this.rec[name].field[field])	{
		var value = this.rec[name].field[field].data[pointer];
		return value;
	} return '';
}
function data_getPointer(table, id, field)	{
	var name = table+'_'+id;
	if (this.rec[name] && this.rec[name].field[field])	{
		return this.rec[name].field[field].pointer;
	} return '';
}
function data_getLabel(table, id)	{
	return TCA.tables[table] ? this.get(table,id,TCA.tables[table].labelCol) : "";
}
function data_getPid(table, id)	{
	var name = table+'_'+id;
	if (this.rec[name])	{
		return this.rec[name].pid;
	} 
	return '';
}
function data_isLoaded (table, id)	{
	var name = table+'_'+id;
	return (this.rec[name]);
}
function data_ischanged(table, id, field)	{
	var name = table+'_'+id;
	if (this.rec[name] && this.rec[name].field[field])	{
		if (this.rec[name].field[field].pointer != 'server')	{
			return true;
		} else {
			return false;
		}
	} else {return false;}
}
function data_loadField (targetDoc,table,id,field)	{
	var name = table+'_'+id;
	var FObj = TCA.tables[table].fields[field];
	if (FObj)	{
		var formfield = this.getFieldName('data',table,id,field);
		var value = this.get(table, id, field);
		this.setFlags(table,id,field,targetDoc);
		if (FObj.type != "check")	{
			if (targetDoc.editform[formfield] && this.rec[name])	{
				var element = targetDoc.editform[formfield];
				var special = FObj.internal_type || ((FObj.type=="select" && FObj.maxitems>1)?"select":"");
				if (FObj.type=="input" && FObj.checkbox && targetDoc.editform[formfield+'_check'])	{
					if (FObj.checkboxValue == value)	{
						targetDoc.editform[formfield+'_check'].checked = 0;
						value = FObj.checkboxValue;
					} else {
						targetDoc.editform[formfield+'_check'].checked = 1;
					}
				}
				loadFormElement (element, evalFunc.outputObjValue(FObj,value), special, FObj.type);
			}
		} else {
			for (var a=0; a<FObj.itemNum; a++)	{
				var element = targetDoc.editform[formfield+'_'+a];
				if (element)	{
					loadFormElement (element, value&Math.pow(2,a),'',FObj.type);
				}
			}
		}
	}
}
function data_loadRecFields (targetDoc,table,id)	{
	var name = table+'_'+id;
	if (this.rec[name])	{
		for (var n = 1; n <= this.rec[name].fieldCount; n++)	{
			this.loadField(targetDoc,table,id,this.rec[name].fieldNames[n]);
		}
	}
}
function data_getFieldName (pre,table,id,field)	{
	return pre+'['+table+']['+id+']['+field+']';
}
function data_registerNewData(table,cur_id,new_id,new_pid)	{
	var keyname = table+'_'+cur_id;
	var keyname_new = table+'_'+new_id;
	if (data.rec[keyname])	{
		this.create(table, new_id, '', '', '');	
		this.rec[keyname_new] = this.rec[table+'_'+cur_id];
		this.rec[keyname_new].pid = new_pid;
		this.rec[keyname_new].id = new_id;

		for (var n = 1; n <= this.recCount; n++)	{
			if (data.rec[data.recNames[n]])	{
				if (data.rec[data.recNames[n]].pid == cur_id)	{
					data.rec[data.recNames[n]].pid = new_id;
				} else if (''+data.rec[data.recNames[n]].pid == '-'+cur_id) {
					data.rec[data.recNames[n]].pid = -new_id;
				}
			}
		}
		for (var n=1; n <= editWin.docCount; n++)	{
			if (editWin.docs[n])	{
				var theItemNum = editWin.docs[n].itemNums[keyname];
				if (editWin.docs[n].items[theItemNum])	{
					editWin.docs[n].items[theItemNum].id = new_id;
					editWin.docs[n].items[theItemNum].pid = new_pid;
					editWin.docs[n].itemNums[keyname_new] = theItemNum;
						
					var nextItem = editWin.docs[n].firstItem;
					var safetyCounter=100;
					while (nextItem!=-1) {
						safetyCounter--;
						if (safetyCounter < 0)	{break;}
						if (editWin.docs[n].items[nextItem].pid == cur_id)	{
							editWin.docs[n].items[nextItem].pid = new_id;
						}
						nextItem = editWin.docs[n].items[nextItem].next;
					}
				}
			}
		}
	}
}
function data_delete(table, id, checkTypoDocs)	{
	var deleteFlag = 1;
	if (checkTypoDocs)	{
		var keyname = table+'_'+id;
		for (var n=1; n <= editWin.docCount; n++)	{
			if (editWin.docs[n])	{
				var theItemNum = editWin.docs[n].itemNums[keyname];
				if (theItemNum)	{deleteFlag = 0; break;}
			}
		}
	}
	if (this.rec[table+'_'+id] && deleteFlag)	{	
		this.recNames[this.rec[table+'_'+id].recCount] = '';
		this.rec[table+'_'+id] = null;
	}
}


// *****************
// ***   Forms   ***
// *****************
function fielddraw_select (theTable, theField, label) {
	this.type = "select";
	this.draw = fielddraw;
	this.table = theTable;
	this.field = theField;
	this.label = label || '';

	this.size = 1;
	this.multiple = '';
	this.maxitems = '';
	this.minitems = '';
	
	this.itemNames = new Array();
	this.itemValues = new Array();
	this.itemNum = 0;
	this.defVal = '';
}
function fielddraw_group (theTable, theField, label) {
	this.type = "group";
	this.draw = fielddraw;
	this.table = theTable;
	this.field = theField;
	this.label = label || '';

	this.internal_type = '';
	this.show_thumbs = '';
	this.size = 3;
	this.multiple = '';
	this.maxitems = '';
	this.minitems = '';
	this.allowed = '';
	this.disallowed = '';
	this.max_size = '';
	this.uploadfolder = '';
	this.tables = '';
	this.defVal = '';
	this.info = '';
}
function fielddraw_text (theTable, theField, label) {
	this.type = "text";
	this.draw = fielddraw;
	this.table = theTable;
	this.field = theField;
	this.label = label || '';

	this.cols = 30;
	this.rows = 5;
	this.wrap = 'virtual';
	this.defVal = '';
}
function fielddraw_input (theTable, theField, label) {
	this.type = "input";
	this.draw = fielddraw;
	this.table = theTable;
	this.field = theField;
	this.label = label || '';

	this.size = 48;
	this.max = 256;
	this.evallist = '';
	this.is_in = '';
	this.checkbox = '';
	this.checkboxValue = '';
	this.range_upper = '';
	this.range_lower = '';
	this.defVal = '';
}
function fielddraw_check (theTable, theField, label) {
	this.type = "check";
	this.draw = fielddraw;
	this.table = theTable;
	this.field = theField;
	this.label = label || '';
	
	this.cols = "";
	this.itemNames = new Array();
	this.itemValues = new Array();
	this.itemNum = 0;
	this.defVal = '';
	this.showIfRTE=0;
}
function fielddraw_radio (theTable, theField, label) {
	this.type = "radio";
	this.draw = fielddraw;
	this.table = theTable;
	this.field = theField;
	this.label = label || '';

	this.itemNames = new Array();
	this.itemValues = new Array();
	this.itemNum = 0;
	this.defVal = '';
}
function fielddraw_none (theTable, theField, label) {
	this.type = "none";
	this.table = theTable;
	this.field = theField;
	this.label = label || '';

	this.draw = fielddraw;
	this.defVal = '';
}
function fielddraw (ID, palette, specConf, theType)	{
	var res='';
	var theColsParam='';
	var itemname = 'data['+this.table+']['+ID+']['+this.field+']';
	if (ID == "pal")	{
		var params = "parent.TCA.currentPaletteTable, parent.TCA.currentPaletteID, '"+this.field+"', this, document";
	} else {
		var params = "'"+this.table+"','"+ID+"','"+this.field+"', this, document";
	}			
	var onFocus = (palette>=0) ? " OnFocus=\"currentElement=this; parent.shift_palette('"+this.table+"','"+ID+"','"+palette+"');\"" : " OnFocus=\"currentElement=this;\"";
	var largeComp = TS.docLarge ? TS.largeComp : 1;
	
	switch (this.type)	{
		case "text":
			value = ''+data.get(this.table, ID, this.field);
			var theCols = this.cols;
			var theRows = this.rows;
			var theWrap = this.wrap;
			if (value.length>TS.charsPerRow*2)	{
				theCols = TS.maxTextareaWidth;
				theRows = Math.round(value.length/TS.charsPerRow);
				if (theRows>20)	{theRows=20;}
				if (theRows<this.rows) {theRows=this.rows;}
			}
			var styleC = ' style="width:'+(Math.round(theCols*TS.rowsToStylewidth*largeComp))+'px"';
			var noRTE=1;
			var theRecPid = data.getPid(this.table, ID)+'';
			if (TS.docRTE && specConf.indexOf('richtext')!=-1)	{
				noRTE=0;
				var RTEfield = getRTEflagField(specConf)+"";
				if (RTEfield)	{noRTE = parseInt(data.getFromPointer(this.table, ID, RTEfield, "server"));}
			}
				// Finally the value loaded to the interface must have had the RTE flag set from the transferdata-class. 
				// In particular this check secures that the RTE is not loaded if it's disabled in this particular branch of the website.
			if (!data.getRTELoaded(this.table, ID, this.field) || theRecPid.indexOf("NEW")!=-1)	noRTE=1;
			if (!noRTE)	{
				res+= '<DIV id="cdiv" style="position:relative; left:0px; top:0px; height:380; width:'+(TS.docLarge?460+150:460)+';border:solid 0px;">';
//					res+= '<TEXTAREA name="'+itemname+'" wrap="soft" style="visibility:visible; z-index:100; position:absolute; left:0px; top:0px; height=100%; width=100%"></TEXTAREA>';
					res+= '<input type=hidden name="'+itemname+'">';
					res+= '<IFRAME src="rte/rte.php?elementId='+rawurlencode(itemname)+'&pid='+theRecPid+'&typeVal='+rawurlencode(theType)+'&sC='+rawurlencode(specConf)+'" id="'+itemname+'" style="visibility: visible; position: absolute; left: 0px; top: 0px; height=100%; width=100%"></IFRAME>';
				res+= '</DIV>';
			} else {
				if (specConf.indexOf('nowrap')!=-1) {theWrap = "OFF";}
				if (!TS.formStyle || theWrap!="OFF")	{theColsParam=' cols="'+Math.round(theCols*largeComp)+'"';} else {theColsParam='';}
				res+= '<textarea name="'+itemname+'"'+theColsParam+' rows="'+theRows+'" wrap="'+theWrap+'" OnBlur="parent.form_has_changed('+params+');" '+onFocus+styleC+'></textarea>';
			}
		break;
		case "input":
			if (this.checkbox)	{
				res+= '<input type="Checkbox" name="'+itemname+'_check" OnClick="parent.inputCheckBoxIsClicked('+params+');">';
			}
			var theSize = this.size;
			var styleC = ' style="width:'+(Math.ceil(theSize*TS.rowsToStylewidth*largeComp))+'px"';
			res+= '<input type="Text" name="'+itemname+'" value="" size="'+Math.ceil(theSize*largeComp)+'" maxlength="'+this.max+'" OnBlur="parent.form_has_changed('+params+');" '+onFocus+styleC+'>';
		break;
		case "check":
			if (this.cols > 1)	{
				res+= '<table border=0 cellspacing=0 cellpadding=0>';
				for (var n = 0; n < this.itemNum; n++) {
					if(!(n%this.cols))	{res+='<tr>'};
					res+= '<td nowrap><input type="Checkbox" name="'+itemname+'_'+n+'" OnClick="parent.form_has_changed('+params+');" '+onFocus+'>'+this.itemNames[n+1]+'&nbsp;</td>';
					if((n%this.cols)+1==this.cols)	{res+='</tr>'};
				}
				for (var n = 0; n < (this.cols-(n%this.cols)); n++) {
					res+= '<td></td>';
				}
				if (n>0)	{res+= '</tr>';}
				res+= '</table>';
			} else {
				for (var n = 0; n < this.itemNum; n++) {
					res+= (n>0?'<BR>':'')+'<input type="Checkbox" name="'+itemname+'_'+n+'" OnClick="parent.form_has_changed('+params+');" '+onFocus+'>'+this.itemNames[n+1];
				}
			}
		break;
		case "radio":
			if (this.itemNum > 0)	{
				for (var n = 1; n <= this.itemNum; n++) {
					res+= '<input type="Radio" name="'+itemname+'" value="'+this.itemValues[n]+'" OnClick="parent.form_has_changed('+params+');" '+onFocus+'>'+this.itemNames[n]+'<BR>';
				}
			}
		break;
		case "select":
			if (this.maxitems<=1)	{
				res+= '<select name="'+itemname+'"'+((this.size)?" size="+this.size:"")+' OnChange="parent.form_has_changed('+params+');" '+onFocus+'>';
				for (var n = 1; n <= this.itemNum; n++) {
					res+= '<option value="'+this.itemValues[n]+'">'+this.itemNames[n]+'</option>';
				}
				res+= '</select>';
			} else {
				res+= '<table border=0 cellspacing=0 cellpadding=0><tr>';
				res+= '<td valign="top">'+langObj.get('l_selected')+':<BR><select style="width:200 px;" name="'+itemname+'"'+((this.size)?" size="+this.size:"")+onFocus+' multiple><option value="">________________________</option></select></td>';
				res+= '<td valign="top"><BR>';
				res+= '<A HREF="javascript: parent.select_group_change(\'totop\', '+params+');"><img src="gfx/group_totop.gif" hspace=2 vspace=2 width=14 height=14 border=0 title="'+langObj.get('l_move_to_top')+'"></a><BR>';
				res+= '<a href="javascript: parent.select_group_change(\'remove\', '+params+');"><img src="gfx/group_clear.gif" hspace=2 vspace=2 width=14 height=14 border=0 title="'+langObj.get('l_remove_selected')+'"></a></td>';
				res+= '<td><img src="clear.gif" width=30 height=1></td>';
				res+= '<td valign="top">'+langObj.get('l_items')+':<BR><select style="width:200 px;" name="'+itemname+'_list"'+((this.size)?" size="+this.size:"")+' OnChange="parent.select_group_change(\'add\', '+params+');">';
				for (var n = 1; n <= this.itemNum; n++) {
					res+= '<option value="'+this.itemValues[n]+'">'+this.itemNames[n]+'</option>';
				}
				res+= '</select></td>';
				res+= '</tr></table>';
			}
		break;
		case "group":
			var theSelectorSize = this.size;
			var thumbsCode = "";
			thumbsCode+= '</td><td><img src="clear.gif" width=20 height=1></td><td valign="top">';
			if (this.show_thumbs)	{
					if (this.internal_type == "file")	{
						var value = data.get(this.table, ID, this.field);
						thumbsCode+= thumbsForDocs(value, TCA.tables[this.table].fields[this.field].uploadfolder);
						var valnum = thumbsForDocs_recentImgCount;
					}
					if (this.internal_type == "db")	{
						value = data.get(this.table, ID, this.field);
						var valnum = 0;
						var valItem = parent.split(value, ',', valnum+1);
						var clipLabel = langObj.get('l_selectToClip');
						var zoomLabel = langObj.get('l_viewItem');
						var editLabel = langObj.get('l_editItem');
						while (valItem)	{
							var theValue = unescape(parent.split(valItem,'|',1));
							var theTitle = unescape(parent.split(valItem,'|',2));
							var theAlt = unescape(parent.dbPathRef.item[theValue]);
							
							var thisTableType = splitKeyname(theValue,"");
							var thisUid = splitKeyname(theValue,"uid");
							var thisIcon = TCA.tables[thisTableType] ? TCA.tables[thisTableType].iconfile : TS.notFoundIcon;
							thumbsCode+= '<DIV><NOBR><A HREF="javascript:parent.launchView(\''+thisTableType+'\', '+thisUid+');"><img src="gfx/zoom2.gif" width=12 height=12 border=0 align="top" title="'+zoomLabel+'"></a><A HREF="javascript:parent.launchEdit(\''+thisTableType+'\', '+thisUid+');"><img src="gfx/edit2.gif" width=11 height=12 border=0 align="top" title="'+editLabel+'"></a><A HREF="javascript:parent.clipBrd.aI(parent.clipBrd.pad, \''+thisTableType+'\', '+thisUid+', \'db\', unescape(\''+escape(theTitle)+'\'), \'\', \'\', \''+TS.iconpath+thisIcon+'\',\'copy\');parent.clipBrd.update();"><img src="gfx/clipbrd.gif" width=12 height=12 border=0 title="'+clipLabel+'" align="top"></a>&nbsp;&nbsp;&nbsp;&nbsp;<img src="'+TS.iconpath+thisIcon+'" width=18 hspace=2 height=16 border=0 align="top" title="'+theAlt+'">'+theTitle+'</NOBR></DIV>';
							if (TS.thumbmode && parent.thumbRef.item[theValue])	{
								thumbsCode+='<table width=100><tr><td><img src="clear.gif" width=30 height=1></td><td>';
								thumbsCode+= thumbsForDocs(parent.thumbRef.item[theValue], parent.thumbRef.itemDir[theValue], 3);
								thumbsCode+='</td></tr></table>';
							}
							valnum++;
							valItem = parent.split(value, ',', valnum+1);
						}
					}
					if (valnum > theSelectorSize) {theSelectorSize = valnum;}
			}
			thumbsCode+= '</td>';

			res+= '<table border=0 cellspacing=0 cellpadding=0><tr>';
			res+= '<td valign="top" width=100><select style="width:200 px;" name="'+itemname+'"'+((theSelectorSize>1)?" size="+theSelectorSize:"")+onFocus+' multiple><option value="">________________________</option><option></option><option></option></select>';
			res+= '<BR>'+this.info;
			res+= '</td>';
			res+= '<td valign="top">';
			
			var tempCmd = 'parent.group_change(\'add\', '+params+');';
			var browseParams = this.table+'|'+ID+'|'+this.field+'|'+this.allowed+'|'+this.disallowed;
			var clipUpload = '<A HREF="#" onClick="parent.clipBrd.open(\''+rawurlencode(tempCmd)+'\'); return false;"><img src="gfx/group_upload.gif" hspace=2 vspace=2 width=14 height=14 border=0 title="'+langObj.get('l_upload_files')+'"></A>';
			var browseWindow = '<A HREF="#" onClick="parent.clipBrd.openBrowser(\''+this.internal_type+'\',\''+rawurlencode(browseParams)+'\'); return false;"><img src="gfx/insert3.gif" hspace=2 width=14 height=14 border=0 title="'+langObj.get('l_browse_'+this.internal_type)+'"></A>';
			
			res+= '<A HREF="javascript: '+tempCmd+'"><img src="gfx/group_clipbrd.gif" hspace=2 width=14 height=14 border=0 title="'+langObj.get('l_import_clip')+'"></a>';
			res+= browseWindow;
			res+= '<BR>';
			res+= '<A HREF="javascript: parent.group_change(\'totop\', '+params+');"><img src="gfx/group_totop.gif" hspace=2 vspace=2 width=14 height=14 border=0 title="'+langObj.get('l_move_to_top')+'"></a>';
			if (this.internal_type=="file")	{
				res+= clipUpload;
			}
			res+= '<BR>';
			res+= '<A HREF="javascript: parent.group_change(\'remove\', '+params+');"><img src="gfx/group_clear.gif" hspace=2 width=14 height=14 border=0 title="'+langObj.get('l_remove_selected')+'"></A>';
			res+=thumbsCode;
			res+= '</tr></table>';
			if (TS.isUpload && TS.docUpload && this.internal_type=="file")	{
				var itemid = this.table+'__'+ID+'__'+this.field;
				res+= '<nobr><input type="file" name="upload_'+itemid+'" size=50><input type="Hidden" name="file[upload]['+itemid+'][target]" value="'+TS.isUpload+'"><input type="Hidden" name="file[upload]['+itemid+'][data]" value="'+itemid+'"><input type="Hidden" name="redirect" value="status_file.php?editwin=1">&nbsp;&nbsp;<input type="submit" value="'+langObj.get('l_upload')+'" name="submit" onClick="document.editform.action=\'tce_file.php\';"></nobr><BR>';
			}
		break;
		case "none":
			res+= data.get(this.table, ID, this.field);
		break;
	}
	return res;
}
function loadFormElement (element, value, special, type)	{
	switch (element.type)	{
		case "select-one":
		case "select-multiple":
			switch (special)	{
			case "select":	
			case "file":
			case "db":
				loadGroupSelectorBox(element, value);
			break;
			default:
				for (var i=0; i < element.options.length; i++) {
					if (element.options[i].value == value)	{
						element.selectedIndex = i;
			//			debug(element.name,value,special,type);
					}
				}
			}
		break;
		case "checkbox":
			element.checked = value;
		break;
		default:
			if (type=="radio")	{
				for (var i=0; i < element.length; i++) {
					if (element[i].value==value) {element[i].checked=true;} else {element[i].checked=false;}
				}
/*		Meget elegant, men virker kun med netscape...
			   for (i in element) {
			   		if (i>=0 && i<element.length)	{
						if (element[i].value==value) {element[i].checked=true;} else {element[i].checked=false;}
					}
			   }			   */
			} else {
				element.value = value;
			}
	}
}



// *********************
// ***   TCAtables   ***
// *********************

function tcaTablesItemType (name)	{
	this.name = name;
	this.items = new Array();
	this.altlabel = new Array();
	this.palette = new Array();
	this.specConf = new Array();
	this.itemCount = 0;
}
function tcaTablesPalette (name, table, num)	{
	this.name = name;
	this.table = table;
	this.num = num;
	this.items = new Array();
	this.altlabel = new Array();
	this.itemCount = 0;
}
function tcaTables_getField (table, id, name, altlabel, palette, specConf,theType)	{
	var res = '';
	var thePalette = (TCA.palettes[table+'_'+palette] ? TCA.palettes[table+'_'+palette].num : 0);
	if (this.tables[table].fields[name] || name=="--div--" || name=="--palette--")	{
		if (!this.tables[table].fields[name] || !this.tables[table].fields[name].showIfRTE || TS.docRTE)	{
			var itemname = 'data['+table+']['+id+']['+name+']';

			if (TS.fieldHelpMode=="text" && TCA_DESCR && TCA_DESCR[table+"."+name])	{
				res+= '<tr><td colspan=3></td><td colspan=2>';
				res+='<table border=0 cellpadding=2 cellspacing=0 width=90%><tr><td valign=top width=14><a href="#" onClick="return top.viewHelp(\''+table+'.'+name+'\');"><img src="gfx/helpbubble.gif" width="14" height="14" border=0 align=absmiddle></a></td><td valign=top><font color="#666666">'+TCA_DESCR[table+"."+name]+'</font></td></tr></table>';
				res+='</td></tr>';
			}

			res+= '<tr><td></td><td align="right"><font color="#666666"><b>';
			if (this.tables[table].fields[name])	{
				res+= (altlabel || this.tables[table].fields[name].label);
				if (specConf=="button")	{
				    res+= '<A HREF="javascript:parent.shift_palette(\''+table+'\',\''+id+'\',\''+thePalette+'\');">';
					res+= '<img src="'+path+'options.gif" width=18 height=16 hspace=3 border=0 align="top">';
					res+= '</A>';
					thePalette = 0;
				}
			}
			res+='</b></font></td><td>';
			res+= '<img name="req_'+table+'_'+id+'_'+name+'" src="clear.gif" width=10 height=10><img name="cm_'+table+'_'+id+'_'+name+'" src="clear.gif" width=7 height=10>';
			res+= '</td><td colspan=2>';
			if (name == "--div--")	{
				res+= '<img src="gfx/stiblet_mini.gif" width=460 vspace=6 height=1>';
			} else if (name == "--palette--") {
			    res+= '<A HREF="javascript:parent.shift_palette(\''+table+'\',\''+id+'\',\''+thePalette+'\');">';
				res+= '<img src="'+path+'options.gif" width=18 height=16 hspace=3 border=0 align="top">';
				res+= '<B>'+altlabel+'</b>';
				res+= '</A>';
			} else {
				res+= this.tables[table].fields[name].draw(id, thePalette, ''+specConf,theType);
				if (TS.fieldHelpMode=="icon" && TCA_DESCR && TCA_DESCR[table+"."+name])	{
					res+= '<a href="#" onClick="return top.viewHelp(\''+table+'.'+name+'\');"><img src="gfx/helpbubble.gif" width="14" height="14" hspace=2 border=0 align=absmiddle></a>';
				}
			}
			res+='</td></tr>';
		}
	}
	return res;
}
function tcaTables_getRecord (table, id, RecT, minimized, tdRN)	{
		var theType = RecT;
		var theStringID = ''+id;
	color = "#cccccc";
	var res='';
	res+= '<table border=0 cellspacing=0 cellpadding=0 width='+(TS.docLarge?750:600)+'>';
	res+= '<tr><td></td><td><A HREF="#" onClick="top.funcMgr.openCM('+tdRN+', \'editMenu1\');return false;">';		
	res+= menuImages.getIconTag(data.getImage(table,id), '','',langObj.get('l_click_menu'),'');
	res+= '</A>';
	if (this.tables[table].mainpalette && !minimized)	{
		res+= '<A HREF="javascript:parent.shift_palette(\''+table+'\',\''+id+'\',\''+(TCA.palettes[table+'_'+this.tables[table].mainpalette] ? TCA.palettes[table+'_'+this.tables[table].mainpalette].num : 0)+'\');"><img src="'+path+'options.gif" width=18 height=16 hspace=3 border=0 title="'+langObj.get('l_show_options')+'" align="top"></A>';
	}
	res+= '</td><td></td>';
	res+= '<td><font color="#333366"><b>'+this.tables[table].title+'</b>'+((theStringID.indexOf('NEW')!=-1)?' <font color=red><b>'+langObj.get('l_new')+'</b></font>':' ['+id+']')+   '</font>';
	res+= ' - '+fixed_lgd(data.getLabel(table, id),40);
	res+= '</td><td>';
	res+= '<a href="javascript: parent.minimizeItem('+tdRN+');">';
	if (!minimized)	{
		res+= '<img src="gfx/minimize.gif" width=11 height=10 border=0 title="'+langObj.get('l_minimize')+'" align="top">';
	} else {
		res+= '<img src="gfx/maximize.gif" width=11 height=10 border=0 title="'+langObj.get('l_maximize')+'" align="top">';
	}
	res+= '</a>';
	res+= '<a href="javascript: parent.closeItem('+tdRN+');"><img src="gfx/close.gif" width=11 height=10 border=0 title="'+langObj.get('l_close')+'" align="top"></a>';
	res+= '</td></tr>';

	if (!minimized)	{
		if (!this.tables[table].types[theType])	{var theType=1;}
		if (this.tables[table].types[theType])	{
			var count = this.tables[table].types[theType].itemCount;
			var specConf = "";
			for (var a=0; a < count; a++) {
				specConf = (this.tables[table].types[theType].specConf[a]) ? this.tables[table].types[theType].specConf[a] : "";
				res+= '\n'+this.getField(table, id, this.tables[table].types[theType].items[a], this.tables[table].types[theType].altlabel[a], this.tables[table].types[theType].palette[a], specConf,theType);	
			}
		}
	}
	res+= '<tr><td><img src="clear.gif" width=2 height=1></td><td><img src="clear.gif" width=110 height=1></td><td><img src="clear.gif" width=17 height=1></td><td><img src="clear.gif" width='+(TS.docLarge?440+150:440)+' height=1></td><td><img src="clear.gif" width=31 height=1></td></tr>';
	res+= '\n</table>';
	return res;
}
function tcaTables_getPalette (name)	{
	color = "#cccccc";
	var res='';
	res+= '<table border=0 cellspacing=0 cellpadding=0 width=100><tr><td><img src="clear.gif" width=6 height=1></td>';
	if (!this.palettes[name])	{
		return "";
	}
	var count = this.palettes[name].itemCount;
	for (var a=0; a < count; a++) {
		field = this.palettes[name].items[a];
		table = this.palettes[name].table;
		if (!this.tables[table].fields[field])	{

		} else {
			res+= '<td nowrap valign="bottom"><nobr><b>'+ (this.palettes[name].altlabel[a] || this.tables[table].fields[field].label) +'</b>';
			res+= '<img name="req_'+table+'_'+field+'" src="clear.gif" width=10 height=10><img name="cm_'+table+'_'+field+'" src="clear.gif" width=7 height=10>';
			res+=this.tables[table].fields[field].draw('pal');		
			if (TS.fieldHelpMode && TCA_DESCR && TCA_DESCR[table+"."+field])	{
				res+= '<a href="#" onClick="return top.viewHelp(\''+table+'.'+field+'\');"><img src="gfx/helpbubble.gif" width="14" height="14" hspace=2 border=0 align=absmiddle></a>';
			}
			res+='</nobr></td>';
			if (a+1 < count)	{
				res+= '<td><img src="'+path+'spacer.gif" width=10 height=20 border="0"></td>';		
			}
		}
	}
		res+= '\n</tr></table>';
	return res;
}
function tcaTables_showPalette (targetWin, nmb, table, id)	{
	if ((this.currentPaletteNum!=nmb || this.currentPaletteID!=id) && !targetWin.loading)	{
		var number = nmb;
		if (this.currentPaletteNum > 0)	{
			var layerObj = dom_getObj('layer'+this.currentPaletteNum, targetWin.document);
			layerObj.css.visibility = "hidden";
		}	
		this.currentPaletteNum = number;
		this.currentPaletteTable = table;
		this.currentPaletteID = id;

		if (number > 0)	{
			var layerObj = dom_getObj('layer'+this.currentPaletteNum, targetWin.document);
			layerObj.css.visibility = "visible";
			var targetDoc = dom_getObj('layer'+number, targetWin.document).ref;
			var palname = this.paletteNames[number];
			var count = this.palettes[palname].itemCount;
			for (var a=0; a<count; a++)	{
				var field = this.palettes[palname].items[a];
				if (TCA.tables[table].fields[field])	{
					if (targetDoc['editform'+number])	{
						var FObj = TCA.tables[table].fields[field];
						data.setFlags(table,id,field,targetDoc);
						if (FObj.type != "check")	{
							var formfield = data.getFieldName('data',table,'pal',field);
							var element = targetDoc['editform'+number][formfield];
							if (!element)	{alert('System Error:\n\n Due to unknown causes there are no form fields in the layer in the palette! ('+formfield+')');} else {
								var value = data.get(table, id, field);
								if (FObj.type=="input" && FObj.checkbox && targetDoc['editform'+number][formfield+'_check'])	{
									if (FObj.checkboxValue == value)	{
										targetDoc['editform'+number][formfield+'_check'].checked = 0;
										value = FObj.checkboxValue;
									} else {
										targetDoc['editform'+number][formfield+'_check'].checked = 1;
									}
								}
								loadFormElement (element, evalFunc.outputObjValue(FObj,value),'',FObj.type);
							}
						} else {
							var value = data.get(table, id, field);
							for (var b=0; b<FObj.itemNum; b++)	{
								var element = targetDoc['editform'+number][data.getFieldName('data',table,'pal',field)+'_'+b];
								if (!element)	{alert('System Error:\n\n Due to unknown causes there are no form fields in the layer in the palette!');} else {
									loadFormElement (element, value&Math.pow(2,b),'',FObj.type);
								}
							}
						}
					} else {alert('System Error:\n\n An error has occurred in the palette layers. Log in again and see if that corrects the error.');}
				}
			}
		}
	}
}	


// ****************************
// ***   Editwin functions  ***
// ****************************

function form_has_changed(table,id,field,element,targetDoc)	{
	if (TCA.tables[table] && TCA.tables[table].fields[field])	{
		var FObj = TCA.tables[table].fields[field];
		var update = "";
		switch (element.type)	{
			case "select-one":
			case "select-multiple":
				var value = element.options[element.selectedIndex].value;
				update = 1;
			break;
			case "checkbox":
				var	check = (element.checked) ? 1 : 0 ;
				var modifier = Math.pow(2,element.name.substring(element.name.length-1));
				var value = and(data.get(table, id, field) , Math.pow(2,FObj.itemNum)-1);
				value = or(value,modifier);	
				value-=modifier;
				if (check)	{value = or(value,modifier);}
				update = 1;
			break;
			default:
				var value = element.value;
				if (FObj.checkbox)	{
					if (!value) value = FObj.checkboxValue
				}
				var dataVal = data.get(table, id, field);
				if (dataVal != value)	{
					if (isInCommaList(FObj.evallist,'password') && value==TS.passwordDummy)	{update=0;} else {update=1;}
				}
		}
		if (update)	{

			var valBeforeEval = value;
	
			if (element.type=="select-one" && value=="--div--")	{
				value = data.get(table, id, field);
			}
	
			if (FObj.evallist)	{
				value = evalFunc.evalObjValue(FObj,value);
				if (isInCommaList(FObj.evallist,'uniqueInPid'))	{
					runScript(TS.serverpath+"getunique.php?table="+table+"&field="+field+"&id="+id+"&value="+rawurlencode(value)+"&formRef="+escape("parent.content.document.editform")+"&uniqueInPid=1");
				}
				if (isInCommaList(FObj.evallist,'unique'))	{
					runScript(TS.serverpath+"getunique.php?table="+table+"&field="+field+"&id="+id+"&value="+rawurlencode(value)+"&formRef="+escape("parent.content.document.editform"));
				}
			}
			if (FObj.range_upper || FObj.range_lower)	{
				value = evalFunc.parseInt(value);
				if (FObj.range_upper && value>FObj.range_upper)	{value = evalFunc.parseInt(FObj.range_upper);}
				if (FObj.range_lower && value<FObj.range_lower)	{value = evalFunc.parseInt(FObj.range_lower);}
			}

			var result = parent.data.update(table, id, field, value, 'client');
			parent.data.setFlags(table, id, field, targetDoc);
			
			if (FObj.type=="input" && FObj.checkbox)	{
				var theElement = element.form[element.name+'_check'];
				if (theElement)	{
					if (FObj.checkboxValue == value)	{
						theElement.checked = 0;
						value = FObj.checkboxValue;
					} else {
						theElement.checked = 1;
					}
				}
			}

			if (value!=valBeforeEval || isInCommaList(FObj.evallist,'password'))	{
				loadFormElement (element, evalFunc.outputObjValue(FObj,value), '', TCA.tables[table].fields[field].type);
			}

			if (result == 'reload')	{
				parent.editWin.reloadContent();
			}
		}
	} else {		
		alert('System Error:\n\n The form field you just left, was not updated correctly!');
	}
}
function inputCheckBoxIsClicked(table,id,field,element,targetDoc)	{
	var FObj = TCA.tables[table].fields[field];
	if (element.checked)	{
		element.checked = 0;
	} else {
		var value = FObj.checkboxValue;

		var result = parent.data.update(table, id, field, value, 'client');
		parent.data.setFlags(table, id, field, targetDoc);

		var theFormElement = element.form[element.name.substr(0,element.name.length-6)];
		if (theFormElement)	{
			loadFormElement (theFormElement, evalFunc.outputObjValue(FObj,value), '', TCA.tables[table].fields[field].type);
		}

		if (result == 'reload')	{
			parent.editWin.reloadContent();
		}
	}
}
function group_change_fetchClip(value, pad, selectorBox, manyItems, type, allwed, disallwed, maxItems)	{
	var allowed = ','+allwed+',';
	var disallowed = ','+disallwed+',';
	var counter = 0;
	for (var i = 0; i < clipBrd.bankCount[pad]; i++) {
		var clipItem = clipBrd.bank[pad][i+1];
		if (clipItem && clipItem.uid && clipItem.act && clipItem.type == type && counter<maxItems)	{
			if (allowed.indexOf(',' + (clipItem.filetype||clipItem.table) + ',')!=-1 || ((!allwed || allwed=="*") && disallowed.indexOf(',' + (clipItem.filetype||clipItem.table) + ',')==-1))	{
				var inValue = clipItem.fullpath || clipItem.table+'_'+clipItem.uid;
				var inText = clipItem.title;
				var alreadySelected = 0;
				if (!manyItems)	{
					for (var a=0; a<selectorBox.length; a++)	{
						if (selectorBox.options[a].value == inValue)	{
							alreadySelected = 1;
						}
					}
				}
				if (!alreadySelected)	{
					counter++;
					value+=rawurlencode(inValue)+'|'+rawurlencode(inText)+',';
				}
			}
		}
	}
	return value;
}
function group_change(mode, table,id,field,element,targetDoc)	{
	var fieldObj = parent.TCA.tables[table].fields[field];
	var minItems = (fieldObj.minitems) ? fieldObj.minitems : 0;
	var maxItems = (fieldObj.maxitems) ? fieldObj.maxitems : TS.maxItemsDefault;
	var manyItems = fieldObj.multiple;	
	var internal_type = fieldObj.internal_type;
	var allowed = fieldObj.allowed;
	var disallowed = fieldObj.disallowed;
	var selectorBox = targetDoc.editform['data['+table+']['+id+']['+field+']'];
	var value = '';
	var oldSI = selectorBox.selectedIndex;
	switch(mode)	{
		case "add":	
			var pad = (!parent.clipBrd.clipboard) ? "normal" : clipBrd.pad;
			var valueSel=0;
			if (internal_type==clipBrd.bankType[pad] || clipBrd.bankType[pad] == '')	{
				for (var a=0; a<selectorBox.length; a++)	{
					value+=rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text)+',';
					if (selectorBox.options[a].selected && !valueSel)	{
						value = group_change_fetchClip(value, pad, selectorBox, manyItems, internal_type, allowed, disallowed, maxItems);
						valueSel=1;
					}
				}
				if (!valueSel)	{
					value = group_change_fetchClip(value, pad, selectorBox, manyItems, internal_type, allowed, disallowed, maxItems);
				}
				parent.data.update(table, id, field, value, 'client');
				loadGroupSelectorBox (selectorBox,value);
				if (selectorBox.length>oldSI+1) {selectorBox.selectedIndex=oldSI+1};
				if (selectorBox.length < minItems)	{
					alert(langObj.get('err_3',minItems));
				}
				if (selectorBox.length > maxItems)	{
					alert(langObj.get('err_4',maxItems));
				}
			} else {
				if (internal_type != "file")	{
					alert(langObj.get('err_5'));
				} else {
					alert(langObj.get('err_6'));
				}
			}
		break;  
		case "remove":
			for (var a=0; a<selectorBox.length; a++)	{
				if (!selectorBox.options[a].selected)	{
					value+=rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text)+',';
				}
			}
			parent.data.update(table, id, field, value, 'client');
			loadGroupSelectorBox (selectorBox,value);
			if (selectorBox.length > oldSI)	{selectorBox.selectedIndex=oldSI;}	else {selectorBox.selectedIndex=selectorBox.length-1;}
			if (selectorBox.length < minItems)	{
				alert(langObj.get('err_3',minItems));
			}
		break;	
		case "totop":
			var value_wait="";
			selItemList="";
			for (var a=selectorBox.length; a>0; a--)	{
				theItemValue = rawurlencode(selectorBox.options[a-1].value)+'|'+rawurlencode(selectorBox.options[a-1].text);
				if (!selectorBox.options[a-1].selected)	{
					value = value_wait + theItemValue+',' + value;
					value_wait="";
				} else {
					value_wait = theItemValue+',' + value_wait;
					selItemList+= theItemValue+',';
				}
			}
			if (value_wait)	{value = value_wait + value;}
			parent.data.update(table, id, field, value, 'client');
			loadGroupSelectorBox (selectorBox,value);
			for (var a=0; a<selectorBox.length; a++)	{
				theItemValue = rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text);
				selectorBox.options[a].selected = isInCommaList(selItemList,theItemValue);
			}
		break;
	}	
	parent.data.setFlags(table, id, field, targetDoc);
}
function select_group_change(mode, table,id,field,element,targetDoc)	{
	var fieldObj = parent.TCA.tables[table].fields[field];
	var minItems = (fieldObj.minitems) ? fieldObj.minitems : 0;
	var maxItems = (fieldObj.maxitems) ? fieldObj.maxitems : TS.maxItemsDefault;
	var manyItems = fieldObj.multiple;
	var selectorBox = targetDoc.editform['data['+table+']['+id+']['+field+']'];
	var value = '';
	var oldSI = selectorBox.selectedIndex;
	switch(mode)	{
		case "add":
			var inValue = element.options[element.selectedIndex].value;
			var inText = element.options[element.selectedIndex].text;
			
			var valueSel=0;
			for (var a=0; a<selectorBox.length; a++)	{
				if (!manyItems)	{
					if (selectorBox.options[a].value != inValue)	{
						value+=rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text)+',';
					}
				} else {
					value+=rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text)+',';
				}
				if (selectorBox.options[a].selected)	{
					value+=rawurlencode(inValue)+'|'+rawurlencode(inText)+',';
					valueSel=1;
				}
			}
			if (!valueSel)	{value+=rawurlencode(inValue)+'|'+rawurlencode(inText)+','}
			parent.data.update(table, id, field, value, 'client');
			loadGroupSelectorBox (selectorBox,value);
			if (selectorBox.length>oldSI+1) {selectorBox.selectedIndex=oldSI+1};
			if (selectorBox.length > maxItems)	{
				alert(langObj.get('err_4',maxItems));
			}
		break; 
		case "remove":
			for (var a=0; a<selectorBox.length; a++)	{
				if (!selectorBox.options[a].selected)	{
					value+=rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text)+',';
				}
			}
			parent.data.update(table, id, field, value, 'client');
			loadGroupSelectorBox (selectorBox,value);
			if (selectorBox.length > oldSI)	{selectorBox.selectedIndex=oldSI;}	else {selectorBox.selectedIndex=selectorBox.length-1;}
			if (selectorBox.length < minItems)	{
				alert(langObj.get('err_3',minItems));
			}
		break;	
		case "totop":
			var value_wait="";
			selItemList="";
			for (var a=selectorBox.length; a>0; a--)	{
				theItemValue = rawurlencode(selectorBox.options[a-1].value)+'|'+rawurlencode(selectorBox.options[a-1].text);
				if (!selectorBox.options[a-1].selected)	{
					value = value_wait + theItemValue+',' + value;
					value_wait="";
				} else {
					value_wait = theItemValue+',' + value_wait;
					selItemList+= theItemValue+',';
				}
			}
			if (value_wait)	{value = value_wait + value;}
			parent.data.update(table, id, field, value, 'client');
			loadGroupSelectorBox (selectorBox,value);
			for (var a=0; a<selectorBox.length; a++)	{
				theItemValue = rawurlencode(selectorBox.options[a].value)+'|'+rawurlencode(selectorBox.options[a].text);
				selectorBox.options[a].selected = isInCommaList(selItemList,theItemValue);
			}
		break;		
	}	
	parent.data.setFlags(table, id, field, targetDoc);
}
function loadGroupSelectorBox (element,value)	{
	element.length=0;
	var valnum = 0;
	valItem = parent.split(value, ',', valnum+1);
	while (valItem)	{
		element.length++;
		element.options[valnum].value = unescape(parent.split(valItem, '|', 1));
		element.options[valnum].text = unescape(parent.split(valItem, '|', 2));
		valnum++;
		valItem = parent.split(value, ',', valnum+1);
	}
	if (element.length)	{
		element.selectedIndex = 0;
	}
}
function countElementsInGroup(value)	{
	var valnum = 0;
	valItem = parent.split(value, ',', valnum+1);
	while (valItem)	{
		valnum++;
		valItem = parent.split(value, ',', valnum+1);
	}
	return valnum;
}
function isRequiredNotOK(FObj, value)	{
	if (FObj)	{
		if (FObj.evallist)	{
			return (isInCommaList(FObj.evallist,'required') && !value);
		}
		if (FObj.type=="group" || FObj.type=="select")	{
			var valCount = countElementsInGroup(value);
			var minItems = (FObj.minitems) ? FObj.minitems : 0;
			var maxItems = (FObj.maxitems) ? FObj.maxitems : TS.maxItemsDefault;
			return (valCount<minItems || valCount>maxItems);
		}
		return false;
	} else {
		return false;
	}
}
function shift_palette (table,id,palnum)	{
	if (palnum > 0)	{
		parent.TCA.showPalette (parent.palette_frame, palnum, table, id);
	} else {
		parent.TCA.showPalette (parent.palette_frame, palnum, '', 0);
	}
}
function closeItem(itemNum)	{
	shift_palette('','',0);
	var itemObj = parent.editWin.docs[parent.editWin.currentDoc].items[itemNum];
	if (itemObj && (!data.checkFieldsWithData(itemObj.table,itemObj.id,'changed') || confirm(langObj.get('mess_recIsChanged'))) )	{
		parent.editWin.docs[parent.editWin.currentDoc].removeRec(itemObj.table,itemObj.id);
		if (parent.editWin.docs[parent.editWin.currentDoc].firstItem == -1)	{
			parent.editWin.closeCur();
		}
		editWin.reloadAll();
	}
}
function minimizeItem(itemNum)	{
	shift_palette('','',0);
	var docObj = parent.editWin.docs[parent.editWin.currentDoc];
	var itemObj = docObj.items[itemNum];
	itemObj.maximized = itemObj.maximized^1; 
	if (!itemObj.maximized && itemObj.table==parent.TCA.pagesTable)	{
		var nextItem = docObj.items[itemNum].next;
		var safetyCounter=100;
		while (nextItem!=-1 && docObj.items[nextItem].table!=parent.TCA.pagesTable) {
			safetyCounter--;
			if (safetyCounter < 0)	{break;}
			docObj.items[nextItem].maximized=false;
			nextItem = docObj.items[nextItem].next;
		}
	}
	itemObj.reload();
}




// *********************************
// ***   Timeout og busycontrol  ***
// *********************************
function busy(loginTOI)	{
	this.types = new Array();
	this.types['mainmenu'] = 1;
	this.types['palettes'] =71;
	this.types['propframe'] = 1;

	this.loadState = this.types['mainmenu'] | this.types['palettes'] | this.types['propframe'];
	this.defaultState = 1;
	this.types['loginstate'] = 0;

	this.loginTOI = loginTOI;
	this.loginTOMargin = 10;
	this.checkInterval = 5;
	var date = new Date();
	var theTime = Math.floor(date.getTime()/1000);
	this.loginTO = theTime + this.loginTOI - this.loginTOMargin;

	this.currentState = this.loadState | this.defaultState | this.types['loginstate'];
			
	this.isBusy = busy_isBusy;	
	this.md5 = "";
	this.set = busy_set;	
	this.checkMD5 = busy_checkMD5;
	this.click = busy_click;	
	this.openLogin = busy_openLogin;
	this.loginRefreshed = busy_loginRefreshed;
	this.checkLoginTimeout = busy_checkLoginTimeout;
	
	this.startingUp=1;
}
function busy_checkMD5(md5)	{
	if (!this.md5)	{
		this.md5=md5;
	}
	if (this.md5 != md5)	{
		alert(langObj.get('mess_permChanges'));
	}
}
function busy_set(flag, theType)	{
	if (flag>=0)	{
		if (theType)	{
			this.types[theType] = flag;
		} else {
			this.defaultState = flag;
		}
		this.loadState = this.types['mainmenu'] | this.types['palettes'] | this.types['propframe'];
		this.currentState = this.loadState | this.defaultState | this.types['loginstate'];
	}
	
	if (bottonsFrameLoaded)	{
		if (parent.nButtons_frame && parent.nButtons_frame.document && parent.nButtons_frame.document.sys_busy)	{
			var imgType = (this.types['loginstate'])?"d":((this.currentState)?"h":"n");
			if (flag==-1) {imgType="h";}
			nButtons_frame.document.sys_busy.src = glImage.getSrc('sys_busy', imgType);
		}
	}
	if (this.startingUp && !this.isBusy())	{
		this.startingUp=0;
		parent.menuFaner.click(parent.menuFaner.current);
	}
}
function busy_isBusy(dialog,id)	{
	this.checkLoginTimeout();
	if (dialog && this.currentState)	{
		alert(langObj.get('err_7')+' ('+id+')');
	}
	return this.currentState;
}
function busy_click()	{
	if (this.types['loginstate'])	{
		this.openLogin();
	} else {
		if (this.currentState)	{
			this.set(0);
		}
		if (this.currentState)	{
			alert("System Error:\n\n This is not cleared yet: \nmainmenu: "+this.types['mainmenu']+"\npalettes: "+this.types['palettes']+"\npropframe: "+this.types['propframe']);
		}
		parent.load_frame.location = "dummy.html";
	}
}
function busy_loginRefreshed()	{
	var date = new Date();
	var theTime = Math.floor(date.getTime()/1000);
	this.loginTO = theTime + this.loginTOI - this.loginTOMargin;
	this.set (0, 'loginstate');
}
function busy_checkLoginTimeout()	{
	var date = new Date();
	var theTime = Math.floor(date.getTime()/1000);
	if (theTime > this.loginTO && !this.types['loginstate'])	{
		this.set (1, 'loginstate');
		if (confirm(langObj.get('mess_refresh_login')))	{
			this.openLogin();
		}
	}
}
function busy_openLogin()	{
	this.loginWin = window.open('login_frameset.php','loginwin'+TS.uniqueID,'height=300,width=400,status=0,menubar=0');
	this.loginWin.typoWin = parent;
}
function busy_checkLoginTimeout_timer()	{
	busy.checkLoginTimeout();
	window.setTimeout("busy_checkLoginTimeout_timer();",busy.checkInterval*1000);
}


// *******************
// ***   Language  ***
// *******************
function langVer()	{
	this.item = new Array();
	this.add = langVer_add;	
	this.get = langVer_get;
}
function langVer_add(name,value)	{
	this.item[name] = value;
}
function langVer_get(name,p1,p2,p3,p4,p5)	{
	var value = this.item[name];
	var msg = "";
	var theP = "";
	if (value)	{
		var index=1;
		var theWord = split(value, "%s", index);
		while (theWord || index==1) {
			theP = eval('p'+index);
			msg+=theWord+((theP)?theP:"");
			index++;
			theWord = split(value, "%s", index);
		}
		return msg;
	} else {
		alert('System Error:\n\n The requested message "'+name+'" did not exist!!');
		return '';
	}
}

// *******************
// ***   RollMenu  ***
// *******************
function rollMenu()		{
	this.menu = new rollMenu_menu();
	this.add = rollMenu_add;
}
function rollMenu_add(name, selfRef, elementRef, defaultFunction)	{
	this.menu[name] = new rollMenu_menu(name, selfRef, elementRef, defaultFunction);
}
function rollMenu_menu(name, selfRef, elementRef, defaultFunction)	{
	this.name = name;
	this.selfRef = selfRef;
	this.element = elementRef;
	this.defaultFunction = defaultFunction;
	
	this.item = new rollMenu_item();
	this.itemNums = new Array();
	this.itemCount = 0;

	this.aI = rollMenu_menuAddItem;
	this.select = rollMenu_select;
	this.write = rollMenu_write;
	this.update = rollMenu_update;
	this.setMode = rollMenu_setMode;
}
function rollMenu_menuAddItem(name, label, func) {
	this.itemCount++;
	this.item[this.itemCount] = new rollMenu_item(name, label,((func)?func:''));
	this.itemNums[name] = this.itemCount;
}
function rollMenu_write(formTag)	{
	var theCode = "";
	theCode+='<select name="'+this.name+'" onChange="'+this.selfRef+'.menu[\''+this.name+'\'].select(this);">';
	for (var a=1; a<=this.itemCount; a++)	{
		theCode+='<option value="'+a+'">'+this.item[a].label+'</option>';
	}
	theCode+='</select>';
	if (formTag)	{
		theCode='<form>'+theCode+'</form>';
	}
	return theCode;
}
function rollMenu_select(element)	{
	theVal = element.options[element.selectedIndex].value;
	element.selectedIndex=0;
	if (this.item[theVal] && this.item[theVal].name!='')	{
		if (this.item[theVal].func)	{
			eval(this.item[theVal].func);
		} else {
			eval(this.defaultFunction);
		}
	}
}
function rollMenu_item(name,label,func)	{
	this.name = name;
	this.label = label;
	this.func = func;
	this.enabled = 1;
}
function rollMenu_setMode(name, mode)	{
	var obj = this.item[this.itemNums[name]];
	if (obj)	{
		obj.enabled = mode;
	}
}
function rollMenu_update()	{
	if (clipBrd.clipboard)	{
		var element = eval(this.element);
		if (element)	{
			element.length=0;
			for (var a=1; a<=this.itemCount; a++)	{
				element.length++;
				if (this.item[a].enabled)	{
					element.options[element.length-1].value = a;
					element.options[element.length-1].text = this.item[a].label;
				} else {
					element.options[element.length-1].value = -1;
					element.options[element.length-1].text = '  ('+this.item[a].label+')';
				}
			}
			element.selectedIndex=0;
		}
	}
}

// *********************
// ***   thumbnails  ***
// *********************
function thumbRef()	{
	this.item = new Array();
	this.itemDir = new Array();
	this.add = thumbRef_add;
}
function thumbRef_add(key,data,folder)	{
	this.item[key] = data;
	this.itemDir[key] = folder;
}
function thumbsForDocs(value, uploadFolder, theCols)	{
	if (theCols==null || theCols<1)	{var cols = 1;} else {var cols=theCols;}
	var valnum = 0;
	var res ="";
	var valItem = parent.split(value, ',', valnum+1);
	var clipLabel = langObj.get('l_selectToClip');
	var zoomLabel = langObj.get('l_viewItem');
	var thumbFlag;
	var align;
	res+="<DIV><NOBR>";
	while (valItem)	{
		var theValue = unescape(parent.split(valItem,'|',1));
		var tmp_alttext = unescape(parent.split(valItem,'|',2));
		var alttext = ((tmp_alttext!="null") ? tmp_alttext:"");
		var theTitle = (cols>1) ? "" : alttext;

		if (theValue.indexOf('/')!=-1)	{
			var thisFilePath = theValue;
		} else {
			var thisFilePath = uploadFolder+theValue;
		}
		var thisFileType = getFileType(theValue);
		var thisIcon = (TS.fileicons[thisFileType]) ? TS.fileicons[thisFileType] : "default.gif";

		if (thisFileType && (parent.TS.image_files.indexOf(',' + thisFileType + ',')!=-1 || thisFileType=="ttf___"))	{		// Change ttf___ to ttf if you want thumbsnails for truetype fonts.
			thumbFlag=1;
			align="absmiddle";
		} else {
			thumbFlag=0;
			align="top";
		}		
		res+= '<A HREF="javascript:parent.launchView(\''+thisFilePath+'\', \'\');"><img src="gfx/zoom2.gif" width=12 height=12 border=0 align="'+align+'" title="'+zoomLabel+'"></a><A HREF="javascript:parent.clipBrd.aI(parent.clipBrd.pad, \'\', \''+MD5(thisFilePath)+'\', \'file\', unescape(\''+escape(theTitle || theValue)+'\'), \''+thisFilePath+'\', \''+thisFileType+'\', \''+thisIcon+'\',\'copy\');parent.clipBrd.update();"><img src="gfx/clipbrd.gif" width=12 height=12 border=0 title="'+clipLabel+'" align="'+align+'"></a>';
		if (thumbFlag)	{
			res+= '<img src="'+TS.serverpath+TS.thumbScript+'?dummy='+Math.random()+'&file='+rawurlencode(thisFilePath)+'" vspace=2 hspace=4 border=0 align="'+align+'" title="'+alttext+'">'+theTitle;
		} else {
			res+= '<img src="gfx/fileicons/'+thisIcon+'" vspace=2 width=18 hspace=20 height=16 border=0 align="'+align+'" title="'+alttext+'">'+theTitle;
		}
		valnum++;
		valItem = parent.split(value, ',', valnum+1);
		if (valItem && valnum%cols==0)	{
			res+="</DIV></NOBR><DIV><NOBR>";
		}
	}
	res+="</DIV></NOBR>";
	thumbsForDocs_recentImgCount = valnum;
	return res;
}


// ******************
// ***   System   ***
// ******************
	// Commands
function issueCommand (cmd,backPath)	{
	if (cmd.length < 2000)	{
		if (!parent.busy.isBusy(0,'cmd'))	{
//			alert(backPath);
			if (!backPath) {var bP="";} else {var bP=backPath;}
			//  || !TS.bP
//			alert(TS.serverpath+bP+"tce_db.php?redirect...");
			parent.load_frame.location = TS.serverpath+bP+"tce_db.php?redirect="+rawurlencode(TS.serverpath+"status.php?logid="+logid)+"&vC="+TS.veriCode+cmd;
			parent.busy.set(1);
		}
	} else {
		alert("System Error:\n\n Commandstring is longer than 2000 characters!");
	}
}
function issueFileCommand (cmd,backPath)	{
	if (cmd.length < 2000)	{
		if (!parent.busy.isBusy(0,'filecmd'))	{
			if (!backPath) {var bP="";} else {var bP=backPath;}
			//  || !TS.bP
			parent.load_frame.location = TS.serverpath+bP+"tce_file.php?"+cmd+'&vC='+TS.veriCode;
			parent.busy.set(1);
		}
	} else {
		alert("System Error:\n\n Commandstring is longer than 2000 characters!");
	}
}
function runScript (url)	{
	if (!parent.busy.isBusy(0,'script'))	{
		parent.load_frame.location = url;
		parent.busy.set(1);
	}
}

// 	Interrupt-handler
function executeStat()	{
	this.statement = "";
	this.exe = executeStat_exe;
	this.set = executeStat_set;
}
function executeStat_exe()	{
	if (this.statement)	{
		eval(this.statement);
		this.statement="";
	}
}
function executeStat_set(statement)	{
	this.statement = statement;
	window.setTimeout("top.executeStat.exe();",0);
}
function logout()	{
		var params = "";
		if (theFileTreeIsLoaded)	params+= '&dirTree='+escape(parent.fileMenu.expRec());
		if (theWebTreeIsLoaded)		params+= '&pageTree='+escape(parent.theMenu.expRec());
		parent.load_frame.location = TS.serverpath+'logout.php?sendLogoutSignal=1'+params+parent.mods.dumpPosition();
}
function closeTypo3Windows()	{
	if (clipBrd.clipboard)	{
		clipBrd.clipboard.close();
	}
	self.close();
}
function callStatus()	{
	parent.load_frame.location = TS.serverpath+"status.php?logid="+logid;
	parent.busy.set(1);
}


// ***************
// ***   Misc  ***
// ***************
function getRTEflagField(string)	{
	if (string.indexOf('rte_transform')!=-1)	{
		var partStr = string.substring(string.indexOf('rte_transform')+13);
		if (partStr.indexOf('flag=')!=-1)	{
			var fieldNamePart=partStr.substring(partStr.indexOf('flag=')+5);
			fieldNamePart=fieldNamePart.substring(0,fieldNamePart.indexOf("]"));
			if (partStr.indexOf('|')!=-1)	{
				fieldNamePart=fieldNamePart.substring(0,fieldNamePart.indexOf("|"));
			}
			fieldNamePart = evalFunc_ltrim(evalFunc_btrim(fieldNamePart));
			return fieldNamePart;
		}
	}
	return "";
}
function viewHelp(table_field)	{
	var theWin=window.open('view_help.php?tfID='+table_field,'viewHelp'+TS.uniqueID,'height=300,width=250,status=0,menubar=0,scrollbars=1');
	theWin.focus();
	return false;
}
function getWindow() {return top.window;}
function setStatus(theText) {
	var theWindow = getWindow();
	if (theWindow) {
		theWindow.status = theText;
	}
	return true;
}
function clearStatus() {
	var theWindow = getWindow();
	if (theWindow != null) {theWindow.status = '';}
}
function fixed_lgd(string,chars)	{
	var str=''+string;
	if (chars>=4 || !str)	{
		if (str.length>chars)	{
			return str.substr(0,(chars-3))+'...';
		} else {
			return str;
		}
	}
}
function fixed_lgd_pre(string,chars)	{
	var str=''+string;
	if (chars>=4 || !str)	{
		if (str.length>chars)	{
			return '...'+str.substr(str.length-chars+3);
		} else {
			return str;
		}
	}
}
function fixPath(p) {
	return (p.substring(0,2) == '/:') ? p.substring(thePath.indexOf('/', 2), p.length) : p;
}
function getParm(theStr, parm, delim) {
     if (theStr.length == 0) {return '';}
	 var sPos = theStr.indexOf(parm + "=");
     if (sPos == -1) {return '';}
     sPos = sPos + parm.length + 1;
     var ePos = theStr.indexOf(delim, sPos);
     if (ePos == -1) {ePos = theStr.length;}
     return unescape(theStr.substring(sPos, ePos));
}
function getFileType (theFileName)	{
	var valnum = 1;
	var theType = '';
	var valItem = split(theFileName, '.', valnum+1);
	while (valItem)	{
		theType = valItem;
		valnum++;
		valItem = split(theFileName, '.', valnum+1);
	}
	return theType.toLowerCase();
}
function splitKeyname (keyname, part)	{
	var valnum = 1;
	var theUID = '';
	var valItem = split(keyname, '_', valnum+1);
	while (valItem)	{
		theUID = valItem;
		valnum++;
		valItem = split(keyname, '_', valnum+1);
	}
	if (theUID)	{
		if (part=="uid")	{
			return theUID;
		} else {
			return keyname.substring(0,keyname.length-(1+theUID.length));
		}
	} else {
		return "";
	}
}
function slashJS (string)	{	
	var newString="";
	var inStr = ''+string;
	for (var a=0;a<inStr.length;a++)	{
		var theChar = inStr.substr(a,1);
		if (theChar=="'")	{theChar="\\'";}
		newString+=theChar;
	}
	return newString;
}
function rawurlencode(str)	{
	var output = escape(str);
	output = str_replace("*","%2A", output);
	output = str_replace("+","%2B", output);
	output = str_replace("/","%2F", output);
	output = str_replace("@","%40", output);
	return output;
}
function str_replace(match,replace,string)	{
	var input = ''+string;
	var matchStr = ''+match;
	if (!matchStr)	{return string;}
	var output = '';
	var pointer=0;
	var pos = input.indexOf(matchStr);
	while (pos!=-1)	{
		output+=''+input.substr(pointer, pos-pointer)+replace;
		pointer=pos+matchStr.length;
		pos = input.indexOf(match,pos+1);
	}
	output+=''+input.substr(pointer);
	return output;
}
function syncPaths(theTypo3Path,theRelPath)	{
	typo3Path = ''+theTypo3Path;
	relPath = ''+theRelPath;
	if (relPath.substr(0,1)=="/" || relPath.substr(1,1)==":")	{
		return relPath;
	} else {
		var p=relPath.substr(0,3);
		var a=typo3Path.length;
		a--;
		while(p=="../")	{
			relPath = relPath.substr(3);
			
			var theChar = typo3Path.substr(a-1,1);
			while (theChar!="/" || a<=0)	{
				a--;
				var theChar = typo3Path.substr(a-1,1);
			}
			a--;
			p=relPath.substr(0,3);
		}
		return typo3Path.substr(0,a+1)+relPath;
	}
}
function split(theStr1, delim, index) {	
	var theStr = ''+theStr1;
	var lengthOfDelim = delim.length;
	sPos = -lengthOfDelim;
	if (index<1) {index=1;}
	for (a=1; a<index; a++)	{
		sPos = theStr.indexOf(delim, sPos+lengthOfDelim);
		if (sPos==-1)	{return null;}
	}
	ePos = theStr.indexOf(delim, sPos+lengthOfDelim);
	if(ePos == -1)	{ePos = theStr.length;}	
	return (theStr.substring(sPos+lengthOfDelim,ePos));
}
function propertyFrame_writeFrame()	{
	propertyFrame.writeFrame();
}
function menuFrame_writeFrame(theDoc)	{
	theMenu.draw(theDoc);
}
function menuFrame_writeWaiting(theDoc)	{
	theDoc.writeln('<table border=0 cellpadding=2 cellspacing=10 width=180><tr><td><img src="gfx/working.gif" width=19 height=14></td><td nowrap bgColor="'+top.TS.globalBackgroundColor2+'" align="center">'+top.TS.globalFont_b+'<B>'+langObj.get('mess_gettingTree')+'</b>'+top.TS.globalFont_e+'</td></tr></table>');
}
function fileFrame_writeFrame(theDoc)	{
	fileMenu.draw(theDoc);
}
function switchDocument (theNum)	{
	var newNum = parseInt(theNum);
	if (editWin.docs[newNum])	{
		shift_palette('','',0);
		editWin.currentDoc = newNum;
		editWin.reloadAll();
	}
}
function writeCharSet (targetDoc)	{
	targetDoc.writeln(TS.charSetMeta);
}
function writeStyleSheet (targetDoc)	{
	writeCharSet(targetDoc);
	if (theBrowser.platform == "UNIX")	{
			targetDoc.writeln('<STYLE TYPE="text/css">');
			targetDoc.writeln('TD {	font-family: Sans-serif; font-size: small; color: #000000; valign: "top";  }');
			targetDoc.writeln(' A:link {text-decoration: none; color:black}  A:visited {text-decoration: none; color:black}   A:active {text-decoration: none; color:black}');
			targetDoc.writeln('</STYLE>');
	} else {
			targetDoc.writeln('<STYLE TYPE="text/css">');
			targetDoc.writeln('TD {	font-family: Verdana,Arial; font-size: 10px; color: #000000; valign: "top";  }');
			targetDoc.writeln('select  {  font-family: Verdana, Arial, Helvetica; font-size: 10px }   textarea  {  font-family: Verdana, Arial, Helvetica; font-size: 10px }    input   {  font-family: Verdana, Arial, Helvetica; font-size: 10px }');
			targetDoc.writeln(' A:link {text-decoration: none; color:black}  A:visited {text-decoration: none; color:black}   A:active {text-decoration: none; color:black}');
			targetDoc.writeln('</STYLE>');
	}
}
function reloadCurrentWin()	{
	switch (parent.menuFaner.current)	{
		case "doc":
		case "web":
		case "file":
			parent.menuFaner.click(parent.menuFaner.current);
		break;
		default:
//			debug(parent.menuFaner.current);
	}
	if (parent.menuFaner.current=="web" && parent.content.nav_frame)	{
		parent.content.nav_frame.location = "db_navframe.html";
	}
	if (parent.menuFaner.current=="file" && parent.content.nav_frame)	{
		parent.content.nav_frame.location = "file_navframe.html";
	}
}
function launchView(table,uid,bP)	{
	var backPath= bP ? bP : "";
	var thePreviewWindow="";
	thePreviewWindow = window.open(backPath+'show_item.php?table='+escape(table)+'&uid='+escape(uid),'ShowItem'+TS.uniqueID,'height=300,width=410,status=0,menubar=0,resizable=0,location=0,directories=0,scrollbars=1,toolbar=0');	
	if (thePreviewWindow && thePreviewWindow.focus)	{
		thePreviewWindow.focus();
	}
}
function launchEdit(table,uid)	{
	var params = '';
	if (TCA.tables[table] && uid)	{
		params= '&edit[' + table + '][' + uid + ']=edit&samedoc=0';
		parent.editWin.edit(params);
	}
}
function isInCommaList (theList, theVal)	{
	var theWorkList = ","+theList+",";
	return (theWorkList.indexOf(","+theVal+",")!=-1);
}
function browserInfo() {
	this.code = 'unknown';
	this.version = 0;
	this.platform = 'Win';
	this.blurOnClick = '';

	this.dom= (document.getElementById);
	this.op=  (navigator.userAgent.indexOf("Opera")>-1);
	this.ie4= (document.all && !this.dom && !this.op);
	this.ie5= (document.all && this.dom && !this.op);
	this.ns4= (document.layers && !this.dom);
	this.ns5= (!document.all && this.dom && !this.op);
	this.ns6= (this.ns5);
	this.bw=  (this.ie4 || this.ie5 || this.ns4 || this.ns6 || this.op);

	var ua = navigator.userAgent;
	var i = ua.indexOf('MSIE');
	if (i >= 0) {
		this.code = 'MSIE';
		this.blurOnClick = 'onClick="this.blur();" ';
		this.version = parseFloat(ua.substring(i+5, i+9));
	} else {
		i = ua.indexOf('Mozilla/');
	 	if (i >= 0) {
	 		this.code = 'NS';
	 		this.version = parseFloat(ua.substring(i+8, i+12));
	 	}
	}
	if (ua.indexOf('Mac') >= 0) {this.platform = 'Mac';}
	if (ua.indexOf('OS/2') >= 0) {this.platform = 'OS/2';}
	if (ua.indexOf('X11') >= 0) {this.platform = 'UNIX';}
}
function dom_getObj(obj,docRef){
	this.el= theBrowser.ie4?docRef.all[obj]:theBrowser.ns4?docRef[obj]:docRef.getElementById(obj);	
   	this.css= theBrowser.ns4?this.el:this.el.style;
	this.ref= theBrowser.ns4?this.el.document:docRef;		
	this.x= (theBrowser.ns4||theBrowser.op)?this.css.left:this.el.offsetLeft;
	this.y= (theBrowser.ns4||theBrowser.op)?this.css.top:this.el.offsetTop;
	this.height= (theBrowser.ie4||theBrowser.ie5||theBrowser.ns6)?this.el.offsetHeight:theBrowser.ns4?this.ref.height:theBrowser.op?this.css.pixelHeight:0;
	this.width= (theBrowser.ie4||theBrowser.ie5||theBrowser.ns6)?this.el.offsetWidth:theBrowser.ns4?this.ref.width:theBrowser.op?this.css.pixelWidth:0;
	return this;
}
function dom_getImg(target,name)	{
	if (target && target.document)	{
		return  target.document[name] ? target.document[name] : (target.ref ? target.ref[name] : "");
	}
}
function loadInMyFrame(theDoc, theUrl)	{
	theDoc.location = theUrl;
}
function showInFrontend(theId, backPath)	{
	var tempWin = window.open(backPath+TS.fe_script+"?"+TS.fe_uid+"="+theId, "frontend"+TS.uniqueID);
	tempWin.focus();
} 
function thumbmodeToggle()	{
	TS.thumbmode = TS.thumbmode^1;
	if (TS.thumbmode) {
		buttons['thumbmode'].state=true;
	} else {
		buttons['thumbmode'].state=false;
	}
}
function writeLines(target, content)	{
	target.writeln(content);
}
function loadTree(type)	{
	if (!busy.isBusy(1,'loadTree'))	{
		if (type=="web")	{
			var expData = parent.theMenu.count ? '&expData='+escape(parent.theMenu.expRec()) : '';
			parent.load_frame.location='load_tree.php?type='+type+expData;
			parent.theWebTreeIsLoaded=1;
			parent.busy.set(-1);
		}
		if (type=="file")	{
			var expData = parent.fileMenu.count ? '&expData='+escape(parent.fileMenu.expRec()) : '';
			parent.load_frame.location='load_tree.php?type='+type+expData;
			parent.theFileTreeIsLoaded=1;
			parent.busy.set(-1);
		}
	}
}
function debug(p1,p2,p3,p4,p5,p6,p7,p8,p9)	{
	var theMsg= p1+' | '+p2+' | '+p3+' | '+p4+' | '+p5+' | '+p6+' | '+p7+' | '+p8+' | '+p9;
	alert('*** DEBUG ***\n'+theMsg);
}
// Print properties of an object
function debugObj(obj,name)	{
	var acc;
	for (i in obj) {
		if (obj[i])	{
			acc+=i+":  "+obj[i]+"\n";
		}
	}			  
	alert("Object: "+name+"\n\n"+acc);
}



// *************************
// ***   PropertyFrame   ***
// *************************
function pFrame (defVal)	{
	this.current = defVal;
	this.wideDoc = pFrameWDoc;
	this.loadMod = pFrameLoadModule;
}
function pFrameLoadModule(fane,url,pal,cpal)	{
	this.current = fane;
	parent.propmenu.layerControl.hide();
	parent.palette_frame.layerControl.hide();
	shift_palette('','',0);
	switch(fane)	{
		case "doc":
			editWin.initFaner();
			parent.content.location = "editwin_content.html";
			parent.propmenu.layerControl.show('edit');
		break;
		case "datatest":
//			parent.content.location = 'debug_data.html';
		break;
		default:
			if (pal)	{
				parent.palette_frame.layerControl.show(pal);
			}
			if (cpal)	{
				parent.propmenu.layerControl.show(cpal);
			}
			var token = (url.indexOf('?')!=-1) ? '&' : '?';
			switch(fane)	{
				case "web":
					if (parent.content.db_list_frame)	{
						parent.content.db_list_frame.location = getModuleUrl(url + token + "id="+escape(parent.theMenu.recentuid)+"&imagemode="+TS.thumbmode);
					} else {
						parent.content.location = "db_frameset.html";
					}
				break;
				case "file":
					if (parent.content.file_list_frame)	{
						parent.content.file_list_frame.location = getModuleUrl(url + token + "id="+rawurlencode(parent.fileMenu.recentuid)+"&imagemode="+TS.thumbmode);
					} else {
						parent.content.location = "file_frameset.html";
					}
				break;
				default:
					parent.content.location = getModuleUrl(url);
			}
	}
}
function pFrameWDoc(type, url)	{
	parent.propmenu.layerControl.hide();
	parent.palette_frame.layerControl.hide();
	shift_palette('','',0);
	switch(type)	{
		case "pagestat":
			parent.content.location = url;
		break;
	}
}


// *************************
// ***   ModuleControl   ***
// *************************
function subModule(name,defaultUrl,cpal,path)	{
	this.name = name;
	this.cpal = cpal;
	this.path = path;
	this.defaultUrl = defaultUrl;
	this.currentUrl = defaultUrl;
}
function module(name,defaultUrl,pal,cpal,path,defaultSub)	{
	this.name = name;
	this.pal = pal;
	this.cpal = cpal;
	this.path = path;
	this.defaultUrl = defaultUrl;
	this.currentUrl = defaultUrl;

	this.subModules = new subModule();
	this.subModuleNames = new Array();
	this.subModuleCount = 0;
	this.currentSub = defaultSub;

	this.add = addSubModule;
}
function addSubModule(name,defaultUrl,cpal,path)	{
	this.subModuleCount++;
	this.subModuleNames[this.subModuleCount] = name;
	this.subModules[name] = new subModule (name,defaultUrl,cpal,path);
}
function modArray ()	{
	this.modules = new module('','');
	this.moduleNames = new Array();
	this.moduleCount = 0;
	
	this.add = addModule;
	this.load = loadModule;
	this.loadSub = loadSubModule;
	this.setUrl = setModuleUrl;
	this.loadFA = module_loadFA;
	this.dumpPosition = modules_dumpPosition;
}
function modules_dumpPosition()	{
	var params="";
	for (var a=1;a<=this.moduleCount;a++)	{
		if (this.moduleNames[a])	{
			var mod=this.modules[this.moduleNames[a]];
//			params+='&mod['+this.moduleNames[a]+'][currentURL]='+rawurlencode(mod.currentUrl);
			params+='&mod['+this.moduleNames[a]+'][currentSub]='+rawurlencode(mod.currentSub);
			for (var b=1;b<=mod.subModuleCount;b++)	{
			//	params+='&submod['+this.moduleNames[a]+'_'+mod.subModuleNames[b]+'][currentURL]='+rawurlencode(mod.subModules[mod.subModuleNames[b]].currentUrl);
			}
		}
	}
	return params+"&currentMenuFane="+escape(parent.menuFaner.current);
}
function addModule(name,defaultUrl,pal,cpal,path,defSub)	{
	this.moduleCount++;
	this.moduleNames[this.moduleCount] = name;
	this.modules[name] = new module (name,defaultUrl,pal,cpal,path,defSub);
}
function module_loadFA(modName)	{
	top.executeStat.set('top.mods.load(\''+modName+'\');');
}
function loadModule(modName)	{
	if (this.modules[modName])	{
		parent.menuFaner.select(modName);
		if (this.modules[modName].subModuleCount)	{
			if (!this.modules[modName].currentSub || !this.modules[modName].subModules[this.modules[modName].currentSub])	{
				if (this.modules[modName].currentUrl=="dummy.html")	{
					this.modules[modName].currentSub = this.modules[modName].subModuleNames[1];			
				} else {
					this.modules[modName].currentSub='';
				}
			}
		} else {
			this.modules[modName].currentSub='';
		}
		if (this.modules[modName].currentSub)	{
			var subMod = this.modules[modName].subModules[this.modules[modName].currentSub];
			parent['modPane_'+modName].select('modPane_'+modName+'_'+this.modules[modName].currentSub);
			parent.propertyFrame.loadMod(modName,subMod.path+subMod.currentUrl,this.modules[modName].pal,subMod.cpal);
			regModuleName(modName+"_"+subMod.name);
		} else {	// normal module
			parent.propertyFrame.loadMod(modName,this.modules[modName].path+this.modules[modName].currentUrl,this.modules[modName].pal,this.modules[modName].cpal);
			regModuleName(modName);
		}
	} else {
		alert('System Error:\n\n No module by that name');
	}
}
function loadSubModule(modName, subModName)	{
	if (this.modules[modName])	{
		if (this.modules[modName].subModules[subModName])	{
			this.modules[modName].currentSub = subModName;
			this.load(modName);
			regModuleName(modName+"_"+subModName);
		} else {
			alert('System Error:\n\n No submodule by that name');
		}
	} else {
		alert('System Error:\n\n No module by that name');
	}
}
function setModuleUrl(modName,url)	{
	if (this.modules[modName])	{
		if (url)	{
			this.modules[modName].currentUrl = url;
		} else {
			this.modules[modName].currentUrl = this.modules[modName].defaultUrl;
		}
	} else {
		alert('System Error:\n\n No module by that name');
	}
}
var currentModuleLoaded = '';
function regModuleName(modName)	{
//	alert(modName);
	currentModuleLoaded = modName;
}




var nextLoadModuleUrl="";
function getModuleUrl(inUrl)	{
	var nMU;
	if (top.nextLoadModuleUrl)	{
		nMU=top.nextLoadModuleUrl;
		top.nextLoadModuleUrl="";
		return nMU;
	} else {
		return inUrl;
	}
}
function loadTopMenu(url)	{
	// dummy;
	return false;
}

