<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * New database item menu
 *
 * This script lets users choose a new database element to create. 
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 
$BACK_PATH="";
include ("init.php");
include ("template.php");
include("lang/LL_misc.php");

// ***************************
// Functions
// ***************************
include_once(PATH_t3lib."class.t3lib_page.php");
include_once(PATH_t3lib."class.t3lib_positionmap.php");
include_once(PATH_t3lib."class.t3lib_pagetree.php");




// ***************************
// Script Classes
// ***************************
class localPageTree extends t3lib_pageTree {
	function wrapIcon($icon,$row)	{
		return substr($icon,0,-1).' title="id='.htmlspecialchars($row["uid"]).'">';
	}
	function expandNext($id)	{
		return $id==$GLOBALS["SOBE"]->id ? 1 : 0;
	}
}
class SC_db_new {
	var $pageinfo;
	var $pidInfo;
	var $newPagesInto;
	var $newContentInto;
	var $newPagesAfter;
	var $web_list_modTSconfig;
	var $allowedNewTables;
	var $web_list_modTSconfig_pid;
	var $allowedNewTables_pid;
	var $code;
	var $R_URI;
	var $content;
	var $perms_clause;
	var $code;	
	var $id;
	var $doc;	

		// Constructor:
	function init()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		$this->perms_clause = $BE_USER->getPagePermsClause(1);
		$this->id = intval(t3lib_div::GPvar("id"));
		$AB=1;	// For the sake of the link to list-module
		
		$this->doc = t3lib_div::makeInstance("smallDoc");
		$this->doc->backPath = $BACK_PATH;
		$this->doc->JScode='';
		
		// ***************************
		// Creating content
		// ***************************
		$this->content="";
		$this->content.=$this->doc->startPage($LANG->php3Lang["db_new.php"]["pagetitle"]);
		$this->content.=$this->doc->header($LANG->php3Lang["db_new.php"]["pagetitle"]);
		$this->content.=$this->doc->spacer(5);
		
		if ($this->id)	{
			$this->pageinfo = t3lib_BEfunc::readPageAccess($this->id,$this->perms_clause);
		}
		
		if ($this->pageinfo["uid"])	{
			$this->pidInfo=t3lib_BEfunc::getRecord("pages",$this->pageinfo["pid"]);
			if ($BE_USER->doesUserHaveAccess($this->pageinfo,8))	{	
				$this->newPagesInto=1;
			}
			if ($BE_USER->doesUserHaveAccess($this->pageinfo,16))	{
				$this->newContentInto=1;
			}
		
			if (($BE_USER->isAdmin()||is_array($this->pidInfo)) && $BE_USER->doesUserHaveAccess($this->pidInfo,8))	{
				$this->newPagesAfter=1;
			}
		} elseif ($BE_USER->isAdmin())	{
			$this->newPagesInto=1;
			$this->newContentInto=1;
			$this->newPagesAfter=0;
		} else {
			$this->newPagesInto=0;
			$this->newContentInto=0;
			$this->newPagesAfter=0;
		}
	}
	function main()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		if ($this->pageinfo["uid"] || $BE_USER->user["admin"])	{
			$this->web_list_modTSconfig = t3lib_BEfunc::getModTSconfig($this->pageinfo["uid"],"mod.web_list");
			$this->allowedNewTables = t3lib_div::trimExplode(",",$this->web_list_modTSconfig["properties"]["allowedNewTables"],1);
		
			$this->web_list_modTSconfig_pid = t3lib_BEfunc::getModTSconfig($this->pageinfo["pid"],"mod.web_list");
			$this->allowedNewTables_pid = t3lib_div::trimExplode(",",$this->web_list_modTSconfig_pid["properties"]["allowedNewTables"],1);
		
			if (!$this->showNewRecLink("pages"))	{
				$this->newPagesInto=0;
			}
			if (!$this->showNewRecLink("pages",$this->allowedNewTables_pid))	{
				$this->newPagesAfter=0;
			}
		
		
		
			$this->code=$this->doc->getHeader("pages",$this->pageinfo,$this->pageinfo["_thePath"])."<BR>";
			$this->R_URI=t3lib_div::GPvar("returnUrl");
		
			if ($BE_USER->uc["edit_showFieldHelp"])	{
				$TCA_DESCR=t3lib_BEfunc::loadTablesDescriptions($LANG->lang!="default"?$LANG->lang:"");
				t3lib_BEfunc::loadSingleTableDescription("pages",$LANG->lang);
			}
		
			if (!t3lib_div::GPvar("pagesOnly"))	{	// Regular:
				$this->regularNew();
			} elseif ($this->showNewRecLink("pages")) {	// Pages only:
				$this->pagesOnly();
			}
		
			if ($this->R_URI)	{
				$this->code.='<BR><a href="'.$this->R_URI.'"><img src="gfx/goback.gif" width="14" height="14" hspace="2" border="0" align="top"><strong>'.$LANG->getLL("goBack").'</strong></a>';
			}
			$this->content.=$this->doc->section('',$this->code);
		}
	}
	function pagesOnly()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		$posMap = t3lib_div::makeInstance("t3lib_positionMap");
		$this->code.="<BR><strong>".$LANG->getLL("selectPosition").":</strong><BR><BR>";
		$this->code.= $posMap->positionTree($this->id,$this->pageinfo,$this->perms_clause,$this->R_URI);
	}
	function regularNew()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		$this->code.='<img src="'.$BACK_PATH.'t3lib/gfx/ol/halfline.gif" width=18 height=8 align="top"><BR>';
	
		// New pages INSIDE this pages
		if ($this->newPagesInto && $this->isTableAllowedForThisPage($this->pageinfo, "pages") && $BE_USER->check("tables_modify","pages"))	{
			$t="pages";
			$v=$TCA[$t];
			$this->code.=$this->linkWrap('<img src="'.$BACK_PATH.'t3lib/gfx/ol/join.gif" width=18 height=16 align="top" border=0><img src="'.$BACK_PATH.'gfx/i/'.($v["ctrl"]["iconfile"] ? $v["ctrl"]["iconfile"] : $t.".gif").'" width=18 height=16 align="top" border=0> '.$LANG->sL($v["ctrl"]["title"]).' ('.$LANG->php3Lang["db_new.php"]["inside"].')',$t,$this->id);
			if (isset($TCA_DESCR[$t]["columns"][""]))	{
				$this->code.='<a href="#" onClick="vHWin=window.open(\'view_help.php?tfID='.$t.'.\',\'viewFieldHelp\',\'height=300,width=250,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="gfx/helpbubble.gif" width="14" height="14" hspace=4 border=0 align=absmiddle'.$this->doc->helpStyle().'></a>';
			}
			$this->code.='<BR>';

			$this->code.='<img src="gfx/ol/line.gif" width="18" height="16" border="0" align=top><img src="gfx/ol/joinbottom.gif" width="18" height="16" border="0" align=top><a href="'.t3lib_div::linkThisScript(array("pagesOnly"=>1)).'"><img src="gfx/new_page.gif" width="13" height="12" border="0" align=top> '.$LANG->getLL("clickForWizard").'</a><BR>';
			$this->code.='<img src="gfx/ol/halfline.gif" width="18" height="8" border="0" align=top><BR>';
		}
		// New tables (but not pages) INSIDE this pages
		if ($this->newContentInto)	{
			if (is_array($TCA))	{
				reset($TCA);
				while(list($t,$v)=each($TCA))	{
					if ($t!="pages" 
							&& $this->showNewRecLink($t)
							&& $this->isTableAllowedForThisPage($this->pageinfo, $t) 
							&& $BE_USER->check("tables_modify",$t) 
							&& (($v["ctrl"]["rootLevel"] xor $this->id) || $v["ctrl"]["rootLevel"]==-1)
							)	{

						$this->code.=$this->linkWrap('<img src="'.$BACK_PATH.'t3lib/gfx/ol/join.gif" width=18 height=16 align="top" border=0><img src="'.$BACK_PATH.t3lib_iconWorks::getIcon($t).'" width=18 height=16 align="top" border=0> '.$LANG->sL($v["ctrl"]["title"]),$t,$this->id);

						if ($BE_USER->uc["edit_showFieldHelp"])	{
							t3lib_BEfunc::loadSingleTableDescription($t,$LANG->lang);
							if (isset($TCA_DESCR[$t]["columns"][""]))	{
								$this->code.='<a href="#" onClick="vHWin=window.open(\'view_help.php?tfID='.$t.'.\',\'viewFieldHelp\',\'height=300,width=250,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="gfx/helpbubble.gif" width="14" height="14" hspace=4 border=0 align=absmiddle'.$this->doc->helpStyle().'></a>';
							}
						}
						
						$this->code.='<BR>';
						if ($t=="tt_content")	{
							$this->code.='<img src="gfx/ol/line.gif" width="18" height="16" border="0" align=top><img src="gfx/ol/joinbottom.gif" width="18" height="16" border="0" align=top><a href="db_new_content_el.php?id='.$this->id.'&returnUrl='.rawurlencode($this->R_URI).'"><img src="gfx/new_record.gif" width="16" height="12" border="0" align=top> '.$LANG->getLL("clickForWizard").'</a><BR>';
							$this->code.='<img src="gfx/ol/halfline.gif" width="18" height="8" border="0" align=top><BR>';
						}
					}
				}
			}
		}
		// New pages AFTER this pages
		if ($this->newPagesAfter && $this->isTableAllowedForThisPage($this->pidInfo,"pages") && $BE_USER->check("tables_modify","pages"))	{
			$t="pages";
			$v=$TCA[$t];
			$this->code.=$this->linkWrap('<img src="'.$BACK_PATH.t3lib_iconWorks::getIcon($t).'" width=18 height=16 align="top" border=0> '.$LANG->sL($v["ctrl"]["title"]).' ('.$LANG->php3Lang["db_new.php"]["after"].')',"pages",-$this->id);
			if (isset($TCA_DESCR[$t]["columns"][""]))	{
				$this->code.='<a href="#" onClick="vHWin=window.open(\'view_help.php?tfID='.$t.'.\',\'viewFieldHelp\',\'height=300,width=250,status=0,menubar=0,scrollbars=1\');vHWin.focus();return false;"><img src="gfx/helpbubble.gif" width="14" height="14" hspace=4 border=0 align=absmiddle'.$this->doc->helpStyle().'></a>';
			}
			$this->code.='<BR>';
		} else {
			$this->code.='<img src="'.$BACK_PATH.'t3lib/gfx/ol/stopper.gif" width=18 height=16 align="top"><BR>';
		}
		
		if ($this->showNewRecLink("pages"))	{
			$this->code.='<BR><a href="'.t3lib_div::linkThisScript(array("pagesOnly"=>"1")).'"><img src="gfx/new_page.gif" width="13" height="12" border="0" align=top><img src=clear.gif width=3 height=1 align=top border=0><strong>'.$LANG->getLL("createNewPage").'</strong></a><BR>';
		}
	}
	function printContent()	{
		global $SOBE,$AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA;

		// Ending / Outputting
		// ***************************
		$this->content.= $this->doc->middle();
		$this->content.= $this->doc->endPage();
		echo $this->content;
	}


	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
	function linkWrap($code,$table,$pid)	{
		$params = '&edit['.$table.']['.$pid.']=new'.
			($table=="pages" && $GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"] && substr(t3lib_BEfunc::editOnClick("","",""),0,17)!="document.location"	?
				'&edit['.$GLOBALS["TYPO3_CONF_VARS"]["SYS"]["contentTable"].'][prev]=new&returnNewPageId=1'	:
				''
			);
		return '<a href="#" onClick="'.t3lib_BEfunc::editOnClick($params,"",t3lib_div::GPvar("returnUrl")).'">'.$code.'</a>';
	}
	function isTableAllowedForThisPage($pid_row, $checkTable)	{
		global $TCA, $PAGES_TYPES;
		if (!is_array($pid_row))	{
			if ($GLOBALS["BE_USER"]->user["admin"])	{
				return true;
			} else {
				return false;
			}
		}
		if ($checkTable=="be_users" || $checkTable=="be_groups")	{	// be_users and be_groups may not be created anywhere but in the root.
			return false;
		}
		$doktype = intval($pid_row["doktype"]);
		if (!$allowedTableList = $PAGES_TYPES[$doktype]["allowedTables"])	{
			$allowedTableList = $PAGES_TYPES["default"]["allowedTables"];
		}
		if (strstr($allowedTableList,"*") || t3lib_div::inList($allowedTableList,$checkTable))	{		// If all tables or the table is listed as a allowed type, return true
			return true;
		}
	}
	function showNewRecLink($table,$allowedNewTables="")	{
		$allowedNewTables = is_array($allowedNewTables) ? $allowedNewTables : $GLOBALS["allowedNewTables"];
		return !count($allowedNewTables) || in_array($table,$allowedNewTables);
	}
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/db_new.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/db_new.php"]);
}







// Make instance:
$SOBE = t3lib_div::makeInstance("SC_db_new");
$SOBE->init();
$SOBE->main();
$SOBE->printContent();

?>