<?php
/***************************************************************
*  Copyright notice
*  
*  (c) 1999-2002 Kasper Sk�rh�j (kasper@typo3.com)
*  All rights reserved
*
*  This script is part of the Typo3 project. The Typo3 project is 
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
* 
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license 
*  from the author is found in LICENSE.txt distributed with these scripts.
*
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/** 
 * TCE (Typo Core Engine) for file-handling.
 *
 * This script serves as the fileadministration part of the Typo Core Engine 
 * Basically it includes two libraries which are used to manipulate files on the server.
 *
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

/*

Please read the comments to include_once(PATH_t3lib."class.t3lib_basicfilefunc.php") and include_once(PATH_t3lib."class.t3lib_extfilefunc.php")
if you want to take a look at the configuration possibilities

Operations is written to the log-table


SYNTAX:
Submit values in a multidimensional array ($this->file) this way:

$this->file[operation][index][key]

operation can be one of these:  delete,copy,move,rename,newfolder,upload,unzip
index is just a counter. Use whatever value you like. This provides the ability to perform many alike operations in one submission
key is dependent on the operation. See this list:

___delete___:
file[delete][0][data]:		Absolute path to the file/folder to delete

___copy___:
file[copy][0][data]:		Absolute path to the file/folder to copy
file[copy][0][target]:		Absolute path to the folder to copy to (destination)
file[copy][0][altName]:		(boolean): If set, another filename is found (by appending numbers/unique-string) in case the target already exists.

___move___:
(exactly like copy, just replace the word "copy" with "move")

___newfolder___:
file[newfolder][0][data]:		Foldername, max 30 characters alphanum
file[newfolder][0][target]:		Absolute path to the folder where to create it

___rename___:
file[rename][0][data]:			New name, max 30 characters alphanum
file[rename][0][target]:		Absolute path to the target file/folder

___upload___:
file[upload][0][data]:			ID-number (points to the global var that holds the filename-ref  ($GLOBALS["HTTP_POST_FILES"]["upload_".$id]["name"])
file[upload][0][target]:		Absolute path to the target folder (destination)
upload_$id						Filereference. $id must equal value of file[upload][0][data]!

___unzip___:
file[unzip][0][data]:			Absolute path to the zip-file. (fileextension must be "zip")
file[unzip][0][target]:			The absolute path to the target folder (destination)	(if not set, default is the same as the zip-file)


****************************************************************/


include("init.php");
include("template.php");

include_once(PATH_t3lib."class.t3lib_basicfilefunc.php");
include_once(PATH_t3lib."class.t3lib_extfilefunc.php");


// ***************************
// Script Classes
// ***************************
class SC_tce_file {
	var $include_once=array();
	var $CB;
	var $file;
	var $redirect;
	
	function init()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		// ***************************
		// Registering Incoming data
		// ***************************
		$this->file = t3lib_div::GPvar("file");
		$this->redirect = t3lib_div::GPvar("redirect");
//		t3lib_div::setGPvars("file,redirect");

		$this->CB = t3lib_div::GPvar("CB");
		if (is_array($this->CB))	{
			$this->include_once[]=PATH_t3lib."class.t3lib_clipboard.php";
		}
	}
	function initClipboard()	{
		if (is_array($this->CB))	{
			$clipObj = t3lib_div::makeInstance("t3lib_clipboard");
			$clipObj->initializeClipboard();
			if ($this->CB["paste"])	{
				$clipObj->setCurrentPad($this->CB["pad"]);
				$this->file = $clipObj->makePasteCmdArray_file($this->CB["paste"],$this->file);
			}
			if ($this->CB["delete"])	{
				$clipObj->setCurrentPad($this->CB["pad"]);
				$this->file = $clipObj->makeDeleteCmdArray_file($this->file);
			}
		}
	}
	function main()	{
		global $AB,$BE_USER,$LANG,$BACK_PATH,$TCA_DESCR,$TCA,$HTTP_GET_VARS,$HTTP_POST_VARS,$CLIENT,$TYPO3_CONF_VARS;
		global $FILEMOUNTS;
		
		// *********************************
		// Initializing
		// *********************************
		$fileProcessor = t3lib_div::makeInstance("t3lib_extFileFunctions");
		$fileProcessor->init($FILEMOUNTS, $TYPO3_CONF_VARS["BE"]["fileExtensions"]);
		$fileProcessor->init_actionPerms($BE_USER->user["fileoper_perms"]);
		$fileProcessor->dontCheckForUnique = t3lib_div::GPvar("overwriteExistingFiles") ? 1 : 0;
		
		// ***************************
		// Checking referer / executing
		// ***************************
		$refInfo=parse_url(getenv("HTTP_REFERER"));
		list($httpHost) = explode(":",getenv("HTTP_HOST"));
		if ($httpHost!=$refInfo["host"] && t3lib_div::GPvar("vC")!=$BE_USER->veriCode() && !$TYPO3_CONF_VARS["SYS"]["doNotCheckReferer"])	{
			$fileProcessor->writeLog(0,2,1,"Referer host '%s' and server host '%s' did not match!",array($refInfo["host"],$httpHost));
		} else {
			$fileProcessor->start($this->file);
			$fileProcessor->processData();
		}
		
		if (!$this->redirect)	{
			$this->redirect = "status_file.php";
		}
	}
	function finish()	{
		// ***************************
		// Redirecting
		// ***************************
		Header("Location: ".$this->redirect);
		echo '
		<script language="javascript">
			if (confirm(\'System Error:\n\n Some error happend in tce_file.php. Continue?\'))	{
				document.location = \''.$this->redirect.'\';
			}
		</script>
		';
	}
	
	// ***************************
	// OTHER FUNCTIONS:	
	// ***************************
}

// Include extension?
if (defined("TYPO3_MODE") && $TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/tce_file.php"])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]["XCLASS"]["typo3/tce_file.php"]);
}












// Make instance:
$SOBE = t3lib_div::makeInstance("SC_tce_file");
$SOBE->init();

// Include files?
reset($SOBE->include_once);	
while(list(,$INC_FILE)=each($SOBE->include_once))	{include_once($INC_FILE);}

$SOBE->initClipboard();
$SOBE->main();
$SOBE->finish();
?>