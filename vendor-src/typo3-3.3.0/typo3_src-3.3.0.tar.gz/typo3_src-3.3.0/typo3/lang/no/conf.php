<?php
		// Url to norwegian manual
	$typo3_help_url= "http://www.typo3.com/man_dk/";

		// Mainlang in norwegian. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"view" => "Vis",
			"edit" => "Redig�r",
			"new" => "Ny",
			"copy" => "Kopier",
			"cut" => "Klipp ut",
			"pasteinto" => "Lim inn",
			"pasteafter" => "Lim inn etter",
			"select" => "Velg",
			"deselect" => "Fravelg",
			"selectto" => "Velg her til",
			"deselectto" => "Fravelg her til",
			"delete" => "Slett",
			"upload" => "Last opp filer",
			"rename" => "Nytt navn",
			"open" => "�pne",
			"save" => "Lagre",
			"unzip" => "Pakk opp",
			"info" => "Info",
			"createnew" => "Opprett ny",
			"hide" => 'Skjul',
			"unhide" => 'Vis',
		),
		"buttons" => Array (
			"clipboard" => "Klippebord",
			"logout" => "Avslutt",
			"clear" => "T�m"
		),
		"labels" => Array (
		// Tabs
			"webtabs" => "Sidetre #",
			"filetabs" => "Katalog Tre #",
		// Buttons
			"logout" => "Husk alltid � avlutte Typo3 med denne knappen!",
			"selectmode" => "Velg emner med et enkelt klikk",
			"thumbmode" => "Vis miniatyrer",
			"thumbmode_clip" => "Vis miniatyrer p� klippebordet",
			"copymode" => "Kopier emner i stedet for � flytte dem",
			"refresh" => "Gjeninnles treet fra serveren",
			"clearClip" => "Fjern undervalgte emner fra klippebordet",
		// ClipBoard
			"clipNormal" => "Standard klippebord",
			"filelist" => "N�v�rende fil-listing",
			"dblist" => "N�v�rende record-listing",
			"clip" => "Klippebordet inneholder dine valgte emner",
			"cliptabs" => "Klippebord #",
			"removeItem" => "Fjern emne",
			"inverseSelection" => "Inverter markeringen",
			"selectAll" => "Velg alle",
			"selectNone" => "Velg ingen",
		// Document-tab
			"selected" => "Valgte",
			"items" => "Emner",
			"prevDoc" => "Forrige dokument",
			"nextDoc" => "Neste dokument",
			"click_menu" => "Klikk for meny",
			"show_options" => "Vis generelle valg",
			"remove_selected" => "Fjern valgte emner fra listen",
			"import_clip" => "Overf�r emner fra klippebordet",
			"move_to_top" => "Flytt det valgte emne til toppen",
			"upload_files" => "Last opp filer via klippebordet",
			"minimize" => "Minimer",
			"maximize" => 'Maksimer',
			"browse_file" => 'Finn filer',
			"browse_db" => 'Finn database elementer',
			"upload" => 'Last opp fil',
			"close" => "Lukk",
			"selectToClip" => "Legg emner opp p� klippebordet",
			"viewItem" => "Vis emne",
			"new" => 'NY',
			"editItem" => "Rediger emne",
			"clipNormal2" => 'Normal',
			"clipNoEl" => 'Ingen elementer',
			"generalOptions" => 'Generelle valg:',
			"allTables" => '[Alle tabeller]',
			"moreOptions" => 'Flere valg...',
			"noMatchingValue" => 'N�v�rende verdi er ikke tilgjengelig (%s)',
		),
		"mess" => Array (
			"recIsChanged" => 'Denne record er endret.\nVil du likevel lukke den?',
			"docIsChanged" => 'Dokumentet "%s" er endret.\nVil du likevel lukke det?',
			"unzip" => 'Er du sikker p�, at du vil pakke opp arkivet "%s"?',
			"delete" => 'Er du sikker p�, at du vil slette "%s"?',
			"permChanges" => 'Der er blitt endret p� dine rettigheter.\nDu b�r lukke og �pne Typo3 p� nytt for at oppdatere interfacen med endrigene!',
			"gettingTree" => 'Henter treet fra serveren<BR>Venligst vent...',
			"move_into" => 'Flytt "%s" inn i "%s"?',
			"move_after" => 'Flytt "%s" til posisjonen etter "%s"?',
			"copy_into" => 'Kopier "%s" inn i "%s"?',
			"copy_after" => 'Kopier "%s" til posisjonen etter "%s"?',
			"copycb_into" => 'Kopier alle elementer (%s) fra klippebordet inn i "%s"?',
			"copycb_after" => 'Kopier alle elementer (%s) fra klippebordet til posisjonen etter "%s"?',
			"movecb_into" => 'Flytt alle elementer (%s) fra klippebordet inn i "%s"?',
			"movecb_after" => 'Flytt alle elementer (%s) fra klippebordet til posisjonen etter "%s"?',
			"refresh_login" => 'Din login er utl�pt.\nVil du fornye den n�?',
			"miss_field" => 'De f�lgende felter er ikke utfylt korrekt:\n',
			"miss_field_in_doc" => 'Dokumentet "%s" inneholder felter, som ikke er utfylt korrekt:%s\n\nDet er ikke lagret noe!',
			"deleteClip" => 'Er du sikker p� at du vil slette ALLE valgte elementer (%s) p� klippebordet?',
			"closeTypo" => 'Vil du virkelig forlate Typo3?',
			"onChangeAlert" => 'Denne endringen vil p�virke hvilke felter som er tilgjengelige i skjemaet.\n�nsker du � lagre n� for � oppfriske skjermbildet?',
		),
		"rm" => Array (
			"menu" => "[meny]",
			"saveDoc" => "Lagre dokumentet",
			"saveAllDocs" => "Lagre alle dokumenter",
			"closeDoc" => "Lukk dokument",
			"closeAllDocs" => "Lukk alle dokumenter",
			"clearCache_pages" => "T�m sidecachen",
			"clearCache_all" => "T�m hele cachen",
			"edit" => "Rediger",
			"saveDocShow" => 'Lagre dokumentet og vis siden',
			"saveCloseDoc" => 'Lagre og lukk dokumentet',
			"saveCloseAllDocs" => 'Lagre og lukk alle dokumenter',
			"viewDoc" => 'Vis dokument',
			"delete" => 'Slett',
			"upload" =>  "Last opp filer",
			"saveNewDoc" => 'Lagre dokumentet og opprett et nytt',
			"clearCache_clearCache" => 'T�m cache',
			"clearCache_thisPage" => 'Denne siden',
		),
		"err" => Array (
			"1" => "Du m� lagre emnet for at du kan f� sett siden!",
			"2" => "Denne record er blitt fjernet fra hukommelsen. Gjeninnles listen.",
			"3" => "Det skal vere minst %s emne(r) i listen!",
			"4" => "Legg ikke til flere enn %s emne(r)",
			"5" => "Innholdet fra klippebordet kan ikke settes inn. Det skal v�re records fra databasen!",
			"6" => "Innholdet fra klippebordet kan ikke settes inn. Det skal vere filer fra serveren!",
			"7" => "Systemet er opptatt - vennligst vent. Hvis ikke systemet blir tilgjengelig i l�pet av kort tid, s� start Typo p� nytt",
			"8" => "Du kan ikke lagre en ny record, som er tilknyttet en annen ny record!"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(
			"path" => "Sti",
			"upOneLevel" => "Et niv� opp",
			"reload" => "Oppdater",
			"clear_cache" => "T�m cachen for denne side",
			"no_title" => "Ingen tittel",
			"cancel" => "Avbryt",
			"hidden" => "Skjult",
			"starttime" => "Start",
			"endtime" => "Slutt",
			"minutesHoursDaysYears" => "min| timer| dager| �r",
			"enterSearchString" => "Sett inn s�keord:",
			"enterSearchLevels" => "Denne side|1 niv� ned|2 niv�er ned|3 niv�er ned|4 niv�er ned",
			"noEditPermission" => "Beklager, men du hadde ikke rettigheter til � utf�re denne endringen.",
			"fieldsMissing" => "Enkelte felter er ikke korrekt utfylt. Feltene er markert med et gult utropstegn.",
			"_CONTROL_" => "Kontroll",
			"_PATH_" => "Sti",
			"setFields" => "Sett felter",
			"search" => "S�k",
			"author" => "Forfatter:",
			"note" => "Kommentar:",
			"category" => "Kategori:",
			"csv" => "Last ned CSV fil",
			"menu" => "Meny:",
			"showPage" => "Vis webside",
			"days" => "dager",
			"openInNewWindow" => "�pne i nytt vindu",
			"goBack" => "G� tilbake",
			"makeShortcut" => "Lag en snarvei til denne siden?",
			"lockedRecord" => "Brukeren '%s' startet redigeringen av dette elementet %s siden.",
			"lockedRecord_content" => "Brukeren '%s' startet redigeringen av innholdet p� denne side %s siden.",
			"showRecords" => "Vis elementer",
			"fieldsChanged" => "Det er endringer som ikke er lagret i feltene! Vil du likevel fortsette?",
			"showPalettes" => "Vis sekund�re muligheter (paletter)",
			"showDescriptions" => "Vis feltbeskrivelser",
			"disableRTE" => "Ikke bruk 'Rik tekst editor' (RTE)",
			"showList" => "Vis elementliste",
		),
		"show_item.php" => Array(
			"viewItem" => "Vis emner",
			"file" => "Fil",
			"dimensions" => "Dimensjoner",
			"filesize" => "St�rrelse",
			"ftp_area" => "FTP OMR�DE"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nytt element",
			"after" => "etter",
			"inside" => "inn i"
		),
		"file_edit.php" => Array (
			"pagetitle" => "Rediger",
			"submit" => "Lagre",
			"saveAndClose" => "Lagre og lukk",
			"coundNot" => "Denne filtypen kan ikke redigeres. Filen m� v�re av typen: <b>%s</B>",
		),
		"file_upload.php" => Array(
			"pagetitle" => "Send filer",
			"submit" => "Send filer",
			"files" => "filer"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Bytt navn",
			"submit" => "Bytt navn"
		),
		"file_newfolder.php" => Array(
			"newfile_submit" => "Opprett fil",
			"newfile" => "Ny tekstfil",
			"pagetitle" => "Ny katalog",
			"submit" => "Opprett kataloger",
			"folders" => "kataloger"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Feil under opplasting av filsti!",
			"warning" => 'Det ble ikke funnet noen sti til opplastning av bilder. Du m� opprette en katalog, TEMP ("_temp_") i roten av et av dine fildrev f�rst!',
		),
		"mess" => Array(
			"redraw" => "Gjeninnlesning av siden vil annullere de aktuelle valg. Vil du fortsette?",
			"start_typo3" => 'Vil du starte Typo3 standard interface med det samme? \n(Det tar et minutt eller to)',
			"close_login" => "Du har sansynligvis ikke bruk for dette skjermbilde lengre, med mindre du enn� ikke har startet Typo3, s� kan du lukke dette vinduet."
		)
	);
	



?>