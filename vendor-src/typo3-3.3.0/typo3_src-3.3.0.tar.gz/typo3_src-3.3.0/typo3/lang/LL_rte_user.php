<?php
$LOCAL_LANG = Array (
	"default" => Array (
		"noTitle" => "No title",
		"expand" => "Expand category",
		"noTextSelection" => "Error: There was no selected text to wrap.",
		"pixels" => "Pixels",
		"filesize" => "Filesize",
	),
	"dk" => Array (
		"noTitle" => "Ingen titel",
		"expand" => "Fold kategorien ud",
		"noTextSelection" => "Fejl: Du har ikke valgt nogen del af tekst til bearbejdelse.",
		"pixels" => "Pixler",
		"filesize" => "Filstr.",
	),
	"de" => Array (
		"noTitle" => "Kein Titel",
		"expand" => "Kategorie erweitern",
		"noTextSelection" => "Fehler: Kein Text zum Umbrechen ausgew�hlt.",
		"pixels" => "Bildpunkte",
		"filesize" => "Dateigr��e",
	),
	"no" => Array (
		"noTitle" => "Ingen tittel",
		"expand" => "Fold ut kategorien",
		"noTextSelection" => "Feil: Du har ikke valgt noen del av teksten til � bearbeide.",
		"pixels" => "Piksler",
		"filesize" => "Filstr.",
	),
	"it" => Array (
	),
	"pl" => Array (
		"noTitle" => "Brak tytu�u",
		"expand" => "Rozwi� kategori�",
		"noTextSelection" => "B��d: nie wybrano tekstu",
		"pixels" => "Pikseli",
		"filesize" => "Rozmiar pliku",
	),
	"fr" => Array (
	),
	"es" => Array (
	),
	"nl" => Array (
		"noTitle" => "Geen titel",
		"expand" => "Uitvouwen categorie",
		"noTextSelection" => "Fout: Er is geen tekst geselecteerd!",
		"pixels" => "Pixels",
		"filesize" => "Bestandsgrootte",
	),
	"fi" => Array (
		"noTitle" => "Ei otsikkoa",
		"expand" => "Laajenna luokkaa",
		"noTextSelection" => "Virhe: ",
		"pixels" => "Pixelej�",
		"filesize" => "Tiedoston koko",
	),
	"tr" => Array (
		"noTitle" => "Ba�l�k yok",
		"expand" => "Kategoriyi geni�let",
		"noTextSelection" => "Hata: Metin paketlemesi i�in se�ili metin bulunmamaktad�r.",
		"pixels" => "Pikseller",
		"filesize" => "Dosya ebat�",
	)
);
?>