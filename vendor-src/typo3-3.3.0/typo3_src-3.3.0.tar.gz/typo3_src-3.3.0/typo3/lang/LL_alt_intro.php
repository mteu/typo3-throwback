<?php
$LOCAL_LANG = Array (
	"default" => Array (
		"introtext" => "Typo%s<BR>Web Content Management System",
		"introtext2" => "This is a brief description of the available modules:",
		"endText" => "Features may vary depending on your website and permissions",
		"userInfo" => "<font size=1>You're logged in as user: <strong>%s</strong> (%s)<br></font>"
	),
	"dk" => Array (
		"introtext" => "Typo%s<BR>Web Content Management System",
		"introtext2" => "Dette er en kort beskrivelse af de tilg�ngelige moduler:",
		"endText" => "Adgang til faciliteterne kan variere afh�ngigt af dit website og dine rettigheder.",
		"userInfo" => "Du er logget ind som bruger: <strong>%s</strong> (%s)"
	),
	"de" => Array (
		"introtext" => "Typo%s<BR>Web Content Managment System",
		"introtext2" => "Dies ist eine kurze Beschreibung der vorhandenen Module:",
		"endText" => "Eigenschaften k�nnen abh�ngig von Ihrer Webseite und Ihren Zugriffsrechten variieren.",
		"userInfo" => "Sie sind angemeldet als: <strong>%s</strong> (%s)",
	),
	"no" => Array (
		"introtext" => " Typo%s<BR>Web Content Management System",
		"introtext2" => "Dette er en kort beskrivelse av de tilgjengelige modulene:",
		"endText" => "Adgang til fasiliteter kan variere avhengig av ditt webomr�de og dine rettigheter.",
		"userInfo" => "Du er logget inn som bruker: <strong>%s</strong> (%s)",
	),
	"it" => Array (
		"introtext" => "Typo%s<BR>Web Content Management System",
		"introtext2" => "Breve descrizione dei moduli disponibili:",
		"endText" => "Le caratteristiche possono variare a seconda del sito web e dei permessi",
		"userInfo" => "<font size=1>Hai avuto accesso come utente: <strong>%s</strong> (%s)<br></font>",
	),
	"fr" => Array (
		"introtext" => "Typo%s<BR>Web Content Management System",
		"introtext2" => "Voil� une br�ve description des modules disponibles:",
		"endText" => "Les fonctions peuvent varier selon votre h�b�ergeur et vos permissions.",
		"userInfo" => "Vous �tes identifi� en temps que : <strong>%s</strong> (%s)",
	),
	"pl" => Array (
		"introtext" => "Typo%s<BR>System Zarz�dzania Tre�ci� Web",
		"introtext2" => "To jest kr�tki opis dost�pnych modu��w:",
		"endText" => "Funkcjonalno�� mo�e si� r�ni� w zale�no�ci od uprawnie�",
		"userInfo" => "Jeste� zalogowany jako: <strong>%s</strong> (%s)<br>",
	),
	"es" => Array (
		"introtext" => "Typo%s<BR>Web Content Management System<BR>Sistema de Administraci�n de Contenido",
		"introtext2" => "Esta es una descripc��n corta de los m�dulos disponibles:",
		"endText" => "Las caracter�sticas pueden variar dependiendo de su website y permisos",
		"userInfo" => "<font size=1>Est� firmado como el usuario: <strong>%s</strong> (%s)<br></font>",
	),
	"nl" => Array (
		"introtext" => "Typo%s<BR>Web Content Management Systeem",
		"introtext2" => "Dit is een korte omschrijving van de aanwezige modules:",
		"endText" => "De aanwezigheid van onderdelen hangt van je website en de rechten af.",
		"userInfo" => "<font size=1>Je bent ingelogd als gebruiker: <strong>%s</strong> (%s)<br></font>",
	),
	"cz" => Array (
		"introtext" => "Typo%s<BR>syst�m pro spr�vu obsahu webu",
		"introtext2" => "Toto jsou kr�tk� popisy dostupn�ch modul�:",
		"endText" => "Vlastnosti se mohou m�nit podle va�eho website a p��stupov�ch pr�v",
		"userInfo" => "<font size=1>Jste zalogov�n jako u�ivatel: <strong>%s</strong> (%s)<br></font>",
	),
	"si" => Array (
		"introtext" => "Typo%s<br>sistem za urejanje spletne vsebine",
		"introtext2" => "To je kratek opis modulov, ki so na voljo",
		"endText" => "Mo�nosti se lahko razlikujejo glede na va�o verzijo in privilegije",
		"userInfo" => "<font size=1>Prijavljeni ste kot uporabnik: <strong>%s</strong> (%s)<br></font>",
	),
	"fi" => Array (
		"introtext" => "Typo%s<BR>Web Content Management System",
		"introtext2" => "T�m� on lyhyt kuvaus k�ytt�vist� moduleista",
		"endText" => "Mahdollisuudet voivat olla riippuvaisia asennuksesta ja k�ytt�ymp�rist�st�",
		"userInfo" => "<font size=1>Olet sis��nkirjoittautunut k�ytt�j�n�: <strong>%s</strong> (%s)<br></font>",
	),
	"tr" => Array (
		"introtext" => "Typo%s<BR>Web ��eri�i Y�netim Sistemi",
		"introtext2" => "Bu mevcut mod�llerin tan�t�m�n�n �zetidir:",
		"endText" => "�zellikler websitenize ve izinlerinize de�i�ik bir �ekilde ba�lan�yor olabilir",
		"userInfo" => "<font size=1>Kullan�c� olarak giri� yapt�n�z: <strong>%s</strong> (%s)<br></font>",
	)
);
?>