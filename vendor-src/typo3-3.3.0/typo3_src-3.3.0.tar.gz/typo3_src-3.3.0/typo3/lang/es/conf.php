<?php

		// Mainlang in spanish. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"view" => "Ver",
			"edit" => "Editar",
			"new" => "Nuevo",
			"copy" => "Copiar",
			"cut" => "Cortar",
			"pasteinto" => "Pegar en",
			"pasteafter" => "Pegar luego de",
			"select" => "Seleccionar",
			"deselect" => "Deseleccionar",
			"selectto" => "Selecciona a",
			"deselectto" => "Deselecciona a",
			"delete" => "Borrar",
			"upload" => "Enviar archivos",
			"rename" => "Cambiar nombre",
			"open" => "Abrir",
			"save" => "Guardar",
			"createnew" => "Crear nuevo",
			"unzip" => 'Unzip',
			"info" => 'Info'
		),
		"buttons" => Array (
			"clipboard" => "Portapapeles",
			"logout" => "Salir",
			"clear" => "Limpiar"
		),
		"labels" => Array (
		// Tabs
			"webtabs" => "Arbol de P�ginas #",
			"filetabs" => "Arbol de Directorios #",
		// Buttons
			"logout" => "�Siempre salga en lugar de cerrar la ventana!",
			"selectmode" => "Seleccionar los elementos con un solo click",
			"thumbmode" => "Ver miniaturas",
			"thumbmode_clip" => "Ver miniaturas en el portapales",
			"copymode" => "Copiar elementos en lugar de moverlos",
			"refresh" => "Refresca el �rbol desde el servidor",
			"clearClip" => "Retirar los elementos seleccionados del portapapeles",
		// ClipBoard
			"clipNormal" => "Portapapeles Est�ndard",
			"filelist" => "Lista de archivos actuales",
			"dblist" => "Lista de registros actuales",
			"clip" => "El Portapales contiene los elementos seleccionados",
			"cliptabs" => "Portapapeles #",
			"removeItem" => "Borrar elemento",
			"inverseSelection" => "Invertir la selecci�n",
			"selectAll" => "Selecciona todos",
			"selectNone" => "Seleccionar ninguno",
		// Document-tab
			"selected" => "Seleccionados",
			"items" => "Elementos",
			"prevDoc" => "Documento anterior",
			"nextDoc" => "Siguiente documento",
			"click_menu" => "Dele click para ver el men�",
			"show_options" => "Mostrar opciones generales",
			"remove_selected" => "Remueve elementos seleccionados",
			"import_clip" => "Importar del Portapapeles",
			"move_to_top" => "Mover el elemento seleccionado hacia arriba",
			"upload_files" => "Env�ar archivos",
			"minimize" => "Minimizar",
			"maximize" => "Maximizar",
			"close" => "Cerrar",
			"selectToClip" => "Selecciona elemento para el Portapapeles",
			"viewItem" => "Ver elemento",
			"new" => "NUEVO",
			"editItem" => "Editar elemento",
			"browse_file" => 'Lista de archivos',
			"browse_db" => 'Lista de registros',
			"upload" => 'Subir archivo'
		),
		"mess" => Array (
			"recIsChanged" => 'El registro ha cambiado.\n�A�n as� lo desea cerrar?',
			"docIsChanged" => 'El documento "%s" ha cambiado.\n�A�n as� lo desea cerrar?',
			"unzip" => '�Desea descomprimir el ZIP "%s"?',
			"delete" => '�Seguro que desea borrar "%s"?',
			"deleteClip" => '�Seguro que desea borrar TODOS los elementos (%s) del Portapapeles?',
			"permChanges" => 'Han habido cambios en sus permisos. Deber�a de cerrar y abrir nuevamente Typo3 para que vea reflejados los cambios',
			"gettingTree" => 'Extrayendo el �rbol del servidor<BR>Espere un momento...',
			"move_into" => '�Desea mover "%s" dentro de "%s"?',
			"move_after" => '�Desea mover "%s" luego de "%s"?',
			"copy_into" => '�Desea copiar "%s" dentro de "%s"?',
			"copy_after" => '�Desea copiar "%s" luego de "%s"?',
			"copycb_into" => '�Desea copiar todos los elementos (%s) del portapapeles dentro de "%s"?',
			"copycb_after" => '�Desea copiar todos los elementos (%s) del portapapeles luego de "%s"?',
			"movecb_into" => '�Desea mover todos los elementos (%s) del portapapeles dentro de "%s"?',
			"movecb_after" => '�Desea mover todos los elementos (%s) del portapapeles luego de "%s"?',
			"refresh_login" => 'Su conexi�n probablemente ya expir�.\n�Desea renovarla?',
			"miss_field" => 'Los siguientes campos no fueron llenados adecuadamente:\n',
			"miss_field_in_doc" => 'El documento "%s" contiene campos llenados incorretamente: %s\n\n�No se guard� nada!',
			"closeTypo" => '�Desea salir de Typo3?'
		),
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Guardar documento",
			"saveAllDocs" => "Guardar todos los documentos",
			"closeDoc" => "Cerrar documento",
			"closeAllDocs" => "Cerrar todos los documentos",
			"clearCache_pages" => "Borra el cach� de la p�gina",
			"clearCache_all" => "Borra todo el cach�",
			"edit" => "Editar",
			"delete" => "Borrar",
			"upload" =>  "Enviar archivo",
			"saveDocShow" => 'Guardar documento y ver p�gina',
			"saveCloseDoc" => 'Guardar y cerrar documento',
			"saveCloseAllDocs" => 'Guardar y cerrar todos los documentos',
			"viewDoc" => 'Ver documento'
		),
		"err" => Array (
			"1" => "�Debe de guardar el registro antes de ver la p�gina!",
			"2" => "Este registro ha sido eliminado de la memoria. Cargue la lista nuevamente",
			"3" => "�Deben de estar al menos %s elemento(s) en el grupo!",
			"4" => "No agregue mas de %s elemento(s)",
			"5" => "No fue posible agregar el contenido del portapapeles. �Deben de ser registros de la base de datos!",
			"6" => "No fue posible agregar el contenido del portapapeles. �Deben de ser archivos � carpetas!",
			"7" => "El sistema est� ocupado - Por favor espere un momento. Si el sistema no est� listo en un corto peri�do tal vez tendr� que reiniciar Typo",
			"8" => "�No puede guardar guardar un registro nuevo que a su vez depende de otro registro nuevo"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(
			"path" => "Ruta",
			"upOneLevel" => "Subir un nivel",
			"reload" => "Recargar",
			"clear_cache" => "Borrar el cach� de esta p�gina",
			"no_title" => "Sin t�tulo",
			"cancel" => "Cancelar",
			"hidden" => "Oculto",
			"starttime" => "Inicio",
			"endtime" => "Final",
			"viewItem" => "Ver elemento",
			"minutesHoursDaysYears" => "min| horas| d�as| A�os",
			"days" => "d�as",
			"enterSearchString" => "Buscar:",
			"enterSearchLevels" => "Esta p�gina|Bajar un nivel|Bajar 2 niveles|Bajar 3 niveles|Bajar 4 niveles",
			"noEditPermission" => "Lo lamento, no tiene los permisos necesarios para hacer este cambio.",
			"fieldsMissing" => "Hay campos en la forma que no est�n llenados correctamente. Los campos est�n marcados con un signo de admiraci�n amarillo.",
			"_CONTROL_" => "Control",
			"_PATH_" => "Ruta",
			"setFields" => "Especificar campos",
			"search" => "Buscar",
			"author" => "Autor:",
			"note" => "Nota:",
			"category" => "Categor�a:",
			"csv" => "Descargar archivo CSV",
			"menu" => "Menu:",
			"showPage" => "Ver p�gina"
		),
		"show_item.php" => Array(
			"viewItem" => "Ver elemento",
			"file" => "Archivo",
			"dimensions" => "Dimensiones",
			"filesize" => "Tama�o del archivo",
			"ftp_area" => "AREA FTP"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nuevo registro",
			"after" => "desp�es",
			"inside" => "dentro"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Env�a archivos",
			"submit" => "Env�a archivos",
			"files" => "archivos"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Cambiar nombre",
			"submit" => "Cambiar"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Nueva carpeta",
			"submit" => "Crear carpeta",
			"folders" => "carpetas",
			"newfile_submit" => "Crear archivo",
			"newfile" => "Crear nuevo archivo de texto"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Error en la ruta de env�o",
			"warning" => 'No se encontr� ninguna carpeta de env�o. Debe crear una carpeta TEMP ("_temp_") en la ra�z de alguno de sus discos montados'
		),
		"file_edit.php" => Array(
			"pagetitle" => "Editar",
			"submit" => "Guardar",
			"saveAndClose" => "Guardar y Cerrar",
			"coundNot" => "Este tipo de archivo no puede ser editado<p>El archivo debe de tener una extensi�n como:<p>%s"
		),
		"mess" => Array(
			"redraw" => "El redesplegado de la p�gina descartar� la informaci�n actual. �Desea continuar?",
			"start_typo3" => '�Desear�a iniciar la interfase est�ndard de Typo3? \n(Puede tardar un par de minutos)',
			"close_login" => "Probablemente ya no necesite esta ventana, a menos que a�n no halla inciado Typo3 puede cerrarla."
		)
	);

	
	
?>
