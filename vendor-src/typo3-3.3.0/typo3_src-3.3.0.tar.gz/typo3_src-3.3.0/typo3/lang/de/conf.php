<?php
		// Url to german manual
	$typo3_help_url= "";

		// Mainlang in german. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"view" => "Ansehen",
			"edit" => "Bearbeiten",
			"new" => "Neu",
			"copy" => "Kopieren",
			"cut" => "Ausschneiden",
			"pasteinto" => "Einf�gen in",
			"pasteafter" => "Einf�gen nach",
			"select" => "Ausw�hlen",
			"deselect" => "Auswahl aufheben",
			"selectto" => "Ausw�hlen bis",
			"deselectto" => "Ausw. bis aufheben",
			"delete" => "L�schen",
			"upload" => "Datei-Upload",
			"rename" => "Umbenennen",
			"open" => "�ffnen",
			"save" => "Sichern",
			"unzip" => "Unzip",
			"info" => "Info",
			"createnew" => "Neu anlegen",
			"hide" => 'Ausblenden',
			"unhide" => 'Einblenden',
		),
		"buttons" => Array (
	        "clipboard" => "Klemmbrett",
			"logout" => "Logout",
			"clear" => "L�schen"
		),
		"labels" => Array (
			"generalOptions" => 'Allgemeine Optionen:',
			"moreOptions" => 'Weitere Optionen...',
			"noMatchingValue" => 'AKTUELLER WERT IST NICHT VERF�GBAR (%s)',
		// Tabs
			"webtabs" => "Seiten Baum #",
			"filetabs" => "Ordner Baum #",
		// Buttons
			"logout" => "Bitte immer ausloggen anstatt das Browserfenster zu schlie�en!",
			"selectmode" => "Objekte mit Einfachklick ausw�hlen",
			"thumbmode" => "Zeige Vorschaubilder",
			"thumbmode_clip" => "Zeige Vorschaubilder im Klemmbrett",
			"copymode" => "Kopiere Objekte statt zu Verschieben",
			"refresh" => "Die Ansicht erneuern (Reload)",
			"clearClip" => "Ausgew�hlte Objekte vom Klemmbrett l�schen",
		// Klemmbrett
			"clipNormal2" => 'Normal',
			"clipNoEl" => 'Keine Elemente',
			"clipNormal" => "Standard Klemmbrett",
			"filelist" => "Aktuelle Dateiliste",
			"dblist" => "Aktuelle Datensatzliste",
			"clip" => "Das Klemmbrett enth�lt die ausgew�hlten Objekte",
			"cliptabs" => "Klemmbrett #",
			"removeItem" => "Objekt l�schen",
			"inverseSelection" => "Auswahl umkehren",
			"selectAll" => "Alle ausw�hlen",
			"selectNone" => "Nichts ausw�hlen",
		// Document-tab
			"selected" => "Ausgew�hlt",
			"items" => "Objekte",
			"prevDoc" => "Voriges Dokument",
			"nextDoc" => "N�chstes Dokument",
			"click_menu" => "Klick f�r Men�",
			"show_options" => "Zeige allgemeine Einstellungen",
			"remove_selected" => "Ausgew�hltes Objekt l�schen",
			"import_clip" => "Objekte vom Klemmbrett holen",
			"move_to_top" => "Objekt zum Anfang verschieben",
			"upload_files" => "Upload von Dateien ins Klemmbrett",
			"browse_file" => 'Durch Dateien browsen',
			"browse_db" => 'Durch Datens�tze browsen',
			"minimize" => "Minimieren",
			"maximize" => "Maximieren",
			"close" => "Schliessen",
			"selectToClip" => "Select item to Klemmbrett",
			"viewItem" => "Objekt ansehen",
	        "new" => "NEU",
			"upload" => 'Datei hochladen',
			"editItem" => "Objekt bearbeiten",
			"allTables" => '[Alle Tabellen]',
		),
	// This is messages and comfirmations.
	// %s will be substituted by some variable from the context when shown. 
		"mess" => Array (
			"onChangeAlert" => 'Diese �nderung beeinflusst die zur Verf�gung stehenden Eingabefelder.\nWollen Sie gemachte �nderunge nsichern und die Anzeige aktualisieren?',
			"recIsChanged" => 'Dieser Datensatz wurde ge�ndert.\nWollen Sie ihn wirklich schliessen?',
			"docIsChanged" => 'Das Dokument "%s" wurde ge�ndert.\nWollen Sie es wirklich schliessen?',
			"unzip" => 'Wollen Sie das ZIP-Archiv "%s" entpacken?',
			"delete" => 'Soll "%s" wirklich gel�scht werden?',
			"permChanges" => 'Ihre Rechte wurden ge�ndert.\nBitte Schliessen Sie Typo3 und loggen Sie sich neu ein!',
	        "gettingTree" => 'Daten werden vom<BR>Server geholt.<BR>Bitte warten...',
			"move_into" => 'Verschiebe "%s" into "%s"?',
			"move_after" => 'Verschiebe "%s" to after "%s"?',
			"copy_into" => 'Kopiere "%s" into "%s"?',
			"copy_after" => 'Kopiere "%s" to after "%s"?',
			"copycb_into" => 'Kopiere alle Objekte (%s) vom Klemmbrett into "%s"?',
			"copycb_after" => 'Kopiere alle Objekte (%s) vom Klemmbrett to the position after "%s"?',
			"movecb_into" => 'Verschiebe alle Objekte (%s) vom Klemmbrett into "%s"?',
			"movecb_after" => 'Verschiebe alle Objekte (%s) vom Klemmbrett to the position after "%s"?',
			"refresh_login" => 'Ihr Login ist vorraussichtlich abgelaufen. \nWollen Sie sich neu einloggen?',
			"miss_field" => 'Folgende Felder sind nicht richtig ausgef�llt:\n',
			"miss_field_in_doc" => 'Das Dokument "%s" enth�lt ung�ltig gef�llte Felder:%s\n\nDokument wurde nicht gespeichert!',
			"deleteClip" => 'Sollen alle markierten Elemente (%s) vom Klemmbrett entfernt werden?',
			"closeTypo" => 'Wollen Sie Typo3 wirklich verlassen?'
		),
	// Roll menus
		"rm" => Array (
			"menu" => "[Men�]",
			"clearCache_clearCache" => 'Cache l�schen',
			"clearCache_thisPage" => 'Diese Seite',
			"saveDoc" => "Dokument sichern",
			"saveAllDocs" => "Alle Dokumente sichern",
			"closeDoc" => "Dokument schliessen",
			"closeAllDocs" => "Alle Dokumente schliessen",
			"clearCache_pages" => "Seiten-Cache l�schen",
			"clearCache_all" => "Alle Caches l�schen",
			"edit" => "Bearbeiten",
			"saveDocShow" => 'Dokument sichern und Webseite anzeigen',
			"saveCloseDoc" => 'Dokument sichern und schliessen',
			"saveCloseAllDocs" => 'Alle Dokumente sichern und schliessen',
			"viewDoc" => 'Dokument anzeigen',
			"delete" => 'L�schen',
			"upload" =>  "Datei-Upload",
			"saveNewDoc" => 'Dokument sichern und neues anlegen',
		),
	// Error-messages
		"err" => Array (
			"1" => "Der Datensatz muss erst gespeichert werden um Ihn ansehen zu k�nnen!",
			"2" => "Dieser Datensatz ist nicht mehr im Speicher. Reload.",
			"3" => "%s Objekt(e) m�ssen mindestens in dieser Gruppe sein!",
			"4" => "Nicht mehr als %s Objekt(e) m�glich",
			"5" => "Der Inhalt des Klemmbretts kann nicht eingef�gt werden. Es m�ssen Datens�tze aus der Datenbank sein!",
			"6" => "Der Inhalt des Klemmbretts kann nicht eingef�gt werden. Es m�ssen Dateien oder Ordner sein!",
			"7" => "Das System arbeitet - Einen Moment bitte. Falls das System nicht bald verf�gbar ist, bitte Typo3 neu starten.",
			"8" => "You cannot save a new Datensatz that is attached to another new Datensatz!"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(		// general
			"path" => "Pfad",
			"upOneLevel" => "Eine Ebene h�her gehen",
			"reload" => "Neu Laden",
			"clear_cache" => "Cache f�r diese Seite l�schen",
			"no_title" => "Kein Titel",
			"cancel" => "Abbrechen",
			"hidden" => "Versteckt",
			"starttime" => "Start",
			"endtime" => "Ende",
			"enterSearchString" => "Suchbegriff:",
			"enterSearchLevels" => "Diese Seite|Inkl. 1 Ebene|Inkl. 2 Ebenen|Inkl. 3 Ebenen|Inkl. 4 Ebenen",
			"noEditPermission" => "Sie haben nicht die n�tigen Rechte, um diese �nderung durchzuf�hren.",
			"fieldsMissing" => "Einige Felder in diesem Formular wurden nicht korrekt ausgef�llt. Diese Felder sind mit einer gelben ... markiert.",
			"_CONTROL_" => "Control",
			"_PATH_" => "Pfad",
			"setFields" => "Felder setzen",
			"search" => "Suchen",
			"author" => "Autor:",
			"note" => "Notiz:",
			"category" => "Kategorie:",
			"csv" => "CSV Datei herunterladen",
			"minutesHoursDaysYears" => " Min | Std | Tage | Jahre",
			"menu" => "Men�:",
			"showPage" => "Webseite anzeigen",
			"days" => "Tage",
			"goBack" => "Zur�ck",
			"makeShortcut" => "Erzeuge einen Verweis auf diese Seite?",
			"lockedRecord" => "Der Benutzer '%s' hat mit der Bearbeitung dieses Datensatzes vor %s begonnen.",
			"lockedRecord_content" => "Der Benutzer '%s' hat mit der Bearbeitung dieses Seite vor %s begonnen.",
			"showRecords" => "Datens�tze anzeigen",
			"fieldsChanged" => "Es existieren nicht gespeicherte �nderungen in diesem Formular! Wollen Sie fortfahren?",
			"showPalettes" => "Zweite Optionspalette anzeigen",
			"disableRTE" => "Schalte Rich Text Editor (RTE) ab",
			"openInNewWindow" => "In neuem Fenster �ffnen",
			"showDescriptions" => "Feldbeschreibung anzeigen",
			"showList" => "Datensatzliste anzeigen",
		),
		"show_item.php" => Array(
			"viewItem" => "Element anzeigen",
			"file" => "Datei",
			"dimensions" => "Ausma�e",
			"filesize" => "Datei-Gr�sse",
			"ftp_area" => "FTP BEREICH",
		),
		"db_new.php" => Array(
			"pagetitle" => "Neuer Datensatz",
			"after" => "nach",
			"inside" => "in"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Datei-Upload",
			"submit" => "Upload",
			"files" => "Dateien"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Bearbeiten",
			"submit" => "Sichern",
			"saveAndClose" => "Sichern und Schliessen",
			"coundNot" => "Dieser Dateityp kann nicht bearbeitet werden. Folgende Dateitypen werden unterst�tzt: %s"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Umbenennen",
			"submit" => "Umbenennen"
		),
		"file_newfolder.php" => Array(
			"newfile_submit" => "Datei erzeugen",
			"newfile" => "Textdatei erzeugen",
			"pagetitle" => "Neuer Ordner",
			"submit" => "Ordner anlegen",
			"folders" => "Ordner"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Upload Pfad Fehler",
			"warning" => 'Kein Upload-Ordner gefunden. Sie sollten einen TEMP-Ordner in einem Ihrer Hauptverzeichnissen anlegen ("_temp_")!'
		),
		"mess" => Array(
			"redraw" => "Durch das Neuzeichnen der Seite gehen die aktuellen Daten verloren. Wollen Sie den Vorgang fortf�hren?",
			"close_login" => "Sofern Sie sich schon bei Typo3 eingeloggt haben, ben�tigen Sie dieses Fenster vermutlich nicht mehr. Sie k�nnen es bei Bedarf schliessen.",
			"start_typo3" => 'M�chten Sie Typo3 mit der Standard Benutzeroberfl�che starten?\n(Dies kann einige Zeit dauern)',
		)
	);


?>