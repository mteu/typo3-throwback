<?php
		// Url to dutch manual
	$typo3_help_url= "";

		// Mainlang in italian. This is overlayed on the default $mainLang

	$mainLang = Array (
		"cm" => Array (
			"view" => 'Toon',
			"edit" => 'Bewerken',
			"new" => 'Nieuw',
			"copy" => 'Kopi�ren',
			"cut" => 'Knippen',
			"pasteinto" => 'Plakken in',
			"pasteafter" => 'Plakken na',
			"select" => 'Selecteren',
			"deselect" => 'Deselecteren',
			"selectto" => 'Selecteren naar',
			"deselectto" => 'Deselecteren naar',
			"delete" => 'Verwijderen',
			"upload" => 'Uploaden bestanden',
			"rename" => 'Hernoemen',
			"open" => 'Open',
			"save" => 'Opslaan',
			"unzip" => 'Uitpakken',
			"info" => 'Info',
			"createnew" => 'Maak nieuwe',
			"hide" => 'Verberg',
			"unhide" => 'Toon',
		),
		"buttons" => Array (
			"clipboard" => 'Klembord',
			"logout" => 'Log uit',
			"clear" => 'Wis'
		),
		"labels" => Array (
			"clipNormal2" => 'Normaal',
			"clipNoEl" => 'Geen elementen',
			"generalOptions" => 'Algemene opties:',
			"webtabs" => 'Paginastructuur #',
			"filetabs" => 'Mapstructuur #',
			"logout" => 'Log altijd uit in plaats van het venster te sluiten!',
			"selectmode" => 'Selecteer item met enkele klik',
			"thumbmode" => 'Toon mini-afbeelding',
			"thumbmode_clip" => 'Toon mini-afbeelding op klembord',
			"copymode" => 'Kopieer items inplaats van verplaatsen',
			"refresh" => 'Herlaad de sitestructuur vanaf de server',
			"clearClip" => 'Wis geselecteerde elementen van het klembord',
			"clipNormal" => 'Standaard klembord',
			"filelist" => 'Huidige bestandslijst',
			"dblist" => 'Huidige databaselijst',
			"clip" => 'Het klembord bevat je geselecteerde item',
			"cliptabs" => 'Klembord #',
			"removeItem" => 'Verwijder item',
			"inverseSelection" => 'Inverse selectie',
			"selectAll" => 'Selecteer alles',
			"selectNone" => 'Selecteer niets',
			"selected" => 'Geselecteerde',
			"items" => 'Items',
			"prevDoc" => 'Vorige document',
			"nextDoc" => 'Volgende document',
			"click_menu" => 'Klik voor menu',
			"show_options" => 'Toon algemene opties',
			"remove_selected" => 'Verwijder geselecteerde items',
			"import_clip" => 'Verplaats items van het klembord',
			"move_to_top" => 'Verplaats geselecteerd item stap naar boven',
			"upload_files" => 'Upload bestanden naar klembord',
			"minimize" => 'Minimalizeren',
			"maximize" => 'Maximalizeren',
			"close" => 'Sluiten',
			"selectToClip" => 'Selecteer item naar het klembord',
			"viewItem" => 'Toon item',
			"new" => 'NIEUW',
			"browse_file" => 'Zoeken naar bestanden',
			"browse_db" => 'Zoeken naar records',
			"upload" => 'Upload bestand',			
			"editItem" => 'Bewerk item',
			"moreOptions" => 'Meer opties....',
			"noMatchingValue" => 'HUIDIGE WAARDE IS NIET BESCHIKBAAR (%s)',
			"allTables" => '[Alle tabellen]',
		),
		"mess" => Array (
			"gettingTree" => 'Opbouwen van de sitestructuur op de server. Even wachten...',
			"recIsChanged" => 'Dit record is gewijzigd.\nWilt je het nog steeds sluiten?',
			"docIsChanged" => 'Het document "%s" is gewijzigd.\nWilt je het nog steeds sluiten?',
			"unzip" => 'Weet je zeker, dat je het archief "%s" uit wilt pakken?',
			"delete" => 'Weet je zeker, dat je "%s" wilt verwijderen?',
			"deleteClip" => 'Weet je zeker, dat je alle elementen (%s) wilt verwijderen van het klembord?',
			"permChanges" => 'Je rechten zijn gewijzigd!\nJe dient Typo3 te sluiten en opnieuw starten om het resultaat van je wijzigingen te zien!',
			"move_into" => 'Verplaats "%s" in "%s"?',
			"move_after" => 'Verplaats "%s" na "%s"?',
			"copy_into" => 'Kopieer "%s" in "%s"?',
			"copy_after" => 'Kopieer "%s" na "%s"?',
			"copycb_into" => 'Kopieer alle elementen (%s) van het klembord in "%s"?',
			"copycb_after" => 'Kopieer alle elementen (%s) van het klembord naar de positie na "%s"?',
			"movecb_into" => 'Verplaats alle elementen (%s) van het klembord in "%s"?',
			"movecb_after" => 'Verplaats alle elementen (%s) van het klembord naar de positie na "%s"?',
			"refresh_login" => 'Je login is waarschijnlijk verlopen.\nWilt je nu opnieuw inloggen?',
			"miss_field" => 'De volgende velden zijn niet correct ingevuld:\n',
			"miss_field_in_doc" => 'Het document "%s" bevat velden die niet correct zijn ingevuld:%s\n\nEr is niets opgeslagen!',
			"onChangeAlert" => 'Deze wijziging is van invloed op de beschikbare velden.\nWil je nu opslaan om de bijbehorende velden te tonen?',
		),
		"rm" => Array (
			"clearCache_clearCache" => 'Cache legen',
			"clearCache_thisPage" => 'Deze pagina',
			"saveDocShow" => 'Sla document op en toon pagina',
			"saveCloseDoc" => 'Sla document op en sluit pagina',
			"saveCloseAllDocs" => 'Sla documenten op en sluit pagina\'s',
			"viewDoc" => 'Toon document',
			"menu" => '[menu]',
			"saveDoc" => 'Document opslaan',
			"saveAllDocs" => 'Alle documenten opslaan',
			"closeDoc" => 'Document sluiten',
			"closeAllDocs" => 'Alle documenten sluiten',
			"clearCache_pages" => 'Wis Pagina Cache',
			"clearCache_all" => 'Wis Alle Cache',
			"edit" => 'Bewerk',
			"delete" => 'Verwijderen',
			"upload" => 'Upload bestanden',
			"saveNewDoc" => 'Sla document op en maak een nieuwe',
		),
		"err" => Array (
			"1" => 'Je moet eerst het record opslaan voor je het kan tonen!',
			"2" => 'Dit record is verwijdert uit het geheugen. Herlaad de lijst.',
			"3" => 'Er dienen minimaal %s item(s) in de groep aanwezig te zijn!',
			"4" => 'Voeg niet meer dan %s item(s) toe',
			"5" => 'Het inhoud van het klembord kan niet worden ingevoegd. Dit dienen records uit de database te zijn!',
			"6" => 'Het inhoud van het klembord kan niet worden ingevoegd. Het dienen bestanden of mappen te zijn!',
			"7" => 'Het systeem is bezet - Even wachten alsjeblieft. Als het systeem niet binnen afzienbare tijd beschikbaar komt, dan dien je Typo3 te herstarten.',
			"8" => 'Je kan geen nieuw record opslaan dat gekoppeld is aan een ander record!',
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(
			"makeShortcut" => "Maak een snelkoppeling naar deze pagina.",
			"lockedRecord" => "De gebruiker '%s' begon %s geleden dit record te bewerken.",
			"lockedRecord_content" => "De gebruiker '%s' begon %s geleden inhoud van deze pagina te bewerken.",
			"showRecords" => "Toon records",
			"path" => "Pad",
			"upOneLevel" => "Een niveau omhoog",
			"reload" => "Herlaad",
			"clear_cache" => "Wis cache voor deze pagina",
			"no_title" => "Geen titel",
			"cancel" => "Annuleren",
			"hidden" => "Verbergen",
			"starttime" => "Start",
			"endtime" => "Eind",
			"minutesHoursDaysYears" => "min| uren| dagen| jaren",
			"menu" => "Menu:",
			"enterSearchString" => "Zoekreeks:",
			"enterSearchLevels" => "Deze pagina|1 niveau lager|2 niveau's lager|3 niveau's lager|4 niveau's lager|",
			"noEditPermission" => "Helaas, dat gaat niet lukken. Je hebt niet de juiste bevoegdheden om deze wijziging uit te voeren.",
			"fieldsMissing" => "Er zijn velden in het formulier die nog niet correct zijn ingevuld. Deze velden zijn gemarkeerd met een geel uitroepteken.",
			"_CONTROL_" => "Control",
			"_PATH_" => "Pad",
			"setFields" => "Plaats velden",
			"search" => "Zoek",
			"author" => "Auteur:",
			"note" => "Aantekening:",
			"category" => "Categorie:",
			"csv" => "Download CSV bestand",
			"showPage" => "Bekijk webpagina",
			"days" => "dagen",
			"goBack" => "Ga terug",
			"fieldsChanged" => "Er zijn niet opgeslagen wijzigingen! Wil je toch doorgaan?",
			"showPalettes" => "Toon extra opties (paletten)",
			"disableRTE" => "Deactiveer Tekst Plus Editor (TPE)",
			"openInNewWindow" => "Open in nieuw venster",
			"showDescriptions" => "Toon veld omschrijvingen",
			"showList" => "Toon records lijst",
		),
		"show_item.php" => Array(
			"viewItem" => "Bekijk item",
			"file" => "Bestand",
			"dimensions" => "Dimensies",
			"filesize" => "Formaat",
			"ftp_area" => "FTP gebied"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nieuw record",
			"after" => "na",
			"inside" => "in"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Bewerk",
			"submit" => "Opslaan",
			"saveAndClose" => "Opslaan en Sluiten",
			"coundNot" => "Dit bestandstype kan niet worden gewijzigd. De volgende bestandstypes zijn wel te wijzigen:%s"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Upload bestanden",
			"submit" => "Upload bestanden",
			"files" => "bestanden"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Hernoemen",
			"submit" => "Hernoemen"
		),
		"file_newfolder.php" => Array(
			"newfile_submit" => "Bestand maken",
			"newfile" => "Tekstbestand maken",		
			"pagetitle" => "Nieuwe map",
			"submit" => "Maak mappen",
			"folders" => "mappen"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Verkeerd upload pad!",
			"warning" => 'Er is geen Upload-map gevonden. Je moet eerst een TEMP-map ("_temp_") aanmaken in de root van een van de startpunten!'
		),
		"mess" => Array(
			"redraw" => "Hertekenen van de pagina verwijdert de huidige data. Wilt U toch doorgaan?",
			"start_typo3" => "Wilt U de Typo3 standaard interface nu starten. (Duurt een minuut of twee.)",
			"close_login" => "Je hebt dit venster waarschijnlijk niet meer nodig, tenzij je Typo3 nog niet gestart hebt, kun je dit venster sluiten!"
		)
	);


?>