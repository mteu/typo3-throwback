<?php
	// Url to turkish manual
	$typo3_help_url= "";
	$charSet = "iso-8859-9";                                                // String. Charset other than 'iso-8859-1' to use in the backend, eg. 'windows-1250'
	
	//turkish
	$mainLang = Array (
			// ClickMenus
			// items in clickmenus
		"cm" => Array (
			"view" => "G�ster",
			"edit" => "D�zenle",
			"new" => "Yeni",
			"copy" => "Kopyala",
			"cut" => "Kes",
			"pasteinto" => "��ine yap��t�r",
			"pasteafter" => "Sonra yap��t�r",
			"select" => "Se�",
			"deselect" => "Se�imi iptal et",
			"selectto" => "Bunu se�",
			"deselectto" => "Bunu iptal et",
			"delete" => "Sil",
			"upload" => "Y�kleme",
			"rename" => "Yeniden adland�r",
			"open" => "A��k",
			"save" => "Kaydet",
			"unzip" => "S�k��t�r�lm�� dosyay� a�",
			"info" => "Bilgi",
			"createnew" => "Yarat",
			"hide" => 'Gizle',
			"unhide" => 'Gizleme',
		),
		
		// defines which tabs are being generated. Entries in this array are significant. If a tab should not hold a textual value but an icon only, then leave this blank
		"tabs" => Array (
			"normal" => "Normal"
		),
		// defines buttons. They are made with both a normal and rollover state
		"buttons" => Array (
			"clipboard" => "Pano",
			"logout" => "��k��",
			"clear" => "Temizle"
		),
		
		// Image Labels
		// This is image alt-texts in typo
		// prepended with "l" only!!
		"labels" => Array (
			// Tabs
			"webtabs" => "Sayfa a�ac� #",
			"filetabs" => "Dizin a�ac� #",
			// Buttons
			"logout" => "Sistem ��k���",
			"selectmode" => "Nesneleri tek t�klamayla se�in",
			"thumbmode" => "K���k resim modunu g�ster",
			"thumbmode_clip" => "K���k resim modunu panoda g�ster",
			"copymode" => "Kopyalanan nesneleri onlar�n yerine koy",
			"refresh" => "Dizin a�ac�n� yeniden y�kle",
			"clearClip" => "Panodaki se�ili elementleri temizle",
			// ClipBoard
			"clipNormal" => "Normal pano",
			"filelist" => "G�ncel dosya listesi",
			"dblist" => "G�ncel veri taban� listesi",
			"clip" => "Pano se�ti�iniz nesneleri tutar",
			"cliptabs" => "Pano #",
			"removeItem" => "Nesneleri kald�r",
			"inverseSelection" => "Se�ileni ters �evir",
			"selectAll" => "Hepsini se�",
			"selectNone" => "Hi�birini se�me",
			// Document-tab
			"selected" => "Se�ili",
			"items" => "Nesneler",
			"prevDoc" => "Bir �nceki d�k�man",
			"nextDoc" => "Bir sonraki d�k�man",
			"click_menu" => "Men� i�in t�klay�n",
			"show_options" => "Genel se�enekleri g�ster",
			"remove_selected" => "Se�ili nesneleri kald�r",
			"import_clip" => "Panodan nesneleri transfer et",
			"move_to_top" => "Se�ili nesneleri yukar�ya ta��",
			"upload_files" => "Dosyalar� klipborda y�kle",
			"browse_file" => 'Browse i�in dosyalar',
			"browse_db" => 'Browse i�in kay�tlar',
			"minimize" => "Minimize et",
			"maximize" => "Maksimize et",
			"close" => "Kapat",
			"selectToClip" => "Panoda nesneleri se�",
			"viewItem" => "Nesneleri g�ster",
			"new" => "YEN�",
			"upload" => "Dosya y�kle",
			"editItem" => "Nesne d�zenle",
			"clipNormal2" => 'Normal',
			"clipNoEl" => 'Elementler yok',
			"generalOptions" => 'Genel se�enekler:',
			"allTables" => '[T�m tablolar]',
			"moreOptions" => 'Di�er se�enekler...',
			"noMatchingValue" => 'SE�T���N�Z DE�ER MEVCUT DE��L (%s)',
		),
		// This is messages and comfirmations.
		// %s will be substituted by some variable from the context when shown.
		"mess" => Array (
			"recIsChanged" => 'Bu kay�t de�i�tirildi.\nHala kapatmak istiyormusunuz?',
			"docIsChanged" => 'D�k�man�n "%s" de�i�tirildi.\nHala de�i�tirmek istiyormusunuz?',
			"unzip" => 'S�k��t�r�l�m�� ar�iv dosyas�n� a�mak iste�inizden emin misiniz "%s"?',
			"delete" => 'Silmek istedi�inizden emin misiniz "%s"?',
			"deleteClip" => 'Panodaki T�M se�ili elementlerin (%s) silmek istedi�inizden emin misiniz?',
			"permChanges" => 'Yektilerinizin baz�lar� de�i�tirildi.\nBu de�i�iklikleri arabirime yans�tmak i�in kapat�n ve tekrar typo3 komutunda a��n!',
			"gettingTree" => 'Serverdan a�a� al�n�yor <BR>L�tfen bekleyin...',
			"move_into" => 'Ta��nan "%s" i�eriye "%s"?',
			"move_after" => 'Ta��nan "%s" sonrakine "%s"?',
			"copy_into" => 'Kopyalanan "%s" i�eriye "%s"?',
			"copy_after" => 'Kopyalanan "%s" sonrakine "%s"?',
			"copycb_into" => 'T�m elementleri kopyala (%s) panonun i�ine "%s"?',
			"copycb_after" => 'T�m elementleri kopyala (%s) panonun sonraki pozisyonundan "%s"?',
			"movecb_into" => 'T�m elementleri ta�� (%s) panonun i�ine "%s"?',
			"movecb_after" => 'T�m elementleri ta�� (%s) panonun sonraki pozisyonundan "%s"?',
			"refresh_login" => 'Galiba giri� s�reniz doldu. \nTekrar yenilemek istiyormusnuz?',
			"miss_field" => 'Belirtilen alan do�ru bir �ekilde doldurulmad�:\n',
			"miss_field_in_doc" => 'D�k�man�n "%s" alan� kapsayan k�sm�, do�ru bir �ekilde doldurulmad�:%s\n\nHi� bir�ey kaydedilmedi!',
			"onChangeAlert" => 'Bu de�i�iklik formun i�inde bulunan lanalara etki edecektir.\nG�r�nt�y� yenilemek i�in kaydetmek istiyormusunuz?',
		//                        "closeTypo" => 'Opravdu chcete opustit Typo3?'
		),
		// Roll menus
		"rm" => Array (
			"menu" => "[men�]",
			"saveDoc" => "D�k�man� kaydet",
			"saveAllDocs" => "T�m dosyalar� kaydet",
			"saveCloseDoc" => "Kaydet ve d�k�man� kapat",
			"saveCloseAllDocs" => "Kaydet ve t�m d�k�manlar� kapat",
			"saveDocShow" => "D�k�manlar� kaydet ve sayfada g�ster",
			"closeDoc" => "D�k�man� kapat",
			"closeAllDocs" => "T�m d�k�manlar� kapat",
			"viewDoc" => "D�k�man� g�ster",
			"clearCache_pages" => "Sayfa �nbelle�ini temizle",
			"clearCache_all" => "T�m �nbelle�i temizle",
			"edit" => "D�zenle",
			"delete" => "Sil",
			"upload" =>  "Dosyalar� y�kle",
			"saveNewDoc" => 'Dok�man� kaydet ve yeni bir tane yarat',
			"clearCache_clearCache" => '�nbelle�i temizle',
			"clearCache_thisPage" => 'Bu sayfada',
		),
		// Error-messages
		"err" => Array (
			"1" => "Kay�tlar�n�z� sayfada g�stermek i�in kaydetmelisiniz!",
			"2" => "Bu kay�t haf�zadan kald�r�ld�. Listeyi tekrar y�kleyiniz.",
			"3" => "Nesnelerin en az %s grup olmal�d�r!",
			"4" => "%s dan fazla nesne eklemeyiniz ",
			"5" => "Panodaki i�erik eklenemedi. Kay�tlar veritaban�ndan olmal�d�r!",
			"6" => "Panodaki i�erik eklenemdi. Dosya veya klas�rler olmal�d�r!",
			"7" => "Sistem me�gul - L�tfen bekleyiniz. E�er sistem k�sa bir zaman i�inde mevcut olmazsa, Typoyu tekrar ba�latmal�s�n�z",
			"8" => "Yeni bir kay�t kaydedemediniz, bu kay�t� ba�ka bir kay�tla ili�kilendiremediniz!"
		)
	);
	
	
	
	// This array contains labels used for direct output in PHP-code.
	
	$php3Lang = Array (
		"labels" => Array(                // general
			"path" => "Men�",
			"upOneLevel" => "Bir �st seviye",
			"enterSearchString" => "Dizgi arama:",
			"reload" => "Tekrar y�kle",
			"clear_cache" => "Bu sayfa i�in �nbelle�i temizleyin",
			"no_title" => "Ba�l�k yok",
			"cancel" => "�ptal",
			"hidden" => "Gizli",
			"starttime" => "Ba�lama zaman�",
			"endtime" => "Bitirme zaman�",
			"minutesHoursDaysYears" => " dakika| saat| g�n| y�l",
			"menu" => "Men�:",
			"days" => "g�nler",
			"enterSearchLevels" => "Bu sayfa|alt seviye 1 |alt seviye 2|alt seviye 3|alt seviye 4",
			"noEditPermission" => "�zg�n�m, bu de�i�iklikte uygun yetkileri yerine getirmediniz.",
			"fieldsMissing" => "Formun i�inde hen�z do�ru bir �ekilde doldurulmayan alanlar var. Alanlar sar� �nlem imiyle �izilmi�tir.",
			"_CONTROL_" => "Kontrol",
			"_PATH_" => "Men�",
			"setFields" => "Alanlar� kur",
			"search" => "Ara�t�r",
			"author" => "Yazar:",
			"note" => "Not:",
			"category" => "Kategori:",
			"csv" => "CSV dosyas�n� download yap�n",
			"showPage" => "Web sayfas�n� g�ster",
			"openInNewWindow" => "Yeni pencere a�",
			"goBack" => "Geri d�n",
			"makeShortcut" => "Bu sayfaya k�sayol yarat?",
			"lockedRecord" => "Kullan�c� '%s' kayd�n� %s �nce d�zenlemeye ba�lad�.",
			"lockedRecord_content" => "Kullan�c� '%s' bu sayfa i�eri�ini %s �nce d�zenlemeye ba�lad�.",
			"showRecords" => "Kay�tlar� g�ster ",
			"fieldsChanged" => "Formun i�inde kaydedilmemi� de�i�iklikler bulunmaktad�r! Hala devam etmek istiyormusunuz?",
			"showPalettes" => "�kincil se�enekleri g�ster (paletler)",
			"showDescriptions" => "Alan tan�mlar�n� g�ster",
			"disableRTE" => "Zengin Metin D�zenleyiciyi devre d��� b�rak (ZMD)",
			"showList" => "Kay�t listesini g�ster",
		),
		"show_item.php" => Array(
			"viewItem" => "Nesne g�ster",
			"file" => "Dosya",
			"dimensions" => "Boyutlar",
			"filesize" => "Dosya ebat�",
			"ftp_area" => "FTP B�LGES�"
		),
		"db_new.php" => Array(
			"pagetitle" => "Yeni kay�t",
			"after" => "sonraki",
			"inside" => "i�indeki"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Y�klenen dosyalar",
			"submit" => "Y�klenen dosyalar",
			"files" => "dosyalar"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Yeniden adland�r",
			"submit" => "Yeniden adland�r"
		),
		"file_edit.php" => Array(
			"pagetitle" => "D�zenle",
			"submit" => "Kaydet",
			"saveAndClose" => "Kaydet ve Kapat",
			"coundNot" => "Bu dosya t�r� d�zenlenemiyor.<BR>Dosya mutlaka geni�letilmelidir:<BR><BR> <b>%s</b>"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Yeni klas�r",
			"submit" => "Klas�rler yarat",
			"folders" => "klas�rler",
			"newfile_submit" => "Dosya yarat",
			"newfile" => "Yeni metin dosyas� yarat"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Y�klenen yol hatal�",
			"warning" => 'Y�klenen klas�r bulunamad�. �lk mountunuzun k�k�nde yeni bir ge�ici bir klas�r ("_temp_") yaratmal�s�n�z!!'
		),
		"mess" => Array(
			"redraw" => "Sayfay� yeniden olu�turmak �u andaki bilgileri yoksayacacakt�r. Devam etmek istiyormusununuz?",
			"start_typo3" => 'Typo3 arabirim standart�n� do�ru bir �ekilde ba�latmak istermisiniz? \n(Bir veya iki dakika al�r)',
			"close_login" => "E�er Typo3 � hen�z ba�latmad�ysan�z bu ekrana daha fazla ihtiyac�n�z yok, bu pencereyi kapatabilirsiniz."
		)
	);
	
	
	

?>
