<?php
		// Url to french manual
	$typo3_help_url= "";

		// Mainlang in french. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"view" => "Visualiser",
			"edit" => "Editer",
			"new" => "Nouveau",
			"copy" => "Copier",
			"cut" => "Couper",
			"pasteinto" => "Coller dans",
			"pasteafter" => "Coller apr�s",
			"select" => "S�lectionner",
			"deselect" => "D�s�lectionner",
			"selectto" => "S�lectionner vers",
			"deselectto" => "D�s�lectionner vers",
			"delete" => "Supprimer",
			"upload" => "Uploader fichiers",
			"rename" => "Renommer",
			"open" => "Ouvrir",
			"save" => "Enregistrer",
			"unzip" => "D�zipper",
			"info" => "Info",
			"createnew" => "Cr�er nouveau"
		),
		"buttons" => Array (
			"clipboard" => "Presse-papier",
			"logout" => "D�connexion",
			"clear" => "Effacer"
		),
		"labels" => Array (
			"webtabs" => "N� page dans arborescence",
			"filetabs" => "N� r�pertoire dans arborescence",
			"logout" => "Pour quitter l'application, vous devez vous d�connecter avant de fermer la fen�tre.",
			"selectmode" => "S�lectionnez les �l�ments � l'aide d'un clic-droit de la souris.",
			"thumbmode" => "Visualiser catalogue",
			"thumbmode_clip" => "Visualiser catalogue dans le presse-papier",
			"copymode" => "Copier les �l�ments sans les d�placer",
			"refresh" => "Recharger l'arborescence � partir du serveur",
			"clearClip" => "Effacer les �l�ments du presse-papier",
			"clipNormal" => "Press-papier standard",
			"filelist" => "Liste des fichiers en cours",
			"dblist" => "Liste des enregisterments en cours",
			"clip" => "Le presse papier contient les �l�ments que vous avez s�lectionn�s",
			"cliptabs" => "N� dans le presse-papier",
			"removeItem" => "Supprimer �l�ments",
			"inverseSelection" => "Inverser s�lection",
			"selectAll" => "Tout s�lectionner",
			"selectNone" => "Tout d�s�lectionner",
			"selected" => "S�lectionn�(s)",
			"items" => "El�ments",
			"prevDoc" => "Document pr�c�dent",
			"nextDoc" => "Document suivant",
			"click_menu" => "Cliquez pour acc�der au menu",
			"show_options" => "Visualiser les options principales",
			"remove_selected" => "Supprimer �l�ments s�lectionn�s",
			"import_clip" => "Transf�rer �l�ments � partir du presse-papier",
			"move_to_top" => "D�placer �l�ments s�lectionn�s vers le haut",
			"upload_files" => "Uploader",
			"browse_file" => 'Naviguer dans les fichiers',
			"browse_db" => 'Naviguer dans les enregistrements',
			"upload" => 'Uploader un fichier',
			"minimize" => "R�duire",
			"maximize" => "Maximiser",
			"close" => "Fermer",
			"selectToClip" => "S�lectionner �l�ments vers presse-papier",
			"viewItem" => "Visualiser �l�ment",
			"new" => "NOUVEAU",
			"editItem" => "Editer �l�ment"
		),
		"mess" => Array (
			"recIsChanged" => 'Cet enregistrement a �t� modifi�. \n Souhaitez-vous toujours le fermer ?',
			"docIsChanged" => 'Le document "%s" a �t� modifi�. \n Souhaitez-vous toujours le fermer ?',
			"unzip" => 'Souhaitez-vous extraire l\'archive zip "%s" ?',
			"delete" => 'Souhaitez-vous supprimer "%s" ?',
			"permChanges" => 'Certains de vos droits d\'acc�s ont �t� modifi�s.\n Veuillez quitter l\'application et vous connecter � nouveau pour mettre � jour d\'interface.',
			"gettingTree" => "Veuillez patienter durant<BR>la mise � jour de l'arborescence<BR>depuis le serveur",
			"move_into" => 'D�placer "%s" vers "%s"?',
			"move_after" => 'D�placer "%s" apr�s "%s"?',
			"copy_into" => 'Copier "%s" vers "%s"?',
			"copy_after" => 'Copier "%s" apr�s "%s"?',
			"copycb_into" => 'Copier tous les �l�ments (%s) du presse papier vers "%s"?',
			"copycb_after" => 'Copier tous les �l�ments(%s) du presse papier apr�s "%s"?',
			"movecb_into" => 'D�placer tous les �l�ments (%s) du presse papier vers "%s"?',
			"movecb_after" => 'D�placer tous les �l�ments  (%s) du presse papier apr�s "%s"?',
			"refresh_login" => 'Connexion d�sactiv�e. \nSouhaitez-vous vous reconnecter?',
			"deleteClip" => 'Etes-vous s�re de vouloir supprimer TOUS les �l�ments s�l�ctionn�s (%s) dans le presse-papier?',			
			"miss_field" => 'Les champs suivants n\'ont pas �t� correctement renseign�s :\n',
			"miss_field_in_doc" => 'Certains champs du document "%s" ne sont pas correctement renseign�s:%s\n\nL\'enregistrement a �chou�.'
		),
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Enregistrer document",
			"saveAllDocs" => "Enregistrer tous les documents",
			"closeDoc" => "Fermer document",
			"closeAllDocs" => "Fermer tous les document",
			"clearCache_pages" => "Effacer cache page",
			"clearCache_all" => "Effacer tous les caches",
			"saveDocShow" => 'Enregistrer et visualiser le document',
			"saveCloseDoc" => 'Sauvegarder et fermer le document',
			"saveCloseAllDocs" => 'Sauvegarder et fermer tous les documents',
			"viewDoc" => 'Visualiser le document',
			"delete" => 'Supprimer',			
			"edit" => "Edition",
			"upload" => "Uploader"		//  fichiers vers serveur
		),
		"err" => Array (
			"1" => "Vous devez enregistrer la page avant de la visualiser.",
			"2" => "Aucun enregistrement de base de donn�es en m�moire. Rechargez la liste.",
			"3" => "%s �l�ment(s) au minimum doivent faire partie du groupe.",
			"4" => "Ajout de plus de %s �l�ment(s) interdit",
			"5" => "Insersion du contenu du presse-papier impossible. Le presse-papier doit contenir des enregistrements de base de donn�es.",
			"6" => "Insersion du contenu du presse-papier impossible. Le presse-papier doit contenir des fichiers ou des dossiers.",
			"7" => "Veuillez patienter durant la mise � jour du syst�me. En cas de blocage persistant, veuillez relancer Typo.",
			"8" => "Impossible de sauvegarder un enregistrement li� � un autre enregistrement !"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(
			"setFields" => "Param�trer un champs",
			"path" => "Chemin",
			"upOneLevel" => "Remonter d'un niveau dans l'aborescence",
			"reload" => "Recharger",
			"clear_cache" => "Effacer le cache de cette page",
			"no_title" => "Sans titre",
			"cancel" => "Annuler",
			"hidden" => "Cach� (non visible)",
			"starttime" => "D�but",
			"endtime" => "Fin",
			"enterSearchString" => "Rechercher:",
			"enterSearchLevels" => "Cette page|1 niveau inf�rieur|2 niveaux inf�rieurs|3 niveaux inf�rieurs|4 niveaux inf�rieurs",
			"noEditPermission" => "D�sol�, vous n'avez pas les permissions suffisantes pour effectuer ces changements.",
			"fieldsMissing" => "Certains champs ne sont pas correctement remplis. Ils sont marqu�s d'un point d'exclamation jaune.",
			"_CONTROL_" => "Contr�le",
			"_PATH_" => "Chemin",
//			"setFields" => "Set fields",
			"search" => "Rechercher",
			"author" => "Auteur:",
			"note" => "Note:",
			"category" => "Cat�gorie:",
			"csv" => "T�l�charger le fichier CSV",
			"minutesHoursDaysYears" => "min.|h.|j.|a.",
			"menu" => "Menu:",
			"showPage" => "Visualiser la page web",			
			"days" => "Jours"
		),
		"show_item.php" => Array (
			"viewItem" => "Visualiser l'�l�ment",
			"file" => "Fichier",
			"dimensions" => "Dimensions",
			"filesize" => "Taille",
			"ftp_area" => "Zone FTP",		
		),
		"file_edit.php" => Array (
			"pagetitle" => "Editer",
			"submit" => "Sauvegarder",
			"saveAndClose" => "Sauvegarder et fermer",
			"coundNot" => "Ce type de fichier ne peut �tre �dit�. Il doit avoir une extension comme:",		
		),
		"db_new.php" => Array(
			"pagetitle" => "Nouvel enregistrement",
			"after" => "Apr�s",
			"inside" => "Dans"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Uploader fichiers",
			"submit" => "Uploader fichiers",
			"files" => "Fichiers"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Renommer",
			"submit" => "Renommer"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Nouveau dossier",
			"submit" => "Cr�er dossiers",
			"newfile_submit" => "Cr�er un fichier",
			"newfile" => "Cr�er un nouveau fichier texte",
			"folders" => "dossiers"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Chemin d'upload erron�",
			"warning" => 'Impossible de trouver le dossier d\'upload. Vous devez cr�er un dossier temporaire nomm� "_temp_" au premier niveau d\'un de vos disques mont�s.'
		),
		"mess" => Array(
			"redraw" => "La mise � jour de l'affichage de la page annule les donn�es en cours de saisie. Souhaitez-vous poursuivre ?",
			"start_typo3" => 'Souhaitez-vous acc�der directement � l\'interface standard de Typo ? \nDans l\'affirmative, veuillez alors de patienter quelques minutes.',
			"close_login" => "Si vous n'avez pas encore lanc� Typo, vous pouvez fermer cette fen�tre."
		)
	);
	





?>