<?php
/***************************************************************
*  Copyright notice
* 
*  (c) 1999-2002 Kasper Sk�rh�j
*  All rights reserved
* 
*  This script is part of the Typo3 project. Typo3 is free software;
*  You can redistribute it and/or modify it under the terms of the 
*  Typo3 License as published from the www.typo3.com website.
* 
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* 
*  This copyright notice MUST APPEAR in all copies of this script
***************************************************************/
/** 
 * Typo3 Backend Language class
 *
 * The lang-class is used to define the labels in the various languages. 
 * This is loaded when Typo3's interface is started and these messages are included once and copied into the JavaScript
 * If you translate Typo3 into another language you MUST be shure to include all settings in this document.
 * 
 * Translation is done by creating a new folder is this folder. Put a "conf.php" in this folder an let it contain a $mainLang-array 
 * corresponding to the one in this class. You should definitely look at the current example of the danish translation...
 * 
 * @author	Kasper Sk�rh�j <kasper@typo3.com>
 */

 

class language {
	var $typo3_help_url= "http://www.typo3.com/man_uk/";			// This is the url to the Typo3 manual
	var $lang="default";			// This is set to the language that is currently running for the user
	var $langSplit="default";	// Values like the labels in the tables.php-document are split by "|". This values defines which language is represented by which position in the resulting array after splitting a value.
	var $charSet = "";						// String. Charset other than 'iso-8859-1' to use in the backend, eg. 'windows-1250'

	var $mainLang = Array (
	// ClickMenus
	// items in clickmenus
		"cm" => Array (
			"view" => "Show",
			"edit" => "Edit",
			"new" => "New",
			"copy" => "Copy",
			"cut" => "Cut",
			"pasteinto" => "Paste into",
			"pasteafter" => "Paste after",
			"select" => "Select",
			"deselect" => "Deselect",
			"selectto" => "Select to",
			"deselectto" => "Deselect to",
			"delete" => "Delete",
			"hide" => "Hide",
			"unhide" => "Unhide",
			"upload" => "Upload Files",
			"rename" => "Rename",
			"open" => "Open",
			"save" => "Save",
			"unzip" => "Unzip",
			"info" => "Info",
			"createnew" => "Create new"
		),
		"cm_images" => Array (			// for each element in "cm" you can specify an icon, ?x12 pixels right-aligned
			"edit" => "gfx/edit2.gif",
			"view" => "gfx/zoom.gif",
//			"delete" => "gfx/garbage.gif",
			"info" => "gfx/zoom2.gif"
		),
		"cm_preloadList" => "view,edit,new,info,copy,cut,delete",
	// defines which tabs are being generated. Entries in this array are significant. If a tab should not hold a textual value but an icon only, then leave this blank
		"tabs" => Array (
			"normal" => "Normal"
		),
		"tabs_images" => Array (		// for each element in "tabs" you can specify an icon, ?x12 pixels left-aligned
			"normal" => ""
		),
	// defines buttons. They are made with both a normal and rollover state
		"buttons" => Array (
			"clipboard" => "Clipboard",
			"logout" => "Logout",
			"clear" => "Clear"
		),
		"buttons_h" => Array (		// for each element in "buttons": If a button is generated with a highligted version
			"clipboard" => "1",
			"logout" => "1",
			"clear" => "1"
		),
		"buttons_images" => Array (		// for each element in "buttons" you can specify an icon, ?x12 pixels left-aligned
			"clipboard" => "gfx/clipbrd.gif",
//			"clear" => "gfx/clearout.gif"
		),
		"buttons_noJS" => Array (),		// for each element in "buttons": True-values disables output to JS but just generates the button!!

	// Image Labels
	// This is image alt-texts in typo
	// prepended with "l" only!!
		"labels" => Array (
		// Tabs
			"webtabs" => "Page Tree #",
			"filetabs" => "Directory Tree #",
		// Buttons
			"logout" => "Always remember to log out instead of closing the window!",
			"selectmode" => "Select items with a single click",
			"thumbmode" => "Show Thumbnails",
			"thumbmode_clip" => "Show Thumbnails on ClipBoard",
			"copymode" => "Copy items instead of moving them",
			"refresh" => "Reload the tree from server",
			"clearClip" => "Clear selected elements on clipboard",
		// ClipBoard
			"clipNormal" => "Standard Clipboard",
			"clipNormal2" => "Normal",
			"clipNoEl" => "No elements",
			"filelist" => "Current file listing",
			"dblist" => "Current database listing",
			"clip" => "The clipboard holds your selected items",
			"cliptabs" => "Clipboard #",
			"removeItem" => "Remove item",
			"inverseSelection" => "Inverse selection",
			"selectAll" => "Select all",
			"selectNone" => "Select none",
		// Document-tab
			"selected" => "Selected",
			"items" => "Items",
			"prevDoc" => "Previous document",
			"nextDoc" => "Next document",
			"click_menu" => "Click for menu",
			"show_options" => "Show general options",
			"remove_selected" => "Remove selected items",
			"import_clip" => "Transfer items from Clipboard",
			"move_to_top" => "Move selected item upwards",
			"upload_files" => "Upload files to clipboard",
			"browse_file" => "Browse for files",
			"browse_db" => "Browse for records",
			"minimize" => "Minimize",
			"maximize" => "Maximize",
			"close" => "Close",
			"selectToClip" => "Select item to clipboard",
			"viewItem" => "View item",
			"new" => "NEW",
			"upload" => "Upload file",
			"generalOptions" => "General options:",
			"allTables" => "[All tables]",
			"moreOptions" => "More options...",
			"noMatchingValue" => "CURRENT VALUE IS NOT AVAILABLE (%s)",
			"editItem" => "Edit item"
		),
	// This is messages and comfirmations.
	// %s will be substituted by some variable from the context when shown. 
		"mess" => Array (
			"onChangeAlert" => 'This change will affect which fields are available in the form.\nWould you like to save now in order to refresh the display?',
			"recIsChanged" => 'This record was changed.\nDo you still want to close it?',
			"docIsChanged" => 'The document "%s" was changed.\nDo you still want to close it?',
			"unzip" => 'Are you sure, you want to unzip the archive "%s"?',
			"delete" => 'Are you sure, you want to delete "%s"?',
			"deleteClip" => 'Are you sure, you want to delete ALL selected elements (%s) on the clipboard?',
			"permChanges" => 'There has been made some changes to your permissions.\nYou should close and reopen Typo3 again in order for the interface to reflect these changes!',
			"gettingTree" => 'Fetching the tree from server<BR>Please wait...',
			"move_into" => 'Move "%s" into "%s"?',
			"move_after" => 'Move "%s" to after "%s"?',
			"copy_into" => 'Copy "%s" into "%s"?',
			"copy_after" => 'Copy "%s" to after "%s"?',
			"copycb_into" => 'Copy all elements (%s) from the clipboard into "%s"?',
			"copycb_after" => 'Copy all elements (%s) from the clipboard to the position after "%s"?',
			"movecb_into" => 'Move all elements (%s) from the clipboard into "%s"?',
			"movecb_after" => 'Move all elements (%s) from the clipboard to the position after "%s"?',
			"refresh_login" => 'Your login has probably expired. \nDo you want to refresh it now?',
			"miss_field" => 'The following fields are not correctly filled:\n',
			"miss_field_in_doc" => 'The document "%s" contains fields that are not correctly filled:%s\n\nNothing is saved!'
//			"closeTypo" => 'Do you really want to leave Typo3?'
		),
	// Roll menus
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Save document",
			"saveDocShow" => "Save document and view page",
			"saveAllDocs" => "Save all documents",
			"saveCloseDoc" => "Save and close document",
			"saveCloseAllDocs" => "Save and close all documents",
			"saveNewDoc" => "Save document and create a new one",
			"closeDoc" => "Close document",
			"closeAllDocs" => "Close all documents",
			"viewDoc" => "View document",
			"clearCache_clearCache" => "Clear cache",
			"clearCache_thisPage" => "This page",
			"clearCache_pages" => "Clear Page Cache",
			"clearCache_all" => "Clear All Cache",
			"edit" => "Edit",
			"delete" => "Delete",
			"upload" =>  "Upload files"
		),
	// Error-messages
		"err" => Array (
			"1" => "You must save the record to view the page!",
			"2" => "This record has been removed from the memory. Reload the list.",
			"3" => "%s items(s) at least must be in the the group!",
			"4" => "Do not add more than %s item(s)",
			"5" => "The content of the clipboard cannot be inserted. It must be records from the database!",
			"6" => "The content of the clipboard cannot be inserted. It must be files or folders!",
			"7" => "The system is busy - Please wait. If the system do not become available within a short while you may have to restart Typo",
			"8" => "You cannot save a new record that is attached to another new record!"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	var $php3Lang = Array (
		"labels" => Array(		// general
			"openInNewWindow" => "Open in new window",
			"goBack" => "Go back",
			"makeShortcut" => "Create a shortcut to this page?",
			"lockedRecord" => "The user '%s' began to edit this record %s ago.",
			"lockedRecord_content" => "The user '%s' began to edit content on this page %s ago.",
			"showRecords" => "Show records",
			"path" => "Path",
			"upOneLevel" => "Up one level",
			"enterSearchString" => "Search String:",
			"enterSearchLevels" => "This page|1 level down|2 levels down|3 levels down|4 levels down",
			"noEditPermission" => "Sorry, you didn't have proper permissions to perform this change.",
			"fieldsMissing" => "There are fields in the form which are not yet correctly filled in.\nThe fields are marked with a yellow exclamation mark.",
			"fieldsChanged" => "There are unsaved changes in the form!\nDo you want to continue WITHOUT saving?",
			"showPalettes" => "Show secondary options (palettes)",
			"showDescriptions" => "Show field descriptions",
			"disableRTE" => "Disable Rich Text Editor (RTE)",
			"_CONTROL_" => "Control",
			"_PATH_" => "Path",
			"setFields" => "Set fields",
			"search" => "Search",
			"author" => "Author:",
			"note" => "Note:",
			"category" => "Category:",
			"reload" => "Reload",
			"csv" => "Download CSV file",
			"clear_cache" => "Clear cache for this page",
			"no_title" => "No title",
			"cancel" => "Cancel",
			"hidden" => "Hidden",
			"starttime" => "Start",
			"endtime" => "End",
			"minutesHoursDaysYears" => " min| hrs| days| yrs",
			"menu" => "Menu:",
			"showPage" => "View webpage",
			"showList" => "Show record list",
			"days" => "days"
		),
		"show_item.php" => Array(
			"viewItem" => "View Item",
			"file" => "File",
			"dimensions" => "Dimensions",
			"filesize" => "Size",
			"ftp_area" => "FTP AREA"
		),
		"db_new.php" => Array(
			"pagetitle" => "New record",
			"after" => "after",
			"inside" => "inside"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Upload files",
			"submit" => "Upload files",
			"files" => "files"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Rename",
			"submit" => "Rename"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Edit",
			"submit" => "Save",
			"saveAndClose" => "Save and Close",
			"coundNot" => "This filetype cannot be edited.<BR>The file must have an extension like:<BR><BR> <b>%s</b>"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "New folder",
			"submit" => "Create folders",
			"folders" => "folders",
			"newfile_submit" => "Create file",
			"newfile" => "Create new textfile"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Upload path error",
			"warning" => 'No upload-folder is found. You should create a TEMP-folder ("_temp_") in the root of one of your mounts first!'
		),
		"mess" => Array(
			"redraw" => "Redrawing the page will discard the current data. Do you want to continue?",
			"start_typo3" => 'Would you like to start the Typo3 standard interface right away? \n(It takes a minute or two)',
			"close_login" => "You probably don't need this screen anymore, so unless you haven't started Typo3 already, you can close this window."
		)
	);
	



		// Internal
	var $langSplitIndex=0;

	function init($lang,$altPath="")	{	
		// initializes the language $lang. 
		// The folder is found and the conf.php file is included. The language-overriding is done.
		$this->langSplit=TYPO3_languages;
		$path=($altPath?$altPath:PATH_typo3)."lang/".$lang;
		if (@is_dir($path) && @file_exists($path."/conf.php"))	{
			$this->lang = $lang;
			include($path."/conf.php");		// The conf-file is included. This must be valid PHP.
			$this->addLanguage($mainLang,"");	// $mainLang-array from the included file is loaded
			$this->addLanguage_PHP($php3Lang,"");	// $mainLang-array from the included file is loaded
			if ($typo3_help_url)	$this->typo3_help_url=$typo3_help_url;	// Help-url is set.
			if ($charSet)	$this->charSet=$charSet;	// Charset is set

			$ls = explode("|",$this->langSplit);
			while(list($i,$v)=each($ls))	{
				if ($v==$this->lang)	{$this->langSplitIndex=$i;}
			}
		}
//		$this->typo3_help_url = $GLOBALS["helpUrl"].$this->typo3_help_url;
	}
	function printClickmenuToJS()	{
		// This checks for and possibly generates the gif-files for the click-menues.
		// Afterwards the images are loaded by JavaScript statements
		if (is_array($this->mainLang[cm]))	{
			reset($this->mainLang[cm]);
			while(list($key,$val)=each($this->mainLang[cm])) {
				$name = $GLOBALS["TBE_iGraphics"]->makeClick($val,$this->mainLang[cm_images][$key]);
				$preLoad = t3lib_div::inList($this->mainLang[cm_preloadList],$key) ? 1 : 0;
				echo "
	glImage.add ('cm_".$key."', 104, 12, 'temp/".t3lib_div::slashJS($name)."','','','',".$preLoad.");";
			}
		}
		echo "
		";
	}
	function printTabsToJS()	{
		// This checks for and possibly generates the gif-files for the panes.
		// Afterwards the images are loaded by JavaScript statements
		if (is_array($this->mainLang[tabs]))	{
			reset($this->mainLang[tabs]);
			while(list($name,$label)=each($this->mainLang[tabs])) {
				if ($this->mainLang[tabs_images][$name] && @is_file($this->mainLang[tabs_images][$name]))	{
					$basefile = $this->mainLang[tabs_images][$name];
				} else {
					$basefile = "";
				}	
				if (!$basefile && !$label) {
					$label="...";
				}
				$modconf[icon_dims] = $GLOBALS["TBE_iGraphics"]->makePane($name,$label,$basefile);
				echo "
	glImage.add ('fane_".$name."', ".$modconf[icon_dims][0].", 12, 'temp/".$modconf[icon_dims][name]."');";
			}
		}
		echo "
		";
	}
	function printButtonsToJS($returnArray=0)	{
		// This checks for and possibly generates the gif-files for the buttons.
		// Afterwards the images are loaded by JavaScript statements
		$items=array();
		if (is_array($this->mainLang[buttons]))	{
			reset($this->mainLang[buttons]);
			while(list($name,$label)=each($this->mainLang[buttons])) {
				if ($this->mainLang[buttons_images][$name] && @is_file($this->mainLang[buttons_images][$name]))	{
					$basefile = $this->mainLang[buttons_images][$name];
				} else {
					$basefile = "";
				}	
				if (!$basefile && !$label) {
					$label="...";
				}
				$modconf[icon_dims] = $GLOBALS["TBE_iGraphics"]->makeButtons($name."_n",$label,$basefile,"");
				if ($this->mainLang[buttons_h][$name])	{	// Only if stated, we make a highlighted one
					$modconf2[icon_dims] = $GLOBALS["TBE_iGraphics"]->makeButtons($name."_h",$label,$basefile,"139,148,183");
				} else {
					$modconf2="";
				}
				if (!$this->mainLang["buttons_noJS"][$name])	{
					if (!$returnArray)	{
						echo "
	glImage.add ('button_".$name."', ".$modconf[icon_dims][0].", ".$modconf[icon_dims][1].", 'temp/".$modconf[icon_dims][name]."','','".($modconf2 ? "temp/".$modconf2[icon_dims][name] : "")."');";
					} else $items["button_".$name] = "temp/".$modconf[icon_dims][name];
				}
			}
		}
		if (!$returnArray)	{
			echo "
		";
		} else return $items;
	}
	function printJS()	{
		// This outputs the interface-labels as JavaScript code
		$this->printArrayToJS($this->mainLang[labels],"l");
		$this->printArrayToJS($this->mainLang[mess],"mess");
		$this->printArrayToJS($this->mainLang[rm],"rm");
		$this->printArrayToJS($this->mainLang[err],"err");
	}
	function printArrayToJS($arr,$pref)	{
		// internal...
		if (is_array($arr))	{
			reset($arr);
			while(list($key,$val)=each($arr)) {
				echo "
	langObj.add('".$pref."_".$key."','".t3lib_div::slashJS($val)."');";
			}
		}
		echo "
		";
	}
	function addLanguage($arr,$prefix)	{
		// This function takes an array corresponding to $this->mainLang.
		// The values in these arrays are transferred to $this->mainLang in this object and as such it provides a way to override the default language labels
		if (is_array($arr))	{
			reset($arr);
			while(list($k,$larr)=each($arr))	{
				if (is_array($larr))	{
					reset($larr);
					while(list($l,$v)=each($larr))	{
						if (isset($this->mainLang[$k]))	{
							$this->mainLang[$k][$prefix.$l]=$v;
						}
					}
				}
			}
		}
	}
	function addLanguage_PHP($arr,$prefix)	{
		// This function takes an array corresponding to $this->php3Lang.
		// The values in these arrays are transferred to $this->php3Lang in this object and as such it provides a way to override the default language labels
		if (is_array($arr))	{
			reset($arr);
			while(list($k,$larr)=each($arr))	{
				if (is_array($larr))	{
					reset($larr);
					while(list($l,$v)=each($larr))	{
						if (isset($this->php3Lang[$k]))	{
							$this->php3Lang[$k][$prefix.$l]=$v;
						}
					}
				}
			}
		}
	}
	function getLL($index)	{
		// Get Local Language
		if (isset($GLOBALS["LOCAL_LANG"][$this->lang][$index]))	{
			return $GLOBALS["LOCAL_LANG"][$this->lang][$index];
		} else {
			return $GLOBALS["LOCAL_LANG"]["default"][$index];
		}
	}
	function sL($input)	{		// splitLabel
		$t = explode("|",$input);
		return $t[$this->langSplitIndex] ? $t[$this->langSplitIndex] : $t[0];
	}
}

?>