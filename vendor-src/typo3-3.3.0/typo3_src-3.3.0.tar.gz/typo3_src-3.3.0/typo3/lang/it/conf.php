<?php
		// Url to italian manual
	$typo3_help_url= "";

		// Mainlang in italian. This is overlayed on the default $mainLang

	$mainLang = Array (
		"cm" => Array (
			"view" => "Mostra",
			"edit" => "Edita",
			"new" => "Nuovo",
			"copy" => "Copia",
			"cut" => "Taglia",
			"pasteinto" => "Incolla in",
			"pasteafter" => "Incolla dopo",
			"select" => "Seleziona",
			"deselect" => "De-seleziona",
			"selectto" => "Seleziona a",
			"deselectto" => "De-seleziona a",
			"delete" => "Cancella",
			"upload" => "Invia Files",
			"rename" => "Rinomina",
			"open" => "Apri",
			"save" => "Salva",
			"unzip" => "Unzip",
			"info" => "Info",
			"createnew" => "Crea Nuovo"
		),
		"buttons" => Array (
			"clipboard" => "Clipboard",
			"logout" => "Uscita",
			"clear" => "Pulisci"
		),
		"labels" => Array (
		// Tabs
			"webtabs" => 'Page Tree #',
			"filetabs" => 'Directory Tree #',
			"items" => 'Items',
		// Buttons
			"logout" => "Ricordati di uscire prima di chiudere la finestra",
			"selectmode" => "Seleziona items con un singolo click",
			"thumbmode" => "Mostra Miniature",
			"thumbmode_clip" => "Mostra miniature nella clipboard",
			"copymode" => "Copia gli items invece di spostarli",
			"refresh" => "Ricarica dal server",
			"clearClip" => "Cancelle gli elementi selezionati dalla clipboard",
		// ClipBoard
			"clip" => 'In attesa di selezione items',
			"clipNormal" => "Clipboard standard",
			"filelist" => "Lista attuale dei files",
			"dblist" => "Lista attuale del database",
			"cliptabs" => "Clipboard #",
			"removeItem" => "Rimuovi item",
			"inverseSelection" => "Selezione inversa",
			"selectAll" => "Seleziona tutto",
			"selectNone" => "De-seleziona tutto",
		// Document-tab
			"selected" => "Selezionato",

			"prevDoc" => "Documento precedente",
			"nextDoc" => "Prossimo documento",
			"click_menu" => "Clicca per il menu",
			"show_options" => "Mostra le opzioni generali",
			"remove_selected" => "Cancella item selezionato",
			"import_clip" => "Trasferisci item dalla clipboard",
			"move_to_top" => "Sposat item selezionato su",
			"upload_files" => "Invia file nella clipboard",
			"minimize" => "Minimizza",
			"maximize" => "Massimizza",
			"close" => "Chiudi",
			"selectToClip" => "Seleziona item per la clipboard",
			"viewItem" => "Vedi item",
			"new" => 'NUOVO',
			"browse_file" => 'Scorri Files',
			"browse_db" => 'Scorri Records',
			"upload" => 'Invia File',			
			"editItem" => "Edita item"
		),
		"mess" => Array (
			"recIsChanged" => 'Questo record e\' cambiato.\nVuoi chiudere lo stesso?',
			"docIsChanged" => 'Il documento "%s" e cambiato.\nVuoi chiudere lo stesso?',
			"unzip" => 'Sei sicuro di aprire il file "%s"?',
			"delete" => 'Sei sicuro di voler cancellare "%s"?',
			"permChanges" => 'Hai cambiato alcuni permessi.\nPer vedere i cambiamenti chiudi Typo3 e rilancialo!',
			"gettingTree" => 'Ricerca dei file dal server.. <BR>Attendere prego ...',
			"move_into" => 'Muovi "%s" in "%s"',
			"move_after" => 'Muovi "%s" dopo "%s"',
			"copy_into" => 'Copia "%s" in "%s"',
			"copy_after" => 'Copia "%s" dopo "%s"',
			"copycb_into" => 'Copia tutti gli elementi "%s" dalla clipboard in "%s"',
			"copycb_after" => 'Copia tutti gli elementi "%s" dalla clipboard nella posizione dopo "%s"',
			"movecb_into" => 'Sposta tutti gli elementi (%s) dalla clipbard a "%s"',
			"movecb_after" => 'Sposta tutti gli elementi (%s) dalla clipboard nella posizione dopo "%s"',
			"refresh_login" => 'Il tuo account e probabilmente scaduto.\nVuoi rinnovarlo ora?',
			"deleteClip" => 'Sei sicuro di voler cancellare TUTTI gli elementi selezionati (%s) nella clipborad?',			
			"miss_field" => 'I seguenti campi non sono completi:\n',
			"miss_field_in_doc" => 'Il documento "%s" contiene campi che non sono corretti:%s\n\nNon ho salvato nulla'
		),
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Salva documento",
			"saveAllDocs" => "Salva tutti i documenti",
			"closeDoc" => "Chiudi il documento",
			"closeAllDocs" => "Chiudi tutti i documenti",
			"clearCache_pages" => "Cancella la cache della pagina",
			"clearCache_all" => "Cancella tutte le cache",
			"saveDocShow" => 'Salva il documento e visualizza la pagina',
			"saveCloseDoc" => 'Salva e chiudi documento',
			"saveCloseAllDocs" => 'Salve e chiudi tutti i documenti',
			"viewDoc" => 'Visualizza documento',
			"delete" => 'Cancella',			
			"edit" => "Edita",
			"upload" =>  "Invia files"
		),
		"err" => Array (
			"1" => "Devi salvare il record per vedere la pagina!",
			"2" => "Questo record e stato rimosso dalla memoria. Ricarica la lista.",
			"3" => '%s item(s) deve essere nel gruppo!',
			"4" => 'Non puoi aggiungere piu\' di %s item(s)',
			"5" => "Il contenuto della clipboard non pou essere inserito. Deve essere un record del database.",
			"6" => "Il contenuto della clipboard non pou essere inserito. Deve essere un file o una cartella.",
			"7" => "Il sistema e in attesa. Se il sistema non risponde dopo un po, rilanciate typo.",
			"8" => "Non puoi salvare un nuovo record che e' inserito in un altro nuovo record!"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(
			"path" => "Percorso",
			"upOneLevel" => "Su di un livello",
			"reload" => "Ricarica",
			"clear_cache" => "Cancella la cache per questa pagina",
			"no_title" => "Nessun titolo",
			"cancel" => "Cancella",
			"hidden" => "Nascosto",
			"starttime" => "Inizio",
			"endtime" => "Fine",
			"minutesHoursDaysYears" => " min| ore| gg| anni",
			"enterSearchString" => "Ricerca Stringa:",
			"enterSearchLevels" => "Questa pagina |1 livello giu'|2 livelli giu'|3 livelli giu'|4 livelli giu'",
			"noEditPermission" => "Non hai i permessi giusti per eseguire l'operazione",
			"fieldsMissing" => "Ci sono campi che non sono correttamente riempiti.I campi errati sono marcati con un ! giallo",
			"_CONTROL_" => "Controllo",
			"_PATH_" => "Percorso",
			"setFields" => "Setta campi",
			"search" => "Ricerca",
			"author" => "Autore:",
			"note" => "Note:",
			"category" => "Categoria:",
			"csv" => "Scarica CVS File",
			"menu" => "Menu:",
			"showPage" => "Vedi webpage",			
			"days" => "giorni"
		),
		"show_item.php" => Array(
			"viewItem" => "Vedi Item",
			"file" => "File",
			"dimensions" => "Dimensioni",
			"filesize" => "Grandezza",
			"ftp_area" => "Area FTP"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nuovo record",
			"after" => "dopo",
			"inside" => "dentro"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Edita",
			"submit" => "Salva",
			"saveAndClose" => "Salva e chiudi",
			"coundNot" => "Queto tipo di file non puo' essere editato.Il file deve avere una estensione tipo: %s"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Invia files",
			"submit" => "Invia files",
			"files" => "files"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Rinomina",
			"submit" => "Rinomina"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Nuova cartella",
			"submit" => "Crea cartella",
			"newfile_submit" => "Crea File",
			"newfile" => "Crea nuovo file di testo",			
			"folders" => "Cartella"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Percorso di invio errato",
			"warning" => 'Nessun percorso di invio trovato. Devi creare una cartella TEMP ("_temp_") nella radice principale prima!'
		),
		"mess" => Array(
			"redraw" => "Ricaricare la pagina cancellera i dati correnti. Vuoi proseguire?",
			"close_login" => "Probabilmente , non hai piu' bisogno di questa schermata, puoi chiderla",
			"start_typo3" => 'Vuoi far ripartire Typo?\n(questo impieghera 1-2 minuti)'
		)
	);


?>