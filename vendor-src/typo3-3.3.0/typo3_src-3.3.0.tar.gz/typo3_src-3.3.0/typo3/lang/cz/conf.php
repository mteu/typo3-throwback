<?php
		// Url to czech manual
	$typo3_help_url= "";
	$charSet = "windows-1250";						// String. Charset other than 'iso-8859-1' to use in the backend, eg. 'windows-1250'

	//czech
	$mainLang = Array (
	// ClickMenus
	// items in clickmenus
		"cm" => Array (
			"view" => "Uk�zat",
			"edit" => "Edit",
			"new" => "Nov�",
			"copy" => "Kop�rovat",
			"cut" => "Vyjmout",
			"pasteinto" => "Vlo�it do",
			"pasteafter" => "Vlo�it za",
			"select" => "Vybrat",
			"deselect" => "Zru�it v�b�r",
			"selectto" => "Vybrat do",
			"deselectto" => "Nevybrat do",
			"delete" => "Odstranit",
			"upload" => "Upload soubor�",
			"rename" => "P�ejmenovat",
			"open" => "Otev��t",
			"save" => "Ulo�it",
			"unzip" => "Rozbalit",
			"info" => "Info",
			"createnew" => "Vytvo�it nov�"
		),

	// defines which tabs are being generated. Entries in this array are significant. If a tab should not hold a textual value but an icon only, then leave this blank
		"tabs" => Array (
			"normal" => "Norm�ln�"
		),
	// defines buttons. They are made with both a normal and rollover state
		"buttons" => Array (
			"clipboard" => "Schr�nka",
			"logout" => "Logout",
			"clear" => "Smazat"
		),

	// Image Labels
	// This is image alt-texts in typo
	// prepended with "l" only!!
		"labels" => Array (
		// Tabs
			"webtabs" => "Str�nka #",
			"filetabs" => "Slo�ka #",
		// Buttons
			"logout" => "V�dy pou�ijte logout m�sto zav�en� okna!",
			"selectmode" => "Zvolit polo�ky jedn�m kliknut�m",
			"thumbmode" => "Ukazovat n�hledy",
			"thumbmode_clip" => "Ukazovat n�hledy ve schr�nce",
			"copymode" => "Kop�rovat polo�ky m�sto p�esunut�",
			"refresh" => "Znovu nahr�t strom str�nek ze serveru",
			"clearClip" => "Vyma�te zvolen� prvky ze schr�nky",
		// ClipBoard
			"clipNormal" => "Standardn� schr�nka",
			"filelist" => "P��slu�n� seznam soubor�",
			"dblist" => "P��slu�n� seznam polo�ek z datab�ze",
			"clip" => "Schr�nka obsahuje va�e zvolen� polo�ky",
			"cliptabs" => "Schr�nka �.",
			"removeItem" => "Odstranit polo�ku",
			"inverseSelection" => "Inverzn� v�b�r",
			"selectAll" => "Vybrat v�e",
			"selectNone" => "Zru�it v�b�r",
		// Document-tab
			"selected" => "Vybran�",
			"items" => "Polo�ky",
			"prevDoc" => "P�edchoz� dokument",
			"nextDoc" => "N�sleduj�c� dokument",
			"click_menu" => "Kliknut�m otev�ete menu",
			"show_options" => "Uk�zat celkov� mo�nosti",
			"remove_selected" => "Odstranit zvolen� polo�ky",
			"import_clip" => "P�en�st polo�ky ze schr�nky",
			"move_to_top" => "Posunout zvolenou polo�ku nahoru",
			"upload_files" => "Upload soubor� do schr�nky",
			"browse_file" => 'Proch�zet soubory',
			"browse_db" => 'Proch�zet z�znamy',
			"minimize" => "Minimalizovat",
			"maximize" => "Maximalizovat",
			"close" => "Zav��t",
			"selectToClip" => "Zvolit polo�ku do schr�nky",
			"viewItem" => "Uk�zat polo�ku",
			"new" => "NOV�",
			"upload" => "Upload souboru",
			"editItem" => "Editovat polo�ku"
		),
	// This is messages and comfirmations.
	// %s will be substituted by some variable from the context when shown. 
		"mess" => Array (
			"recIsChanged" => 'Tento z�znam byl zm�n�n.\nOpravdu jej chcete zav��t?',
			"docIsChanged" => 'Dokument "%s" byl zm�n�n.\nOpravdu jej chcete zav��t?',
			"unzip" => 'Opravdu chcete rozbalit soubor "%s"?',
			"delete" => 'Opravdu chcete smazat "%s"?',
			"deleteClip" => 'Opravdu chcete smazat V�ECHNY prvky (%s) ve schr�nce?',
			"permChanges" => 'Zm�nila se va�e p��stupov� pr�va.\nM�li byste zav��t a op�t otev��t Typo3, aby se zm�ny mohly projevit!',
			"gettingTree" => 'Na��t�m strom ze serveru<BR>Pros�m �ekejte...',
			"move_into" => 'P�esunout "%s" do "%s"?',
			"move_after" => 'P�esunout "%s" za "%s"?',
			"copy_into" => 'Zkop�rovat "%s" do "%s"?',
			"copy_after" => 'Zkop�rovat "%s" za "%s"?',
			"copycb_into" => 'Zkop�rovat v�echny prvky (%s) ze schr�nky do "%s"?',
			"copycb_after" => 'Zkop�rovat v�echny prvky (%s) ze schr�nky na pozici za "%s"?',
			"movecb_into" => 'P�esunout v�echny prvky (%s) ze schr�nky do "%s"?',
			"movecb_after" => 'P�esunout v�echny prvky (%s) ze schr�nky na pozici za "%s"?',
			"refresh_login" => 'Va�e p�ihl�en� pravd�podobn� vypr�elo. \nChcete jej obnovit?',
			"miss_field" => 'N�sleduj�c� pole nejsou ��dn� vypln�na:\n',
			"miss_field_in_doc" => 'Dokument "%s" obsahuje pole, kter� nejsou ��dn� vypln�na:%s\n\nNeulo�eno!'
//			"closeTypo" => 'Opravdu chcete opustit Typo3?'
		),
	// Roll menus
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Ulo�it dokument",
			"saveAllDocs" => "Ulo�it v�echny dokumenty",
			"saveCloseDoc" => "Ulo�it a zav��t dokument",
			"saveCloseAllDocs" => "Ulo�it a zav��t v�echny dokumenty",
			"saveDocShow" => 'Ulo�it dokument a uk�zat stranu',
			"closeDoc" => "Zav��t dokument",
			"closeAllDocs" => "Zav��t v�echny dokumenty",
			"viewDoc" => "Uk�zat dokument",
			"clearCache_pages" => "Smazat cache str�nky",
			"clearCache_all" => "Smazat celou cache",
			"edit" => "Editovat",
			"delete" => "Smazat",
			"upload" =>  "Upload soubor�"
		),
	// Error-messages
		"err" => Array (
			"1" => "Mus�te z�znam ulo�it, abyste mohli vid�t str�nku!",
			"2" => "Tento z�znam byly vymaz�n z pam�ti. Znovuna�t�te seznam.",
			"3" => "Ve skupin� mus� b�t alespo� %s polo�ky!",
			"4" => "Nep�id�vejte v�ce ne� %s polo�ek",
			"5" => "Obsah schr�nky n��e b�t vlo�en. Mus� to b�t z�znamy z datab�ze!",
			"6" => "Obsah schr�nky n��e b�t vlo�en. Mus� to b�t soubory nebo slo�ky!",
			"7" => "Syst�m je zanepr�zdn�n - Pros�m �ekejte. Pokud nebude syst�m za chvilku dostupn�, budete muset restartovat Typo",
			"8" => "Nem��ete ulo�it nov� z�znam, kter� je p�ipojen k jin�mun nov�mu z�znamu!"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(		// general
			"path" => "Cesta",
			"upOneLevel" => "O �rove� nahoru",
			"enterSearchString" => "Hledat:",
			"reload" => "Znovuna��st",
			"clear_cache" => "Smazat cache pro tuto stranu",
			"no_title" => "Bez titulu",
			"cancel" => "Zp�t",
			"hidden" => "Skryt�",
			"starttime" => "Start",
			"endtime" => "Konec",
			"minutesHoursDaysYears" => " min| h| dn�| rok�",
			"menu" => "Menu:",
			"days" => "dn�",
			"enterSearchLevels" => "Tato strana|1 �rove� dol�|2 �rovn� dol�|3 �rovn� dol�|4 �rovn� dol�",
			"noEditPermission" => "Bohu�el nem�te opr�vn�n� k t�to zm�n�.",
			"fieldsMissing" => "Ve formul��i jsou pole, kter� nebyla ��dn� vypln�na. Tato pole jsou ozna�ena �lut�m vyk�i�n�kem.",
			"_CONTROL_" => "Kontrola",
			"_PATH_" => "Cesta",
			"setFields" => "Nastav pole",
			"search" => "Hledej",
			"author" => "Autor:",
			"note" => "Pozn�mka:",
			"category" => "Kategorie:",
			"csv" => "Download souboru CSV",
			"showPage" => "Uk�zat stranu"			
		),
		"show_item.php" => Array(
			"viewItem" => "Vid�t polo�ku",
			"file" => "Soubor",
			"dimensions" => "Rozm�ry",
			"filesize" => "Velikost",
			"ftp_area" => "OBLAST FTP"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nov� z�znam",
			"after" => "za",
			"inside" => "dovnit�"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Upload soubor�",
			"submit" => "Upload soubor�",
			"files" => "soubor�"
		),
		"file_rename.php" => Array(
			"pagetitle" => "P�ejmenovat",
			"submit" => "P�ejmenovat"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Editovat",
			"submit" => "Ulo�it",
			"saveAndClose" => "Ulo�it a zav��t",
			"coundNot" => "Tento typ souboru nelze editovat.<BR>Soubor mus� m�t extenzi:<BR><BR> <b>%s</b>"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Nov� slo�ka",
			"submit" => "Vytvo�it slo�ky",
			"folders" => "slo�ky",
			"newfile_submit" => "Vytvo�it soubor",
			"newfile" => "Vytvo�it nov� textov� soubor"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Chyba v cest� pro upload",
			"warning" => 'Nenalezena slo�ka pro upload. M�li byste nejd��ve vytvo�it a do�asnou slo�ku ("_temp_") v ko�enov�m adres��i n�kter�ho z va�ich p�ipojen�!'
		),
		"mess" => Array(
			"redraw" => "P�ekreslen� str�nky zru�� sou�asn� data. Chcete pokra�ovat?",
			"start_typo3" => 'Chcete spustit rozhran� Typo3 te� hned? \n(Trv� to asi minutu, dv�)',
			"close_login" => "Pravd�podobn� tuto obrazovku nepot�ebujete, proto nespustili-li jste ji� Typo3, m��ete toto okno zav��t."
		)
	);
	



?>