<?php
		// Url to danish manual
	$typo3_help_url= "http://www.typo3.com/man_dk/";

		// Mainlang in danish. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"hide" => 'Skjul',
			"unhide" => 'Synligg�r',	// Tidligere "Vis"
			"view" => "Vis",
			"edit" => "Redig�r",
			"new" => "Ny",
			"copy" => "Kopier",
			"cut" => "Klip",
			"pasteinto" => "Inds�t i",
			"pasteafter" => "Inds�t efter",
			"select" => "V�lg",
			"deselect" => "Frav�lg",
			"selectto" => "V�lg hertil",
			"deselectto" => "Frav�lg hertil",
			"delete" => "Slet",
			"upload" => "Upload filer",
			"rename" => "Omd�b",
			"open" => "�bn",
			"save" => "Gem",
			"unzip" => "Unzip",
			"info" => "Info",
			"createnew" => "Opret ny"
		),
		"buttons" => Array (
			"clipboard" => "Klippebord",
			"logout" => "Afslut",
			"clear" => "T�m"
		),
		"labels" => Array (
			"allTables" => '[Alle tabeller]',
			"moreOptions" => 'Flere valg...',
			"noMatchingValue" => 'NUV�RENDE V�RDI ER IKKE TILG�NGELIG (%s)',
			"generalOptions" => "Generelle valg:",
		// Tabs
			"webtabs" => "Sidetr� #",
			"filetabs" => "Mappetr� #",
		// Buttons
			"logout" => "Husk altid at afslutte Typo3 med denne knap!",
			"selectmode" => "V�lg emner med et enkelt klik",
			"thumbmode" => "Vis miniaturer",
			"thumbmode_clip" => "Vis miniaturer p� klippebordet",
			"copymode" => "Kopier emner i stedet for blot at flytte dem",
			"refresh" => "Genindl�s tr�et fra serveren",
			"clearClip" => "Fjern udvalgte emner fra klippebordet",
		// ClipBoard
			"clipNormal" => "Standard klippebord",
			"clipNormal2" => "Normal",
			"clipNoEl" => "Ingen elementer",
			"filelist" => "Nuv�rende fil-listning",
			"dblist" => "Nuv�rende record-listning",
			"clip" => "Klippebordet indeholder dine valgte emner",
			"cliptabs" => "Klippebord #",
			"removeItem" => "Fjern emne",
			"inverseSelection" => "Invert�r markeringen",
			"selectAll" => "V�lg alle",
			"selectNone" => "V�lg ingen",
		// Document-tab
			"selected" => "Valgte",
			"items" => "Emner",
			"prevDoc" => "Forrige dokument",
			"nextDoc" => "N�ste dokument",
			"click_menu" => "Klik for menu",
			"show_options" => "Vis generelle valg",
			"remove_selected" => "Fjern valgte emner fra listen",
			"import_clip" => "Overf�r emner fra klippebordet",
			"move_to_top" => "Ryk valgte emner opad",
			"upload_files" => "Upload filer via klippebordet",
			"browse_file" => "Find filer",
			"browse_db" => "Find database elementer",
			"minimize" => "Minim�r",
			"maximize" => "Maxim�r",
			"close" => "Luk",
			"selectToClip" => "L�g emner op p� klippebordet",
			"viewItem" => "Vis emne",
			"new" => "NY",
			"upload" => "Upload fil",
			"editItem" => "Rediger emne"
		),
		"mess" => Array (
			"onChangeAlert" => 'Denne �ndring vil p�virke hvilke felter, der er tilg�ngelige i formen.\n�nsker du at gemme nu for at gendanne sk�rmbilledet?',
			"recIsChanged" => 'Denne record er �ndret.\nVil du stadig lukke den?',
			"docIsChanged" => 'Dokumentet "%s" er �ndret.\nVil du stadig lukke det?',
			"unzip" => 'Er du sikker p�, at du vil unzippe arkivet "%s"?',
			"delete" => 'Er du sikker p�, at du vil slette "%s"?',
			"deleteClip" => 'Er du sikker p�, at du vil slette ALLE elementer (%s) p� klippebordet?',
			"permChanges" => 'Der er blevet �ndret p� dine rettigheder.\nDu b�r lukke og gen�bne Typo3 for at opdatere interfacet med �ndringerne!',
			"gettingTree" => 'Henter tr�et fra serveren<BR>Vent venligst...',
			"move_into" => 'Flyt "%s" ind i "%s"?',
			"move_after" => 'Flyt "%s" til positionen efter "%s"?',
			"copy_into" => 'Kopier "%s" ind i "%s"?',
			"copy_after" => 'Kopier "%s" til positionen efter "%s"?',
			"copycb_into" => 'Kopier alle elementer (%s) fra klippebordet ind i "%s"?',
			"copycb_after" => 'Kopier alle elementer (%s) fra klippebordet til positionen efter "%s"?',
			"movecb_into" => 'Flyt alle elementer (%s) fra klippebordet ind i "%s"?',
			"movecb_after" => 'Flyt alle elementer (%s) fra klippebordet til positionen efter "%s"?',
			"refresh_login" => 'Dit login er udl�bet.\nVil du forny det nu?',
			"miss_field" => 'De f�lgende felter er ikke udfyldt korrekt:\n',
			"miss_field_in_doc" => 'Dokumentet "%s" indeholder felter, som ikke er udfyldt korrekt:%s\n\nDer er ikke gemt noget!',
			"closeTypo" => 'Vil du virkelig forlade Typo3?'
		),
		"rm" => Array (
			"menu" => "[menu]",
			"saveNewDoc" => 'Gem dokument og opret et nyt',
			"saveDoc" => "Gem dokument",
			"saveDocShow" => "Gem dokument og vis siden",
			"saveAllDocs" => "Gem alle dokumenter",
			"saveCloseDoc" => "Gem og luk dokument",
			"saveCloseAllDocs" => "Gem og luk alle dokumenter",
			"closeDoc" => "Luk dokument",
			"closeAllDocs" => "Luk alle dokumenter",
			"viewDoc" => "Vis dokument",
			"clearCache_clearCache" => "T�m cache",
			"clearCache_thisPage" => "Denne side",
			"clearCache_pages" => "T�m sidecachen",
			"clearCache_all" => "T�m hele cachen",
			"edit" => "Redig�r",
			"delete" => "Slet",
			"upload" =>  "Upload filer"
		),
		"err" => Array (
			"1" => "Du skal gemme emnet for at du kan f� vist siden!",
			"2" => "Denne record er blevet fjernet fra hukommelsen. Genindl�s listen.",
			"3" => "Der skal v�re mindst %s emne(r) i listen!",
			"4" => "Tilf�j ikke flere end %s emne(r)",
			"5" => "Indholdet fra klippebordet kan ikke inds�ttes. Det skal v�re records fra databasen!",
			"6" => "Indholdet fra klippebordet kan ikke inds�ttes. Det skal v�re filer fra serveren!",
			"7" => "Systemet er optaget - vent venligst. Hvis ikke systemet bliver tilg�ngeligt i l�bet af kort tid, s� genstart Typo",
			"8" => "Du kan ikke gemme en ny record, der er tilknyttet en anden ny record!"
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(
			"showDescriptions" => "Vis feltbeskrivelser",
			"showList" => "Vis elementliste",
			"goBack" => "G� tilbage",
			"fieldsChanged" => "Der er ikke-gemte �ndringer i felterne! Vil du forts�tte UDEN at gemme?",
			"showPalettes" => "Vis sekund�re muligheder (paletter)",
			"disableRTE" => "Sl� Formatteret Redigering fra (RTE)",
			"makeShortcut" => "Opret genvej til denne side?",
			"lockedRecord" => "Brugeren '%s' p�begyndte redigering af dette element %s siden.",
			"lockedRecord_content" => "Brugeren '%s' p�begyndte redigering af indhold p� denne side %s siden.",
			"showRecords" => "Vis elementer",
			"path" => "Sti",
			"upOneLevel" => "�t niveau op",
			"enterSearchString" => "Indtast s�geord:",
			"enterSearchLevels" => "Denne side|1 niveau ned|2 niveauer ned|3 niveuaer ned|4 niveauer ned",
			"noEditPermission" => "Beklager, men du havde ikke rettigheder til at udf�re denne �ndring.",
			"fieldsMissing" => "Der er felter, som endnu ikke er korrekt udfyldt.\nFelterne er markeret med et gult udr�bstegn.",
			"_CONTROL_" => "Kontrol",
			"_PATH_" => "Sti",
			"setFields" => "S�t felter",
			"search" => "S�g",
			"author" => "Forfatter:",
			"note" => "Note:",
			"category" => "Kategori:",
			"reload" => "Genindl�s",
			"csv" => "Download CSV fil",
			"clear_cache" => "T�m cachen for denne side",
			"no_title" => "Ingen titel",
			"cancel" => "Annuller",
			"hidden" => "Skjult",
			"starttime" => "Start",
			"endtime" => "Slut",
			"viewItem" => "Vis emne",
			"minutesHoursDaysYears" => " min| timer| dage| �r",
			"menu" => "Menu:",
			"showPage" => "Vis webside",
			"days" => "dage",
			"openInNewWindow" => "�ben i nyt vindue",
		),
		"show_item.php" => Array(
			"viewItem" => "Vis emner",
			"file" => "Fil",
			"dimensions" => "Dimensioner",
			"filesize" => "St�rrelse",
			"ftp_area" => "FTP OMR�DE"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nyt element",
			"after" => "efter",
			"inside" => "inden i"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Send filer",
			"submit" => "Send filer",
			"files" => "filer"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Omd�b",
			"submit" => "Omd�b"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Ny mappe",
			"submit" => "Opret mapper",
			"newfile_submit" => "Opret fil",
			"newfile" => "Ny tekstfil",
			"folders" => "mapper"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Rediger",
			"submit" => "Gem",
			"saveAndClose" => "Gem og luk",
			"coundNot" => "Denne filtype kan ikke redigeres. Filen skal v�re af typen: <b>%s</B>"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Upload filsti fejl",
			"warning" => 'Der blev ikke fundet noget sti til upload af billeder. Du skal oprette en mappe, TEMP ("_temp_") i roden af et af dine fil-mounts f�rst!'
		),
		"mess" => Array(
			"redraw" => "Genindl�sning af siden vil annullere de aktuelle valg. Vil du forts�tte?",
			"start_typo3" => 'Vil du starte Typo3 standard interface med det samme? \n(Det tager et minut eller to)',
			"close_login" => "Du har formentlig ikke brug for dette sk�rmbillede l�ngere, s� medmindre du endnu ikke har startet Typo3, s� kan du lukke dette vindue."
		)
	);
	



?>