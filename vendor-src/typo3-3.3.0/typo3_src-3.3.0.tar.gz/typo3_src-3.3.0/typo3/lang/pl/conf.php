<?php
		// Url to polish manual
	$typo3_help_url= "";
	$charSet = "iso-8859-2";



		// Mainlang in polish. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"view" => "Zobacz",
			"edit" => "Edytuj",
			"new" => "Nowy",
			"copy" => "Kopiuj",
			"cut" => "Wytnij",
			"pasteinto" => "Wklej W",
			"pasteafter" => "Wklej ZA",
			"select" => "Wybierz",
			"deselect" => "Skasuj wyb�r",
			"selectto" => "Wiebierz DO",
			"deselectto" => "Skasuj wyb�r DO",
			"delete" => "Usu�",
			"upload" => "Uploaduj",
			"rename" => "Zmie� nazw�",
			"open" => "Otw�rz",
			"save" => "Zapisz",
			"unzip" => "Rozpakuj",
			"info" => "Informacja",
			"createnew" => "Stw�rz nowy",
			"hide" => 'Ukryj',
			"unhide" => 'Odkryj',
		),

	// defines which tabs are being generated. Entries in this array are significant. If a tab should not hold a textual value but an icon only, then leave this blank
		"tabs" => Array (
			"normal" => "Normalnie"
		),

		"buttons" => Array (
	        "clipboard" => "Schowek",
			"logout" => "Wyloguj",
			"clear" => "Opr�nij"
		),

		
		
		
		"labels" => Array (
		// Tabs
			"webtabs" => "Widok stron #",
			"filetabs" => "Widok katalog�w #",
		// Buttons
			"logout" => "Po zako�czeniu pracy WYLOGUJ SI�!",
			"selectmode" => "Wyb�r przez pojedyncze klikni�cie",
			"thumbmode" => "Pokazuj miniatury",
			"thumbmode_clip" => "Pokazuj miniatury w Schowku",
			"copymode" => "Kopiowanie element�w zamiast przenoszenia",
			"refresh" => "Od�wie�enie widoku",
			"clearClip" => "Opr�nij Schowek z wybranych element�w",
		// Klemmbrett
			"clipNormal" => "Schowek standardowy",
			"filelist" => "Wy�wietl aktualn� zawarto�� zak�adki Pliki",
			"dblist" => "Wy�wietl aktualn� zawarto�� zak�adki Web",
			"clip" => "Schowek przechowuje wybrane elementy",
			"cliptabs" => "Schowek #",
			"removeItem" => "Usu� element",
			"inverseSelection" => "Odwr�� zaznaczenie",
			"selectAll" => "Wybierz wszystko",
			"selectNone" => "Wybierz nic",
		// Document-tab
			"selected" => "Zaznaczone",
			"items" => "Elementy",
			"prevDoc" => "Poprzedni dokument",
			"nextDoc" => "Nast�pny dokument",
			"click_menu" => "Kliknij aby zobaczy� menu",
			"show_options" => "Poka� opcje",
			"remove_selected" => "Usu� wybrane elementy",
			"import_clip" => "Wstaw elementy ze Schowka",
			"upload_files" => "Uploaduj pliki do Schowka",
			"browse_file" => 'Szukaj plik�w',
			"browse_db" => 'Szukaj rekord�w',
			"minimize" => "Minimalizuj",
			"maximize" => "Maksymalizuj",
			"close" => "Zamknij",
			"selectToClip" => "Wybierz element do Schowka",
			"move_to_top" => "Przesu� zaznaczone elementy w g�r�",
			"viewItem" => "Zobacz element",
			"new" => "NOWY",
			"upload" => "Uploaduj plik",
			"editItem" => "Edytuj element",
			"clipNormal2" => 'Normalny',
			"clipNoEl" => 'Brak pozycji',
			"generalOptions" => 'Opcje og�lne:',
			"allTables" => '[Wszystkie tablice]',
			"moreOptions" => 'Wi�cej opcji...',
			"noMatchingValue" => 'BIE��CA WARTO�� JEST NIEDOST�PNA (%s)',
		),
	// This is messages and comfirmations.
	// %s will be substituted by some variable from the context when shown. 
		"mess" => Array (
			"recIsChanged" => 'Ten rekord zmieni� si�.\nNadal chcesz go zamkn��?',
			"docIsChanged" => 'Dokument "%s" zmieni� si�.\nNadal chcesz go zamkn��?',
			"unzip" => 'Czy jeste� pewien, �e chcesz rozpakowa� plik "%s"?',
			"delete" => 'Czy jeste� pewien, �e chcesz usun�� "%s"?',
			"deleteClip" => 'Jeste� pewien, �e chcesz usun�� WSZYSTKIE wybrane elementy (%s) w Schowku?',
			"permChanges" => 'Twoje uprawnienia zosta�y zmienione.\nPowiniene� si� wylogowa� i zalogowa� ponownie aby odzwierciedli� zmiany!',
			"gettingTree" => 'Pobieram struktur� z serwera<BR>Prosz� czeka�...',
			"move_into" => 'Przenie� "%s" w "%s"?',
			"move_after" => 'Przenie� "%s" po "%s"?',
			"copy_into" => 'Kopiuj "%s" w "%s"?',
			"copy_after" => 'Kopiuj "%s" po "%s"?',
			"copycb_into" => 'Kopiuj wszystkie elementy (%s) ze Schowka do "%s"?',
			"copycb_after" => 'Kopiuj wszystkie elementy (%s) ze Schowka na pozycj� za "%s"?',
			"movecb_into" => 'Przenie� wszystkie elementy (%s) ze Schowka do "%s"?',
			"movecb_after" => 'Przenie� wszystkie elementy (%s) ze Schowka na pozycj� za "%s"?',
			"refresh_login" => 'Tw�j login prawdopodobnie straci� wa�no��. \nCzy chcesz od�wie�y�?',
			"miss_field" => 'Poni�sze pola nie s� wype�nione poprawnie:\n',
			"miss_field_in_doc" => 'Document "%s" zawiera niepoprawnie wype�nione pliki:%s\n\nZAPIS NIEUDANY!',
			"onChangeAlert" => 'Ta zmiana wp�ynie na liczb� p�l widocznych na formularzu.\nCzy chcesz zapisa� zmiany aby od�wie�y� widok?',
//			"closeTypo" => 'Do you really want to leave Typo3?'
		),
	// Roll menus
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Zapisz dokument",
			"saveAllDocs" => "Zapisz wszystkie dokumenty",
			"saveCloseDoc" => "Zapisz i zamknij dokument",
			"saveCloseAllDocs" => "Zapisz i zamknij wszystkie dokumenty",
			"closeDoc" => "Zamknij dokument",
			"closeAllDocs" => "Zamknij wszystkie dokumenty",
			"viewDoc" => "Zobacz dokument",
			"clearCache_pages" => "Wyczy�� Cache strony",
			"clearCache_all" => "Wyczy�� ca�y Cache",
			"saveDocShow" => 'Zapisz i podejrzyj dokument',
			"edit" => "Edytuj",
			"delete" => "Usu�",
			"upload" =>  "Uploaduj pliki",
			"saveNewDoc" => 'Zapisz dokument i utw�rz nowy',
			"clearCache_clearCache" => 'Wyczy�� cache',
			"clearCache_thisPage" => 'Ta strona',
		),
	// Error-messages
		"err" => Array (
			"1" => "Musisz zapisa� rekord, aby obejrze� stron�!",
			"2" => 'Ten rekord zosta� usuni�ty z pami�ci. Od�wie� list�.',
			"3" => "%s element(y) s� wymagane w grupie!",
			"4" => 'Nie dodawaj wi�cej ni� %s element�w',
			"5" => "Zawarto�� Schowka nie mo�e zosta� wstawiona. Wymagany jest rekord!",
			"6" => "Zawarto�� Schowka nie mo�e zosta� wstawiona. Wymagane s� pliki lub foldery!",
			"7" => 'System jest zaj�ty - prosz� czeka�. Je�li system nie odblokuje si� w najbli�szym czasie b�dzie wymagane ponowne uruchomienie.',
			"8" => "Nie mo�esz zapisa� nowego rekordu, kt�ry jest do��czony do innego nowego rekordu!",
		)
	);

	

	// This array contains labels used for direct output in PHP-code. 
	
	$php3Lang = Array (
		"labels" => Array(		// general
			"path" => "�cie�ka",
			"upOneLevel" => "O jeden poziom w g�r�",
			"enterSearchString" => "Wprowad� szukan� fraz�:",
			"author" => "Autor:",
			"note" => "Notatka:",
			"category" => "Kategoria:",
			"reload" => "Prze�aduj",
			"clear_cache" => "Wyczy�� cache dla tej strony",
			"no_title" => "Brak tytu�u",
			"cancel" => "Anuluj",
			"hidden" => "Ukryte",
			"starttime" => "Widoczne od",
			"endtime" => "Widoczne do",
			"minutesHoursDaysYears" => " min| godz| dni| lata",
			"menu" => "Menu:",
			"enterSearchLevels" => "Ta strona|1 poziom w d�|2 poziomy w d�|3 poziomy w d�|4 poziomy w d�",
			"noEditPermission" => "Przykro mi, ale nie masz uprawnie� do wprowadzenia tej zmiany.",
			"fieldsMissing" => "W formularzu niekt�re pola zosta�y wype�nione niepoprawnie. Te pola oznaczono ��tym symbolem wykrzyknika.",
			"_CONTROL_" => "Kontrola",
			"_PATH_" => "�cie�ka",
			"setFields" => "Ustaw pola",
			"search" => "Szukaj",
			"csv" => "Pobierz plik CVS",
			"showPage" => "Podgl�d strony",
			"days" => "dni",
			"openInNewWindow" => "Otw�rz w nowym oknie",
			"goBack" => "Powr�t",
			"makeShortcut" => "Utworzy� skr�t do tej strony?",
			"lockedRecord" => "U�ytkownik '%s' zacz�� edytowa� ten rekord %s temu.",
			"lockedRecord_content" => "U�ytkownik '%s' zacz�� edytowa� zawarto�� tej strony %s temu",
			"showRecords" => "Poka� rekordy",
			"fieldsChanged" => "Nie zapisano zawarto�ci w formularzu! Czy nadal chcesz kontynuowa�?",
			"showPalettes" => "Poka� dodatkowe opcje (palety)",
			"showDescriptions" => "Poka� opisy p�l",
			"disableRTE" => "Wy��cz edytor RTE",
			"showList" => "Poka� list� rekord�w",
		),
		"show_item.php" => Array(
			"viewItem" => "Podgl�d elementu",
			"file" => "Plik",
			"dimensions" => "Wymiary",
			"filesize" => "Wielko��",
			"ftp_area" => "Strefa FTP",
		),
		"db_new.php" => Array(
			"pagetitle" => "Nowy rekord",
			"after" => "po",
			"inside" => "w"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Uploaduj pliki",
			"submit" => "Uploaduj pliki",
			"files" => "pliki"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Zmie� nazw�",
			"submit" => "Zmie� nazw�"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Edytuj",
			"submit" => "Wy�lij",
			"saveAndClose" => "Zapisz i zamknij",
			"coundNot" => "Nie mog� edytowa� tego rodzaju plik�w.<BR>Plik musi mie� rozszerzenie:<BR><BR> <b>%s</b>"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Nowy folder",
			"submit" => "Tw�rz foldery",
			"folders" => "Foldery",
			"newfile_submit" => "Wy�lij nowy plik",
			"newfile" => "Stw�rz nowy plik"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "B��d w �cie�ce uploadowanego pliku",
			"warning" => 'Brak upload-folderu. Powiniene� stworzy� TEMP-folder ("_temp_") w katalogu g��wnym pod��czonych katalog�w!'
		),
		"mess" => Array(
			"redraw" => "Po od�wie�eniu strony zostan� utracone bie��ce zmiany. Czy kontynuowa�?",
			"start_typo3" => "Czy chcesz uruchomi� standardowy interfejs Typo3? \n(Mo�e to potrwa� kilka minut))",
			"close_login" => "Prawdopodobnie nie potrzebujesz ju� tego okienka. Je�li zalogowa�e� si� do Typo3 mo�esz zamkn�� to okno."
		)
	);



?>