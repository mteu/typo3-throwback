<?php
$LOCAL_LANG = Array (
	"default" => Array (
		"details" => "Details",
		"syntax" => "Syntax",
		"seeAlso" => "See also",
		"goBack" => "Go back",
		"fullDescription" => "See full description of table",
		"close" => "Close"
	),
	"dk" => Array (
		"details" => "Detaljer",
		"syntax" => "Format",
		"seeAlso" => "Se ogs�",
		"goBack" => "G� tilbage",
		"fullDescription" => "Se hele tabelbeskrivelsen",
		"close" => "Luk"
	),
	"de" => Array (
		"details" => "Details",
		"syntax" => "Syntax",
		"seeAlso" => "Siehe auch",
		"goBack" => "Zur�ck",
		"close" => "Schliessen",
		"fullDescription" => "Komplette Beschreibung der Tabelle ansehen",
	),
	"no" => Array (
		"details" => "Detaljer",
		"syntax" => "Format",
		"seeAlso" => "Se ogs�",
		"goBack" => "G� tilbake",
		"fullDescription" => "Se hele tabellbeskrivelsen",
		"close" => "Lukk",
	),
	"it" => Array (
		"details" => "Dettagli",
		"syntax" => "Sintassi",
		"seeAlso" => "Vedi altro",
		"goBack" => "Indietro",
		"fullDescription" => "Vedi descrizione completa della tavola",
		"close" => "Chiudi",
	),
	"fr" => Array (
		"details" => "D�tails",
		"syntax" => "Syntaxe",
		"seeAlso" => "Voir aussi",
		"goBack" => "Retour",
		"fullDescription" => "Voir la description compl�te de la table",
		"close" => "Fermer"
	),
	"pl" => Array (
		"details" => "Szczeg�y",
		"syntax" => "Sk�adnia",
		"seeAlso" => "Zobacz r�wnie�",
		"goBack" => "Powr�t",
		"fullDescription" => "Zobacz pe�ny opis tablicy",
		"close" => "Zamknij",
	),
	"es" => Array (
		"details" => "Detalles",
		"syntax" => "Sint�xis",
		"seeAlso" => "Ve�se tambi�n",
		"goBack" => "Regresar",
		"fullDescription" => "Ver descripci�n completa de la tabla",
		"close" => "Cerrar",
	),
	"nl" => Array (
		"details" => "Details",
		"syntax" => "Syntax",
		"seeAlso" => "Zie ook",
		"goBack" => "Ga terug",
		"close" => "Sluiten",
		"fullDescription" => "Zie volledige omschrijving van deze tabel.",
	),
	"cz" => Array (
		"details" => "Detaily",
		"syntax" => "Syntaxe",
		"seeAlso" => "Viz tak�",
		"goBack" => "J�t zp�t",
		"close" => "Zav��t",
	),
	"si" => Array (
		"details" => "Podrobnosti",
		"syntax" => "Sintaksa",
		"seeAlso" => "Glej tudi",
		"goBack" => "Pojdi nazaj",
		"fullDescription" => "Poglej poln opis tabele",
		"close" => "Zapri",
	),
	"fi" => Array (
		"details" => "Yksityiskohdat",
		"syntax" => "Syntaksi",
		"seeAlso" => "Katso my�s",
		"goBack" => "Takaisin",
		"fullDescription" => "Katso koko tauln kuvausta",
		"close" => "Sulje",
	),
	"tr" => Array (
		"details" => "Ayrnt�lar",
		"syntax" => "S�zdizimi",
		"seeAlso" => "G�r",
		"goBack" => "Geri git",
		"fullDescription" => "Tablonun t�m tan�t�m�n� g�r",
		"close" => "Kapat",
	)	
);
?>