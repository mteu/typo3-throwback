<?php
        // Slovenian translation by Andrej Blatnik <ablatnik@email.si>, december 2001.

        // Url to Slovenian manual
	$typo3_help_url= "";
	$charSet = "windows-1250";

		// Mainlang in Slovenian. This is overlayed on the default $mainLang
	$mainLang = Array (
		"cm" => Array (
			"view" => "Prika�i",
			"edit" => "Uredi",
			"new" => "Novo",
			"copy" => "Kopiraj",
			"cut" => "Izre�i",
			"pasteinto" => "Prilepi v",
			"pasteafter" => "Prilepi za",
			"select" => "Izberi",
			"deselect" => "Razveljavi izbor",
			"selectto" => "Izberi do",
			"deselectto" => "Razveljavi izbor do",
			"delete" => "Izbri�i",
			"upload" => 'Prenesi datoteko',
			"rename" => "Preimenuj",
			"open" => "Odpri",
			"save" => "Shrani",
			"unzip" => "Odpakiraj (unzip)",
			"info" => "Info",
			"createnew" => "Ustvari novo"
		),
		"buttons" => Array (
	        "clipboard" => "Odlo�i��e",
			"logout" => "Odjava",
			"clear" => "Razveljavi"
		),
		"labels" => Array (
		// Tabs
			"webtabs" => "Drevo strani #",
			"filetabs" => "Drevo map #",
		// Buttons
			"logout" => "Zmeraj se odjavite namesto da zaprete okno!",
			"selectmode" => "Izberi predmete z enim klikom",
			"thumbmode" => "Prika�i ikone",
			"thumbmode_clip" => "Prika�i ikone predmetov v odlo�i��u",
			"copymode" => "Kopiraj predmete namesto da jih premakne�",
			"refresh" => "Osve�i drevo iz stre�nika",
			"clearClip" => "Odstrani izbrane predmete iz odlo�i��a",
		// ClipBoard
			"clipNormal" => "Standardno odlo�i��e",
			"filelist" => "Trenutni seznam datotek",
			"dblist" => "Trenutni seznam map",
			"clip" => "V odlo�i��u so naslednji izbrani predmeti",
			"cliptabs" => "Odlo�i��e #",
			"removeItem" => "Odstrani predmet",
			"inverseSelection" => "Obrni izbor",
			"selectAll" => "Izberi vse",
			"selectNone" => "Izberi ni�",
		// Document-tab
			"selected" => "Izbrano",
			"items" => "Predmeti",
			"prevDoc" => "Prej�nji dokument",
			"nextDoc" => "Naslednji dokument",
			"click_menu" => "Klikni za meni",
			"show_options" => "Prika�i splo�ne nastavitve",
			"remove_selected" => "Odstrani izbrane predmete",
			"import_clip" => "Prenesi predmete iz odlo�i��a",
			"move_to_top" => "Premakni izbran predmet gor",
			"upload_files" => 'Prenesi datoteko v odlo�i��e',
			"minimize" => "Pomanj�aj",
			"maximize" => "Pove�aj",
			"close" => "Zapri",
			"selectToClip" => "Izberi predmet v odlo�i��e",
			"viewItem" => "Prika�i predmet",
			"new" => "NOVO",
			"upload" => "Prenesi datoteko",
			"browse_file" => 'Razi��i datoteke',
			"browse_db" => 'Razi��i zapise',
			"editItem" => "Uredi predmet"
		),
	// This is messages and comfirmations.
	// %s will be substituted by some variable from the context when shown.
		"mess" => Array (
			"recIsChanged" => 'Ta zapis je bil spremenjen.\nGa �e zmeraj �elite zapreti?',
			"docIsChanged" => 'Dokument "%s" je bil spremenjen.\nGa �e zmeraj �elite zapreti?',
			"unzip" => 'Ste prepri�ani, da �elite odpakirati arhiv "%s"?',
			"delete" => 'Ste prepri�ani, da �elite izbrisati "%s"?',
			"deleteClip" => 'Ste prepri�ani, da �elite izbrisati VSE izbrane predmete (%s) v odlo�i��u?',
			"permChanges" => 'Spremenjene so bile varnostne nastavitve.\nZapustite in znova odprite Typo3, da se bodo spremembe upo�tevale!',
			"gettingTree" => 'Obnavljam drevo iz stre�nika<BR>Prosim po�akajte...',
			"move_into" => 'Premakni "%s" v "%s"?',
			"move_after" => 'Premakni "%s" za "%s"?',
			"copy_into" => 'Kopiraj "%s" v "%s"?',
			"copy_after" => 'Kopiraj "%s" za "%s"?',
			"copycb_into" => 'Kopiraj vse predmete (%s) iz odlo�i��a v "%s"?',
			"copycb_after" => 'Kopiraj vse predmete (%s) iz odlo�i��a na pozicijo za "%s"?',
			"movecb_into" => 'Premakni vse predmete (%s) iz odlo�i��a v "%s"?',
			"movecb_after" => 'Premakni vse predmete (%s) iz odlo�i��a na pozicijo za "%s"?',
			"refresh_login" => 'Va�a prijave je potekla. \nJo �elite obnoviti?',
			"miss_field" => 'Naslednja polja niso pravilno izpolnjena:\n',
			"miss_field_in_doc" => 'Dokument "%s" vsebuje napa�no izpolnjena polja:%s\n\nNi� ni shranjeno!',
			"closeTypo" => 'Zares �elite zapustiti Typo3?'
		),
	// Roll menus
		"rm" => Array (
			"menu" => "[menu]",
			"saveDoc" => "Shrani dokument",
			"saveAllDocs" => "Shrani vse dokumente",
			"saveCloseDoc" => "Shrani in zapri dokument",
			"saveCloseAllDocs" => "Shrani in zapri vse dokumente",
			"saveDocShow" => 'Shrani dokument in poglej stran',
			"closeDoc" => "Zapri dokument",
			"closeAllDocs" => "Zapri vse dokumente",
			"viewDoc" => "Prika�i dokument",
			"clearCache_pages" => "Izprazni strani iz predpomnilnika",
			"clearCache_all" => "Izprazni celoten predpomnilnik",
			"edit" => "Uredi",
			"delete" => "Izbri�i",
			"upload" =>  "Prenesi datoteke"
		),
	// Error-messages
		"err" => Array (
			"1" => "Da si lahko ogledate stran morate najprej shraniti zapis!",
			"2" => "Ta zapis je bil odstranjen iz spomina. Osve�ite seznam.",
			"3" => "V skupini mora biti vsaj %s predmetov!",
			"4" => "Ne dodajte ve� kot %s predmetov",
			"5" => "Vsebine odlo�i��a ne morete vstaviti. To morajo biti zapisi iz baze podatkov!",
			"6" => "Vsebine odlo�i��a ne morete vstaviti. To morajo biti datoteke ali mape!",
			"7" => "Sistem je zaposlen - Prosimo po�akajte. �e sistem kmalu ne postane dosegljiv ponovno po�enite Typo3",
			"8" => "Ne morete shraniti novega zapisa, ki je pripet drugemu novemu zapisu!"
		)
	);

// This array contains labels used for direct output in PHP-code.

	$php3Lang = Array (
		"labels" => Array(		// general
			"enterSearchLevels" => "Ta stran je |1 nivo ni�je|2 nivoja ni�je|3 nivoje ni�je|4 nivoje ni�je",
			"noEditPermission" => "Nimate privilegijev, potrebnih za vnos te spremembe.",
			"fieldsMissing" => "V obrazcu so polja, ki jih �e niste pravilno izpolnili. Ozna�ena so z rumenim klicajem.",
			"_CONTROL_" => "Kontrola",
			"_PATH_" => "Pot",
			"setFields" => "Nastavi polja",
			"search" => "I��i",
			"csv" => "Prenesi CSV datoteko",
			"showPage" => "Poglej stran",
			"path" => "Pot",
			"upOneLevel" => "Nivo vi�je",
			"enterSearchString" => "Vpi�ite iskalni niz:",
			"author" => "Avtor:",
			"note" => "Opomba:",
			"category" => "Kategorija:",
			"reload" => "Osve�i",
			"clear_cache" => "Izprazni predpomnilnik za to stran",
			"no_title" => "Brez naslova",
			"cancel" => "Prekli�i",
			"hidden" => "Skrito",
			"starttime" => "Za�etek",
			"endtime" => "Konec",
			"minutesHoursDaysYears" => " min| ura| dan| leto",
			"menu" => "Menu:",
			"days" => "dnevi"
		),
		"show_item.php" => Array(
			"viewItem" => "Prika�i predmet",
			"file" => "Datoteka",
			"dimensions" => "Dimenzije",
			"filesize" => "Velikost",
			"ftp_area" => "FTP PODRO�JE"
		),
		"db_new.php" => Array(
			"pagetitle" => "Nov zapis",
			"after" => "za",
			"inside" => "v"
		),
		"file_upload.php" => Array(
			"pagetitle" => "Prenesi datoteke",
			"submit" => "Prenesi datoteke",
			"files" => "datoteke"
		),
		"file_rename.php" => Array(
			"pagetitle" => "Preimenuj",
			"submit" => "Preimenuj"
		),
		"file_edit.php" => Array(
			"pagetitle" => "Uredi",
			"submit" => "Shrani",
			"saveAndClose" => "Shrani in zapri",
			"coundNot" => "Te datoteke ne morete urejati.<BR>Datoteka mora imeti kon�nico:<BR><BR> <b>%s</b>"
		),
		"file_newfolder.php" => Array(
			"pagetitle" => "Nove mape",
			"submit" => "Ustvari mape",
			"folders" => "mape",
			"newfile_submit" => "Ustvari datoteko",
			"newfile" => "Ustvari novo tekstovno datoteko"
		),
		"file_clipupload.php" => Array(
			"warning_head" => "Napaka poti za prenos.",
			"warning" => 'Ni mape za prenos. Ustvarite TEMP-mapo ("_temp_") v svoji osnovni mapi!'
		),
		"mess" => Array(
			"redraw" => "Osve�itev strani bo zavrgla vse trenutne podatke. �elite nadaljevati?",
			"start_typo3" => '�elite takoj pognati obi�ajni Typo3 vmesnik? \n(Traja minutko ali dve)',
			"close_login" => "Tega okna najbr� ne potrebujete ve�.  �e ste �e pognali Typo3, ga lahko zaprete."
   		)
	);

?>