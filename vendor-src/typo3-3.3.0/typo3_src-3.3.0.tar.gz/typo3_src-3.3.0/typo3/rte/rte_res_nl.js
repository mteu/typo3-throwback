var L_CANCEL_TEXT = "Annuleer";
var L_INSERT_TEXT = "Invoegen";
//var L_LINKIMGBORDER_TEXT = "Toon een rand om afbeeldingslink.";
//var L_LINKSELECT_TEXT = "Selecteer een community pagina: ";
//var L_LINKSELECTPAGE_TEXT = "Selecteer Pagina";
//var L_LINKWEB_TEXT = "of geef het adres van de webpagina in op het internet: ";
var L_PUTITLEBGCOLOR_TEXT = "Bepaal Achtergrond Kleur";
var L_PUTITLEFONTFACE_TEXT = "Bepaal Font Stijl";
var L_PUTITLEFONTSIZE_TEXT = "Bepaal Font Grootte";
var L_PUTITLEIMAGE_TEXT = "Invoegen / Bewerken Afbeelding";
var L_PUTITLELINK_TEXT = "Invoegen / Bewerken Link";
var L_PUTITLENEWTABLE_TEXT = "Invoegen / Bewerken Tabel";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Bepaal Alinea Stijl";
var L_PUTITLECLASS_TEXT = "Bepaal Alinea Class";
var L_PUTITLETEXTCOLOR_TEXT = "Bepaal Tekst Kleur";
var L_PUTITLEEMOTICON_TEXT = "Invoegen Symbool";
var L_STYLEFORMATTED_TEXT = "Reeds opgemaakt";
//var L_STYLECLASS_TEXT = "Tekst met Class";
var L_STYLEHEADING_TEXT = "Hoofd";
var L_STYLENORMAL_TEXT = "Normaal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Achtergrond";
var L_TABLEBORDERS_TEXT = "Randen";
var L_TABLEINPUTBGCOLOR_TEXT = "Achtergrond Kleur: ";
var L_TABLEINPUTBGIMGURL_TEXT = "Achtergrond Afbeelding URL: ";
var L_TABLEINPUTBORDER_TEXT = "Achtergrond Breedte: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Rand Kleur: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Cell Padding: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Cell Spacing: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Kolommen: ";
var L_TABLEINPUTROWS_TEXT = "Rijen: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Padding and Spacing";
var L_TABLEROWSANDCOLS_TEXT = "Rijen en Kolommen";
var L_TABLEINSERTROW_TEXT = "Rij invoegen";
var L_TABLEINSERTCELL_TEXT = "Kolom invoegen";
var L_TABLEINSERT_TEXT = "Tabel invoegen";
var L_TABLEUPDATE_TEXT = "Tabel actualiseren";
var L_TABLENEW_TEXT = "Nieuwe Tabel";
var L_TABLEEDIT_TEXT = "Tabel bewerken";
var L_TIPB_TEXT = "Vet";
var L_TIPBGCOLOR_TEXT = "Achtergrond KLeur";
var L_TIPCJ_TEXT = "Gecentreerd uitvullen";
var L_TIPCOPY_TEXT = "Kopieer tekst";
var L_TIPCUT_TEXT = "Knip tekst";
var L_TIPDINDENT_TEXT = "Inspringen verkleinen";
var L_TIPFGCOLOR_TEXT = "Tekst Kleur";
var L_TIPFSIZE_TEXT = "Font Grootte";
var L_TIPFSTYLE_TEXT = "Font Stijl";
var L_TIPI_TEXT = "Schuinschrift";
var L_TIPIINDENT_TEXT = "Inspringen vergroten";
var L_TIPLINE_TEXT = "Regel invoegen";
var L_TIPLINK_TEXT = "Link invoegen";
var L_TIPLJ_TEXT = "Links uitvullen";
var L_TIPOL_TEXT = "Genummerde lijst";
var L_TIPP_TEXT = "Alinea Lijst";
var L_TIPPASTE_TEXT = "Plak tekst";
var L_TIPPICTURE_TEXT = "Afbeelding invoegen";
var L_TIPRJ_TEXT = "Recht uitvullen";
var L_TIPTABLE_TEXT = "Tabel invoegen";
var L_TIPU_TEXT = "Onderstrepen";
var L_TIPUL_TEXT = "Lijst met bullets";
var L_TIPEMOTICON_TEXT = "Symbolen";
var L_TIPCLASS_TEXT = "Class";
var L_MODETITLE_TEXT = "Geavanceerde HTML Modus";
var L_MODETITLE_TEXT = "Bron code";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Ander Font...";
var L_CUSTOMFONTENTRY_TEXT = "Voer de naam van je font in:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Kolommen";
var L_TBDATALABEL_TEXT   = 'Toevoegen van een plaatsvervanger voor de geselecteerde kolom.';
var L_DEFAULTHTML_TEXT = "<DIV></DIV>";
var L_REMOVECLASS_TEXT = "Verwijder Karakter Stijl";
var L_REMOVEALLHTML_TEXT = "Verwijder alle HTML opmaak"; 
var L_TARGETTAGCLASS_TEXT = "Doel HTML-tag"; 
var L_TIPUSER_TEXT = "Voeg gebruikers elementen in";
var L_PUTITLEUSER_TEXT = "Meerdere elementen";
var L_OPTIONS = "Opties";
var L_TIPCOPY_TEXT2 = "Kopieer";
var L_TIPCUT_TEXT2 = "Knip";
var L_TIPPASTE_TEXT2 = "Plak";










// THESE ARE NEW AND NOT TRANSLATED:

