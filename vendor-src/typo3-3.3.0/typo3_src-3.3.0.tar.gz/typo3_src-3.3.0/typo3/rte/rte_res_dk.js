var L_CANCEL_TEXT = "Annull�r";
var L_INSERT_TEXT = "Inds�t";
// var L_LINKIMGBORDER_TEXT = "?????????????";
// var L_LINKSELECT_TEXT = "????????????????: ";
// var L_LINKSELECTPAGE_TEXT = "??????????????";
// var L_LINKWEB_TEXT = "?????????????";
var L_PUTITLEBGCOLOR_TEXT = "V�lg baggrundsfarve";
var L_PUTITLEFONTFACE_TEXT = "V�lg skrifttype";
var L_PUTITLEFONTSIZE_TEXT = "V�lg skriftst�rrelse";
var L_PUTITLEIMAGE_TEXT = "Inds�t/Redig�r billede";
var L_PUTITLELINK_TEXT = "Inds�t/Redig�r link";
var L_PUTITLENEWTABLE_TEXT = "Inds�t/Redig�r tabel";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "V�lg afsnitstypografi";
var L_PUTITLECLASS_TEXT = "V�lg tegntypografi";
var L_PUTITLETEXTCOLOR_TEXT = "V�lg skriftfarve";
var L_PUTITLEEMOTICON_TEXT = "Inds�t symbol";
var L_STYLEFORMATTED_TEXT = "Preformatteret";
// var L_STYLECLASS_TEXT = "??????????????";
var L_STYLEHEADING_TEXT = "Overskrift ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Baggrund";
var L_TABLEBORDERS_TEXT = "Kanter";
var L_TABLEINPUTBGCOLOR_TEXT = "Baggrundsfarve: ";
var L_TABLEINPUTBGIMGURL_TEXT = "???????????????";
var L_TABLEINPUTBORDER_TEXT = "Kantbredde:";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Kantfarve: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Cellemargen: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Celleafstand: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Kolonner: ";
var L_TABLEINPUTROWS_TEXT = "R�kker: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Margen og afstand";
var L_TABLEROWSANDCOLS_TEXT = "R�kker og kolonner";
var L_TABLEINSERTROW_TEXT = "Inds�t r�kke";
var L_TABLEINSERTCELL_TEXT = "Inds�t kolonne";
var L_TABLEINSERT_TEXT = "Inds�t tabel";
var L_TABLEUPDATE_TEXT = "Opdat�r tabel";
var L_TABLENEW_TEXT = "Ny tabel";
var L_TABLEEDIT_TEXT = "Redig�r tabel";
var L_TIPB_TEXT = "Fed";
var L_TIPBGCOLOR_TEXT = "Baggrundsfarve";
var L_TIPCJ_TEXT = "Centreret";
var L_TIPCOPY_TEXT = "Kopier tekst";
var L_TIPCUT_TEXT = "Klip tekst";
var L_TIPDINDENT_TEXT = "Fjern indrykning";
var L_TIPFGCOLOR_TEXT = "Skriftfarve";
var L_TIPFSIZE_TEXT = "Skriftst�rrelse";
var L_TIPFSTYLE_TEXT = "Skrifttype";
var L_TIPI_TEXT = "Kursiv";
var L_TIPIINDENT_TEXT = "Tilf�j indrykning";
var L_TIPLINE_TEXT = "Inds�t linie";
var L_TIPLINK_TEXT = "Inds�t link";
var L_TIPLJ_TEXT = "Venstrejustering";
var L_TIPOL_TEXT = "Nummerliste";
var L_TIPP_TEXT = "Afsnitstypografi";
var L_TIPPASTE_TEXT = "Inds�t tekst";
var L_TIPPICTURE_TEXT = "Inds�t billede";
var L_TIPRJ_TEXT = "H�jrejustering";
var L_TIPTABLE_TEXT = "Inds�t tabel";
var L_TIPU_TEXT = "Understregning";
var L_TIPUL_TEXT = "Punktliste";
var L_TIPEMOTICON_TEXT = "Symboler";
var L_TIPCLASS_TEXT = "Tegntypografi";
var L_MODETITLE_TEXT = "Kildekode";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Anden skrifttype...";
var L_CUSTOMFONTENTRY_TEXT = "Indtast navnet p� skrifttypen:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Kolonner";
var L_TBDATALABEL_TEXT   = "Tilf�j en midlertidig erstatning for den valgte kolonne.";

var L_DEFAULTHTML_TEXT = "<DIV></DIV>";




var L_REMOVECLASS_TEXT = "Fjern tegntypografi";	// Added!!!
var L_REMOVEALLHTML_TEXT = "Fjern al HTML formattering"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "Aktuelle HTML-tag";	// Added!!!





// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Valg";
var L_TIPCOPY_TEXT2 = "Kopier";
var L_TIPCUT_TEXT2 = "Klip";
var L_TIPPASTE_TEXT2 = "Inds�t";

