var L_CANCEL_TEXT = "Cancel";
var L_INSERT_TEXT = "Insert";
//var L_LINKIMGBORDER_TEXT = "Display a border around the image link";
//var L_LINKSELECT_TEXT = "Select a community page: ";
//var L_LINKSELECTPAGE_TEXT = "Select Page";
//var L_LINKWEB_TEXT = "or type in a URL to a page on the Web: ";
var L_PUTITLEBGCOLOR_TEXT = "Set the Background Color";
var L_PUTITLEFONTFACE_TEXT = "Set the Font Style";
var L_PUTITLEFONTSIZE_TEXT = "Set The Font Size";
var L_PUTITLEIMAGE_TEXT = "Insert/ Edit Image";
var L_PUTITLELINK_TEXT = "Insert/ Edit a link";
var L_PUTITLENEWTABLE_TEXT = "Create/ Edit Table";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Set the Paragraph Style";
var L_PUTITLECLASS_TEXT = "Set the Character Style";
var L_PUTITLETEXTCOLOR_TEXT = "Set the Text Color";
var L_PUTITLEEMOTICON_TEXT = "Insert Symbol";
var L_STYLEFORMATTED_TEXT = "Preformatted";
//var L_STYLECLASS_TEXT = "Text with Class";
var L_STYLEHEADING_TEXT = "Heading ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Background";
var L_TABLEBORDERS_TEXT = "Borders";
var L_TABLEINPUTBGCOLOR_TEXT = "Background Color: ";
var L_TABLEINPUTBGIMGURL_TEXT = "Background Image URL: ";
var L_TABLEINPUTBORDER_TEXT = "Border Width: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Border Color: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Cell Padding: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Cell Spacing: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Columns: ";
var L_TABLEINPUTROWS_TEXT = "Rows: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Padding and Spacing";
var L_TABLEROWSANDCOLS_TEXT = "Rows and Columns";
var L_TABLEINSERTROW_TEXT = "Insert Row";
var L_TABLEINSERTCELL_TEXT = "Insert Column";
var L_TABLEINSERT_TEXT = "Insert Table";
var L_TABLEUPDATE_TEXT = "Update Table";
var L_TABLENEW_TEXT = "New Table";
var L_TABLEEDIT_TEXT = "Edit Table";
var L_TIPB_TEXT = "Bold";
var L_TIPBGCOLOR_TEXT = "Background Color";
var L_TIPCJ_TEXT = "Center Justify";
var L_TIPCOPY_TEXT = "Copy Text";
var L_TIPCUT_TEXT = "Cut Text";
var L_TIPDINDENT_TEXT = "Decrease Indent";
var L_TIPFGCOLOR_TEXT = "Text Color";
var L_TIPFSIZE_TEXT = "Font Size";
var L_TIPFSTYLE_TEXT = "Font Style";
var L_TIPI_TEXT = "Italic";
var L_TIPIINDENT_TEXT = "Increase Indent";
var L_TIPLINE_TEXT = "Insert Line";
var L_TIPLINK_TEXT = "Insert Link";
var L_TIPLJ_TEXT = "Left Justify";
var L_TIPOL_TEXT = "Numbered List";
var L_TIPP_TEXT = "Paragraph Style";
var L_TIPPASTE_TEXT = "Paste Text";
var L_TIPPICTURE_TEXT = "Insert Picture";
var L_TIPRJ_TEXT = "Right Justify";
var L_TIPTABLE_TEXT = "Insert Table";
var L_TIPU_TEXT = "Underline";
var L_TIPUL_TEXT = "Bulleted List";
var L_TIPEMOTICON_TEXT = "Symbols";
var L_TIPCLASS_TEXT = "Character Style";
var L_MODETITLE_TEXT = "Source code";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Other Font...";
var L_CUSTOMFONTENTRY_TEXT = "Enter the name of your font:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Columns";
var L_TBDATALABEL_TEXT   = 'Add a placeholder for the selected column.';

var L_DEFAULTHTML_TEXT = "<DIV></DIV>";




var L_REMOVECLASS_TEXT = "Remove Character Style";	// Added!!!
var L_REMOVEALLHTML_TEXT = "Remove all HTML formatting"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "Target HTML-tag";	// Added!!!












// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Options";
var L_TIPCOPY_TEXT2 = "Copy";
var L_TIPCUT_TEXT2 = "Cut";
var L_TIPPASTE_TEXT2 = "Paste";

