var L_CANCEL_TEXT = "Prekli�i";
var L_INSERT_TEXT = "Vstavi";
//var L_LINKIMGBORDER_TEXT = "Prika�i obrobo okrog slikovne povezave";
//var L_LINKSELECT_TEXT = "Izberi stran skupine: ";
//var L_LINKSELECTPAGE_TEXT = "Izberi stran";
//var L_LINKWEB_TEXT = "ali vpi�i naslov strani v spletu: ";
var L_PUTITLEBGCOLOR_TEXT = "Dolo�i barvo ozadja";
var L_PUTITLEFONTFACE_TEXT = "Dolo�i slog pisave";
var L_PUTITLEFONTSIZE_TEXT = "Dolo�i velikost pisave";
var L_PUTITLEIMAGE_TEXT = "Vstavi/ Uredi sliko";
var L_PUTITLELINK_TEXT = "Vstavi/ Uredi povezavo";
var L_PUTITLENEWTABLE_TEXT = "Ustvari/ Uredi tabelo";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Dolo�i slog odstavka";
var L_PUTITLECLASS_TEXT = "Dolo�i slog �rk";
var L_PUTITLETEXTCOLOR_TEXT = "Dolo�i barvo besedila";
var L_PUTITLEEMOTICON_TEXT = "Vstavi simbol";
var L_STYLEFORMATTED_TEXT = "Predoblikovano";
//var L_STYLECLASS_TEXT = "Razred oblike besedila";
var L_STYLEHEADING_TEXT = "Naslov ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Ozadje";
var L_TABLEBORDERS_TEXT = "Robovi";
var L_TABLEINPUTBGCOLOR_TEXT = "Barva ozadja: ";
var L_TABLEINPUTBGIMGURL_TEXT = "URL slike za ozadje: ";
var L_TABLEINPUTBORDER_TEXT = "Debelina robu: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Barva robu: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Prostor okrog celice: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Prostor med celicami: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Stolpci: ";
var L_TABLEINPUTROWS_TEXT = "Vrstice: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Okrog in med celicami";
var L_TABLEROWSANDCOLS_TEXT = "Vrstice in stolpci";
var L_TABLEINSERTROW_TEXT = "Vstavi vrstico";
var L_TABLEINSERTCELL_TEXT = "Vstavi stolpec";
var L_TABLEINSERT_TEXT = "Vstavi tabelo";
var L_TABLEUPDATE_TEXT = "Osve�i tabelo";
var L_TABLENEW_TEXT = "Nova tabela";
var L_TABLEEDIT_TEXT = "Uredi tabelo";
var L_TIPB_TEXT = "Krepko";
var L_TIPBGCOLOR_TEXT = "Barva ozadja";
var L_TIPCJ_TEXT = "Sredinska poravnava";
var L_TIPCOPY_TEXT = "Kopiraj besedilo";
var L_TIPCUT_TEXT = "Izre�i besedilo";
var L_TIPDINDENT_TEXT = "Zman�aj umik";
var L_TIPFGCOLOR_TEXT = "Barva besedila";
var L_TIPFSIZE_TEXT = "Velikost pisave";
var L_TIPFSTYLE_TEXT = "Slog";
var L_TIPI_TEXT = "Po�evno";
var L_TIPIINDENT_TEXT = "Pove�aj umik";
var L_TIPLINE_TEXT = "Vstavi vrstico";
var L_TIPLINK_TEXT = "Vstavi povezavo";
var L_TIPLJ_TEXT = "Leva poravnava";
var L_TIPOL_TEXT = "Seznam po �t.";
var L_TIPP_TEXT = "Slog odstavka";
var L_TIPPASTE_TEXT = "Prilepi besedilo";
var L_TIPPICTURE_TEXT = "Vstavi sliko";
var L_TIPRJ_TEXT = "Desna poravnava";
var L_TIPTABLE_TEXT = "Vstavi tabelo";
var L_TIPU_TEXT = "Pod�rtano";
var L_TIPUL_TEXT = "Seznam po to�kah";
var L_TIPEMOTICON_TEXT = "Simboli";
var L_TIPCLASS_TEXT = "Slog �rk";
var L_MODETITLE_TEXT = "Izvorna koda";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Druga pisava...";
var L_CUSTOMFONTENTRY_TEXT = "Vpi�ite ime svoje pisave:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Stolpci";
var L_TBDATALABEL_TEXT   = 'Fiksiraj velikost izbranega stolpca.';

var L_DEFAULTHTML_TEXT = "<DIV></DIV>";



var L_REMOVECLASS_TEXT = "Odstrani slog �rk";	// Added!!!
var L_REMOVEALLHTML_TEXT = "Odstrani vso HTML oblikovanje"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "Ciljni HTML-element";	// Added!!!















// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Options";
var L_TIPCOPY_TEXT2 = "Copy";
var L_TIPCUT_TEXT2 = "Cut";
var L_TIPPASTE_TEXT2 = "Paste";

