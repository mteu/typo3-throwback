var L_CANCEL_TEXT = "Zru�it";
var L_INSERT_TEXT = "Vlo�it";
//var L_LINKIMGBORDER_TEXT = "Zobrazit okraj okolo odkazu na obr�zek";
//var L_LINKSELECT_TEXT = "Zvolit komunitn� stranu: ";
//var L_LINKSELECTPAGE_TEXT = "Zvolit stranu";
//var L_LINKWEB_TEXT = "nebo napi�te URL strany na webu: ";
var L_PUTITLEBGCOLOR_TEXT = "Nastavit barvu pozad�";
var L_PUTITLEFONTFACE_TEXT = "Nastavit styl p�sma";
var L_PUTITLEFONTSIZE_TEXT = "Nastavit velikost p�sma";
var L_PUTITLEIMAGE_TEXT = "Vlo�it / Editovat obr�zek";
var L_PUTITLELINK_TEXT = "Vlo�it / Editovat odkaz";
var L_PUTITLENEWTABLE_TEXT = "Vytvo�it / Editovat tabulku";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Nastavit styl odstavce";
var L_PUTITLECLASS_TEXT = "Nastavit styl znaku";
var L_PUTITLETEXTCOLOR_TEXT = "Nastavit barvu textu";
var L_PUTITLEEMOTICON_TEXT = "Vlo�it symbol";
var L_STYLEFORMATTED_TEXT = "Preform�tovan�";
//var L_STYLECLASS_TEXT = "Text s t��dou";
var L_STYLEHEADING_TEXT = "Nadpis ";
var L_STYLENORMAL_TEXT = "Norm�ln�";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Pozad�";
var L_TABLEBORDERS_TEXT = "Okraje";
var L_TABLEINPUTBGCOLOR_TEXT = "Barva pozad�: ";
var L_TABLEINPUTBGIMGURL_TEXT = "URL obr�zku na pozad�: ";
var L_TABLEINPUTBORDER_TEXT = "S�la okraje: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Barva okraje: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Odstup bun�k: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Mezery mezi bu�kami: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Sloupce: ";
var L_TABLEINPUTROWS_TEXT = "��dky: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Odstup a mezery";
var L_TABLEROWSANDCOLS_TEXT = "��dky a sloupce";
var L_TABLEINSERTROW_TEXT = "Vlo�it ��dku";
var L_TABLEINSERTCELL_TEXT = "Vlo�it sloupec";
var L_TABLEINSERT_TEXT = "Vlo�it tabulku";
var L_TABLEUPDATE_TEXT = "Aktualizovat tabulku";
var L_TABLENEW_TEXT = "Nov� tabulka";
var L_TABLEEDIT_TEXT = "Editovat tabulku";
var L_TIPB_TEXT = "Tu�n�";
var L_TIPBGCOLOR_TEXT = "Barva pozad�";
var L_TIPCJ_TEXT = "Zarovnat na st�ed";
var L_TIPCOPY_TEXT = "Kop�rovat text";
var L_TIPCUT_TEXT = "Vyjmout text";
var L_TIPDINDENT_TEXT = "Zmen�it odsazen�";
var L_TIPFGCOLOR_TEXT = "Barva textu";
var L_TIPFSIZE_TEXT = "Velikost p�sma";
var L_TIPFSTYLE_TEXT = "Styl p�sma";
var L_TIPI_TEXT = "Kurz�va";
var L_TIPIINDENT_TEXT = "Zv�t�it odsazen�";
var L_TIPLINE_TEXT = "Vlo�it ��dku";
var L_TIPLINK_TEXT = "Vlo�it odkaz";
var L_TIPLJ_TEXT = "Zarovnat vlevo";
var L_TIPOL_TEXT = "��slovan� seznam";
var L_TIPP_TEXT = "Styl odstavce";
var L_TIPPASTE_TEXT = "Vlo�it text";
var L_TIPPICTURE_TEXT = "Vlo�it obr�zek";
var L_TIPRJ_TEXT = "Zarovn�n� vpravo";
var L_TIPTABLE_TEXT = "Vlo�it tabulku";
var L_TIPU_TEXT = "Podtr�en�";
var L_TIPUL_TEXT = "Seznam s odr�kami";
var L_TIPEMOTICON_TEXT = "Symboly";
var L_TIPCLASS_TEXT = "Styl znaku";
var L_MODETITLE_TEXT = "Zdrojov� text";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Jin� p�smo...";
var L_CUSTOMFONTENTRY_TEXT = "Napi�te jm�no va�eho p�sma:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Sloupce";
var L_TBDATALABEL_TEXT   = 'P�idejte placeholder pro zvolen� sloupec.';
var L_DEFAULTHTML_TEXT = "<DIV></DIV>";


var L_REMOVECLASS_TEXT = "Odstranit styl znaku";  // Added!!!
var L_REMOVEALLHTML_TEXT = "Odstranit v�echno HTML form�tov�n�"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "C�lov� HTML-tag";  // Added!!!












// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Options";
var L_TIPCOPY_TEXT2 = "Copy";
var L_TIPCUT_TEXT2 = "Cut";
var L_TIPPASTE_TEXT2 = "Paste";

