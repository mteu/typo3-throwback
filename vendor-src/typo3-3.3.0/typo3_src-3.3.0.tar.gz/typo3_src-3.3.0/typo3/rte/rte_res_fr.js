var L_CANCEL_TEXT = "Annuler";
var L_INSERT_TEXT = "Ins�rer";
//var L_LINKIMGBORDER_TEXT = "Afficher une bordure autour des images (liens)";
//var L_LINKSELECT_TEXT = "S�l�ctionnez un page de communaut�: ";
//var L_LINKSELECTPAGE_TEXT = "S�l�ctionnez une page";
//var L_LINKWEB_TEXT = "ou entrer une URL vers une page sur Internet: ";
var L_PUTITLEBGCOLOR_TEXT = "Configurer la couleur de fond";
var L_PUTITLEFONTFACE_TEXT = "Configurer le style de font";
var L_PUTITLEFONTSIZE_TEXT = "Configurer la taille de la font";
var L_PUTITLEIMAGE_TEXT = "Ins�rer/ �diter une image";
var L_PUTITLELINK_TEXT = "Ins�rer/ �diter un liens";
var L_PUTITLENEWTABLE_TEXT = "Cr�er/ �diter un lien";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Configuer le style de paragraphe";
var L_PUTITLECLASS_TEXT = "Configurer le style de caract�re";
var L_PUTITLETEXTCOLOR_TEXT = "Configurer la couleur du texte";
var L_PUTITLEEMOTICON_TEXT = "Ins�rer un symbole";
var L_STYLEFORMATTED_TEXT = "Pr�format�";
//var L_STYLECLASS_TEXT = "Texte avec Class";
var L_STYLEHEADING_TEXT = "Titre ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Fond";
var L_TABLEBORDERS_TEXT = "Bord";
var L_TABLEINPUTBGCOLOR_TEXT = "Couleur de fond: ";
var L_TABLEINPUTBGIMGURL_TEXT = "Image de fond (URL): ";
var L_TABLEINPUTBORDER_TEXT = "Largeur des bords: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Couleur des bords: ";
var L_TABLEINPUTCELLPADDING_TEXT = "D�calement des cellules: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Espacement des cellules: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Colonnes: ";
var L_TABLEINPUTROWS_TEXT = "Lignes: ";
var L_TABLEPADDINGANDSPACING_TEXT = "D�calement et espacement";
var L_TABLEROWSANDCOLS_TEXT = "Lignes et colonnes";
var L_TABLEINSERTROW_TEXT = "Ins�rer une ligne";
var L_TABLEINSERTCELL_TEXT = "Ins�rer une colonne";
var L_TABLEINSERT_TEXT = "Ins�rer un tableau";
var L_TABLEUPDATE_TEXT = "Mettre � jour le tableau";
var L_TABLENEW_TEXT = "Nouveau tableau";
var L_TABLEEDIT_TEXT = "Editer le tableau";
var L_TIPB_TEXT = "Gras";
var L_TIPBGCOLOR_TEXT = "Couleur de fond";
var L_TIPCJ_TEXT = "Justifi� centr�";
var L_TIPCOPY_TEXT = "Copier le texte";
var L_TIPCUT_TEXT = "Couper le texte";
var L_TIPDINDENT_TEXT = "Diminuer l'identation";
var L_TIPFGCOLOR_TEXT = "Couleur de texte";
var L_TIPFSIZE_TEXT = "Taille de la font";
var L_TIPFSTYLE_TEXT = "Style de la font";
var L_TIPI_TEXT = "Italique";
var L_TIPIINDENT_TEXT = "Augmenter l'identation";
var L_TIPLINE_TEXT = "Ins�rer une ligne";
var L_TIPLINK_TEXT = "Ins�rer un lien";
var L_TIPLJ_TEXT = "Justifi� gauche";
var L_TIPOL_TEXT = "Liste num�rot�e";
var L_TIPP_TEXT = "Style de paragraphe";
var L_TIPPASTE_TEXT = "Coller le texte";
var L_TIPPICTURE_TEXT = "Ins�rer une image";
var L_TIPRJ_TEXT = "Justification droite";
var L_TIPTABLE_TEXT = "Ins�rer un tableau";
var L_TIPU_TEXT = "Soulign�";
var L_TIPUL_TEXT = "Liste";
var L_TIPEMOTICON_TEXT = "Symboles";
var L_TIPCLASS_TEXT = "Style de caract�res";
var L_MODETITLE_TEXT = "Code source";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Autre font...";
var L_CUSTOMFONTENTRY_TEXT = "Entrer le nom de votre font:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Colonne";
var L_TBDATALABEL_TEXT   = 'Ajouter le support pour la colonne s�l�ctionn�e.';

var L_DEFAULTHTML_TEXT = "<DIV></DIV>";




var L_REMOVECLASS_TEXT = "Supprimer les styles de caract�res";	// Added!!!
var L_REMOVEALLHTML_TEXT = "Supprimer toute la mise en page HTML"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "Tag cible HTML";	// Added!!!











// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Options";
var L_TIPCOPY_TEXT2 = "Copy";
var L_TIPCUT_TEXT2 = "Cut";
var L_TIPPASTE_TEXT2 = "Paste";

