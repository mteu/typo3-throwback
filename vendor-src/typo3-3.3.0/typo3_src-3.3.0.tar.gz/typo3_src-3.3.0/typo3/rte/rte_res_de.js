var L_CANCEL_TEXT = "Abbrechen";
var L_INSERT_TEXT = "Einf�gen";
//var L_LINKIMGBORDER_TEXT = "Rahmen um Bildverweise anzeigen";
//var L_LINKSELECT_TEXT = "Community-Seite ausw�hlen: ";
//var L_LINKSELECTPAGE_TEXT = "Seite ausw�hlen";
//var L_LINKWEB_TEXT = "oder tragen Sie eine URL zu einer Webseite ein: ";
var L_PUTITLEBGCOLOR_TEXT = "Hintergrundfarbe setzen";
var L_PUTITLEFONTFACE_TEXT = "Schriftart setzen";
var L_PUTITLEFONTSIZE_TEXT = "Schriftgr�sse setzen";
var L_PUTITLEIMAGE_TEXT = "Bild einf�gen/bearbeiten";
var L_PUTITLELINK_TEXT = "Link einf�gen/bearbeiten";
var L_PUTITLENEWTABLE_TEXT = "Tabelle anlegen/bearbeiten";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Absatzart setzen";
var L_PUTITLECLASS_TEXT = "Zeichenart setzen";
var L_PUTITLETEXTCOLOR_TEXT = "Textfarbe setzen";
var L_PUTITLEEMOTICON_TEXT = "Symbol einf�gen";
var L_STYLEFORMATTED_TEXT = "Vorformatiert";
//var L_STYLECLASS_TEXT = "Text mit Kategorie";
var L_STYLEHEADING_TEXT = "Kopftext ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Hintergrund";
var L_TABLEBORDERS_TEXT = "R�nder";
var L_TABLEINPUTBGCOLOR_TEXT = "Hintergrund-Farbe: ";
var L_TABLEINPUTBGIMGURL_TEXT = "Hintergrund-Bild URL: ";
var L_TABLEINPUTBORDER_TEXT = "Rand Breite: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Rand Farbe: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Zellen Innenrand: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Zellen Abstand: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Spalten: ";
var L_TABLEINPUTROWS_TEXT = "Zeilen: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Innenrand und Abstand";
var L_TABLEROWSANDCOLS_TEXT = "Zeilen und Spalten";
var L_TABLEINSERTROW_TEXT = "Zeile einf�gen";
var L_TABLEINSERTCELL_TEXT = "Spalte einf�gen";
var L_TABLEINSERT_TEXT = "Tabelle einf�gen";
var L_TABLEUPDATE_TEXT = "Tabelle aktualisieren";
var L_TABLENEW_TEXT = "Tabelle anlegen";
var L_TABLEEDIT_TEXT = "Tabelle bearbeiten";
var L_TIPB_TEXT = "Fett";
var L_TIPBGCOLOR_TEXT = "Hintergrundfarbe";
var L_TIPCJ_TEXT = "Zentriert";
var L_TIPCOPY_TEXT = "Text kopieren";
var L_TIPCUT_TEXT = "Text ausschneiden";
var L_TIPDINDENT_TEXT = "Einzug verkleinern";
var L_TIPFGCOLOR_TEXT = "Textfarbe";
var L_TIPFSIZE_TEXT = "Schriftgr�sse";
var L_TIPFSTYLE_TEXT = "Schriftart";
var L_TIPI_TEXT = "Kursiv";
var L_TIPIINDENT_TEXT = "Einzug vergr�ssern";
var L_TIPLINE_TEXT = "Linie einf�gen";
var L_TIPLINK_TEXT = "Link einf�gen";
var L_TIPLJ_TEXT = "Linksb�ndig";
var L_TIPOL_TEXT = "Nummerierung";
var L_TIPP_TEXT = "Absatzart";
var L_TIPPASTE_TEXT = "Text einf�gen";
var L_TIPPICTURE_TEXT = "Bild einf�gen";
var L_TIPRJ_TEXT = "Rechtsb�ndig";
var L_TIPTABLE_TEXT = "Tabelle einf�gen";
var L_TIPU_TEXT = "Unterstrichen";
var L_TIPUL_TEXT = "Aufz�hlungszeichen";
var L_TIPEMOTICON_TEXT = "Symbol einf�gen";
var L_TIPCLASS_TEXT = "Zeichenart";
var L_MODETITLE_TEXT = "HTML-Quelltext";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Andere Schriftart...";
var L_CUSTOMFONTENTRY_TEXT = "Geben Sie den Namen Ihrer Schriftart ein:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Spalten";
var L_TBDATALABEL_TEXT   = 'Platzhalter f�r markierte Spalte einf�gen.';

var L_DEFAULTHTML_TEXT = "<DIV></DIV>";




var L_REMOVECLASS_TEXT = "Absatzart entfernen";	// Added!!!
var L_REMOVEALLHTML_TEXT = "Komplette HTML-Formatierung entfernen"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "Ziel-HTML-Marke";	// Added!!!











// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Options";
var L_TIPCOPY_TEXT2 = "Copy";
var L_TIPCUT_TEXT2 = "Cut";
var L_TIPPASTE_TEXT2 = "Paste";

