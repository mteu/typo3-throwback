var L_CANCEL_TEXT = "Cancelar";
var L_INSERT_TEXT = "Insertar";
//var L_LINKIMGBORDER_TEXT = "Desplegar borde alrededor de la liga de la im�ge";
//var L_LINKSELECT_TEXT = "Seleccionar una p�gina de la comunidad:  ";
//var L_LINKSELECTPAGE_TEXT = "Seleccionar una P�gina";
//var L_LINKWEB_TEXT = "o capture un URL que apunte una p�gina Web: ";
var L_PUTITLEBGCOLOR_TEXT = "Seleccionar color de fondo";
var L_PUTITLEFONTFACE_TEXT = "Seleccionar estilo de la fuente";
var L_PUTITLEFONTSIZE_TEXT = "Seleccionar tama�o de la fuente";
var L_PUTITLEIMAGE_TEXT = "Insertar / Editar Im�gen";
var L_PUTITLELINK_TEXT = "Insertar / Editar una liga";
var L_PUTITLENEWTABLE_TEXT = "Crear / Editar Tabla";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Seleccionar Estilo del P�rrafo";
var L_PUTITLECLASS_TEXT = "Seleccionar Estilo del Caracter";
var L_PUTITLETEXTCOLOR_TEXT = "Seleccionar Color del TExto";
var L_PUTITLEEMOTICON_TEXT = "Insertar S�mbolo";
var L_STYLEFORMATTED_TEXT = "Preformateado";
//var L_STYLECLASS_TEXT = "Texto con Clase";
var L_STYLEHEADING_TEXT = "Encabezado ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Fondo";
var L_TABLEBORDERS_TEXT = "Bordes";
var L_TABLEINPUTBGCOLOR_TEXT = "Color de Fondo: ";
var L_TABLEINPUTBGIMGURL_TEXT = "URL de la Im�gen del Fondo: ";
var L_TABLEINPUTBORDER_TEXT = "Anchura del Borde: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Color del Borde: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Tama�o de Celdas: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Espaciado de Celdas: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Columnas: ";
var L_TABLEINPUTROWS_TEXT = "Filas: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Tama�o y Espaciado";
var L_TABLEROWSANDCOLS_TEXT = "Filas y Columnas";
var L_TABLEINSERTROW_TEXT = "Insertar Filas";
var L_TABLEINSERTCELL_TEXT = "Insertar Columnas";
var L_TABLEINSERT_TEXT = "Insertar Tabla";
var L_TABLEUPDATE_TEXT = "Actualizar Tabla";
var L_TABLENEW_TEXT = "Tabla Nueva";
var L_TABLEEDIT_TEXT = "Editar Tabla";
var L_TIPB_TEXT = "Negrillas";
var L_TIPBGCOLOR_TEXT = "Color de Fondo";
var L_TIPCJ_TEXT = "Justificar al Centro";
var L_TIPCOPY_TEXT = "Copiar Texto";
var L_TIPCUT_TEXT = "Cortar Texto";
var L_TIPDINDENT_TEXT = "Disminuir Identaci�n";
var L_TIPFGCOLOR_TEXT = "Color del Texto";
var L_TIPFSIZE_TEXT = "Tama�o de la Fuente";
var L_TIPFSTYLE_TEXT = "Estilo de la Fuente";
var L_TIPI_TEXT = "It�licas";
var L_TIPIINDENT_TEXT = "Aumentar Identaci�n";
var L_TIPLINE_TEXT = "Insertar L�nea";
var L_TIPLINK_TEXT = "Insertar Liga";
var L_TIPLJ_TEXT = "Justificar a la Izquierda";
var L_TIPOL_TEXT = "Lista Numerada";
var L_TIPP_TEXT = "Estilo de P�rrafo";
var L_TIPPASTE_TEXT = "Pegar Texto";
var L_TIPPICTURE_TEXT = "Insertar Im�gen";
var L_TIPRJ_TEXT = "Justificar a la Derecha";
var L_TIPTABLE_TEXT = "Insertar Tabla";
var L_TIPU_TEXT = "Subrayar";
var L_TIPUL_TEXT = "Texto con Vi�etas";
var L_TIPEMOTICON_TEXT = "S�mbolos";
var L_TIPCLASS_TEXT = "Estilo del Caracter";
var L_MODETITLE_TEXT = "C�digo Fuente";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Otra Fuente...";
var L_CUSTOMFONTENTRY_TEXT = "Especifique el nombre de su fuente:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Columnas";
var L_TBDATALABEL_TEXT   = 'Apartar el espacio de la columna seleccionada.';

var L_DEFAULTHTML_TEXT = "<DIV></DIV>";




var L_REMOVECLASS_TEXT = "Remover el Estilo del Caracte";	// Added!!!
var L_REMOVEALLHTML_TEXT = "Remover el Formateo HTML"; // Added!!!
var L_TARGETTAGCLASS_TEXT = "Etiqueta-HTML objetivo";	// Added!!!







// THESE ARE NEW AND NOT TRANSLATED:
var L_TIPUSER_TEXT = "Insert user elements";
var L_PUTITLEUSER_TEXT = "Various elements";
var L_OPTIONS = "Options";
var L_TIPCOPY_TEXT2 = "Copy";
var L_TIPCUT_TEXT2 = "Cut";
var L_TIPPASTE_TEXT2 = "Paste";

