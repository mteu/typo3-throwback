var L_CANCEL_TEXT = "Angre";
var L_INSERT_TEXT = "Sett inn";
//var L_LINKIMGBORDER_TEXT = "Vis en ramme rundt bildelinken";
//var L_LINKSELECT_TEXT = "Velg en omr�deside: ";
//var L_LINKSELECTPAGE_TEXT = "Velg side";
//var L_LINKWEB_TEXT = "eller skriv inn adressen (URL) til en side p� Internett: ";
var L_PUTITLEBGCOLOR_TEXT = "Velg bakgrunnsfarge";
var L_PUTITLEFONTFACE_TEXT = "Velg skrifttype";
var L_PUTITLEFONTSIZE_TEXT = "Velg skriftst�rrelse";
var L_PUTITLEIMAGE_TEXT = "Sett inn/ rediger bilde";
var L_PUTITLELINK_TEXT = "Sett inn/ rediger link";
var L_PUTITLENEWTABLE_TEXT = "Sett inn/ rediger tabell";
var L_PUTITLEPARAGRAPHSTYLE_TEXT = "Velg avsnittsstil/ -format";
var L_PUTITLECLASS_TEXT = "Velg tekststil";
var L_PUTITLETEXTCOLOR_TEXT = "Velg skriftfarge";
var L_PUTITLEEMOTICON_TEXT = "Sett inn symbol";
var L_STYLEFORMATTED_TEXT = "Formatert";
//var L_STYLECLASS_TEXT = "Text with Class";
var L_STYLEHEADING_TEXT = "Overskrift ";
var L_STYLENORMAL_TEXT = "Normal";
var L_STYLESAMPLE_TEXT = "ABCabc012...  ";
var L_TABLEBG_TEXT = "Bakgrunn";
var L_TABLEBORDERS_TEXT = "Kanter";
var L_TABLEINPUTBGCOLOR_TEXT = "Bakgrunnsfarge: ";
var L_TABLEINPUTBGIMGURL_TEXT = "Link til bakgrunnsbilde (URL): ";
var L_TABLEINPUTBORDER_TEXT = "Kantlinjebredde: ";
var L_TABLEINPUTBORDERCOLOR_TEXT = "Kantlinje farge: ";
var L_TABLEINPUTCELLPADDING_TEXT = "Celleutfylling: ";
var L_TABLEINPUTCELLSPACING_TEXT = "Celleavstand: ";
var L_TABLEINPUTCOLUMNS_TEXT = "Kolonner: ";
var L_TABLEINPUTROWS_TEXT = "Rader: ";
var L_TABLEPADDINGANDSPACING_TEXT = "Utfylling og avstand";
var L_TABLEROWSANDCOLS_TEXT = "Rader og kolonner";
var L_TABLEINSERTROW_TEXT = "Sett inn rad";
var L_TABLEINSERTCELL_TEXT = "Sett inn kolonne";
var L_TABLEINSERT_TEXT = "Sett inn tabell";
var L_TABLEUPDATE_TEXT = "Oppdater tabell";
var L_TABLENEW_TEXT = "Ny tabell";
var L_TABLEEDIT_TEXT = "Rediger tabell";
var L_TIPB_TEXT = "Sterk";
var L_TIPBGCOLOR_TEXT = "Bakgrunnsfarge";
var L_TIPCJ_TEXT = "Midtstilt";
var L_TIPCOPY_TEXT = "Kopier tekst";
var L_TIPCUT_TEXT = "Klipp ut tekst";
var L_TIPDINDENT_TEXT = "Fjern innrykk";
var L_TIPFGCOLOR_TEXT = "Skriftfarge";
var L_TIPFSIZE_TEXT = "Skriftst�rrelse";
var L_TIPFSTYLE_TEXT = "Skrifttype";
var L_TIPI_TEXT = "Kursiv";
var L_TIPIINDENT_TEXT = "Legg til innrykk";
var L_TIPLINE_TEXT = "Sett inn linje";
var L_TIPLINK_TEXT = "Sett inn link";
var L_TIPLJ_TEXT = "Venstrejustering";
var L_TIPOL_TEXT = "Nummerert liste";
var L_TIPP_TEXT = "Avsnittsstil/ -format";
var L_TIPPASTE_TEXT = "Lim inn tekst";
var L_TIPPICTURE_TEXT = "Sett inn bilde";
var L_TIPRJ_TEXT = "H�yrejustert";
var L_TIPTABLE_TEXT = "Sett inn tabell";
var L_TIPU_TEXT = "Understreking";
var L_TIPUL_TEXT = "Punktmerket liste";
var L_TIPEMOTICON_TEXT = "Symboler";
var L_TIPCLASS_TEXT = "Tekststil";
var L_MODETITLE_TEXT = "Kildekodee";
var L_MODEDESC_TEXT = "";
//var L_CUSTOMFONT_TEXT = "Annen skrifttype...";
var L_CUSTOMFONTENTRY_TEXT = "Skriv inn navnet p� skrifttypen:";
var L_SAMPLEFONTENTRY_TEXT = "Arial, Geneva, Sans-serif";
var L_CLOSEBUTTON_TEXT = "x";
var L_TBDATABINDING_TEXT = "Kolonner";
var L_TBDATALABEL_TEXT   = 'Sett inn en midlertidig erstatning for valgte kolonnen.';
var L_DEFAULTHTML_TEXT = "<DIV></DIV>";
var L_REMOVECLASS_TEXT = "Fjern skriftstil";
var L_REMOVEALLHTML_TEXT = "Fjern all HTML formaterting";
var L_TARGETTAGCLASS_TEXT = "Aktuell HTML-tag";
var L_TIPUSER_TEXT = "Sett inn brukerelementer";
var L_PUTITLEUSER_TEXT = "Diverse elementer";
var L_OPTIONS = "Alternativer";
var L_TIPCOPY_TEXT2 = "Kopier";
var L_TIPCUT_TEXT2 = "Klipp ut";
var L_TIPPASTE_TEXT2 = "Lim inn";











// THESE ARE NEW AND NOT TRANSLATED:
